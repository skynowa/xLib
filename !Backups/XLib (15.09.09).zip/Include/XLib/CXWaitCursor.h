/****************************************************************************
* Class name:  CXWaitCursor
* Description: wait cursor
* File name:   CXWaitCursor.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.06.2009 19:08:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXWaitCursorH
#define CXWaitCursorH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXWaitCursor {
		_NO_COPY(CXWaitCursor);
		
	public:
		//Set the cursor remembering the old cursor.
		CXWaitCursor() {
			
			m_hCursor = ::SetCursor(::LoadCursor(NULL, IDC_WAIT));
		}

		//Restore cursor when it was valid. If it was not set the arrow cursor.
		virtual ~CXWaitCursor()	{
			
			::SetCursor( m_hCursor ? m_hCursor : ::LoadCursor(NULL, IDC_ARROW));
		}

		//Restore the wait cursor.
		inline void Restore() {
			::SetCursor( ::LoadCursor(NULL, IDC_WAIT));
		}
		
	private:
		HCURSOR m_hCursor;
};
//---------------------------------------------------------------------------
#endif