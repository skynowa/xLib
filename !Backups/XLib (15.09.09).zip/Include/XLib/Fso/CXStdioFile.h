/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef	CXStdioFileH
#define	CXStdioFileH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <io.h>
#include <fcntl.h>
#include <vector>
#include <hash_map>
#include <map>
//---------------------------------------------------------------------------
class CXStdioFile {
		_NO_COPY(CXStdioFile);
		
	public:
	    //
	    enum EErrorType{
			etError = EOF
	    };  

		//File attribute
		enum EAttributes {
			faInvalid  = - 1,           /*?*/
			faNormal   =  _A_NORMAL,    /* Normal file - No read/write restrictions */
			faReadOnly =  _A_RDONLY,	/* Read only file */
			faHidden   =  _A_HIDDEN,    /* Hidden file */
			faSystem   =  _A_SYSTEM,    /* System file */
			faSubDir   =  _A_SUBDIR,    /* Subdirectory */
			faArchive  =  _A_ARCH ,     /* Archive file */			
		};	
		
		//Translation mode
		typedef enum {
			tmText   = _O_TEXT,          /* file mode is text (translated) */
			tmBinary = _O_BINARY         /* file mode is binary (untranslated) */
		} ETranslationMode;	
		
		//Access mode
		typedef enum {
			amExistence = 0,	//Existence only
			amWrite     = 2, 	//Write permission
			amRead      = 4,	//Read permission
			amReadWrite = 6	//Read and write permission
		} EAccessMode;	
		
		//file position data for the given stream
		typedef enum {
			ppBegin = SEEK_SET,	
			ppCurr  = SEEK_CUR,	
			ppEnd   = SEEK_END,
			ppError = - 1L	
		} EPointerPosition;	
		
		//mode for file buffering
		typedef enum {
			bmFull = _IOFBF, 
			bmLine = _IOLBF, 
			bmNo   = _IONBF	 
		} EBufferingMode;
		
		//Locking action to perform
		typedef enum {
			/*[BC++]*/ //lmTryLock = _LK_LOCK,		//Locks the specified bytes. If the bytes cannot be locked, the program immediately tries again after 1 second. If, after 10 attempts, the bytes cannot be locked, the constant returns an error.
			/*[BC++]*/ //lmLock    = _LK_NBLCK,		//Locks the specified bytes. If the bytes cannot be locked, the constant returns an error.
			////lmXXX = _LK_NBRLCK,		//Same as _LK_NBLCK.
			////lmXXX = _LK_RLCK,		//Same as _LK_LOCK.
			/*[BC++]*/ //lmUnlock  = _LK_UNLCK		//Unlocks the specified bytes, which must have been previously locked.
		} ELockingMode;
		
		
		//Permission mode
		typedef enum {
			pmWrite     = _S_IWRITE,				//Writing permitted
			pmRead      = _S_IREAD,					//Reading permitted
			pmReadWrite = (_S_IREAD | _S_IWRITE)	//Reading and writing permitted
		} EPermissionMode;
		
	
			               CXStdioFile         ();	
			              ~CXStdioFile         ();	
			              
		operator           FILE *              ();	
		
		FILE              *pGetFile            ();
		BOOL               bOpen               (const std::string &csFilePath, const std::string &csMode);	
		BOOL               bReopen             (const std::string &csFilePath, const std::string &csMode);	
		std::string        sGetFilePath        ();	
		
		
		/****************************************************************************
		* ������ / ������ �����
		*
		*****************************************************************************/

		size_t             uiRead              (LPVOID pvBuf,         size_t uiCount); 
		size_t             uiWrite             (const LPVOID pcvBuff, size_t uiCount); 

		BOOL               bReadAll            (LPVOID pvBuff,       size_t uiBuffSize, const size_t cuiBlockSize);
		BOOL               bWriteAll           (const LPVOID pcvBuf, size_t uiBuffSize, const size_t cuiBlockSize);
		
		BOOL               bReadLine           (LPSTR pszStr, size_t uiMaxSize); 
		BOOL               bWriteLine          (const std::string &csStr); 	

		BOOL               bWriteChar          (CHAR cChar); 
		CHAR               cReadChar           (); 
		BOOL               bUngetChar          (CHAR cChar); 
		
		BOOL               bWriteString        (const std::string &csStr); 
				
		static BOOL        bReadFile           (const std::string &csFilePath, std::vector<std::string> *pvecsVector);
		static BOOL        bWriteFile          (const std::string &csFilePath, const std::vector<std::string> &cvecsVector);
		
		static BOOL        bReadFile           (const std::string &csFilePath, std::map<std::string, std::string> *pmsMap);
		static BOOL        bWriteFile          (const std::string &csFilePath, const std::map<std::string, std::string> &cmsMap);
		/////////////////////////////////	
		

		BOOL               bLocking            (ELockingMode lmMode, LONG liBytes); 
		BOOL               bSetPosition        (LONG lOffset, EPointerPosition fpPos/* = fpBegin*/); 
		LONG               liGetPosition       (); 
		BOOL               bClose              (); 
		BOOL               bFlush              (); 
		LONG               liGetSize           (); 
		BOOL               bChsize             (LONG liSize); 
		BOOL               bSetVBuff           (LPSTR pszBuff, EBufferingMode bmMode, size_t uiSize); 
		BOOL               bSetMode            (ETranslationMode tmMode); 
		

		
		//Character input/output:
		static CHAR        cGetCharFromStdin   (); 
		static std::string sGetStringFromStdin (LPSTR pszBuff); 
		static BOOL        bWriteCharToStdout  (CHAR cChar); 
		static BOOL        bWriteStringToStdout(const std::string &csStr);

		//Operations on files:
		static BOOL        bIsExists           (const std::string &csFilePath); 
		static BOOL        bAccess             (const std::string &csFilePath, EAccessMode amMode); 
		static BOOL        bChmod              (const std::string &csFilePath, EPermissionMode pmMode); 
		static BOOL        bRemove             (const std::string &csFilePath); 
		static BOOL        bUnlink             (const std::string &csFilePath);	
		static BOOL        bRename             (const std::string &csOldFilePath, const std::string &csNewFilePath); 
		static BOOL        bMove               (const std::string &csFilePath, const std::string &csDirPath); 
		static BOOL        bCopy               (const std::string &csFromFilePath, const std::string &csToFilePath);

		static BOOL        bExec               (const std::string &csFilePath); 
        static std::string sCreateTempFileName (); 
		static BOOL        bFlushAllOutput     (); 
		static INT         iFlushAll           (); 
		static ULONG       ulLines             (const std::string &csFilePath); 

		//Formatted input/output:
		INT                iFprintf            (LPCSTR pcszFormat, ...); 
		static INT         iPrintf             (LPCSTR pcszFormat, ...); 
		static INT         iSprintf            (LPSTR  pszStr,  LPCSTR pcszFormat, ...); 
		INT                iVfprintf           (LPCSTR pcszFormat, va_list arg); 
		static INT         iVprintf            (LPCSTR pcszFormat, va_list arg); 
		static INT         iVsprintf           (LPSTR  pszStr, LPCSTR pcszFormat, va_list arg); 

		//Error-handling:
		BOOL               bClearErr           (); 
		BOOL               bIsEof              (); 
		BOOL               bIsError            (); 	
		static BOOL        bPrintError         (const std::string &csStr); 		

		//Macros
		//FILENAME_MAX	Maximum length of file names (constant)
		//TMP_MAX		Number of temporary files (constant)

		/****************************************************************************
		* ������ / ������ ����� (all not tested)
		*
		*****************************************************************************/
		static std::vector<std::string> vecsReadFile             (const std::string &csFilePath); 
		static BOOL                     bReadFile		         (const std::string &csFilePath, std::vector<CHAR> *pvecchVector); 
		static std::map<std::string, std::string> mapReadFile    (const std::string &csFilePath, const std::string &csDelimiter); 
		static BOOL                     bReadFile                (const std::string &csFilePath, std::string &cStr); 


	private:
		FILE             *_m_pFile;
		std::string       _m_sFilePath;
		INT               _iGetHandle          ();
};
//---------------------------------------------------------------------------
#endif	


/*
"r"		Open a file for reading. The file must exist.
"w"		Create an empty file for writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file. 
"a"		Append to a file. Writing operations append data at the end of the file. The file is created if it does not exist.
"r+"	Open a file for update both reading and writing. The file must exist.
"w+"	Create an empty file for both reading and writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file.
"a+"	Open a file for reading and appending. All writing operations are performed at the end of the file, protecting the previous content to be overwritten. You can re
*/




/*
//setlocale(LC_NUMERIC, "");
//setlocale(LC_ALL, ".ACP" );
//setlocale(LC_ALL,"Russian");
*/


//TODO: std::ifsStream - �� ������ ������� �����