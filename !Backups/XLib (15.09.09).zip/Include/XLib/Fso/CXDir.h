/****************************************************************************
* Class name:  CXDir
* Description: �������� � �������
* File name:   CXDir.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXDirH
#define CXDirH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <vector>
//---------------------------------------------------------------------------
class CXDir {
	public:
								    	CXDir        ();
								       ~CXDir        ();
		static BOOL                     bIsExists    (const std::string &csDirPath); /*+*/
		static BOOL                     bIsEmpty     (const std::string &csDirPath, const std::string &csMask); /*+*/
		static std::string              sGetCurrent  ();  /*+*/
		static BOOL                     bSetCurrent  (const std::string &csDirPath); /*+*/
		static std::string              sGetTempPath (); /*+*/
		static BOOL                     bCreate      (const std::string &csDirPath); /*+*/
		static VOID                     vForceCreate (const std::string &csDirPath); /*+*/
		static BOOL                     bCopy        (const std::string &csDirPathFrom, const std::string &cscsDirPathTo, BOOL bFailIfExists); /*+*/
		static BOOL                     bDelete      (const std::string &csDirPath); /*+*/
		static BOOL                     bForceClear  (const std::string &csDirPath); /*+*/
		static BOOL                     bForceDelete (const std::string &csDirPath); /*+*/
		static std::vector<std::string> vecsListFiles(const std::string &csDirPath, const std::string &csMask); /*+*/
		static std::vector<std::string> vecsListDirs (const std::string &csDirPath); /*+*/
};
//---------------------------------------------------------------------------
#endif
