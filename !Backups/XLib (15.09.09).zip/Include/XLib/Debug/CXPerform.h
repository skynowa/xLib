/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.h
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#ifndef CXPerformH
#define CXPerformH       
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <time.h>
//---------------------------------------------------------------------------
class CXPerform {
		_NO_COPY(CXPerform);
		
	public:
		//Perfomance mode
		typedef enum  {
			pmUknown, 
			pmTime, 
			pmGetTickCount, 
			pmQueryPerformanceCounter, 
			pmGetThreadTimes
		} EPerfomMode;	
		
					  CXPerform            (const std::string &csFileName, EPerfomMode pmPerformMode); //todo: csFileName + iPerfomMode
		             ~CXPerform            ();
		BOOL          bStart               ();
		BOOL          bStop                (const std::string &csComment);
        BOOL          bPulse               (const std::string &csComment);     
        BOOL          bPulse               (ULONG  ulComment);
        BOOL          bOpenLog             ();
		BOOL          bDeleteLog           ();

    private:
		EPerfomMode   _m_pmPerfomModeNow;		 
        BOOL          _m_bWasStarted;

		BOOL          _bResetData           ();
        std::string   _sMilliSecToTimeString(LONGLONG i64MilliSec); 
		
		//pmTime
		//TDateTime    dtBeginTime;
		//TDateTime    dtEndTime;

		//pmGetTickCount
		ULONG         _m_ulBeginTime;
		ULONG         _m_ulEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER _m_liStart;
		LARGE_INTEGER _m_liBeginCount;
		LARGE_INTEGER _m_liEndCount;
		LARGE_INTEGER _m_liCount;
		
		//GetThreadTimes
		FILETIME      _m_lpCreationTime;  
		FILETIME      _m_lpExitTime;
		FILETIME      _m_lpKernelTime0;
		FILETIME      _m_lpUserTime0;
		FILETIME      _m_lpKernelTime1;
		FILETIME      _m_lpUserTime1;
		LONGLONG      _iFiletimeToint64     (FILETIME F);

		//���
		std::string   _m_sLogPath;
		BOOL          _bLog                (const std::string &csText);
        BOOL          _bLog                (const std::string &csComment, const std::string &csText); 
};
//---------------------------------------------------------------------------
#endif