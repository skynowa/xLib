/****************************************************************************
* Class name:  CXResources
* Description: 
* File name:   CXResources.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.09.2009 9:44:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/





#ifndef CXResourcesH
#define CXResourcesH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXString.h>
#include <vector>
#include <map>
#include <boost/preprocessor/seq/elem.hpp>
//---------------------------------------------------------------------------
/*
#define (ID)(Left)(Top)(Width)(Length)(Style)(StyleEx)
*/	
#define CTRL_ID(CTRL)       BOOST_PP_SEQ_ELEM(0, CTRL)	
#define CTRL_LEFT(CTRL)     BOOST_PP_SEQ_ELEM(1, CTRL)
#define CTRL_TOP(CTRL)      BOOST_PP_SEQ_ELEM(2, CTRL)
#define CTRL_WIDTH(CTRL)	BOOST_PP_SEQ_ELEM(3, CTRL)
#define CTRL_HEIGHT(CTRL)	BOOST_PP_SEQ_ELEM(4, CTRL)
#define CTRL_STYLE (CTRL)   BOOST_PP_SEQ_ELEM(5, CTRL)
#define CTRL_STYLE_EX(CTRL) BOOST_PP_SEQ_ELEM(6, CTRL)

#define CTRL1_PROPERTIES 1001
#define CTRL2_PROPERTIES 1002
//---------------------------------------------------------------------------
class CXResources {
	public:
		//-------------------------------------
		//����� �������� ���������	
		class CXSettings {
			public:
					 CXSettings() :
						 _m_iLeft  (0), 
						 _m_iTop   (0), 
						 _m_iWidth (0), 
						 _m_iHeight(0)		 {}

				    ~CXSettings()            {}

				//Left
				INT  iGetLeft  () const      {return _m_iLeft;}
				VOID vSetLeft  (INT iLeft)   {_m_iLeft = iLeft;}
				
				//Top
				INT  iGetTop   () const      {return _m_iTop;}
				VOID vSetTop   (INT iTop)    {_m_iTop = iTop;}
                
				//Width
				INT  iGetWidth () const      {return _m_iWidth;}
				VOID vSetWidth (INT iWidth)  {_m_iWidth = iWidth;}
                
				//Height
				INT  iGetHeight() const      {return _m_iHeight;}
				VOID vSetHeight(INT iHeight) {_m_iHeight = iHeight;}
			
			private:
				INT _m_iLeft; 
				INT _m_iTop; 
				INT _m_iWidth; 
				INT _m_iHeight;
		};

/*----------------------------------------------------------------------*/ 
/* <������> ��������� �������� (������� ������������ ����������)        */
/*----------------------------------------------------------------------*/ 


	public:	
		CXResources() {
			BOOL bRes = FALSE;

			const std::string csIncludeFileContent =                              
									#include "d:/XLib/Test/GUI/CXFrame/Resource.xrc"				
		    ;
			
			bRes = _bParseIncludeFileContent(csIncludeFileContent);


			//////-------------------------------------
			//////m_CXButton1
			////_m_Settings[0].vSetLeft  (CTRL_LEFT(CTRL1_PROPERTIES));				//<<< 
			////_m_Settings[0].vSetTop   (CTRL_TOP(CTRL1_PROPERTIES));				//<<< 
			////_m_Settings[0].vSetWidth (CTRL_WIDTH(CTRL1_PROPERTIES));				//<<< 
			////_m_Settings[0].vSetHeight(CTRL_HEIGHT(CTRL1_PROPERTIES));				//<<< 

			////bRes = bAddControl(CTRL_ID(CTRL1_PROPERTIES), &_m_Settings[0]);	//<<< 
			/////*DEBUG*/XASSERT(TRUE == bRes);

			//////-------------------------------------
			//////m_CXButton2
			////_m_Settings[1].vSetLeft  (CTRL_LEFT(CTRL2_PROPERTIES));				//<<< 
			////_m_Settings[1].vSetTop   (CTRL_TOP(CTRL2_PROPERTIES));				//<<< 
			////_m_Settings[1].vSetWidth (CTRL_WIDTH(CTRL2_PROPERTIES));				//<<< 
			////_m_Settings[1].vSetHeight(CTRL_HEIGHT(CTRL2_PROPERTIES));				//<<< 

			////bRes = bAddControl(CTRL_ID(CTRL2_PROPERTIES), &_m_Settings[1]);	//<<< 
			/////*DEBUG*/XASSERT(TRUE == bRes);
    	}
		~CXResources() {}

	private:
		CXSettings _m_Settings[2];

		BOOL       _bParseIncludeFileContent(const std::string &csFileContent) {
			/*DEBUG*/XASSERT_RET(false == csFileContent.empty(), FALSE);
			/*DEBUG*///���� �� [;"] � ����� ������
			
			BOOL bRes = FALSE;

			//---------------------------
			//���� ���������� ������ [CTRL1_PROPERTIES 0,0,75,25,0,0;CTRL2_PROPERTIES 10,10,75,25,0,0;]
			std::vector<std::string> vecsLines;
			
			bRes = bSplit(csFileContent, ";", &vecsLines);
			CHECK_RET(FALSE == bRes, FALSE);

			//---------------------------
			//������ ������ ��������:
			//	CTRL1_PROPERTIES 0,0,75,25,0,0	
			//	CTRL2_PROPERTIES 10,10,75,25,0,0
			//	[������ ������]
			for (std::size_t i = 0; i < vecsLines.size() - 1; i ++) {
				INT   iID       = - 1;
				INT   iLeft     = - 1;
				INT   iTop      = - 1;
				INT   iWidth    = - 1;
				INT   iHeight   = - 1;
				//ULONG ulStyle   = - 1;
				//ULONG ulStyleEx = - 1;

				//������ ������ [ID Left,Top,Width,Height,Style,StyleEx]
				std::string sLine = "";

				sLine = vecsLines.at(i);
				sLine = sReplaceAll(sLine, "\t", " ");
				sLine = sTrimSpace(sLine);
				CHECK_DO(true == sLine.empty(), continue);

				//ID + Values [ID Left,Top,Width,Height,Style,StyleEx]
				std::vector<std::string> vecsID_And_Values;
				bRes = bSplit(sLine, " ", &vecsID_And_Values);
				CHECK_RET(FALSE == bRes, FALSE);

				iID  = tStrToAnyT<INT>(vecsID_And_Values.at(0));	

				//Values
				std::vector<std::string> vecsValues;
				bRes = bSplit(vecsID_And_Values.at(1), ",", &vecsValues);
				CHECK_RET(FALSE == bRes, FALSE);

				iLeft   = tStrToAnyT<INT>(vecsValues.at(0));
				iTop    = tStrToAnyT<INT>(vecsValues.at(1));
				iWidth  = tStrToAnyT<INT>(vecsValues.at(2));
				iHeight = tStrToAnyT<INT>(vecsValues.at(3));
				//ulStyle   = tStrToAnyT<ULONG>(vecsValues.at(4));
				//ulStyleEx = tStrToAnyT<ULONG>(vecsValues.at(5));

				//������������� �������� (Left, Top, Width, Height, Style, StyleEx)
				_m_Settings[i].vSetLeft   (iLeft);				
				_m_Settings[i].vSetTop    (iTop);				
				_m_Settings[i].vSetWidth  (iWidth);				
				_m_Settings[i].vSetHeight (iHeight);				
				//_m_Settings[i].vSetStyle  (ulStyle);				
				//_m_Settings[i].vSetStyleEx(ulStyleEx);				

				//��������� �������
				bRes = bAddControl(iID, &_m_Settings[i]);	
				/*DEBUG*/XASSERT(TRUE == bRes);
			}





			return TRUE;
		}


/*----------------------------------------------------------------------*/ 
/* <�����> ��������� ��������                                           */
/*----------------------------------------------------------------------*/ 
	public:	

		//-------------------------------------
		//�������� ��������� ��������
		INT iGetLeft(INT iID) {
			CHECK_RET(true == _m_SettingsMap.empty(), 0);

			return _m_SettingsMap[iID]->iGetLeft();
		}
		INT iGetTop(INT iID) {
			CHECK_RET(true == _m_SettingsMap.empty(), 0);

			return _m_SettingsMap[iID]->iGetTop();
		}
		INT iGetWidth(INT iID) {
			CHECK_RET(true == _m_SettingsMap.empty(), 0);

			return _m_SettingsMap[iID]->iGetWidth();
		}
		INT iGetHeight(INT iID) {
			CHECK_RET(true == _m_SettingsMap.empty(), 0);

			return _m_SettingsMap[iID]->iGetHeight();
		}
	
	private:
		typedef std::map<INT, const CXSettings *> TSettingsMap;	
		TSettingsMap _m_SettingsMap;

		BOOL bAddControl(INT iID, const CXSettings *pcSettings) {
			XASSERT_RET(0 < iID,            FALSE);
			XASSERT_RET(NULL != pcSettings, FALSE);

			_m_SettingsMap[iID] = pcSettings;

			return TRUE;
		}
		
		BOOL bRemoveControl(INT iID) {
			XASSERT_RET(0 < iID, FALSE);

			TSettingsMap::const_iterator it;

			it = _m_SettingsMap.find(iID);
			XASSERT_RET(_m_SettingsMap.end() != it, FALSE);

			_m_SettingsMap.erase(it);
			
			return TRUE;
		}
};
//---------------------------------------------------------------------------
#endif