/****************************************************************************
*    �����: CXCrc32 (CXCrc32.h)
*
*****************************************************************************/



#ifndef CXCrc32H
#define CXCrc32H
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXCrc32 {
        _NO_COPY(CXCrc32);
        
	public:
						  CXCrc32       ();
						  ~CXCrc32      ();

		unsigned long int ulCalc        (unsigned char *pucBuff, unsigned long int ulSize);
		unsigned long int ulCalcFile    (const std::string &csFilePath);

		
		unsigned long int ulCalcFast    (unsigned char *pucBuff, unsigned long int ulSize);
		unsigned long int ulCalcFileFast(const std::string &csFilePath);

	private:
		unsigned long int ulFileSize    (FILE *pFile);
};
//---------------------------------------------------------------------------
#endif
