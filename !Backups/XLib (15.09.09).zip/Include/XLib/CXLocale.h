/****************************************************************************
* Class name:  CXLocale
* Description: ������
* File name:   CXLocale.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.08.2009 19:47:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLocaleH
#define CXLocaleH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <locale.h>
//---------------------------------------------------------------------------
class CXLocale {
	public:
		                  CXLocale   ();
	                     ~CXLocale   ();
	   
	   static std::string sGetCurrent();
	   static BOOL        bSetCurrent(const std::string &csLocale);
	   static BOOL        bSetDefault();
};
//---------------------------------------------------------------------------
#endif