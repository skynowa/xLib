/**********************************************************************
*	vExecStr - ������� ������� �� ������
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vExecStr(const UnicodeString &cusStr) {
	STARTUPINFO         si;   ZeroMemory(&si, sizeof(si));   si.cb = sizeof(si);
	PROCESS_INFORMATION pi;   ZeroMemory(&pi, sizeof(pi));

	if (!CreateProcess(NULL, cusStr.w_str(), NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi)) {
        return;
	}

	////WaitForSingleObject(pi.hProcess, INFINITE);

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
}
//---------------------------------------------------------------------------
