/**********************************************************************
*	������ � ������������ (������� Split)
*
***********************************************************************/


AnsiString __fastcall TfrmMain::Split(const AnsiString & asStr, char cDelimiter, int iIndex) {
    TStringList* pList = new TStringList(); 
    pList->Delimiter     = cDelimiter;
    pList->DelimitedText = asStr;

    if (iIndex < 0 || iIndex >= pList->Count) {
        return "";
    }

    return pList->Strings[iIndex];
}
