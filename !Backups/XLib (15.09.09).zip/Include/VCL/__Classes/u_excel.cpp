
#include <vcl.h>
#pragma hdrstop

#include "u_excel.h"
////#pragma package(smart_init)
//---------------------------------------------------------------------------
CExcel::CExcel() {
    //MessageBox(NULL, "����������� CExcel", "�����������!", 0 | 48 | 0 | 0 | 262144);
}
//---------------------------------------------------------------------------
CExcel::~CExcel() {
    //MessageBox(NULL, "���������� CExcel", "����������!", 0 | 48 | 0 | 0 | 262144);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vCreateApplication() {
    try {
        vExcel = CreateOleObject("Excel.Application");
    } catch (Exception &exception) {
        Application->ShowException(&exception);
    }                    
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vCloseAppication() {
    //Excel.OlePropertySet("Visible",true);
    DeleteFileA(asTemplatePath);
    vExcel.OlePropertyGet("Workbooks").OlePropertyGet("Item", 1).OleProcedure("SaveAs", asTemplatePath.c_str());
    DeleteFileA(asTemplatePath);
    vExcel.OlePropertyGet("Workbooks").OleProcedure("Close");
    vExcel.Clear();
    vExcel = Unassigned;
}
//---------------------------------------------------------------------------
void CExcel::OutText(AnsiString asCell, AnsiString asText, bool bHorizAlign, bool bVertAlign, bool bBold) {
    vExcel.OlePropertyGet("Range", asCell.c_str()).OleProcedure("Merge"); //����������� �����
    vExcel.OlePropertyGet("Range", asCell.c_str()).OlePropertySet("NumberFormat", "@");
    vExcel.OlePropertyGet("Range", asCell.c_str()).OlePropertySet("Value", asText.c_str());
    if (bHorizAlign) {
        vExcel.OlePropertyGet("Range", asCell.c_str()).OlePropertySet("HorizontalAlignment", 3); //�������������
    }
    if (bVertAlign) {
        vExcel.OlePropertyGet("Range", asCell.c_str()).OlePropertySet("VerticalAlignment", 2);  //�������������
    }
    if (bBold) {
        vExcel.OlePropertyGet("Range", asCell.c_str()).OlePropertyGet("Font").OlePropertySet("Bold", true);   //������ �����
    }
}
//---------------------------------------------------------------------------
void CExcel::OutTextA(AnsiString Cell, AnsiString Text, bool HorizAlign, bool VertAlign, TFont *Font, bool Bold) {
    vExcel.OlePropertyGet("Range", Cell.c_str()).OleProcedure("Merge"); //����������� �����
    vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertySet("NumberFormat", "@");
    vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertySet("Value", Text.c_str());
    if (HorizAlign) {
        vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertySet("HorizontalAlignment", 3);  //�������������
    }
    if (VertAlign) {
        vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertySet("VerticalAlignment", 2);    //�������������
    }
    //��������� ������
    if (Bold) {
        vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Bold", true);   //������ �����
    }
    vExcel.OlePropertyGet("range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Size", Font->Size); //������ �����
}
//---------------------------------------------------------------------------
void CExcel::OutTextBox(AnsiString Cell, AnsiString Text, bool HorizAlign, bool VertAlign, TFont *Font, bool Bold, int BoxStyle, int Width) {
    vExcel.OlePropertyGet("Range", Cell.c_str()).OleProcedure("Merge"); //����������� �����
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("NumberFormat", "@");
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("ColumnWidth", Width);
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("Value", Text.c_str());
    if (HorizAlign) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("HorizontalAlignment", 3);//�������������
    }
    if (VertAlign) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("VerticalAlignment", 2);//�������������
    }
    //��������� ������
    if (Bold) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Bold", true); //������ �����
    }
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Size", Font->Size); //������ �����
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 1).OlePropertySet("LineStyle", BoxStyle);
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 2).OlePropertySet("LineStyle", BoxStyle);
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 3).OlePropertySet("LineStyle", BoxStyle);
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 4).OlePropertySet("LineStyle", BoxStyle);
}
//---------------------------------------------------------------------------
void CExcel::DrawBox(AnsiString Cell, int BoxStyle, int iBackgroundColor, bool Left, bool Top, bool Right, bool Bottom) {
    if (Left) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 1).OlePropertySet("LineStyle", BoxStyle);
    }
    if (Top) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 3).OlePropertySet("LineStyle", BoxStyle);
    }
    if (Right) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 2).OlePropertySet("LineStyle", BoxStyle);
    }
    if (Bottom) {
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 4).OlePropertySet("LineStyle", BoxStyle);
    }

    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Interior").OlePropertySet("ColorIndex", iBackgroundColor);
}
//---------------------------------------------------------------------------
void CExcel::OutTextBoxA(AnsiString Cell, AnsiString Text, bool HorizAlign, bool VertAlign, TFont *Font, bool Bold, int BoxStyle, bool Left, bool Top, bool Right, bool Bottom) {
    vExcel.OlePropertyGet("Range", Cell.c_str()).OleProcedure("Merge"); //����������� �����
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("NumberFormat", "@");
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("Value", Text.c_str());
    if (HorizAlign)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("HorizontalAlignment", 3);//�������������
    if (VertAlign)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertySet("VerticalAlignment", 2);//�������������
    //��������� ������
    if (Bold)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Bold", true); //������ �����
    vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Font").OlePropertySet("Size", Font->Size); //������ �����

    if (Left)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 1).OlePropertySet("LineStyle", BoxStyle);
    if (Top)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 3).OlePropertySet("LineStyle", BoxStyle);
    if (Right)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 2).OlePropertySet("LineStyle", BoxStyle);
    if (Bottom)
        vExcel.OlePropertyGet("Range", Cell.c_str()).OlePropertyGet("Borders", 4).OlePropertySet("LineStyle", BoxStyle);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vAddWorkbook(const AnsiString &asPageName) {
    vExcel.OlePropertyGet("Workbooks").OleProcedure("Add");

    //������ ������ ����� ���������� Excel
    vExcel.OlePropertyGet("Sheets").OlePropertyGet("Item", 3).OleProcedure("Select");
    vExcel.OlePropertyGet("ActiveWindow").OlePropertyGet("SelectedSheets").OleProcedure("Delete");

    vExcel.OlePropertyGet("Sheets").OlePropertyGet("Item", 2).OleProcedure("Select");
    vExcel.OlePropertyGet("ActiveWindow").OlePropertyGet("SelectedSheets").OleProcedure("Delete");

    //������ �������� "��������"
    vExcel.OlePropertyGet("Sheets").OlePropertyGet("Item", 1).OlePropertySet("Name", asPageName.c_str());
    vExcel.OlePropertyGet("Sheets", asPageName.c_str()).OleProcedure("Select");
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vOpenDocument(const AnsiString &asFileName) {
    asTemplatePath = asFileName + "t";
    vExcel.OlePropertyGet("Workbooks").OleProcedure("Open", asFileName.c_str());
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vSaveAsDocument(const AnsiString &asFileName) {
    vExcel.OlePropertyGet("Workbooks").OlePropertyGet("Item", 1).OleProcedure("SaveAs", asFileName.c_str());
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vSelPage(const AnsiString &asPage) {
    vExcel.OlePropertyGet("Sheets", asPage.c_str()).OleProcedure("Select");
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vPrintPage(const AnsiString &asPage) {
    vExcel.OlePropertyGet("Sheets", asPage.c_str()).OleProcedure("PrintOut");
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vVisibleDocument(bool bVisible) {
    vExcel.OlePropertySet("Visible", bVisible);
}
//---------------------------------------------------------------------------
AnsiString CExcel::GetCell(int i,int j) {
    return vExcel.OlePropertyGet("Cells", i, j).OlePropertyGet("Value");
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vAutoFitColumn(const AnsiString &asColumnRange) {
    Variant vWorkbook  = vExcel.OlePropertyGet("ActiveWorkbook");
    Variant vWorksheet = vWorkbook.OlePropertyGet("ActiveSheet");
    Variant vRange     = vWorksheet.OlePropertyGet("Range", asColumnRange.c_str());
    Variant vColumns   = vRange.OlePropertyGet("EntireColumn");
    vColumns.OleProcedure("AutoFit");
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vFullScreen(bool bFlag) {
    vExcel.OlePropertySet("DisplayFullScreen", bFlag);   //1 - ������
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vWindowState(signed int iState) {
    vExcel.OlePropertySet("WindowState", iState);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vWindowDimensions(int iWidth, int iHeight, int iLeft, int iTop) {
    vExcel.OlePropertySet("DisplayFullScreen", false);
    vExcel.OlePropertySet("Width",  iWidth);
    vExcel.OlePropertySet("Height", iHeight);
    vExcel.OlePropertySet("Left",   iLeft);
    vExcel.OlePropertySet("Top",    iTop);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vDocumentZoom(int iPercent) {
    vExcel.OlePropertyGet("ActiveWindow").OlePropertySet("Zoom", iPercent);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vDisplayHeadings(bool bVisible) {
    vExcel.OlePropertyGet("ActiveWindow").OlePropertySet("DisplayHeadings", bVisible);
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vPrintPreview() {
    Variant vWorkbook  = vExcel.OlePropertyGet("ActiveWorkbook");
    Variant vWorksheet = vWorkbook.OlePropertyGet("ActiveSheet");
    vWorksheet.OleProcedure("PrintPreview");
    ///vExcel.OlePropertyGet("ActiveWindow").OlePropertySet("DisplayHeadings", bVisible);

//    vWorksheet.OleProcedure("Activate");   //WordApplication1->Activate();
//    vExcel.OlePropertySet("Top",     -1);
//    vExcel.OlePropertySet("Left",    -1);
//    vExcel.OlePropertySet("Height",  Screen->Height);
//    vExcel.OlePropertySet("Width",   Screen->Width);
//    vExcel.OlePropertySet("PrintPreview", 100);
//
    

//    Function PrintPreview (sheet:variant):boolean;
//    PrintPreview:=true;
//    try
//                    E.ActiveWorkbook.Sheets.Item[sheet].PrintPreview;
//    except
//    PrintPreview:=false;
//    End;
}
//---------------------------------------------------------------------------
void __fastcall CExcel::vSmallScroll() {
    //ActiveWindow.SmallScroll Down = 10
//    vExcel.OlePropertyGet("ActiveWindow").OlePropertySet("DisplayHeadings", bVisible);
    ////vExcel.OlePropertyGet("ActiveWindow").OlePropertyGet("SmallScroll").OlePropertySet("Down", 10);
}

/*
    //������ ������ ����� ���������� Excel
    vExcel.OlePropertyGet("Sheets").OlePropertyGet("Item", 3).OleProcedure("Select");
    vExcel.OlePropertyGet("ActiveWindow").OlePropertyGet("SelectedSheets").OleProcedure("Delete");

*/
