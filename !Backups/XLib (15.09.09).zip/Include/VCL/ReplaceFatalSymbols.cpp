/**********************************************************************
* �������� ��������� �������
*
***********************************************************************/


AnsiString __fastcall TfrmMain::ReplaceFatalSymbols(AnsiString asFatalStr) { // TODO: ReplaceFatalSymbols()
    char FatalChars[] = {'\\', '/', ':', '*', '<', '>', '|', '?', '"', '\t', '\n', '\r'};
    TReplaceFlags flags;
    flags << rfReplaceAll << rfIgnoreCase;

    for (int i = 0; i < sizeof(FatalChars) / sizeof(FatalChars[0]); i ++) {
        asFatalStr = StringReplace(asFatalStr, FatalChars[i], "", flags);
	}
    return asFatalStr;
}