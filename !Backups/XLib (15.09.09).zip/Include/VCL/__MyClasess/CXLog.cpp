/**********************************************************************
*	�����  CXLog (CXLog.cpp) (C++Builder 6.0)  
*	
***********************************************************************/


#pragma warning(disable: 4996)	//strcpy, ::wsprintf, vsnprintf

#include "CXLog.h"

#include <stdio.h>
//--#include <stdlib.h>
#include <sysutils.hpp>

#define LOCK_FILE    EnterCriticalSection(&m_csLog); __try {
#define UNLOCK_FILE  } __finally {  LeaveCriticalSection(&m_csLog);  }
//---------------------------------------------------------------------------
CXLog::CXLog(const AnsiString &casFileName, unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csLog);

	m_asLogName     = casFileName;
	m_asLogPath     = ExtractFilePath(asExePath()) + "\\" + m_asLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::CXLog(unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csLog);

	m_asLogName     = ChangeFileExt(ExtractFileName(asExePath()), ".log");
	m_asLogPath     = ExtractFilePath(asExePath()) + "\\" + m_asLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	
	/*UNLOCK*/DeleteCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vLog
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vLog(const AnsiString &csStr) {     
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csStr.c_str());
        }
    } __finally {
        fflush(pFile);	fclose(pFile);	pFile = NULL;
    } 	
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vLog(const AnsiString &csComment, const AnsiString &csStr) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  %s --> %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csStr.c_str());
        }
    } __finally {
        fflush(pFile);  fclose(pFile);	pFile = NULL;
    }
	
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vLog(const AnsiString &csComment, int iValue) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  %s --> %i\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), iValue);	
        }
    } __finally {
        fflush(pFile); fclose(pFile);	pFile = NULL;
    }
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vLog(const AnsiString &csComment, unsigned long int ulValue) {
	vDeleteLogIfFull();
	
	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  %s --> %ul\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), ulValue);	//ul?????
        }
    } __finally {
        fflush(pFile);  fclose(pFile);	pFile = NULL;
    } 
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrorStr(const AnsiString &csComment, unsigned long int ulLastError) {
	vDeleteLogIfFull();

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
    FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), (LPCTSTR)lpMsgBuf);	
        }
    } __finally {
        fflush(pFile);  fclose(pFile);  pFile = NULL;
    }                  
	/*UNLOCK*/UNLOCK_FILE

	::LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrStrServ() {
	vDeleteLogIfFull();

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
    /*LOCK*/LOCK_FILE
    FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            SYSTEMTIME stST;   ::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, "fail");
        } else {
            SYSTEMTIME stST;   ::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, (LPCTSTR)lpMsgBuf);
        }
    } __finally {
        fflush(pFile); fclose(pFile);  pFile = NULL;
    }
    /*UNLOCK*/UNLOCK_FILE

	::LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CXLog::vLogUCharAsHex(const AnsiString &csComment, unsigned char *pucBuff, unsigned long int ulBuffSize) {
	vDeleteLogIfFull();

	AnsiString sRes = "";   
	for (unsigned int i = 0; i < ulBuffSize; i ++) {
		if (pucBuff[i] < 16) {  
			char szTemp[6]; ::ZeroMemory(&szTemp, sizeof(szTemp));
			::wsprintf(szTemp, "0x0%x ", pucBuff[i]);
			sRes += szTemp;
		} else {
			char szTemp[6]; ::ZeroMemory(&szTemp, sizeof(szTemp));
			::wsprintf(szTemp, "0x%2x ", pucBuff[i]);
			sRes += szTemp;
	    }
	}

	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;    ::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());
        }
    } __finally {
        fflush(pFile);  fclose(pFile);	pFile = NULL;
    }
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vLogUCharAsStr(const AnsiString &csComment, unsigned char *pucBuff, unsigned long int ulBuffSize) {
    XASSERT(NULL != pucBuff);

	vDeleteLogIfFull();

	AnsiString sRes = "";   
	for (unsigned int i = 0; i < ulBuffSize; i ++) {
        //sRes += AnsiString(0).wsprintf("%c", pcFileText[i]);
        sRes += (char)pucBuff[i];      //???????????
	}

	//-------------------------------------
	//����� ���
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "a");
    __try {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
            ::GetLocalTime(&stST);
            fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());
        }
    } __finally {
        fflush(pFile);  fclose(pFile);	pFile = NULL;
    }                  
	/*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vTrace
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vTrace(const AnsiString &casStr) {
	::OutputDebugString((casStr + "\r\n").c_str());	//VERIFY
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const AnsiString &casComment, const AnsiString &casStr) {
	::OutputDebugString((casComment + "--->" + casStr + "\r\n").c_str());
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const AnsiString &casComment, int iValue) {
	::OutputDebugString((casComment + "--->" + IntToStr(iValue) + "\r\n").c_str());
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const AnsiString &casComment, unsigned long int ulValue) {
	::OutputDebugString((casComment + "--->" + IntToStr(ulValue) + "\r\n").c_str());
}
//---------------------------------------------------------------------------
void CXLog::vTraceLastError(const AnsiString &casComment, unsigned long int ulLastError) {
	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);

	::OutputDebugString((casComment + "--->" + AnsiString((const char *)lpMsgBuf) + "\r\n").c_str());
}
//---------------------------------------------------------------------------


/****************************************************************************
*	
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vDelete() {
    /*LOCK*/LOCK_FILE
	if (false == ::SetFileAttributes(m_asLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
		vLogLastErrStrServ();
	}

    if (false == ::DeleteFile(m_asLogPath.c_str())) {
        vLogLastErrStrServ();
    }
    /*UNLOCK*/UNLOCK_FILE
}
//---------------------------------------------------------------------------
void CXLog::vSetPath(const AnsiString &csFilePath) {
	m_asLogPath = m_asLogPath;
}
//---------------------------------------------------------------------------
void CXLog::vSetName(const AnsiString &casFileName) {
	m_asLogName = casFileName;
	m_asLogPath = ExtractFilePath(asExePath()) + "\\" + casFileName;
}
//---------------------------------------------------------------------------
void CXLog::vOpen() {
	STARTUPINFO si;				::ZeroMemory(&si, sizeof(STARTUPINFO));
	PROCESS_INFORMATION pi;     ::ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
	si.cb = sizeof(STARTUPINFO);   //��������� �������� ��������� STARTUPINFO �� ���������

    __try {
        AnsiString sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.3\\notepad++.exe " + m_asLogPath;
        if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            return;
        }	

        Sleep(500);  //������� �������� � �������� ���� ������
    } __finally {
        //������� ����������� ����������� �������� � ������� ��������
        ::CloseHandle(pi.hThread);
        ::CloseHandle(pi.hProcess);
    }   
}
//---------------------------------------------------------------------------
void CXLog::vClear() {
	/*LOCK*/LOCK_FILE
	FILE *pFile = fopen(m_asLogPath.c_str(), "w");
    __try  {
        if (NULL == pFile) {
            vLogLastErrStrServ();
        } else {
            fprintf(pFile, "");
        }
    } __finally {
        fflush(pFile); fclose(pFile); pFile = NULL;
    }
    /*UNLOCK*/UNLOCK_FILE 	
}
//---------------------------------------------------------------------------
void CXLog::vSetMaxFileSizeMb(unsigned long int ulMaxFileSize) {
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
void CXLog::vDeleteLogIfFull() {
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ulFileSize(m_asLogPath) / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Other
*
*****************************************************************************/

//---------------------------------------------------------------------------
//void CXLog::vErrorMessageBox() {
//	LPVOID lpMsgBuf = NULL;
//	::FormatMessage( 
//		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
//		FORMAT_MESSAGE_FROM_SYSTEM | 
//		FORMAT_MESSAGE_IGNORE_INSERTS,
//		NULL,
//		GetLastError(),
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
//		(LPTSTR) &lpMsgBuf,
//		0,
//		NULL
//	);
//	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
//	::LocalFree(lpMsgBuf);
//}
//---------------------------------------------------------------------------
//AnsiString CXLog::sErrorMessageStr() {
//	LPVOID lpMsgBuf = NULL;
//	::FormatMessage( 
//		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
//		FORMAT_MESSAGE_FROM_SYSTEM | 
//		FORMAT_MESSAGE_IGNORE_INSERTS,
//		NULL,
//		GetLastError(),
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
//		(LPTSTR) &lpMsgBuf,
//		0,
//		NULL
//	);
//	////::LocalFree(lpMsgBuf);
//
//	return AnsiString((LPCTSTR)lpMsgBuf);
//}
//---------------------------------------------------------------------------
void CXLog::vMsgBoxLastError(const AnsiString &csComment) {
	AnsiString asRes    = "";
	LPVOID     lpMsgBuf = NULL;

	::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR)&lpMsgBuf,
		0,
		NULL);

	asRes = csComment + " ---> " + AnsiString((LPTSTR)lpMsgBuf);
	
	if (lpMsgBuf) {
		::LocalFree(lpMsgBuf);
		lpMsgBuf = NULL;
	}

	::MessageBox(0, asRes.c_str(), "Last error", MB_OK);
}
//---------------------------------------------------------------------------
AnsiString CXLog::asExePath() {
	char szExePath[MAX_PATH];	::ZeroMemory(szExePath, sizeof(szExePath));
	::GetModuleFileName(GetModuleHandle(NULL), szExePath, MAX_PATH);		

	return AnsiString(szExePath);	
}
//---------------------------------------------------------------------------
unsigned long int CXLog::ulFileSize(const AnsiString &csFilePath) {
	unsigned long int ulRes = 0;

    /*LOCK*/LOCK_FILE
	FILE *pFile = fopen(csFilePath.c_str(), "rb");
    __try {
        if (0 != fseek(pFile, 0, SEEK_END)) {
            ulRes = 0;
        } else {
            ulRes = ftell(pFile);
            rewind(pFile);
        }
    } __finally {
        fflush(pFile);  fclose(pFile);	pFile = NULL;
    }
    /*UNLOCK*/UNLOCK_FILE 	

	return ulRes;
}
//---------------------------------------------------------------------------
