/**********************************************************************
*	�����  CAccess (CAccess.h)
*
***********************************************************************/


#ifndef CAccessH
#define CAccessH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <Classes.hpp>
#include <SysUtils.hpp> //
#include <system.hpp>   //AnsiString
#include <SysUtils.hpp> //GetCurrentDir, Now()
#include <windows.h>	//vErrorMessageBox
#include <ComObj.hpp>   //OLE
#include <ADODB.hpp>
#include <DB.hpp>


#define MSG_WARNING(MSG)      MessageBox(0, AnsiString(MSG).c_str(), "��������",   MB_OK + MB_ICONSTOP        + MB_TOPMOST)
#define MSG_INFO(MSG)         MessageBox(0, AnsiString(MSG).c_str(), "����������", MB_OK + MB_ICONINFORMATION + MB_TOPMOST)
//---------------------------------------------------------------------------
class CAccess {
	public:
		CAccess();
		~CAccess();

        bool       bIsMDBFile             (const AnsiString &asFilePath);
        bool       bIsApplicationInstalled(const WideString& cwsApplicationString);
        bool       bCreateResMDB          (const AnsiString &asFilePath);
        bool       bCreateAdoMDB          (const WideString& cwsMdbFilePath);
        bool       bCompactMDB            (const AnsiString& casMdbFilePath, const AnsiString& casPass1, const AnsiString& casPass2);
        bool       bCompactMDBEx          (TADOConnection *pADOConnection, TADOQuery *pADOQuery, const AnsiString& casMdbFilePath, const AnsiString& casPass1, const AnsiString& casPass2);
        bool       bCreateBackupMDB       (const AnsiString& casMdbFilePath);
        AnsiString fADOVersion            ();
	
	private:

};
//---------------------------------------------------------------------------
#endif