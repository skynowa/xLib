/**********************************************************************
*	curSummDBColumn.cpp -
*
***********************************************************************/


//---------------------------------------------------------------------------
Currency __fastcall TdmHomeBuh::curSummDBColumn(TADOConnection *pADOConnection, const UnicodeString &cusTableName, const UnicodeString &cusFieldName) {
	Currency curRes = 0;

	TADOQuery *qryTmp =  new TADOQuery(NULL);

    try {
		qryTmp->Connection = pADOConnection;
		qryTmp->Close();
		qryTmp->SQL->Text = L"SELECT " + cusFieldName + L" FROM " + cusTableName + L";";      //ShowMessage(qryTmp->SQL->Text);
		qryTmp->Open();
		qryTmp->First();
		while (! qryTmp->Eof) {
			if (false == qryTmp->FieldByName(cusFieldName)->IsNull) {
				curRes += qryTmp->FieldByName(cusFieldName)->AsCurrency;
            }
            qryTmp->Next();
        }
		qryTmp->Close();
	} catch (Exception &exception) {
		curRes = 0;
		Application->ShowException(&exception); //��������� �������, � ��.
	}

	delete qryTmp; qryTmp = NULL;

	return curRes;
}
//---------------------------------------------------------------------------
