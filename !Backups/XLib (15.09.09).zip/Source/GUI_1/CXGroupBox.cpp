/****************************************************************************
* Class name:  CXGroupBox
* Description: 
* File name:   CXGroupBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:10:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXGroupBox.h>
//---------------------------------------------------------------------------
CXGroupBox::CXGroupBox() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ���� 
	_m_sClassName     = CXGROUPBOX_CONTROL_CLASS;           
	_m_ulStyle        = CXGROUPBOX_DEFAULT_WINDOW_STYLE;     
	_m_ulExStyle      = CXGROUPBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXGROUPBOX_DEFAULT_WIDTH;     
	_m_iHeight        = CXGROUPBOX_DEFAULT_HEIGHT;      
}
//---------------------------------------------------------------------------
CXGroupBox::~CXGroupBox() {
	LOG();
}
//---------------------------------------------------------------------------