/****************************************************************************
* Class name:  CXComboBox
* Description: ������ � ���������� �������
* File name:   CXComboBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 17:01:13
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXComboBox.h>

#include <fstream>
//---------------------------------------------------------------------------
CXComboBox::CXComboBox() {
	LOG();
	
	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXCOMBOBOX_CONTROL_CLASS;
	_m_ulStyle        = CXCOMBOBOX_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXCOMBOBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXCOMBOBOX_DEFAULT_WIDTH;
	_m_iHeight        = CXCOMBOBOX_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXComboBox::~CXComboBox() {
	LOG();
}
//---------------------------------------------------------------------------
BOOL CXComboBox::bAddString(const std::string &csItem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	BOOL bRes = FALSE;

	bRes = (BOOL)lSendMessage(CB_ADDSTRING, 0, (LPARAM)csItem.c_str());
	/*DEBUG*///??? XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXComboBox::bResetContent() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	BOOL bRes = FALSE;

	bRes = (BOOL)lSendMessage(CB_RESETCONTENT, 0, 0);
	/*DEBUG*///??? XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXComboBox::bSetCurSel(WPARAM wIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	BOOL bRes = FALSE;

	bRes = (BOOL)lSendMessage(CB_SETCURSEL, wIndex, 0);
	/*DEBUG*///??? XASSERT_RET(FALSE != bRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXComboBox::bLoadFromFile(const std::string &csFilePath, int iItemIndex) {    //overflow!!!
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/////XASSERT_RET(TRUE == bFileExists(csFilePath), FALSE);

	BOOL bRes = FALSE;

	try {
		bResetContent();

		//��������� ���� ���������
		std::ifstream ifsStream(csFilePath.c_str(), std::ios::in);
		const ULONG   culLineSize             = MAX_PATH;
		CHAR          szLine[culLineSize + 1] = {0};	
		
		while ((!ifsStream.eof()) && (!ifsStream.fail())) {
			ifsStream.getline(szLine, culLineSize);					//overflow!!!
			if (0 != ::lstrlen(szLine)) {
				szLine[::lstrlen(szLine)] = '\0';		//������� "\r\n"	
			}			

			bAddString(szLine);
		}
		ifsStream.close();

		bSetCurSel(iItemIndex);

		bRes = TRUE;
	} catch (...) {
		bRes = FALSE;
	}

	return bRes;
}
//---------------------------------------------------------------------------