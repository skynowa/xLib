/****************************************************************************
* Class name:  CXListBox
* Description: 
* File name:   CXListBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 22:59:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXListBox.h>
//---------------------------------------------------------------------------
//TODO: + CXListBox 
CXListBox::CXListBox() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXLISTBOX_CONTROL_CLASS;
	_m_ulStyle        = CXLISTBOX_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXLISTBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXLISTBOX_DEFAULT_WIDTH;
	_m_iHeight        = CXLISTBOX_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
//TODO: + ~CXListBox
CXListBox::~CXListBox() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bAddString 
BOOL CXListBox::bAddString(const std::string &csItem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_ADDSTRING, NULL, (LPARAM)csItem.c_str());
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bResetContent 
BOOL CXListBox::bResetContent() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_RESETCONTENT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAddFile
BOOL CXListBox::bAddFile(const std::string &csFileName) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_ADDFILE, NULL, (LPARAM)csFileName.c_str());
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bDeleteString
BOOL CXListBox::bDeleteString(INT iStartIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_DELETESTRING, (WPARAM)iStartIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bDeleteString
BOOL CXListBox::bDir(UINT uiDir) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	////lSendMessage(LB_DIR, (WPARAM)uiDir, NULL);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bFindString
BOOL CXListBox::bFindString(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_FINDSTRING, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bFindStringExact
BOOL CXListBox::bFindStringExact(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_FINDSTRINGEXACT, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetAnchorIndex
BOOL CXListBox::bGetAnchorIndex() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETANCHORINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCaretIndex
BOOL CXListBox::bGetCaretIndex() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETCARETINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCount
BOOL CXListBox::bGetCount() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETCOUNT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCurSel
BOOL CXListBox::bGetCurSel() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETCURSEL, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetHorizontalExtent
BOOL CXListBox::bGetHorizontalExtent() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETHORIZONTALEXTENT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemData
BOOL CXListBox::bGetItemData(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETITEMDATA, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemHeight
BOOL CXListBox::bGetItemHeight(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETITEMHEIGHT, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemRect
BOOL CXListBox::bGetItemRect(WPARAM wItemIndex, LPARAM lRect) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETITEMRECT, wItemIndex, lRect);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetListBoxInfo
BOOL CXListBox::bGetListBoxInfo() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETLISTBOXINFO, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetLocale
BOOL CXListBox::bGetLocale() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETLOCALE, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSel
BOOL CXListBox::bGetSel(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETSEL, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSelCount
BOOL CXListBox::bGetSelCount() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETSELCOUNT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSelItems
BOOL CXListBox::bGetSelItems(LPARAM lItems) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETSELITEMS, NULL, lItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetText
BOOL CXListBox::bGetText(WPARAM wItemIndex, LPARAM lItems) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETTEXT, wItemIndex, lItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetTextLen
BOOL CXListBox::bGetTextLen(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETTEXTLEN, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetTopIndex
BOOL CXListBox::bGetTopIndex() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_GETTOPINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bInitStorage
BOOL CXListBox::bInitStorage(WPARAM wItemsCount, LPARAM lMem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_INITSTORAGE, wItemsCount, lMem);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bInsertString
BOOL CXListBox::bInsertString(WPARAM wItemIndex, LPARAM lString) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_INSERTSTRING, wItemIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bItemFromPoint
BOOL CXListBox::bItemFromPoint(LPARAM lPoint) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_ITEMFROMPOINT, NULL, lPoint);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelectString
BOOL CXListBox::bSelectString(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SELECTSTRING, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelItemRange
BOOL CXListBox::bSelItemRange(WPARAM wOption, LPARAM lFirstLastItems) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SELITEMRANGE, wOption, lFirstLastItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelItemRangeEx
BOOL CXListBox::bSelItemRangeEx(WPARAM wFirstItem, LPARAM lLastItem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SELITEMRANGEEX, wFirstItem, lLastItem);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetAnchorIndex
BOOL CXListBox::bSetAnchorIndex(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETANCHORINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCaretIndex
BOOL CXListBox::bSetCaretIndex(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETCARETINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetColumnWidth
BOOL CXListBox::bSetColumnWidth(WPARAM wWidth) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETCOLUMNWIDTH, wWidth, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCount
BOOL CXListBox::bSetCount(WPARAM wCount) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETCOUNT, wCount, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCurSel
BOOL CXListBox::bSetCurSel(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETCURSEL, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetHorizontalExtent
BOOL CXListBox::bSetHorizontalExtent(WPARAM wScrollWidth) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETHORIZONTALEXTENT, wScrollWidth, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetItemData
BOOL CXListBox::bSetItemData(WPARAM wItemIndex, LPARAM lValue) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETITEMDATA, wItemIndex, lValue);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetItemHeight
BOOL CXListBox::bSetItemHeight(WPARAM wItemIndex, LPARAM lHeight) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETITEMHEIGHT, wItemIndex, lHeight);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetLocale
BOOL CXListBox::bSetLocale(WPARAM wLocaleIdentifier) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETLOCALE, wLocaleIdentifier, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetSel
BOOL CXListBox::bSetSel(WPARAM wSelOption, LPARAM lItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETSEL, wSelOption, lItemIndex);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetTabStops
BOOL CXListBox::bSetTabStops(WPARAM wTabStopsNum, LPARAM lTabStopsArr) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETTABSTOPS, wTabStopsNum, lTabStopsArr);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetTopIndex
BOOL CXListBox::bSetTopIndex(WPARAM wItemIndex) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(LB_SETTOPINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bVScroll
BOOL CXListBox::bVScroll(WPARAM wPos) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

    return lSendMessage(WM_VSCROLL, MAKEWORD(wPos, 0), 0);
    
    return TRUE;
}
//---------------------------------------------------------------------------