/****************************************************************************
* Class name:  CXSleeper
* Description: ������ ::Sleep()
* File name:   CXSleeper.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.07.2009 12:54:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXSleeper.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXSleeper::CXSleeper() {
	_m_objEvent.bCreate(NULL, FALSE, FALSE, NULL);
}
//---------------------------------------------------------------------------
CXSleeper::~CXSleeper() {

}
//---------------------------------------------------------------------------
BOOL CXSleeper::bSleep(ULONG ulMilliseconds) {
	ULONG ulRes = WAIT_FAILED;

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
	ulRes = _m_objEvent.ulWaitForSingleObject(ulMilliseconds);	//MsgBox(ulRes, "ulWaitForSingleObject");
	/*DEBUG*/XASSERT_RET(WAIT_TIMEOUT == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------