/****************************************************************************
* Class name:  CXMutex
* Description: ������ � ����������
* File name:   CXMutex.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:48:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXMutex.h>

#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXMutex::CXMutex() 
	: _m_hMutex(NULL)
{

}
//---------------------------------------------------------------------------
CXMutex::~CXMutex() {
	/*DEBUG*/XASSERT(NULL != _m_hMutex);

	if (NULL != _m_hMutex) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(_m_hMutex);    _m_hMutex = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXMutex::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, NULL);

	return _m_hMutex;
}
//---------------------------------------------------------------------------
BOOL CXMutex::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialOwner, LPCSTR pcszName) {
	_m_hMutex = ::CreateMutex(lpsaAttributes, bInitialOwner, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXMutex::bOpen(ULONG dwAccess, BOOL bInheritHandle, LPCSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	_m_hMutex = ::OpenMutex(dwAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXMutex::bRelease() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	BOOL bRes = FALSE;

	bRes = ::ReleaseMutex(_m_hMutex);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXMutex::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
	return ::WaitForSingleObject(_m_hMutex, ulTimeout);
}
//---------------------------------------------------------------------------