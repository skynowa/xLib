/****************************************************************************
* Class name:  CXDialog
* Description: ������ � ������
* File name:   CXDialog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXDialog.h>

#include <XLib/GUI/Common.h>
#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXDialog::CXDialog() :
	_m_siTemplID  (0),
	_m_siIconID   (0)
{
	_m_hParentWnd = NULL;

	_m_bIsDialog = TRUE;
}
//---------------------------------------------------------------------------
CXDialog::CXDialog(SHORT TemplID, SHORT siIconID, HWND hParentWnd) : 
	_m_siTemplID(TemplID),
	_m_siIconID (siIconID)	
{
	_m_hParentWnd = hParentWnd;

	_m_bIsDialog = TRUE;
}
//---------------------------------------------------------------------------
CXDialog::~CXDialog() {

}
//---------------------------------------------------------------------------
//TODO: ����� ���������
X_BEGIN_MSG_MAP(CXDialog)
	X_MSG(WM_INITDIALOG, OnInitial);
	X_MSG(WM_PAINT,      OnPaint);
	X_MSG(WM_COMMAND,    OnCommand);
	X_MSG(WM_NOTIFY,     OnNotify);
	X_MSG(WM_SIZE,       OnSize);
	X_MSG(WM_CLOSE,      OnClose);    
	X_MSG(WM_DESTROY,    OnDestroy);  
X_END_MSG_MAP_NOPARENT
//---------------------------------------------------------------------------
INT CXDialog::CreateModal() {
	INT iRes = - 1;

	iRes = (INT)::DialogBoxParam(CXApplication::hGetInstance(), (LPCTSTR)_m_siTemplID, _m_hParentWnd, (DLGPROC)_s_pWndProc, LPARAM(this));
	/*DEBUG*/XASSERT_RET(- 1 != iRes, iRes);
	/*DEBUG*/XASSERT_RET(0   != iRes, iRes);

	return iRes;
}
//---------------------------------------------------------------------------
BOOL CXDialog::bCreate(SHORT TemplID, SHORT IconID, HWND hParent) {
	_m_siTemplID  = TemplID;
	_m_siIconID   = IconID;
	_m_hParentWnd = hParent;

	_m_hWnd = ::CreateDialogParam(CXApplication::hGetInstance(), (LPCTSTR)_m_siTemplID, _m_hParentWnd, (DLGPROC)_s_pWndProc, LPARAM(this));
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	if (0 != _m_siIconID) {
		lSendMessage(WM_SETICON, WPARAM(ICON_SMALL), (LPARAM)::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)_m_siIconID));
	}

	return TRUE;
}
//---------------------------------------------------------------------------
INT CXDialog::OnInitial(WPARAM wParam, LPARAM lParam) {		/*virtual*/
	return FALSE;
}
//---------------------------------------------------------------------------
VOID CXDialog::OnPaint(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXDialog::OnCommand(WPARAM wParam, LPARAM lParam) {	/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXDialog::OnNotify(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXDialog::OnSize(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXDialog::OnClose(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXDialog::OnDestroy(WPARAM wParam, LPARAM lParam) {	/*virtual*/ 

}
//---------------------------------------------------------------------------