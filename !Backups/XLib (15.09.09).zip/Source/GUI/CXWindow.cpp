/****************************************************************************
* Class name:  CXWindow
* Description: ����� root ��� ���� �������� ���� 
* File name:   CXWindow.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     31.08.2009 16:44:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXWindow.h>

#include <XLib/GUI/CXApplication.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXWindow
CXWindow::CXWindow() :
	_m_hWnd      (NULL),
	_m_ulExStyle (0),
	_m_sClassName(""),
	_m_sText     (""),
	_m_ulStyle   (0),
	_m_iWidth    (0),
	_m_iHeight   (0),
	_m_iLeft     (CW_USEDEFAULT),
	_m_iTop      (CW_USEDEFAULT),
	_m_hParentWnd(NULL),		
	_m_iID       (0),
	_m_Font      (NULL),
	_m_bIsFrame  (FALSE),
	_m_bIsDialog (FALSE)
{
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + ~CXWindow
CXWindow::~CXWindow() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + lpProcessMessage
LRESULT CXWindow::lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	/*virtual*/
	return ::DefWindowProc(_m_hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------
//TODO: + bIsWindow
BOOL CXWindow::bIsWindow() const {
	/*DEBUG*///not need

	return (NULL != _m_hWnd) && (INVALID_HANDLE_VALUE != _m_hWnd) && (FALSE != ::IsWindow(_m_hWnd));
}
//---------------------------------------------------------------------------
//TODO: + bIsDialog
BOOL CXWindow::bIsDialog(HWND hWnd) {		/*static*/ 
	/*DEBUG*///not need

	UINT uiRes = 0;

	uiRes = ::GetClassWord(hWnd, GCW_ATOM);
	/*DEBUG*/XASSERT_RET(0 != uiRes, FALSE);

	CHECK_RET(32770 != uiRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: hGetHandle
HWND CXWindow::hGetHandle() { 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return _m_hWnd; 
}
//---------------------------------------------------------------------------
//TODO: iGetID
INT CXWindow::iGetID() {
	/*DEBUG*/XASSERT_RET(0 != _m_iID, 0);

	return _m_iID;
}
//---------------------------------------------------------------------------
//TODO: vSetID
VOID CXWindow::vSetID(INT iID) {
	/*DEBUG*/XASSERT_DO(0 != iID, return);
	
	_m_iID = iID;
}
//---------------------------------------------------------------------------
//TODO: + bShow
BOOL CXWindow::bShow(INT iCmdShow) {
	/*DEBUG*/////XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	INT iRes = - 1;
	/*iCmdShow
	SW_FORCEMINIMIZE
	SW_HIDE
	SW_MAXIMIZE
	SW_MINIMIZE
	SW_RESTORE
	SW_SHOW
	SW_SHOWDEFAULT
	SW_SHOWMAXIMIZED
	SW_SHOWMINIMIZED
	SW_SHOWMINNOACTIVE
	SW_SHOWNA
	SW_SHOWNOACTIVATE
	SW_SHOWNORMAL*/

	iRes = ::ShowWindow(_m_hWnd, iCmdShow);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUpdate
BOOL CXWindow::bUpdate() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::UpdateWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWindow::bMoveCenter() {
	LOG();

	RECT rect;
	INT horScrSize;
	INT verScrSize;
	INT x,y,w,h;

	::GetWindowRect(_m_hWnd,&rect);
	horScrSize = ::GetDeviceCaps(::GetDC(NULL),HORZRES);
	verScrSize = ::GetDeviceCaps(::GetDC(NULL),VERTRES);
	w = rect.right-rect.left;
	h = rect.bottom-rect.top;
	x = (horScrSize-w)/2;
	y = (verScrSize-h)/2;
	::MoveWindow(_m_hWnd,x,y,w,h,FALSE);

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - SendMessage
LRESULT CXWindow::lSendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LRESULT lpRes = FALSE;

	lpRes = ::SendMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/// ??? XASSERT_RET(FALSE == (BOOL)lpRes, FALSE); 

	return lpRes;
}
//---------------------------------------------------------------------------
//TODO: + PostMessage
BOOL CXWindow::bPostMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDestroy
BOOL CXWindow::bDestroy() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::DestroyWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;

	///::PostQuitMessage(0);
}
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL CXWindow::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return bPostMessage(WM_CLOSE, NULL, NULL);

	//CloseWindow	
}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_pWndProc
LRESULT CXWindow::_s_pWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	CXWindow *pWnd = NULL;

	switch (uiMsg) {
		case WM_INITDIALOG:
			{
				::SetWindowLong(hWnd, GWL_USERDATA, (LONG)lParam);
				pWnd = (CXWindow *)lParam;	//������� ��������� �� �����
				/*DEBUG*/XASSERT(NULL != pWnd);
				pWnd->_m_hWnd = hWnd;
			}
			break;

		case WM_NCCREATE:
			{
				LONG ulNewLong = 0;

				ulNewLong = (INT)((LPCREATESTRUCT)lParam)->lpCreateParams;
				::SetWindowLong(hWnd, GWL_USERDATA, ulNewLong);
				pWnd = (CXWindow *)(((LPCREATESTRUCT)lParam)->lpCreateParams);	//������� ��������� �� �����
				/*DEBUG*/XASSERT(NULL != pWnd);
				pWnd->_m_hWnd = hWnd;
			}
			break;

		default:
			{
				// ������� ��������� �� �����
				pWnd = (CXWindow *)::GetWindowLong(hWnd, GWL_USERDATA); 
				/*DEBUG*///XASSERT(NULL != pWnd);
			}
	}

	if (NULL != pWnd) {
		return pWnd->lpProcessMessage(uiMsg, wParam, lParam);
	}

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + _bInitCommonControls
BOOL CXWindow::_bInitCommonControls(ULONG ulFlags) {		/*static*/
	BOOL bRes = FALSE;

	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = ulFlags;

	bRes = ::InitCommonControlsEx(&iccx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bRegisterClass(const WNDCLASSEX *cpwcWndClassEx) {		/*static*/
	/*DEBUG*/XASSERT_RET(NULL != cpwcWndClassEx, FALSE);

	BOOL bRes = FALSE;

	bRes = ::RegisterClassEx(cpwcWndClassEx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bUnregisterClass(const std::string &csClassName) {		/*static*/
	/*DEBUG*///XASSERT_RET(false != csClassName.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::UnregisterClass(csClassName.c_str(), CXApplication::hGetInstance());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCreateEx
BOOL CXWindow::bCreateEx(INT iID, HWND hParent, const std::string &csClassName, const std::string &csText, 
						 INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulExStyle, LPVOID lpParam)
{
	/*DEBUG*/XASSERT_RET(NULL  == _m_hWnd,             NULL);
	/*DEBUG*/XASSERT_RET(false == csClassName.empty(), NULL);

	BOOL bRes = FALSE;

	_m_hWnd = ::CreateWindowEx(_m_ulExStyle | ulExStyle, 
							   csClassName.c_str(), 
							   csText.c_str(), 
		                       _m_ulStyle | ulStyle, 
							   iLeft, iTop, iWidth, iHeight, 
							   hParent, 
							   (HMENU)iID, 
							   CXApplication::hGetInstance(), 
							   lpParam);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	////bRes = bSetDefaultFont();
	////CHECK_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_ulExStyle  = _m_ulExStyle | ulExStyle;    
	_m_sClassName = _m_sClassName;
	_m_sText      = _m_sText;
	_m_ulStyle    = _m_ulStyle | ulStyle;
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;
	_m_hParentWnd =	hParent;	
	_m_iID        = iID;

	return TRUE;
}
//---------------------------------------------------------------------------