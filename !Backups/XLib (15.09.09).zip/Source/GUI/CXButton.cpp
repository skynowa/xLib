/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXButton.h>

#include <XLib/GUI/Common.h>
//---------------------------------------------------------------------------
CXButton::CXButton() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXBUTTON_CONTROL_CLASS;
	_m_ulStyle        = CXBUTTON_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = CXBUTTON_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXButton::~CXButton() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - bCreate
BOOL CXButton::bCreate(INT iID, HWND hParent, const std::string &csText, 
					   INT iLeft, INT iTop, INT iWidth, INT iHeight,
					   ULONG ulStyles, ULONG ulExStyles) 
{
	/*DEBUG*/

	BOOL bRes = FALSE;


	/*CXResources*/////Load(iID, iLeft, iTop, iWidth, iHeight);

	bRes = bCreateEx(iID, hParent, _m_sClassName, csText,		
					 iLeft, iTop, iWidth, iHeight,
					 _m_ulStyle | ulStyles,
					 _m_ulExStyle | ulExStyles, 											
					 this); 
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bCreate
BOOL CXButton::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/

	_m_hWnd = ::GetDlgItem(hParent, iID);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------