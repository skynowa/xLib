/****************************************************************************
* Class name:  CXWndLog
* Description: ����������� � ����
* File name:   CXWndLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXWndLog.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Sync/CXLockScope.h>

CXCriticalSection CXWndLog::ms_csListBox;
//---------------------------------------------------------------------------
//CXWndLog::CXWndLog() {
//	//code
//}
//---------------------------------------------------------------------------
CXWndLog::CXWndLog(HWND hWnd, EWindowClass wcWC) :
	_m_hWnd(hWnd),
	_m_eWC (wcWC)
{
	/*DEBUG*/XASSERT(NULL      != _m_hWnd);
	/*DEBUG*/XASSERT(wcListBox == _m_eWC);
}
//---------------------------------------------------------------------------
CXWndLog::~CXWndLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXWndLog::bWrite(LPCSTR pcszFormat, ...) { 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd,     FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%.2d:%.2d:%.2d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	switch(_m_eWC) {
		case wcListBox: 	
			{
				/*LOCK*/CXLockScope SL(ms_csListBox);
				
				//sRemoveEOL
				::SendMessage(_m_hWnd, LB_ADDSTRING, 0, (LPARAM)(sRemoveEOL(sTime + " " + sParam)).c_str());
				::SendMessage(_m_hWnd, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
			}
			break;

		default:	
			{
				/*DEBUG*/XASSERT_RET(FALSE, FALSE);
			}
			break;
	}
	
	return TRUE;
}
//---------------------------------------------------------------------------