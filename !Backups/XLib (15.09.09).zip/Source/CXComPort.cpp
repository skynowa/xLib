/**********************************************************************
*	����� CXComPort (CXComPort.cpp)
*
***********************************************************************/


#include <XLib/CXComPort.h>
//---------------------------------------------------------------------------
CXComPort::CXComPort(const std::string &sPortNum = "COM1") {	
	m_hComPort = INVALID_HANDLE_VALUE;
	m_sPortNum = sPortNum; 
}
//---------------------------------------------------------------------------
CXComPort::~CXComPort() {	
	bClose();
}
//--------------------------------------------------------------------------
//������� ����
BOOL CXComPort::bOpen() {
	m_hComPort = ::CreateFile(m_sPortNum.c_str(), GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);
    if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	} else {	
		return TRUE;	
	}
}
//--------------------------------------------------------------------------
//���������� ����
BOOL CXComPort::bConfig() {
	DCB dcb;
	dcb.fOutxCtsFlow = false;                  //Disable CTS monitoring
	dcb.fOutxDsrFlow = false;				   //Disable DSR monitoring
	dcb.fDtrControl  = DTR_CONTROL_DISABLE;    //Disable DTR monitoring
	dcb.fOutX        = false;                  //Disable XON/XOFF for transmission
	dcb.fInX         = false;                  //Disable XON/XOFF for receiving
	dcb.fRtsControl  = RTS_CONTROL_DISABLE;    //Disable RTS (Ready To Send)

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout         = 20; 
	timeouts.ReadTotalTimeoutMultiplier  = 10;
	timeouts.ReadTotalTimeoutConstant    = 100;
	timeouts.WriteTotalTimeoutMultiplier = 10;
	timeouts.WriteTotalTimeoutConstant   = 100;

	if (FALSE == ::SetCommTimeouts(m_hComPort, &timeouts))	{
		//
	}

	bClearData();

	::SetCommMask(m_hComPort, EV_DSR);
	
	ULONG lpEvtMask = 0;	
	::WaitCommEvent(m_hComPort, &lpEvtMask, NULL);
	//CTest->OnRead();

	return FALSE;
}
//--------------------------------------------------------------------------
//�������� ������ � �����
BOOL CXComPort::bClearData() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}
  
	::PurgeComm(m_hComPort, PURGE_RXCLEAR | PURGE_TXCLEAR); ///PurgeComm(m_hComPort, PURGE_TXCLEAR | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_RXABORT);
	
	ULONG ulErrors;
	::ClearCommError(m_hComPort, &ulErrors, 0);

	return true;
}
//--------------------------------------------------------------------------
//��������� ������ � �����
std::string CXComPort::bReadData(LPSTR pszBuff, ULONG dwNumOfBytesToRead) {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return "";
	}		

	::Sleep(5L);

	DWORD dwNumOfBytesRead = 0;
	BOOL  bRes             = ::ReadFile(m_hComPort, pszBuff, dwNumOfBytesToRead/*cuiSendStrLen*/, &dwNumOfBytesRead, NULL); 
	if (FALSE == bRes) {
		return "";
	}
	if (dwNumOfBytesRead != dwNumOfBytesToRead) {
		return "";
	}

	return std::string(pszBuff, dwNumOfBytesRead);
}
//--------------------------------------------------------------------------
//
INT CXComPort::iReadDataWaiting() {
	return 0;
}
//--------------------------------------------------------------------------
//�������� ������ � ����
BOOL CXComPort::bWriteData(const char *pcszBuff, DWORD dwNumOfBytesToWrite) {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	ULONG dwNumOfBytesWritten = 0;
	if (::WriteFile(m_hComPort, pcszBuff, dwNumOfBytesToWrite, &dwNumOfBytesWritten, NULL) == false) {
		return FALSE;
	}

	if (dwNumOfBytesWritten != dwNumOfBytesToWrite) {
		return FALSE;
	}

	if (FALSE == ::FlushFileBuffers(m_hComPort)) {
		return FALSE;
	}
	
	return TRUE;


	////OVERLAPPED osWrite   = {0};
	////DWORD      dwWritten = 0;
	////bool       bRes      = false;

	//////Issue write
	////if (!WriteFile(m_hComPort, lpBuf, dwToWrite, &dwWritten, NULL)) {
	////	if (GetLastError() != ERROR_IO_PENDING) {  //WriteFile failed, but it isn't delayed. Report error and abort.
	////		bRes = false;
	////	} else {
	////		//Write is pending
	////		if (GetOverlappedResult(m_hComPort, &osWrite, &dwWritten, TRUE) == false) {     
	////			bRes = false;
	////		} else {
	////			//Write operation completed successfully.
	////			bRes = true;
	////		}
	////	}
	////} else {
	////	//WriteFile completed immediately.
	////	bRes = true;
	////}
 //// 
	////return bRes;
}
//--------------------------------------------------------------------------
//������� ����
BOOL CXComPort::bClose() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

    bool bRes = FALSE; 

	if (FALSE == ::CloseHandle(m_hComPort)) {
		bRes = FALSE; 
	} else {
		bRes = TRUE; 
	}

	m_hComPort = INVALID_HANDLE_VALUE;

	return bRes;
}
//--------------------------------------------------------------------------
ULONG CXComPort::dwInputBuffTest() {
	ULONG    dwErrors;
	_COMSTAT csStat;
	
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}
	
	if (FALSE == ::ClearCommError(m_hComPort, &dwErrors, &csStat)) {
		return FALSE;
	}
	
	return csStat.cbInQue;
}
//-------------------------------------------------------------------------
//���������� ������ DTR
BOOL CXComPort::bClearCLRDTR() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	return ::EscapeCommFunction(m_hComPort, CLRDTR);
}
//-------------------------------------------------------------------------
//���������� ������ RTS
BOOL CXComPort::bClearCLRRTS() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	return ::EscapeCommFunction(m_hComPort, CLRRTS);
}
//-------------------------------------------------------------------------
//������������ ������ DTR
BOOL CXComPort::bSetSETDTR() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	return ::EscapeCommFunction(m_hComPort, SETDTR);
}
//-------------------------------------------------------------------------
//������������� ������ RTS
BOOL CXComPort::bSetSETRTS() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	return ::EscapeCommFunction(m_hComPort, SETRTS);
}
//-------------------------------------------------------------------------