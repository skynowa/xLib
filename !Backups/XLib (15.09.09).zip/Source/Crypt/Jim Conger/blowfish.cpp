// blowfish.cpp   C++ class implementation of the BLOWFISH encryption algorithm
// _THE BLOWFISH ENCRYPTION ALGORITHM_
// by Bruce Schneier
// Revised code--3/20/94
// Converted to C++ class 5/96, Jim Conger
// http://www.schneier.com/blowfish-download.html

#include <XLib/Crypt/Jim Conger/blowfish.h>
#include "blowfish.h2"	// holds the random digit tables

#define S(x,i)		 (SBoxes[i][x.w.byte##i])
#define bf_F(x)		 (((S(x,0) + S(x,1)) ^ S(x,2)) + S(x,3))
#define ROUND(a,b,n) (a.dword ^= bf_F(b) ^ PArray[n])


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
CXBlowFish::CXBlowFish() {
 	PArray = new ULONG[18];
 	SBoxes = new ULONG[4][256];
}
//---------------------------------------------------------------------------
CXBlowFish::~CXBlowFish() {
	delete PArray;
	delete [] SBoxes;
}
//---------------------------------------------------------------------------
//constructs the enctryption sieve
VOID CXBlowFish::vInitialize(UCHAR key[], int keybytes) {
	INT  		i, j = 0;
	ULONG  		data, datal, datar = 0;
	union aword temp = {0};

	// first fill arrays from data tables
	for (i = 0 ; i < 18 ; i++)
		PArray [i] = bf_P [i] ;

	for (i = 0 ; i < 4 ; i++)
	{
	 	for (j = 0 ; j < 256 ; j++)
	 		SBoxes [i][j] = bf_S [i][j] ;
	}


	j = 0 ;
	for (i = 0 ; i < NPASS + 2 ; ++i)
	{
		temp.dword = 0 ;
		temp.w.byte0 = key[j];
		temp.w.byte1 = key[(j+1) % keybytes] ;
		temp.w.byte2 = key[(j+2) % keybytes] ;
		temp.w.byte3 = key[(j+3) % keybytes] ;
		data = temp.dword ;
		PArray [i] ^= data ;
		j = (j + 4) % keybytes ;
	}

	datal = 0 ;
	datar = 0 ;

	for (i = 0 ; i < NPASS + 2 ; i += 2)
	{
		Blowfish_encipher (&datal, &datar) ;
		PArray [i] = datal ;
		PArray [i + 1] = datar ;
	}

	for (i = 0 ; i < 4 ; ++i)
	{
		for (j = 0 ; j < 256 ; j += 2)
		{
		  Blowfish_encipher (&datal, &datar) ;
		  SBoxes [i][j] = datal ;
		  SBoxes [i][j + 1] = datar ;
		}
	}
}
//---------------------------------------------------------------------------
//constructs the enctryption sieve
VOID CXBlowFish::vInitialize(const std::string &csKey) {
    vInitialize((UCHAR *)csKey.c_str(), csKey.size());
}
//---------------------------------------------------------------------------
//get output length, which must be even MOD 8
ULONG CXBlowFish::ulGetOutputLength(ULONG lInputLong) {
	ULONG lVal = 0;

	lVal = lInputLong % 8 ;	// find out if uneven number of bytes at the end
	if (0 != lVal) {
		return lInputLong + 8 - lVal;
	} else {
		return lInputLong;
	}
}
//---------------------------------------------------------------------------
//ulEncode pIntput into pOutput.  Input length in lSize.  Returned value
//is length of output which will be even MOD 8 bytes.  Input buffer and
//output buffer can be the same, but be sure buffer length is even MOD 8.
ULONG CXBlowFish::ulEncode(UCHAR * pInput, UCHAR * pOutput, ULONG lSize) {
    /*DEBUG*/XASSERT_RET(0 == (lSize % 8), FALSE);

	ULONG 	lCount, lOutSize, lGoodBytes = 0;
	UCHAR	*pi, *po = NULL;
	INT		i, j = 0;
	INT		SameDest = (pInput == pOutput ? 1 : 0) ;

	lOutSize = ulGetOutputLength (lSize) ;
	for (lCount = 0 ; lCount < lOutSize ; lCount += 8)
	{
		if (SameDest)	// if encoded data is being written into input buffer
		{
		 	if (lCount < lSize - 7)	// if not dealing with uneven bytes at end
		 	{
		 	 	Blowfish_encipher ((ULONG *) pInput, (ULONG *) (pInput + 4)) ;
		 	}
		 	else		// pad end of data with null bytes to complete encryption
		 	{
				po = pInput + lSize ;	// point at byte past the end of actual data
				j = (int) (lOutSize - lSize) ;	// number of bytes to set to null
				for (i = 0 ; i < j ; i++)
					*po++ = 0 ;
		 	 	Blowfish_encipher ((ULONG *) pInput, (ULONG *) (pInput + 4)) ;
		 	}
		 	pInput += 8 ;
		}
		else 			// output buffer not equal to input buffer, so must copy
		{               // input to output buffer prior to encrypting
		 	if (lCount < lSize - 7)	// if not dealing with uneven bytes at end
		 	{
		 		pi = pInput ;
		 		po = pOutput ;
		 		for (i = 0 ; i < 8 ; i++) {// copy bytes to output
		 			*po++ = *pi++ ;
                }
		 	 	Blowfish_encipher ((ULONG *) pOutput, (ULONG *) (pOutput + 4));	// now encrypt them
		 	 		
		 	}
		 	else		// pad end of data with null bytes to complete encryption
		 	{
		 		lGoodBytes = lSize - lCount ;	// number of remaining data bytes
		 		po = pOutput ;
		 		for (i = 0 ; i < (int) lGoodBytes ; i++)
		 			*po++ = *pInput++ ;
		 		for (j = i ; j < 8 ; j++)
		 			*po++ = 0 ;
		 	 	Blowfish_encipher ((ULONG *) pOutput, (ULONG *) (pOutput + 4)) ;
		 	}
		 	pInput += 8 ;
		 	pOutput += 8 ;
		}
	}
    /*DEBUG*/XASSERT_RET(0 == lOutSize % 8, FALSE);

	return lOutSize ;
 }
//---------------------------------------------------------------------------
//vDecode pIntput into pOutput.  Input length in lSize.  Input buffer and
//output buffer can be the same, but be sure buffer length is even MOD 8.
VOID CXBlowFish::vDecode(UCHAR * pInput, UCHAR * pOutput, ULONG lSize) {
    /*DEBUG*/XASSERT_DO(0 == (lSize % 8), return);

	ULONG 	lCount = 0;
	UCHAR	*pi, *po = NULL;
	INT		i = 0;
	INT		SameDest = (pInput == pOutput ? 1 : 0) ;

	for (lCount = 0 ; lCount < lSize ; lCount += 8) {
		if (SameDest) {	// if encoded data is being written into input buffer
	 	 	Blowfish_decipher ((ULONG *) pInput, (ULONG *) (pInput + 4)) ;
		 	pInput += 8 ;
		}
		else 			// output buffer not equal to input buffer
		{               // so copy input to output before decoding
	 		pi = pInput ;
	 		po = pOutput ;
	 		for (i = 0 ; i < 8 ; i++)
	 			*po++ = *pi++ ;
	 	 	Blowfish_decipher ((ULONG *) pOutput, (ULONG *) (pOutput + 4)) ;
		 	pInput += 8 ;
		 	pOutput += 8 ;
		}
	}
}
//---------------------------------------------------------------------------
BOOL CXBlowFish::bEncode(const std::string &csIn, std::string *psOut) {
	/*DEBUG*/XASSERT_RET(NULL  != psOut, FALSE);
	
	CHECK_RET(true == csIn.empty(), FALSE);
	
	BOOL  bRes  = FALSE;
	ULONG ulRes = 0;

	psOut->clear();
	psOut->resize(ulGetOutputLength(csIn.size()));

	ulRes = ulEncode((UCHAR *)&csIn[0], (UCHAR *)&(*psOut)[0], (ULONG)csIn.size());

	psOut->assign(psOut->c_str(), ulRes);

	return TRUE;
}
//---------------------------------------------------------------------------
#include <vcl.h>
BOOL CXBlowFish::bDecode(const std::string &csIn, std::string *psOut) {
    /*DEBUG*/XASSERT_RET(NULL  != psOut, FALSE);

    CHECK_RET(true == csIn.empty(), FALSE);

    BOOL  bRes  = FALSE;
    ULONG ulRes = 0;

    psOut->clear();
    psOut->resize(csIn.size());
    /*DEBUG*/XASSERT_RET(csIn.size() == (*psOut).size(), FALSE);

    vDecode((UCHAR *)&csIn[0], (UCHAR *)&(*psOut)[0], /*(ULONG)*/csIn.size());

    //std::string sTemp((*psOut).c_str());
//    std::string sTemp("ggg");
//
//    (*psOut) = sTemp;

    return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//the low level (private) encryption function
VOID CXBlowFish::Blowfish_encipher(ULONG *xl, ULONG *xr) {
	union aword  Xl, Xr = {0};

	Xl.dword = *xl ;
	Xr.dword = *xr ;

	Xl.dword ^= PArray [0];
	ROUND (Xr, Xl, 1) ;  ROUND (Xl, Xr, 2) ;
	ROUND (Xr, Xl, 3) ;  ROUND (Xl, Xr, 4) ;
	ROUND (Xr, Xl, 5) ;  ROUND (Xl, Xr, 6) ;
	ROUND (Xr, Xl, 7) ;  ROUND (Xl, Xr, 8) ;
	ROUND (Xr, Xl, 9) ;  ROUND (Xl, Xr, 10) ;
	ROUND (Xr, Xl, 11) ; ROUND (Xl, Xr, 12) ;
	ROUND (Xr, Xl, 13) ; ROUND (Xl, Xr, 14) ;
	ROUND (Xr, Xl, 15) ; ROUND (Xl, Xr, 16) ;
	Xr.dword ^= PArray [17] ;

	*xr = Xl.dword ;
	*xl = Xr.dword ;
}
//---------------------------------------------------------------------------
//the low level (private) decryption function
VOID CXBlowFish::Blowfish_decipher(ULONG *xl, ULONG *xr) {
	union aword  Xl = {0};
	union aword  Xr = {0};

	Xl.dword = *xl ;
	Xr.dword = *xr ;

	Xl.dword ^= PArray [17] ;
	ROUND (Xr, Xl, 16) ;  ROUND (Xl, Xr, 15) ;
	ROUND (Xr, Xl, 14) ;  ROUND (Xl, Xr, 13) ;
	ROUND (Xr, Xl, 12) ;  ROUND (Xl, Xr, 11) ;
	ROUND (Xr, Xl, 10) ;  ROUND (Xl, Xr, 9) ;
	ROUND (Xr, Xl, 8) ;   ROUND (Xl, Xr, 7) ;
	ROUND (Xr, Xl, 6) ;   ROUND (Xl, Xr, 5) ;
	ROUND (Xr, Xl, 4) ;   ROUND (Xl, Xr, 3) ;
	ROUND (Xr, Xl, 2) ;   ROUND (Xl, Xr, 1) ;
	Xr.dword ^= PArray[0];

	*xl = Xr.dword;
	*xr = Xl.dword;
}
//---------------------------------------------------------------------------