/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/xassert.h> 

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h> 
#include <XLib/CXMsgBoxRtfEx.h>


/****************************************************************************
*	release
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID vAppendLogFile(const std::string &csFilePath, const std::string &csText) {
	FILE *pFile = fopen(csFilePath.c_str(), "a");
	if (NULL == pFile) {
		return;
	}

	__try {
		SYSTEMTIME stST = {0};
		::GetLocalTime(&stST);
		fprintf(pFile, "[%d:%d:%d]  %s\n---------------------------------------------------------------------------\n\n", 
			            stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());
	}
	__finally {
		if (NULL != pFile) {
			fflush(pFile);
			fclose(pFile);	pFile = NULL;
		}
	}
}
//---------------------------------------------------------------------------
VOID vAssertLog(const std::string &csExp, 
				ULONG			   ulLastError, 
				const std::string &csFile, 
				ULONG			   ulLine, 
				const std::string &csFunc, 
				const std::string &csComment) 
{
	::SetLastError(0);

	//-------------------------------------
	//�������� ���������
	std::string sProgram      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), FALSE);
	std::string sFile         = CXPath::sWinToUnixPath(CXPath::sMinimizePath(csFile,     45), FALSE);
	std::string sGetLastError = sLastErrorStr(ulLastError);
	std::string sExeName      = CXPath::sExtractFileName(CXPath::sExePath());							
																					
	std::string sFStr = sFormatStr(
				"%s\n\n"
				"%s:  %s\n"
				"%s:  %s\n"
				"%s:  %i\n"
				"%s:  %s\n"
				"%s:  %s\n"
				"%s:  %s\n"		/*����� ���� \n �� ����*/
				"%s:  %s",	

				"Assertion failed.",
				"Program:",         sProgram.c_str(),
				"File:",            sFile.c_str(),
				"Line:",            ulLine,
				"Function:",        csFunc.c_str(),
				"Expression:",      csExp.c_str(),
				"GetLastError:",    sGetLastError.c_str(),
				"Comment:",         csComment.c_str());
																							
	//-------------------------------------
	//������� � ���
	std::string sFilePath = CXPath::sChangeFileExt(CXPath::sExePath(), "debug");
																							
	vAppendLogFile(sFilePath, sFStr.c_str());												
}
//---------------------------------------------------------------------------


/****************************************************************************
* debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL bCheckForDebugger() {
	__try {
		::DebugBreak();
	}
	__except (GetExceptionCode() == EXCEPTION_BREAKPOINT ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
		// No debugger is attached, so return FALSE and continue.
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
VOID vAssert(const std::string &csExp, 
			 ULONG              ulLastError, 
			 const std::string &csFile, 
			 ULONG              ulLine, 
			 const std::string &csFunc, 
			 const std::string &csComment)
{
	//-------------------------------------
	//�������� ���������
	std::string sProgram      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), false);
	std::string sFile         = CXPath::sWinToUnixPath(CXPath::sMinimizePath(csFile,     45), false);
	std::string sGetLastError = sLastErrorStr(ulLastError);
	std::string sExeName      = CXPath::sExtractFileName(CXPath::sExePath());

	std::string sFStr = sFormatStr(
				////"%s\n\n"
				////"%s:  %s\n"
				////"%s:  %s\n"
				////"%s:  %i\n"
				////"%s:  %s\n"
				////"%s:  %s\n"
				////"%s:  %s"		/*����� ���� \n �� ����*/
				////"%s:  %s",	
				"{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}"
				"{\\colortbl ;\\red255\\green0\\blue0;}"
				"\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par"
				"\\par"
				"\\b %s\\b0   \\lang1033\\f1      \\cf1\\lang1049\\f0 %s\\par"
				"\\cf0\\b %s\\b0   \\lang1033\\f1              \\cf1\\lang1049\\f0 %s\\par"
				"\\cf0\\b %s\\b0   \\lang1033\\f1             \\cf1\\lang1049\\f0 %i\\cf0\\par"
				"\\b %s\\b0  \\lang1033\\f1     \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0   \\lang1033\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0\\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0  \\lang1033\\f1      \\cf1 %s\\cf0\\lang1049\\f0\\par}",			 

				"Assertion failed.",
				"Program:",         sProgram.c_str(),
				"File:",            sFile.c_str(),
				"Line:",            ulLine,
				"Function:",        csFunc.c_str(),
				"Expression:",      csExp.c_str(),
				"GetLastError:",    sGetLastError.c_str(),
				"Comment:",         csComment.c_str() 
	);

	//-------------------------------------
	//������� MessageBox
	//INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	INT iRes = NMsgBoxRtf::iShow(NULL, sFStr, sExeName);
	switch (iRes) {
		case NMsgBoxRtf::mrAbort: 
			{
	    		exit(- 1);
			}
			break;

		case NMsgBoxRtf::mrRetry: 
			{
				////if (FALSE == bCheckForDebugger()) { //CheckRemoteDebuggerPresent  /*::IsDebuggerPresent*/
				////	MsgBox("Debugger is not present.\nThe application will be terminated.", "XLib", MB_OK | MB_ICONWARNING);
				////	exit(- 1);
				////} else {
				////	////_asm {int 3}
				////	////CrtDbgBreak();
				////	////::DebugBreak();
				////}

				_asm {int 3}
			}
			break;
		
		case NMsgBoxRtf::mrIgnore: 
			{
				//����������
			}
			break;
		
	}
}
//---------------------------------------------------------------------------