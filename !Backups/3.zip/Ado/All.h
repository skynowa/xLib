#ifndef _ADO_ALL_H_
#define _ADO_ALL_H_
//
// all.h
//
// (C) Copyright 2003 Jan van den Baard
//     All Rights Reserved.
//

// Simply include all headers in this directory.
#include "adobase.h"
#include "ado2.h"
#include "adox.h"
#include "currency.h"
#include "datetime.h"

#endif // _ADO_ALL_H_