#ifndef _CUSTOMTABCTRL_ALL_H_
#define _CUSTOMTABCTRL_ALL_H_
//
// all.h
//
// (C) Copyright 2004 Jan van den Baard
//     All Rights Reserved.
//

#include "customtabctrl.h"
#include "dotnettabctrl.h"
#include "foldertabctrl.h"

#endif // _CUSTOMTABCTRL_ALL_H_