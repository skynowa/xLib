#ifndef __ComErrMsg_h__
#define __ComErrMsg_h__

#include <comdef.h>

class COMErrMsg
{

public:

	COMErrMsg( REFGUID rguid, LPCOLESTR szSource  );
	virtual ~COMErrMsg();

	HRESULT Build( UINT nID, int sev, int code );
	HRESULT Build(_com_error e);

private:
	
	REFGUID    m_rguid;
	LPCOLESTR  m_szSource;
};

#endif //__ComErrMsg_h__
