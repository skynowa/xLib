#ifndef __CPicturePacker_h__
#define __CPicturePacker_h__

//
// CPicturePacker
//
// Abstract base class handling picture compression.
//
// Written by Laurent Kemp� (lkempe@netcourrier.com) for Tech Head WebSite
// Copyright (c) 2001 Laurent Kemp�.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPicturePacker  
{

public:

	CPicturePacker() {};
	virtual ~CPicturePacker() {};

	// Methods ////////////////////////////////////////////////////////////////
	
public:
	
	virtual bool Pack( unsigned char * pSource, 
					   unsigned int nSourceBytes,
					   int BitmapWidth,
					   int BitmapWidthBytes,
					   int BitmapHeight,
					   unsigned char ** ppPacked,
					   unsigned long * pnPackedBytes ) = 0;
	
	
	virtual bool UnPack( unsigned char * pSource,
						 long nSourceBytes,
						 unsigned char ** ppUnPacked,
						 unsigned int * pnUnPackedBytes,
						 unsigned long * pBitmapWidth,
						 unsigned long * pBitmapWidthBytes,
						 unsigned long * pBitmapHeight ) = 0;
	
protected:
		
	// Data Members ///////////////////////////////////////////////////////////
	
public:
	
protected:
	
	
};

#endif //__CPicturePacker_h__
