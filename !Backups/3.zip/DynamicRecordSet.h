#if !defined(AFX_DYNAMICRECORDSET_H__B763D08F_EF6E_11D4_B317_C4C87BA9B871__INCLUDED_)
#define AFX_DYNAMICRECORDSET_H__B763D08F_EF6E_11D4_B317_C4C87BA9B871__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DynamicRecordSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDynamicRecordSet recordset

class CDynamicRecordSetDataStorage
{
public:
	CString m_Text;
	long	m_int;
	double	m_float;
	CTime	m_Time;
};
typedef CTypedPtrMap<CMapStringToPtr,CString,CDynamicRecordSetDataStorage*>CDynamicRecordSetDataStorageMap;
class CDynamicRecordSet : public CRecordset
{
public:
	bool DirectSQL(CString sql);
	void ProcessError(CDBException* e);
	void DisConnect();
	bool Connect(CString strConnect,int QueryTimeout=30,bool fEnableMessages=false);
	DECLARE_DYNAMIC(CDynamicRecordSet)
	bool DynOpen(CString s="",bool fEnableMapping=false);
	bool DynOpen(LPSTR lpszSQL,bool fEnableMapping=false);
	bool DynSetAbsPos(int Row);
	bool DynMove(long nRows);
	bool DynMoveFirst();
	bool DynMoveLast();
	bool DynMovePrev();
	bool DynMoveNext();
	bool DynDelete();
	bool DynAddNew();
	bool DynUpdate();
	bool DynEdit();
	void Close();
	CDatabase	m_db;
	CDynamicRecordSetDataStorage* GetFieldPtr(CString Name);
	bool SetField(CString Field,int Val);
	bool SetField(CString Field,double Val);
	bool SetField(CString Field,CString Val);
	int GetIntField(CString FieldName);
	double GetDoubleField(CString FieldName);
	CString GetTextField(CString FieldName);
	CDynamicRecordSet(CString ConnectStr);
	CDynamicRecordSet(CDatabase* pDatabase = NULL);
	CDynamicRecordSetDataStorage m_Data[256];
	CStringArray	m_Name;
	CDWordArray		m_Type;
	int m_ColCount;
	CString m_sLastError;
	CString m_LastSelect;
	CString m_LastErrCod;
	CString m_ConnectString;
	int m_QueryTimeout;
	

private:
	bool	m_fConnectionFAILED;
	bool	m_fFieldsInfo;
	bool	m_fEnableMessage;
	bool	m_fEnableMapping;
	bool	GetRecordSetFieldsInfo();
	CDynamicRecordSetDataStorageMap	m_DataMap;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDynamicRecordSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
typedef CTypedPtrArray<CObArray,CDynamicRecordSet*>CDynamicRecordsetArray;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DYNAMICRECORDSET_H__B763D08F_EF6E_11D4_B317_C4C87BA9B871__INCLUDED_)
