#include "StdAfx.h"
#include "ComErrMsg.h"

COMErrMsg::COMErrMsg( REFGUID rguid, LPCOLESTR szSource ) : m_rguid( rguid ), m_szSource( szSource )
{
}

COMErrMsg::~COMErrMsg( )
{
}

HRESULT COMErrMsg::Build( UINT nID, int sev, int code)
{
	ICreateErrorInfo* pCreateErrorInfo;

	CreateErrorInfo( &pCreateErrorInfo );

	CComBSTR abstr;
	abstr.LoadString( nID );

	pCreateErrorInfo->SetDescription( abstr );
	pCreateErrorInfo->SetGUID( m_rguid );
	pCreateErrorInfo->SetSource( (LPOLESTR)m_szSource );

	IErrorInfo* pErrorInfo;
	pCreateErrorInfo->QueryInterface( IID_IErrorInfo, (void**)&pErrorInfo );
	SetErrorInfo( 0, pErrorInfo );

	pErrorInfo->Release();
	pCreateErrorInfo->Release();
		
	return MAKE_HRESULT( sev, FACILITY_ITF, code );
}

HRESULT COMErrMsg::Build(_com_error e)
{
	ICreateErrorInfo* pCreateErrorInfo;
	
	CreateErrorInfo( &pCreateErrorInfo );

	pCreateErrorInfo->SetDescription( e.Description() );
	pCreateErrorInfo->SetGUID( m_rguid );
	pCreateErrorInfo->SetSource( (LPOLESTR)m_szSource );
	
	IErrorInfo* pErrorInfo;
	pCreateErrorInfo->QueryInterface( IID_IErrorInfo, (void**)&pErrorInfo );
	SetErrorInfo( 0, pErrorInfo );
	
	pErrorInfo->Release();
	pCreateErrorInfo->Release();

	return e.Error();
}