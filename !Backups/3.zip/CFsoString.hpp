/**********************************************************************
 *	����� CFsoString (CFsoString.hpp)       http://www.richelbilderbeek.nl/CppFileExists.htm
 *
 ***********************************************************************/


#ifndef CFsoStringHPP
#define CFsoStringHPP       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <iostream>
#include <cassert>
#include <algorithm>
#include <ostream>
#include <iterator>
//---------------------------------------------------------------------------
bool                            bFileExists          (const std::string &csFilePath);
void                            vCopyFile            (const std::string &csFilePathFrom, const std::string &csFilePathTo);
unsigned long int               ulFileLines          (const std::string &csFilePath);

const std::vector <std::string> vecFileToVector      (const std::string &csFilePath);
void                            vFileToArray         (const std::string &csFilePath);
template <class T> void         vRandomShuffle       (std::vector<T> &v);
template <class T> void         vSortVector          (std::vector<T> &v);

std::string						sExePath             ();
std::string						sExtractFilePath     (const std::string &csFilePath);
std::string                     sExtractFullFileName (const std::string &csFilePath);
std::string                     sExtractShortFileName(const std::string &csFilePath);
std::string                     sExtractFileExt      (const std::string &csFilePath);

std::string                     sChangeFileExt       (const std::string &csFilePath, const std::string &csFileExt);
std::string                     sChangeFullFileName  (const std::string &csFilePath, const std::string &csFileName);

std::string                     sRemoveFileExt       (const std::string &csFileName);

/*
ExtractFileDir 
ExtractFileDrive 
ExtractFileExt 
ExtractFileName 
ExtractFilePath 
ExtractRelativePath 
ExtractShortPathName
*/
//---------------------------------------------------------------------------



/**********************************************************************
 *	����� CFsoString (CFsoString.cpp)
 *
 ***********************************************************************/


//--------------------------------------------------------------------------
bool bFileExists(const std::string &csFilePath) {
	//std::fstream fin("");
	//fin.open(casFileName.c_str(), std::ios::in);
	//if (fin.is_open()) {
	//	fin.close();
	//	
	//	return true;
	//}
	//fin.close();
	//return false;
	
	return GetFileAttributes(csFilePath.c_str()) != INVALID_FILE_ATTRIBUTES; 
}
//--------------------------------------------------------------------------
void vCopyFile(const std::string &csFilePathFrom, const std::string &csFilePathTo) {
	assert(bFileExists(csFilePathFrom));
	
	std::ifstream in(csFilePathFrom.c_str());
	std::ofstream out(csFilePathTo.c_str());
	out << in.rdbuf();
	out.close();
	in.close();
}
//--------------------------------------------------------------------------
unsigned long int ulFileLines(const std::string &csFilePath) {
	unsigned long int ulLines = 0;   //������� �����

	std::ifstream fin(csFilePath.c_str(), std::ios::in);
	if (fin) {
		char cChar = '\0';
		while (fin.get(cChar)) {
			if (cChar == '\n') {
				ulLines ++;
			}
		} 
		ulLines ++;
	} else {
		return 0;
	}

	fin.close();
	
	return ulLines;
}
//--------------------------------------------------------------------------
const std::vector <std::string> vecFileToVector(const std::string &csFilePath) {
	assert(bFileExists(csFilePath) == true);

	std::vector <std::string> vecVector;
	std::ifstream             in(csFilePath.c_str());
	std::string               sStr("");

	for (int i = 0; !in.eof();  ++ i) {
		std::getline(in, sStr);
		vecVector.push_back(sStr);
	}

	return vecVector;
}
//--------------------------------------------------------------------------
void vFileToArray(const std::string &csFilePath) {
	//ulFileLines(csFilePath);
	//...
}
//--------------------------------------------------------------------------
template <class T> void vRandomShuffle(std::vector<T> &v) {
	std::random_shuffle(v.begin(), v.end());
	/*	std::vector<std::string>(v);
	v.push_back("111111");
	v.push_back("2222222");
	v.push_back("33333333");
	v.push_back("4444444444");
	v.push_back("55555555555");

	vRandomShuffle(v);

    for (unsigned int i = 0; i < v.size(); i ++) {
		MessageBox(0, v.at(i).c_str(), "", MB_OK);
    }
*/
}
//--------------------------------------------------------------------------
template <class T> void vSortVector(std::vector<T> &v) {
    std::sort(v.begin(), v.end());
}
//---------------------------------------------------------------------------
std::string sExePath() {
	char szExePath[MAX_PATH];	memset(szExePath, 0, sizeof(szExePath));
	GetModuleFileName(GetModuleHandle(NULL), szExePath, MAX_PATH);		

	return std::string(szExePath);	
}
//---------------------------------------------------------------------------
std::string sExtractFilePath(const std::string &csFilePath) {
	/*std::string sGetFilePath(const std::string &csFilePath) {    //without a trailing backslash '\'	//?????
		const int ciEndOfPathIndex = csFilePath.rfind("\\", csFilePath.size());
		assert(ciEndOfPathIndex <static_cast <int> (csFilePath.size()));
		
		return csFilePath.substr(0, ciEndOfPathIndex);
	}*/

	std::string sRes("");
	sRes.assign(csFilePath);

	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� ���� '\\'
		if (sRes.at(i - 1) == '\\') {
			sRes.erase(i, sRes.length() - i);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sExtractFullFileName(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� ���� '\\'
		if (sRes.at(i - 1) == '\\') {
			sRes = sRes.substr(i, sRes.length() - i);
			
			break;
		}
	}
	//const int ciEndOfPathIndex = casFileName.rfind("\\", casFileName.size());
	
	return sRes;
}
//--------------------------------------------------------------------------
std::string sExtractShortFileName(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	sRes = sRemoveFileExt(sExtractFullFileName(sRes));

	return sRes;
}
//--------------------------------------------------------------------------
std::string sExtractFileExt(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);
	
	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� '.'
		if (sRes.at(i - 1) == '.') {
			sRes = sRes.substr(i, sRes.length() - i);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sChangeFileExt(const std::string &csFilePath, const std::string &csFileExt) {	
	std::string sRes("");
	sRes.assign(csFilePath);
	
	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� '.'
		if (sRes.at(i - 1) == '.') {
			sRes.erase(i, sRes.length() - i);
			sRes.append(csFileExt);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sChangeFullFileName(const std::string &csFilePath, const std::string &csFileName) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� ���� '\\'
		if (sRes.at(i - 1) == '\\') {
			sRes.erase(i, sRes.length() - i);
			sRes.append(csFileName);
			
			break;
		}
	}

	return sRes;
}

//---------------------------------------------------------------------------
std::string sRemoveFileExt(const std::string &csFileName) {
	std::string sRes("");
	sRes.assign(csFileName);

	for (unsigned int i = sRes.length() - 1; i > 0; i --) {
		//������� '.' - ������� ����� � ����������
		if (sRes.at(i - 1) == '.') {
			sRes = sRes.erase(i - 1, sRes.length() - i + 1);
			
			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
#endif

//--------------------------------------------------------------------------
/*int main() {
//Silenty executes 'dir' and writes the output to the file "temp.txt"
std::system("dir > temp.txt");

//Read "temp.txt" in a std::vector<std::string>
const std::vector<std::string> file(FileToVector("temp.txt"));

//Display the file
typedef std::vector<std::string>::const_iterator Iterator;
for (Iterator i = file.begin(); i!=file.end(); ++i)
{
std::cout << *i << std::endl;
}

//Wait for key press
std::cin.get();
}*/
//--------------------------------------------------------------------------
/*
Perform a file operation (see API doc)
Also includes MakeDir and DeleteFile

Dependencies: GetShell32Version (only for NT4 compatibility)

Web: http://beta.unclassified.de/code/cpp/
*/
/*
// wFunc: FO_COPY, FO_DELETE, FO_MOVE, FO_RENAME
bool CFileSys::FileOperation(UINT wFunc, LPCTSTR szSrc, LPCTSTR szDest)
{
    SHFILEOPSTRUCT fos;
    char cFrom[MAX_PATH + 2];
    int iRet;

    strcpy(cFrom, szSrc);
    cFrom[strlen(cFrom) + 1] = '\0';  // IMPORTANT: add second NULL

    fos.wFunc = wFunc;
    fos.pFrom = cFrom;
    fos.pTo = szDest;
    fos.fFlags = FOF_NOCONFIRMATION | FOF_NOCONFIRMMKDIR | FOF_NOERRORUI | FOF_RENAMEONCOLLISION | FOF_SILENT;

    iRet = SHFileOperation(&fos);

    // workaround on windows nt 4
    if ((GetShell32Version() == "4.00") && ((iRet == 117) || (iRet == 183)))
    {
        fos.fAnyOperationsAborted = true;
    }

    return !iRet && !fos.fAnyOperationsAborted;
}

int MakeDir(LPCTSTR szPath)
{
    if (!CreateDirectory(szPath, NULL))
    {
        return GetLastError();
    }
    else
    {
        return 0;
    }
}


bool DeleteFile(LPCTSTR szFilename)
{
    return FileOperation(FO_DELETE, szFilename, "");
}*/


//--------------------------------------------------------------------------
/*
Return system directories

Dependencies: CString

Web: http://beta.unclassified.de/code/cpp/
*/
/*
// SystemDir defines
#define SD_ROOT          0x0100
#define SD_WIN           0x0101
#define SD_SYS           0x0102

// params used for SHGetSpecialFolderPath
// only available with shell32.dll v4.71+
// copied from pladform sdk shlobj.h (SD_* was originally CSIDL_*)
// remarked values return no filesystem path
#define SD_DESKTOP                   0x0000        // <desktop>
#define SD_PROGRAMS                  0x0002        // Start Menu\Programs
#define SD_PERSONAL                  0x0005        // My Documents
#define SD_FAVORITES                 0x0006        // <user name>\Favorites
#define SD_STARTUP                   0x0007        // Start Menu\Programs\Startup
#define SD_RECENT                    0x0008        // <user name>\Recent
#define SD_SENDTO                    0x0009        // <user name>\SendTo
#define SD_STARTMENU                 0x000b        // <user name>\Start Menu
#define SD_DESKTOPDIRECTORY          0x0010        // <user name>\Desktop
#define SD_NETHOOD                   0x0013        // <user name>\nethood
#define SD_FONTS                     0x0014        // windows\fonts
#define SD_TEMPLATES                 0x0015
#define SD_COMMON_STARTMENU          0x0016        // All Users\Start Menu
#define SD_COMMON_PROGRAMS           0X0017        // All Users\Programs
#define SD_COMMON_STARTUP            0x0018        // All Users\Startup
#define SD_COMMON_DESKTOPDIRECTORY   0x0019        // All Users\Desktop
#define SD_APPDATA                   0x001a        // <user name>\Application Data
#define SD_PRINTHOOD                 0x001b        // <user name>\PrintHood
#define SD_LOCAL_APPDATA             0x001c        // <user name>\Local Settings\Application Data (non roaming)
#define SD_COMMON_FAVORITES          0x001f
#define SD_INTERNET_CACHE            0x0020
#define SD_COOKIES                   0x0021
#define SD_HISTORY                   0x0022
#define SD_COMMON_APPDATA            0x0023        // All Users\Application Data
#define SD_WINDOWS                   0x0024        // GetWindowsDirectory()
#define SD_SYSTEM                    0x0025        // GetSystemDirectory()
#define SD_PROGRAM_FILES             0x0026        // C:\Program Files
#define SD_MYPICTURES                0x0027        // C:\Program Files\My Pictures
#define SD_PROFILE                   0x0028        // USERPROFILE
#define SD_SYSTEMX86                 0x0029        // x86 system directory on RISC
#define SD_PROGRAM_FILESX86          0x002a        // x86 C:\Program Files on RISC
#define SD_PROGRAM_FILES_COMMON      0x002b        // C:\Program Files\Common
#define SD_PROGRAM_FILES_COMMONX86   0x002c        // x86 Program Files\Common on RISC
#define SD_COMMON_TEMPLATES          0x002d        // All Users\Templates
#define SD_COMMON_DOCUMENTS          0x002e        // All Users\Documents
#define SD_COMMON_ADMINTOOLS         0x002f        // All Users\Start Menu\Programs\Administrative Tools
#define SD_CONNECTIONS               0x0031        // Network and Dial-up Connections
//#define SD_INTERNET                  0x0001        // Internet Explorer (icon on desktop)
//#define SD_CONTROLS                  0x0003        // My Computer\Control Panel
//#define SD_PRINTERS                  0x0004        // My Computer\Printers
//#define SD_BITBUCKET                 0x000a        // <desktop>\Recycle Bin
//#define SD_DRIVES                    0x0011        // My Computer
//#define SD_NETWORK                   0x0012        // Network Neighborhood
//#define SD_ALTSTARTUP                0x001d        // non localized startup
//#define SD_COMMON_ALTSTARTUP         0x001e        // non localized common startup
//#define SD_ADMINTOOLS                0x0030        // <user name>\Start Menu\Programs\Administrative Tools

#define SD_FLAG_CREATE               0x8000        // combine with SD_ value to force folder creation in SHGetFolderPath()
#define SD_FLAG_DONT_VERIFY          0x4000        // combine with SD_ value to return an unverified folder path
#define SD_FLAG_MASK                 0xFF00        // mask for all possible flag values

// runtime function
typedef BOOL (WINAPI *SHGETSPECIALFOLDERPATH)(HWND hwndOwner, LPTSTR lpszPath, int nFolder, BOOL fCreate);
SHGETSPECIALFOLDERPATH pSHGetSpecialFolderPath = 0;


// initialisation needed!
HMODULE hShellDLL = LoadLibrary("shell32.dll");
if (hShellDLL)
{
    pSHGetSpecialFolderPath = (SHGETSPECIALFOLDERPATH) GetProcAddress(hShellDLL, "SHGetSpecialFolderPathA");
}

// free module when finished!
FreeLibrary(hShellDLL);


CString GetSystemDir(int iType)
{
    CString str;
    int i = MAX_PATH + 1;
    switch (iType)
    {
        case SD_ROOT:
            str = GetSystemDir(SD_WIN);
            str = str.Left(3);
            break;
        case SD_WIN:
            GetWindowsDirectory(str.GetBuffer(i), i);
            str.ReleaseBuffer();
            break;
        case SD_SYS:
            GetSystemDirectory(str.GetBuffer(i), i);
            str.ReleaseBuffer();
            break;
        default:
            if (pSHGetSpecialFolderPath)
            {
                pSHGetSpecialFolderPath(NULL, str.GetBuffer(MAX_PATH + 1), iType, FALSE);
                str.ReleaseBuffer();
            }
            else
            {
                str = "";
            }
            break;
    }
    return str;
}*/
//--------------------------------------------------------------------------
/*
Check files for existance, attributes, size
Scan directories

Dependencies: CString, CStringList (MFC)
Status: partially unchecked

Web: http://beta.unclassified.de/code/cpp/
*/
/*
int file_exists(CString filename)
{
    return _access(filename, 0) ? false : true;
}

int is_directory(CString strPath)
{
    WIN32_FIND_DATA lpffd;
    HANDLE      hFind;

    hFind = FindFirstFile(strPath, &lpffd);
    if (hFind != INVALID_HANDLE_VALUE)
    {
        if (lpffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            FindClose(hFind);
            return true;
        }
    }
    FindClose(hFind);
    return false;
}

int dir_list_entries(CString strPath, CStringList *slEntries)
{
    WIN32_FIND_DATA lpffd;
    CString   strTmp;
    HANDLE      hFind;
    int    rc, bRet = true;

    strPath = strPath + "\\*.*";

    rc = false;
    hFind = FindFirstFile(strPath, &lpffd);
    while (hFind != INVALID_HANDLE_VALUE && bRet)
    {
        // at least 1 file was found in the directory
        if (*lpffd.cFileName != '.')
        {
            rc = true;
            if (lpffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            {
                // this is a directory
                strTmp.Format("%s", lpffd.cFileName);
                slEntries->AddHead(strTmp);
            }
        }
        bRet = FindNextFile(hFind, &lpffd);
    }
    FindClose(hFind);

    return rc;
}*/
//--------------------------------------------------------------------------
/*
��� 74 - ������� GetCurrentDirectory() � SetCurrentDirectory()
 

������ ������� �������� ������� �������: 

DWORD GetCurrentDirectory
(
	DWORD nBufferLength,	// ������ ������
	LPTSTR lpBuffer		// ��������� �� �����
);

���� ������� ������� �����������, �������� �������� ���������� ����� ��������, ���������� � �����, �� ������� ������ ����������, ����� �������� �������� �������. ���� �����, ��������� �� lpBuffer �� ���������� �������, �������� �������� ���������� ��������� ������ ������, ������� ����� ������, ����������� ��� ������� ����������. 

������ ������� ������������� ������� �������: 

BOOL SetCurrentDirectory
(
	LPCTSTR lpPathName		// ��� ��������
);

���� ��� ���������, �� ������� ������ ��������� ��������, � ��������� ������ ����. �� � ������ ��� ��. 

// TestDir.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include "iostream.h"

void main()
{
	TCHAR buffer[MAX_PATH];
	GetCurrentDirectory(sizeof(buffer),buffer);
	cout << buffer << endl;
	SetCurrentDirectory("C:\\");
	GetCurrentDirectory(sizeof(buffer),buffer);
	cout << buffer << endl;
}

� ��� ��������� � ����: 

C:\VC\TestDir
C:\
Press any key to continue


*/
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
