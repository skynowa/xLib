// FileMap.h: interface for the FileMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEMAP_H__948D8A79_E5CF_11D1_A7F7_00C04FB6794C__INCLUDED_)
#define AFX_FILEMAP_H__948D8A79_E5CF_11D1_A7F7_00C04FB6794C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef _AFXDLL
#include <windows.h>
#else
////#include <afx.h>
#endif

class FileMap  
{
public:
	FileMap();
	virtual ~FileMap();

	virtual PBYTE		Map(DWORD dwSize, DWORD dwProtect = PAGE_READWRITE);
	virtual PBYTE		GetBuffer();
	virtual DWORD		GetLength();
	virtual void		Close();

protected:

	HANDLE				m_hMap;
	PBYTE					m_pMap;
	DWORD					m_dwSize;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.


#endif // !defined(AFX_FILEMAP_H__948D8A79_E5CF_11D1_A7F7_00C04FB6794C__INCLUDED_)
