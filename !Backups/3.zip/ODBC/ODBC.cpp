// ODBC.cpp: implementation of the CODBC class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ODBC.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#include <afxdb.h>		//Needed for WriteProfile
#include <odbcinst.h>	//Needed for SQLConfigDataSource etc


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CODBC::CODBC()
{

}

CODBC::~CODBC()
{

}

BOOL CODBC::CreateDSN(CString sDBPath, CString sProjectName, CString sDescription)
{//Function creates System DSN.
 //Projectname should be one word ("Demo")
 //DBPath should be full path without filename: ("C:\Tests")
 //Description: optional parameter.

	//Check in ODBC.INI (In your Windows DIR) if DSN already exists:
	HKEY hKey; 
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\ODBC\\ODBC.INI\\" + sProjectName), 0L, KEY_QUERY_VALUE, &hKey))
	{ 
		RegCloseKey(hKey); 
		AfxMessageBox("Data Source is already registered");
		return FALSE; 
	} 
	
	char MdbFile[_MAX_FNAME];
	char DSNName[_MAX_FNAME];
	char Description[_MAX_PATH];

	char* szDesc;
	char* szAttributes;
	int mlen, i=0, j=0;

	lstrcpy(DSNName, sProjectName);
	sProjectName=sDBPath + "\\" + sProjectName + ".mdb";
	lstrcpy(MdbFile, sProjectName);
	lstrcpy(Description,sDescription);

	szDesc = new char[256];
	szAttributes = new char[256];
	
	//Use Hexadecimal 'FF' (=255) as temporary place holder
	wsprintf(szDesc, "DSN=%s \xFF DESCRIPTION=%s \xFF DBQ=%s: FIL=MS Access;\xFF \xFF ", DSNName, Description, MdbFile);
	mlen = strlen(szDesc);
	
	//Loop to replace "FF" by "\0"(so as to store multiple strings into one):
	while(i<mlen-1)
	{
		if ((szDesc[i] == '\xFF') && (szDesc[i+1] == ' '))
		{
			szAttributes[j] = '\0';
			i++;
		}
		else
		{
			szAttributes[j] = szDesc[i];
		}
		i++;
		j++;
	}

	//Create DSN:
	if (!SQLConfigDataSource(NULL, ODBC_ADD_SYS_DSN, "Microsoft Access Driver (*.mdb)\0", (LPCSTR)szAttributes))
	{
		AfxMessageBox("Failed to add Data Source\nBe sure you are logged on as an Administrator");
		delete [] szDesc;
		delete [] szAttributes;
		return FALSE;
	}
	else
	{
		AfxMessageBox("Data Source Name was added successfully");
	}
		
	delete [] szDesc;
	delete [] szAttributes;

	return TRUE;
}
