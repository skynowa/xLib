// ODBC.h: interface for the CODBC class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBC_H__2D467733_6C12_4E2C_A021_65A2DF970441__INCLUDED_)
#define AFX_ODBC_H__2D467733_6C12_4E2C_A021_65A2DF970441__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CODBC  
{
public:
	CODBC();
	virtual ~CODBC();

	BOOL CreateDSN(CString sDBPath, CString sProjectName, CString sDescription="");

};

#endif // !defined(AFX_ODBC_H__2D467733_6C12_4E2C_A021_65A2DF970441__INCLUDED_)
