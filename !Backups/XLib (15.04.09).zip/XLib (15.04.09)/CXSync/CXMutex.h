/****************************************************************************
*    �����: CXMutex (CXMutex.h)
*
*****************************************************************************/


#ifndef CXMutexH
#define CXMutexH
//---------------------------------------------------------------------------
#include <iostream>
#include <windows.h>
#include <process.h>
#include <assert.h>
//---------------------------------------------------------------------------
class CXMutex {
	public:
		       CXMutex              ();
			   CXMutex              (LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialState, LPCSTR lpszName);
			  ~CXMutex              ();
	    HANDLE hGetHandle           ();
		BOOL   bCreate              (LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialState, LPCSTR lpszName);
		BOOL   bOpen                (DWORD dwAccess, BOOL bInheritHandle, LPCSTR lpszName);
		BOOL   bRelease             ();
		DWORD  dwWaitForSingleObject(DWORD dwTimeout);

	private:
		HANDLE m_hMutex;
};
//---------------------------------------------------------------------------
#endif