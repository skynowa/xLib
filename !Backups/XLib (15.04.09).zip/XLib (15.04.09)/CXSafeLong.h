/****************************************************************************
*    ����� CXSafeLong (CXSafeLong.h)	
*
*****************************************************************************/


#ifndef SAFELONG_H_INCLUDED
#define SAFELONG_H_INCLUDED
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
class CXSafeLong {
	public:
		CXSafeLong(void)  { 
			InterlockedExchange(&m_liValue, 0); 
		}

		~CXSafeLong(void) {

		}

		CXSafeLong& operator += (const CXSafeLong &_Right) {
			InterlockedExchangeAdd(&m_liValue, _Right.m_liValue); 

			return *this;
		}

		CXSafeLong& operator -= (const CXSafeLong &_Right) {
			InterlockedExchange(&m_liValue, m_liValue - _Right.m_liValue); 

			return *this;
		}

		CXSafeLong& operator = (const CXSafeLong &_Right)	{
			InterlockedExchange(&m_liValue, _Right.m_liValue); 

			return *this;
		}

		CXSafeLong& operator += (const long _Right) {
			InterlockedExchangeAdd(&m_liValue, _Right); 

			return *this;
		}

		CXSafeLong& operator -= (const long _Right) {
			InterlockedExchange(&m_liValue, m_liValue - _Right); 

			return *this;
		}

		CXSafeLong& operator = (const long _Right) {
			InterlockedExchange(&m_liValue, _Right); 

			return *this;
		}

		bool operator == (const CXSafeLong &_Right) {
			return m_liValue == _Right.m_liValue;
		}

		bool operator != (const CXSafeLong &_Right) {
			return !(m_liValue == _Right.m_liValue);
		}

		bool operator == (const long _Right) {
			return m_liValue == _Right;
		}

		bool operator != (const long _Right) {
			return !(m_liValue == _Right);
		}

		operator long () {
			return m_liValue;
		}

		operator bool () {
			return m_liValue ? true : false; 
		}

		CXSafeLong& operator ++ (int iPos)	{
			if (0 == iPos) {
				InterlockedIncrement(&m_liValue);
			} else {
				InterlockedExchangeAdd(&m_liValue, iPos + 1);
			}

			return *this;
		}

		CXSafeLong& operator -- (int iPos)	{
			if (0 == iPos) {
				InterlockedDecrement(&m_liValue);
			} else {
				InterlockedExchangeAdd(&m_liValue, - (iPos + 1));
			}

			return *this;
		}

	private:
		long int m_liValue;
};
//---------------------------------------------------------------------------
#endif