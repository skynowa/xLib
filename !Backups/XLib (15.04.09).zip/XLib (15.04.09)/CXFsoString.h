 /****************************************************************************
* Class name:  CXFsoString
* Description: ������ ��� ������ � �������� ��������
* File name:   CXFsoString.h
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:02:43
*
*****************************************************************************/
//http://www.richelbilderbeek.nl/CppFileExists.htm

#ifndef CXFsoStringH
#define CXFsoStringH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <vector>
#include <stdio.h>
//---------------------------------------------------------------------------
//����������
template <class T> void  vRandomShuffle          (std::vector<T> &v); /*-*/
template <class T> void  vSortVector             (std::vector<T> &v); /*-*/

//�������� � ������
std::string				 sExePath                (); /*+*/
std::string				 sExtractFilePath        (const std::string &csFilePath); /*+*/
std::string              sExtractFullFileName    (const std::string &csFilePath); /*+*/
std::string              sExtractShortFileName   (const std::string &csFilePath); /*+*/
std::string              sExtractFileExt         (const std::string &csFilePath); /*+*/
std::string              sChangeFileExt          (const std::string &csFilePath, const std::string &csFileExt); /*+*/
std::string              sChangeFullFileName     (const std::string &csFilePath, const std::string &csFileName); /*+*/
std::string              sRemoveFileExt          (const std::string &csFilePath); /*+*/
std::string              sExtractFileDir         (const std::string &csFilePath); /*+*/
std::string              sExtractFileDrive       (const std::string &csFilePath); /*...*/
std::string              sExtractRelativePath    (const std::string &csFilePath); /*...*/
void					 vMakePathOK			 (LPSTR szPath, bool bNeedBackslashAtEnd);
void					 vBuildPath			     (LPCSTR pszPath);
std::string              sMinimizeFileName       (const std::string &csStr, const unsigned int cuiMaxLen);

//������ �����
bool                     bIsDriveReady           (LPCSTR pcszDrivePath); /*+*/
unsigned long int        ulFileLines             (const std::string &csFilePath); /*+*/
bool                     bFileExists             (const std::string &csFilePath); /*+*/
unsigned long int		 ulFileSize              (FILE *pFile); /*+*/
unsigned long int		 ulFileSize			     (const std::string &csFilePath); /*+*/
unsigned __int64         ui64GetFileSize         (HANDLE hFile);	/*-*/
bool					 bGetCompressedFileSize  (LPCTSTR fileName, unsigned __int64 &size);
bool                     bGetCompressedFileSizeW (LPCWSTR fileName, unsigned __int64 &size);

//��������
bool                     bSetFileNormalAttr      (const std::string &csFilePath); /*+*/
int						 iIsFile                 (const std::string &csFilePath); /*+*/	//0, 1, 2
bool					 bIsReadOnly             (DWORD ulAttr);
bool 					 bIsHidden               (DWORD ulAttr);
bool 					 bIsSystem               (DWORD ulAttr);
bool 					 bIsDirectory            (DWORD ulAttr);
bool 					 bIsArchived             (DWORD ulAttr);
bool 					 bIsCompressed           (DWORD ulAttr);
bool 					 bIsEncrypted            (DWORD ulAttr);

//������ / ������ �����
void                     vFileToArray            (const std::string &csFilePath); /*-*/
std::vector<std::string> vecsReadFile            (const std::string &csFilePath); /*-*/
std::vector<char>        vecchReadFile		     (const std::string &csFilePath); /*-*/
std::string				 sReadText   		     (const std::string &csFilePath); /*+*/
bool					 bWriteText  		     (const std::string &csFilePath, const std::string &csText); /*+*/

//�������� � �������
bool                     bCopyFile               (const std::string &csFilePathFrom, const std::string &csFilePathTo); /*+*/
bool                     bMoveFile               (const std::string &csFilePathIn, const std::string &csFilePathOut);	//����, ������� /*+*/
bool                     bRenameFile             (const std::string &csFilePath); /*...*/
bool                     bDeleteFile             (const std::string &csFilePath); /*+*/
bool                     bSecureDeleteFile       (const std::string &csFilePath, unsigned int uiPasses); /*-*/
bool                     bCutFileFromEnd         (const std::string &csFilePath, long int lDistanceToCut);	/*+*/
bool                     bCutFileFromEnd         (FILE *pFile, unsigned long int ulDistanceToCut);	/*+*/
bool                     bCheckSignature         (char *pszBuff, char *pszSignature, int iSignatureSize);	/*-*/

bool                     bSetRandomFileDate      (const std::string &csFilePath); /*-*/
bool				     bSetFileUncompressedAttr(const std::string &csFilePath); /*-*/
bool			         bSetFileCompressedAttr  (const std::string &csFilePath, bool bCompress); /*-*/

//������
unsigned long int        ulCountDigits           (unsigned long int ulDigit); 
//---------------------------------------------------------------------------
#endif