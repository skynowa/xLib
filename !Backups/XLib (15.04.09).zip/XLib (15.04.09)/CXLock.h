/**********************************************************************
*	����� CXLock (CXLock.h)
*
***********************************************************************/


#ifndef CXLockH
#define CXLockH       
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
class CXLock {
	public:
		CXLock (CRITICAL_SECTION *pcsCS): m_ps(pcsCS) {
			EnterCriticalSection(m_pcsCS); 
		}
		
		~CXLock() { 
			LeaveCriticalSection (m_pcsCS); 
		}

	private:
		CRITICAL_SECTION *m_pcsCS;
};
//---------------------------------------------------------------------------
#endif

#define GUARD_SHARED_DATA(csCS) CXLock csLock(&csCS);

/*
//�������������
void CMyClass::SetXXX (...)
{
   GUARD_SHARED_DATA(m_cs);
   // TODO: ����������� ���� ������
   ...
}*/