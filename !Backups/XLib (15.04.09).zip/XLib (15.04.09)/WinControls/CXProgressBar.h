/****************************************************************************
*	CXProgressBar
*
*****************************************************************************/


#ifndef CXProgressBar_H
#define CXProgressBar_H
//---------------------------------------------------------------------------
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
class CXProgressBar: public CXSubclassWnd {
	public:
		         CXProgressBar();
		BOOL     Create       (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);

		int      SetRange     (int nMin, int nMax);
		int      SetRange32   (int nMin, int nMax);
		void     GetRange     (PPBRANGE pPBRange);
		int      GetRangeLimit(BOOL bLimit);
		int      GetMaxValue  ();
		int      GetMinValue  ();
		int      SetPos       (int nPos);
		int      GetPos       ();
		int      DeltaPos	  (int nDelta);
		int      SetStep      (int nStep);		
		int      StepIt       ();
		COLORREF SetBarColour (COLORREF clrBar);
		COLORREF SetBkColour  (COLORREF clrBk);

/*
		BOOL SetText(LPCTSTR strMessage);
		BOOL SetSize(int nSize);

*/
};
//---------------------------------------------------------------------------
#endif