/**********************************************************************
*	����� CXTab (CXTab.h)
*
***********************************************************************/


#ifndef CXTabH
#define CXTabH       
//---------------------------------------------------------------------------
#include <windows.h>
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
class CXTab : public CXSubclassWnd {
	public:
	                CXTab       ();
		            //~CXTab    ();
		BOOL        Create      (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);
		void        vInsertTab  (HWND hParent, HMENU hmnuID, LPSTR lpCaption, int iPos, int iImage);
		void        vAddDlg     (HWND hPageDlg, int iPos);
		BOOL        bShowTab    (int iPos, BOOL bFlag);
		LRESULT     iGetCurrSel ();
		LRESULT     GetImageList();
		HIMAGELIST  SetImageList(HIMAGELIST lImageList);
};
//---------------------------------------------------------------------------
#endif