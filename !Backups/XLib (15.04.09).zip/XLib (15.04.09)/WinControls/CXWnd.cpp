/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#include "CXWnd.h"
//---------------------------------------------------------------------------
CXWnd::CXWnd() {
	_m_hWnd        = NULL;
	_m_hMenu       = NULL;
	_m_sClassName  = "CXWnd";
	_m_DefaultFont = CreateDefaultFont();
	_m_sText       = "";
	OnCreate       = NULL;
	OnDoubleClick  = NULL;
	OnResize       = NULL;
	OnCommand      = NULL;
	OnMouseMove    = NULL;
	OnMouseLeftUp  = NULL;
	OnClose        = NULL;
	OnDestroy      = NULL;
}
//---------------------------------------------------------------------------
//Window Procedure called by windows (static)
LRESULT CALLBACK CXWnd::StatiCXWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	//A pointer to the current class (this) is saved into the window with
	//SetWindowLongPtr. Why ? Because WndProc is called as a static method (it's not supposed to be a class method at first)
	//The message handling is then deferred to OnMessage which can use the this pointer.
	CXWnd *pwndThis;
	if (message == WM_CREATE) {
		CREATESTRUCT *cs = (CREATESTRUCT*)lParam;
		pwndThis = (CXWnd*)cs->lpCreateParams;
		::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)pwndThis);
	} else {
		pwndThis = (CXWnd*)GetWindowLongPtr(hWnd, GWLP_USERDATA);
	}

	if (pwndThis == NULL) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return pwndThis->WndProc(hWnd, message, wParam, lParam);
	} 
}
//---------------------------------------------------------------------------
//Window Procedure
LRESULT CXWnd::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	if (!HandleMessage(hWnd, message, wParam, lParam)) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return FALSE;
	} 
}
//---------------------------------------------------------------------------
//Message handling
BOOL CXWnd::HandleMessage(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) { 
		case WM_CREATE:
			{
				if (NULL != OnCreate) {
					OnCreate(wParam, lParam);
				} 
			}
			break;

		case WM_COMMAND:
			{
				if (NULL != OnCommand) {
					OnCommand(wParam, lParam);
				} 
			}
			break;

		case WM_MOUSEMOVE:
			{
				if (NULL != OnMouseMove) {
					OnMouseMove(wParam, (int)LOWORD(lParam), (int)HIWORD(lParam));
				} 
			}
			break;

		case WM_NOTIFY:
			{
				if (NULL != OnNotify) {
					OnNotify(wParam, lParam);
				} 
			}
			break;

		case WM_LBUTTONUP:
			{
				if (NULL != OnMouseLeftUp) {
					OnMouseLeftUp(wParam, (int)LOWORD(lParam), (int)HIWORD(lParam));
				} 
			}
 
			break;
		case WM_LBUTTONDBLCLK:
			{
				if (NULL != OnDoubleClick) {
					OnDoubleClick();
				}
			} 
			break;

		case WM_MOVE:
			{
				_m_iLeft = LOWORD(lParam);
				_m_iTop  = HIWORD(lParam);
			}
			break;

		case WM_CHAR:
			{
				if (NULL != OnChar) {
					OnChar(wParam, lParam);
				} 
			}
			break;

		case WM_KEYDOWN:
			{
				if (NULL != OnKeyDown) {
					OnKeyDown(wParam, lParam);
				} 
			}
			break;

		case WM_KEYUP:
			{
				if (NULL != OnKeyUp) {
					OnKeyUp(wParam, lParam);
				} 
			}
			break;

		case WM_DEADCHAR:
			{
				if (NULL != OnDeadChar) {
					OnDeadChar(wParam, lParam);
				} 
			}
			break;

		case WM_CONTEXTMENU:
			{
				if (NULL != OnContextMenu) {
					OnContextMenu((HWND)wParam, LOWORD(lParam), HIWORD(lParam));
				} 
			}
			break;

		////case WM_SIZE:
		////	{
		////		_m_iWidth  = LOWORD(lParam); //_rect.right-_rect.left;
		////		_m_iHeight = HIWORD(lParam); //_rect.bottom-_rect.top;
		////		if (NULL != OnResize) {
		////			OnResize(_m_iWidth, _m_iHeight, wParam);
		////		} 
		////	}
		////	break;

		case WM_SIZING:
			{
				if (NULL != OnResizing) {
					OnResizing(wParam, (LPRECT)lParam);
				} 
			}
			break;

		case WM_TIMER:
			{
				if (NULL != OnTimer) {
					OnTimer((HWND)wParam, lParam);
				} 
			}
			break;

		case WM_CLOSE:
			{
				if (NULL != OnClose) {
					OnClose();
				} 
			}
		break;


		case WM_DESTROY:
			{
				if (NULL != OnDestroy) {
					OnDestroy();
				} 
				::PostQuitMessage(0); 
			}
			break;

		default:
			return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
void CXWnd::vStartCommonControls(DWORD dwFlags) {
	INITCOMMONCONTROLSEX iccx;
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = dwFlags;
	InitCommonControlsEx(&iccx);
}
//---------------------------------------------------------------------------
void CXWnd::SetText(const string &csText) {
	_m_sText = csText;
	if (NULL != _m_hWnd) {
		::SetWindowText(_m_hWnd, csText.c_str());
	} 
}
//---------------------------------------------------------------------------
string CXWnd::GetText() {
//// 	if (NULL != _m_hWnd) {
//// 		int nTextLength = ::GetWindowTextLength(_m_hWnd);
//// 		if (nTextLength > 0) {
//// 			CHAR *szText = new CHAR[nTextLength + 1];
//// 			::GetWindowText(_m_hWnd, szText, nTextLength + 1);
//// 			_m_sText = szText;
//// 			delete [] szText;
//// 		} else {
//// 			_m_sText = "";
//// 		} 
//// 	}
//// 
//// 	return _m_sText;

	string    sRes  = "";
	const int ciLen = ::GetWindowTextLength(_m_hWnd);
	if (ciLen > 0 ) {
		sRes.resize(ciLen + 1);
		::GetWindowText(_m_hWnd, &sRes[0], ciLen + 1);
		sRes.resize(ciLen);
	}

	return sRes;
}
//---------------------------------------------------------------------------
HWND CXWnd::GetHandle() {
	return _m_hWnd;
}
//---------------------------------------------------------------------------
HFONT CXWnd::GetFont() {
	return (HFONT)::SendMessage(_m_hWnd, WM_GETFONT, 0, 0);
}
//---------------------------------------------------------------------------
void CXWnd::SetFont(HFONT hFont) {
	::SendMessage(_m_hWnd, WM_SETFONT, (WPARAM)hFont, FALSE);
}
//---------------------------------------------------------------------------
HFONT CXWnd::CreateDefaultFont() {
	return ::CreateFont( -11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
}
//---------------------------------------------------------------------------
void CXWnd::SetDefaultFont() {
	SetFont(_m_DefaultFont);
}
//---------------------------------------------------------------------------
LOGFONT CXWnd::GetLogicalFont() {
	LOGFONT lf;
	::GetObject(GetFont(), sizeof(LOGFONT), &lf);
	return lf;
}
//---------------------------------------------------------------------------
int CXWnd::GetWidth() {
	return _m_iWidth;
}
//---------------------------------------------------------------------------
int CXWnd::GetHeight() {
	return _m_iHeight;
}
//---------------------------------------------------------------------------
int CXWnd::GetLeft() {
	return _m_iLeft;
}
//---------------------------------------------------------------------------
int CXWnd::GetTop() {
	return _m_iTop;
}
//---------------------------------------------------------------------------
void CXWnd::SetSize(int Width, int Height) {
	_m_iWidth  = Width;
	_m_iHeight = Height;
	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, 0, 0, Width, Height, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	} 
}
//---------------------------------------------------------------------------
void CXWnd::SetPosition(int Left, int Top) {
	_m_iLeft = Left;
	_m_iTop  = Top;

	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, Left, Top, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	} 
}
//---------------------------------------------------------------------------
void CXWnd::Align(HWND hParent, HWND hChild) {
	RECT rect;		
	::GetClientRect(hParent, &rect);
	::MoveWindow(hChild, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
}
//---------------------------------------------------------------------------
void CXWnd::SetRect(RECT Rect) {
	_m_iWidth  = Rect.right  - Rect.left;
	_m_iHeight = Rect.bottom - Rect.top;
	_m_iLeft   = Rect.left;
	_m_iTop    = Rect.top;

	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, _m_iLeft, _m_iTop, _m_iWidth, _m_iHeight, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
 	} 
}
//---------------------------------------------------------------------------
RECT CXWnd::GetRect() {
	RECT rect;
	::GetWindowRect(_m_hWnd, &rect);

	return rect;
}
//---------------------------------------------------------------------------
BOOL CXWnd::Destroy() {
	return ::DestroyWindow(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Enable(BOOL Enabled) {
	return ::EnableWindow(_m_hWnd, Enabled);
}
//---------------------------------------------------------------------------
HMENU CXWnd::GetMenu() {
	return _m_hMenu;
}
//---------------------------------------------------------------------------
void CXWnd::SetMenu(HMENU Value) {
	_m_hMenu = Value;
}
//---------------------------------------------------------------------------
HWND CXWnd::SetFocus() {
	return ::SetFocus(_m_hWnd);
}
//---------------------------------------------------------------------------
void CXWnd::SetRedraw(BOOL Redraw) {
	::SendMessage(_m_hWnd, WM_SETREDRAW, Redraw, 0);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(BOOL Erase) {
	return ::InvalidateRect(_m_hWnd, NULL, Erase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(LPRECT Rect, BOOL Erase) {
	return ::InvalidateRect(_m_hWnd, Rect, Erase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate() {
	return ::ValidateRect(_m_hWnd, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate(LPRECT Rect) {
	return ::ValidateRect(_m_hWnd, Rect);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Show(int CmdShow) {
	return ::ShowWindow(_m_hWnd, CmdShow);
}
//---------------------------------------------------------------------------
BOOL CXWnd::IsVisible() {
	return ::IsWindowVisible(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::bIsWindow() {
	return _m_hWnd && ::IsWindow(_m_hWnd);
	////return ::IsWindow(_m_hWnd);
}
//---------------------------------------------------------------------------