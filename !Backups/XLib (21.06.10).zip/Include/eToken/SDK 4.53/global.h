/*
 *
 * Copyright 1999 by Aladdin Knowledge Systems Ltd. Tel Aviv, Israel
 *
 * All Rights Reserved
 *
 * Permission to use, copy, modify and distribute this 
 * software and its documentation for any purpose is 
 * restricted according to the software end user license 
 * attached to this software.
 *
 * Any use of this software is subject to the limitations
 * of warranty and liability contained in the end user
 * license.  Without derogating from the abovesaid, 
 * Aladdin Knowledge Systems Ltd. disclaims all warranty with 
 * regard to this software, including all implied warranties of 
 * merchantability and fitness.  In no event shall Aladdin 
 * Knowledge Systems Ltd. be held liable for any special, indirect
 * or consequential damages or any damages whatsoever
 * resulting from loss of use, data or profits, whether in
 * an action of contract, negligence or other tortious
 * action, arising out of or in connection with the use or 
 * performance of this software.
 *
 */

#include "pkcs11.h"
#include <XLib/Common.h>
#include <XLib/Debug/CXPerform.h>
#include <XLib/Fso/CXStdioFile.h>



CK_CHAR label_public [] = { "My public key"  };
CK_CHAR label_private[] = { "My private key" };

CK_CHAR USER_PIN[] = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};

#define pkcs11_path "etpkcs11.DLL"


// forward declaration of utility function
//
CK_OBJECT_HANDLE find_object (CK_SESSION_HANDLE hSess, CK_ATTRIBUTE * t, CK_ULONG size);
std::string      _sEtokenErrorString(DWORD ulRes);

//global define for find_object function
CK_FUNCTION_LIST_PTR   m_pFunctionList;
CK_C_GetFunctionList   pGFL  = 0;
CK_RV                  rv;

BOOL bEncryptBuff(CK_SESSION_HANDLE hSession, 
	              CK_MECHANISM_PTR  pMechanism, 
				  CK_OBJECT_HANDLE  hKey, 
			  	  CK_BYTE_PTR       pData,              
			  	  CK_ULONG          ulDataLen,           
			  	  CK_BYTE_PTR       pEncryptedData,      
			  	  CK_ULONG_PTR      pulEncryptedDataLen 				  
);

BOOL bDecryptBuff(CK_SESSION_HANDLE hSession, 
	              CK_MECHANISM_PTR  pMechanism, 
				  CK_OBJECT_HANDLE  hKey, 
			  	  CK_BYTE_PTR       pEncryptedData,              
			  	  CK_ULONG          ulEncryptedDataLen,           
			  	  CK_BYTE_PTR       pData,      
			  	  CK_ULONG_PTR      pulDataLen 				  
);