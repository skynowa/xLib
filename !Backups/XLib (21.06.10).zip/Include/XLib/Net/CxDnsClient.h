/****************************************************************************
* Class name:  CxDnsClient
* Description: DNS
* File name:   CxDnsClient.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.06.2010 12:59:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Net_CxDnsClientH
#define XLib_Net_CxDnsClientH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDnsClient : public CxNonCopyable {
	public:
		CxDnsClient();
	   ~CxDnsClient();

		//gethostbyname

	   /*
	   Host
	   Port
	   WaitingTime
	   
	   */
};
//---------------------------------------------------------------------------
#endif //XLib_Net_CxDnsClientH
