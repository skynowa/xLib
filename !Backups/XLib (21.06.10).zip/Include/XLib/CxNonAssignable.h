/****************************************************************************
* Class name:  CxNonAssignable
* Description: ����� ��� ������� ��������� ������������
* File name:   CxNonAssignable.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.11.2009 11:11::00
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CxNonAssignableH
#define XLib_CxNonAssignableH
//---------------------------------------------------------------------------
class CxNonAssignable {
   protected:
       CxNonAssignable() {}
      ~CxNonAssignable() {}
      
   private:  
       const CxNonAssignable &operator = (const CxNonAssignable &);
};
//---------------------------------------------------------------------------
#endif	//XLib_CxNonAssignableH