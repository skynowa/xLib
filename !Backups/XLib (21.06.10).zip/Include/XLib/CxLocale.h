/****************************************************************************
* Class name:  CxLocale
* Description: ������
* File name:   CxLocale.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.08.2009 19:47:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CxLocaleH
#define XLib_Fso_CxLocaleH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxLocale : public CxNonCopyable {
	public:
		              CxLocale   ();
	                 ~CxLocale   ();
	   
	   static tString sGetCurrent();
	   static BOOL    bSetCurrent(LPCTSTR pcszLocale);
	   static BOOL    bSetDefault();

	private:

};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CxLocaleH



//-------------------------------------
////_tsetlocale(LC_ALL, NULL);
////setlocale(LC_ALL, "Russian"); 
//////_tsetlocale(LC_ALL, _T(""));