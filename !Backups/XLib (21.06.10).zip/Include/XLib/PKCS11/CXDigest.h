/****************************************************************************
* Class name:  CXDigest
* Description: PKCS11 �����������
* File name:   CXDigest.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:12:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXDigestH
#define XLib_PKCS11_CXDigestH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXDigest : public CXNonCopyable {
	public:
		     CXDigest      (const CXPKCS11 &cPKCS11, const CXSession &cSession);
	        ~CXDigest      ();
	   
	   	BOOL bMake	       (CK_BYTE_PTR pData, CK_ULONG ulDataLen, CK_BYTE_PTR pDigest, CK_ULONG_PTR pulDigestLen);/*C_Digest*/
		BOOL bEncryptUpdate(CK_BYTE_PTR pPart, CK_ULONG ulPartLen, CK_BYTE_PTR pEncryptedPart, CK_ULONG_PTR pulEncryptedPartLen);	/*C_DigestEncryptUpdate*/
		BOOL bFinal        (CK_BYTE_PTR pDigest, CK_ULONG_PTR pulDigestLen);	/*C_DigestFinal*/	
		BOOL bInit	       (CK_MECHANISM_PTR pMechanism);/*C_DigestInit*/
		BOOL bKey	       (CK_OBJECT_HANDLE hKey);/*C_DigestKey*/	
		BOOL bUpdate       (CK_BYTE_PTR pPart, CK_ULONG ulPartLen);/*C_DigestUpdate*/	
	   	
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXDigestH
