/****************************************************************************
* Class name:  CXObject
* Description: PKCS11 ������
* File name:   CXObject.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:09:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXObjectH
#define XLib_PKCS11_CXObjectH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXObject : public CXNonCopyable {
	public:
		CXObject(const CXPKCS11 &cPKCS11, const CXSession &cSession);
	   ~CXObject();
	   
	    CK_OBJECT_HANDLE hGetHandle() const;
		
	   	BOOL bCreate	  (CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulCount);	/*C_CreateObject*/	
		BOOL bGetSize	  (CK_ULONG_PTR pulSize);	/*C_GetObjectSize*/	
		BOOL bCopy	      (CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulCount, CK_OBJECT_HANDLE_PTR phNewObject);	/*C_CopyObject*/		

		BOOL bFindInit    (CK_ATTRIBUTE_PTR  pTemplate, CK_ULONG ulCount);	/*C_FindObjectsInit*/				
		BOOL bFind        (CK_OBJECT_HANDLE_PTR phObject, CK_ULONG ulMaxObjectCount, CK_ULONG_PTR pulObjectCount);	/*C_FindObjects*/
		BOOL bFindFinal   ();		/*C_FindObjectsFinal*/			

		BOOL bDestroy	  ();	/*C_DestroyObject*/
		
		BOOL bGetAttributeValue  (CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulCount);	/*C_GetAttributeValue*/	
		BOOL bSetAttributeValue  (CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulCount);	/*C_SetAttributeValue*/	
		
		//Utils
		BOOL bUtil_Find   (CK_ATTRIBUTE_PTR pTemplate, CK_ULONG ulCount, std::vector<CK_OBJECT_HANDLE> *pvecObjectHandles);	
		
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;	
		CK_SESSION_HANDLE    _m_hSession;
		CK_OBJECT_HANDLE     _m_hObject;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXObjectH
