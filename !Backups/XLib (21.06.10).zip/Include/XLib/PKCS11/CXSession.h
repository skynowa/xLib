/****************************************************************************
* Class name:  CXSession
* Description: PKCS11 ������
* File name:   CXSession.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:04:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXSessionH
#define XLib_PKCS11_CXSessionH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
//---------------------------------------------------------------------------
class CXSession : public CXNonCopyable {
	public:
		CXSession(const CXPKCS11 &cPKCS11);
	   ~CXSession();

	   	CK_SESSION_HANDLE hGetHandle() const;

	    BOOL bOpen             (CK_SLOT_ID slotID, CK_FLAGS flags, CK_VOID_PTR pApplication, CK_NOTIFY Notify);	/*C_OpenSession*/		
		BOOL bGetInfo          (CK_SESSION_INFO_PTR pInfo);	/*C_GetSessionInfo*/		
		BOOL bSetOperationState(CK_BYTE_PTR pOperationState, CK_ULONG ulOperationStateLen, CK_OBJECT_HANDLE hEncryptionKey, CK_OBJECT_HANDLE hAuthenticationKey);/*C_SetOperationState*/	
		BOOL bGetOperationState(CK_BYTE_PTR pOperationState, CK_ULONG_PTR pulOperationStateLen);/*C_GetOperationState*/
		BOOL bClose            ();	/*C_CloseSession*/		
		BOOL bCloseAll         (CK_SLOT_ID slotID);	/*C_CloseAllSessions*/		
		
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXSessionH
