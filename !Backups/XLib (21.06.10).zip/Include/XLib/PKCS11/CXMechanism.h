/****************************************************************************
* Class name:  CXMechanism
* Description: PKCS11 ��������
* File name:   CXMechanism.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:09:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXMechanismH
#define XLib_PKCS11_CXMechanismH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
//---------------------------------------------------------------------------
class CXMechanism : public CXNonCopyable {
	public:
		     CXMechanism(const CXPKCS11 &cPKCS11);
	        ~CXMechanism();
	   
	   	BOOL bGetInfo   (CK_SLOT_ID slotID, CK_MECHANISM_TYPE type, CK_MECHANISM_INFO_PTR pInfo);	/*C_GetMechanismInfo*/	
		BOOL bGetList   (CK_SLOT_ID slotID, CK_MECHANISM_TYPE_PTR pMechanismList, CK_ULONG_PTR pulCount);	/*C_GetMechanismList*/	
		
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXMechanismH