/****************************************************************************
* Class name:  CXSign
* Description: PKCS11 �������
* File name:   CXSign.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:12:48
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXSignH
#define XLib_PKCS11_CXSignH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXSign : public CXNonCopyable {
	public:
		     CXSign        (const CXPKCS11 &cPKCS11, const CXSession &cSession);
	        ~CXSign        ();
	   
		BOOL bInit	       (CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);/*C_SignInit*/	
		BOOL bMake	       (CK_BYTE_PTR pData, CK_ULONG ulDataLen, CK_BYTE_PTR pSignature, CK_ULONG_PTR pulSignatureLen);/*C_Sign*/	
		BOOL bUpdate	   (CK_BYTE_PTR pPart, CK_ULONG ulPartLen);/*C_SignUpdate*/
		BOOL bEncryptUpdate(CK_BYTE_PTR pPart, CK_ULONG ulPartLen, CK_BYTE_PTR pEncryptedPart, CK_ULONG_PTR pulEncryptedPartLen);/*C_SignEncryptUpdate*/	
		BOOL bFinal	       (CK_BYTE_PTR pSignature, CK_ULONG_PTR pulSignatureLen);/*C_SignFinal*/			
		BOOL bRecoverInit  (CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);/*C_SignRecoverInit*/
		BOOL bRecover	   (CK_BYTE_PTR pData, CK_ULONG ulDataLen, CK_BYTE_PTR pSignature, CK_ULONG_PTR pulSignatureLen);/*C_SignRecover*/
	
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXSignH
