/****************************************************************************
* Class name:  CxWndLog
* Description: ����������� � ����
* File name:   CxWndLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CxWndLogH
#define XLib_Log_CxWndLogH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Sync/CxCriticalSection.h>
//---------------------------------------------------------------------------
class CxWndLog : public CxNonCopyable {
	public:
		//����� ����
		enum EWindowClass {
		    wcNone,
			wcListBox,          
		};	

								 CxWndLog(EWindowClass wcWC);
								~CxWndLog();
   		BOOL                     bWrite  (HWND hWnd, LPCTSTR pcszFormat, ...);
   		
   	private:	
   		EWindowClass             _m_eWC;
   		static CxCriticalSection _ms_csListBox;  //Mutex
};
//---------------------------------------------------------------------------
#endif