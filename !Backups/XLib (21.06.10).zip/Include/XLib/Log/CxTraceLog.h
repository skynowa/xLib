/****************************************************************************
* Class name:  CxTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CxTraceLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CxTraceLogH
#define XLib_Log_CxTraceLogH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Sync/CxCriticalSection.h>
//---------------------------------------------------------------------------
class CxTraceLog : public CxNonCopyable {
	public:	
			 CxTraceLog(BOOL bIsNeedTimeStr);
			~CxTraceLog();
		BOOL bWrite    (LPCTSTR pcszFormat, ...); 

	private:	
		BOOL _m_bIsNeedTimeStr;		//���� �� �������� �����       	
};
//---------------------------------------------------------------------------
#endif	//XLib_Log_CxTraceLogH