/****************************************************************************
* Class name:  CxWaitCursor
* Description: wait cursor
* File name:   CxWaitCursor.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.06.2009 19:08:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CxWaitCursorH
#define XLib_Gui_CxWaitCursorH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxWaitCursor : public CxNonCopyable {
	public:
		        CxWaitCursor();
	           ~CxWaitCursor();

		BOOL    bRestore    ();
		
	private:
		HCURSOR _m_hCursor;
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CxWaitCursorH