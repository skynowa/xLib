/****************************************************************************
* Class name:  
* Description: 
* File name:   Common.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:09:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CommonH
#define XLib_Gui_CommonH  
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>

///#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include <commctrl.h>
#pragma comment(lib, "comctl32.lib")


//#include <Uxtheme.h>
//#pragma comment(lib, "UxTheme.lib")

#include <richedit.h>

//#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")


#include <XLib/Log/CxTraceLog.h>
#include <XLib/Gui/CxResources.h>


//---------------------------------------------------------------------------
//����� ������� ���������
/*
ANIMATE_CLASS      - Creates animation controls. These controls silently display an audio video interleaved (AVI) clip.
DATETIMEPICK_CLASS - Creates date and time picker controls. These controls provide a simple interface to exchange date and time information with a user. 
HOTKEY_CLASS       - Creates hot key controls. These controls make it easy for the user to define hot keys. 
LINK_CLASS         - Creates syslink controls. These controls are used with links. 
MONTHCAL_CLASS     - Creates month calendar controls. These controls provide a simple way for a user to select a date from a familiar interface. 
NATIVEFNTCTL_CLASS - Creates native font controls. These controls are used with native fonts. 
PROGRESS_CLASS     - Creates progress bars. These controls indicate the progress of a lengthy operation.
REBARCLASSNAME     - Creates rebar controls. These controls act as a container for child windows. 
STANDARD_CLASSES   - Creates intrinsic User32 controls, such as button, edit, and scrollbar.
STATUSCLASSNAME    - Creates status windows. These controls display status information in a horizontal window.
TOOLBARCLASSNAME   - Creates toolbars. These controls contain buttons that carry out menu commands. 
TOOLTIPS_CLASS     - Creates tooltip controls. These controls display a small pop-up window containing a line of text that describes the purpose of a tool in an application.
TRACKBAR_CLASS     - Creates trackbars. These controls let the user select from a range of values by moving a slider. 
UPDOWN_CLASS       - Creates up-down controls. These controls combine a pair of arrows with an edit control. Clicking the arrows increments or decrements the value in the edit control. 
WC_BUTTON          - Creates button controls. These controls enable a user to initiate an action.
WC_COMBOBOX        - Creates combobox controls. These controls contain a drop-down list from which a single item can be selected. 
WC_COMBOBOXEX      - Creates ComboBoxEx controls. These controls provide an extension of the combo box control that provides native support for item images. 
WC_EDIT            - Creates edit controls. These controls contain editable text. 
WC_HEADER		   - Creates header controls. These controls display headings at the top of columns of information and let the user sort the information by clicking the headings. 
WC_LISTBOX         - Creates listbox controls. These controls contain lists of items. 
WC_IPADDRESS       - Creates IP address controls. These controls are similar to an edit control, but they enable you to enter a numeric address in Internet protocol (IP) format. 
WC_LINK            - Creates SysLink controls. These controls contain hypertext links.
WC_LISTVIEW        - Creates list-view controls. These controls display a collection of items, each consisting of an icon and a label, and provide several ways to arrange the items.
WC_NATIVEFONTCTL   - Creates native font controls. These are invisible controls that work in the background to enable a dialog box's predefined controls to display the current system language.
WC_PAGESCROLLER    - Creates pager controls. These controls are used to contain and scroll another window. 
WC_SCROLLBAR       - Creates scrollbar controls. These controls enable the user to scroll the contents of a window.
WC_STATIC		   - Creates static controls. These controls contain noneditable text. 
WC_TABCONTROL	   - Creates tab controls. These controls define multiple pages for the same area of a window or dialog box. Each page consists of a set of information or a group of controls that an application displays when the user selects the corresponding tab.
WC_TREEVIEW		   - Creates tree-view controls. These controls display a hierarchical list of items. Each item consists of a label and an optional bitmap.
*/
#define xCxWindow_CONTROL_CLASS                 xT("WC_XWINDOW")
#define xCxLayout_CONTROL_CLASS                 xT("WC_XLAYOUT")

#define xCxButton_CONTROL_CLASS                 WC_BUTTON
#define xCxPushButton_CONTROL_CLASS             WC_BUTTON
#define xCXIMAGEBUTTON_CONTROL_CLASS            WC_BUTTON
#define xCxCheckBox_CONTROL_CLASS               WC_BUTTON
#define xCxRadioButton_CONTROL_CLASS            WC_BUTTON
#define xCxGroupBox_CONTROL_CLASS               WC_BUTTON
#define xCxOwnerDrawButton_CONTROL_CLASS        WC_BUTTON

#define xCxComboBox_CONTROL_CLASS               WC_COMBOBOX
#define xCxEdit_CONTROL_CLASS                   WC_EDIT
#define xCXMDICLIENT_CONTROL_CLASS              xT("MDICLIENT")
#define xCXSCROLLBAR_CONTROL_CLASS              xT("SCROLLBAR")     
#define xCxStatic_CONTROL_CLASS                 WC_STATIC
#define xCxPicture_CONTROL_CLASS                WC_STATIC
#define xCxListBox_CONTROL_CLASS                WC_LISTBOX
#define xCxStatusBar_CONTROL_CLASS              STATUSCLASSNAME
#define xCxProgressBar_CONTROL_CLASS            PROGRESS_CLASS
#define xCxListView_CONTROL_CLASS               WC_LISTVIEW
#define xCxRichEdit10_CONTROL_CLASS             xT("RichEdit") 
#define xCxRichEdit20_CONTROL_CLASS             RICHEDIT_CLASS          
#define xCxTab_CONTROL_CLASS                    WC_TABCONTROL          
//---------------------------------------------------------------------------
//��������� ������� ����� ���������
#define xCXFRAME_DEFAULT_WINDOW_STYLE           WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX
#define xCXFRAME_DEFAULT_WINDOW_STYLE_EX        0

#define xCxLayout_DEFAULT_WINDOW_STYLE			WS_CHILD | WS_TABSTOP | WS_CAPTION
#define xCxLayout_DEFAULT_WINDOW_STYLE_EX		WS_EX_CONTROLPARENT



#define xCxButton_DEFAULT_WINDOW_STYLE          WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_TEXT /*| BS_NOTIFY*/
#define xCxButton_DEFAULT_WINDOW_STYLE_EX       0

#define xCxPushButton_DEFAULT_WINDOW_STYLE      WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX | BS_TEXT | BS_PUSHLIKE /*| BS_NOTIFY*/
#define xCxPushButton_DEFAULT_WINDOW_STYLE_EX   0

#define xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE     WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON /*| BS_NOTIFY*/
#define xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE_EX  0

#define xCxCheckBox_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX /*| BS_NOTIFY*/
#define xCxCheckBox_DEFAULT_WINDOW_STYLE_EX     0

#define xCxRadioButton_DEFAULT_WINDOW_STYLE     WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTORADIOBUTTON /*| BS_NOTIFY*/
#define xCxRadioButton_DEFAULT_WINDOW_STYLE_EX  0

#define xCxGroupBox_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_GROUPBOX /*| BS_NOTIFY*/
#define xCxGroupBox_DEFAULT_WINDOW_STYLE_EX     0

#define xCxOwnerDrawButton_DEFAULT_WINDOW_STYLE WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW /*| BS_NOTIFY*/
#define xCxOwnerDrawButton_DEFAULT_WINDOW_STYLE_EX 0




#define xCxComboBox_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | CBS_DROPDOWN | CBS_SORT | WS_VSCROLL 	/*WS_CHILD | WS_VISIBLE | WS_TABSTOP*/
#define xCxComboBox_DEFAULT_WINDOW_STYLE_EX     0

#define xCxEdit_DEFAULT_WINDOW_STYLE            WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL
#define xCxEdit_DEFAULT_WINDOW_STYLE_EX         WS_EX_CLIENTEDGE

#define xCXMDICLIENT_DEFAULT_WINDOW_STYLE       0	//TODO:
#define xCXMDICLIENT_DEFAULT_WINDOW_STYLE_EX    0

#define xCXSCROLLBAR_DEFAULT_WINDOW_STYLE       0	//TODO:
#define xCXSCROLLBAR_DEFAULT_WINDOW_STYLE_EX    0

#define xCxStatic_DEFAULT_WINDOW_STYLE          WS_CHILD | WS_VISIBLE | WS_TABSTOP | SS_SIMPLE | SS_NOTIFY
#define xCxStatic_DEFAULT_WINDOW_STYLE_EX       0

#define xCxPicture_DEFAULT_WINDOW_STYLE         WS_CHILD | WS_VISIBLE | WS_TABSTOP | SS_BITMAP | SS_NOTIFY
#define xCxPicture_DEFAULT_WINDOW_STYLE_EX      0



#define xCxListBox_DEFAULT_WINDOW_STYLE         WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | LBS_HASSTRINGS | LBS_NOINTEGRALHEIGHT
#define xCxListBox_DEFAULT_WINDOW_STYLE_EX      WS_EX_CLIENTEDGE

#define xCxStatusBar_DEFAULT_WINDOW_STYLE       WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS | CCS_BOTTOM
#define xCxStatusBar_DEFAULT_WINDOW_STYLE_EX    0

#define xCxProgressBar_DEFAULT_WINDOW_STYLE     WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER
#define xCxProgressBar_DEFAULT_WINDOW_STYLE_EX  0

#define xCxListView_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP /*| LVS_REPORT*/
#define xCxListView_DEFAULT_WINDOW_STYLE_EX     0

#define xCxRichEdit_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP
#define xCxRichEdit_DEFAULT_WINDOW_STYLE_EX     0

#define xCxTab_DEFAULT_WINDOW_STYLE			   WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS | TCS_FOCUSNEVER | TCS_SINGLELINE//WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS
#define xCxTab_DEFAULT_WINDOW_STYLE_EX          0
//---------------------------------------------------------------------------
//��������� ������� ��������� (������, ������)
#define xCXFRAME_DEFAULT_WIDTH                  CW_USEDEFAULT
#define xCXFRAME_DEFAULT_HEIGHT                 CW_USEDEFAULT

#define xCxLayout_DEFAULT_WIDTH                 CW_USEDEFAULT
#define xCxLayout_DEFAULT_HEIGHT                CW_USEDEFAULT


#define xCxButton_DEFAULT_WIDTH                 75
#define xCxButton_DEFAULT_HEIGHT                25

#define xCxPushButton_DEFAULT_WIDTH             75
#define xCxPushButton_DEFAULT_HEIGHT            25

#define xCXIMAGEBUTTON_DEFAULT_WIDTH            30
#define xCXIMAGEBUTTON_DEFAULT_HEIGHT           25

#define xCxCheckBox_DEFAULT_WIDTH               200
#define xCxCheckBox_DEFAULT_HEIGHT              17

#define xCxRadioButton_DEFAULT_WIDTH            120
#define xCxRadioButton_DEFAULT_HEIGHT           17

#define xCxGroupBox_DEFAULT_WIDTH               200
#define xCxGroupBox_DEFAULT_HEIGHT              200

#define xCxOwnerDrawButton_DEFAULT_WIDTH        25
#define xCxOwnerDrawButton_DEFAULT_HEIGHT       75


#define xCxComboBox_DEFAULT_WIDTH               120
#define xCxComboBox_DEFAULT_HEIGHT              21 * 20

#define xCxEdit_DEFAULT_WIDTH                   120
#define xCxEdit_DEFAULT_HEIGHT                  21

#define xCXMDICLIENT_DEFAULT_WIDTH              CW_USEDEFAULT
#define xCXMDICLIENT_DEFAULT_HEIGHT             CW_USEDEFAULT

#define xCXSCROLLBAR_DEFAULT_WIDTH              0
#define xCXSCROLLBAR_DEFAULT_HEIGHT             0

#define xCxStatic_DEFAULT_WIDTH                 120
#define xCxStatic_DEFAULT_HEIGHT                13

#define xCxPicture_DEFAULT_WIDTH                120
#define xCxPicture_DEFAULT_HEIGHT               120





#define xCxListBox_DEFAULT_WIDTH                100
#define xCxListBox_DEFAULT_HEIGHT               120

#define xCxStatusBar_DEFAULT_WIDTH              0
#define xCxStatusBar_DEFAULT_HEIGHT             0

#define xCxProgressBar_DEFAULT_WIDTH            120
#define xCxProgressBar_DEFAULT_HEIGHT           23

#define xCxListView_DEFAULT_WIDTH               200
#define xCxListView_DEFAULT_HEIGHT              200

#define xCxRichEdit_DEFAULT_WIDTH               120
#define xCxRichEdit_DEFAULT_HEIGHT              120

#define xCxTab_DEFAULT_WIDTH                    650
#define xCxTab_DEFAULT_HEIGHT                   350
//---------------------------------------------------------------------------
#define xSNDMSG(TCastType, uiMsg, wParam, lParam) \
	((TCastType)( pSendMessage((UINT)(uiMsg), (WPARAM)(wParam), (LPARAM)(lParam)) ));

#define xSNDMSG_API(TCastType, hWnd, uiMsg, wParam, lParam) \
	((TCastType)( ::SendMessage((HWND)(hWnd), (UINT)(uiMsg), (WPARAM)(wParam), (LPARAM)(lParam)) ));

#define LOG()                                  _m_tlLog.bWrite(_T(__FUNCTION__))
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CommonH






