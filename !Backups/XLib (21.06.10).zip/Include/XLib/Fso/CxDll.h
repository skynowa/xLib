/****************************************************************************
* Class name:  CxDll
* Description: DLL
* File name:   CxDll.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CxDllH 
#define XLib_Fso_CxDllH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDll : public CxNonCopyable {
	public:
		        CxDll           ();
		       ~CxDll           ();

		BOOL    bIsLoaded       ();
		BOOL    bLoad           (LPCTSTR pcszDllPath);
		FARPROC fpGetProcAddress(LPCSTR  pszProcName/*ANSI*/);
		BOOL    bFree           ();

	private:
		HMODULE _m_hDLL;
};
//---------------------------------------------------------------------------
#endif //XLib_Fso_CxDllH