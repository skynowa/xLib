/****************************************************************************
* Class name:  CxFileAttribute
* Description: �������� �����
* File name:   CxFileAttribute.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.04.2010 13:37:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxFileAttributeH
#define CxFileAttributeH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxFileAttribute : public CxNonCopyable {
	public:
		//-------------------------------------
		//�������� ������
		typedef ULONG TAttribute;

		static const TAttribute faInvalid           = INVALID_FILE_ATTRIBUTES;
		static const TAttribute faReadOnly          = FILE_ATTRIBUTE_READONLY;  
		static const TAttribute faHidden            = FILE_ATTRIBUTE_HIDDEN; 
		static const TAttribute faSystem            = FILE_ATTRIBUTE_SYSTEM;  
		static const TAttribute faDirectory         = FILE_ATTRIBUTE_DIRECTORY;
		static const TAttribute faArchive           = FILE_ATTRIBUTE_ARCHIVE;
		static const TAttribute faDevice            = FILE_ATTRIBUTE_DEVICE;  
		static const TAttribute faNormal            = FILE_ATTRIBUTE_NORMAL;  
		static const TAttribute faTemporary         = FILE_ATTRIBUTE_TEMPORARY;  
		static const TAttribute faSparseFile        = FILE_ATTRIBUTE_SPARSE_FILE;  
		static const TAttribute faReparsePoint      = FILE_ATTRIBUTE_REPARSE_POINT;  
		static const TAttribute faCompressed        = FILE_ATTRIBUTE_COMPRESSED;  
		static const TAttribute faOffline           = FILE_ATTRIBUTE_OFFLINE;  
		static const TAttribute faNotContentIndexed = FILE_ATTRIBUTE_NOT_CONTENT_INDEXED;
		static const TAttribute faEncrypted         = FILE_ATTRIBUTE_ENCRYPTED; 


		static TAttribute atGet    (const tString &csFilePath);
		static BOOL       bSet     (const tString &csFilePath, TAttribute atValue);
		static BOOL       bAdd     (const tString &csFilePath, TAttribute atValue);
		static BOOL       bRemove  (const tString &csFilePath, TAttribute atValue);
		static BOOL       bModify  (const tString &csFilePath, TAttribute atRemoveValue, TAttribute atAddValue);
		static BOOL       bIsExists(const tString &csFilePath, TAttribute atValue);

	 
	private:
		                  CxFileAttribute();
		virtual          ~CxFileAttribute();		
};
//---------------------------------------------------------------------------
#endif //CxFileAttributeH