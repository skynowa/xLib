/****************************************************************************
* Class name:  CxDir
* Description: �������� � �������
* File name:   CxDir.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CxDirH
#define XLib_Fso_CxDirH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDir : public CxNonCopyable {
	public:
		static BOOL    bIsExists   (const tString &csDirPath);
		static BOOL    bIsEmpty    (const tString &csDirPath, const tString &csMask); 
		//static BOOL  bIsRoot     ();
		static tString sGetCurrent ();  
		static BOOL    bSetCurrent (const tString &csDirPath); 
		static tString sGetTempPath(); 
		static BOOL    bCreate     (const tString &csDirPath); 
		static BOOL    bCreateForce(const tString &csDirPath); 
		static BOOL    bCopy       (const tString &csDirPathFrom, const tString &cscsDirPathTo, BOOL bFailIfExists); 
		static BOOL    bMove       (const tString &csDirPathIn,   const tString &csDirPathOut);  

		static BOOL    bDelete     (const tString &csDirPath); 
		static BOOL    bClearForce (const tString &csDirPath); 
		static BOOL    bDeleteForce(const tString &csDirPath); 
		static BOOL    bListFiles  (const tString &csDirPath, const tString &csMask, std::vector<tString> *pvecsFiles); 
		static BOOL    bListDirs   (const tString &csDirPath, std::vector<tString> *pvecsDirs);

	private:
			           CxDir       ();
					  ~CxDir       ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CxDirH
