/****************************************************************************
*    �����: CxCrc32 (CxCrc32.h)
*
*****************************************************************************/



#ifndef XLib_Crypt_CxCrc32H
#define XLib_Crypt_CxCrc32H
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxCrc32 : public CxNonCopyable {
	public:
			  CxCrc32       ();
			 ~CxCrc32       ();

		ULONG ulCalc        (UCHAR *pucBuff, ULONG ulSize);
		ULONG ulCalcFile    (const std::string &csFilePath);
		
		ULONG ulCalcFast    (UCHAR *pucBuff, ULONG ulSize);
		ULONG ulCalcFileFast(const std::string &csFilePath);

	private:
		ULONG ulFileSize    (FILE *pFile);
};
//---------------------------------------------------------------------------
#endif	//XLib_Crypt_CxCrc32H
