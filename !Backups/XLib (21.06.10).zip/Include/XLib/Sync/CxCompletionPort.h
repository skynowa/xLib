/****************************************************************************
* Class name:  CCompletionPort
* Description: ���� ����������
* File name:   CCompletionPort.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.02.2010 14:28:40
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CxCOMpletionPortH
#define XLib_Sync_CxCOMpletionPortH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/CxHandleT.h>
//---------------------------------------------------------------------------
class CxCOMpletionPort : public CxNonCopyable  {
	public:
		explicit        CxCOMpletionPort();
	                   ~CxCOMpletionPort();

		BOOL            bCreate         (HANDLE hFileHandle, HANDLE hExistingCompletionPort, ULONG_PTR pulCompletionKey, ULONG ulNumberOfConcurrentThreads);
		BOOL            bGetStatus      (LPDWORD lpNumberOfBytes, PULONG_PTR lpCompletionKey, LPOVERLAPPED *lpOverlapped, ULONG ulMilliseconds);
		BOOL            bPostStatus     (ULONG ulNumberOfBytesTransferred, ULONG_PTR ulCompletionKey, LPOVERLAPPED lpOverlapped);

	private:
		CxHandleT<NULL> _m_hCompletionPort; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CxCOMpletionPortH