/****************************************************************************
* Class name:  CxTest
* Description: ������������
* File name:   CxTest.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 9:29:52
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CxTestH
#define XLib_CxTestH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Fso/CxEnvironment.h>
//---------------------------------------------------------------------------
class CxTest : public CxNonCopyable {
	public:
					BOOL                       m_bRes;
					INT                        m_iRes;
					UINT                       m_uiRes;
					ULONG                      m_ulRes;
					ULONGLONG                  m_ullRes;
					DOUBLE                     m_dRes;
					HANDLE                     m_hRes;
					HWND                       m_hwndRes;
					tString                    m_sRes;
					std::vector<tString>       m_vecsRes; 
					std::map<tString, tString> m_mapsRes;

		            CxTest        ();
	   virtual     ~CxTest        ();

	   BOOL         bRun          (ULONG ulLoops /*0 - infinite*/);
	   virtual BOOL bUnit         () = 0;
	   tString      sGetWorkDir   ();
	   BOOL         bSetWorkDir   (const tString &csDirPath = xT(""));
	
	private:
		BOOL        _m_bRes;
		tString     _m_sWorkDir;
};
//---------------------------------------------------------------------------
#endif //XLib_CxTestH
