/****************************************************************************
* Class name:  CXTodo
* Description: TODO ����� Error List
* File name:   CXTodo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.12.2009 16:19:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Debug_CXTodoH
#define XLib_Debug_CXTodoH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXTodo : public CXNonCopyable {
	public:
	
	private:
		CXTodo();
	   ~CXTodo();
};
//---------------------------------------------------------------------------
#define STRINGIZE2(x) #x
#define STRINGIZE(x)  STRINGIZE2(x)
#define TODO(text_)   message(__FILE__ "(" STRINGIZE(__LINE__) ") [" __FUNCTION__ "]: warning TODO: [" __FUNCTION__ "] " ## text_)
#define TODO_IMPL     TODO("Implement " __FUNCTION__ " function!")
//---------------------------------------------------------------------------
#endif	//XLib_Debug_CXTodoH