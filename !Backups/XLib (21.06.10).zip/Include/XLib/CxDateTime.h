/****************************************************************************
* Class name:  CxDateTime
* Description: ������ � ������
* File name:   CxDateTime.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CxDateTimeH
#define XLib_CxDateTimeH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDateTime /*: public CxNonCopyable*/ {
	public:
				           CxDateTime        (); 
				           CxDateTime        (ULONGLONG ullDateTime); 
						   CxDateTime        (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMilliseconds); 
				          ~CxDateTime        (); 
				          
	    CxDateTime         dtNow             (); 
		
		//��������������
		tString			   sFormatDateTimeStr(); 
		tString            sFormatDateStr    (); 
		tString            sFormatTimeStr    (); 

		static BOOL        bMSecToDateTime   (ULONGLONG ullMilliSec, SYSTEMTIME *stST); 
		static ULONGLONG   ullDateTimeToMSec (const SYSTEMTIME &stST); 

		//���������
		CxDateTime        &operator =        (CxDateTime dtDT);
		CxDateTime         operator +        (CxDateTime dtDT);
		CxDateTime         operator -        (CxDateTime dtDT);
		//++
		//--
		//+=
		//-=
		//
		
		//������
		static tString     sGetZodiacSign    (INT iMonth, INT iDay);
		static tString     sGetMonthStr      (INT iMonth, BOOL bIsShortName);
		static tString     sGetWeekDayStr    (INT iDay,   BOOL bIsShortName);
		//�������� ������������ DTYMSMs

   	private:
   		SYSTEMTIME         _m_stDateTime;
		ULONGLONG          _m_ullDateTime;
};
//---------------------------------------------------------------------------
#endif	//XLib_CxDateTimeH

/*
typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/





//GetTimeFormatEx
//GetDateFormat