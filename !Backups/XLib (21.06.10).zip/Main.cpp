/****************************************************************************
* Lib name:    XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/Common.h>


//Debug
#include <XLib/Debug/CXAssert.h>
#include <XLib/Debug/CXPerform.h>
#include <XLib/Debug/CXTodo.h>

//CXSync
#include <XLib/Sync/CXCompletionPort.h>
#include <XLib/Sync/CXCriticalSection.h>
#include <XLib/Sync/CXAutoCriticalSection.h>
#include <XLib/Sync/CXEvent.h>
#include <XLib/Sync/CXMutex.h>
#include <XLib/Sync/CXAutoMutex.h>
#include <XLib/Sync/CXSemaphore.h>
#include <XLib/Sync/CXSleeper.h>
#include <XLib/Sync/CXThread.h>
#include <XLib/Sync/CXThreadPool.h>
#include <XLib/Sync/CXTls.h>
#include <XLib/Sync/CXWaitableTimer.h>
#include <XLib/Sync/CXAtomicLongInt.h>


//CXFso
#include <XLib/Fso/CXDir.h>
#include <XLib/Fso/CXDll.h>
#include <XLib/Fso/CXDrive.h>
#include <XLib/Fso/CXFile.h>
#include <XLib/Fso/CXIni.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXStdioFile.h>
#include <XLib/Fso/CXEnvironment.h>
#include <XLib/Fso/CXFileAttribute.h>

//CXLog
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXDbLog.h>
#include <XLib/Log/CXEventLog.h>
#include <XLib/Log/CXFileLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <XLib/Log/CXWndLog.h>

//Random
#include <XLib/Random/CXRandom.h>

//PKCS11
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXDecrypt.h>
#include <XLib/PKCS11/CXDigest.h>
#include <XLib/PKCS11/CXEncrypt.h>
#include <XLib/PKCS11/CXeTokenInfo.h>
#include <XLib/PKCS11/CXFunction.h>
#include <XLib/PKCS11/CXInfo.h>
#include <XLib/PKCS11/CXKey.h>
#include <XLib/PKCS11/CXLogin.h>
#include <XLib/PKCS11/CXMechanism.h>
#include <XLib/PKCS11/CXObject.h>
#include <XLib/PKCS11/CXPin.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
#include <XLib/PKCS11/CXSign.h>
#include <XLib/PKCS11/CXSlot.h>
#include <XLib/PKCS11/CXUtils.h>
#include <XLib/PKCS11/CXVerify.h>
#include <XLib/PKCS11/All.h>


//Gui
////#include <XLib/Gui/Common.h>
////#include <XLib/Gui/CXFont.h>
////#include <XLib/Gui/CXApplication.h>
////#include <XLib/Gui/CXWindow.h>
////#include <XLib/Gui/XMessageMap.h>
////#include <XLib/Gui/CXWindowImpl.h>
////#include <XLib/Gui/CXButton.h>
////#include <XLib/Gui/CXCheckBox.h>
////#include <XLib/Gui/CXComboBox.h>
////#include <XLib/Gui/CXDialog.h>
////#include <XLib/Gui/CXEdit.h>
////#include <XLib/Gui/CXGroupBox.h>
////#include <XLib/Gui/CXImageList.h>
////#include <XLib/Gui/CXLayout.h>
////#include <XLib/Gui/CXListBox.h>
////#include <XLib/Gui/CXListView.h>
////#include <XLib/Gui/CXMsgBoxRtf.h>
////#include <XLib/Gui/CXMsgBoxT.h>
////#include <XLib/Gui/CXProgressBar.h>
////#include <XLib/Gui/CXRadioButton.h>
////#include <XLib/Gui/CXRebar.h>
////#include <XLib/Gui/CXResources.h>
////#include <XLib/Gui/CXRichEdit.h>
////#include <XLib/Gui/CXStatic.h>
////#include <XLib/Gui/CXStatusBar.h>
////#include <XLib/Gui/CXTab.h>
////#include <XLib/Gui/CXToolBar.h>
////#include <XLib/Gui/CXWaitCursor.h>
////////#include <XLib/Gui/Resource.xrc.h>
////////#include <XLib/Gui/Resource.xrc.cpp>




//CXNet
//////#include <XLib/CXNet/CQueryList.hpp>
//////#include <XLib/CXNet/CSMTPConn.h>
//#include <XLib/Net/CXMimeHeader.h>
//#include <XLib/Net/CXPop3.h>
//#include <XLib/Net/CXSmtp.h>
//#include <XLib/Net/CXTcpClientSocket.h>
//#include <XLib/Net/CXTcpServerSocket.h>

//Other



////#include <shellapi.h>
//---------------------------------------------------------------------------
int main(int argc /*, char* argv[]*/) {




	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------