/****************************************************************************
* Class name:  CxThread
* Description: �����
* File name:   CxThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CxThread.h>

#include <XLib/CxSystemInfo.h>
#include <XLib/CxString.h>

#if defined(_MT) || defined(_DLL)
#	include <process.h>
#endif // _MT


/****************************************************************************
*	[public]
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxThread (�����������)
CxThread::CxThread(BOOL bIsPaused, BOOL bIsAutoDelete, BOOL bIsUsingCOM) :
	m_ulTag                 (0),
	
	//���������
	_m_culStillActiveTimeout(2),	
	_m_culExitTimeout       (5000),   

	//������ ������
	_m_ulID					(0),
	_m_uiExitCode			(0),
	_m_pvParam				(NULL),
	_m_ptfStartAddress		(0),
	_m_cbIsAutoDelete		(bIsAutoDelete),

	//��������� �������
	_m_bIsCreated			(FALSE),
	_m_bIsRunning			(FALSE),
	_m_bIsPaused			(bIsPaused/*TRUE == bIsPaused ? CREATE_SUSPENDED : 0*/),
	////-TEST- _m_bIsSleeping			(FALSE),
#ifdef defVarPolicy
	_m_bIsExited			(FALSE),
#else 
	//...
#endif

	//
	///_vOnExit                (NULL),

	//���������     
	_m_clLog                (FALSE),
	_m_pevStarter			(NULL),
	_m_cbIsUsingCOM         (bIsUsingCOM),
	_m_pcomCOM              (NULL)
{
	////this->hMainThread	= ::GetCurrentThread();
	////this->hMainThreadId = ::GetCurrentThreadId();   
}
//---------------------------------------------------------------------------
//TODO: + ~CxThread (����������)
/*virtual*/ CxThread::~CxThread() {
	/*DEBUG*/

	BOOL bRes = FALSE;

    //-------------------------------------
	//��������� �����, ���� �� �������� - ??? typa na vsykiy sluchay???
	bRes = bIsRunning();
	if (TRUE == bRes) {
		bRes = bExit(_m_culExitTimeout);   
		if (FALSE == bRes) {
            bRes = bKill(_m_culExitTimeout);
		}
	}

	//-------------------------------------
	//��������� �������
	_vSetDefaultStates();
}
//---------------------------------------------------------------------------

/****************************************************************************
*	��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bCreate (������ ������)
BOOL CxThread::bCreate(UINT uiStackSize, const pThreadProc ptfStartAddress, VOID *pvParam) {
	/*DEBUG*/xASSERT_RET(FALSE == _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///uiStackSize  - not need
	/*DEBUG*///ptfStartAddr - not need
	/*DEBUG*///pvParam      - not need

	BOOL   bRes = FALSE;
	HANDLE hRes = NULL;

	_m_ptfStartAddress = ptfStartAddress;
	_m_pvParam         = pvParam; 

	//-------------------------------------
	//_m_evStarter
	_m_pevStarter = new CxEvent();
	/*DEBUG*/xASSERT_RET(NULL != _m_pevStarter, FALSE);

	bRes = _m_pevStarter->bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

#ifdef _MT              
	hRes = reinterpret_cast<HANDLE>(_beginthreadex(NULL, uiStackSize, _s_uiStartFunc, this, 0, xreinterpret_cast<UINT *>(&_m_ulID)));
#else
	hRes = ::CreateThread(NULL, uiStackSize, xreinterpret_cast<LPTHREAD_START_ROUTINE>(_s_uiStartFunc), this, 0, &_m_ulID);
#endif 

	//-------------------------------------
	//WatchDog
	/*WatchDog*/ULONG ulLastError = ::GetLastError();
	/*WatchDog*/if (8 == ulLastError) {
	/*WatchDog*/	::MessageBox(0, _T(" 8 - \"������������ ������ ��� ��������� �������.\""), _T("WatchDog"), MB_OK);
	/*WatchDog*/	return FALSE;
	/*WatchDog*/}

	/*DEBUG*/xASSERT_RET(NULL != hRes,    FALSE);
	/*DEBUG*/xASSERT_RET(0    <  _m_ulID, FALSE);

	_m_hThread/*.m_hHandle*/ = hRes;
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);    


	//-------------------------------------
	//_m_evPause
	//--bRes = _m_evPause.bCreate(NULL, FALSE, FALSE, NULL);
	bRes = _m_evPause.bCreate(NULL, TRUE/*-FALSE*/, TRUE/*FALSE*/, NULL);      //_m_bIsPaused
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = _m_evExit.bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	_m_bIsCreated = TRUE;
	_m_bIsRunning = TRUE;
	/*_m_bIsPaused*/
	if (TRUE == _m_bIsPaused) {	//+++++++++++++++++++++++++++++++++++++++++++++
		//��������� ����� ����� - "�����"  
		bRes = _m_evPause.bSet();	 
		/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	}

	/*_m_bIsSleeping*/
	/*_m_bIsExited*/	

	//-------------------------------------
	//������� ����� ����� �������������
	bRes = _m_pevStarter->bSet();  
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bResume (�������������)
BOOL CxThread::bResume() {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);    

	BOOL bRes = FALSE;

	bRes = _m_evPause.bSet();  
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- _m_bIsPaused = FALSE;
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPause (�����)
BOOL CxThread::bPause() {
	/*DEBUG*/xASSERT_MSG_RET(FALSE != _m_hThread.bIsValid(), CxString::lexical_cast(_m_hThread.m_hHandle).c_str(), FALSE); 

	BOOL bRes = FALSE;

	//TODO: ����� ������ ���������� ++++++++++++++++++
	bRes = _m_evPause.bReset();	 
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);





	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- _m_bIsPaused = TRUE;
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExit (����� �� ������ - ��������� ����� ������ �� ������)
BOOL CxThread::bExit(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - not need

	BOOL bRes = FALSE;
	
	//-------------------------------------
	//��������� �������
#ifdef defVarPolicy
	_m_bIsExited = TRUE;
#else 
	_m_evExit.bSet();					
#endif
	/*_m_bIsCreated*/	
	/*_m_bIsRunning*/
	/*_m_bIsPaused*/	xCHECK_DO(TRUE == bIsPaused(),   bResume());			//���� ����� ���������������� (bPause) - ������������
	/*_m_bIsSleeping*/	xCHECK_DO(TRUE == bIsSleeping(), bSleeperWakeUp());	//���� ����� ����             (bSleep) - �����
																			//���� ������� ����-�� 
	//-- ���� ���� ���� --
	////bRes = bWait(ulTimeout);
	/////*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bKill (����������� ������)
BOOL CxThread::bKill(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);        
	/*DEBUG*///ulTimeout - not need

	ULONG ulRes = 0;
	BOOL  bRes  = FALSE;

	_m_uiExitCode = 0;
	bRes = ::TerminateThread(_m_hThread.m_hHandle, _m_uiExitCode);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	for (;;) {
		ulRes = ulGetExitCode();
		xCHECK_DO(STILL_ACTIVE != ulRes, break);            

		bRes = bSleep(_m_culStillActiveTimeout);
		/*DEBUG*/xASSERT_DO(FALSE != bRes, break);
	}

	//-- ���� ���� ���� --
	////bRes = bWait(ulTimeout); //TODO: - 
	/////*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	_m_uiExitCode = ulRes;

	//-------------------------------------
	//������ ��������
	////CLOSE_HANDLE(_m_hThread);
	_m_ulID            = 0;
	//_m_uiExitCode    = 0;	//???
	_m_ptfStartAddress = 0;
	_m_pvParam         = NULL;
	//_m_bIsAutoDelete - not need 

	//-------------------------------------
	//��������� �������
	_vSetDefaultStates();

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait (�������� ������)
BOOL CxThread::bWait(ULONG ulTimeout) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - not need

	//-------------------------------------
	//��������� �������
	//?????????

	xASSERT(CxThread::ulGetCurrId() != _m_ulID);		//TODO: ?????
	xCHECK_RET(CxThread::ulGetCurrId() == _m_ulID, TRUE);		//TODO: ?????

	ULONG ulRes = WAIT_FAILED;
	ulRes = ::WaitForSingleObject(_m_hThread.m_hHandle, ulTimeout); 
	/*DEBUG*/xASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	����� ��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsCreated (������ �� �����)
BOOL CxThread::bIsCreated() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	return _m_bIsCreated;
}
//---------------------------------------------------------------------------
//TODO: + bIsRunning (�������� ���������� ������)
BOOL CxThread::bIsRunning() const {
	/*DEBUG*///_m_hThread - not need

	BOOL bRes = FALSE;
	
	/*
	return  ( FALSE         != _m_hThread.bIsValid()             ) && 
			( 0L            <  _m_ulID                              ) &&
			( TRUE          == _m_bIsRunning                        ) &&
			( WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread.m_hHandle, 0) ) && 
			( STILL_ACTIVE  == ulGetExitCode()                      ); 
	*/

	BOOL bCond1 = ( FALSE         != _m_hThread.bIsValid()                );		
	BOOL bCond2 = ( 0L            <  _m_ulID                              );
	BOOL bCond3 = ( TRUE          == _m_bIsRunning                        );
	/*BOOL bCond4 = ( WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread.m_hHandle, 0) );*/ 
	/*BOOL bCond5 = ( STILL_ACTIVE  == ulGetExitCode()                      );*/

	bRes = bCond1 && bCond2 && bCond3 /*&& bCond4 && bCond5*/;

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + bIsPaused (������������� �� �����)
BOOL CxThread::bIsPaused() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	///TODO: + ������ ���������� - �����
	///--return _m_bIsPaused;	

	return !_m_evPause.bIsSignaled();
}
//---------------------------------------------------------------------------
//TODO: + bIsSleeping (���� �� �����)
//TODO: - bIsSleeping_DEPR (���� �� �����)
BOOL CxThread::bIsSleeping() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	//TODO: - ������ ���������� - �����
	//--return _m_bIsSleeping;	

	return _m_slSleeper.bIsSleeping();
}
//---------------------------------------------------------------------------
//TODO: + bIsExited (��������� �� ���� ������ ��� ������)
BOOL CxThread::bIsExited() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), TRUE);

#ifdef defVarPolicy
	return _m_bIsExited;
#else 
	return _m_evExit.bIsSignaled();
#endif
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bPostMessage (������� ��������� �� ������ � ����)
BOOL CxThread::bPostMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);		
	/*DEBUG*/xASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSendMessage (������� ��������� �� ������ � ����)
BOOL CxThread::bSendMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	::SendMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*///- not need 
	/*DEBUG*/xASSERT(0 == ::GetLastError());

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPostThreadMessage (������� ��������� � �����)
BOOL CxThread::bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostThreadMessage(ulGetId(), uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue (�������� ��������� c ����������� �� ������� ������)
BOOL CxThread::bMessageWaitQueue(UINT uiMsg, INT *piParam1, INT *piParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/xASSERT_RET(0    <  uiMsg,                  FALSE);

	BOOL bRes   = - 1;
	MSG  msgMsg = {0};

	while (bRes = ::GetMessage(&msgMsg, NULL, 0, 0 )) {
		if (- 1 == bRes) {
			/*DEBUG*/xASSERT_RET(FALSE, FALSE);
			break;
		}

		if (uiMsg == msgMsg.message) {
			if (NULL != piParam1) {
				*piParam1 = static_cast<INT>(msgMsg.lParam);
			}

			if (NULL != piParam2) {
				*piParam2 = static_cast<INT>(msgMsg.wParam);
			}

			break;
		}

		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetPriority (��������� ���������� ������)
BOOL CxThread::bSetPriority(EPriority tpPriority) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriority(_m_hThread.m_hHandle, tpPriority);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iGetPriority (��������� ���������� ������)
CxThread::EPriority CxThread::tpGetPriority() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), xPRIORITY_ERROR); 

	CxThread::EPriority tpRes = xPRIORITY_ERROR;

	tpRes = static_cast<EPriority>(::GetThreadPriority(_m_hThread.m_hHandle));
	/*DEBUG*/xASSERT_RET(xPRIORITY_ERROR != tpRes, xPRIORITY_ERROR);

	return tpRes;
}
//---------------------------------------------------------------------------
//TODO: + sGetPriorityString (��������� ���������� ������ ��� ������)
tString CxThread::sGetPriorityString() const {
	/*DEBUG*///not need

	switch ( tpGetPriority() ) {
		case xPRIORITY_ABOVE_NORMAL:	return _T("Above normal");
		case xPRIORITY_BELOW_NORMAL:	return _T("Below normal");
		case xPRIORITY_HIGHEST:			return _T("Highest");
		case xPRIORITY_IDLE:			return _T("Idle");
		case xPRIORITY_LOWEST:			return _T("Lowest");
		case xPRIORITY_NORMAL:			return _T("Normal");
		case xPRIORITY_TIME_CRITICAL:	return _T("Time critical");
	}

	return _T("N/A");
}
//---------------------------------------------------------------------------
//TODO: + bPriorityUp (��������� ���������� �� ���� �������)
BOOL CxThread::bPriorityUp() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = xPRIORITY_ERROR;
	EPriority tpiNewLevel = xPRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case xPRIORITY_TIME_CRITICAL:	return TRUE;							break;
		case xPRIORITY_HIGHEST: 		tpiNewLevel = xPRIORITY_TIME_CRITICAL;	break;
		case xPRIORITY_ABOVE_NORMAL: 	tpiNewLevel = xPRIORITY_HIGHEST;		break;
		case xPRIORITY_NORMAL: 			tpiNewLevel = xPRIORITY_ABOVE_NORMAL;	break;
		case xPRIORITY_BELOW_NORMAL: 	tpiNewLevel = xPRIORITY_NORMAL;			break;
		case xPRIORITY_LOWEST: 			tpiNewLevel = xPRIORITY_BELOW_NORMAL;	break;
		case xPRIORITY_IDLE: 			tpiNewLevel = xPRIORITY_LOWEST;			break;

		default:			/*xASSERT*/xASSERT_RET(FALSE, xPRIORITY_NORMAL);	break;
	}

	return bSetPriority(tpiNewLevel);
} 
//---------------------------------------------------------------------------
//TODO: + bPriorityDown (��������� ���������� �� ���� �������)
BOOL CxThread::bPriorityDown() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = xPRIORITY_ERROR;
	EPriority tpiNewLevel = xPRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case xPRIORITY_TIME_CRITICAL:	tpiNewLevel = xPRIORITY_HIGHEST;		break;
		case xPRIORITY_HIGHEST: 		tpiNewLevel = xPRIORITY_ABOVE_NORMAL;	break;
		case xPRIORITY_ABOVE_NORMAL: 	tpiNewLevel = xPRIORITY_NORMAL;			break;
		case xPRIORITY_NORMAL: 			tpiNewLevel = xPRIORITY_BELOW_NORMAL;	break;
		case xPRIORITY_BELOW_NORMAL: 	tpiNewLevel = xPRIORITY_LOWEST;			break;
		case xPRIORITY_LOWEST: 			tpiNewLevel = xPRIORITY_IDLE;			break;
		case xPRIORITY_IDLE: 			return TRUE;							break;

		default:			/*xASSERT*/xASSERT_RET(FALSE, xPRIORITY_NORMAL);	break;
	}

	return bSetPriority(tpiNewLevel);
}
//---------------------------------------------------------------------------
//TODO: + bIsPriorityBoost (Retrieves the priority boost control state of the specified thread)
BOOL CxThread::bIsPriorityBoost() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	BOOL bDisablePriorityBoost = TRUE;

	bRes = ::GetThreadPriorityBoost(_m_hThread.m_hHandle, &bDisablePriorityBoost);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	//bDisablePriorityBoost == TRUE  - dynamic boosting is disabled
	//bDisablePriorityBoost == FALSE - normal behavior

	return ! bDisablePriorityBoost;
}
//---------------------------------------------------------------------------
//TODO: + bSetPriorityBoost (Disables or enables the ability of the system to temporarily boost the priority of a thread)
BOOL CxThread::bSetPriorityBoost(BOOL bIsEnabled) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriorityBoost(_m_hThread.m_hHandle, ! bIsEnabled);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	CPU
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetAffinityMask (Sets a processor affinity mask for the specified thread)
BOOL CxThread::bSetAffinityMask(DWORD_PTR pulMask) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	DWORD_PTR pulRes = 0;

	pulRes = ::SetThreadAffinityMask(_m_hThread.m_hHandle, pulMask);	//ERROR_INVALID_PARAMETER	
	/*DEBUG*/xASSERT_RET(0 != pulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetIdealProcessor (Sets a preferred processor for a thread, ulIdealProcessor - this value is zero-based)
BOOL CxThread::bSetIdealCPU(ULONG ulIdealCPU) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, ulIdealCPU);
	/*DEBUG*/xASSERT_RET((ULONG) - 1 != ulRes, FALSE); 
	
	//TODO: - xASSERT_RET
	///*DEBUG*/xASSERT_RET(ulIdealCPU != ulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ulGetIdealProcessor (current ideal processor without changing it)
ULONG CxThread::ulGetIdealCPU() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, MAXIMUM_PROCESSORS);
	/*DEBUG*/xASSERT_RET((ULONG) - 1 != ulRes, FALSE); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCPUCount (���-�� ����������� �� �����)
ULONG CxThread::ulGetCPUCount() const {
	/*DEBUG*///_m_hThread - not need 

	ULONG ulRes = 0;

	ulRes = CxSystemInfo::ulGetNumOfCPUs();
	xCHECK_RET(ulRes < 1 || ulRes > 32, 1);

	return ulRes;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetHandle (������ ������)
HANDLE CxThread::hGetHandle() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), NULL); 

	return _m_hThread.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + ulGetId (ID ������)
ULONG CxThread::ulGetId() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	return _m_ulID;
}
//---------------------------------------------------------------------------
//TODO: + bGetExitCode (Retrieves the termination status of the specified thread)
ULONG CxThread::ulGetExitCode() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = 0;	
	BOOL  bRes  = 0;

	bRes = ::GetExitCodeThread(_m_hThread.m_hHandle, &ulRes);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, ulRes/*0*/);

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetDebugName (Name your threads in the VC debugger thread list)
BOOL CxThread::bSetDebugNameA(LPCSTR pcszName) const {
	/*DEBUG*/xASSERT_RET(0    <  _m_ulID,              FALSE); 
	/*DEBUG*/xASSERT_RET(NULL != pcszName,             FALSE); 
	/*DEBUG*/xASSERT_RET(32   >  ::lstrlenA(pcszName), FALSE); //MAX_NAME_SIZE 32

	BOOL bRes = FALSE;

	typedef struct tagTHREADNAME_INFO {
		DWORD  dwType;     //must be 0x1000
		LPCSTR szName;     //pointer to name (in user addr space)
		DWORD  dwThreadID; //thread ID (-1=caller thread)
		DWORD  dwFlags;    //reserved for future use, must be zero
	} THREADNAME_INFO;

	THREADNAME_INFO tiInfo = {0};
	tiInfo.dwType     = 0x1000;
	tiInfo.szName     = pcszName;
	tiInfo.dwThreadID = ulGetId() /*- 1*/;	//_m_ulID;
	tiInfo.dwFlags    = 0;

	__try {
		//::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), static_cast<DWORD *>( static_cast<LPVOID>(&tiInfo) ));
		::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), xreinterpret_cast<DWORD *>(&tiInfo));
	}
	__except (EXCEPTION_CONTINUE_EXECUTION)	{
		/*DEBUG*/xASSERT_RET(FALSE, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	static
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hOpen (Opens an existing thread object.)
/*static*/ HANDLE CxThread::hOpen(ULONG ulAccess, BOOL bInheritHandle, ULONG ulId) {
	/*DEBUG*///ulAccess       - not need 
	/*DEBUG*///bInheritHandle - not need
	/*DEBUG*/xASSERT_RET(0 < ulId, NULL); 

	HANDLE hRes = NULL;

	hRes = ::OpenThread(ulAccess, bInheritHandle, ulId);
	/*DEBUG*/xASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCurrId (Retrieves the thread identifier of the calling thread.)
/*static*/ ULONG CxThread::ulGetCurrId() {
	/*DEBUG*///not need 

	ULONG ulRes = 0;

	ulRes = ::GetCurrentThreadId();
	/*DEBUG*/xASSERT_RET(0 < ulRes, 0); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + hGetCurrHandle (Retrieves a pseudo handle for the calling thread)
/*static*/ HANDLE CxThread::hGetCurrHandle() {
	/*DEBUG*///not need 

	HANDLE hRes = NULL;

	hRes = ::GetCurrentThread();
	/*DEBUG*/xASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------

/****************************************************************************
*    callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnEnter ()
VOID CxThread::vAttachHandler_OnEnter(SClosureT<VOID(CxThread *pthSender)> vCallback) {
	_m_vCallback_OnEnter = vCallback;
	//_m_bFlag_OnEnter  = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnEnter ()
////VOID vDetachHandler_OnEnter(CxThread *pthSender) {
////	//_m_bFlag_OnEnter         = FALSE;
////	_m_Callback_OnEnter.p_this = NULL;
////}
//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnExit ()
VOID CxThread::vAttachHandler_OnExit(SClosureT<VOID(CxThread *pthSender)> vCallback) {
	_m_vCallback_OnExit = vCallback;
	//_m_bFlag_OnExit    = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnExit ()
////VOID vDetachHandler_OnExit(CxThread *pthSender) {
////	//_m_bFlag_OnExit         = FALSE;
////	_m_Callback_OnExit.p_this = NULL;
////}
//---------------------------------------------------------------------------




/****************************************************************************
*	[protected] 
*
*****************************************************************************/

/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + uiOnRun (������� ������)	//must override this
/*virtual*/ UINT CxThread::uiOnRun(VOID *pvParam) /*= 0*/ {
	/*DEBUG*///not need
	/*DEBUG*/xASSERT_RET(FALSE, 0);

	/*UINT uiRes = 0;

	for (;;) {
		//-------------------------------------
		//�� ���� �� ����� ��� ���������������
		bRes = bIsTimeToExit();
		xCHECK_DO(TRUE == bRes, break);

		//...
	}	

	return uiRes;*/

	return 0;
}
//---------------------------------------------------------------------------
//TODO: + vOnEnter (������� �� ��������������� ������)	//must override this
/*virtual*/ VOID CxThread::vOnEnter() {
	/*DEBUG*///not need
	/*DEBUG*/xASSERT_DO(FALSE, return);

	return;
}
//---------------------------------------------------------------------------
//TODO: + vOnExit (������� �� ���������� ������)	//must override this
/*virtual*/ VOID CxThread::vOnExit() {
	/*DEBUG*///not need
	/*DEBUG*/xASSERT_DO(FALSE, return);

	return;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bYield (�������� ������� ������� ������, ������� ����� � ���������� �� !������� ����������!)
BOOL CxThread::bYield() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	::SwitchToThread();
	/*DEBUG*///not need

	//-------------------------------------
	//��������� �������
	//not need

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleep (Suspends the execution of the current thread until the time-out interval elapses)
BOOL CxThread::bSleep(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - not need

	BOOL bRes = FALSE;  

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- /*_m_bIsPaused*/
	////-TEST- _m_bIsSleeping = TRUE;
	/*_m_bIsExited*/

	bRes = _m_slSleeper.bSleep(ulTimeout);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- /*_m_bIsPaused*/
	////-TEST- _m_bIsSleeping = FALSE;		//�����
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleeperWakeUp (���������� ������� bSleep - ����� �� ������� ���������)
BOOL CxThread::bSleeperWakeUp() {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = _m_slSleeper.bWakeUp();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- /*_m_bIsPaused*/
	////-TEST- _m_bIsSleeping = FALSE;
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsTimeToExit (���� �� �������� �� ������)
BOOL CxThread::bIsTimeToExit() {   
	/*DEBUG*///not need

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	///bSleep(1);

	bRes = bIsExited();
	xCHECK_RET(FALSE != bRes, TRUE);

	//-------------------------------------
	//����� / �������������
	///bSleep(1);

	bRes = bIsPaused();
	xCHECK_RET(FALSE != bRes, !_bWaitResumption());

	//-------------------------------------
	//��������� �������
	//[not need]

	return FALSE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*	[private]
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_uiStartFunc (����������� ������� ������)
UINT WINAPI CxThread::_s_uiStartFunc(VOID *pvParam) {
	/*DEBUG*/xASSERT_RET(NULL != pvParam, 0);

	UINT uiRes = 0;
	BOOL bRes  = 0;

	CxThread *pthThis = static_cast<CxThread *>(pvParam); 
	/*DEBUG*/xASSERT_RET(NULL != pthThis, 0);

	//-------------------------------------
	//���� ���� ����� ��� ��������
	//::Sleep(5);
	bRes = pthThis->_m_pevStarter->bWait(/*+INFINITE*/10000);  
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	xDELETE_PTR(pthThis->_m_pevStarter);

	/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 

	//-------------------------------------
	//������ �� ���������������� �����?
	xCHECK_DO(TRUE == pthThis->bIsPaused(), pthThis->_bWaitResumption());

	//-------------------------------------
	//������������� COM
	if (TRUE == pthThis->_m_cbIsUsingCOM) {
		pthThis->_m_pcomCOM = new CxCOM(CxCOM::cmMultiThreaded);
		/*DEBUG*/xASSERT_DO(NULL != pthThis->_m_pcomCOM, 0);
	}


	{
		//-------------------------------------
		//������ ������� ������
		try {
			//--pthThis->vOnEnter();
			pthThis->_vHandler_OnEnter(pthThis);
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	
		//-------------------------------------
		//���������� ������� ������
		try {
			if (0 == pthThis->_m_ptfStartAddress) {
				uiRes = pthThis->uiOnRun(pthThis->_m_pvParam);
			} else {
				uiRes = pthThis->_m_ptfStartAddress(pthThis->_m_pvParam);
			}
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	
		//-------------------------------------
		//��������� ������� ������
		try {
			//--pthThis->vOnExit();
			pthThis->_vHandler_OnExit(pthThis);
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	}

	
	//-------------------------------------
	//��������������� COM
	if (TRUE == pthThis->_m_cbIsUsingCOM) {
		xDELETE_PTR(pthThis->_m_pcomCOM);
	}

	//-------------------------------------
	//������ �������� (���� �� ���������???)												
	bRes = pthThis->_m_hThread.bClose();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, 0);

	pthThis->_m_ulID            = 0;
	pthThis->_m_uiExitCode      = uiRes;	//???
	pthThis->_m_ptfStartAddress = 0;
	pthThis->_m_pvParam         = NULL;
	//pthThis->_m_bIsAutoDelete - not need 

	//-------------------------------------
	//��������� �������
	pthThis->_vSetDefaultStates();

	//-------------------------------------
	//��������������� ������
	xCHECK_DO(TRUE == pthThis->_m_cbIsAutoDelete, xDELETE_PTR(pthThis));

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: + _bWaitForResume (���� ������ �����)
BOOL CxThread::_bWaitResumption() {
	/*DEBUG*/

	BOOL  bRes  = FALSE;
	ULONG ulRes = 0;

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	////-TEST- _m_bIsPaused = TRUE;           
	////-TEST- /*_m_bIsSleeping*/
	/*_m_bIsExited*/

	ulRes = ::WaitForSingleObject(_m_evPause.hGetHandle(), INFINITE); 
	/*DEBUG*///- not need

	return TRUE;

	/*
	//a mechanism for terminating thread should be implemented
	//not allowing the method to be run from the main thread
	if (::GetCurrentThreadId () == this->hMainThreadId) {
		return 0;
	} else {
		::MessageBoxW (0, _T("I'm running in a different thread!"), _T("CMyThread"), MB_OK);

		return 0;
	}
	*/
}
//---------------------------------------------------------------------------
//TODO: + _vSetDefaultStates ()
VOID CxThread::_vSetDefaultStates() {
	/*DEBUG*///not need 

	//-------------------------------------
	//��������� �������
	_m_bIsCreated  = FALSE;
	_m_bIsRunning  = FALSE;
	////-TEST- _m_bIsPaused   = FALSE;
	////-TEST- _m_bIsSleeping = FALSE;
#ifdef defVarPolicy
	_m_bIsExited   = FALSE;
#else 
	//???
#endif
}
//---------------------------------------------------------------------------

/****************************************************************************
*    callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vHandler_OnEnter ()
VOID CxThread::_vHandler_OnEnter(CxThread *pthSender)	{
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnEnter) {
	xCHECK_DO(NULL == _m_vCallback_OnEnter, return); 

	_m_vCallback_OnEnter(pthSender);
}
//---------------------------------------------------------------------------
//TODO: + vHandler_OnExit ()
VOID CxThread::_vHandler_OnExit(CxThread *pthSender) {
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnExit) {
	xCHECK_DO(NULL == _m_vCallback_OnExit, return)

	_m_vCallback_OnExit(pthSender);

}
//---------------------------------------------------------------------------