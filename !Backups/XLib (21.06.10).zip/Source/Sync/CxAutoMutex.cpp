/****************************************************************************
* Class name:  CxMutexScopeLock
* Description: ������� � �����
* File name:   CxAutoMutex.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     16.12.2009 10:06:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CxAutoMutex.h>

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxAutoMutex ()
CxAutoMutex::CxAutoMutex(CxMutex &mtMutex) : 
	_m_mtMutex(mtMutex) 
{
	BOOL bRes = FALSE;

	bRes = _m_mtMutex.bWait(INFINITE);
	/*DEBUG*/xASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//TODO: - ~CxAutoMutex ()
CxAutoMutex::~CxAutoMutex() {
	BOOL bRes = FALSE;

	bRes = _m_mtMutex.bRelease();
	/*DEBUG*/xASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------