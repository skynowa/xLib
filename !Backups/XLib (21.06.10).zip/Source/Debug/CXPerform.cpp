/****************************************************************************
* Class name:  CxPerform
* Description: ����� ������������������ ����
* File name:   CxPerform.cpp
* String type: Ansi (tString)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#include <XLib/Debug/CxPerform.h>

#include <time.h>
#include <XLib/CxString.h>
#include <XLib/Fso/CxPath.h>
#include <XLib/Fso/CxStdioFile.h>
//---------------------------------------------------------------------------
//TODO: + CxPerform (�����������)
CxPerform::CxPerform(const tString &csFileName, EMode pmMode) {
	/*DEBUG*/xASSERT_DO(false == csFileName.empty(), return);
	/*DEBUG*/xASSERT_DO(pmMode < 2 || pmMode > 0,    return);
	
	_bResetData(); 

	_m_pmModeNow = pmMode;
	_m_sLogPath  = CxPath::sGetDir(CxPath::sGetExe()) + _T("\\") + csFileName;
	
	_bLog(_T("------------------------------"));
}
//---------------------------------------------------------------------------
//TODO: + ~CxPerform (����������)
CxPerform::~CxPerform() {	
	_bLog(_T("------------------------------"));
}
//--------------------------------------------------------------------------
//TODO: + bStart (����� ���������)
BOOL CxPerform::bStart() {
	/*DEBUG*/(FALSE == _m_bWasStarted, FALSE);

    switch (_m_pmModeNow) {
		//pmTime
		case pmTime: {
				////::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				////////dtBeginTime = Time();
				////SYSTEMTIME stST = {0};
				////::GetLocalTime(&stST);

				////fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	
			}
			break;

        //pmGetTickCount
		case pmTickCount: {
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				_m_ulBeginTime = ::GetTickCount();
			}
            break;
		
		//QueryPerformanceCounter
        case pmPerformanceCount: {
				if (!::QueryPerformanceFrequency(&_m_liStart)) {
					/*DEBUG*/xASSERT_MSG_RET(FALSE, _T("��������� ����������"), FALSE);
				}
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::QueryPerformanceFrequency(&_m_liBeginCount);
			}
            break;

		//pmGetThreadTimes
		case pmThreadTimes: {
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::GetThreadTimes(::GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTime0, &_m_lpUserTime0);
			}
			break;
		
		//pmUknown
		case pmUknown: {
				/*DEBUG*/xASSERT_RET(FALSE, FALSE);
			}
			break; 

        default: {
				/*DEBUG*/xASSERT_MSG_RET(FALSE, _T("���������� �����"), FALSE);
			}
            break;
    }

    _m_bWasStarted = TRUE;

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bStop (���� ���������)
BOOL CxPerform::bStop(const tString &csComment) {
	/*DEBUG*/(FALSE != _m_bWasStarted, FALSE);

	switch (_m_pmModeNow) {
		//pmTime
		case pmTime: {
				////dtEndTime = Time();
				////bLog(casComment, (dtEndTime - dtBeginTime).FormatString("hh:nn:ss:zz"));
			}
			break;

        //pmGetTickCount (��������)
        case pmTickCount: {
				_m_ulEndTime = ::GetTickCount();
                _bLog(_sMilliSecToTimeString(_m_ulEndTime - _m_ulBeginTime), csComment);
            }
            break;

	    //QueryPerformanceCounter (�����)
	    case pmPerformanceCount: {
                ::QueryPerformanceCounter(&_m_liEndCount);
                _m_liCount.QuadPart = _m_liEndCount.QuadPart - _m_liBeginCount.QuadPart;
				_bLog(CxString::lexical_cast(_m_liCount.QuadPart * 1000 / _m_liStart.QuadPart), csComment);
            }
            break;

        //pmGetThreadTimes (��������)
        case pmThreadTimes: {
				::GetThreadTimes(::GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTime1, &_m_lpUserTime1);
                /*???? float*/_bLog(_sMilliSecToTimeString((_iFiletimeToint64(_m_lpUserTime1) - _iFiletimeToint64(_m_lpUserTime0)) / 10000), csComment);	//10000 - ������������; 10 - ������������
            }
            break;  
		
		//pmUknown
		case pmUknown: {
				/*DEBUG*/xASSERT(FALSE);
			}
			break; 

		default: {
				/*DEBUG*/xASSERT(FALSE);
			}
			break;

	}

	_bResetData();

	_m_bWasStarted = FALSE;

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bPulse (��������� � �����, �� ��������� ���������)
BOOL CxPerform::bPulse(const tString &csComment) {
	BOOL bRes = FALSE;

	bRes = bStop(csComment);
    xCHECK_RET(FALSE == bRes, FALSE);

	bRes = bStart();
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPulse (��������� � �����, �� ��������� ���������)
BOOL CxPerform::bPulse(ULONG ulComment) {
	BOOL bRes = FALSE;

    bRes = bStop(CxString::lexical_cast(ulComment));
	xCHECK_RET(FALSE == bRes, FALSE);
    
	bRes = bStart();
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDeleteLog (�������� ����)
BOOL CxPerform::bDeleteLog() {
    BOOL bRes = FALSE;

	bRes = CxStdioFile::bIsExists(_m_sLogPath);
	xCHECK_RET(FALSE == bRes, FALSE);

	bRes = CxStdioFile::bRemove(_m_sLogPath);
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpenLog (�������� ����)
BOOL CxPerform::bOpenLog() {
	BOOL bRes = FALSE;

	bRes = CxStdioFile::bExec(_m_sLogPath);
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------







/****************************************************************************
*	Private methods	
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _bResetData (��������� ���� ������)
BOOL CxPerform::_bResetData() {
    _m_bWasStarted                   = FALSE;

	//pmGetTickCount
	_m_ulBeginTime                   = 0;
	_m_ulEndTime                     = 0;

    //QueryPerformanceCounter
    _m_liStart.QuadPart              = 0;
	_m_liBeginCount.QuadPart         = 0;
	_m_liEndCount.QuadPart           = 0;
	_m_liCount.QuadPart              = 0;

	//GetThreadTimes
	_m_lpCreationTime.dwLowDateTime  = 0;
    _m_lpCreationTime.dwHighDateTime = 0;
	_m_lpExitTime.dwLowDateTime      = 0;
    _m_lpExitTime.dwHighDateTime     = 0;
	_m_lpKernelTime0.dwLowDateTime   = 0;
    _m_lpKernelTime0.dwHighDateTime  = 0;
	_m_lpUserTime0.dwLowDateTime     = 0;
    _m_lpUserTime0.dwHighDateTime    = 0;
	_m_lpKernelTime1.dwLowDateTime   = 0;
    _m_lpKernelTime1.dwHighDateTime  = 0;
	_m_lpUserTime1.dwLowDateTime     = 0;
    _m_lpUserTime1.dwHighDateTime    = 0;
    
    ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + _iFiletimeToint64 ()
__int64 CxPerform::_iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//--------------------------------------------------------------------------
//TODO: + _bLog (�����������)
BOOL CxPerform::_bLog(const tString &csText) {
	BOOL bRes = FALSE;

	CxStdioFile sfLog;

	bRes = sfLog.bOpen(_m_sLogPath, _T("a"));
	xCHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	
	sfLog.iFprintf(_T("[%.2d:%.2d:%.2d]  %s\n"), stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bLog (�����������)
BOOL CxPerform::_bLog(const tString &csText, const tString &csComment) {
	BOOL bRes = FALSE;

	CxStdioFile sfLog;

	bRes = sfLog.bOpen(_m_sLogPath, _T("a"));
	xCHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	/*DEBUG*///not need
	
	sfLog.iFprintf(_T("[%.2d:%.2d:%.2d]  %s: %s\n"), stST.wHour, stST.wMinute, stST.wSecond, csText.c_str(), csComment.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _sMilliSecToTimeString ()
tString CxPerform::_sMilliSecToTimeString(LONGLONG i64MilliSec) {
	tString sRes;

    const LONGLONG ci64H  = i64MilliSec / 3600000;
    const LONGLONG ci64M  = i64MilliSec % 3600000 / 60000;
    const LONGLONG ci64S  = i64MilliSec % 60000   / 1000;
    const LONGLONG ci64Ms = i64MilliSec % 1000;
	
	sRes = CxString::sFormat(_T("%I64d:%.2I64d:%.2I64d:%.3I64d"), ci64H, ci64M, ci64S, ci64Ms);
	
	return sRes;
}
//---------------------------------------------------------------------------







/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

BOOL F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
INT main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/