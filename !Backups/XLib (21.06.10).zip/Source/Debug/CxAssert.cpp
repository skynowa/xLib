/****************************************************************************
* Class name:  CxAssert
* Description: ������� ����
* File name:   CxAssert.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.11.2009 16:39:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/CxAssert.h>

#include <XLib/Fso/CxPath.h> 
#include <XLib/CxSystemInfo.h>
#include <XLib/Gui/CxMsgBoxRtf.h>



/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bLog (������� �������� � ������)
/*static*/
BOOL CxAssert::bLog(LPCTSTR pcszExp, ULONG ulLastError, 
					LPCTSTR pcszFile, ULONG ulLine, LPCTSTR pcszFunc, 
					LPCTSTR pcszDate, LPCTSTR pcszTime, 
					ULONG ulOSVersion, LPCTSTR pcszComment) 
{
	/*CHECK*/

	//-------------------------------------
	//Never corrupt the last error value
	ULONG _ulLastError = ulLastError;

	//-------------------------------------
	//�������� ���������
	tString sProgram   = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(CxPath::sGetExe(), FALSE), 45), FALSE );
	tString sFile      = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(pcszFile,          FALSE), 45), FALSE );
	tString sLastError = CxString::lexical_cast(ulLastError) + xT(" - \"") + CxString::sLastErrorStr(ulLastError) + xT("\"");
	tString sExeName   = CxPath::sGetName(CxPath::sGetExe());							
	tString sOSVersion = CxSystemInfo::sFormatOSVerson(ulOSVersion);							

	tString sFStr = CxString::sFormat(
						xT("%s\n\n")
						xT("%s  %s\n")
						xT("%s  %s\n")
						xT("%s  %i\n")
						xT("%s  %s\n")
						xT("%s  %s\n")
						xT("%s  %s\n")		
						xT("%s  %s/%s\n")	
						xT("%s  %s\n")		
						xT("%s  %s"),	

						xT("Assertion failed."),
						xT("Program:"),    sProgram.c_str(),
						xT("File:"),       sFile.c_str(),
						xT("Line:"),       ulLine,
						xT("Function:"),   pcszFunc,
						xT("Expression:"), pcszExp,
						xT("LastError:"),  sLastError.c_str(),
						xT("Build date:"), pcszDate, pcszTime,
						xT("Minimum OS:"), sOSVersion.c_str(),
						xT("Comment:"),    pcszComment);

	//-------------------------------------
	//�������� ��� �����
	tString sFilePath = CxPath::sSetExt(CxPath::sGetExe(), xT("debug"));

	//-------------------------------------
	//������� � ���
	_bLogAppend(sFilePath.c_str(), sFStr.c_str());	

	//-------------------------------------
	//Never corrupt the last error value
	::SetLastError(_ulLastError);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMsg (������� �������� � ������, ����� ����������� ����)
/*static*/
BOOL CxAssert::bMsg(LPCTSTR pcszExp, ULONG ulLastError, 
					LPCTSTR pcszFile, ULONG ulLine, 
					LPCTSTR pcszFunc, LPCTSTR pcszDate, LPCTSTR pcszTime, 
					ULONG ulOSVersion, LPCTSTR pcszComment/* = xT("")*/) 
{
	/*CHECK*/

	//-------------------------------------
	//Never corrupt the last error value
	ULONG _ulLastError = ulLastError;

	//-------------------------------------
	//�������� ���������
	tString sProgram   = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(CxPath::sGetExe(), FALSE), 45), FALSE );
	tString sFile      = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(pcszFile,          FALSE), 45), FALSE );
	tString sLastError = CxString::lexical_cast(ulLastError) + xT(" - \"") + CxString::sLastErrorStr(ulLastError) + xT("\"");
	tString sExeName   = CxPath::sGetName(CxPath::sGetExe());
	tString sOSVersion = CxSystemInfo::sFormatOSVerson(ulOSVersion);							

	tString sFStr = CxString::sFormat(
						xT("%s\n\n")
						xT("%s  %s\n")
						xT("%s  %s\n")
						xT("%s  %i\n")
						xT("%s  %s\n")
						xT("%s  %s\n")
						xT("%s  %s\n")	
						xT("%s  %s/%s\n")								
						xT("%s  %s\n")	
						xT("%s  %s"),	

						xT("Assertion failed."),
						xT("Program:"),    sProgram.c_str(),
						xT("File:"),       sFile.c_str(),
						xT("Line:"),       ulLine,
						xT("Function:"),   pcszFunc,
						xT("Expression:"), pcszExp,
						xT("LastError:"),  sLastError.c_str(),
						xT("Build date:"), pcszDate, pcszTime,
						xT("Minimum OS:"), sOSVersion.c_str(),
						xT("Comment:"),    pcszComment);

	//-------------------------------------
	//������� MessageBox
	INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
				exit(- 1);
			}
			break;

		case IDIGNORE: {
				//����������
			}
			break;

		case IDRETRY: {
				if (TRUE == ::IsDebuggerPresent()) {		//CheckRemoteDebuggerPresent
					////::DebugBreak();
					_asm {int 3}
				} else {
					::MessageBox(NULL, xT("Debugger is not present.\nThe application will be terminated."), xT("XLib"), MB_OK | MB_ICONWARNING);
					exit(- 1);
				}	
			}
			break;
	}

	//-------------------------------------
	//Never corrupt the last error value
	::SetLastError(_ulLastError);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMsgRtf (������� �������� � ������, ����� ����������� ����)
/*static*/
BOOL CxAssert::bMsgRtf(LPCTSTR pcszExp, ULONG ulLastError, 
					   LPCTSTR pcszFile, ULONG ulLine, 
					   LPCTSTR pcszFunc, LPCTSTR pcszDate, 
					   LPCTSTR pcszTime, ULONG ulOSVersion, 
					   LPCTSTR pcszComment/* = xT("")*/) 
{
	/*CHECK*/

	//-------------------------------------
	//Never corrupt the last error value
	ULONG _ulLastError = ulLastError;

	//-------------------------------------
	//�������� ���������
	tString sProgram   = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(CxPath::sGetExe(), FALSE), 45), FALSE );
	tString sFile      = CxPath::sToNix( CxPath::sMinimize(CxPath::sToWin(pcszFile,          FALSE), 45), FALSE );
	tString sLastError = CxString::lexical_cast(ulLastError) + xT(" - \"") + CxString::sLastErrorStr(ulLastError) + xT("\"");
	tString sExeName   = CxPath::sGetName(CxPath::sGetExe());
	tString sOSVersion = CxSystemInfo::sFormatOSVerson(ulOSVersion);							

	tString sFStr = CxString::sFormat(
						xT("{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}")
						xT("{\\colortbl ;\\red0\\green0\\blue0;\\red255\\green0\\blue0;\\red0\\green0\\blue255;}")
						xT("{\\*\\generator Msftedit 5.41.15.1515;}\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par")
						xT("\\par")
						xT("\\b %s\\b0      \\lang1033\\f1    \\cf1\\lang1049\\f0 %s\\cf2\\par")
						xT("\\cf0\\b %s\\b0      \\lang1033\\f1            \\cf1\\lang1049\\f0 %s\\cf2\\par")
						xT("\\cf0\\b %s\\b0      \\lang1033\\f1           \\cf1\\lang1049\\f0 %i\\cf0\\par")
						xT("\\b %s\\b0     \\lang1033\\f1   \\lang1049\\f0  \\lang1033\\f1  \\cf3\\lang1049\\f0 %s\\cf0\\par")
						xT("\\b %s\\b0      \\cf2 %s\\cf0\\par")
						xT("\\b %s\\lang1033\\b0\\f1         \\cf2\\lang1049\\f0 %s\\cf0\\par")
						xT("\\b %s\\lang1033\\b0\\f1       \\cf1\\lang1049\\f0 %s %s\\cf0\\par")
						xT("\\b %s\\lang1033\\b0\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par")
						xT("\\b %s\\b0     \\lang1033\\f1    \\cf1 %s\\lang1049\\f0\\par")
						xT("}"),

						xT("Assertion failed."),
						xT("Program:"),    sProgram.c_str(),
						xT("File:"),       sFile.c_str(),
						xT("Line:"),       ulLine,
						xT("Function:"),   pcszFunc,
						xT("Expression:"), pcszExp,
						xT("LastError:"),  sLastError.c_str(),
						xT("Build date:"), pcszDate, pcszTime,
						xT("Minimum OS:"), sOSVersion.c_str(),
						xT("Comment:"),    pcszComment 
	);

	//-------------------------------------
	//������� CxMsgBoxRtf
	INT iRes = CxMsgBoxRtf::iShow(NULL, sFStr, sExeName);
	switch (iRes) {
		case CxMsgBoxRtf::mrAbort: {
				exit(- 1);
			}
			break;

		case CxMsgBoxRtf::mrIgnore: {
				//����������
			}
			break;

		case CxMsgBoxRtf::mrRetry: {
				if (TRUE == ::IsDebuggerPresent()) {		//CheckRemoteDebuggerPresent
					////::DebugBreak();
					_asm {int 3}
				} else {
					::MessageBox(0, xT("Debugger is not present.\nThe application will be terminated."), xT("XLib"), MB_OK | MB_ICONWARNING);
					exit(- 1);
				}				
			}
			break;	
	}

	//-------------------------------------
	//Never corrupt the last error value
	::SetLastError(_ulLastError);
	
	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxAssert ()
CxAssert::CxAssert() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CxAssert ()
CxAssert::~CxAssert() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + _bLogAppend (������� �������� � ������, ������ � ����)
/*static*/
BOOL CxAssert::_bLogAppend(LPCTSTR pcszFilePath, LPCTSTR pcszText) {
	/*CHECK*/

	FILE *pFile = _tfopen(pcszFilePath, xT("a"));
	if (NULL == pFile) {
		return FALSE;
	}

	__try {
		SYSTEMTIME stST = {0};
		::GetLocalTime(&stST);
		_ftprintf(pFile, xT("[%d:%d:%d]  %s\n---------------------------------------------------------------------------\n\n"), 
			                 stST.wHour, stST.wMinute, stST.wSecond, pcszText);
	}
	__finally {
		if (NULL != pFile) {
			fflush(pFile);
			fclose(pFile);	pFile = NULL;
		}
	}
	
	return TRUE;
}
//---------------------------------------------------------------------------