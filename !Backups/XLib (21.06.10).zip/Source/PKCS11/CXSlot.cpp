/****************************************************************************
* Class name:  CXSlot
* Description: PKCS11 ����
* File name:   CXSlot.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:07:29
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXSlot.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/
 
//---------------------------------------------------------------------------
//TODO: - CXSlot ()
CXSlot::CXSlot(const CXPKCS11 &cPKCS11) :
	_m_bRes (FALSE),
	_m_ulRes(!CKR_OK),
	_m_pFunc(cPKCS11.pGetFuncList())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXSlot ()
CXSlot::~CXSlot() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bGetList (btains a list of slots in the system)
BOOL CXSlot::bGetList(
	CK_BBOOL       bTokenPresent,  /* only slots with tokens? */
	CK_SLOT_ID_PTR pSlotList,     /* receives array of slot IDs */
	CK_ULONG_PTR   pulCount       /* receives number of slots */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetSlotList(bTokenPresent, pSlotList, pulCount);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);
		
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetInfo (obtains information about a particular slot in the system)
BOOL CXSlot::bGetInfo(
	CK_SLOT_ID       slotID,  /* the ID of the slot */
	CK_SLOT_INFO_PTR pInfo    /* receives the slot information */
)
{
	/*DEBUG*/
	
	_m_ulRes = _m_pFunc->C_GetSlotInfo(slotID, pInfo);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);
	
	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: - bWaitForEvent (waits for a slot event (token insertion, removal, etc.) to occur)
BOOL CXSlot::bWaitForEvent(
	CK_FLAGS       flags,     /* blocking/nonblocking flag */
	CK_SLOT_ID_PTR pSlot,	  /* location that receives the slot ID */
	CK_VOID_PTR    pRserved   /* reserved.  Should be NULL_PTR */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_WaitForSlotEvent(flags, pSlot, pRserved);		
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
