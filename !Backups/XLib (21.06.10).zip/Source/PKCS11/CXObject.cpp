/****************************************************************************
* Class name:  CXObject
* Description: PKCS11 ������
* File name:   CXObject.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:09:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXObject.h>

#include <XLib/PKCS11/CXUtils.h>

#define MAX_FINDED_OBJECTS 512

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXObject ()
CXObject::CXObject(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle()),
	_m_hObject (NULL)
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXObject ()
CXObject::~CXObject() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - CXObject (gets a handle)
CK_OBJECT_HANDLE CXObject::hGetHandle() const {
	/*DEBUG*/

	return _m_hObject;
}
//---------------------------------------------------------------------------
//TODO: - bCreate (creates a new object)
BOOL CXObject::bCreate(
	CK_ATTRIBUTE_PTR  pTemplate,   /* the object's template */
	CK_ULONG          ulCount     /* attributes in template */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_CreateObject(_m_hSession, pTemplate, ulCount, &_m_hObject);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetSize (gets the size of an object in bytes)	
BOOL CXObject::bGetSize(
	CK_ULONG_PTR      pulSize    /* receives size of object */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetObjectSize(_m_hSession, _m_hObject, pulSize);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bCopy (copies an object, creating a new object for the copy)
BOOL CXObject::bCopy(
	CK_ATTRIBUTE_PTR     pTemplate,   /* template for new object */
	CK_ULONG             ulCount,     /* attributes in template */
	CK_OBJECT_HANDLE_PTR phNewObject  /* receives handle of copy */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_CopyObject(_m_hSession, _m_hObject, pTemplate, ulCount, phNewObject);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bFindInit (initializes a search for token and session objects that match a template)
BOOL CXObject::bFindInit(
	CK_ATTRIBUTE_PTR  pTemplate,  /* attribute values to match */
	CK_ULONG          ulCount     /* attrs in search template */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_FindObjectsInit(_m_hSession, pTemplate, ulCount);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bFind (continues a search for token and session objects that match a template, obtaining additional object handles)
BOOL CXObject::bFind(
	CK_OBJECT_HANDLE_PTR phObject,          /* gets obj. handles */
	CK_ULONG             ulMaxObjectCount,  /* max handles to get */
	CK_ULONG_PTR         pulObjectCount     /* actual # returned */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_FindObjects(_m_hSession, phObject, ulMaxObjectCount, pulObjectCount );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bFindFinal (finishes a search for token and session objects)
BOOL CXObject::bFindFinal() {
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_FindObjectsFinal(_m_hSession);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}	
//---------------------------------------------------------------------------
//TODO: - bDestroy (destroys an object)
BOOL CXObject::bDestroy() {
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DestroyObject(_m_hSession, _m_hObject);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetAttributeValue (obtains the value of one or more object attributes)
BOOL CXObject::bGetAttributeValue(
	CK_ATTRIBUTE_PTR  pTemplate,  /* specifies attrs; gets vals */
	CK_ULONG          ulCount     /* attributes in template */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetAttributeValue(_m_hSession, _m_hObject, pTemplate, ulCount);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetAttributeValue (modifies the value of one or more object attributes)
BOOL CXObject::bSetAttributeValue(
	CK_ATTRIBUTE_PTR  pTemplate,  /* specifies attrs and values */
	CK_ULONG          ulCount     /* attributes in template */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_SetAttributeValue(_m_hSession, _m_hObject, pTemplate, ulCount);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUtil_Find (search for token and session objects that match a template, obtaining additional object handles)
BOOL CXObject::bUtil_Find(
	CK_ATTRIBUTE_PTR               pTemplate,  			/* attribute values to match */
	CK_ULONG                       ulCount,    			/* attrs in search template */
	std::vector<CK_OBJECT_HANDLE> *pvecObjectHandles	/* [out] handles to objects */
) 
{
	/*DEBUG*/

	_m_bRes = bFindInit(pTemplate, ulCount);	// To find all attributes, set ulCount to 0.
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	CK_OBJECT_HANDLE hList[MAX_FINDED_OBJECTS] = {0};
	CK_ULONG         ulFound  = 0;
	
	_m_bRes = bFind(&hList[0], MAX_FINDED_OBJECTS, &ulFound);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	_m_bRes = bFindFinal();
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	xCHECK_RET(0 == ulFound, FALSE);
	
	//-------------------------------------
	//���������� std::vector
	(*pvecObjectHandles).clear();
	for (CK_ULONG i = 0; i < ulFound; ++ i) {
    	(*pvecObjectHandles).push_back( hList[i] );
    }

	return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
