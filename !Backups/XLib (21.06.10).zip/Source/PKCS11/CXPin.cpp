/****************************************************************************
* Class name:  CXPin
* Description: PKCS11 ���-���
* File name:   CXPin.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:09:04
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXPin.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXPin ()
CXPin::CXPin(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXPin ()
CXPin::~CXPin() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bInitToken (initializes a token)
BOOL CXPin::bInitToken(
	CK_SLOT_ID      slotID,    /* ID of the token's slot */
	CK_UTF8CHAR_PTR pPin,      /* the SO's initial PIN */
	CK_ULONG        ulPinLen,  /* length in bytes of the PIN */
	CK_UTF8CHAR_PTR pLabel     /* 32-byte token label (blank padded) */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_InitToken(slotID, pPin, ulPinLen, pLabel);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bInitPIN (initializes the normal user's PIN)
BOOL CXPin::bInitPIN(
	CK_UTF8CHAR_PTR   pPin,      /* the normal user's PIN */
	CK_ULONG          ulPinLen   /* length in bytes of the PIN */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_InitPIN(_m_hSession, pPin, ulPinLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetPIN (modifies the PIN of the user who is logged in)
BOOL CXPin::bSetPIN(
	CK_UTF8CHAR_PTR   pOldPin,   /* the old PIN */
	CK_ULONG          ulOldLen,  /* length of the old PIN */
	CK_UTF8CHAR_PTR   pNewPin,   /* the new PIN */
	CK_ULONG          ulNewLen   /* length of the new PIN */
) 
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_SetPIN(_m_hSession, pOldPin, ulOldLen, pNewPin, ulNewLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
