/****************************************************************************
* Class name:  CxLocale
* Description: ������
* File name:   CxLocale.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.08.2009 19:47:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CxLocale.h>

#include <locale.h>

//---------------------------------------------------------------------------
//TODO: + CxLocale
CxLocale::CxLocale() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CxLocale
CxLocale::~CxLocale() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + sGetCurrent (������ ������� ������)
/*static*/ tString CxLocale::sGetCurrent() {
	/*DEBUG*///not need
	
	tString sRes;
	INT     iRes = - 1;
	LCID    lc   = 0;
	
	lc = ::GetSystemDefaultLCID();
	/*DEBUG*///not need
	
	//������ ��������� ������ ������
	iRes = ::GetLocaleInfo(lc, LOCALE_SENGLANGUAGE, 0, 0);
	/*DEBUG*/xASSERT_RET(0 != iRes, tString());

	sRes.resize(iRes);
	iRes = ::GetLocaleInfo(lc, LOCALE_SENGLANGUAGE, &sRes[0], sRes.size());
	/*DEBUG*/xASSERT_RET(0 != iRes, tString());
	
	sRes.assign(sRes.c_str());	//������� ��������� ������ '\0'
	
	return sRes;
	
	//-------------------------------------
	//2-�������
	//////const TCHAR  *pszLocale = NULL;
	//////
	//////pszLocale = _tsetlocale(LC_ALL, NULL);
	///////*DEBUG*/xASSERT_RET(NULL != pszLocale, _T(""));
	//////
	//////return tString(pszLocale);
}
//---------------------------------------------------------------------------
//TODO: - bSetCurrent (������������� ������� ������)
/*static*/ BOOL CxLocale::bSetCurrent(LPCTSTR pcszLocale) {
	/*DEBUG*/xASSERT_RET(NULL     != pcszLocale,  FALSE);
	/*DEBUG*/xASSERT_RET(_T('\0') != *pcszLocale, FALSE);

	BOOL     bRes       = FALSE;
	LPCTSTR _pcszLocale = NULL;

    _pcszLocale = _tsetlocale(LC_ALL, pcszLocale);
    /*DEBUG*/xASSERT_RET(NULL != _pcszLocale, FALSE);
 
    return TRUE;
 
	//-------------------------------------
	//2-�������
	////BOOL bRes = FALSE;

	////bRes = ::SetLocaleInfo((LCID)csLocale.c_str(), LC_ALL,  0);
	/////*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	////return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetDefault (������������� ������ ��-���������)
/*static*/ BOOL CxLocale::bSetDefault() {
	BOOL bRes = FALSE;
	
	bRes = CxLocale::bSetCurrent(CxLocale::sGetCurrent().c_str());
   /*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
   
   return TRUE;
}
//---------------------------------------------------------------------------


//int GetLocaleInfo(
//				  __in   LCID Locale,
//				  __in   LCTYPE LCType,
//				  __out  LPTSTR lpLCData,
//				  __in   int cchData
//				  );

//BOOL SetLocaleInfo(
//				   __in  LCID Locale,
//				   __in  LCTYPE LCType,
//				   __in  LPCTSTR lpLCData
//				   );