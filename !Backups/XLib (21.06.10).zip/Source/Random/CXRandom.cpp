// Copyright 2003 "Gilles Degottex"

// This file is part of "CppAddons"

// "CppAddons" is free software; you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// "CppAddons" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



#include <XLib/Random/CxRandom.h>

////#include <cmath>
#include <math.h>
//---------------------------------------------------------------------------
const int CxRandom::A = 48271;
//const int CxRandom::M = 2147483647;
const int CxRandom::M = RAND_MAX;
const int CxRandom::Q = M / A;
const int CxRandom::R = M % A;

CxRandom CxRandom::s_random;
//---------------------------------------------------------------------------
CxRandom::CxRandom(long seed) {
	m_haveNextNextGaussian=false;

	setSeed(seed);

	next();
}
//---------------------------------------------------------------------------
void CxRandom::setSeed(long seed) {
	srand(seed);

	if(seed < 0)	seed += M+1;
	m_seed = seed;
	if(m_seed==0)	m_seed = 1;

	m_haveNextNextGaussian = false;
}
//---------------------------------------------------------------------------
long CxRandom::next() {
//	int tmp = A * (m_seed % Q) - R * (m_seed / Q);
//	if(tmp>=0)	m_seed = tmp;
//	else		m_seed = tmp + M;
//
//	return m_seed;

	return rand();
}
//---------------------------------------------------------------------------
int CxRandom::nextInt() {
	return (int)next();
}
//---------------------------------------------------------------------------
int CxRandom::nextInt(int max) {
	return nextInt()%max;
}
//---------------------------------------------------------------------------
int CxRandom::nextInt(int a, int b) {
	return nextInt()%(b-a) + a;
}
//---------------------------------------------------------------------------
long CxRandom::nextLong()	{
	return next();
}
//---------------------------------------------------------------------------
bool CxRandom::nextBoolean() {
	return next() % 2 == 0;
}
//---------------------------------------------------------------------------
float CxRandom::nextFloat() {
	return nextInt() / float(M);
}
//---------------------------------------------------------------------------
double CxRandom::nextDouble() {
	return nextInt() / double(M);
}
//---------------------------------------------------------------------------
char CxRandom::nextLetter() {
	return char(('z' - 'a' + 1) * nextDouble() + 'a');
}
//---------------------------------------------------------------------------
char CxRandom::nextFigure() {
	return char(('9' - '0' + 1) * nextDouble() + '0');
}
//---------------------------------------------------------------------------
double CxRandom::nextGaussian() {
//	Throw("nextGaussian", "not yet implemented");

	// See Knuth, ACP, Section 3.4.1 Algorithm C.
	if(m_haveNextNextGaussian) {
    	m_haveNextNextGaussian = false;
    	return m_nextNextGaussian;
	} else {
		double v1, v2, s;
    	do {
			v1 = 2 * nextDouble() - 1; // between -1 and 1
			v2 = 2 * nextDouble() - 1; // between -1 and 1
			s = v1 * v1 + v2 * v2;
    	}
		while (s >= 1 || s == 0);

		double multiplier = sqrt(-2 * log(s)/s);

    	m_nextNextGaussian     = v2 * multiplier;
		m_haveNextNextGaussian = true;

		return v1 * multiplier;
	}
}
//---------------------------------------------------------------------------