/****************************************************************************
* Class name:  CxDll
* Description: DLL
* File name:   CxDll.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Fso/CxDll.h>

//---------------------------------------------------------------------------
//TODO: + CxDll 
CxDll::CxDll() :
    _m_hDLL(NULL)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CxDll 
CxDll::~CxDll() {
	bFree();
}
//---------------------------------------------------------------------------
//TODO: + bIsLoaded
BOOL CxDll::bIsLoaded() {
	/*DEBUG*/// n/a

	return _m_hDLL != NULL;
}
//---------------------------------------------------------------------------
//TODO: + bLoad 
BOOL CxDll::bLoad(LPCTSTR pcszDllPath) {
	/*DEBUG*/// n/a
	/*DEBUG*/xASSERT_RET(NULL != pcszDllPath, FALSE);

	BOOL bRes = FALSE; 
	
	bRes = bFree();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	_m_hDLL = ::LoadLibrary(pcszDllPath);
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + fpGetProcAddress
FARPROC CxDll::fpGetProcAddress(LPCSTR pcszProcName) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, NULL);

	FARPROC fpRes = NULL;

	fpRes = ::GetProcAddress(_m_hDLL, pcszProcName);
	/*DEBUG*/xASSERT_RET(NULL != fpRes, NULL);

	return fpRes;
}
//---------------------------------------------------------------------------
//TODO: + bFree 
BOOL CxDll::bFree() {
	/*DEBUG*/// n/a

	BOOL bRes = FALSE; 
	
	xCHECK_RET(FALSE == bIsLoaded(), TRUE);

	bRes = ::FreeLibrary(_m_hDLL);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	
	_m_hDLL = NULL;	

	return TRUE;
}
//---------------------------------------------------------------------------