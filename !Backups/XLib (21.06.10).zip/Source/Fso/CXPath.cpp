/****************************************************************************
* Class name:  CxPath
* Description: �������� � ������
* File name:   CxPath.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CxPath.h>



/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - sGetExe
/*static*/
tString CxPath::sGetExe() {
	TCHAR szRes[MAX_PATH + 1] = {0};
	
	ULONG ulStored = ::GetModuleFileName(NULL, szRes, MAX_PATH);
	/*DEBUG*/xASSERT_RET(0        != ulStored, tString());
	/*DEBUG*/xASSERT_RET(NULL     != szRes,    tString());        
	/*DEBUG*/xASSERT_RET(xT('\0') != *szRes,   tString());    

	return tString(szRes, ulStored);	
}
//---------------------------------------------------------------------------
//TODO: - sGetExeDir
/*static*/
tString CxPath::sGetExeDir() {
	return sGetDir(sGetExe());
}
//---------------------------------------------------------------------------
//TODO: - sGetDrive (����)
/*static*/
tString CxPath::sGetDrive(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiDriveDelimPos = csFilePath.find(xDRIVE_DELIM);
	/*DEBUG*/xASSERT_RET(tString::npos != uiDriveDelimPos, tString());
	/*DEBUG*/xASSERT_RET(1             == uiDriveDelimPos, tString());

	return csFilePath.substr(0, uiDriveDelimPos + xDRIVE_DELIM.size()); 
}
//--------------------------------------------------------------------------
//TODO: - sGetDir (Returns the path, without a trailing backslash '\')
/*static*/
tString CxPath::sGetDir(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	//*DEBUG*/// n/a
	/*DEBUG*/xASSERT_RET(tString::npos != uiSlashPos, tString());

	return csFilePath.substr(0, uiSlashPos);
}
//---------------------------------------------------------------------------
//TODO: - sGetFullName (��� + ���������)
/*static*/
tString CxPath::sGetFullName(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tString::npos != uiSlashPos, tString());

	return csFilePath.substr(uiSlashPos + xWIN_SLASH.size(), csFilePath.size());
}
//--------------------------------------------------------------------------
//TODO: - sGetName (���)
/*static*/
tString CxPath::sGetName(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tString::npos != uiSlashPos, tString());

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tString::npos != uiDotPos, tString());

	return CxString::sCut(csFilePath, uiSlashPos + xWIN_SLASH.size(), uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: - sGetExt (���������� ��� �����)
/*static*/
tString CxPath::sGetExt(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/// ???????????

	return csFilePath.substr(uiDotPos + xDOT.size());
}
//--------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: - sSetDrive ()
/*static*/
tString CxPath::sSetDrive(const tString &csFilePath, const tString &csDrivePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// csDrivePath

	tString sRes;
	sRes.assign(csFilePath);

	tString sDrive = sGetDrive(sRes);
	/*DEBUG*/xASSERT_RET(false == sDrive.empty(), tString());

	std::size_t uiPos = sRes.find(sDrive);
	/*DEBUG*/xASSERT_RET(tString::npos != uiPos, tString());

	return sRes.replace(uiPos, sDrive.size(), csDrivePath);
}
//---------------------------------------------------------------------------
//TODO: - sSetDir ()
/*static*/
tString CxPath::sSetDir(const tString &csFilePath, const tString &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// csDirPath

	tString sRes;
	sRes.assign(csFilePath);

	tString sDir = sGetDir(sRes);
	/*DEBUG*/xASSERT_RET(false == sDir.empty(), tString());

	std::size_t uiPos = sRes.find(sDir);
	/*DEBUG*/xASSERT_RET(tString::npos != uiPos, tString());

	return sRes.replace(uiPos, sDir.size(), sRemoveSlash(csDirPath));
}
//---------------------------------------------------------------------------
//TODO: - sSetFullName ()
/*static*/
tString CxPath::sSetFullName(const tString &csFilePath, const tString &csFullName) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// csFullName

	tString sRes;
	sRes.assign(csFilePath);

	tString sFullName = sGetFullName(sRes);
	/*DEBUG*/xASSERT_RET(false == sFullName.empty(), tString());

	std::size_t uiPos = sRes.rfind(sFullName);
	/*DEBUG*/xASSERT_RET(tString::npos != uiPos, tString());

	return sRes.replace(uiPos, sFullName.size(), csFullName);
}
//---------------------------------------------------------------------------
//TODO: - sSetName ()
/*static*/
tString CxPath::sSetName(const tString &csFilePath, const tString &csName) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString());
	/*DEBUG*/// csName

	tString sRes;
	sRes.assign(csFilePath);

	tString sName = sGetName(sRes);
	/*DEBUG*/xASSERT_RET(false == sName.empty(), tString());

	std::size_t uiPos = sRes.rfind(sName);
	/*DEBUG*/xASSERT_RET(tString::npos != uiPos, tString());

	return sRes.replace(uiPos, sName.size(), csName);
}
//---------------------------------------------------------------------------
//TODO: - sSetExt
/*static*/
tString CxPath::sSetExt(const tString &csFilePath, const tString &csExt) {	
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// csExt - n/a 

	tString sRes;
	sRes.assign(csFilePath);

	tString sExt = sGetExt(sRes);
	/*DEBUG*/xASSERT_RET(false == sExt.empty(), tString());

	std::size_t uiPos = sRes.rfind(sExt);
	/*DEBUG*/xASSERT_RET(tString::npos != uiPos, tString());

	return sRes.replace(uiPos, sExt.size(), csExt);
}
//---------------------------------------------------------------------------


//--------------------------------------------------------------------------
//TODO: + sRemoveExt
/*static*/
tString CxPath::sRemoveExt(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/// n/a

	return csFilePath.substr(0, uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: + sRemoveExtIf
/*static*/
tString CxPath::sRemoveExtIf(const tString &csFilePath, const tString &csExt) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 

	//���� ��� ������ ����������, �� ���������� �������� ������
	std::size_t uiExtPos = csFilePath.rfind(xDOT + csExt, csFilePath.size());
	xCHECK_RET(tString::npos == uiExtPos, csFilePath);

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tString::npos != uiDotPos, tString());

	return csFilePath.substr(0, uiDotPos);
}


//---------------------------------------------------------------------------
//TODO: - bIsValidName ()
/*static*/
BOOL CxPath::bIsValidName(const tString &csFileName) {
	/*DEBUG*/// csFileName - n/a
	
	BOOL bRes = FALSE;

	

	return TRUE;
}
//---------------------------------------------------------------------------




//---------------------------------------------------------------------------
//TODO: + sSetValidName
/*static*/
tString CxPath::sSetValidName(const tString &csFileName) {
	/*DEBUG*/// n/a

	tString sRes;
	sRes.assign(csFileName);

	//-------------------------------------
	//��� ����� �� ������ ������
	xCHECK_RET(true == sRes.empty(), tString());

	//-------------------------------------
	//��� ����� �� ������ 255 ��������
	xCHECK_RET(255/*ciFileNameMaxSize*/ <= sRes.size(), tString());

	//-------------------------------------
	//��� ����� �� ����� �������� ������ �� ����� �����
	std::size_t uiDotPos = sRes.find_first_not_of(xDOT);
	xCHECK_RET(tString::npos == uiDotPos, tString());

	//-------------------------------------
	//������ ������ - �� �����  	// if the first character is a dot, the filename is okay or space
	xCHECK_RET(xDOT.at(0) == sRes.at(0), tString()); 

	//-------------------------------------
	//A device name was used. You can pass this value to GetIsValidFileNameErrStr to obtain a pointer to the name of this device.


	//-------------------------------------
	//All characters greater than ASCII 31 to be used except for the following:    "/*:<>?\|
	const tString csFatalChars = xT("\\/:*<>|?\"\t\n\r");

	std::size_t uiFound = sRes.find_first_of(csFatalChars);
	while (tString::npos != uiFound) {
		sRes.erase(uiFound, 1);
		uiFound = sRes.find_first_of(csFatalChars, uiFound);
	}

	//-------------------------------------
	//The following device names cannot be used for a file name nor may they
	//be used for the first segment of a file name (that part which precedes the  first dot):
	//CLOCK$, AUX, CON, NUL, PRN, COM1, COM2, COM3, COM4, COM5, COM6, COM7, COM8,
	//COM9, LPT1, LPT2, LPT3, LPT4, LPT5, LPT6, LPT7, LPT8, LPT9
	//Device names are case insensitve. aux, AUX, Aux, etc. are identical.

	const tString csReserved[] = { 
		xT("CON"),  xT("PRN"),  xT("AUX"),  xT("CLOCK$"), xT("NUL"),
		xT("COM0"), xT("COM1"), xT("COM2"), xT("COM3"),   xT("COM4"), 
		xT("COM5"), xT("COM6"), xT("COM7"), xT("COM8"),   xT("COM9"),
		xT("LPT0"), xT("LPT1"), xT("LPT2"), xT("LPT3"),   xT("LPT4"), 
		xT("LPT5"), xT("LPT6"), xT("LPT7"), xT("LPT8"),   xT("LPT9") 
	};

	tString sFileName = sRemoveExt(sRes);

	for (std::size_t i = 0; i < xARRAY_SIZE(csReserved); ++ i) {
		xCHECK_RET(TRUE == CxString::bCompareNoCase(sFileName, csReserved[i]), tString());
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: - sToWin
/*static*/
tString CxPath::sToWin(const tString &csFilePath, BOOL bIsSlashAtEnd) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// bIsSlashAtEnd - n/a 

	tString sRes;

	if (TRUE == bIsSlashAtEnd) {
		sRes = sAppendSlash(csFilePath);
	} else {
		sRes = sRemoveSlash(csFilePath);
	}

	sRes = CxString::sReplaceAll(sRes, xNIX_SLASH, xWIN_SLASH);

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: - sToNix
/*static*/
tString CxPath::sToNix(const tString &csFilePath, BOOL bIsSlashAtEnd) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString()); 
	/*DEBUG*/// bIsSlashAtEnd - n/a 

	tString sRes;

	if (TRUE == bIsSlashAtEnd) {
		sRes = sAppendSlash(csFilePath);
	} else {
		sRes = sRemoveSlash(csFilePath);
	}

	sRes = CxString::sReplaceAll(sRes, xWIN_SLASH, xNIX_SLASH);

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: - sMinimizeName 
/*static*/
tString CxPath::sMinimizeName(const tString &csFileName, const std::size_t cuiMaxSize) {	
	/*DEBUG*/xASSERT_RET(false == csFileName.empty(),          tString());
	/*DEBUG*///xASSERT_RET(false == sGetExt(csFileName).empty(), tString());
	/*DEBUG*/xASSERT_RET(0 < cuiMaxSize,                       tString());

	tString     sRes;
	tString     sTildaDotExt      = xT("~") + xDOT + sGetExt(csFileName);
	std::size_t uiTildaDotExtSize = sTildaDotExt.size();

	if (csFileName.size() > cuiMaxSize) {
		if (cuiMaxSize < uiTildaDotExtSize) {
			sRes = csFileName.substr(0, cuiMaxSize);
		} else {
			sRes = csFileName.substr(0, cuiMaxSize - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csFileName;
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: - sMinimize
/*static*/
tString CxPath::sMinimize(const tString &csFilePath, const size_t cuiMaxSize) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tString());
	/*DEBUG*/xASSERT_RET(0 < cuiMaxSize,              tString());

	tString sRes;
	sRes.assign(csFilePath);	

	tString sDrive = sGetDrive(sRes);										//D:
	tString sDir   = sGetDir(sRes).erase(0, sDrive.size()) + xWIN_SLASH;	//\XLib\Test\CxString\Project\Debug\ 
	tString sName  = sGetFullName(sRes);									//Test.exe

	while (((false == sDir.empty()) || (false == sDrive.empty())) && (sRes.size() > cuiMaxSize)) { 
		if ((xWIN_SLASH + xT("...") + xWIN_SLASH) == sDir ) {
			sDrive.clear();
			sDir = xT("...") + xWIN_SLASH;
		} 
		else if (true == sDir.empty()) {
			sDrive.clear();
		} 
		else {
			BOOL        bRoot = FALSE;
			std::size_t uiPos = tString::npos;

			if (xWIN_SLASH == sDir) {
				sDir.clear();
			} 
			else {
				if (sDir.at(0) == xWIN_SLASH.at(0)  /*xT('\\')*/) {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = FALSE;
				}

				if (/*xT('.')*/xDOT.at(0) == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//uiPos = AnsiPos("\\", S); 
				uiPos = sDir.find_first_of(xWIN_SLASH);		//-- uiPos = sDir.find_first_of(xWIN_SLASH) + 1;
				if (tString::npos == uiPos) {
					sDir.clear();
				} else {
					//Delete(S, 1, uiPos); - c ������� 1(0) uiPos ��������
					sDir.erase(0, uiPos + xWIN_SLASH.size()/*1*/);				//-- sDir.erase(0, uiPos);
					sDir = xT("...") + xWIN_SLASH + sDir; 
				}

				if (TRUE == bRoot) {
					sDir = xWIN_SLASH + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO:  - sAppendSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
/*static*/
tString CxPath::sAppendSlash(const tString &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(), tString()); 

	if (xWIN_SLASH.at(0) == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	} else {
		return csDirPath + xWIN_SLASH;
	}
}
//--------------------------------------------------------------------------
//TODO: -  sRemoveSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
/*static*/
tString CxPath::sRemoveSlash(const tString &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(), tString()); 

	const std::size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if (xWIN_SLASH.at(0) == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	} else {
		return csDirPath;
	}
}
//--------------------------------------------------------------------------




/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxPath
CxPath::CxPath() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CxPath
CxPath::~CxPath() {
	//code
}
//---------------------------------------------------------------------------


/*
CommandLineToArgvA
    PCHAR*
    CommandLineToArgvA(
        PCHAR CmdLine,
        int* _argc
        )
    {
        PCHAR* argv;
        PCHAR  _argv;
        ULONG   len;
        ULONG   argc;
        CHAR   a;
        ULONG   i, j;

        BOOLEAN  in_QM;
        BOOLEAN  in_TEXT;
        BOOLEAN  in_SPACE;

        len = strlen(CmdLine);
        i = ((len+2)/2)*sizeof(PVOID) + sizeof(PVOID);

        argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
            i + (len+2)*sizeof(CHAR));

        _argv = (PCHAR)(((PUCHAR)argv)+i);

        argc = 0;
        argv[argc] = _argv;
        in_QM = FALSE;
        in_TEXT = FALSE;
        in_SPACE = TRUE;
        i = 0;
        j = 0;

        while( a = CmdLine[i] ) {
            if(in_QM) {
                if(a == '\"') {
                    in_QM = FALSE;
                } else {
                    _argv[j] = a;
                    j++;
                }
            } else {
                switch(a) {
                case '\"':
                    in_QM = TRUE;
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    in_SPACE = FALSE;
                    break;
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    if(in_TEXT) {
                        _argv[j] = '\0';
                        j++;
                    }
                    in_TEXT = FALSE;
                    in_SPACE = TRUE;
                    break;
                default:
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    _argv[j] = a;
                    j++;
                    in_SPACE = FALSE;
                    break;
                }
            }
            i++;
        }
        _argv[j] = '\0';
        argv[argc] = NULL;

        (*_argc) = argc;
        return argv;
    }
*/

/*

 String
   FileUtilities::GetShortPath(const String &sInPath)
   {
      TCHAR szModuleShort[_MAX_PATH];
      GetShortPathName(sInPath, szModuleShort, _MAX_PATH );

      return szModuleShort;
   }

   String
   FileUtilities::GetLongPath(const String &sInPath)
   {
      TCHAR szLong[_MAX_PATH];
      GetLongPathName(sInPath, szLong, _MAX_PATH );

      return szLong;
   }




//--------------------------------------------------------------------------
*/