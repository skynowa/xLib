/****************************************************************************
* Class name:  CxTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CxTraceLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Log/CxTraceLog.h>

#include <XLib/CxString.h>
#include <XLib/Fso/CxPath.h>
//---------------------------------------------------------------------------
//TODO: + CxTraceLog ()
CxTraceLog::CxTraceLog(BOOL bIsNeedTimeStr) :
	_m_bIsNeedTimeStr(bIsNeedTimeStr)
{
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CxTraceLog ()
CxTraceLog::~CxTraceLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CxTraceLog::bWrite(LPCTSTR pcszFormat, ...) {  
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tString    sTime;
	SYSTEMTIME stST = {0};

	if (TRUE == _m_bIsNeedTimeStr) {
		::GetLocalTime(&stST);
		sTime = CxString::sFormat(xT("[%.2d:%.2d:%.2d] "), stST.wHour, stST.wMinute, stST.wSecond);
	} else {
		sTime = xT("");
	}

	//-------------------------------------
	//���������
	tString sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = CxString::sFormatV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	::OutputDebugString((sTime + sParam + xLF).c_str());
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------