/****************************************************************************
* Class name:  CxMimeBody
* Description: ���� ��������� ������ (RFC 822)
* File name:   CxMimeBody.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.07.2009 19:11:02
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CxMimeBody.h>
//---------------------------------------------------------------------------
CxMimeBody::CxMimeBody() {
	//code
}
//---------------------------------------------------------------------------
CxMimeBody::~CxMimeBody() {
	//code
}
//---------------------------------------------------------------------------
