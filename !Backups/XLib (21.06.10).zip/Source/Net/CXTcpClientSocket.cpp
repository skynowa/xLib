/****************************************************************************
* Class name:  CxTcpClientSocket
* Description: 
* File name:   CxTcpClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/Net/CxTcpClientSocket.h> 

#include <iostream> 
#include <XLib/CxString.h>   
//---------------------------------------------------------------------------  
//TODO: + CxTcpClientSocket
CxTcpClientSocket::CxTcpClientSocket() {   
	bSetTimeout(0, COptions::SOCKET_TIMEOUT);
} 
//---------------------------------------------------------------------------  
//TODO: + CxTcpClientSocket
CxTcpClientSocket::CxTcpClientSocket(SOCKET puiSocket) {  
    bSetTimeout(0, COptions::SOCKET_TIMEOUT);
}   
//---------------------------------------------------------------------------   
//TODO: + ~CxTcpClientSocket
CxTcpClientSocket::~CxTcpClientSocket() {
	/*DEBUG*/xASSERT(INVALID_SOCKET == _m_puiSocket);
}   
//---------------------------------------------------------------------------
//TODO: bIoctl (The ioctlsocket function controls the I/O mode of a socket.)
BOOL CxTcpClientSocket::bIoctl(LONG liCmd, ULONG *pulArgp) {
	/*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

	INT iRes = etError;

	iRes = ::ioctlsocket(_m_puiSocket, liCmd, pulArgp);
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetNonBlockingMode
BOOL CxTcpClientSocket::bSetNonBlockingMode(const BOOL cbFlag) {
	BOOL bRes = FALSE;

#ifdef WIN32	
	ULONG ulNonBlockingMode = (ULONG)cbFlag;
	bRes = bIoctl(FIONBIO, (ULONG FAR *)&ulNonBlockingMode);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 
#else
	INT opts;

	opts = fcntl(m_sock, F_GETFL);

	if (opts < 0) { 
		return FALSE; 
	}

	if (cbFlag) {
		opts = (opts | O_NONBLOCK);
	} else {
		opts = (opts & ~O_NONBLOCK);
	}

	fcntl(m_sock, F_SETFL, opts);
#endif

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsReadible
BOOL CxTcpClientSocket::bIsReadable() {   
	timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	fd_set  fds       = {0};  FD_ZERO(&fds);   

	FD_SET(_m_puiSocket, &fds); 

	INT iStatus = etError;

	iStatus = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	xCHECK_RET(etError == iStatus || 0 == iStatus, FALSE);   

	return TRUE;
}  
//--------------------------------------------------------------------------- 
//TODO: + bConnect
BOOL CxTcpClientSocket::bConnect(const std::string &csIp, USHORT usPort) { 
	/*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket,   FALSE);
	/*DEBUG*/xASSERT_RET(false          == csIp.empty(),   FALSE);
    /*DEBUG*/xASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	INT iRes = etError;
	
	struct sockaddr_in saSockAddr = {0};		   
	saSockAddr.sin_family      = AF_INET; 
	saSockAddr.sin_addr.s_addr = inet_addr(csIp.c_str());   
	saSockAddr.sin_port        = ::htons(usPort); //???????

	//connect - [+] 0 [-] SOCKET_ERROR
	iRes = ::connect(_m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(struct sockaddr_in));  
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);

	return TRUE;   
}   
//---------------------------------------------------------------------------
BOOL CxTcpClientSocket::bSetTimeout(LONG liSec, LONG liMicroSec) {
	/*DEBUG*/
	
	_m_tvTimeout.tv_sec  = liSec;
	_m_tvTimeout.tv_usec = liMicroSec;
	
	return TRUE;
} 
//---------------------------------------------------------------------------
BOOL CxTcpClientSocket::bGetTimeout(LONG *pliSec, LONG *pliMicroSec) {
	/*DEBUG*/
	
	*pliSec      = _m_tvTimeout.tv_sec;
	*pliMicroSec = _m_tvTimeout.tv_usec;
	
	return TRUE;
} 
//---------------------------------------------------------------------------






/*
//////-------------------------------------
//////��������� �������� ��������
////timeval ReceiveTimeout = {0};
////ReceiveTimeout.tv_sec  = 0;
////ReceiveTimeout.tv_usec = COptions::SOCKET_TIMEOUT;              

////fd_set fds = {0};
////FD_ZERO(&fds);
////FD_SET(_m_puiSocket, &fds);

//-------------------------------------
//������ �� ������

////FD_CLR(_m_puiSocket, &fds);
*/