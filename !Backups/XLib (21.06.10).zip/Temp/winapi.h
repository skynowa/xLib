#ifndef WINAPI_H
#define WINAPI_H

/* Copyright (c) 2004-2007 Alex Martynov, amart at mail dot ru
 */

// define WINAPI_IN_MARTY_NAMESPACE for use ::marty::winapi::* insted of ::winapi::*
// also you can define MARTY_NAMESPACE macro, which automaticaly define WINAPI_IN_MARTY_NAMESPACE

#ifdef MARTY_NAMESPACE
    #ifndef WINAPI_IN_MARTY_NAMESPACE
        #define WINAPI_IN_MARTY_NAMESPACE
    #endif
#endif


#if !defined(_WINDOWS_)
    #include <windows.h>
#endif

#if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
    #include <malloc.h>
#endif

#ifndef __CHAR_T_H_INCLUDED__
    #include <char_t.h>
#endif


#if !defined(WINAPI_NO_SHFOLDER)

#ifndef _SHFOLDER_H_
    #include <ShFolder.h>
#endif

#endif /* WINAPI_NO_SHFOLDER */



#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


#ifndef FILENAME_OLD_NAMES
    #define FILENAME_OLD_NAMES
#endif

#ifndef FILENAME_H
    #include <filename.h>
#endif


#ifdef WINAPI_IN_MARTY_NAMESPACE
namespace marty {
#endif


namespace winapi
{

#ifndef FILENAME_USING_TSTRING
    #ifdef FILENAME_IN_MARTY_NAMESPACE
        using ::marty::filename::tstring;
    #else
        using ::filename::tstring;
    #endif
#endif

/*
   getter(TCHAR *buf, size_t size)
*/

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
/*
struct TGetter
{
   TGetter() {}
   DWORD operator() (TCHAR *buf, size_t size) const
      { return ::WiapiCall( ... , buf, (DWORD)size); }
};
*/

// ������ ������������ ��� ��������� ������� WinAPI �������.
// T getter �������� ��������� �� ����� � ������ ������,
// �������� ������ WinAPI �����, ��������� ��� �������������
// �������������� ���������. ��������� ������� ������ ��������� � ������ ���� 
// �������, ������� ��� ������������� ����� ������ ���������� ��� �� �����.
// ������ getApiStringValue ��������� ��� �������� �������� getter, �� ��� ��� ����
// ������������ ����� �� ����� ������ ����������. 
// getApiStringValue ������������� ��������� ��������� ������. � ������ ����������
// ������������ __alloca � ����������� ������� ���������� ������ � ��� ���� ��� �������.
// ������ ������ ������ ����� ������� ����� ��������� ������� (���� �������� ����� getter,
// ������� ������ ��� ��������� � ���������� ���� �������-�������), �� ����� �������
// ����� �������� ��������� ��������� ������ ��� �������������.

template <typename T>
tstring getApiStringValue(const T &getter)
   {
    size_t size = 1024;
    TCHAR *buf = (TCHAR*)_alloca(size*sizeof(buf[0]));
    DWORD res = getter( buf, size);
    while(res==size)
       {
        size *= 2;
        buf = (TCHAR*)_alloca(size*sizeof(buf[0]));
        res = getter( buf, size);
       }
    buf[res] = 0;
    return tstring(buf);
   }
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

template <typename ProcType>
ProcType getProcAddress(HMODULE hModule, const char *procName)
   {
    return (ProcType)::GetProcAddress(hModule, procName);
   }



//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

// ���� �� ���������� � �������������� Interlocked ������� ��� ��������� ������������������
class CModule;

class CModuleRefCounted
{
    friend class CModule;

        HMODULE  hModule;
        int      refCount;

    public:

        CModuleRefCounted(HMODULE hModule) : hModule(hModule), refCount(1) {}
        int addRef()  { return ++refCount; }
        int release()         
           {
            int res = --refCount;
            if (res<=0)
               {
                if (hModule) ::FreeLibrary(hModule);
                delete this;
               }
            return res;
           }
};


// CModule - ������������ ��� �������� � stl-����������� map, vector
class CModule
{
        CModuleRefCounted *pRefCountedHModule;

    public:

        CModule(const TCHAR *modName)
           : pRefCountedHModule(0)
           { 
            pRefCountedHModule = new CModuleRefCounted(
                                                       modName 
                                                       ? ::LoadLibrary(modName)
                                                       : (HMODULE)0
                                                      );
           }

        CModule(const tstring &modName)
           : pRefCountedHModule(0)
           { 
            pRefCountedHModule = new CModuleRefCounted(
                                                       !modName.empty()
                                                       ? ::LoadLibrary(modName.c_str())
                                                       : (HMODULE)0
                                                      );
           }

        CModule(HMODULE hModule)
           : pRefCountedHModule(0)
           {
            pRefCountedHModule = new CModuleRefCounted(hModule);
           }

        CModule(const CModule &cmod)
           : pRefCountedHModule(cmod.pRefCountedHModule)
           {
            if (pRefCountedHModule) pRefCountedHModule->addRef();
           }

        CModule& operator=(const CModule &cmod)
           {
            if (&cmod==this) return *this;
            CModuleRefCounted  *pOldRefCountedHModule = pRefCountedHModule;
            pRefCountedHModule = cmod.pRefCountedHModule;
            if (pRefCountedHModule)    pRefCountedHModule->addRef();
            if (pOldRefCountedHModule) pOldRefCountedHModule->release();
            return *this;
           }

        ~CModule()
           { 
            if (pRefCountedHModule) pRefCountedHModule->release();
           }

        operator HMODULE () const
           {
            if (!pRefCountedHModule) return 0;
            return pRefCountedHModule->hModule;
           }

        bool operator!() const
           {
            if (!pRefCountedHModule) return true;
            return pRefCountedHModule->hModule==0;
           }

        template <typename ProcType>
        ProcType getProcAddress(const char *procName)
           {
            if (!pRefCountedHModule) return 0;
            return winapi::getProcAddress<ProcType>(pRefCountedHModule->hModule, procName);
           }
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// getter
struct CGetModuleFileName
{
    HMODULE hModule;
    CGetModuleFileName(HMODULE hModule) : hModule(hModule) {}
    DWORD operator() (TCHAR *buf, size_t size) const
       { return ::GetModuleFileName( hModule, buf, (DWORD)size); }
};

inline
tstring getModuleFileName(HMODULE hModule)
   {
    return getApiStringValue(CGetModuleFileName(hModule));
   }
//-----------------------------------------------------------------------------
inline
tstring getSystemDirectory()
   {
    TCHAR ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetSystemDirectory(buf, 1);
    buf = (TCHAR*)_alloca(size);
    ::GetSystemDirectory(buf, size);
    return tstring(buf);
   }
//-------------------------------------------------------------------- 
inline
tstring getWindowsDirectory()
   {
    TCHAR  ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetWindowsDirectory(buf, 1);
    buf = (TCHAR*)_alloca(size);
    ::GetWindowsDirectory(buf, size);
    return tstring(buf);
   }
//-------------------------------------------------------------------- 
inline
tstring getCurrentDirectory()
   {
    TCHAR  ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetCurrentDirectory(1, buf);
    buf = (TCHAR*)_alloca(size);
    ::GetCurrentDirectory(size, buf);
    return tstring(buf);
   }






//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------


/* #ifndef CSIDL_FLAG_CREATE
 *     #define CSIDL_FLAG_CREATE               0x8000        // combine with CSIDL_ value to force folder creation in SHGetFolderPath()
 * #endif
 *  
 * #ifndef CSIDL_FLAG_DONT_VERIFY
 *     #define CSIDL_FLAG_DONT_VERIFY          0x4000        // combine with CSIDL_ value to return an unverified folder path
 * #endif
 *  
 * #ifndef CSIDL_FLAG_MASK
 *     #define CSIDL_FLAG_MASK                 0xFF00        // mask for all possible flag values
 * #endif
 */

/* typedef HRESULT (__stdcall * PFNSHGETFOLDERPATHA)(HWND, int, HANDLE, DWORD, LPSTR);  // "SHGetFolderPathA"
 * typedef HRESULT (__stdcall * PFNSHGETFOLDERPATHW)(HWND, int, HANDLE, DWORD, LPWSTR); // "SHGetFolderPathW"
 *  
 * #ifdef UNICODE
 * #define SHGetFolderPath     SHGetFolderPathW
 * #define PFNSHGETFOLDERPATH  PFNSHGETFOLDERPATHW
 * #else
 * #define SHGetFolderPath     SHGetFolderPathA
 * #define PFNSHGETFOLDERPATH  PFNSHGETFOLDERPATHA
 * #endif
 */

#if !defined(WINAPI_NO_SHFOLDER)

#define SHGETFOLDERPATHA_PROCNAME "SHGetFolderPathA"
#define SHGETFOLDERPATHW_PROCNAME "SHGetFolderPathW"

#if defined(_UNICODE) || defined(UNICODE)
    #define SHGETFOLDERPATH_PROCNAME  SHGETFOLDERPATHW_PROCNAME
#else
    #define SHGETFOLDERPATH_PROCNAME  SHGETFOLDERPATHA_PROCNAME
#endif


// ������� ��� ShGetFolderPath - ����� ���������� false �� ������ ��������,
// ��� ��� ����� �������, 
inline
bool shGetFolderPath( HWND hwndOwner,
                      int nFolder,
                      tstring &path,
                      DWORD dwFlags
                    )
   {
    CModule mod(_T("shell32.dll"));

    PFNSHGETFOLDERPATH proc = mod.getProcAddress<PFNSHGETFOLDERPATH>(SHGETFOLDERPATH_PROCNAME);
    if (!proc) return false;

    TCHAR buf[MAX_PATH];
    HRESULT hRes = proc(hwndOwner, nFolder, 0, dwFlags, buf);
    if (hRes==S_FALSE) return false;
    if (hRes==E_FAIL) return false;
    if (hRes==E_INVALIDARG ) return false;

    if (hRes==S_OK)
    //if (S_OK==proc(hwndOwner, nFolder, 0, dwFlags, buf))
       {
        path = buf;
        return true;
       }

    return false;
   }

#endif /* WINAPI_NO_SHFOLDER */


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
inline
tstring makeUnicodeLongFilename(const tstring &name)
   {
    if (name.size()>=3 && (tstring(name, 0, 3)==_T("\\\\.") || tstring(name, 0, 3)==_T("\\\\?")) )
       {
        // already long name or device name (such as \\.\COMX)
        return name; // return untouched name
       }

    const TCHAR* sepList = _T("/\\");
    const TCHAR sep = _T('\\');

    if (filename::isDriveAbsolutePath(name, sepList)) // make \\?\D:\<path> 
       return tstring(_T("\\\\?\\")) + filename::canonical(name, sepList, sep );

    if (filename::isUncAbsolutePath(name, sepList)) // make \\?\UNC\Server\Share from \\Server\Share
       return tstring(_T("\\\\?\\UNC")) + tstring(filename::canonical(name, sepList, sep ), 1, tstring::npos);

    return name; // other names can't be longer than 260 chars
   }
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
#if defined(UNICODE) || defined(_UNICODE)
     // do not touch WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    //#if defined(WINAPI_DISABLE_UNICODE_LONG_FILENAMES_SUPPORT)
#else /* ANSI verison compiled, force disable lfn support */
    #if !defined(WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT)
        #define WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    #endif
#endif
    
//-----------------------------------------------------------------------------
    



//-----------------------------------------------------------------------------
// FindFirstFile/FindNextFile wrappers
//-----------------------------------------------------------------------------


/* Sample handler
 * struct CPrintFileFindData
 * {
 *     bool operator(tstring &path, const WIN32_FIND_DATA &fndData)
 *        {
 *         std::cout<<getAttrString(fndData.dwFileAttributes)<<"  "<<fndData.cFileName<<"\n";
 *         return true;
 *        }
 * }
 */


//-----------------------------------------------------------------------------
// ����� ����� �� �����
// ������� ������ ������� ��� WinAPI ������� FindFirstFile/FindNextFile
template <typename TFindHandler>
DWORD findFile(const tstring path, const tstring mask, TFindHandler handler)
   {
    tstring pathMask = filename::appendPath(path,  
                                            (mask.empty() ? tstring(_T("*")) : mask),
                                            _T("/\\"), _T('\\')
                                           );
    #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    pathMask = makeUnicodeLongFilename(pathMask);
    #endif

    WIN32_FIND_DATA fndData;
    HANDLE hFind = ::FindFirstFile( pathMask.c_str(), &fndData );
    if (hFind==INVALID_HANDLE_VALUE) return ::GetLastError();

    /* if (!handler(path, fndData))
     *    { 
     *     CloseHandle(hFind);
     *     return 0;
     *    }
     */

    do{
       if (!handler(path, fndData))
          break;
      } while(::FindNextFile( hFind, &fndData ));

    /* while(::FindNextFile( hFind, &fndData ))
     *    {
     *     if (!handler(path, fndData))
     *        break;
     *    }
     */

    ::FindClose(hFind);
    return 0;
   }

//-----------------------------------------------------------------------------
// Borland C++ can't convert char to tstring
//#ifdef __BORLANDC__
template <typename TFindHandler>
DWORD findFile(const TCHAR* path, const tstring &mask, TFindHandler handler)
   {
    findFile(tstring(path), mask, handler);
   }
template <typename TFindHandler>
DWORD findFile(const tstring &path, const TCHAR* &mask, TFindHandler handler)
   {
    findFile(path, tstring(mask), handler);
   }
template <typename TFindHandler>
DWORD findFile(const TCHAR* path, const TCHAR* mask, TFindHandler handler)
   {
    findFile(tstring(path), tstring(mask), handler);
   }
//#endif

//-----------------------------------------------------------------------------
template <typename TFindHandler>
DWORD findFile(const tstring pathMask, TFindHandler handler)
   {
    return findFile(filename::path( pathMask, _T("/\\")), filename::file( pathMask, _T("/\\")), handler);
   }

//#ifdef __BORLANDC__
template <typename TFindHandler>
DWORD findFile(const TCHAR* pathMask, TFindHandler handler)
   {
    return findFile(filename::path( pathMask, _T("/\\")), filename::file( pathMask, _T("/\\")), handler);
   }
//#endif

//-----------------------------------------------------------------------------

namespace utils
{

struct CFindCounter
{
    int &count;
    CFindCounter(int &c) : count(c) {}
    bool operator()(const tstring &path, const WIN32_FIND_DATA &fndData)
       { ++count; return true; }

};

}; // namespace utils


//-----------------------------------------------------------------------------
// return number of found files
/* mask allowed */
int fileExist(const tstring &pathName )
   {
    int counter = 0;
    findFile<utils::CFindCounter>(pathName, utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(pathName, winapi::utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(winapi::utils::CFindCounter(counter), pathName, tstring(_T("*")));
    return counter;
   }


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

namespace utils
{

//-----------------------------------------------------------------------------
struct removeTralingSlash
{
    void operator() (tstring &path)
       { filename::pathRemoveTrailingSlashInplace(path, _T("/\\")); }
};

//-----------------------------------------------------------------------------
// ��������� ���� � ������, ���� ��� ��� ������ ���
void addPathIfNotFound(std::vector<tstring> &pathList, const tstring& path, const tstring& subDir, const std::vector<tstring> *pExcludePathList)
   {
    tstring newPath = filename::appendPath(path, subDir, _T("/\\"), _T('\\'));

    std::vector<tstring>::const_iterator it = std::find_if(
                                                     pathList.begin(),
                                                     pathList.end(),
                                                     filename::compareTo<filename::compareProcType>(newPath, filename::equal)
                                                    );
    if (it!=pathList.end())
       return; // path allready in list

    if (pExcludePathList)
       {
        it = std::find_if(
                          pExcludePathList->begin(),
                          pExcludePathList->end(),
                          filename::compareTo<filename::compareProcType>(newPath, filename::equal)
                         );
        if (it!=pExcludePathList->end())
           return; // path found in exclude list
       }

    pathList.push_back(newPath);
   }

//-----------------------------------------------------------------------------
template <typename TH>
struct CFindFilesRecurceProxy
{
    TH                    handler;
    bool                  recurceAllowed;
    bool                  buildDirListMode;
    bool                  callHandlerAllowed;
    std::vector<tstring>  &pathList;
    const std::vector<tstring> * pExcludePathList;
    bool                  &breakFlag;

    CFindFilesRecurceProxy( TH h, 
                            std::vector<tstring> &pl,
                            const std::vector<tstring> *pEx,
                            bool bRecurce,
                            bool bdl,
                            bool cha,
                            bool &brf)
       : handler(h)
       , pathList(pl)
       , pExcludePathList(pEx)
       , recurceAllowed(bRecurce)
       , buildDirListMode(bdl)
       , callHandlerAllowed(cha)
       , breakFlag(brf)
       { }

    void setup( bool bRecurce, bool bdl, bool cha)
       {
        recurceAllowed     = bRecurce;
        buildDirListMode    = bdl;
        callHandlerAllowed = cha;
        //breakFlag = false;
       }


    bool operator()(const tstring &path, const WIN32_FIND_DATA &fndData)
       {
        if ((fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) && recurceAllowed && buildDirListMode)
           {
            if (fndData.cFileName!=tstring(_T(".")) && fndData.cFileName!=tstring(_T("..")))
               addPathIfNotFound( pathList, path, fndData.cFileName, pExcludePathList);
            //std::cout<<"*** PathList size: "<<(unsigned)pathList.size()<<"\n";
           }

        if (callHandlerAllowed)
           {
            if (!handler(path, fndData))
               {
                breakFlag = true;
                return false;
               }
           }
        return true;
       }
}; // struct CFindFilesRecurceProxy

}; // namespace utils

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// ����������� ����� �� �����. ��������������� �������
// ���� ����� ������ �������� �� *, �� ������� ������������ ����� ��������� �� ����� *
template <typename TFindHandler>
DWORD findFileAux( const std::vector<tstring> &pathList, 
                   const std::vector<tstring> *pExcludePathList, 
                   const tstring &mask, 
                   TFindHandler handler, 
                   bool traverseSubFolders)
   {
    std::vector<tstring> pathListCopy = pathList;
    std::for_each(pathListCopy.begin(), pathListCopy.end(), utils::removeTralingSlash());

    bool breakFlag = false;
    utils::CFindFilesRecurceProxy<TFindHandler> proxy(handler, pathListCopy, pExcludePathList, true, true, false, breakFlag);

    if (mask!=_T("*") && traverseSubFolders)
       {
        std::vector<tstring>::size_type i = 0;
        for(; i<pathListCopy.size(); ++i)
            findFile(pathListCopy[i], _T("*"), proxy);
       }

    proxy.setup( traverseSubFolders, mask==_T("*") && traverseSubFolders, true);
    std::vector<tstring>::size_type i = 0;
    for(; i<pathListCopy.size(); ++i)
       {
        findFile( pathListCopy[i], mask, proxy);
        if (breakFlag) return 0;
       }

    return 0;
   }

// 
template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList, 
                const std::vector<tstring> &excludePathList, 
                const tstring &mask, 
                TFindHandler handler, 
                bool traverseSubFolders)
   {
    return findFileAux( pathList, &excludePathList, mask, handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList, 
                const std::vector<tstring> &excludePathList, 
                const TCHAR *mask, 
                TFindHandler handler, 
                bool traverseSubFolders)
   {
    return findFileAux( pathList, &excludePathList, tstring(mask), handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList, 
                const tstring &mask, 
                TFindHandler handler, 
                bool traverseSubFolders)
   {
    return findFileAux( pathList, 0, mask, handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList, 
                const TCHAR *mask, 
                TFindHandler handler, 
                bool traverseSubFolders)
   {
    return findFileAux( pathList, 0, tstring(mask), handler, traverseSubFolders);
   }

/*  
 *  
 * template <typename TFindHandler>
 * DWORD findFile(const std::vector<tstring> &pathList, const TCHAR *mask, TFindHandler handler, bool traverseSubFolders = true)
 *    {
 *     return findFile(pathList, tstring(mask), handler, traverseSubFolders);
 *    }
 */


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
struct CWin32EnumDrivesData
{
    TCHAR     driveName[4];
    UINT      driveType;

    BOOL      driveInfoValid;
    TCHAR     volumeName[_MAX_PATH];
    DWORD     volumeSerial;
    DWORD     maxComponentLength;
    DWORD     filesystemFlags;
    TCHAR     filesystemName[_MAX_PATH];

    BOOL      spaceInfoValid;
    DWORD     sectorsPerCluster;
    DWORD     bytesPerSector;
    DWORD     numOfFreeClusters;
    DWORD     numOfTotalClusters;

};


// void Handler(const CWin32EnumDrivesData &enumData)

template <typename THandler>
void enumLogicalDrives(THandler handler)
   {
    CWin32EnumDrivesData enumData;
    tstrcpy(enumData.driveName, _T("C:\\"));

    DWORD logicalDrivesMask = ::GetLogicalDrives();
    for(TCHAR driveLetter=_T('A'); driveLetter<=_T('Z'); ++driveLetter, logicalDrivesMask>>=1)
       {
        if (!(logicalDrivesMask&1)) continue;
        enumData.driveName[0] = driveLetter;
        enumData.driveType = ::GetDriveType(enumData.driveName);

        enumData.driveInfoValid = ::GetVolumeInformation( enumData.driveName,
                                                          enumData.volumeName,
                                                          DWORD(sizeof(enumData.volumeName)/sizeof(enumData.volumeName[0])),
                                                          &enumData.volumeSerial,
                                                          &enumData.maxComponentLength,
                                                          &enumData.filesystemFlags,
                                                          enumData.filesystemName,
                                                          DWORD(sizeof(enumData.filesystemName)/sizeof(enumData.filesystemName[0]))
                                                        );
        enumData.spaceInfoValid = ::GetDiskFreeSpace( enumData.driveName,
                                                      &enumData.sectorsPerCluster,
                                                      &enumData.bytesPerSector,
                                                      &enumData.numOfFreeClusters,
                                                      &enumData.numOfTotalClusters
                                                    );
        handler(enumData);
       }
   
   }





}; // namespace winapi

#ifdef WINAPI_IN_MARTY_NAMESPACE
}; // namespace marty
#endif



#endif /* WINAPI_H */

