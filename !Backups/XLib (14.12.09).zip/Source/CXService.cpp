/****************************************************************************
* Class name:  CXService
* Description: ������ � ��������
* File name:   CXService.cpp
* Compilers:   Visual C++ 2008
* std::string type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     20.07.2009 16:23:36
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXService.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
//TODO: + CXService
CXService::CXService() {

}
//---------------------------------------------------------------------------
//TODO: + ~CXService
CXService::~CXService() {

}
//---------------------------------------------------------------------------
//TODO: bRegisterService (Registres a service with the SCM. (adds the application to the list of services))
BOOL CXService::bRegisterService(const std::string &csServiceName, const std::string &ServiceCaption) {
	// Retrieve the handle for the local service manager.
	SC_HANDLE hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE | SC_MANAGER_LOCK);

	if (hSCManager == NULL)
	{
		////std::string sErrorMessage;
		////sErrorMessage.Format("Source: CXService::bRegisterService, Description: OpenSCManager failed. (%d)", GetLastError());
		///////////////Logger::Instance()->LogError(sErrorMessage);
		return false;
	}

	// Get the path to the currently running executable
	std::string sPath;
	//////////////sPath = Application::GetExecutableName();
	sPath += " RunAsService";

	// Check wether we should set the service dependent on MySQL.
	LPCTSTR szServiceDependencies;

	if (bDoesServiceExist("hMailServerMySQL"))
		szServiceDependencies = "hMailServerMySQL\0RPCSS\0\0";
	else if (bDoesServiceExist("MSSQLSERVER"))
		szServiceDependencies = "MSSQLSERVER\0RPCSS\0\0";
	else if (bDoesServiceExist("MySql"))
		szServiceDependencies = "MySql\0RPCSS\0\0";
	else
		szServiceDependencies = "RPCSS\0\0";

	// Check wether we already exists.
	if (bDoesServiceExist(csServiceName))
	{
		if (!_bReconfigureService(hSCManager, csServiceName))
			return false;
	}
	else
	{
		SC_HANDLE hService = ::CreateService( hSCManager,
			csServiceName.c_str(),
			ServiceCaption.c_str(),
			GENERIC_EXECUTE | GENERIC_WRITE | GENERIC_READ,
			SERVICE_WIN32_OWN_PROCESS,
			SERVICE_AUTO_START,
			SERVICE_ERROR_NORMAL,
			sPath.c_str(),
			NULL,
			NULL,
			szServiceDependencies,
			NULL,
			NULL
			);  


		if (hService == NULL)
		{
			///////std::string sErrorMessage;
			///////////sErrorMessage.Format("Source: CXService::bRegisterService, Description: CreateService failed. (%d)", GetLastError());
			/////////////Logger::Instance()->LogError(sErrorMessage);
			return false;
		}

		::CloseServiceHandle (hService);

	}


	::CloseServiceHandle (hSCManager);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: vMakeDependentOn (Makes hMailServer dependent on RPCSS and csServiceName)
VOID CXService::vMakeDependentOn(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE | SC_MANAGER_LOCK);

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, "hMailServer", SERVICE_CHANGE_CONFIG );

  SC_LOCK sclLock = ::LockServiceDatabase(hSCManager); 

  if (sclLock == NULL)
  {
	  ::CloseServiceHandle(hService);
     return;
  }

  int iLength = csServiceName.size() + 8;
  char * lpDependent = new char[iLength];
  memset(lpDependent, 0, iLength);
  strcpy(lpDependent, "RPCSS");
  strcpy(lpDependent+6, csServiceName.c_str());
  
  int iRet = ::ChangeServiceConfig( 
     hService,        // handle of service 
     SERVICE_NO_CHANGE, // service type: no change 
     SERVICE_NO_CHANGE, // service start type no change
     SERVICE_NO_CHANGE, // error control: no change 
     NULL,            // binary path changed
     NULL,              // load order group: no change 
     NULL,              // tag ID: no change 
     lpDependent,      // dependencies: no change 
     NULL,              // account name: no change 
     NULL,              // password: no change 
     NULL);             // display name: no change


  ::CloseServiceHandle(hService); 
  ::UnlockServiceDatabase(sclLock); 
}
//---------------------------------------------------------------------------  
//TODO: bUnregisterService (Deregisters a service. (removes the service from the list of services))
BOOL CXService::bUnregisterService(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CREATE_SERVICE );

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_ALL_ACCESS );

  if (!hService)
  {
	  ::CloseServiceHandle (hSCManager);
     return FALSE;
  }

  ::DeleteService(hService);

  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  return 0;
}
//---------------------------------------------------------------------------
//TODO: bStartServiceOnLocalComputer (Starts the service with name csServiceName on the local computer.)
BOOL CXService::bStartServiceOnLocalComputer(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CONNECT );

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_START );

  BOOL bResult = ::StartService(hService, 0, NULL);

  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  if (bResult)
     return TRUE;
  else
     return FALSE;

}
//---------------------------------------------------------------------------
//TODO: bStopServiceOnLocalComputer (Stops the service with name csServiceName on the local computer.)
BOOL CXService::bStopServiceOnLocalComputer(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CONNECT );

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_STOP );

  SERVICE_STATUS ssStatus;
  BOOL bResult = ::ControlService(hService, SERVICE_CONTROL_STOP, &ssStatus);

  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  if (bResult)
     return TRUE;
  else
     return FALSE;

}
//---------------------------------------------------------------------------
//TODO: bUserControlService
BOOL CXService::bUserControlService(const std::string &csServiceName, ULONG OpCode) {
   // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, SC_MANAGER_CONNECT );

  if (hSCManager == NULL)
  {
     int err = GetLastError();
     switch (err)
     {
        case ERROR_ACCESS_DENIED:
           ////////Logger::Instance()->LogError("bUserControlService::OpenSCManager failed. The requested access was denied.\n");      
           return false;
        case ERROR_DATABASE_DOES_NOT_EXIST:
           ////////Logger::Instance()->LogError("bUserControlService::OpenSCManager failed. The specified database does not exist.\n");      
           return false;
        case ERROR_INVALID_PARAMETER:
           ////////////Logger::Instance()->LogError("bUserControlService::OpenSCManager failed. A specified parameter is invalid.\n");      
           return false;
     }

  }



  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_USER_DEFINED_CONTROL );

  if (hService == NULL)
  {
     int err = GetLastError();

     switch (err)
     {
        case ERROR_ACCESS_DENIED:
           //////////Logger::Instance()->LogError("bUserControlService::OpenService failed. The specified service control manager database handle does not have access to the service.\n");      
           return false;
        case ERROR_INVALID_HANDLE:
           //////////Logger::Instance()->LogError("bUserControlService::OpenService failed. The specified handle is invalid.\n");      
           return false;
        case ERROR_INVALID_NAME:
           //////////Logger::Instance()->LogError("bUserControlService::OpenService failed. The specified service name is invalid.\n");      
           return false;
        case ERROR_SERVICE_DOES_NOT_EXIST:
           //////////Logger::Instance()->LogError("bUserControlService::OpenService failed. The specified service does not exist.\n");      
           return false;
     }
  }



  // Thell the thserver what to to
  SERVICE_STATUS ssStatus;
  BOOL bResult = ::ControlService(hService, OpCode, &ssStatus);


  if (bResult != 0)
  {
     int err = GetLastError();

     switch (err)
     {
        case ERROR_ACCESS_DENIED:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The specified handle was not opened with the necessary access.\n");      
           return false;
        case ERROR_DEPENDENT_SERVICES_RUNNING:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The service cannot be stopped because other running services are dependent on it.\n");      
           return false;
        case ERROR_INVALID_HANDLE:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The specified handle was not obtained using CreateService or OpenService, or the handle is no longer valid. \n");      
           return false;
        case ERROR_INVALID_PARAMETER:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The requested control code is undefined.\n");      
           return false;
        case ERROR_INVALID_SERVICE_CONTROL:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The requested control code is not valid, or it is unacceptable to the service.\n");      
           return false;
        case ERROR_SERVICE_CANNOT_ACCEPT_CTRL:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The requested control code cannot be sent to the service because the state of the service is SERVICE_STOPPED, SERVICE_START_PENDING, or SERVICE_STOP_PENDING.\n");      
           return false;
        case ERROR_SERVICE_NOT_ACTIVE:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The service has not been started.\n");      
           return false;
        case ERROR_SERVICE_REQUEST_TIMEOUT:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The process for the service was started, but it did not call StartServiceCtrlDispatcher, or the thread that called StartServiceCtrlDispatcher may be blocked in a control handler function.\n");      
           return false;
        case ERROR_SHUTDOWN_IN_PROGRESS:
           //////////Logger::Instance()->LogError("bUserControlService::ControlService failed. The system is shutting down.\n");      
           return false;


     }
  }


  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  if (bResult)
     return TRUE;
  else
     return FALSE;
}
//---------------------------------------------------------------------------
//TODO:  stGetServiceStatus (Stops the service with name csServiceName on the local computer.)
SERVICE_STATUS CXService::stGetServiceStatus(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, GENERIC_READ );

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_QUERY_STATUS );

  SERVICE_STATUS Status;
  BOOL bResult = ::QueryServiceStatus(hService, &Status);

  int e = GetLastError();

  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  return Status;

}
//---------------------------------------------------------------------------
//TODO: bDoesServiceExist
BOOL CXService::bDoesServiceExist(const std::string &csServiceName) {
  // Retrieve the handle for the local service manager.
  SC_HANDLE hSCManager;
  hSCManager = ::OpenSCManager( NULL, NULL, GENERIC_READ );

  // Retrieve the handle for the service.
  SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(), SERVICE_QUERY_STATUS );
  
  ::CloseServiceHandle (hSCManager);
  ::CloseServiceHandle (hService);

  if (hService == NULL)
     return false;
  else
     return true;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: _vSetDependency (Configurs the hService to be dependent on sDependency.)
VOID CXService::_vSetDependency(SC_HANDLE hService, LPTSTR sDependency) {
	if (::ChangeServiceConfig( 
		hService,        // handle of service 
		SERVICE_NO_CHANGE, // service type: no change 
		SERVICE_NO_CHANGE, // service start type no change
		SERVICE_NO_CHANGE, // error control: no change 
		NULL,            // binary path changed
		NULL,              // load order group: no change 
		NULL,              // tag ID: no change 
		sDependency,      // dependencies: no change 
		NULL,              // account name: no change 
		NULL,              // password: no change 
		NULL) == 0)             // display name: no change
	{
		//////std::string sErrorMessage;
		//sErrorMessage.Format("Source: CXService::_vSetDependency, Description: ChangeServiceConfig failed. (%d)", GetLastError());
		//////////Logger::Instance()->LogError(sErrorMessage);
	}
}
//---------------------------------------------------------------------------
//TODO: _bIsServiceDependentOnRPCSS (Returns true if hService is dependent on RPCSS)
BOOL CXService::_bIsServiceDependentOnRPCSS(SC_HANDLE hService) {
	LPQUERY_SERVICE_CONFIG lpqscBuf =  (LPQUERY_SERVICE_CONFIG)::LocalAlloc(LPTR, 4096); 

	ULONG dwBytesNeeded; 
	if (!::QueryServiceConfig(hService, lpqscBuf, 4096, &dwBytesNeeded) ) 
	{
		/////std::string sErrorMessage;
		//////sErrorMessage.Format("Source: CXService::_bIsServiceDependentOnRPCSS, Description: QueryServiceConfig failed. (%d)", GetLastError());
		//////////Logger::Instance()->LogError(sErrorMessage);
		return false;
	}

	LPSTR lpBuf = lpqscBuf->lpDependencies;
	if (*lpBuf == 0)
	{  
		::LocalFree(lpqscBuf);
		return false;
	}

	// Check the length of the dependency string.
	int iLength = _bGetDependencyStringLength(lpBuf);
	if (!iLength)
	{
		// Something went wrong.
		::LocalFree(lpqscBuf);
		return false;
	}

	// Does RPCSS exist in this the dependency string?
	BOOL bFound = FALSE; //////////StringParser::strnstr(lpBuf, "RPCSS", iLength) != NULL;

	// Free the memory structure for the service configuration.
	::LocalFree(lpqscBuf); 

	return bFound;
}
//---------------------------------------------------------------------------
//TODO: _bGetDependencyStringLength 
//Calculates the length of a Service dependency string. The string is a null
//seperated list of other service names. It is ended with two nulls.
//Returns -1 if something goes wrong.
int CXService::_bGetDependencyStringLength(LPTSTR lpString) {
	BOOL bNullFound = false;

	int iCurPos = 0;
	while (1)
	{
		char p = lpString[iCurPos];
		if (p == NULL)
		{
			if (bNullFound)
			{
				//We have found two nulls.
				break;
			}

			bNullFound = true;
		}
		else
			bNullFound = false;

		iCurPos++;

		if (iCurPos > 50)
		{
			// Something has gone wrong.
			/////////////Logger::Instance()->LogError("Source: CXService::_bGetDependencyStringLength, Description: Could not find end of dependency string.");

			return -1;
		}
	}

	return iCurPos + 1;
}
//---------------------------------------------------------------------------
//TODO: _bReconfigureService (Updates an existing hMailServer service.)
BOOL CXService::_bReconfigureService(SC_HANDLE hSCManager, const std::string &csServiceName) {
	// Retrieve the handle for the service.
	SC_HANDLE hService = ::OpenService( hSCManager, csServiceName.c_str(),  SERVICE_QUERY_CONFIG | SERVICE_CHANGE_CONFIG);


	SC_LOCK sclLock = ::LockServiceDatabase(hSCManager); 

	if (sclLock == NULL)
	{
		//////////Logger::Instance()->LogError("Source: CXService::_bReconfigureService, Description: Failed to obtain lock on service database.");
		::CloseServiceHandle(hService);
		return false;
	}

	// Update the path to the executable
	std::string sPath;
	//////////sPath = Application::GetExecutableName();
	sPath += " RunAsService";

	if (::ChangeServiceConfig(
		hService,        // handle of service 
		SERVICE_NO_CHANGE , // service type: no change 
		SERVICE_NO_CHANGE, // service start type no change
		SERVICE_NO_CHANGE, // error control: no change 
		sPath.c_str(),            // binary path changed
		NULL,              // load order group: no change 
		NULL,              // tag ID: no change 
		NULL,              // dependencies: no change 
		NULL,              // account name: no change 
		NULL,              // password: no change 
		NULL) == 0)             // display name: no change
	{
		////std::string sErrorMessage;
		/////sErrorMessage.Format("Source: CXService::_bReconfigureService, Description: ChangeServiceConfig failed. (%d)", GetLastError());
		//////////Logger::Instance()->LogError(sErrorMessage);
		return false;
	}

	// Check if we need to update the dependencies.
	// hMailServer should be dependent on RPCSS and
	// the database server.
	if (!_bIsServiceDependentOnRPCSS(hService))
	{
		// The service is not dependent on RPCSS
		if (bDoesServiceExist("hMailServerMySQL"))
		{
			// Set the service to be dependent on MySQL and RPCSS
			_vSetDependency(hService, "RPCSS\0hMailServerMySQL\0\0");
		}
		else if (bDoesServiceExist("MSSQLSERVER"))
		{
			// Set the service to be dependent on Microsoft SQL Server and RPCSS
			_vSetDependency(hService,"RPCSS\0MSSQLSERVER\0\0");
		}
		else if (bDoesServiceExist("MySql"))
		{
			// Set the service to be dependent on MYSQL and RPCSS
			_vSetDependency(hService,"RPCSS\0MySql\0\0");
		}
		else
		{
			// Set the service to be dependent on just RPCSS.
			_vSetDependency(hService,"RPCSS\0\0");
		}
	}

	// Unlock and release.
	::CloseServiceHandle(hService); 

	::UnlockServiceDatabase(sclLock); 

	::CloseServiceHandle (hSCManager);
	return true;
}
//---------------------------------------------------------------------------