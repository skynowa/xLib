/****************************************************************************
* Class name:  CXWaitCursor
* Description: wait cursor
* File name:   CXWaitCursor.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.06.2009 19:08:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXWaitCursor.h>
//---------------------------------------------------------------------------
//TODO: + CXWaitCursor (Set the cursor remembering the old cursor)
CXWaitCursor::CXWaitCursor() :
	_m_hCursor(NULL)
{
	HCURSOR hRes = NULL;

	hRes = ::LoadCursor(NULL, IDC_WAIT);
	/*DEBUG*/XASSERT_DO(NULL != hRes, return);
	
	_m_hCursor = ::SetCursor(hRes);
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
//TODO: + ~CXWaitCursor (Restore cursor when it was valid. If it was not set the arrow cursor)
CXWaitCursor::~CXWaitCursor() {
	HCURSOR hRes = NULL;

	hRes = ::LoadCursor(NULL, IDC_ARROW);
	/*DEBUG*/XASSERT_DO(NULL != hRes, return);

	::SetCursor(_m_hCursor ? _m_hCursor : hRes);
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
//TODO: + bRestore (Restore the wait cursor)
BOOL CXWaitCursor::bRestore() {
	HCURSOR hRes = NULL;

	hRes = ::LoadCursor(NULL, IDC_WAIT);
	/*DEBUG*/XASSERT_DO(NULL != hRes, FALSE);

	::SetCursor(hRes);
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------