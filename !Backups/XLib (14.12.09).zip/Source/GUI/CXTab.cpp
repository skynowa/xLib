/****************************************************************************
* Class name:  CXTab
* Description: ��������
* File name:   CXTab.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXTab.h>
#include <XLib/GUI/Resource.xrc.h>
#include <XLib/CXString.h>

/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
CXTab::CXTab() :
	_m_iCountSheet(0)
{	
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXTAB_CONTROL_CLASS;
	_m_ulStyle        = CXTAB_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = CXTAB_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXTAB_DEFAULT_WIDTH;
	_m_iHeight        = CXTAB_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXTab
CXTab::~CXTab() {
	LOG();

	for (size_t i = 0; i < _m_vecSheets.size(); i ++) {
		/*DEBUG*/XASSERT(NULL != _m_vecSheets.at(i));

		delete _m_vecSheets.at(i);
		_m_vecSheets.at(i) = NULL;
	}
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXTab::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = _bInitCommonControls(ICC_TAB_CLASSES);
	CHECK_RET(FALSE == bRes, FALSE);

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
							 CXResources::sGetText(iID), 
							 CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
							 CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
							 CXResources::ulGetStyle(iID), 
							 CXResources::ulGetStyleEx(iID),
							 this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXTab::bInsertTab(LPTSTR lpCaption, INT iPos, INT iImage) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd,    FALSE);
	/*DEBUG*/XASSERT_RET(NULL !=  lpCaption, FALSE);
	/*DEBUG*/XASSERT_RET(0    <= iPos,       FALSE);

	BOOL bRes   = FALSE;
	INT  iIndex = - 1;

	TCITEM tci = {0};		
	tci.pszText    = lpCaption;
	tci.cchTextMax = 20;
	tci.mask       = TCIF_IMAGE | TCIF_TEXT;
	tci.iImage     = iImage;
	
	iIndex = (INT)lSendMessage(TCM_INSERTITEM, (WPARAM)(INT)iPos, (LPARAM)&tci);			
	/*DEBUG*/XASSERT_RET(- 1 != iIndex, FALSE);	//Returns the index of the new tab if successful, or -1 otherwise.

	tci.pszText = lpCaption;
    
    
    /*-----------------------*/
    //������� Sheet (����)
    CXSheet *pwndSheet = new CXSheet();
	/*DEBUG*/XASSERT_RET(NULL != pwndSheet, FALSE);

	bRes = pwndSheet->bCreateRes(IDD_WND_SHEET, this->hGetHandle());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	/*DEBUG*/::SetWindowText(pwndSheet->hGetHandle(), lexical_cast(iIndex).c_str());

    //�������� Sheet �� �������
	bRes = bPutSheet(pwndSheet->hGetHandle(), iIndex);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	_m_vecSheets.push_back(pwndSheet); 
	pwndSheet = NULL;
    /*-----------------------*/

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXTab::bShowTab(INT iPos, BOOL bShow) {	
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/XASSERT_RET(0    <= iPos,    FALSE);

	BOOL bRes = FALSE;

	TCITEM tci = {0};		
	tci.mask   = TCIF_PARAM;
	
	bRes = (BOOL)lSendMessage(TCM_GETITEM, (WPARAM)(INT)iPos, (LPARAM)&tci);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	HWND hSheet = reinterpret_cast<HWND>(tci.lParam);
    /*DEBUG*/XASSERT_RET(NULL != hSheet, FALSE);

	bRes = ::ShowWindow(hSheet, bShow ? SW_SHOW : SW_HIDE);
	/*DEBUG*///not need

	bRes = ::EnableWindow(hSheet, bShow ? TRUE : FALSE);
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------
INT CXTab::iGetCurSel() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	INT iRes = - 1;

	iRes = TabCtrl_GetCurSel(this->hGetHandle());
	////iRes = (INT)lSendMessage(TCM_GETCURSEL, 0, 0);	//Returns the index of the selected tab if successful, or -1 if no tab is selected.
	/*DEBUG*/XASSERT_RET(- 1 != iRes, - 1);	    
	
	return iRes;
}
//---------------------------------------------------------------------------
LRESULT CXTab::GetImageList()	{
	/*DEBUG*/XASSERT(bIsWindow());

	return lSendMessage(TCM_GETIMAGELIST, NULL, NULL);
}
//---------------------------------------------------------------------------
HIMAGELIST CXTab::SetImageList(HIMAGELIST lImageList) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

// #define TCM_SETIMAGELIST        (TCM_FIRST + 3)
// #define TabCtrl_SetImageList(hwnd, himl) \
// 		(HIMAGELIST)SNDMSG((hwnd), TCM_SETIMAGELIST, 0, (LPARAM)(HIMAGELIST)(himl))

	return (HIMAGELIST)lSendMessage(TCM_SETIMAGELIST, (WPARAM)NULL, (LPARAM)lImageList);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXTab::bPutSheet(HWND hSheet, INT iPos) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hSheet,  FALSE);
	/*DEBUG*/XASSERT_RET(0    <= iPos,    FALSE);

	BOOL    bRes = FALSE;

	RECT rect = {0};		
	bRes = ::GetClientRect(_m_hWnd, &rect);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	lSendMessage(TCM_ADJUSTRECT, 0, (LPARAM)&rect);
	/*DEBUG*///not return value

	bRes = ::MoveWindow(hSheet, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	TCITEM tci = {0};	 
	tci.mask   = TCIF_PARAM;
	tci.lParam = reinterpret_cast<LPARAM>(hSheet);

	bRes = lSendMessage(TCM_SETITEM, (WPARAM)(INT)iPos, (LPARAM)&tci);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------