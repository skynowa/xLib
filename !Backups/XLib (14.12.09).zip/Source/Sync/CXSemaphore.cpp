/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXSemaphore.h>
//---------------------------------------------------------------------------
//TODO: + CXSemaphore ()
CXSemaphore::CXSemaphore() : 
	_m_hSemaphore(NULL)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CXSemaphore ()
CXSemaphore::~CXSemaphore() {
	/*DEBUG*/XASSERT(NULL != _m_hSemaphore);

	if (NULL != _m_hSemaphore) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(_m_hSemaphore);	_m_hSemaphore = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXSemaphore::hGetHandle() const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, NULL);

	return _m_hSemaphore;
}
//---------------------------------------------------------------------------
//TODO: + bCreate (Creates or opens a named or unnamed semaphore object)
BOOL CXSemaphore::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL == _m_hSemaphore, FALSE);

	HANDLE hRes = NULL;

	hRes = ::CreateSemaphore(lpsaAttributes, liInitialCount, liMaxCount, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hSemaphore = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXSemaphore::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);
	
	HANDLE hRes = NULL;

	hRes = ::OpenSemaphore(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hSemaphore = hRes;
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRelease ()
BOOL CXSemaphore::bRelease(LONG liReleaseCount, LONG *pliOldCount) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);

	BOOL bRes = FALSE;
	
	bRes = ::ReleaseSemaphore(_m_hSemaphore, liReleaseCount, pliOldCount);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXSemaphore::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);

	ULONG ulRes = WAIT_FAILED;

	ulRes = ::WaitForSingleObject(_m_hSemaphore, ulTimeout); 
	/*DEBUG*/XASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------