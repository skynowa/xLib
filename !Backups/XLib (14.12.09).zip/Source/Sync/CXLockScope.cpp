/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ �������� � �����
* File name:   CXLockScope.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXLockScope.h>
//---------------------------------------------------------------------------
//TODO: + CXLockScope ()
CXLockScope::CXLockScope(CXCriticalSection &csCS) : 
    _m_lsLS(csCS) 
{
    _m_lsLS.vEnter();
}
//---------------------------------------------------------------------------
//TODO: + ~CXLockScope ()
CXLockScope::~CXLockScope() {
	_m_lsLS.vLeave();
}
//---------------------------------------------------------------------------