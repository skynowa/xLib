/****************************************************************************
* Class name:  CXMutex
* Description: ������ � ����������
* File name:   CXMutex.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:48:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXMutex.h>
//---------------------------------------------------------------------------
//TODO: + CXMutex ()
CXMutex::CXMutex() : 
	_m_hMutex(NULL)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CXMutex ()
CXMutex::~CXMutex() {
	/*DEBUG*/XASSERT(NULL != _m_hMutex);

	if (NULL != _m_hMutex) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(_m_hMutex);    _m_hMutex = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXMutex::hGetHandle() const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, NULL);

	return _m_hMutex;
}
//---------------------------------------------------------------------------
//TODO: + bCreate ()
BOOL CXMutex::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialOwner, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL == _m_hMutex, FALSE);

	HANDLE hRes = NULL;

	hRes = ::CreateMutex(lpsaAttributes, bInitialOwner, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hMutex = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXMutex::bOpen(ULONG dwAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	HANDLE hRes = NULL;

	hRes = ::OpenMutex(dwAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hMutex = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRelease ()
BOOL CXMutex::bRelease() const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	BOOL bRes = FALSE;

	bRes = ::ReleaseMutex(_m_hMutex);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXMutex::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hMutex, FALSE);

	ULONG ulRes = WAIT_FAILED;

	ulRes = ::WaitForSingleObject(_m_hMutex, ulTimeout); 
	/*DEBUG*/XASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------