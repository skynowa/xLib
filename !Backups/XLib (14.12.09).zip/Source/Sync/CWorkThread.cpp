/****************************************************************************
* Class name:  CWorkThread
* Description: ������� �����
* File name:   CWorkThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2009 22:10:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CWorkThread.h>

#include <XLib/CXString.h>
#include <XLib/Sync/CXThreadPool.h>
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

////////////////extern CXThreadPool *thpTP;
//---------------------------------------------------------------------------
//TODO: - CWorkThread
CWorkThread::CWorkThread(BOOL bIsPaused, BOOL bAutoDelete, BOOL bIsUsingCOM) :
	CXThread (bIsPaused, bAutoDelete, bIsUsingCOM),
	m_uiIndex(0)
{
}
//---------------------------------------------------------------------------
//TODO: - ~CWorkThread
CWorkThread::~CWorkThread() {

}
//---------------------------------------------------------------------------



/****************************************************************************
*    Protected methods                                                       
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - uiOnRun
UINT CWorkThread::uiOnRun(VOID *pData) { 
	/*LOG*/_m_clLog.bWrite(_T("Start thread: #%i\n"), m_uiIndex); 
	
	UINT uiRes = 0;
	BOOL bRes  = FALSE;

	for (INT i = 0; i < /**piParam*/2; i ++, uiRes ++) {
		//-------------------------------------
		//�� ���� �� ����� ��� ���������������
		bRes = bIsTimeToExit();
		CHECK_DO(FALSE == bRes, break);
		
		for (int i = 0; i < 6; i ++) {
			/*LOG*/_m_clLog.bWrite(_T("*\n")); 
			Sleep(500);
		}
	}	

	/*LOG*/_m_clLog.bWrite(_T("End thread: #%i\n"), m_uiIndex); 

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: - vOnEnter
VOID CWorkThread::vOnEnter() {
	//LOG("vOnEnter");
}
//---------------------------------------------------------------------------
//TODO: - vOnExit
VOID CWorkThread::vOnExit() {        
	//LOG("vOnExit");
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------