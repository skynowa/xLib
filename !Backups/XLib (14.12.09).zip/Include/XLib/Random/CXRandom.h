// Copyright 2003 "Gilles Degottex"

// This file is part of "CppAddons"

// "CppAddons" is free software; you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
// 
// "CppAddons" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


#ifndef XLib_Random_RandomH_
#define XLib_Random_RandomH_
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <time.h>
//---------------------------------------------------------------------------
class CXRandom {
	public:
		CXRandom(long seed = time(NULL));

		void   setSeed(long seed);
		static CXRandom s_random;

		int    nextInt();
		int    nextInt(int max);
		int    nextInt(int a, int b);
		long   nextLong();
		bool   nextBoolean();
		float  nextFloat();
		double nextDouble();
		char   nextLetter();
		char   nextFigure();
		double nextGaussian();

	protected:
		long next();

	private:
		static const int A;
		static const int M;
		static const int Q;
		static const int R;

		long   m_seed;
		double m_nextNextGaussian;
		bool   m_haveNextNextGaussian;
};
//---------------------------------------------------------------------------
#endif	XLib_Random_RandomH_

