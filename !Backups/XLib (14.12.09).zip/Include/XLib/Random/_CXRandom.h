/**********************************************************************
*	�����  CXRandom (CXRandom.h)
*
***********************************************************************/


#ifndef CXRandomH
#define CXRandomH     
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXRandom {
		_NO_COPY(CXRandom);
		
	public:
		           CXRandom         ();
		          ~CXRandom         ();

		BOOL       bInitialize      ();
		BOOL       bFinalize        ();
		CHAR       cGetRandomByte   ();
		VOID       vGetRandomBytes  (CHAR  *pszBuff, ULONG ulSize);
		VOID       vGetRandomBytes  (UCHAR *pucBuff, ULONG ulSize); 
		INT        iGetRandomInt    ();
	
	private:
		HCRYPTPROV _m_hCrypt;
};
//---------------------------------------------------------------------------
#endif