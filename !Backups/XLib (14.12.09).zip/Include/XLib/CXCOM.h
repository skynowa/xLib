/****************************************************************************
* Class name:  CXCOM
* Description: ���
* File name:   CXCOM.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2009 15:27:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CXCOMH
#define XLib_CXCOMH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXCOM : public CXNonCopyable {
	public:
		/*
		//the COINIT_APARTMENTTHREADED and COINIT_MULTITHREADED flags cannot both be set
		typedef enum tagCOINIT {
			COINIT_APARTMENTTHREADED   = 0x2,
			COINIT_MULTITHREADED       = 0x0,
			COINIT_DISABLE_OLE1DDE     = 0x4,
			COINIT_SPEED_OVER_MEMORY   = 0x8 
		} COINIT;
		*/
				    CXCOM(ULONG ulCoModel);
		virtual    ~CXCOM();
	
	private:	
		const ULONG _m_culCoModel;	//The concurrency model and initialization options for the thread
};
//---------------------------------------------------------------------------
#endif	//XLib_CXCOMH