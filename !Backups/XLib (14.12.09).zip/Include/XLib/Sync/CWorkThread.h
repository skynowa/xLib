/****************************************************************************
* Class name:  CWorkThread
* Description: ������� �����
* File name:   CWorkThread.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2009 22:10:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CWorkThreadH
#define CWorkThreadH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXThread.h>
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <XLib/Log/CXFileLog.h>
#include <string>
#include <vector>
//---------------------------------------------------------------------------
#define WM_TEST_MSG_1  (WM_USER + 100)
//---------------------------------------------------------------------------
class CWorkThread : public CXThread {
	public:
		size_t       m_uiIndex;

				     CWorkThread(BOOL bIsPaused, BOOL bAutoDelete, BOOL bIsUsingCOM);
			        ~CWorkThread();
	protected:
		virtual UINT uiOnRun    (VOID *pData);	/*overload*/
		virtual VOID vOnEnter   ();			    /*overload*/
		virtual VOID vOnExit    ();			    /*overload*/


	private:
		CXConsoleLog _m_clLog;
};
//---------------------------------------------------------------------------
#endif	//CWorkThreadH