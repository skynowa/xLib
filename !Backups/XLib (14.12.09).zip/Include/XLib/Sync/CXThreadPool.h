/****************************************************************************
* Class name:  CXThreadPool
* Description: ��� �������
* File name:   CXThreadPool.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2009 22:10:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXThreadPoolH
#define XLib_Sync_CXThreadPoolH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXThread.h>
#include <XLib/Sync/CXSemaphore.h>
#include <XLib/Sync/CWorkThread.h>

#include <string>
#include <vector>
#include "closure.h"
////#include <boost\function.hpp>
////#include <boost\bind.hpp>
////#include <functional>
//---------------------------------------------------------------------------
class CXThreadPool : public CXThread {
	public:
								   CXThreadPool(BOOL bIsPaused, BOOL bAutoDelete, BOOL bIsUsingCOM);
							      ~CXThreadPool();
				BOOL               bPushTask   (VOID *pvItem);
				BOOL               bPopTask    (VOID *pvItem);
				
				//��������
				BOOL               bCreateGroup(const pThreadProc _m_ptfStartAddress, VOID *pvParam);
				BOOL               bResumeGroup();
				BOOL               bPauseGroup ();
				BOOL               bExitGroup  (ULONG ulTimeout);
				UINT               uiKillGroup (ULONG ulTimeout);
				BOOL               bWaitGroup  (ULONG ulTimeout) const;

				//

	protected:
		virtual UINT               uiOnRun     (VOID *pData);	/*overload*/
		virtual VOID               vOnEnter    ();				/*overload*/
		virtual VOID               vOnExit     ();				/*overload*/

	private:
		CXConsoleLog               _m_clLog;
		CXSemaphore                _m_semSemaphore;
		std::vector<CWorkThread *> _m_vecpthWorkThreads;

		size_t                     _m_uiMaxRunningTasks;
		size_t                     _m_uiNumTasks;
		size_t                     _m_uiCurrTask;

		VOID                       _vOnExitTask();
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXThreadPoolH