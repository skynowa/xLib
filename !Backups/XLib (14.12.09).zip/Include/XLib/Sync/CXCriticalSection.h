/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ ��������
* File name:   CXLockScope.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXCriticalSectionH
#define XLib_Sync_CXCriticalSectionH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXCriticalSection : public CXNonCopyable {
	public:
		                  CXCriticalSection();
#if (_WIN32_WINNT >= 0x0403)
		explicit          CXCriticalSection(ULONG ulSpinCount);
#endif
		                 ~CXCriticalSection();
		VOID              vEnter           ();
		VOID              vLeave           ();
#if (_WIN32_WINNT >= 0x0403)
		ULONG             ulSetSpinCount   (ULONG ulSpinCount);
#endif
#if (_WIN32_WINNT >= 0x0400)
		BOOL              bTryEnter        ();
#endif

	private:
		CRITICAL_SECTION  _m_CS;
};
//---------------------------------------------------------------------------
#endif	XLib_Sync_CXCriticalSectionH