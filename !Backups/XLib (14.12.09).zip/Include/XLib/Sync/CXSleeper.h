/****************************************************************************
* Class name:  CXSleeper
* Description: ������ ::Sleep()
* File name:   CXSleeper.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.07.2009 12:54:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXSleeperH
#define XLib_Sync_CXSleeperH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXEvent.h>
//---------------------------------------------------------------------------
class CXSleeper : public CXNonCopyable {
	public:
         	    CXSleeper();
			   ~CXSleeper();
		BOOL    bSleep   (ULONG ulTimeout) const;
		BOOL    bReset   () const;

	private:
        CXEvent _m_objEvent; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXSleeperH