/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ �������� � �����
* File name:   CXLockScope.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXLockScopeH
#define XLib_Sync_CXLockScopeH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXLockScope : public CXNonCopyable {
    public:
						   CXLockScope(CXCriticalSection &csCS);
						  ~CXLockScope();
        
	private:
        CXCriticalSection &_m_lsLS;
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXLockScopeH