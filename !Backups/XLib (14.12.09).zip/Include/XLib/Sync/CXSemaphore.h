/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXSemaphoreH
#define XLib_Sync_CXSemaphoreH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXSemaphore : public CXNonCopyable {
	public:
			   CXSemaphore();
			  ~CXSemaphore();
        HANDLE hGetHandle () const;
		BOOL   bCreate    (PSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCTSTR pcszName);
		BOOL   bOpen      (ULONG ulAccess, BOOL bInheritHandle, LPCTSTR lpszName) ;
		BOOL   bRelease   (LONG liReleaseCount/* = 1*/, LONG *pliOldCount/* = NULL*/)  const;
        BOOL   bWait      (ULONG ulTimeout) const;

	private:
		HANDLE _m_hSemaphore;
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXSemaphoreH