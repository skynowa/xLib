/****************************************************************************
* Class name:  CXDrive
* Description: �������� � �������
* File name:   CXDrive.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:25:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXDriveH
#define XLib_Fso_CXDriveH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <vector>
//---------------------------------------------------------------------------
class CXDrive {
	public:
		//���� ������
		typedef enum {
			dtUnknown   = DRIVE_UNKNOWN,		//The drive type cannot be determined
			dtNoRoot    = DRIVE_NO_ROOT_DIR,	//The root path is invalid
			dtRemovable = DRIVE_REMOVABLE,		//The drive has removable media
			dtFixed     = DRIVE_FIXED,			//The drive has fixed media
			dtRemote    = DRIVE_REMOTE,			//The drive is a remote (network) drive
			dtCdRom     = DRIVE_CDROM,			//The drive is a CD-ROM drive
			dtRam       = DRIVE_RAMDISK 		//The drive is a RAM disk
		} EType;	

			           CXDrive					        ();
			          ~CXDrive					        ();
			              
	    static BOOL    bIsReady					        (const tstring &csDrivePath); 
	    static BOOL    bIsEmpty					        (const tstring &csDrivePath); 
		static BOOL    bGetFreeSpace			        (const tstring &csDirPath, ULONGLONG *lpFreeBytesAvailableToCaller, ULONGLONG *lpTotalNumberOfBytes, ULONGLONG *lpTotalNumberOfFreeBytes); 
		static BOOL    bDefineDosDevice			        (ULONG ulFlags, const tstring &csDeviceName, const tstring &csTargetPath);	
		static BOOL    bDeleteVolumeMountPoint          (const tstring &csVolumeMountPoint);
		static HANDLE  hFindFirstVolume                 (tstring *psVolumeName);
		static HANDLE  hFindFirstVolumeMountPoint       (const tstring &csRootPathName, tstring *psVolumeMountPoint);
		static tstring sFindNextVolume			        (HANDLE hFindVolume);
		static BOOL    bFindNextVolumeMountPoint        (HANDLE hFindVolumeMountPoint, tstring *psVolumeMountPoint);
		static BOOL    bFindVolumeClose		            (HANDLE hFindVolume);
		static BOOL    bFindVolumeMountPointClose       (HANDLE hFindVolumeMountPoint);
		static EType   dtGetType				        (const tstring &csDrivePath);
		static BOOL    bGetLogicalDrives                (std::vector<tstring> *vecsDrives);
		static BOOL    bGetLogicalDrives                (std::vector<tstring> *vecsDrives, EType dtDriveType);
		static tstring sGetLogicalStrings               ();
		static BOOL    bGetInformation			        (const tstring &csDrivePath,
															  LPTSTR             pszVolumeNameBuffer/*out*/,
															  ULONG              ulVolumeNameSize,
															  ULONG             *pulVolumeSerialNumber/*out*/,
															  ULONG             *pulMaximumComponentLength/*out*/,
															  ULONG             *pulFileSystemFlags/*out*/,
															  LPTSTR             pszFileSystemNameBuffer/*out*/,
															  ULONG              ulFileSystemNameSize);
		static tstring sGetVolumeNameForVolumeMountPoint(const tstring &csVolumeMountPoint);
		static tstring sGetVolumePathName               (const tstring &csFileName);
		static tstring sGetVolumePathNamesForVolumeName (const tstring &csVolumeName);
		static tstring sQueryDosDevice                  (const tstring &csDeviceName);
		static BOOL    bSetVolumeLabel                  (const tstring &csRootPathName, const tstring &cslpVolumeName);
		static BOOL    bSetVolumeMountPoint             (const tstring &csVolumeMountPoint, const tstring &csVolumeName);
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXDriveH