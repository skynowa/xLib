/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef	XLib_Fso_CXStdioFileH
#define	XLib_Fso_CXStdioFileH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <io.h>
#include <fcntl.h>
#include <vector>
#include <hash_map>
#include <map>
//---------------------------------------------------------------------------
class CXStdioFile : public CXNonCopyable {
	public:
	    //
	    static enum EErrorType{
			etError = EOF
	    };  

		//File attribute
		static enum EAttributes {
			faInvalid  = - 1,           /*?*/
			faNormal   =  _A_NORMAL,    /* Normal file - No read/write restrictions */
			faReadOnly =  _A_RDONLY,	/* Read only file */
			faHidden   =  _A_HIDDEN,    /* Hidden file */
			faSystem   =  _A_SYSTEM,    /* System file */
			faSubDir   =  _A_SUBDIR,    /* Subdirectory */
			faArchive  =  _A_ARCH ,     /* Archive file */			
		};	
		
		//Translation mode
		static enum ETranslationMode {
			tmText   = _O_TEXT,          /* file mode is text (translated) */
			tmBinary = _O_BINARY         /* file mode is binary (untranslated) */
		};	
		
		//Access mode
		static enum EAccessMode {
			amExistence = 0,	//Existence only
			amWrite     = 2, 	//Write permission
			amRead      = 4,	//Read permission
			amReadWrite = 6		//Read and write permission
		};	
		
		//file position data for the given stream
		static enum EPointerPosition {
			ppBegin = SEEK_SET,	
			ppCurr  = SEEK_CUR,	
			ppEnd   = SEEK_END,
			ppError = - 1L	
		};	
		
		//mode for file buffering
		static enum EBufferingMode {
			bmFull = _IOFBF, 
			bmLine = _IOLBF, 
			bmNo   = _IONBF	 
		};
		
		//Locking action to perform
		static enum ELockingMode {
			/*[BC++]*/ //lmTryLock = _LK_LOCK,		//Locks the specified bytes. If the bytes cannot be locked, the program immediately tries again after 1 second. If, after 10 attempts, the bytes cannot be locked, the constant returns an error.
			/*[BC++]*/ //lmLock    = _LK_NBLCK,		//Locks the specified bytes. If the bytes cannot be locked, the constant returns an error.
			////lmXXX = _LK_NBRLCK,		//Same as _LK_NBLCK.
			////lmXXX = _LK_RLCK,		//Same as _LK_LOCK.
			/*[BC++]*/ //lmUnlock  = _LK_UNLCK		//Unlocks the specified bytes, which must have been previously locked.
		};
		
		//Permission mode
		static enum EPermissionMode {
			pmWrite     = _S_IWRITE,				//Writing permitted
			pmRead      = _S_IREAD,					//Reading permitted
			pmReadWrite = (_S_IREAD | _S_IWRITE)	//Reading and writing permitted
		};
	

			               CXStdioFile         ();	
			              ~CXStdioFile         ();	
			              
		operator           FILE *              ();	
		
		FILE              *pGetFile            ();
		BOOL               bOpen               (const tstring &csFilePath, const tstring &csMode);	
		BOOL               bReopen             (const tstring &csFilePath, const tstring &csMode);	
		tstring            sGetFilePath        ();	
		
		
		/****************************************************************************
		* ������ / ������ �����
		*
		*****************************************************************************/

		size_t             uiRead              (LPVOID pvBuf,         size_t uiCount); 
		size_t             uiWrite             (const LPVOID pcvBuff, size_t uiCount); 

		BOOL               bReadAll            (LPVOID pvBuff,       size_t uiBuffSize, const size_t cuiBlockSize);
		BOOL               bWriteAll           (const LPVOID pcvBuf, size_t uiBuffSize, const size_t cuiBlockSize);
		
		BOOL               bReadLine           (LPTSTR pszStr, size_t uiMaxSize); 
		BOOL               bWriteLine          (const tstring &csStr); 	

		BOOL               bWriteChar          (TCHAR cChar); 
		TCHAR              cReadChar           (); 
		BOOL               bUngetChar          (TCHAR cChar); 
		
		BOOL               bWriteString        (const tstring &csStr); 
				
		static BOOL        bReadFile           (const tstring &csFilePath, std::vector<tstring> *pvecsVector);
		static BOOL        bWriteFile          (const tstring &csFilePath, const std::vector<tstring> *pcvecsVector);
		
		static BOOL        bReadFile           (const tstring &csFilePath, std::map<tstring, tstring> *pmsMap);
		static BOOL        bWriteFile          (const tstring &csFilePath, const std::map<tstring, tstring> &cmsMap);
		/////////////////////////////////	
		

		BOOL               bLocking            (ELockingMode lmMode, LONG liBytes); 
		BOOL               bSetPosition        (LONG lOffset, EPointerPosition fpPos/* = fpBegin*/); 
		LONG               liGetPosition       (); 
		BOOL               bClose              (); 
		BOOL               bFlush              (); 
		LONG               liGetSize           (); 
		BOOL               bChsize             (LONG liSize); 
		BOOL               bSetVBuff           (LPTSTR pszBuff, EBufferingMode bmMode, size_t uiSize); 
		BOOL               bSetMode            (ETranslationMode tmMode); 
		

		
		//Character input/output:
		static TCHAR       cGetCharFromStdin   (); 
		static tstring     sGetStringFromStdin (LPTSTR pszBuff); 
		static BOOL        bWriteCharToStdout  (TCHAR cChar); 
		static BOOL        bWriteStringToStdout(const tstring &csStr);

		//Operations on files:
		static BOOL        bIsExists           (const tstring &csFilePath); 
		static BOOL        bAccess             (const tstring &csFilePath, EAccessMode amMode); 
		static BOOL        bChmod              (const tstring &csFilePath, EPermissionMode pmMode); 
		static BOOL        bRemove             (const tstring &csFilePath); 
		static BOOL        bUnlink             (const tstring &csFilePath);	
		static BOOL        bRename             (const tstring &csOldFilePath,  const tstring &csNewFilePath); 
		static BOOL        bMove               (const tstring &csFilePath,     const tstring &csDirPath); 
		static BOOL        bCopy               (const tstring &csFromFilePath, const tstring &csToFilePath);

		static BOOL        bExec               (const tstring &csFilePath); 
        static tstring     sCreateTempFileName (); 
		static BOOL        bFlushAllOutput     (); 
		static INT         iFlushAll           (); 
		static ULONG       ulLines             (const tstring &csFilePath); 

		//Formatted input/output:
		INT                iFprintf            (LPCTSTR pcszFormat, ...); 
		static INT         iPrintf             (LPCTSTR pcszFormat, ...); 
		static INT         iSprintf            (LPTSTR  pszStr, LPCTSTR pcszFormat, ...); 
		INT                iVfprintf           (LPCTSTR pcszFormat, va_list arg); 
		static INT         iVprintf            (LPCTSTR pcszFormat, va_list arg); 
		static INT         iVsprintf           (LPTSTR  pszStr, LPCTSTR pcszFormat, va_list arg); 

		//Error-handling:
		BOOL               bClearErr           (); 
		BOOL               bIsEof              (); 
		BOOL               bIsError            (); 	
		static BOOL        bPrintError         (const tstring &csStr); 		

		//Macros
		//FILENAME_MAX	Maximum length of file names (constant)
		//TMP_MAX		Number of temporary files (constant)

		/****************************************************************************
		* ������ / ������ ����� (all not tested)
		*
		*****************************************************************************/
		static std::vector<tstring>       vecsReadFile(const tstring &csFilePath); 
		static BOOL                       bReadFile	  (const tstring &csFilePath, std::vector<TCHAR> *pvecchVector); 
		static std::map<tstring, tstring> mapReadFile (const tstring &csFilePath, const tstring &csDelimiter); 
		static BOOL                       bReadFile   (const tstring &csFilePath, tstring &cStr); 


	private:
		FILE              *_m_pFile;
		tstring            _m_sFilePath;
		INT                _iGetHandle         ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXStdioFileH	


/*
"r"		Open a file for reading. The file must exist.
"w"		Create an empty file for writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file. 
"a"		Append to a file. Writing operations append data at the end of the file. The file is created if it does not exist.
"r+"	Open a file for update both reading and writing. The file must exist.
"w+"	Create an empty file for both reading and writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file.
"a+"	Open a file for reading and appending. All writing operations are performed at the end of the file, protecting the previous content to be overwritten. You can re
*/




/*
//setlocale(LC_NUMERIC, "");
//setlocale(LC_ALL, ".ACP" );
//setlocale(LC_ALL,"Russian");
*/


//TODO: std::ifsStream - �� ������ ������� �����