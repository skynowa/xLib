#ifndef XLib_CommonH
#define XLib_CommonH

#ifndef WIN32
////#    error This file is intended only for use with the Microsoft Windows API.
#endif
#ifndef __cplusplus
   #error XLib requires C++ compilation (use a .cpp suffix)
#endif

////////#ifndef STRICT
////////#    define STRICT 1
////////#endif

// Standard constants
#undef FALSE
#undef TRUE
#undef NULL

#define FALSE   0
#define TRUE    1
#define NULL    0

#define XARRAYSIZE(a) (sizeof(a) / sizeof(a[0]))

//-------------------------------------
//
#define STRINGIZE2(x) #x
#define STRINGIZE(x)  STRINGIZE2(x)
#define TODO(text_)   message(__FILE__ "(" STRINGIZE(__LINE__) ") [" __FUNCTION__ "]: warning TODO: [" __FUNCTION__ "] " ## text_)
#define TODO_IMPL     TODO("Implement " __FUNCTION__ " function!")

//////#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")


//---------------------------------------------------------------------------
/*
#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1) 
*/
#define DELETE_POINTER(p)   { if (NULL != (p)) {delete p;    p = NULL;} }
#define DELETE_ARRAY(a)		{ if (NULL != (a)) {delete [] a; a = NULL;} } //++memset
#define RELEASE(p)          { {if (p) {p->Release (); p = NULL;}} } }
#define ZERO_BUFF(x)        { ::ZeroMemory(&x, sizeof(x)) }
#define SIZEOF_ARRAY(array) (sizeof(array) / sizeof(array[0])) }


#define CHECK_HANDLE(h)		( (INVALID_HANDLE_VALUE != h) && (NULL != h) /*&& (FALSE != ::GetHandleInformation(h, &g_ulFlags))*/ )
#define CLOSE_HANDLE(h)		{ if ((INVALID_HANDLE_VALUE != h) && (NULL != h)) {::CloseHandle(h);	h = NULL;} }
//-------------------------------------
// --- Verify validity of a BSTR ---
// Verify that a BSTER really is a BSTR and is handled correctly
// Warning! Fails on BSTRs which contain embedded nulls
// Usage:
//  VERIFY_BSTR(bstrName)
//
#ifdef DEBUG
#    define VERIFY_BSTR(bstr) do {    \
	ASSERT(SysStringLen(bstr) == wcslen(bstr)); \
} while (0)
#else
#    define VERIFY_BSTR(bstr) do {} while (0);
#endif
//-------------------------------------
// --- Verify validity of COM object ---
// Verify that a pointer to a COM object is still valid
//
// Usage:
//   VERIFY_COM_INTERFACE(pFoo);
//
template <class Q>
void VERIFY_COM_INTERFACE (Q *p)
{
#   ifdef DEBUG
	p->AddRef();
	p->Release();
#   endif
}
//-------------------------------------
#define Is9xME ((GetVersion () & 0x80000000) != 0)
//-------------------------------------
//Define min and max for Borland C++, Dev-C++ compatibility
#ifndef max
#    define max(a, b)  { (((a) > (b)) ? (a) : (b)) }
#endif

#ifndef min
#    define min(a, b)  { (((a) < (b)) ? (a) : (b)) }
#endif
//---------------------------------------------------------------------------
//Memory Values
////#ifdef _DEBUG
////#define new DEBUG_NEW
////#undef THIS_FILE
////static char THIS_FILE[] = __FILE__;
////#endif
//---------------------------------------------------------------------------
////Debug checked casts
////
////If you want maximum safety, you should always use dynamic_cast. However, if you feel you must optimize away those costs, use this version of checked_cast. It will ASSERT on a bad cast in Debug builds, but not do the slightly more expensive dynamic_cast in Release builds. 
////
////// checked_cast - Uses fast static_cast in Release build,
////// but checks cast with an ASSERT in Debug.
//////
////// Typical usage:
//////   class Foo { /* ... */  };
//////   class Bar : public Foo { /* ... */  };
//////   Foo * pFoo = new Bar;
//////   Bar * pBar = checked_cast<Bar *>(pFoo);
////
////template <class TypeTo, class TypeFrom>                                         
////TypeTo checked_cast(TypeFrom p)                                                 
////{ 
////	ASSERT(dynamic_cast<TypeTo>(p));                                        
////	return static_cast<TypeTo>(p);                                          
////}           
//---------------------------------------------------------------------------
//ASSERT (_CrtCheckMemory()).
////#define _SECURE_SCL 0

//Remove pointless warning messages
#ifdef _MSC_VER
	#pragma warning (disable : 4511) // copy operator could not be generated
	#pragma warning (disable : 4512) // assignment operator could not be generated
	#pragma warning (disable : 4702) // unreachable code (bugs in Microsoft's STL)
	#pragma warning (disable : 4786) // identifier was truncated
	#pragma warning (disable : 4996) // function or variable may be unsafe (deprecated)
	#ifndef _CRT_SECURE_NO_WARNINGS
		#define _CRT_SECURE_NO_WARNINGS // eliminate deprecation warnings for VS2005
	#endif
#endif // _MSC_VER
#ifdef __BORLANDC__
    #pragma option -w-8027		   // function not expanded inline
#endif

//Required for VS 2008 (fails on XP and Win2000 without this fix)
#ifndef _WIN32_WINNT
  #define _WIN32_WINNT 0x0500
#endif

#ifndef STRICT
  #define STRICT 1
#endif

//Prevent winsock.h #include's.
#define _WINSOCKAPI_            

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf

#include <windows.h>
#include <windowsx.h>
#include <string>
#include <stdio.h>
#include <iostream>
#include <tchar.h>

#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator> 
//---------------------------------------------------------------------------
////typedef std::basic_string<TCHAR> tString;
////typedef std::basic_string<TCHAR> generic_string;
#if defined(UNICODE) || defined(_UNICODE)
	typedef std::wstring        tstring;         
	typedef std::wostringstream tostringstream; 
	typedef std::wistringstream tistringstream;
	typedef std::wifstream      tifstream;      
	typedef std::wofstream      tofstream;  

    #define tcout               std::wcout   
#else   
	typedef std::string         tstring;       
	typedef std::ostringstream  tostringstream; 
	typedef std::istringstream  tistringstream;  
	typedef std::ifstream       tifstream;      
	typedef std::ofstream       tofstream;     

	#define tcout               std::cout      
#endif  /*_UNICODE*/
//---------------------------------------------------------------------------
#include <XLib/CXNonCopyable.hpp>
#include <XLib/Gui/CXMsgBoxT.h>
#include <XLib/Debug/CXAssert.h>
//---------------------------------------------------------------------------
//[xCR]
const std::string  xCR_A             = "\r";
const std::wstring xCR_W             = L"\r";
const tstring      xCR               = _T("\r");

//[xLF]
const std::string  xLF_A             = "\n";
const std::wstring xLF_W             = L"\n";
const tstring      xLF               = _T("\n");

//[xCRLF]
const std::string  xCRLF_A           = xCR_A + xLF_A;
const std::wstring xCRLF_W           = xCR_W + xLF_W;
const tstring      xCRLF             = xCR   + xLF;

//[xCOLON]
const std::string  xCOLON_A          = ":";
const std::wstring xCOLON_W          = L":";
const tstring      xCOLON            = _T(":");

//[xWIN_SLASH]
const std::string  xWIN_SLASH_A      = "\\";
const std::wstring xWIN_SLASH_W      = L"\\";
const tstring      xWIN_SLASH        = _T("\\");

//[xNIX_SLASH]
const std::string  xNIX_SLASH_A      = "/";
const std::wstring xNIX_SLASH_W      = L"/";
const tstring      xNIX_SLASH        = _T("/");

//[xEOL]
const std::string  xEOL_A            = xCRLF_A;
const std::wstring xEOL_W            = xCRLF_W;
const tstring      xEOL              = xCRLF;

//[xDRIVE_DELIM]
const std::string  xDRIVE_DELIM_A    = xCOLON_A;	//DELIM
const std::wstring xDRIVE_DELIM_W    = xCOLON_W;
const tstring      xDRIVE_DELIM      = xCOLON;

//[xPATH_SEP]
const std::string  xPATH_SEP_A       = ";";
const std::wstring xPATH_SEP_W       = L";";
const tstring      xPATH_SEP         = _T(";");

//[xDOT]
const std::string  xDOT_A            = ".";
const std::wstring xDOT_W            = L".";
const tstring      xDOT              = _T(".");

//[xALL_FILES_MASK]
const std::string  xALL_FILES_MASK_A = "*.*";
const std::wstring xALL_FILES_MASK_W = L"*.*";
const tstring      xALL_FILES_MASK   = _T("*.*");

//[xATTR_DELIMITER]
const std::string  xATTR_DELIMITER_A = xCOLON_A;
const std::wstring xATTR_DELIMITER_W = xCOLON_W;
const tstring      xATTR_DELIMITER   = xCOLON;

//[xHORIZ_TAB]
const std::string  xHORIZ_TAB_A      = "\t";
const std::wstring xHORIZ_TAB_W      = L"\t";
const tstring      xHORIZ_TAB_TAB    = _T("\t");

//[xVERT_TAB]
//const std::string  xVERT_TAB_A     = Chr(11);
//const std::wstring xVERT_TAB_W     = L Chr(11);
//const tstring      xVERT_TAB       = _T( Chr(11) );

//[xSPACE]
const std::string  xSPACE_A          = " ";
const std::wstring xSPACE_W          = L" ";
const tstring      xSPACE            = _T(" ");


//---------------------------------------------------------------------------
//xSTATIC_ASSERT(INVALID_HANDLE_VALUE != NULL);
//xSTATIC_ASSERT(NULL                 != INVALID_HANDLE_VALUE);
//xSTATIC_ASSERT(INVALID_HANDLE_VALUE != FALSE);
//xSTATIC_ASSERT(FALSE                != INVALID_HANDLE_VALUE);
//xSTATIC_ASSERT(INVALID_HANDLE_VALUE == (HANDLE)((ULONG) - 1));
//xSTATIC_ASSERT(sizeof(DWORD)        == sizeof(ULONG));

#ifdef INT
#    define INT int
#endif
#ifndef INT
#    define INT int
#endif

#ifndef TRUE
#	define TRUE 1
#endif          
#ifndef FALSE
#	define FALSE 0
#endif
//-------------------------------------
//For compilers lacking Win64 support
#ifndef  GetWindowLongPtr
	#define GetWindowLongPtr   GetWindowLong
	#define SetWindowLongPtr   SetWindowLong
	#define GWLP_WNDPROC       GWL_WNDPROC
	#define GWLP_HINSTANCE     GWL_HINSTANCE
	#define GWLP_ID            GWL_ID
	#define GWLP_USERDATA      GWL_USERDATA
	#define DWLP_DLGPROC       DWL_DLGPROC
	#define DWLP_MSGRESULT     DWL_MSGRESULT
	#define DWLP_USER          DWL_USER
	#define DWORD_PTR          DWORD
	#define LONG_PTR           LONG
	#define ULONG_PTR          LONG
#endif
#ifndef GetClassLongPtr
	#define GetClassLongPtr    GetClassLong
	#define SetClassLongPtr    SetClassLong
	#define GCLP_HBRBACKGROUND GCL_HBRBACKGROUND
	#define GCLP_HCURSOR       GCL_HCURSOR
	#define GCLP_HICON         GCL_HICON
	#define GCLP_HICONSM       GCL_HICONSM
	#define GCLP_HMODULE       GCL_HMODULE
	#define GCLP_MENUNAME      GCL_MENUNAME
	#define GCLP_WNDPROC       GCL_WNDPROC
#endif
//-------------------------------------
//For Visual Studio 6 (without an updated platform SDK) and Dev-C++
#ifndef OPENFILENAME_SIZE_VERSION_400
  #define OPENFILENAME_SIZE_VERSION_400 sizeof(OPENFILENAME)
#endif
//-------------------------------------
////_tsetlocale(LC_ALL, NULL);
////setlocale(LC_ALL, "Russian"); 
//////_tsetlocale(LC_ALL, _T(""));
//-------------------------------------
//Automatically include the XLib namespace define NO_USING_NAMESPACE to skip this step
namespace XLib {}
#ifndef NO_USING_NAMESPACE
    using namespace XLib;
#endif
//---------------------------------------------------------------------------
#endif  //XLib_CommonH
















 
  //---------------------------------------------------------------------------
  //#undef  FALSE
  //#define FALSE       0
  //
  //#undef  TRUE
  //#define TRUE        1
  //
  //#undef  NULL
  //#define NULL        0
  //
  //#undef  CHAR        
  //#define CHAR        char
  //
  //#undef  WCHAR       
  //#define WCHAR       wchar_t
  //
  //#undef  UCHAR       
  //#define UCHAR       unsigned char
  //
  //#undef  INT        
  //#define INT         int
  //
  //#undef  UINT     
  //#define UINT        unsigned int
  //
  //#undef  SHORT      
  //#define SHORT       short
  //
  //#undef  USHORT      
  //#define USHORT      unsigned short
  //
  //#undef  LONG         
  //#define LONG        long
  //
  //#undef ULONG       
  //#define ULONG       unsigned long

  //#undef long long int
  //#define long long int

  //#undef  LONGLONG    
  //#define LONGLONG    __int64
  //
  //#undef  ULONGLONG   
  //#define ULONGLONG   unsigned __int64 

  //#undef  VOID        (void)
  //#define VOID        void
  //
  //#undef  CONST       const
  //#define CONST       const

  //#undef  LPSTR       
  //#define LPSTR       char *
  //
  //#undef  LPCSTR      
  //#define LPCSTR      const char *
  //
  //#undef  LPWSTR      
  //#define LPWSTR      wchar_t *  
  //
  //#undef  LPWCSTR     
  //#define LPWCSTR     const wchar_t
  //
  //#undef  LPTSTR     
  //#define LPTSTR      wchar_t *
  //
  //#undef  LPTCSTR     
  //#define LPTCSTR     const wchar_t *

  /*
  CHAR        char
  WCHAR       wchar_t
  UCHAR       unsigned char
  INT         int
  UINT        unsigned int
  SHORT       short
  USHORT      unsigned short
  LONG        long
  ULONG       unsigned long
  long long int
  LONGLONG    __int64
  ULONGLONG   unsigned __int64 
  VOID        void
  CONST       const
  LPSTR       char *
  LPCSTR      const char *
  LPWSTR      wchar_t *  
  LPWCSTR     const wchar_t
  LPTSTR      wchar_t *
  LPTCSTR     const wchar_t *
  */
  