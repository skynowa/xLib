/****************************************************************************
* Class name:  CXStatic
* Description: ������ � ����������� �����
* File name:   CXStatic.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:20:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXStaticH
#define XLib_Gui_CXStaticH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXStatic: public CXWindow {
	public:
		 CXStatic();
		~CXStatic();

		BOOL bCreateRes(INT iID, HWND hParent);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXStaticH
