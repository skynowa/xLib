/****************************************************************************
* Class name:  CXTab
* Description: ��������
* File name:   CXTab.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXTabH
#define XLib_Gui_CXTabH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
#include <XLib/Gui/CXWindowImpl.h>

class CXTab;
//---------------------------------------------------------------------------
////class CXSheet : public CXWindowImpl {
////	public:
////		  CXSheet(const CXTab *ptabParentTab) { 
////			  /*DEBUG*/XASSERT(NULL != ptabParentTab);
////
////			  _m_ptabParentTab = ptabParentTab;
////
////
////			  _m_ulStyle   =  WS_CHILD | WS_TABSTOP | WS_CAPTION;
////			  _m_ulStyleEx = WS_EX_CONTROLPARENT;
////			  
////		  };
////		 ~CXSheet() {};
////
////		//X_DECLARE_MSG_MAP()
////		X_BEGIN_MSG_MAP(CXSheet)
////			/*X_CMD(m_CXButton3.iGetID(), OnTest)*/
////			/*X_CMD(m_CXButton4.iGetID(), OnTest)*/
////		X_END_MSG_MAP(CXWindowImpl)
////
////		VOID       OnCreate    (WPARAM wParam, LPARAM lParam) {};	/*virtual*/
////		VOID       OnNotify    (WPARAM wParam, LPARAM lParam) {
////    		//-------------------------------------
////        	//Tab
////        	LPNMHDR lpnmhdr = reinterpret_cast<LPNMHDR>(lParam);
////        	switch (lpnmhdr->code) {
////        		 case TCN_SELCHANGE:
////        			 {
////        			 LRESULT nSel = _m_ptabParentTab->iGetCurrSel();
////        			 switch (nSel) {
////        				 case 0:
////        					 {
////        					 _m_ptabParentTab->bShowTab(0, TRUE);
////        					 _m_ptabParentTab->bShowTab(1, FALSE);
////        					 }
////        					 break;
////        				 case 1:
////        					 {
////        					 _m_ptabParentTab->bShowTab(0, FALSE);
////        					 _m_ptabParentTab->bShowTab(1, TRUE);
////        					 }
////        					 break;
////        				 }
////        			 }
////        			 break;
////        	}
////		};	/*virtual*/	
////		VOID       OnSize      (WPARAM wParam, LPARAM lParam) {};	/*virtual*/
////		VOID       OnTest      (WORD   id,     LPARAM lParam) {};
////
////	private:
////		const CXTab *_m_ptabParentTab;
////
////};
//////---------------------------------------------------------------------------
////CXSheet::CXSheet() {
////
////}
//////---------------------------------------------------------------------------
////CXSheet::~CXSheet() {
////
////}
//////---------------------------------------------------------------------------
////X_BEGIN_MSG_MAP(CXSheet)
////	/*X_CMD(m_CXButton3.iGetID(), OnTest)*/
////	/*X_CMD(m_CXButton4.iGetID(), OnTest)*/
////X_END_MSG_MAP(CXWindowImpl)
//////---------------------------------------------------------------------------
////VOID CXSheet::OnCreate(WPARAM wParam, LPARAM lParam) {
////	BOOL bRes = FALSE;
////
////	////bRes = m_CXButton3.bCreateRes(IDC_btnCXButton3, hGetHandle());
////	/////*DEBUG*/XASSERT(TRUE == bRes);
////
////	////bRes = m_CXButton4.bCreateRes(IDC_btnCXButton4, hGetHandle());
////	/////*DEBUG*/XASSERT(TRUE == bRes);
////}
//////---------------------------------------------------------------------------
////VOID CXSheet::OnNotify(WPARAM wParam, LPARAM lParam) {
////
////}
//////---------------------------------------------------------------------------
////VOID CXSheet::OnSize(WPARAM wParam, LPARAM lParam) {
////
////}
//////---------------------------------------------------------------------------
////VOID CXSheet::OnTest(WORD id, LPARAM) {
////	::MessageBox(_m_hWnd, "xxxxxxxxxxxxxxx", "Test", 0);
////}
//////---------------------------------------------------------------------------
//---------------------------------------------------------------------------
class CXTab : public CXWindow {
	public:
///////////////////////////////////////////////////////////////////////////////////////////////
		class CXSheet : public CXWindowImpl {
		public:
			CXSheet() { 
				_m_ulStyle   = WS_CHILD | WS_TABSTOP | WS_CAPTION;
				_m_ulStyleEx = WS_EX_CONTROLPARENT;

			};
			~CXSheet() {};

			//X_DECLARE_MSG_MAP()
			X_BEGIN_MSG_MAP(CXSheet)
				/*X_CMD(m_CXButton3.iGetID(), OnTest)*/
				/*X_CMD(m_CXButton4.iGetID(), OnTest)*/
			X_END_MSG_MAP(CXWindowImpl)

			VOID OnCreate(WPARAM wParam, LPARAM lParam) {};	/*virtual*/
			VOID OnNotify(WPARAM wParam, LPARAM lParam) {};	/*virtual*/	
			VOID OnSize  (WPARAM wParam, LPARAM lParam) {};	/*virtual*/
			VOID OnTest  (WORD   id,     LPARAM lParam) {};

		private:

		};
////////////////////////////////////////////////////////////////////////////////////////////////
	                CXTab       ();
		           ~CXTab       ();
		BOOL        bCreateRes  (INT iID, HWND hParent);
		BOOL        bInsertTab  (LPTSTR lpCaption, INT iPos, INT iImage);
		BOOL        bShowTab    (INT iPos, BOOL bFlag);
		INT         iGetCurSel  ();
		LRESULT     GetImageList();
		HIMAGELIST  SetImageList(HIMAGELIST lImageList);
        
    private:
		INT         _m_iCountSheet;

        std::vector<CXSheet *> _m_vecSheets;
		BOOL        bPutSheet   (HWND hPageDlg, INT iPos);
};
//---------------------------------------------------------------------------
#endif //XLib_Gui_CXTabH


/*
	TCM_ADJUSTRECT			TabCtrl_AdjustRect
	TCM_DELETEALLITEMS		TabCtrl_DeleteAllItems
	TCM_DELETEITEM			TabCtrl_DeleteItem
	TCM_DESELECTALL			TabCtrl_DeselectAll
	TCM_GETCURFOCUS			TabCtrl_GetCurFocus
	TCM_GETCURSEL			TabCtrl_GetCurSel
	TCM_GETEXTENDEDSTYLE	TabCtrl_GetExtendedStyle
	TCM_GETIMAGELIST		TabCtrl_GetImageList
	TCM_GETITEM				TabCtrl_GetItem
	TCM_GETITEMCOUNT		TabCtrl_GetItemCount
	TCM_GETITEMRECT			TabCtrl_GetItemRect
	TCM_GETROWCOUNT			TabCtrl_GetRowCount
	TCM_GETTOOLTIPS			TabCtrl_GetToolTips
	TCM_GETUNICODEFORMAT	TabCtrl_GetUnicodeFormat
	TCM_HIGHLIGHTITEM		TabCtrl_HighlightItem
	TCM_HITTEST				TabCtrl_HitTest
	TCM_INSERTITEM			TabCtrl_InsertItem
	TCM_REMOVEIMAGE			TabCtrl_RemoveImage
	TCM_SETCURFOCUS			TabCtrl_SetCurFocus
	TCM_SETCURSEL			TabCtrl_SetCurSel
	TCM_SETEXTENDEDSTYLE	TabCtrl_SetExtendedStyle
	TCM_SETIMAGELIST		TabCtrl_SetImageList
	TCM_SETITEM				TabCtrl_SetItem
	TCM_SETITEMEXTRA		TabCtrl_SetItemExtra
	TCM_SETITEMSIZE			TabCtrl_SetItemSize
	TCM_SETMINTABWIDTH		TabCtrl_SetMinTabWidth
	TCM_SETPADDING			TabCtrl_SetPadding
	TCM_SETTOOLTIPS	        TabCtrl_SetToolTips
	TCM_SETUNICODEFORMAT	TabCtrl_SetUnicodeFormat
*/