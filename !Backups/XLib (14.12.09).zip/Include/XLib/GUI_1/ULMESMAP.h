#include "windows.h"


#define UL_DECLARE_MSG_MAP()\
virtual LRESULT lProcessWindowMessage(UINT uMsg,\
									WPARAM wParam,\
									LPARAM lParam); 

#define UL_BEGIN_MSG_MAP_NO_DECLARE()\
virtual LRESULT lProcessWindowMessage(UINT uMsg,\
									WPARAM wParam,\
									LPARAM lParam) \
{	

#define UL_BEGIN_MSG_MAP(theClass)\
LRESULT theClass::lProcessWindowMessage(UINT uMsg,\
									WPARAM wParam,\
									LPARAM lParam) \
{	

#define UL_MSG(msg, func) \
	if(uMsg == msg) \
	{ \
		func(wParam, lParam); \
		return FALSE; \
	}

#define UL_CMD(id, func) \
	if((uMsg == WM_COMMAND) && (id == LOWORD(wParam))) \
	{ \
		func(LOWORD(wParam),lParam); \
		return FALSE;\
	}


#define UL_END_MSG_MAP(theParentClass)\
	return theParentClass::lProcessWindowMessage(uMsg,\
												wParam,\
												lParam); \
};

#define UL_END_MSG_MAP_NOPARENT\
	return FALSE;};



