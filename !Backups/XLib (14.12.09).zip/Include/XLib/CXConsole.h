/**********************************************************************
*	�����  CXConsole (CXConsole.h)
*
***********************************************************************/


#ifndef CXConsoleH
#define CXConsoleH      
//---------------------------------------------------------------------------
#define APP_NAME "Crypt ++"
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXConsole {
	public:
			        CXConsole           (); /*+*/
		           ~CXConsole           (); /*+*/
		VOID        vSetLocale          (const std::string &csLocale); /*+*/
		BOOL        bSetTextColor       (UINT uiColor); /*+*/
		BOOL        bEnableClose        (BOOL bFlag); /*+*/
		std::string sGetTitle           (); /*+*/
		BOOL        bSetTitle           (const std::string &csTitle); /*+*/
		BOOL        bSetFullScreen      (); /*+9*/
		BOOL        bClear              (); /*+*/
		BOOL		bWriteLine		    (const std::string &csStr); /*+*/
		BOOL        bWriteErrLine       (const std::string &csStr); /*+*/
		std::string sReadLine           (); /*+*/
		CHAR        sReadChar           ();/*-*/

	private:
		HWND        m_hWnd; /*+*/
		HMENU       m_hMenu; /*+*/
		HANDLE      m_hStdIn; /*+*/
		HANDLE      m_hStdOut; /*+*/

		HWND        hGetHandle          (); /*+*/
		BOOL        bCenterWindow       (); /*+*/
};
//---------------------------------------------------------------------------
#endif