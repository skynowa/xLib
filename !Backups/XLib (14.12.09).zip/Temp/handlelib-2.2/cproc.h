//	Project: RSDN
//	File:    CProc.h
//	Author:  Paul Bludov
//	Date:    11/04/2002
//
//	Description:
//		C++ wrapper on Win32 JobObject, semaphore, mutex, timer
//
//	Update History:
//		NONE
//		
/////////////////////////////////////////////////////////////////////////////

#ifndef __RSDN_CPROC_H__
#define __RSDN_CPROC_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "chandle.h"

/////////////////////////////////////////////////////////////////////////////
// Classes in this file
//
// CProcessT<t_bManaged>
// CThreadT<t_bManaged>
// CJobObjectT<t_bManaged>
// CTokenT<t_bManaged>
// CToolhelpSnapshotT<t_bManaged>
//

namespace RSDN
{

// Helpers

inline bool IsValidProcess
	( HANDLE hProcess
	)
{
	// The current process pseudohandle is INVALID_HANDLE_VALUE (-1)
#ifdef _DEBUG
	if (NULL != hProcess)
	{
		if ((HANDLE)-1 == hProcess)
			return true;
		DWORD nError = ::GetLastError();
		_ASSERTE(0 != ::GetPriorityClass(hProcess)
			|| ERROR_ACCESS_DENIED == ::GetLastError());
		::SetLastError(nError);
	}
#endif
	return NULL != hProcess;
}

inline bool IsValidThread
	( HANDLE hThread
	)
{
	// The current thread pseudohandle is -2
#ifdef _DEBUG
	if (NULL != hThread)
	{
		if ((HANDLE)-2 == hThread)
			return true;
		DWORD nError = ::GetLastError();
		_ASSERTE(THREAD_PRIORITY_ERROR_RETURN != ::GetThreadPriority(hThread)
			|| ERROR_ACCESS_DENIED == ::GetLastError());
		::SetLastError(nError);
	}
#endif
	return NULL != hThread;
}

inline BOOL CreateProcess
	( LPCSTR lpApplicationName
	, LPSTR lpCommandLine
	, LPSECURITY_ATTRIBUTES lpProcessAttributes
	, LPSECURITY_ATTRIBUTES lpThreadAttributes
	, BOOL bInheritHandles
	, DWORD nCreationFlags
	, LPVOID lpEnvironment
	, LPCSTR lpCurrentDirectory
	, LPSTARTUPINFOA lpStartupInfo
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpStartupInfo);
	_ASSERTE(lpApplicationName || lpCommandLine);
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	b = ::CreateProcessA(lpApplicationName, lpCommandLine
		, lpProcessAttributes, lpThreadAttributes, bInheritHandles
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}

inline BOOL CreateProcess
	( LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, LPSECURITY_ATTRIBUTES lpProcessAttributes
	, LPSECURITY_ATTRIBUTES lpThreadAttributes
	, BOOL bInheritHandles
	, DWORD nCreationFlags
	, LPVOID lpEnvironment
	, LPCWSTR lpCurrentDirectory
	, LPSTARTUPINFOW lpStartupInfo
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpStartupInfo);
	_ASSERTE(lpApplicationName || lpCommandLine);
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	b = ::CreateProcessW(lpApplicationName, lpCommandLine
		, lpProcessAttributes, lpThreadAttributes, bInheritHandles
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}

inline BOOL CreateProcess
	( LPCSTR lpApplicationName
	, LPSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOA lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOA si = {0};

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOA);
		lpStartupInfo = &si;
	}
	return CreateProcess(lpApplicationName, lpCommandLine, NULL, NULL, FALSE
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, lphProcess, lphThread, lpnProcessId, lpnThreadId);
}

inline BOOL CreateProcess
	( LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOW lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCWSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOW si = {0};

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOW);
		lpStartupInfo = &si;
	}
	return CreateProcess(lpApplicationName, lpCommandLine, NULL, NULL, FALSE
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, lphProcess, lphThread, lpnProcessId, lpnThreadId);
}

inline BOOL CreateProcessAsUser
	( HANDLE hToken
	, LPCSTR lpApplicationName
	, LPSTR lpCommandLine
	, LPSECURITY_ATTRIBUTES lpProcessAttributes
	, LPSECURITY_ATTRIBUTES lpThreadAttributes
	, BOOL bInheritHandles
	, DWORD nCreationFlags
	, LPVOID lpEnvironment
	, LPCSTR lpCurrentDirectory
	, LPSTARTUPINFOA lpStartupInfo
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpStartupInfo);
	_ASSERTE(lpApplicationName || lpCommandLine);
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	b = ::CreateProcessAsUserA(hToken, lpApplicationName, lpCommandLine
		, lpProcessAttributes, lpThreadAttributes, bInheritHandles
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}

inline BOOL CreateProcessAsUser
	( HANDLE hToken
	, LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, LPSECURITY_ATTRIBUTES lpProcessAttributes
	, LPSECURITY_ATTRIBUTES lpThreadAttributes
	, BOOL bInheritHandles
	, DWORD nCreationFlags
	, LPVOID lpEnvironment
	, LPCWSTR lpCurrentDirectory
	, LPSTARTUPINFOW lpStartupInfo
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpStartupInfo);
	_ASSERTE(lpApplicationName || lpCommandLine);
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	b = ::CreateProcessAsUserW(hToken, lpApplicationName, lpCommandLine
		, lpProcessAttributes, lpThreadAttributes, bInheritHandles
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}

inline BOOL CreateProcessAsUser
	( HANDLE hToken
	, LPCSTR lpApplicationName
	, LPSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOA lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOA si = {0};

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOA);
		lpStartupInfo = &si;
	}
	return CreateProcessAsUser(hToken, lpApplicationName, lpCommandLine, NULL, NULL, FALSE
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, lphProcess, lphThread, lpnProcessId, lpnThreadId);
}

inline BOOL CreateProcessAsUser
	( HANDLE hToken
	, LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOW lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCWSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOW si = {0};

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOW);
		lpStartupInfo = &si;
	}
	return CreateProcessAsUser(hToken, lpApplicationName, lpCommandLine, NULL, NULL, FALSE
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, lphProcess, lphThread, lpnProcessId, lpnThreadId);
}

#if (_WIN32_WINNT >= 0x0500)
inline BOOL CreateProcessWithLogon
	( LPCWSTR lpUsername
	, LPCWSTR lpDomain
	, LPCWSTR lpPassword
	, DWORD nLogonFlags
	, LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOW lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCWSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOW si = {0};
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOW);
		lpStartupInfo = &si;
	}
	b = ::CreateProcessWithLogonW(lpUsername, lpDomain, lpPassword
		, nLogonFlags, lpApplicationName, lpCommandLine
		, nCreationFlags, lpEnvironment, lpCurrentDirectory, lpStartupInfo
		, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}

inline BOOL CreateProcessWithToken
	( HANDLE hToken
	, DWORD nLogonFlags
	, LPCWSTR lpApplicationName
	, LPWSTR lpCommandLine
	, DWORD nCreationFlags = 0
	, LPSTARTUPINFOW lpStartupInfo = NULL
	, LPVOID lpEnvironment = NULL
	, LPCWSTR lpCurrentDirectory = NULL
	, LPHANDLE lphProcess = NULL
	, LPHANDLE lphThread = NULL
	, LPDWORD lpnProcessId = NULL
	, LPDWORD lpnThreadId = NULL
	)
{
	_ASSERTE(lpApplicationName || lpCommandLine);
	STARTUPINFOW si = {0};
	PROCESS_INFORMATION pi = {0};
	BOOL b;

	if (!lpStartupInfo)
	{
		si.cb = sizeof(STARTUPINFOW);
		lpStartupInfo = &si;
	}
	b = CreateProcessWithTokenW(hToken, nLogonFlags, lpApplicationName
		, lpCommandLine, nCreationFlags, lpEnvironment, lpCurrentDirectory
		, lpStartupInfo, &pi);
	if (b)
	{
		if (lphProcess)
			*lphProcess = pi.hProcess;
		else
			::CloseHandle(pi.hProcess);
		if (lphThread)
			*lphThread = pi.hThread;
		else
			::CloseHandle(pi.hThread);

		if (lpnProcessId)
			*lpnProcessId = pi.dwProcessId;
		if (lpnThreadId)
			*lpnThreadId = pi.dwThreadId;
	}
	return b;
}
#endif // _WIN32_WINNT >= 0x0500

// Copy the code bytes into the remote process and execute
static HANDLE CreateRemoteThreadEx
	( HANDLE hProcess
	, LPSECURITY_ATTRIBUTES lpThreadAttributes
	, SIZE_T nStackSize
	, LPTHREAD_START_ROUTINE lpStartAddress
	, SIZE_T nStartRoutineSize
	, LPVOID lpParameter = NULL
	, SIZE_T nParameterSize = 0
	, DWORD nCreationFlags = 0
	, LPDWORD lpnThreadId = NULL
	, LPVOID *lplpCodeRemote = NULL
	)
{
	_ASSERTE(lpStartAddress);
	_ASSERTE(nStartRoutineSize > 0);
	_ASSERTE(IsValidProcess(hProcess));
	const int	nAlignBytes = sizeof(INT_PTR) - 1;
	SIZE_T		nTotalSize, nBytesWritten, nStartRoutineSizeAligned;
	BOOL		b, bSuccessAll = FALSE;
	LPBYTE		lpnCodeRemote;
	HANDLE		hThread = NULL;

	// Allocate memory in the remote process's address space large 
	// enough to hold both thread routine and its parameter
	nStartRoutineSizeAligned = (nStartRoutineSize + nAlignBytes) & ~nAlignBytes;
	nTotalSize = nStartRoutineSizeAligned + nParameterSize;
	lpnCodeRemote = (LPBYTE)::VirtualAllocEx(hProcess, NULL, nTotalSize
		, MEM_COMMIT | MEM_TOP_DOWN, PAGE_EXECUTE_READWRITE);
	if (lpnCodeRemote)
	{
		// Write a copy of thread routine to the remote process
		b = ::WriteProcessMemory(hProcess, lpnCodeRemote, lpStartAddress
			, nStartRoutineSize, &nBytesWritten);
		if (b && nBytesWritten == nStartRoutineSize)
		{
			if (nParameterSize)
			{
				// Write an aligned copy of parameter to the remote process
				b = ::WriteProcessMemory(hProcess
					, lpnCodeRemote + nStartRoutineSizeAligned, lpParameter
					, nParameterSize, &nBytesWritten);
				if (b && nBytesWritten == nParameterSize)
					bSuccessAll = TRUE;
			}
			else
				bSuccessAll = TRUE;
		}

		if (bSuccessAll)
			hThread = ::CreateRemoteThread(hProcess, lpThreadAttributes
				, nStackSize, (LPTHREAD_START_ROUTINE)lpnCodeRemote
				, lpnCodeRemote + nStartRoutineSizeAligned, nCreationFlags
				, lpnThreadId);

		if (!hThread)
		{
			// Succeeded to allocate but failed to write or execute
			::VirtualFreeEx(hProcess, lpnCodeRemote, nTotalSize
				, MEM_DECOMMIT);
		}
	}

	if (hThread && lplpCodeRemote)
		*lplpCodeRemote = lpnCodeRemote;

	return hThread;
}

inline HANDLE CreateRemoteThreadEx
	( HANDLE hProcess
	, LPTHREAD_START_ROUTINE lpStartAddress
	, SIZE_T nStartRoutineSize
	, LPVOID lpParameter = NULL
	, SIZE_T nParameterSize = 0
	, DWORD nCreationFlags = 0
	, LPDWORD lpnThreadId = NULL
	, LPVOID *lplpCodeRemote = NULL
	)
{
	return RSDN::CreateRemoteThreadEx(hProcess, NULL, 0, lpStartAddress
		, nStartRoutineSize, lpParameter, nParameterSize, nCreationFlags
		, lpnThreadId, lplpCodeRemote);
}

// CreateRemoteThreadEx causes a leak in the target process memory
// this routine should be called when remote thread finished
inline BOOL FreeRemoteThreadMemory
	( HANDLE hProcess
	, LPVOID lpCodeRemote
	, SIZE_T nStartRoutineSize
	, SIZE_T nParameterSize = 0
	)
{
	_ASSERTE(lpCodeRemote);
	_ASSERTE(nStartRoutineSize > 0);
	_ASSERTE(IsValidProcess(hProcess));
	const int	nAlignBytes = sizeof(INT_PTR) - 1;
	SIZE_T		nTotalSize, nStartRoutineSizeAligned;

	nStartRoutineSizeAligned = (nStartRoutineSize + nAlignBytes) & ~nAlignBytes;
	nTotalSize = nStartRoutineSizeAligned + nParameterSize;
	return ::VirtualFreeEx(hProcess, lpCodeRemote, nTotalSize
		, MEM_DECOMMIT);
}

/////////////////////////////////////////////////////////////////////////////
// Process

template<bool t_bManaged>
class CProcessT
	: public CHandleT<t_bManaged>
{
	typedef CHandleT<t_bManaged> Base;
public:
	CProcessT()
	{ }
	CProcessT
		( const CProcessT<true>& rProcess
		)
		: Base(rProcess)
	{ }
	CProcessT
		( const CProcessT<false>& rProcess
		)
		: Base(rProcess)
	{ }
	explicit CProcessT
		( HANDLE hProcess
		)
		: Base(hProcess)
	{ }

	CProcessT
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCSTR lpCurrentDirectory
		, LPSTARTUPINFOA lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpApplicationName, lpCommandLine, lpProcessAttributes
			, lpThreadAttributes, bInheritHandles, nCreationFlags
			, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lphThread
			, lpnProcessId, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CProcessT
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCWSTR lpCurrentDirectory
		, LPSTARTUPINFOW lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpApplicationName, lpCommandLine, lpProcessAttributes
			, lpThreadAttributes, bInheritHandles, nCreationFlags
			, lpEnvironment, lpCurrentDirectory, lpStartupInfo, lphThread
			, lpnProcessId, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CProcessT
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOA lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpApplicationName, lpCommandLine, nCreationFlags
			, lpStartupInfo, lpEnvironment, lpCurrentDirectory
			, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CProcessT
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpApplicationName, lpCommandLine, nCreationFlags
			, lpStartupInfo, lpEnvironment, lpCurrentDirectory
			, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CProcessT
		( DWORD nProcessId
		, DWORD nDesiredAccess
		, BOOL bInheritHandle = FALSE
		)
	{
		Open(nProcessId, nDesiredAccess, bInheritHandle);
		_ASSERTE(IsValid());
	}

	CProcessT<t_bManaged>& operator=(HANDLE h)
	{
		Base::operator=(h);
		return *this;
	}

	CProcessT<t_bManaged>& operator=(const CProcessT<true>& other)
	{
		Base::operator=(other);
		return *this;
	}

	CProcessT<t_bManaged>& operator=(const CProcessT<false>& other)
	{
		Base::operator=(other);
		return *this;
	}

	bool IsValid() const
	{
		return RSDN::IsValidProcess(m_h);
	}

	HANDLE Create
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCSTR lpCurrentDirectory
		, LPSTARTUPINFOA lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(!IsValid());
		BOOL b;

		b = RSDN::CreateProcess(lpApplicationName, lpCommandLine
			, lpProcessAttributes, lpThreadAttributes, bInheritHandles
			, nCreationFlags, lpEnvironment, lpCurrentDirectory
			, lpStartupInfo, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE Create
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCWSTR lpCurrentDirectory
		, LPSTARTUPINFOW lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(!IsValid());
		BOOL b;

		b = RSDN::CreateProcess(lpApplicationName, lpCommandLine
			, lpProcessAttributes, lpThreadAttributes, bInheritHandles
			, nCreationFlags, lpEnvironment, lpCurrentDirectory
			, lpStartupInfo, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE Create
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOA lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(!IsValid());
		BOOL b;

		b = RSDN::CreateProcess(lpApplicationName, lpCommandLine
			, nCreationFlags, lpStartupInfo, lpEnvironment, lpCurrentDirectory
			, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE Create
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(!IsValid());
		BOOL b;

		b = RSDN::CreateProcess(lpApplicationName, lpCommandLine
			, nCreationFlags, lpStartupInfo, lpEnvironment, lpCurrentDirectory
			, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE CreateAsUser
		( HANDLE hToken
		, LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCSTR lpCurrentDirectory
		, LPSTARTUPINFOA lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartupInfo);
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessAsUser(hToken, lpApplicationName
			, lpCommandLine, lpProcessAttributes, lpThreadAttributes
			, bInheritHandles, nCreationFlags, lpEnvironment
			, lpCurrentDirectory, lpStartupInfo, &m_h, lphThread
			, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE CreateAsUser
		( HANDLE hToken
		, LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCWSTR lpCurrentDirectory
		, LPSTARTUPINFOW lpStartupInfo
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartupInfo);
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessAsUser(hToken, lpApplicationName
			, lpCommandLine, lpProcessAttributes, lpThreadAttributes
			, bInheritHandles, nCreationFlags, lpEnvironment
			, lpCurrentDirectory, lpStartupInfo, &m_h, lphThread
			, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE CreateAsUser
		( HANDLE hToken
		, LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOA lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessAsUser(hToken, lpApplicationName
			, lpCommandLine, nCreationFlags, lpStartupInfo, lpEnvironment
			, lpCurrentDirectory, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE CreateAsUser
		( HANDLE hToken
		, LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessAsUser(hToken, lpApplicationName
			, lpCommandLine, nCreationFlags, lpStartupInfo, lpEnvironment
			, lpCurrentDirectory, &m_h, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

#if (_WIN32_WINNT >= 0x0500)
	HANDLE CreateWithLogon
		( LPCWSTR lpUsername
		, LPCWSTR lpDomain
		, LPCWSTR lpPassword
		, DWORD nLogonFlags
		, LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessWithLogon(lpUsername, lpDomain, lpPassword
			, nLogonFlags, lpApplicationName, lpCommandLine, nCreationFlags
			, lpStartupInfo, lpEnvironment, lpCurrentDirectory, &m_h
			, lphThread, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE CreateWithToken
		( HANDLE hToken
		, DWORD nLogonFlags
		, LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
{
		_ASSERTE(lpApplicationName || lpCommandLine);
		BOOL b;

		b = RSDN::CreateProcessWithToken(hToken, nLogonFlags
			, lpApplicationName, lpCommandLine, nCreationFlags, lpStartupInfo
			, lpEnvironment, lpCurrentDirectory, &m_h, lphThread
			, lpnProcessId, lpnThreadId);
		_ASSERTE(b);
		return m_h;
	}
#endif // _WIN32_WINNT >= 0x0500

	HANDLE Open
		( DWORD nProcessId
		, DWORD nDesiredAccess = PROCESS_ALL_ACCESS
		, BOOL bInheritHandle = FALSE
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::OpenProcess(nDesiredAccess, bInheritHandle, nProcessId);
		return m_h;
	}

	HANDLE GetCurrent()
	{
		_ASSERTE(!IsValid());

		m_h = ::GetCurrentProcess();
		return m_h;
	}

	BOOL Terminate
		( UINT uExitCode
		)
	{
		_ASSERTE(IsValid());

		return ::TerminateProcess(m_h, uExitCode);
	}

	BOOL FlushInstructionCache
		( LPCVOID lpBaseAddress
		, SIZE_T nSize
		)
	{
		_ASSERTE(lpBaseAddress);
		_ASSERTE(IsValid());

		return ::FlushInstructionCache(m_h, lpBaseAddress, nSize);
	}
	
	HANDLE CreateRemoteThread
		( LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(IsValid());

		return ::CreateRemoteThread(m_h, NULL, 0, lpStartAddress, lpParameter
			, nCreationFlags, lpnThreadId);
	}

	HANDLE CreateRemoteThread
		( LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(IsValid());

		return ::CreateRemoteThread(m_h, lpThreadAttributes, nStackSize
			, lpStartAddress, lpParameter, nCreationFlags, lpnThreadId);
	}

	HANDLE CreateRemoteThreadEx
		( LPTHREAD_START_ROUTINE lpStartAddress
		, SIZE_T nStartRoutineSize
		, LPVOID lpParameter = NULL
		, SIZE_T nParameterSize = 0
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		, LPVOID *lplpCodeRemote = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(IsValid());

		return RSDN::CreateRemoteThreadEx(m_h, NULL, 0, lpStartAddress
			, nStartRoutineSize, lpParameter, nParameterSize
			, nCreationFlags, lpnThreadId, lplpCodeRemote);
	}

	HANDLE CreateRemoteThreadEx
		( LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, SIZE_T nStartRoutineSize
		, LPVOID lpParameter = NULL
		, SIZE_T nParameterSize = 0
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		, LPVOID *lplpCodeRemote = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(IsValid());

		return RSDN::CreateRemoteThread(m_h, lpThreadAttributes, nStackSize
			, lpStartAddress, nStartRoutineSize, lpParameter, nParameterSize
			, nCreationFlags, lpnThreadId, lplpCodeRemote);
	}

	LPVOID VirtualAllocEx
		( LPVOID lpAddress
		, SIZE_T nSize
		, DWORD nAllocationType
		, DWORD nProtect
		)
	{
		_ASSERTE(lpAddress);
		_ASSERTE(IsValid());

		return ::VirtualAllocEx(m_h, lpAddress, nSize, nAllocationType
			, nProtect);
	}

	BOOL VirtualFreeEx
		( LPVOID lpAddress
		, SIZE_T nSize
		, DWORD nFreeType
		)
	{
		_ASSERTE(lpAddress);
		_ASSERTE(IsValid());

		return ::VirtualFreeEx(m_h, lpAddress, nSize, nFreeType);
	}

	BOOL VirtualProtectEx
		( LPVOID lpAddress
		, SIZE_T nSize
		, DWORD nNewProtect
		, PDWORD pnOldProtect
		)
	{
		_ASSERTE(lpAddress);
		_ASSERTE(pnOldProtect);
		_ASSERTE(IsValid());

		return ::VirtualProtectEx(m_h, lpAddress, nSize, nNewProtect
			, pnOldProtect);
	}

	SIZE_T VirtualQueryEx
		( LPVOID lpAddress
		, PMEMORY_BASIC_INFORMATION lpBuffer
		, SIZE_T nLength
		) const
	{
		_ASSERTE(lpAddress);
		_ASSERTE(lpBuffer);
		_ASSERTE(IsValid());

		return ::VirtualQueryEx(m_h, lpAddress, lpBuffer, nLength);
	}

	BOOL ReadMemory
		( LPCVOID lpBaseAddress
		, LPVOID lpBuffer
		, SIZE_T nSize
		, SIZE_T *lpnNumberOfBytesRead = NULL
		) const
	{
		_ASSERTE(lpBaseAddress);
		_ASSERTE(lpBuffer);
		_ASSERTE(IsValid());

		return ::ReadProcessMemory(m_h, lpBaseAddress, lpBuffer, nSize
			, lpnNumberOfBytesRead);
	}

	BOOL WriteMemory
		( LPVOID lpBaseAddress
		, LPCVOID lpBuffer
		, SIZE_T nSize
		, SIZE_T *lpnNumberOfBytesWritten = NULL
		)
	{
		_ASSERTE(lpBaseAddress);
		_ASSERTE(lpBuffer);
		_ASSERTE(IsValid());

		return ::WriteProcessMemory(m_h, lpBaseAddress, lpBuffer, nSize
			, lpnNumberOfBytesWritten);
	}

	BOOL OpenToken
		( DWORD nDesiredAccess
		, PHANDLE phTokenHandle
		)
	{
		_ASSERTE(phTokenHandle);
		_ASSERTE(IsValid());

		return ::OpenProcessToken(m_h, nDesiredAccess, phTokenHandle);
	}

	BOOL GetAffinityMask
		( PDWORD_PTR lpnProcessAffinityMask
		, PDWORD_PTR lpnSystemAffinityMask
		) const
	{
		_ASSERTE(lpnProcessAffinityMask);
		_ASSERTE(lpnSystemAffinityMask);
		_ASSERTE(IsValid());

		return ::GetProcessAffinityMask(m_h, lpnProcessAffinityMask
			, lpnSystemAffinityMask);
	}

	BOOL SetAffinityMask
		( DWORD_PTR nProcessAffinityMask
		)
	{
		_ASSERTE(IsValid());

		return ::SetProcessAffinityMask(m_h, nProcessAffinityMask);
	}

#if _WIN32_WINNT >= 0x0501
	BOOL GetHandleCount
		( PDWORD pnHandleCount
		) const
	{
		_ASSERTE(pnHandleCount);
		_ASSERTE(IsValid());

		return ::GetProcessHandleCount(m_h, pnHandleCount);
	}
		
	DWORD GetHandleCount() const
	{
		_ASSERTE(IsValid());
		DWORD nHandleCount;

		if (::GetProcessHandleCount(m_h, &nHandleCount))
			return nHandleCount;
		return (DWORD)-1;
	}
#endif // _WIN32_WINNT >= 0x0501

	BOOL GetTimes
		( LPFILETIME lpCreationTime
		, LPFILETIME lpExitTime
		, LPFILETIME lpKernelTime
		, LPFILETIME lpUserTime
		) const
	{
		_ASSERTE(IsValid());

		return ::GetProcessTimes(m_h, lpCreationTime, lpExitTime
			, lpKernelTime, lpUserTime);
	}

	BOOL GetIoCounters
		( PIO_COUNTERS lpIoCounters
		) const
	{
		_ASSERTE(lpIoCounters);
		_ASSERTE(IsValid());

		return ::GetProcessIoCounters(m_h, lpIoCounters);
	}

	BOOL GetWorkingSetSize
		( PSIZE_T lpnMinimumWorkingSetSize
		, PSIZE_T lpnMaximumWorkingSetSize
		) const
	{
		_ASSERTE(IsValid());

		return ::GetProcessWorkingSetSize(m_h, lpnMinimumWorkingSetSize
			, lpnMaximumWorkingSetSize);
	}

	BOOL GetWorkingSetSizeEx
		( PSIZE_T lpnMinimumWorkingSetSize
		, PSIZE_T lpnMaximumWorkingSetSize
		, PDWORD pnFlags
		) const
	{
		_ASSERTE(IsValid());

		return ::GetProcessWorkingSetSizeEx(m_h, lpnMinimumWorkingSetSize
			, lpnMaximumWorkingSetSize, pnFlags);
	}

	BOOL SetWorkingSetSize
		( SIZE_T nMinimumWorkingSetSize
		, SIZE_T nMaximumWorkingSetSize
		) const
	{
		_ASSERTE(IsValid());

		return ::SetProcessWorkingSetSize(m_h, nMinimumWorkingSetSize
			, nMaximumWorkingSetSize);
	}

	BOOL SetWorkingSetSizeEx
		( SIZE_T nMinimumWorkingSetSize
		, SIZE_T pnMaximumWorkingSetSize
		, DWORD nFlags
		) const
	{
		_ASSERTE(IsValid());

		return ::SetProcessWorkingSetSizeEx(m_h, nMinimumWorkingSetSize
			, nMaximumWorkingSetSize, nFlags);
	}

	BOOL GetPriorityBoost
		( PBOOL pbDisablePriorityBoost
		) const
	{
		_ASSERTE(pbDisablePriorityBoost);
		_ASSERTE(IsValid());

		return ::GetProcessPriorityBoost(m_h, pbDisablePriorityBoost);
	}

	int GetPriorityBoost() const
	{
		_ASSERTE(IsValid());
		BOOL bDisablePriorityBoost;

		if (::GetProcessPriorityBoost(m_h, &bDisablePriorityBoost))
			return !!bDisablePriorityBoost;
		return -1;
	}

	BOOL SetPriorityBoost
		( BOOL bDisablePriorityBoost
		)
	{
		_ASSERTE(IsValid());

		return ::SetProcessPriorityBoost(m_h, bDisablePriorityBoost);
	}

	BOOL SetPriorityClass
		( DWORD nPriorityClas
		)
	{
		_ASSERTE(IsValid());

		return ::SetPriorityClass(m_h, nPriorityClas);
	}

	DWORD GetPriorityClass() const
	{
		_ASSERTE(IsValid());

		return ::GetPriorityClass(m_h);
	}

	BOOL GetExitCode
		( PDWORD pnExitCode
		) const
	{
		_ASSERTE(pnExitCode);
		_ASSERTE(IsValid());

		return ::GetExitCodeProcess(m_h, pnExitCode);
	}

	BOOL GetId() const
	{
		_ASSERTE(IsValid());

		return ::GetProcessId(m_h);
	}

#if _WIN32_WINNT >= 0x0501
	BOOL CheckRemoteDebuggerPresent
		( PBOOL pbDebuggerPresent
		) const
	{
		_ASSERTE(pbDebuggerPresent);
		_ASSERTE(IsValid());

		return ::CheckRemoteDebuggerPresent(m_h, pbDebuggerPresent);
	}

	int CheckRemoteDebuggerPresent() const
	{
		_ASSERTE(IsValid());
		BOOL bDebuggerPresent;

		if (::CheckRemoteDebuggerPresent(m_h, &bDebuggerPresent))
			return !!bDebuggerPresent;
		return -1;
	}
#endif // _WIN32_WINNT >= 0x0501

	BOOL DebugBreak()
	{
		_ASSERTE(IsValid());

		return ::DebugBreakProcess(m_h);
	}

	BOOL AssignToJobObject
		( HANDLE hJobObject
		)
	{
		_ASSERTE(IsValidHandle(hJobObject));
		_ASSERTE(IsValid());

		return ::AssignProcessToJobObject(hJobObject, m_h);
	}

	BOOL IsInJobObject
		( HANDLE hJobObject
		, PBOOL pbResult
		) const
	{
		_ASSERTE(IsValidHandle(hJobObject));
		_ASSERTE(pbResult);
		_ASSERTE(IsValid());

		return ::IsProcessInJobObject(hJobObject, m_h, pbResult);
	}

	int IsInJobObject
		( HANDLE hJobObject
		) const
	{
		_ASSERTE(IsValidHandle(hJobObject));
		_ASSERTE(IsValid());
		BOOL bResult;

		if (::IsProcessInJobObject(hJobObject, m_h, &bResult))
			return !!bResult;
		return -1;
	}

// WinUser.h

#if(WINVER >= 0x0500)
	DWORD GetGuiResources
		( DWORD uiFlags
		) const
	{
		return ::GetGuiResources(m_h, uiFlags);
	}

	DWORD WaitForInputIdle
		( DWORD dwMilliseconds = INFINITE
		) const
	{
		return ::WaitForInputIdle(m_h, dwMilliseconds);
	}
#endif /* WINVER >= 0x0500 */


// Very Large Memory API Subset

#if _WIN32_WINNT >= 0x0500
	BOOL AllocateUserPhysicalPages
		( PULONG_PTR pnNumberOfPages
		, PULONG_PTR pnPageArray
		)
	{
		_ASSERTE(pnNumberOfPages);
		_ASSERTE(pnPageArray);
		_ASSERTE(IsValid());

		return ::AllocateUserPhysicalPages(m_h, pnNumberOfPages, pnPageArray);
	}

	BOOL FreeUserPhysicalPages
		( PULONG_PTR pnNumberOfPages
		, PULONG_PTR pnPageArray
		)
	{
		_ASSERTE(pnNumberOfPages);
		_ASSERTE(pnPageArray);
		_ASSERTE(IsValid());

		return ::FreeUserPhysicalPages(m_h, pnNumberOfPages, pnPageArray);
	}
#endif // _WIN32_WINNT >= 0x0500

#if _WIN32_WINNT >= 0x0501
	BOOL IsWow64
		( PBOOL pbWow64Process
		) const
	{
		_ASSERTE(pbWow64Process);
		_ASSERTE(IsValid());

		return ::IsWow64Process(m_h, pbWow64Process);
	}

	int IsWow64() const
	{
		_ASSERTE(IsValid());
		BOOL bWow64Process;

		if (::IsWow64Process(m_h, &bWow64Process))
			return !!bWow64Process;
		return -1;
	}
#endif // (_WIN32_WINNT >= 0x0501)
};

typedef CProcessT<true> CProcess;
typedef CProcessT<false> CProcessHandle;

/////////////////////////////////////////////////////////////////////////////
// Thread

template<bool t_bManaged>
class CThreadT
	: public CHandleT<t_bManaged>
{
	typedef CHandleT<t_bManaged> Base;
public:
	CThreadT()
	{ }
	CThreadT
		( const CThreadT<true>& rThread
		)
		: Base(rThread)
	{ }
	CThreadT
		( const CThreadT<false>& rThread
		)
		: Base(rThread)
	{ }
	explicit CThreadT
		( HANDLE hThread
		)
		: Base(hThread)
	{ }

	explicit CThreadT
		( LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpStartAddress, lpParameter, nCreationFlags, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CThreadT
		( LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		Create(lpThreadAttributes, nStackSize, lpStartAddress, lpParameter
			, nCreationFlags, lpnThreadId);
		_ASSERTE(IsValid());
	}

	CThreadT
		( DWORD nThreadId
		, DWORD nDesiredAccess
		, BOOL bInheritHandle = FALSE
		)
	{
		Open(nThreadId, nDesiredAccess, bInheritHandle);
		_ASSERTE(IsValid());
	}

	CThreadT<t_bManaged>& operator=(HANDLE h)
	{
		Base::operator=(h);
		return *this;
	}

	CThreadT<t_bManaged>& operator=(const CThreadT<true>& other)
	{
		Base::operator=(other);
		return *this;
	}

	CThreadT<t_bManaged>& operator=(const CThreadT<false>& other)
	{
		Base::operator=(other);
		return *this;
	}

	bool IsValid() const
	{
		return RSDN::IsValidThread(m_h);
	}

	HANDLE Create
		( LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());
		DWORD nThreadId;

		if (lpnThreadId == NULL)
			lpnThreadId = &nThreadId;

		m_h = ::CreateThread(lpThreadAttributes, nStackSize, lpStartAddress
			, lpParameter, nCreationFlags, lpnThreadId);
		return m_h;
	}

	HANDLE Create
		( LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());
		DWORD nThreadId;

		if (lpnThreadId == NULL)
			lpnThreadId = &nThreadId;

		m_h = ::CreateThread(NULL, 0, lpStartAddress, lpParameter
			, nCreationFlags, lpnThreadId);
		return m_h;
	}

	HANDLE CreateRemote
		( HANDLE hProcess
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());

		m_h = ::CreateRemoteThread(hProcess, NULL, 0, lpStartAddress
			, lpParameter, nCreationFlags, lpnThreadId);
		return m_h;
	}

	HANDLE CreateRemote
		( HANDLE hProcess
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());

		m_h = ::CreateRemoteThread(hProcess, lpThreadAttributes, nStackSize
			, lpStartAddress, lpParameter, nCreationFlags, lpnThreadId);
		return m_h;
	}

	HANDLE CreateRemoteEx
		( HANDLE hProcess
		, LPTHREAD_START_ROUTINE lpStartAddress
		, SIZE_T nStartRoutineSize
		, LPVOID lpParameter = NULL
		, SIZE_T nParameterSize = 0
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());

		m_h = RSDN::CreateRemoteThreadEx(hProcess, NULL, 0, lpStartAddress
			, nStartRoutineSize, lpParameter, nParameterSize, nCreationFlags
			, lpnThreadId);
		return m_h;
	}

	HANDLE CreateRemoteEx
		( HANDLE hProcess
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, SIZE_T nStackSize
		, LPTHREAD_START_ROUTINE lpStartAddress
		, LPVOID lpParameter = NULL
		, DWORD nCreationFlags = 0
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartAddress);
		_ASSERTE(!IsValid());

		m_h = RSDN::CreateRemoteThreadEx(hProcess, lpThreadAttributes
			, nStackSize, lpStartAddress, nStartRoutineSize, lpParameter
			, nParameterSize, nCreationFlags, lpnThreadId);
		return m_h;
	}

	HANDLE Open
		( DWORD nThreadId
		, DWORD nDesiredAccess = THREAD_ALL_ACCESS
		, BOOL bInheritHandle = FALSE
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::OpenThread(nDesiredAccess, bInheritHandle, nThreadId);
		return m_h;
	}

	HANDLE GetCurrent()
	{
		_ASSERTE(!IsValid());

		m_h = ::GetCurrentThread();
		return m_h;
	}

	BOOL Terminate
		( UINT uExitCode
		)
	{
		_ASSERTE(IsValid());

		return ::TerminateThread(m_h, uExitCode);
	}

	DWORD GetId() const
	{
		_ASSERTE(IsValid());

		return ::GetThreadId(m_h);
	}

	DWORD GetProcessId() const
	{
		_ASSERTE(IsValid());

		return ::GetProcessIdOfThread(m_h);
	}

	DWORD_PTR SetAffinityMask
		( DWORD_PTR nThreadAffinityMask
		)
	{
		_ASSERTE(IsValid());

		return ::SetThreadAffinityMask(m_h, nThreadAffinityMask);
	}

#if _WIN32_WINNT >= 0x0400
	DWORD SetIdealProcessor
		( DWORD nIdealProcessor
		)
	{
		_ASSERTE(IsValid());

		return ::SetThreadIdealProcessor(m_h, nIdealProcessor);
	}
#endif // _WIN32_WINNT >= 0x0400

	BOOL SetPriority
		( int nPriority
		)
	{
		_ASSERTE(IsValid());

		return ::SetThreadPriority(m_h, nPriority);
	}

	int GetPriority() const
	{
		_ASSERTE(IsValid());

		return ::GetThreadPriority(m_h);
	}

	BOOL SetPriorityBoost
		( BOOL bDisablePriorityBoost
		)
	{
		_ASSERTE(IsValid());

		return ::SetThreadPriorityBoost(m_h, bDisablePriorityBoost);
	}

	BOOL GetPriorityBoost
		( PBOOL pbDisablePriorityBoost
		) const
	{
		_ASSERTE(pbDisablePriorityBoost);
		_ASSERTE(IsValid());

		return ::GetThreadPriorityBoost(m_h, pbDisablePriorityBoost);
	}

	int GetPriorityBoost() const
	{
		_ASSERTE(IsValid());
		BOOL bDisablePriorityBoost;

		if (::GetThreadPriorityBoost(m_h, &bDisablePriorityBoost))
			return !!bDisablePriorityBoost;
		return -1;
	}

	BOOL GetTimes
		( LPFILETIME lpCreationTime
		, LPFILETIME lpExitTime
		, LPFILETIME lpKernelTime
		, LPFILETIME lpUserTime
		) const
	{
		_ASSERTE(IsValid());

		return ::GetThreadTimes(m_h, lpCreationTime, lpExitTime
			, lpKernelTime, lpUserTime);
	}

#if _WIN32_WINNT >= 0x0501
	BOOL GetIOPendingFlag
		( PBOOL pbIOIsPending
		) const
	{
		_ASSERTE(pbIOIsPending);
		_ASSERTE(IsValid());

		return ::GetThreadIOPendingFlag(m_h, pbIOIsPending);
	}

	int GetIOPendingFlag() const
	{
		_ASSERTE(IsValid());
		BOOL bIOIsPending;

		if (::GetThreadIOPendingFlag(m_h, &bIOIsPending))
			return !!bIOIsPending;
		return -1;
	}
#endif // _WIN32_WINNT >= 0x0501

	BOOL GetExitCode
		( PDWORD pnExitCode
		) const
	{
		_ASSERTE(pnExitCode);
		_ASSERTE(IsValid());

		return ::GetExitCodeThread(m_h, pnExitCode);
	}

	BOOL GetSelectorEntry
		( DWORD nSelector
		, LPLDT_ENTRY lpSelectorEntry
		) const
	{
		_ASSERTE(lpSelectorEntry);
		_ASSERTE(IsValid());

		return ::GetThreadSelectorEntry(m_h, nSelector, lpSelectorEntry);
	}

	BOOL GetContext
		( LPCONTEXT lpContext
		) const
	{
		_ASSERTE(lpContext);
		_ASSERTE(IsValid());

		return ::GetThreadContext(m_h, lpContext);
	}

	BOOL SetContext
		( CONST CONTEXT *lpContext
		)
	{
		_ASSERTE(lpContext);
		_ASSERTE(IsValid());

		return ::SetThreadContext(m_h, lpContext);
	}

	DWORD Suspend()
	{
		_ASSERTE(IsValid());

		return ::SuspendThread(m_h);
	}

	DWORD Resume()
	{
		_ASSERTE(IsValid());

		return ::ResumeThread(m_h);
	}

#if _WIN32_WINNT >= 0x0400 || _WIN32_WINDOWS > 0x0400
	DWORD QueueUserAPC
		( PAPCFUNC pfnAPC
		, ULONG_PTR pData
		)
	{
		_ASSERTE(IsValid());

		return ::QueueUserAPC(pfnAPC, m_h, pData);
	}
#endif // _WIN32_WINNT >= 0x0400 || _WIN32_WINDOWS > 0x0400

	BOOL SetToken
		( HANDLE hToken
		)
	{
		_ASSERTE(IsValid());

		return ::SetThreadToken(&m_h, hToken);
	}

	BOOL OpenToken
		( DWORD nDesiredAccess
		, BOOL bOpenAsSelf
		, PHANDLE phTokenHandle
		)
	{
		_ASSERTE(phTokenHandle);
		_ASSERTE(IsValid());

		return ::OpenThreadToken(m_h, nDesiredAccess, bOpenAsSelf
			, phTokenHandle);
	}

	BOOL ImpersonateAnonymousToken()
	{
		_ASSERTE(IsValid());

		return ::ImpersonateAnonymousToken(m_h);
	}
};

typedef CThreadT<true> CThread;
typedef CThreadT<false> CThreadHandle;

/////////////////////////////////////////////////////////////////////////////
// JobObject

template<bool t_bManaged>
class CJobObjectT
	: public CHandleT<t_bManaged>
{
	typedef CHandleT<t_bManaged> Base;
public:
	using RSDN::CHandleT<t_bManaged>::SetInformation;

	CJobObjectT()
	{ }
	CJobObjectT
		( const CJobObjectT<true>& rJobObject
		)
		: Base(rJobObject)
	{ }
	CJobObjectT
		( const CJobObjectT<false>& rJobObject
		)
		: Base(rJobObject)
	{ }
	explicit CJobObjectT
		( HANDLE hJobObject
		)
		: Base(hJobObject)
	{ }

	explicit CJobObjectT
		( LPCSTR lpName
		, LPSECURITY_ATTRIBUTES lpJobObjectAttributes = NULL
		)
	{
		Create(lpName, lpJobObjectAttributes);
		_ASSERTE(IsValid());
	}

	explicit CJobObjectT
		( LPCWSTR lpName
		, LPSECURITY_ATTRIBUTES lpJobObjectAttributes = NULL
		)
	{
		Create(lpName, lpJobObjectAttributes);
		_ASSERTE(IsValid());
	}

	CJobObjectT
		( LPCSTR lpName
		, DWORD nDesiredAccess
		, BOOL bInheritHandle = FALSE
		)
	{
		Open(lpName, nDesiredAccess, bInheritHandle);
		_ASSERTE(IsValid());
	}

	CJobObjectT
		( LPCWSTR lpName
		, DWORD nDesiredAccess
		, BOOL bInheritHandle = FALSE
		)
	{
		Open(lpName, nDesiredAccess, bInheritHandle);
		_ASSERTE(IsValid());
	}

	CJobObjectT<t_bManaged>& operator=(HANDLE h)
	{
		Base::operator=(h);
		return *this;
	}

	CJobObjectT<t_bManaged>& operator=(const CJobObjectT<true>& other)
	{
		Base::operator=(other);
		return *this;
	}

	CJobObjectT<t_bManaged>& operator=(const CJobObjectT<false>& other)
	{
		Base::operator=(other);
		return *this;
	}

	HANDLE Create
		( LPCSTR lpName
		, LPSECURITY_ATTRIBUTES lpJobObjectAttributes = NULL
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::CreateJobObject(lpJobObjectAttributes, lpName);
		return m_h;
	}

	HANDLE Create
		( LPCWSTR lpName
		, LPSECURITY_ATTRIBUTES lpJobObjectAttributes = NULL
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::CreateJobObject(lpJobObjectAttributes, lpName);
		return m_h;
	}

	HANDLE Open
		( LPCSTR lpName
		, DWORD nDesiredAccess = JOB_ALL_ACCESS
		, BOOL bInheritHandle = FALSE
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::OpenJobObject(nDesiredAccess, bInheritHandle, lpName);
		return m_h;
	}

	HANDLE Open
		( LPCWSTR lpName
		, DWORD nDesiredAccess = JOB_ALL_ACCESS
		, BOOL bInheritHandle = FALSE
		)
	{
		_ASSERTE(!IsValid());

		m_h = ::OpenJobObject(nDesiredAccess, bInheritHandle, lpName);
		return m_h;
	}

	BOOL AssignProcess
		( HANDLE hProcess
		)
	{
		_ASSERTE(IsValidProcess(hProcess));
		_ASSERTE(IsValid());

		return ::AssignProcessToJobObject(m_h, hProcess);
	}

	BOOL Terminate
		( UINT uExitCode
		)
	{
		_ASSERTE(IsValid());

		return ::TerminateJobObject(m_h, uExitCode);
	}

	BOOL QueryInformation
		( JOBOBJECTINFOCLASS JobObjectInformationClass
		, LPVOID lpJobObjectInformation
		, DWORD nJobObjectInformationLength
		, LPDWORD lpnReturnLength
		) const
	{
		_ASSERTE(JobObjectBasicAccountingInformation 
			<= JobObjectInformationClass);
		_ASSERTE(MaxJobObjectInfoClass 
			>= JobObjectInformationClass);
		_ASSERTE(IsValid());

		return ::QueryInformationJobObject(m_h, JobObjectInformationClass
			, lpJobObjectInformation, nJobObjectInformationLength
			, lpnReturnLength);
	}

	BOOL SetInformation
		( JOBOBJECTINFOCLASS JobObjectInformationClass
		, LPVOID lpJobObjectInformation
		, DWORD nJobObjectInformationLength
		)
	{
		_ASSERTE(JobObjectBasicAccountingInformation 
			<= JobObjectInformationClass);
		_ASSERTE(MaxJobObjectInfoClass 
			>= JobObjectInformationClass);
		_ASSERTE(IsValid());

		return ::SetInformationJobObject(m_h, JobObjectInformationClass
			, lpJobObjectInformation, nJobObjectInformationLength);
	}

	BOOL IsProcessInJob
		( HANDLE hProcess
		, PBOOL pbResult
		) const
	{
		_ASSERTE(pbResult);
		_ASSERTE(IsValid());

		return ::IsProcessInJob(hProcess, m_h, pbResult);
	}

	int IsProcessInJob
		( HANDLE hProcess
		) const
	{
		_ASSERTE(IsValid());
		BOOL bResult;

		if (::IsProcessInJob(hProcess, m_h, &bResult))
			return !!bResult;
		return -1;
	}

};

typedef CJobObjectT<true> CJobObject;
typedef CJobObjectT<false> CJobObjectHandle;

/////////////////////////////////////////////////////////////////////////////
// Token

template<bool t_bManaged>
class CTokenT
	: public CHandleT<t_bManaged>
{
	typedef CHandleT<t_bManaged> Base;
public:
	using RSDN::CHandleT<t_bManaged>::DuplicateTo;
	using RSDN::CHandleT<t_bManaged>::DuplicateFrom;
	using RSDN::CHandleT<t_bManaged>::GetInformation;
	using RSDN::CHandleT<t_bManaged>::SetInformation;

	CTokenT()
	{ }
	CTokenT
		( const CTokenT<true>& rToken
		)
		: Base(rToken)
	{ }
	CTokenT
		( const CTokenT<false>& rToken
		)
		: Base(rToken)
	{ }
	explicit CTokenT
		( HANDLE hToken
		)
		: Base(hToken)
	{ }

	CTokenT<t_bManaged>& operator=(HANDLE h)
	{
		Base::operator=(h);
		return *this;
	}

	CTokenT<t_bManaged>& operator=(const CTokenT<true>& other)
	{
		Base::operator=(other);
		return *this;
	}

	CTokenT<t_bManaged>& operator=(const CTokenT<false>& other)
	{
		Base::operator=(other);
		return *this;
	}

	HANDLE LogonUser
		( LPCSTR lpszUsername
		, LPCSTR lpszDomain
		, LPCSTR lpszPassword
		, DWORD nLogonType
		, DWORD nLogonProvider
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::LogonUserA(lpszUsername, lpszDomain, lpszPassword, nLogonType
			, nLogonProvider, &m_h);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE LogonUser
		( LPCWSTR lpszUsername
		, LPCWSTR lpszDomain
		, LPCWSTR lpszPassword
		, DWORD nLogonType
		, DWORD nLogonProvider
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::LogonUserW(lpszUsername, lpszDomain, lpszPassword, nLogonType
			, nLogonProvider, &m_h);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE LogonUserEx
		( LPCSTR lpszUsername
		, LPCSTR lpszDomain
		, LPCSTR lpszPassword
		, DWORD nLogonType
		, DWORD nLogonProvider
		, PSID *ppLogonSid = NULL
		, PVOID *ppProfileBuffer = NULL
		, LPDWORD pnProfileLength = NULL
		, PQUOTA_LIMITS pQuotaLimits = NULL
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::LogonUserExA(lpszUsername, lpszDomain, lpszPassword, nLogonType
			, nLogonProvider, &m_h, ppLogonSid, ppProfileBuffer
			, pnProfileLength, pQuotaLimits);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE LogonUserEx
		( LPCWSTR lpszUsername
		, LPCWSTR lpszDomain
		, LPCWSTR lpszPassword
		, DWORD nLogonType
		, DWORD nLogonProvider
		, PSID *ppLogonSid = NULL
		, PVOID *ppProfileBuffer = NULL
		, LPDWORD pnProfileLength = NULL
		, PQUOTA_LIMITS pQuotaLimits = NULL
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::LogonUserExW(lpszUsername, lpszDomain, lpszPassword, nLogonType
			, nLogonProvider, &m_h, ppLogonSid, ppProfileBuffer
			, pnProfileLength, pQuotaLimits);
		_ASSERTE(b);
		return m_h;
	}

	HANDLE OpenProcess
		( HANDLE hProcessHandle
		, DWORD nDesiredAccess
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::OpenProcessToken(hProcessHandle, nDesiredAccess, &m_h);
		ATLASSERT(b);
		return m_h;
	}

	HANDLE OpenThread
		( HANDLE hThreadHandle
		, DWORD nDesiredAccess
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::OpenThreadToken(hThreadHandle, nDesiredAccess, &m_h);
		ATLASSERT(b);
		return m_h;
	}

	HANDLE CreateRestricted
		( HANDLE hExistingTokenHandle
		, DWORD nFlags
		, DWORD nDisableSidCount = 0
		, PSID_AND_ATTRIBUTES pSidsToDisable = NULL
		, DWORD nDeletePrivilegeCount = 0
		, PLUID_AND_ATTRIBUTES pPrivilegesToDelete = NULL
		, DWORD nRestrictedSidCount = 0
		, PSID_AND_ATTRIBUTES pSidsToRestrict = NULL
		)
	{
		_ASSERTE(!IsValid());
		BOOL b;

		b = ::CreateRestrictedToken(hExistingTokenHandle, nFlags
			, nDisableSidCount, pSidsToDisable, nDeletePrivilegeCount
			, pPrivilegesToDelete, nRestrictedSidCount
			, pSidsToRestrict, &m_h);
		ATLASSERT(b);
		return m_h;
	}

	BOOL CreateRestricted
		( DWORD nFlags
		, PHANDLE phNewTokenHandle
		, DWORD nDisableSidCount = 0
		, PSID_AND_ATTRIBUTES pSidsToDisable = NULL
		, DWORD nDeletePrivilegeCount = 0
		, PLUID_AND_ATTRIBUTES pPrivilegesToDelete = NULL
		, DWORD nRestrictedSidCount = 0
		, PSID_AND_ATTRIBUTES pSidsToRestrict = NULL
		)
	{
		_ASSERTE(IsValid());
		
		return ::CreateRestrictedToken(m_h, nFlags, nDisableSidCount
			, pSidsToDisable, nDeletePrivilegeCount, pPrivilegesToDelete
			, nRestrictedSidCount, pSidsToRestrict, phNewTokenHandle);
	}

	BOOL IsRestricted() const
	{
		_ASSERTE(IsValid());

		return ::IsTokenRestricted(m_h);
	}

	BOOL IsUntrusted() const
	{
		_ASSERTE(IsValid());

		return ::IsTokenUntrusted(m_h);
	}

	BOOL DuplicateFrom
		( HANDLE hSource
		, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel
		)
	{
		_ASSERTE(IsValidHandle(hSource));
		_ASSERTE(!IsValid());

		return ::DuplicateToken(hSource, ImpersonationLevel, &m_h);
	}

	BOOL DuplicateFrom
		( HANDLE hSource
		, DWORD nDesiredAccess
		, LPSECURITY_ATTRIBUTES lpTokenAttributes
		, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel
		, TOKEN_TYPE TokenType
		)
	{
		_ASSERTE(IsValidHandle(hSource));
		_ASSERTE(!IsValid());

		return ::DuplicateTokenEx(hSource, nDesiredAccess, lpTokenAttributes
			, ImpersonationLevel, TokenType, &m_h);
	}

	BOOL DuplicateTo
		( LPHANDLE lphDest
		, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel
		) const
	{
		_ASSERTE(lphDest);
		_ASSERTE(IsValid());

		return ::DuplicateToken(m_h, ImpersonationLevel, lphDest);
	}

	BOOL DuplicateTo
		( DWORD nDesiredAccess
		, LPSECURITY_ATTRIBUTES lpTokenAttributes
		, SECURITY_IMPERSONATION_LEVEL ImpersonationLevel
		, TOKEN_TYPE TokenType
		, LPHANDLE lphDest
		) const
	{
		_ASSERTE(lphDest);
		_ASSERTE(IsValid());

		return ::DuplicateTokenEx(m_h, nDesiredAccess, lpTokenAttributes
			, ImpersonationLevel, TokenType, lphDest);
	}

	BOOL ImpersonateLoggedOnUser()
	{
		_ASSERTE(IsValid());

		return ::ImpersonateLoggedOnUser(m_h);
	}

	BOOL SetThread
		( PHANDLE phThread
		)
	{
		return ::SetThreadToken(phThread, m_h);
	}

	BOOL GetInformation
		( TOKEN_INFORMATION_CLASS TokenInformationClass
		, LPVOID lpTokenInformation
		, DWORD nTokenInformationLength
		, PDWORD pnReturnLength
		) const
	{
		_ASSERTE(IsValid());

		return ::GetTokenInformation(m_h, TokenInformationClass
			, lpTokenInformation, nTokenInformationLength, pnReturnLength);
	}

	BOOL SetInformation
		( TOKEN_INFORMATION_CLASS TokenInformationClass
		, LPVOID lpTokenInformation
		, DWORD nTokenInformationLength
		)
	{
		_ASSERTE(IsValid());

		return ::SetTokenInformation(m_h, TokenInformationClass
			, lpTokenInformation, nTokenInformationLength);
	}

	BOOL CreateProcessAsUser
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCSTR lpCurrentDirectory
		, LPSTARTUPINFOA lpStartupInfo
		, LPHANDLE lphProcess = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartupInfo);
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(IsValid());

		return RSDN::CreateProcessAsUser(m_h, lpApplicationName
			, lpCommandLine, lpProcessAttributes, lpThreadAttributes
			, bInheritHandles, nCreationFlags, lpEnvironment
			, lpCurrentDirectory, lpStartupInfo, lphProcess, lphThread
			, lpnProcessId, lpnThreadId);
	}

	BOOL CreateProcessAsUser
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, LPSECURITY_ATTRIBUTES lpProcessAttributes
		, LPSECURITY_ATTRIBUTES lpThreadAttributes
		, BOOL bInheritHandles
		, DWORD nCreationFlags
		, LPVOID lpEnvironment
		, LPCWSTR lpCurrentDirectory
		, LPSTARTUPINFOW lpStartupInfo
		, LPHANDLE lphProcess = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpStartupInfo);
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(IsValid());

		return RSDN::CreateProcessAsUser(m_h, lpApplicationName
			, lpCommandLine, lpProcessAttributes, lpThreadAttributes
			, bInheritHandles, nCreationFlags, lpEnvironment
			, lpCurrentDirectory, lpStartupInfo, lphProcess, lphThread
			, lpnProcessId, lpnThreadId);
	}

	BOOL CreateProcessAsUser
		( LPCSTR lpApplicationName
		, LPSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOA lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCSTR lpCurrentDirectory = NULL
		, LPHANDLE lphProcess = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(IsValid());
		
		return RSDN::CreateProcessAsUser(m_h, lpApplicationName
			, lpCommandLine, nCreationFlags, lpStartupInfo, lpEnvironment
			, lpCurrentDirectory, lphProcess, lphThread, lpnProcessId
			, lpnThreadId);
	}

	BOOL CreateProcessAsUser
		( LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphProcess = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
	{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(IsValid());
		
		return RSDN::CreateProcessAsUser(m_h, lpApplicationName
			, lpCommandLine, nCreationFlags, lpStartupInfo, lpEnvironment
			, lpCurrentDirectory, lphProcess, lphThread, lpnProcessId
			, lpnThreadId);
	}

	BOOL AccessCheck
		( PSECURITY_DESCRIPTOR pSecurityDescriptor
		, DWORD nDesiredAccess
		, PGENERIC_MAPPING pGenericMapping
		, PPRIVILEGE_SET pPrivilegeSet
		, LPDWORD lpnPrivilegeSetLength
		, LPDWORD lpnGrantedAccess
		, LPBOOL lpbAccessStatus
		)
	{
		_ASSERTE(IsValid());

		return ::AccessCheck(pSecurityDescriptor, m_h, nDesiredAccess
			, pGenericMapping, pPrivilegeSet, lpnPrivilegeSetLength
			, lpnGrantedAccess, lpbAccessStatus);
	}

	BOOL AdjustPrivileges
		( BOOL bDisableAllPrivileges
		, PTOKEN_PRIVILEGES pNewState
		, DWORD nBufferLength
		, PTOKEN_PRIVILEGES pPreviousState
		, PDWORD pnReturnLength
		)
	{
		_ASSERTE(IsValid());

		return ::AdjustTokenPrivileges(m_h, bDisableAllPrivileges, pNewState
			, nBufferLength, pPreviousState, pnReturnLength);
	}

	BOOL AdjustGroups
		( BOOL bResetToDefault
		, PTOKEN_GROUPS pNewState
		, DWORD nBufferLength
		, PTOKEN_GROUPS pPreviousState
		, PDWORD pnReturnLength
		)
	{
		_ASSERTE(IsValid());

		return ::AdjustTokenGroups(m_h, bResetToDefault, pNewState
			, nBufferLength, pPreviousState, pnReturnLength);
	}

	BOOL PrivilegeCheck
		( PPRIVILEGE_SET pRequiredPrivileges
		, LPBOOL pbResult
		)
	{
		_ASSERTE(IsValid());

		return ::PrivilegeCheck(m_h, pRequiredPrivileges, pbResult);
	}

	int PrivilegeCheck
		( PPRIVILEGE_SET pRequiredPrivileges
		)
	{
		_ASSERTE(IsValid());
		BOOL pbResult;
	
		if (::PrivilegeCheck(m_h, pRequiredPrivileges, &bResult))
			return !!bResult;
		return -1;
	}

	BOOL ObjectOpenAuditAlarm
		( LPCSTR lpSubsystemName
		, LPVOID lpHandleId
		, LPCSTR lpObjectTypeName
		, LPCSTR lpObjectName
		, PSECURITY_DESCRIPTOR pSecurityDescriptor
		, DWORD nDesiredAccess
		, DWORD nGrantedAccess
		, PPRIVILEGE_SET pPrivileges
		, BOOL bObjectCreation
		, BOOL bAccessGranted
		, LPBOOL lpbGenerateOnClose
		)
	{
		_ASSERTE(IsValid());

		return ::ObjectOpenAuditAlarmA(lpSubsystemName, lpHandleId
			, lpObjectTypeName, lpObjectName, pSecurityDescriptor
			, m_h, nDesiredAccess, nGrantedAccess, pPrivileges
			, bObjectCreation, bAccessGranted, lpbGenerateOnClose);
	}

	BOOL ObjectOpenAuditAlarm
		( LPCWSTR lpSubsystemName
		, LPVOID lpHandleId
		, LPCWSTR lpObjectTypeName
		, LPCWSTR lpObjectName
		, PSECURITY_DESCRIPTOR pSecurityDescriptor
		, DWORD nDesiredAccess
		, DWORD nGrantedAccess
		, PPRIVILEGE_SET pPrivileges
		, BOOL bObjectCreation
		, BOOL bAccessGranted
		, LPBOOL lpbGenerateOnClose
		)
	{
		_ASSERTE(IsValid());

		return ::ObjectOpenAuditAlarmW(lpSubsystemName, lpHandleId
			, lpObjectTypeName, lpObjectName, pSecurityDescriptor
			, m_h, nDesiredAccess, nGrantedAccess, pPrivileges
			, bObjectCreation, bAccessGranted, lpbGenerateOnClose);
	}

	BOOL ObjectPrivilegeAuditAlarm
		( LPCSTR lpSubsystemName
		, LPVOID lpHandleId
		, DWORD nDesiredAccess
		, PPRIVILEGE_SET pPrivileges
		, BOOL bAccessGranted
		)
 	{
		_ASSERTE(IsValid());

		return ::ObjectPrivilegeAuditAlarmA(lpSubsystemName, lpHandleId
			, m_h, nDesiredAccess, pPrivileges, bAccessGranted);
	}

	BOOL ObjectPrivilegeAuditAlarm
		( LPCWSTR lpSubsystemName
		, LPVOID lpHandleId
		, DWORD nDesiredAccess
		, PPRIVILEGE_SET pPrivileges
		, BOOL bAccessGranted
		)
 	{
		_ASSERTE(IsValid());

		return ::ObjectPrivilegeAuditAlarmW(lpSubsystemName, lpHandleId
			, m_h, nDesiredAccess, pPrivileges, bAccessGranted);
	}

	BOOL PrivilegedServiceAuditAlarm
		( LPCSTR lpSubsystemName
		, LPCSTR lpServiceName
		, PPRIVILEGE_SET pPrivileges
		, BOOL bAccessGranted
		)
 	{
		_ASSERTE(IsValid());

		return ::PrivilegedServiceAuditAlarmA(lpSubsystemName, lpServiceName
			, m_h, pPrivileges, bAccessGranted);
	}

	BOOL PrivilegedServiceAuditAlarm
		( LPCWSTR lpSubsystemName
		, LPCWSTR lpServiceName
		, PPRIVILEGE_SET pPrivileges
		, BOOL bAccessGranted
		)
 	{
		_ASSERTE(IsValid());

		return ::PrivilegedServiceAuditAlarmW(lpSubsystemName, lpServiceName
			, m_h, pPrivileges, bAccessGranted);
	}

	BOOL CreatePrivateObjectSecurity
		( PSECURITY_DESCRIPTOR pParentDescriptor
		, PSECURITY_DESCRIPTOR pCreatorDescriptor
		, PSECURITY_DESCRIPTOR *ppNewDescriptor
		, BOOL bIsDirectoryObject
		, PGENERIC_MAPPING pGenericMapping
		)
 	{
		_ASSERTE(IsValid());

		return ::CreatePrivateObjectSecurity(pParentDescriptor
			, pCreatorDescriptor, ppNewDescriptor, bIsDirectoryObject
			, m_h, pGenericMapping);
	}

	BOOL SetPrivateObjectSecurity
		( SECURITY_INFORMATION SecurityInformation
		, PSECURITY_DESCRIPTOR pModificationDescriptor
		, PSECURITY_DESCRIPTOR *ppObjectsSecurityDescriptor
		, PGENERIC_MAPPING pGenericMapping
		)
 	{
		_ASSERTE(IsValid());

		return ::SetPrivateObjectSecurity( SecurityInformation
			, pModificationDescriptor, pModificationDescriptor
			, pGenericMapping, m_h);
	}

	BOOL CheckMembership
		( PSID pSidToCheck
		, PBOOL pbIsMember
		) const
 	{
		_ASSERTE(pbIsMember);

		return ::CheckTokenMembership(m_h, pSidToCheck, pbIsMember);
	}

	int CheckMembership
		( PSID pSidToCheck
		) const
 	{
		BOOL bIsMember;

		if (::CheckTokenMembership(m_h, pSidToCheck, &bIsMember))
			return !!bIsMember;
		return -1;
	}

#if _WIN32_WINNT >= 0x0500
	BOOL AccessCheckByType
		( PSECURITY_DESCRIPTOR pSecurityDescriptor
		, PSID pPrincipalSelfSid
		, DWORD nDesiredAccess
		, POBJECT_TYPE_LIST pObjectTypeList
		, DWORD nObjectTypeListLength
		, PGENERIC_MAPPING pGenericMapping
		, PPRIVILEGE_SET pPrivilegeSet
		, LPDWORD lpnPrivilegeSetLength
		, LPDWORD lpnGrantedAccess
		, LPBOOL lpbAccessStatus
		)
	{
		_ASSERTE(IsValid());

		return ::AccessCheckByType(pSecurityDescriptor, pPrincipalSelfSid
			, m_h, nDesiredAccess, pObjectTypeList, nObjectTypeListLength
			, pGenericMapping, pPrivilegeSet, lpnPrivilegeSetLength
			, lpnGrantedAccess, lpbAccessStatus);
	}

	BOOL AccessCheckByTypeResultList
		( PSECURITY_DESCRIPTOR pSecurityDescriptor
		, PSID pPrincipalSelfSid
		, DWORD nDesiredAccess
		, POBJECT_TYPE_LIST pObjectTypeList
		, DWORD nObjectTypeListLength
		, PGENERIC_MAPPING pGenericMapping
		, PPRIVILEGE_SET pPrivilegeSet
		, LPDWORD lpnPrivilegeSetLength
		, LPDWORD lpnGrantedAccess
		, LPDWORD lpnAccessStatusList
		)
	{
		_ASSERTE(IsValid());

		return ::AccessCheckByTypeResultList(pSecurityDescriptor, pPrincipalSelfSid
			, m_h, nDesiredAccess, pObjectTypeList, nObjectTypeListLength
			, pGenericMapping, pPrivilegeSet, lpnPrivilegeSetLength
			, lpnGrantedAccess, lpnAccessStatusList);
	}

	BOOL AccessCheckByTypeResultListAndAuditAlarmByHandle
		( LPCSTR lpSubsystemName
		, LPVOID lpHandleId
		, LPCSTR lpObjectTypeName
		, LPCSTR lpObjectName
		, PSECURITY_DESCRIPTOR pSecurityDescriptor
		, PSID pPrincipalSelfSid
		, DWORD nDesiredAccess
		, AUDIT_EVENT_TYPE AuditType
		, DWORD nFlags
		, POBJECT_TYPE_LIST pObjectTypeList
		, DWORD nObjectTypeListLength
		, PGENERIC_MAPPING pGenericMapping
		, BOOL bObjectCreation
		, LPDWORD pnGrantedAccess
		, LPDWORD pnAccessStatusList
		, LPBOOL lpbGenerateOnClose
		)
	{
		_ASSERTE(IsValid());

		return ::AccessCheckByTypeResultListAndAuditAlarmByHandleA
			( lpSubsystemName, lpHandleId, m_h, lpObjectTypeName
			, lpObjectName, pSecurityDescriptor, pPrincipalSelfSid
			, nDesiredAccess, AuditType, nFlags, pObjectTypeList
			, nObjectTypeListLength, pGenericMapping, pnGrantedAccess
			, pnAccessStatusList, lpbGenerateOnClose);
	}

	BOOL AccessCheckByTypeResultListAndAuditAlarmByHandle
		( LPCWSTR lpSubsystemName
		, LPVOID lpHandleId
		, LPCWSTR lpObjectTypeName
		, LPCWSTR lpObjectName
		, PSECURITY_DESCRIPTOR pSecurityDescriptor
		, PSID pPrincipalSelfSid
		, DWORD nDesiredAccess
		, AUDIT_EVENT_TYPE AuditType
		, DWORD nFlags
		, POBJECT_TYPE_LIST pObjectTypeList
		, DWORD nObjectTypeListLength
		, PGENERIC_MAPPING pGenericMapping
		, BOOL bObjectCreation
		, LPDWORD pnGrantedAccess
		, LPDWORD pnAccessStatusList
		, LPBOOL lpbGenerateOnClose
		)
	{
		_ASSERTE(IsValid());

		return ::AccessCheckByTypeResultListAndAuditAlarmByHandleW
			( lpSubsystemName, lpHandleId, m_h, lpObjectTypeName
			, lpObjectName, pSecurityDescriptor, pPrincipalSelfSid
			, nDesiredAccess, AuditType, nFlags, pObjectTypeList
			, nObjectTypeListLength, pGenericMapping, pnGrantedAccess
			, pnAccessStatusList, lpbGenerateOnClose);
	}

	BOOL CreatePrivateObjectSecurityEx
		( PSECURITY_DESCRIPTOR pParentDescriptor
		, PSECURITY_DESCRIPTOR pCreatorDescriptor
		, PSECURITY_DESCRIPTOR *ppNewDescriptor
		, GUID *pObjectType
		, BOOL bIsContainerObject
		, ULONG nAutoInheritFlags
		, PGENERIC_MAPPING pGenericMapping
		)
 	{
		_ASSERTE(IsValid());

		return ::CreatePrivateObjectSecurityEx(pParentDescriptor
			, pCreatorDescriptor, ppNewDescriptor, pObjectType
			, bIsContainerObject, nAutoInheritFlags, m_h, pGenericMapping);
	}

	BOOL CreatePrivateObjectSecurityWithMultipleInheritance
		( PSECURITY_DESCRIPTOR pParentDescriptor
		, PSECURITY_DESCRIPTOR pCreatorDescriptor
		, PSECURITY_DESCRIPTOR *ppNewDescriptor
		, GUID **ppObjectTypes
		, ULONG nGuidCount
		, BOOL bIsContainerObject
		, ULONG nAutoInheritFlags
		, PGENERIC_MAPPING pGenericMapping
		)
 	{
		_ASSERTE(IsValid());

		return ::CreatePrivateObjectSecurityWithMultipleInheritance
			( pParentDescriptor, pCreatorDescriptor, ppNewDescriptor
			, ppObjectTypes, nGuidCount, bIsContainerObject
			, nAutoInheritFlags, m_h, pGenericMapping);
	}

	BOOL SetPrivateObjectSecurityEx
		( SECURITY_INFORMATION SecurityInformation
		, PSECURITY_DESCRIPTOR pModificationDescriptor
		, PSECURITY_DESCRIPTOR *ppObjectsSecurityDescriptor
		, ULONG nAutoInheritFlags
		, PGENERIC_MAPPING pGenericMapping
		)
 	{
		_ASSERTE(IsValid());

		return ::SetPrivateObjectSecurityEx( SecurityInformation
			, pModificationDescriptor, pModificationDescriptor
			, nAutoInheritFlags, pGenericMapping, m_h);
	}

	BOOL CreateProcessWithToken
		( DWORD nLogonFlags
		, LPCWSTR lpApplicationName
		, LPWSTR lpCommandLine
		, DWORD nCreationFlags = 0
		, LPSTARTUPINFOW lpStartupInfo = NULL
		, LPVOID lpEnvironment = NULL
		, LPCWSTR lpCurrentDirectory = NULL
		, LPHANDLE lphProcess = NULL
		, LPHANDLE lphThread = NULL
		, LPDWORD lpnProcessId = NULL
		, LPDWORD lpnThreadId = NULL
		)
{
		_ASSERTE(lpApplicationName || lpCommandLine);
		_ASSERTE(IsValid());

		return RSDN::CreateProcessWithToken(m_h, nLogonFlags
			, lpApplicationName, lpCommandLine, nCreationFlags, lpStartupInfo
			, lpEnvironment, lpCurrentDirectory, lphProcess, lphThread
			, lpnProcessId, lpnThreadId);
	}
#endif // _WIN32_WINNT >= 0x0500
};

typedef CTokenT<true> CToken;
typedef CTokenT<false> CTokenHandle;

#ifdef _INC_TOOLHELP32

/////////////////////////////////////////////////////////////////////////////
// ToolhelpSnapshot

template<bool t_bManaged>
class CToolhelpSnapshotT
	: public CHandleT<t_bManaged>
{
	typedef CHandleT<t_bManaged> Base;
public:

	CToolhelpSnapshotT()
	{ }
	CToolhelpSnapshotT
		( const CToolhelpSnapshotT<true>& rToolhelpSnapshot
		)
		: Base(rToolhelpSnapshot)
	{ }
	CToolhelpSnapshotT
		( const CToolhelpSnapshotT<false>& rToolhelpSnapshot
		)
		: Base(rToolhelpSnapshot)
	{ }
	explicit CToolhelpSnapshotT
		( HANDLE hToolhelpSnapshot
		)
		: Base((INVALID_HANDLE_VALUE != hToolhelpSnapshot) ? hToolhelpSnapshot : NULL)
	{ }

	explicit CToolhelpSnapshotT
		( DWORD nFlags
		, DWORD nProcessId = 0
		)
	{
		Create(nFlags, nProcessId);
		_ASSERTE(IsValid());
	}

	CToolhelpSnapshotT<t_bManaged>& operator=(HANDLE h)
	{
		Base::operator=((INVALID_HANDLE_VALUE != h) ? h : NULL);
		return *this;
	}

	CToolhelpSnapshotT<t_bManaged>& operator=
		(const CToolhelpSnapshotT<true>& other)
	{
		Base::operator=(other);
		return *this;
	}

	CToolhelpSnapshotT<t_bManaged>& operator=
		(const CToolhelpSnapshotT<false>& other)
	{
		Base::operator=(other);
		return *this;
	}

	HANDLE Create
		( DWORD nFlags
		, DWORD nProcessId = 0
		)
	{
		_ASSERTE(!IsValid());
		HANDLE h;

		h = ::CreateToolhelp32Snapshot(nFlags, nProcessId);
		if (INVALID_HANDLE_VALUE == h)
			h = NULL;
		return m_h = h;
	}

	BOOL First(LPHEAPLIST32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(HEAPLIST32));
		_ASSERTE(IsValid());

		return ::Heap32ListFirst(m_h, pData);
	}

	BOOL Next(LPHEAPLIST32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(HEAPLIST32));
		_ASSERTE(IsValid());

		return ::Heap32ListNext(m_h, pData);
	}

	BOOL First(LPPROCESSENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(PROCESSENTRY32));
		_ASSERTE(IsValid());

		return ::Process32First(m_h, pData);
	}

	BOOL Next(LPPROCESSENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(PROCESSENTRY32));
		_ASSERTE(IsValid());

		return ::Process32Next(m_h, pData);
	}

#ifndef UNICODE
	BOOL First(LPPROCESSENTRY32W pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(PROCESSENTRY32W));
		_ASSERTE(IsValid());

		return ::Process32FirstW(m_h, pData);
	}

	BOOL Next(LPPROCESSENTRY32W pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(PROCESSENTRY32W));
		_ASSERTE(IsValid());

		return ::Process32NextW(m_h, pData);
	}
#endif // UNICODE

	BOOL First(LPMODULEENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(MODULEENTRY32));
		_ASSERTE(IsValid());

		return ::Module32First(m_h, pData);
	}

	BOOL Next(LPMODULEENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(MODULEENTRY32));
		_ASSERTE(IsValid());

		return ::Module32Next(m_h, pData);
	}

#ifndef UNICODE
	BOOL First(LPMODULEENTRY32W pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(MODULEENTRY32W));
		_ASSERTE(IsValid());

		return ::Module32FirstW(m_h, pData);
	}

	BOOL Next(LPMODULEENTRY32W pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(MODULEENTRY32W));
		_ASSERTE(IsValid());

		return ::Module32NextW(m_h, pData);
	}
#endif // UNICODE

	BOOL First(LPTHREADENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(THREADENTRY32));
		_ASSERTE(IsValid());

		return ::Thread32First(m_h, pData);
	}

	BOOL Next(LPTHREADENTRY32 pData)
	{
		_ASSERTE(pData && pData->dwSize == sizeof(THREADENTRY32));
		_ASSERTE(IsValid());

		return ::Thread32Next(m_h, pData);
	}
};

typedef CToolhelpSnapshotT<true> CToolhelpSnapshot;
typedef CToolhelpSnapshotT<false> CToolhelpSnapshotHandle;

#endif // _INC_TOOLHELP32

/////////////////////////////////////////////////////////////////////////////

}	// namespace RSDN

/////////////////////////////////////////////////////////////////////////////

#endif	// #ifndef __RSDN_CPROC_H__

/////////////////////////////////////////////////////////////////////////////
// End Of File CProc.h
