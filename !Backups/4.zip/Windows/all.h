#ifndef _WINDOWS_ALL_H_
#define _WINDOWS_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2004 Jan van den Baard
//     All Rights Reserved.
//

#include "window.h"
#include "cfwindow.h"
#include "dialog.h"
#include "mdiwindow.h"
#include "messagebox.h"

#endif // _WINDOWS_ALL_H_