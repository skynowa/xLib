// ADO.cpp: implementation of the CADO class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ADO.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#include "ado.h"
#include <afxdisp.h>

DWORD CAdoDatabase::GetRecordCount(_RecordsetPtr m_pRs)
{
	DWORD numRows = 0;
	
	numRows = m_pRs->GetRecordCount();

	if(numRows == -1)
	{
		if(m_pRs->adoEOF != VARIANT_TRUE)
			m_pRs->MoveFirst();

		while(m_pRs->adoEOF != VARIANT_TRUE)
		{
			numRows++;
			m_pRs->MoveNext();
		}
		if(numRows > 0)
			m_pRs->MoveFirst();
	}
	return numRows;
}

bool CAdoDatabase::Open(LPCTSTR lpstrConnection)
{
	

	HRESULT hr = S_OK;

	if(IsOpen())
	{
		Close();
	}

	if(wcscmp((USHORT*)lpstrConnection, L"" ) != 0)
		m_strConnection = lpstrConnection;

	ASSERT(!m_strConnection.IsEmpty());

	try
	{
		hr = m_pConnection->Open(_bstr_t(m_strConnection), "", "", -1);
		
		return hr == S_OK;
	}
	catch(_com_error &e)
	{
		dump_com_error(e);
	}
	return false;
}

void CAdoDatabase::dump_com_error(_com_error &e)
{
	CString ErrorStr;
	
	
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CAdoDatabase Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		(LPCTSTR) e.Error(), (LPCTSTR) e.ErrorMessage(), (LPCTSTR)bstrSource, (LPCTSTR)bstrDescription );
	m_strLastError = _T("Connection String = " + GetConnectionString() + '\n' + ErrorStr);
	#ifdef _DEBUG
		//AfxMessageBox( ErrorStr, MB_OK | MB_ICONERROR );
	#endif	
}

bool CAdoDatabase::IsOpen()
{
	if(m_pConnection )
		return m_pConnection->GetState() != adStateClosed;
	return false;
}

void CAdoDatabase::Close()
{
	if(IsOpen())
		m_pConnection->Close();
}

bool CAdoRecordset::Open(_ConnectionPtr mpdb, LPCTSTR lpstrExec)
{	
	Close();
	
	if(wcscmp((USHORT*)lpstrExec, L"" ) != 0)
		m_strQuery = lpstrExec;


	ASSERT(!m_strQuery.IsEmpty());
	
	//m_strQuery.TrimLeft();
	BOOL bIsSelect = m_strQuery.Mid(0, wcslen(L"Select ")).CompareNoCase(_T("select ")) == 0;

	try
	{
		if(bIsSelect)
		{
			//m_pRecordset->Open((LPCTSTR)m_strQuery, _variant_t((IDispatch*)mpdb, true), adOpenStatic, adLockOptimistic, adCmdUnknown);
			m_pRecordset->Open(lpstrExec, mpdb.GetInterfacePtr(), adOpenDynamic, adLockBatchOptimistic, -1);
		}
		else
		{
			m_pCmd->ActiveConnection = mpdb;
			m_pCmd->CommandText = _bstr_t(m_strQuery);
			m_pCmd->CommandType = adCmdStoredProc;
			
			m_pRecordset = m_pCmd->Execute(NULL, NULL, adCmdText);
		}
	}
	catch(_com_error &e)
	{
		m_bstrLastError			= e.Description();
		throw;
		//dump_com_error(e);
		return FALSE;
	}

	return m_pRecordset != NULL;
}

bool CAdoRecordset::Open(_ConnectionPtr mpdb, LPCTSTR lpstrExec, CursorTypeEnum crsType, LockTypeEnum lckType, CursorLocationEnum crsLoc)
{	
	Close();
	
	if(wcscmp((USHORT*)lpstrExec, L"" ) != 0)
		m_strQuery = lpstrExec;

	ASSERT(!m_strQuery.IsEmpty());
	
	//m_strQuery.TrimLeft();


	try
	{
		m_pRecordset->CursorLocation	= crsLoc;
		
		m_pRecordset->Open(lpstrExec, mpdb.GetInterfacePtr(),
							crsType, lckType, adCmdUnknown);
	}
	catch(_com_error &e)
	{
		m_bstrLastError			= e.Description();
		throw;
		//dump_com_error(e);
		return FALSE;
	}

	return m_pRecordset != NULL;
}


bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, double& dbValue)
{	
	double val = (double)NULL;
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	if(vtFld.vt != VT_NULL)
		val = vtFld.dblVal;
	dbValue = val;
	return true;
}


bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, long& lValue)
{
	long val = (long)NULL;
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	if(vtFld.vt != VT_NULL)
		val = vtFld.lVal;
	lValue = val;
	return true;
}

bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, int& nValue)
{
	int val = NULL;
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	switch(vtFld.vt)
	{
	case VT_I2:
		val = vtFld.iVal;
		break;
	case VT_BOOL:
		val = vtFld.boolVal;
	case VT_NULL:
	case VT_EMPTY:
		break;
	default:
		nValue = 0;
		return false;
	}	
	nValue = val;
	return true;
}

bool CAdoRecordset::IsFieldNull(LPCTSTR lpFieldName)
{
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	return vtFld.vt == VT_NULL;
}

bool CAdoRecordset::IsFieldNull(int nIndex)
{
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	return vtFld.vt == VT_NULL;
}

bool CAdoRecordset::IsFieldEmpty(LPCTSTR lpFieldName)
{
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
}

bool CAdoRecordset::IsFieldEmpty(int nIndex)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
		
	vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	return vtFld.vt == VT_EMPTY || vtFld.vt == VT_NULL;
}

bool CAdoRecordset::GetFieldValue(int nIndex, int& nValue)
{
	int val = (int)NULL;
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	switch(vtFld.vt)
	{
	case VT_I2:
		val = vtFld.iVal;
		break;
	case VT_NULL:
	case VT_EMPTY:
		val = 0;
		break;
	default:
		return false;
	}	
	nValue = val;
	return true;
}

bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, CString& strValue)
{
	CString str = _T("");
	_variant_t vtFld;
	
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	

	switch(vtFld.vt) 
	{
	case VT_BSTR:
		str = vtFld.bstrVal;
		break;
	case VT_I4:
		str = IntToStr(vtFld.iVal);
		break;
	case VT_DATE:
		{
			COleDateTime dt(vtFld);

			str = dt.Format(_T("%Y-%m-%d %H:%M:%S"));
		}
		break;
	case VT_EMPTY:
	case VT_NULL:
		break;
	default:
		strValue.Empty();
		return false;
	}
	strValue = str;
	return true;
}

bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, _bstr_t *bstrValue)
{
	CComVariant		var;
	var				= m_pRecordset->Fields->GetItem(lpFieldName)->Value;

	if(var.vt	== VT_NULL)  
	{
		*bstrValue	="";
	}
	else
	{
		var.ChangeType(VT_BSTR);
		//bstrValue		= ::SysAllocString(V_BSTR(&var));	//memory leak ?to test that//SysReAllocString
		*bstrValue		= V_BSTR(&var);
	}
	return true;
}
bool CAdoRecordset::GetFieldValue(int nIndex, _bstr_t *bstrValue)
{
	CComVariant		var;
	_variant_t		vtIndex;

	vtIndex.vt		= VT_I2;
	vtIndex.iVal	= nIndex;

	var				= m_pRecordset->Fields->GetItem(vtIndex)->Value;

	if(var.vt	== VT_NULL)  
	{
		*bstrValue	="";
	}
	else
	{
		var.ChangeType(VT_BSTR);
		//bstrValue		= ::SysAllocString(V_BSTR(&var));	//memory leak ?to test that//SysReAllocString
		*bstrValue		= V_BSTR(&var);
	}
	
	return true;
}


bool CAdoRecordset::GetFieldValue(int nIndex, CString& strValue)
{
	CString str = _T("");
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	switch(vtFld.vt) 
	{
	case VT_BSTR:
		str = vtFld.bstrVal;
		break;
	case VT_DATE:
		{
			COleDateTime dt(vtFld);
			
			str = dt.Format(_T("%Y-%m-%d %H:%M:%S"));
		}
		break;
	case VT_EMPTY:
	case VT_NULL:
		break;
	default:
		strValue.Empty();
		return false;
	}
	strValue = str;
	return true;
}

bool CAdoRecordset::GetFieldValue(LPCTSTR lpFieldName, COleDateTime& time)
{
	_variant_t vtFld;
	
	vtFld = m_pRecordset->Fields->GetItem(lpFieldName)->Value;
	switch(vtFld.vt) 
	{
	case VT_DATE:
		{
			COleDateTime dt(vtFld);
			time = dt;
		}
		break;
	case VT_EMPTY:
	case VT_NULL:
		break;
	default:
		return false;
	}
	return true;
}

bool CAdoRecordset::GetFieldValue(int nIndex, COleDateTime& time)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	vtFld = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	switch(vtFld.vt) 
	{
	case VT_DATE:
		{
			COleDateTime dt(vtFld);
			time = dt;
		}
		break;
	case VT_EMPTY:
	case VT_NULL:
		break;
	default:
		return false;
	}
	return true;
}

DWORD CAdoRecordset::GetRecordCount()
{
	DWORD nRows = 0;
	
	nRows = m_pRecordset->GetRecordCount();

	if(nRows == -1)
	{
		nRows = 0;
		if(m_pRecordset->adoEOF != VARIANT_TRUE)
			m_pRecordset->MoveFirst();
		
		while(m_pRecordset->adoEOF != VARIANT_TRUE)
		{
			nRows++;
			m_pRecordset->MoveNext();
		}
		if(nRows > 0)
			m_pRecordset->MoveFirst();
	}
	
	return nRows;
}

bool CAdoRecordset::IsOpen()
{
	if(m_pRecordset)
	{
		
		return m_pRecordset->GetState() != adStateClosed;
		
	}
	else
		return false;
}

void CAdoRecordset::Close() 
{
	//AfxMessageBox(_T("close"));
	 
	if(IsOpen())
	{

		m_pRecordset->Close(); 
		//m_pRecordset->PutRefActiveConnection(NULL);
		 
		//m_pRecordset = NULL;
	}	
}


bool CAdoDatabase::Execute(LPCTSTR lpstrExec, long *lNrRows)
{
	ASSERT(m_pConnection != NULL);
	ASSERT(wcscmp((USHORT*)lpstrExec, L"" ) != 0);


	try
	{
		_variant_t			*var	= new _variant_t;
												//====		here will be 
												//  ||		the nr of rows affected	
												//  \/
		m_pConnection->Execute(_bstr_t(lpstrExec), var, adExecuteNoRecords);
		//m_pConnection->Execute(_bstr_t(lpstrExec), var, -1);

		*lNrRows			= var->lVal;
		//*lNrRows			= (long)*var;
		delete				var;

	}
	catch(_com_error &e)
	{
		dump_com_error(e);
		return false;
	}


	return true;	
}

//********************************************************************************************

bool CAdoRecordset::RecordBinding(CADORecordBinding &pAdoRecordBinding)
{
	IADORecordBinding *picRs = NULL;
	HRESULT hr;

	//Open the binding interface.
	if(FAILED(hr = m_pRecordset->QueryInterface(__uuidof(IADORecordBinding), (LPVOID*)&picRs )))
	{
		_com_issue_error(hr);
		return false;
	}
	
	//Bind the recordset to class
	if(FAILED( hr = picRs->BindToRecordset(&pAdoRecordBinding)))
	{
		_com_issue_error(hr);
		return false;
	}
	return true;
}

void CAdoRecordset::dump_com_error(_com_error &e)
{
	CString ErrorStr;
	
	
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	ErrorStr.Format( _T("CAdoRecordset Error\n\tCode = %08lx\n\tCode meaning = %s\n\tSource = %s\n\tDescription = %s\n"),
		e.Error(), e.ErrorMessage(), (LPCSTR)bstrSource, (LPCSTR)bstrDescription );
	m_bstrLastError = _T("Query = " + GetQuery() + '\n' + ErrorStr);

	#ifdef _DEBUG
		AfxMessageBox( ErrorStr, MB_OK | MB_ICONERROR );
	#endif	
}

bool CAdoRecordset::GetFieldInfo(LPCTSTR lpFieldName, CAdoFieldInfo* fldInfo)
{
	_variant_t vtFld;
	
	wcscpy((USHORT*)(LPCTSTR)fldInfo->m_strName, (USHORT*)(LPCTSTR)m_pRecordset->Fields->GetItem(lpFieldName)->GetName());
	fldInfo->m_lSize = m_pRecordset->Fields->GetItem(lpFieldName)->GetActualSize();
	fldInfo->m_lDefinedSize = m_pRecordset->Fields->GetItem(lpFieldName)->GetDefinedSize();
	fldInfo->m_nType = m_pRecordset->Fields->GetItem(lpFieldName)->GetType();
	fldInfo->m_lAttributes = m_pRecordset->Fields->GetItem(lpFieldName)->GetAttributes();
	return true;
}

bool CAdoRecordset::GetFieldInfo(int nIndex, CAdoFieldInfo* fldInfo)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
		
	wcscpy((USHORT*)(LPCTSTR)fldInfo->m_strName, (USHORT*)(LPCTSTR)m_pRecordset->Fields->GetItem(vtIndex)->GetName());
	fldInfo->m_lSize = m_pRecordset->Fields->GetItem(vtIndex)->GetActualSize();
	fldInfo->m_lDefinedSize = m_pRecordset->Fields->GetItem(vtIndex)->GetDefinedSize();
	fldInfo->m_nType = m_pRecordset->Fields->GetItem(vtIndex)->GetType();
	fldInfo->m_lAttributes = m_pRecordset->Fields->GetItem(vtIndex)->GetAttributes();

	m_pRecordset->Fields->GetItem(vtIndex)->GetName();
	return true;
}

_bstr_t CAdoRecordset::GetFieldName(int nIndex)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;	

	return	m_pRecordset->Fields->GetItem(vtIndex)->GetName();
}

bool CAdoRecordset::GetChunk(LPCTSTR lpFieldName, CString& strValue)
{
	CString str = _T("");
	long lngSize, lngOffSet = 0;
	_variant_t varChunk;    
	int ChunkSize = 100;

	lngSize = m_pRecordset->Fields->GetItem(lpFieldName)->ActualSize;
	
	str.Empty();
	while(lngOffSet < lngSize)
	{
		varChunk = m_pRecordset->Fields->GetItem(lpFieldName)->GetChunk(ChunkSize);
		str += varChunk.bstrVal;
		lngOffSet += ChunkSize;
	}

	lngOffSet = 0;
	strValue = str;
	return TRUE;
}

_bstr_t CAdoRecordset::GetString(LPCTSTR lpCols, LPCTSTR lpRows, long numRows)
{
	_bstr_t varOutput;
	_bstr_t varNull("");
	_bstr_t varCols("\t");
	_bstr_t varRows("\r");

	if(wcslen((USHORT*)lpCols) != 0)
		varCols = _bstr_t(lpCols);

	if(wcslen((USHORT*)lpRows) != 0)
		varRows = _bstr_t(lpRows);
	
	if(numRows == 0)
		numRows =(long)GetRecordCount();			
			
	varOutput = m_pRecordset->GetString(adClipString, numRows, varCols, varRows, varNull);

	return (_bstr_t)varOutput;
}

CString IntToStr(int nVal)
{
	CString strRet;
	char buff[10];
	
	itoa(nVal, buff, 10);
	strRet = buff;
	return strRet;
}

CString LongToStr(long lVal)
{
	CString strRet;
	char buff[20];
	
	ltoa(lVal, buff, 10);
	strRet = buff;
	return strRet;
}


_RecordsetPtr		CAdoRecordset::GetRSdisc()
{
	_RecordsetPtr pRS	= NULL;

	try
	{	// Get a disconnected recordset
		
		//1 method
		pRS					= m_pRecordset->Clone(adLockReadOnly);
		pRS->AddRef(); 

		//Disassociate the connection from the recordset.
		//pRS->PutRefActiveConnection(NULL);

		//3 method
		//HRESULT hr = m_pRecordset->QueryInterface(__uuidof(_Recordset),(void **)&pRS);
	}

	catch(_com_error &e)
	{
		m_bstrLastError			= e.Description();
		throw;
		//dump_com_error(e);
		return FALSE;
	}

	return	pRS;
}

_RecordsetPtr		CAdoRecordset::GetRSconn()
{
	try
	{
		// Get a connected recordset

		m_pRecordset->AddRef(); 
		//m_pRecordset->PutRefActiveConnection(NULL);
	}

	catch(_com_error &e)
	{
		m_bstrLastError			= e.Description();
		throw;

		//dump_com_error(e);
		return FALSE;
	}

	return	m_pRecordset;
}

bool CAdoRecordset::GetRows(int intNumber, _variant_t& avarData)
{
	
    // Store results of GetRows method in array.
    avarData = m_pRecordset->GetRows(intNumber);
    
    // Return False only if fewer than the desired
    // number of rows were returned, but not because the
    // end of the Recordset was reached.
    long lUXbound, lUYbound;
    HRESULT hrX, hrY;
	hrX		= SafeArrayGetUBound(avarData.parray,1,&lUXbound);   
	hrY		= SafeArrayGetUBound(avarData.parray,2,&lUYbound);   
    if ((hrX == 0)&&(hrY == 0))
    {
/*		CString ttt;
		ttt.Format(_T("%d"), lUXbound);
		AfxMessageBox(ttt);

		ttt.Format(_T("%d"), lUYbound);
		AfxMessageBox(ttt);
*/	
		return true;
    }
    else 
    {
        m_bstrLastError		=	OLESTR("\nUnable to Get the Array's Upper Bound\n");
        return false;
    }
}

bool CAdoRecordset::GetRSArray(VARIANT * pvar)
{
		HRESULT hr;
		_variant_t var;

		// Clear return value.
		VariantClear(pvar);

		SAFEARRAY * pSA;
		// Create the safearray.
		SAFEARRAYBOUND sabRSarray[1];		// A one-dimensional array.
		sabRSarray[0].cElements		=1;		// 1 element.
		sabRSarray[0].lLbound		=0;		//Lower bound of array.

		pSA=SafeArrayCreate(VT_VARIANT,1, sabRSarray);


		// Disassociate the connection from the recordset.
		m_pRecordset->PutRefActiveConnection(NULL);

		// Copy IDispatch pointer of recordset into our _variant_t array.
        // This will AddRef the recordset one time (refcount now is 2).
		var				= _variant_t( (IDispatch*) m_pRecordset );
		m_pRecordset	= NULL;		// refcount now is 1, variants contain last reference to recordsets.
		
		 // Fill the safearray.
		long ndex;
		ndex = 0;
		hr=SafeArrayPutElement(pSA, &ndex, &var);

		
		// Load the safearray into an output variable.
	   pvar->vt = VT_ARRAY|VT_VARIANT;
	   pvar->parray = pSA;

	return true;
}

int CAdoRecordset::GetFieldsCount()
{

	return	m_pRecordset->Fields->GetCount();
}