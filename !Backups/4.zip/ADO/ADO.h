// ADO.h: interface for the CADO class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADO_H__C4AA1DE8_59BD_11D5_96F9_00A0D212FC63__INCLUDED_)
#define AFX_ADO_H__C4AA1DE8_59BD_11D5_96F9_00A0D212FC63__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
//#include "stdafx.h"

//#import "C:\Program Files\Common Files\System\ADO\msado15.dll"  rename("EOF", "EndOfFile") nonamespace
#import "c:\program files\common files\system\ado\msado15.dll" rename("EOF","adoEOF") no_namespace
//#import  <msado15.dll> rename("EOF", "adoEOF") no_namespace


#include "icrsint.h"

// ado.h : header file
//


struct CAdoFieldInfo
{
	char m_strName[30]; 
	short m_nType;
	long m_lSize; 
	long m_lDefinedSize;
	long m_lAttributes;
	short m_nOrdinalPosition;
	BOOL m_bRequired;   
	BOOL m_bAllowZeroLength; 
	long m_lCollatingOrder;  
};

CString IntToStr(int nVal);

CString LongToStr(long lVal);

class CAdoDatabase
{
public:
	bool Execute(LPCTSTR lpstrExec, long *lNrRows);
	CAdoDatabase()
	{
		
		::CoInitialize(NULL);
			
		m_pConnection = NULL;
		m_strConnection = _T("");
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pRecordset.CreateInstance(__uuidof(Recordset));
		m_pCmd.CreateInstance(__uuidof(Command));
	}
	
	~CAdoDatabase()
	{
		Close();
		//====
		//  ||
		//  \/

		m_pRecordset.Release();
		m_pCmd.Release();
		m_pRecordset = NULL;
		m_pCmd = NULL;

		m_pConnection.Release();
		m_pConnection = NULL;
		::CoUninitialize();
	}
	
	bool Open(LPCTSTR lpstrConnection = _T(""));
	_ConnectionPtr GetActiveConnection() {return m_pConnection;};
	DWORD GetRecordCount(_RecordsetPtr m_pRs);
	long BeginTransaction() 
		{return m_pConnection->BeginTrans();};
	long CommitTransaction() 
		{return m_pConnection->CommitTrans();};
	long RollbackTransaction() 
		{return m_pConnection->RollbackTrans();};
	bool IsOpen();
	void Close();
	void SetConnectionString(LPCTSTR lpstrConnection)
		{m_strConnection = lpstrConnection;};
	CString GetConnectionString()
		{return m_strConnection;};
	CString GetLastError() 
		{return m_strLastError;};
protected:
	void dump_com_error(_com_error &e);

protected:
	_ConnectionPtr		m_pConnection;
	_RecordsetPtr		m_pRecordset;
	_CommandPtr			m_pCmd;

	CString				m_strConnection;
	CString				m_strLastError;
};


//**************************************************************************************

class CAdoRecordset
{
public:
	CAdoRecordset()
	{
		m_pRecordset			= NULL;
		m_pCmd					= NULL;
		m_strQuery				= _T("");
		m_bstrLastError			= _T("");
		m_pRecordset.CreateInstance(__uuidof(Recordset));
		m_pCmd.CreateInstance(__uuidof(Command));
	}
	~CAdoRecordset()
	{

		Close();
		m_pRecordset.Release();
		m_pCmd.Release();
		m_pRecordset = NULL;
		m_pCmd = NULL;
		m_strQuery = _T("");
	}

	CString GetQuery() 
		{return m_strQuery;};
	void SetQuery(LPCSTR strQuery) 
		{m_strQuery = strQuery;};
	bool RecordBinding(CADORecordBinding &pAdoRecordBinding);
	DWORD GetRecordCount();
	bool IsOpen();
	void Close();
	
	bool Open(_ConnectionPtr mpdb, LPCTSTR lpstrExec = _T(""));
	bool Open(_ConnectionPtr mpdb, LPCTSTR lpstrExec,CursorTypeEnum,LockTypeEnum,CursorLocationEnum);

	bool GetFieldValue(LPCTSTR lpFieldName, double& dbValue);
	bool GetFieldValue(int nIndex, double& dbValue);
	bool GetFieldValue(LPCTSTR lpFieldName, long& lValue);
	bool GetFieldValue(int nIndex, long& lValue);
	bool GetFieldValue(LPCTSTR lpFieldName, int& nValue);
	bool GetFieldValue(int nIndex, int& nValue);
	bool GetFieldValue(LPCTSTR lpFieldName, CString& strValue);
	
	bool GetFieldValue(LPCTSTR lpFieldName, _bstr_t *bstrValue);
	bool GetFieldValue(int nIndex,			_bstr_t *bstrValue);

	bool GetFieldValue(int nIndex, CString& strValue);
	bool GetFieldValue(LPCTSTR lpFieldName, COleDateTime& time);
	bool GetFieldValue(int nIndex, COleDateTime& time);
	bool IsFieldNull(LPCTSTR lpFieldName);
	bool IsFieldNull(int nIndex);
	bool IsFieldEmpty(LPCTSTR lpFieldName);
	bool IsFieldEmpty(int nIndex);	
	bool IsEof()
		{return m_pRecordset->adoEOF == VARIANT_TRUE;};
	bool IsBof()
		{return m_pRecordset->BOF == VARIANT_TRUE;};
	void MoveFirst() 
		{m_pRecordset->MoveFirst();};
	void MoveNext() 
		{m_pRecordset->MoveNext();};
	void MovePrevious() 
		{m_pRecordset->MovePrevious();};
	void MoveLast() 
		{m_pRecordset->MoveLast();};
	long GetAbsolutePage()
		{return m_pRecordset->GetAbsolutePage();};
	void SetAbsolutePage(int nPage)
		{m_pRecordset->PutAbsolutePage((enum PositionEnum)nPage);};
	long GetPageCount()
		{return m_pRecordset->GetPageCount();};
	long GetPageSize()
		{return m_pRecordset->GetPageSize();};
	void SetPageSize(int nSize)
		{m_pRecordset->PutPageSize(nSize);};
	long GetAbsolutePosition()
		{return m_pRecordset->GetAbsolutePosition();};
	void SetAbsolutePosition(int nPosition)
		{m_pRecordset->PutAbsolutePosition((enum PositionEnum)nPosition);};
	bool GetFieldInfo(LPCTSTR lpFieldName, CAdoFieldInfo* fldInfo);
	bool GetFieldInfo(int nIndex, CAdoFieldInfo* fldInfo);
	bool GetChunk(LPCTSTR lpFieldName, CString& strValue);

	//___________________________
	_RecordsetPtr		GetRSdisc();
	_RecordsetPtr		GetRSconn();

	//___________________________
	
	_bstr_t		GetString(LPCTSTR lpCols, LPCTSTR lpRows, long numRows = 0);
	
	bool		GetRows(int intNumber, _variant_t& avarData);
	bool		GetRSArray(VARIANT * pvar);
	int			GetFieldsCount();
	_bstr_t		GetFieldName(int nIndex);
	
	_bstr_t		GetLastError() {return m_bstrLastError;};


protected:
	_bstr_t				m_bstrLastError;
	void dump_com_error(_com_error &e);
	CString m_strQuery;

//public:
	_RecordsetPtr		m_pRecordset;
	_CommandPtr			m_pCmd;

};



#endif // !defined(AFX_ADO_H__C4AA1DE8_59BD_11D5_96F9_00A0D212FC63__INCLUDED_)
