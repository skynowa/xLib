#ifndef _EXCEPTIONS_ALL_H_
#define _EXCEPTIONS_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2003 Jan van den Baard
//     All Rights Reserved.
//

#include "exception.h"
#include "fileexception.h"
#include "memoryexception.h"
#include "shellexception.h"

#endif // _EXCEPTIONS_ALL_H_