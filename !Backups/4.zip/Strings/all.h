#ifndef _STRINGS_ALL_H_
#define _STRINGS_ALL_H_
//
// all.h
//
// (C) Copyright 1999-2001 Jan van den Baard
//     All Rights Reserved.
//

// Simply include all headers in this directory.
#include "string.h"

#endif // _STRINGS_ALL_H_