/**********************************************************************
 *	����� MsgBox (MsgBox.hpp)       http://www.richelbilderbeek.nl/CppFileExists.htm
 *
 ***********************************************************************/


#ifndef MsgBoxHPP
#define MsgBoxHPP       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <vector>
#include <iostream>
#include <ostream>

//---------------------------------------------------------------------------
void MsgBox(unsigned long int    ulText, const char *cpszCaption, unsigned long int ulType);
void MsgBox(const char        *cpszText, const char *cpszCaption, unsigned long int ulType);
void MsgBox(signed long int       lText, const char *cpszCaption, unsigned long int ulType);
//---------------------------------------------------------------------------



/**********************************************************************
 *	����� MsgBox (MsgBox.cpp)
 *
 ***********************************************************************/
 
 
 const unsigned long int culTextBuffLen = 1024;
 
//---------------------------------------------------------------------------
void MsgBox(unsigned long int ulText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%u", ulText);
	MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(const char *cpszText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	MessageBox(0, cpszText, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(signed long int  lText, const char *cpszCaption, unsigned long int ulType) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%i", lText);
	MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//DONE: lIntLen
/*unsigned long int ulIntLen(unsigned long int ulDigit) {
    unsigned long int ulCountChars = 0;

	ulDigit = abs(ulDigit);
    do {
        ulDigit /= 10;
        ulCountChars ++;
    }
    while (ulDigit);

    return ulCountChars;
}*/
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#endif