/**********************************************************************
*	�����  CXRandom (CXRandom.cpp)  
*	
***********************************************************************/


#include "stdafx.h"
#include "CXRandom.h"
//---------------------------------------------------------------------------
CXRandom::CXRandom() {
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
CXRandom::~CXRandom() {	
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
//Init CryptoAPI for random generation
BOOL CXRandom::bInitialize() {
	return CryptAcquireContext(&m_hCrypt,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT);
}
//---------------------------------------------------------------------------
//Clean up CryptoAPI
BOOL CXRandom::bFinalize() {
	return CryptReleaseContext(m_hCrypt,0);
}
//---------------------------------------------------------------------------
//Return a single random byte from 0x00 to 0xFF
char CXRandom::cGetRandomByte() {
	char cRes;
	vGetRandomBytes(sizeof(cRes), &cRes);
	
	return cRes;
}
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF
void CXRandom::vGetRandomBytes(int iSize, char *pszBuff) {
	CryptGenRandom(m_hCrypt, iSize, (unsigned char *)pszBuff);
} 
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF + '\0'
void CXRandom::vGetRandomBytes(int iSize, unsigned char *ucBuff) {
	CryptGenRandom(m_hCrypt, iSize, ucBuff);
	ucBuff[iSize - 1] = '\0';
} 
//---------------------------------------------------------------------------
//Return a random integer from 0 to INT_MAX
int CXRandom::iGetRandomInt() {
	int iRes;
	vGetRandomBytes(sizeof(iRes), (char *)&iRes);

	return iRes;
}
//---------------------------------------------------------------------------




/****************************************************************************
	������:

	int main(int argc, char* argv[]) {
		CXRandom R;
		char szBuff[8];
		
		for (int i = 0; i < 10; i ++) {
			if (FALSE == R.bInitialize()) {
				std::cout << "FALSE == R.bInitialize()" << std::endl;
			} else {
				std::cout << "TRUE == R.bInitialize()" << std::endl;
			}

			R.vGetRandomBytes(8, szBuff);
    		std::cout << szBuff << std::endl;
			
			if (FALSE == R.bFinalize()) {
				std::cout << "FALSE == R.bFinalize()" << std::endl;
			} else {
				std::cout << "TRUE == R.bFinalize()" << std::endl;
			}
		}


		system("pause");

		return 0;
	}

*****************************************************************************/