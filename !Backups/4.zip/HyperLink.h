/*
    FILE:       HyperLink.h
    AUTHOR:     Khachaturian Artiom

    OVERVIEW:
    ========
    NOTES:
    =====
*/
#if !defined(AFX_HYPERLINK_H__133847E3_9071_11D9_A2A3_00A00CC11D12__INCLUDED_)
#define AFX_HYPERLINK_H__133847E3_9071_11D9_A2A3_00A00CC11D12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HyperLink.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHyperLink window
typedef void(CObject::*EH_TYPE0)(CString const&);
typedef void(*EH_TYPE1)(LPCTSTR);
class CHyperLink: public CStatic
{
// Construction
public:
	CHyperLink();

// Attributes
public:

// Operations
public:


// Implementation
public:
	void SetInActiveColor(COLORREF crNewColor);
	void SetBackgroundBrushIndirect(CBrush* pNewBrush);
	COLORREF GetActiveColor();
	void SetActiveColor(COLORREF crNewColor);
	void SetClickEventHandler(CObject *pCallingObject,EH_TYPE0 EventHandler);
	void SetClickEventHandler(EH_TYPE1 EventHandler);
	virtual ~CHyperLink();

	// Generated message map functions
protected:
	union
	{
		void(*m_pClickEventHandlerFunc0)(LPCTSTR);
		struct
		{
			void(CObject::*m_pClickEventHandlerFunc1)(CString const&);
			CObject *m_pCallingObject;
		};
	};
	CBrush m_HyperLinkBrush;
	bool m_bUseInsteadClassHandler;
	bool m_bActiveMode;
	bool m_bUseIndirectBrush;
	COLORREF m_crActiveForeColor;
	COLORREF m_crInActiveForeColor;
	HCURSOR m_hHandCursor;
	HCURSOR m_hArrowCursor;
		// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHyperLink)
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CHyperLink)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HYPERLINK_H__133847E3_9071_11D9_A2A3_00A00CC11D12__INCLUDED_)
