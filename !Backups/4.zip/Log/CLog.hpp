/**********************************************************************
*	�����  CLog (CLog.hpp)
*
***********************************************************************/


#ifndef CLogHPP
#define CLogHPP      
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
//---------------------------------------------------------------------------
class CLog {
	public:
					      CLog                  (const std::string &csFileName, unsigned long int ulMaxFileSize);
						  CLog					(unsigned long int ulMaxFileSize);
					      ~CLog                 ();

		void              vSetMaxFileSize       (unsigned long int ulMaxFileSize);	//Mb 
		void              vLog                  (const std::string &csFileText);
		void              vLog                  (unsigned long int ulData);
		
		void              vLogLastErrorStr      (const std::string &csComment, unsigned long int ulLastError);		
		void              vLogCharAsHex         (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
        void              vLogCharAsStr         (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
		void              vOpen                 ();
		void              vClear                ();
		void              vDelete               ();
		void              vSetName              (const std::string &csFileName);
		void              vSetPath              (const std::string &csFilePath);
        
		void              vWriteToLst           (HWND hLst, const std::string &csStr); 
		void              vWriteToLst           (HWND hLst, const std::string &csComment, const std::string &csStr); 
		void              vWriteToLst           (HWND hLst, const std::string &csComment, int iValue);
		void              vWriteToLst           (HWND hLst, const std::string &csComment, unsigned long int ulLastError);
	
	private:
		std::string       m_sLogName;
		std::string       m_sLogPath;
		unsigned long int m_ulMaxFileSize;
		
		unsigned long int ulGetFileSize			(const std::string &csFilePath);
		void              vDeleteLogIfFull		();
		void              vLogLastErrStrServ	(); 
		
		CRITICAL_SECTION  m_csWriteToLog;
};
//---------------------------------------------------------------------------
#endif



/**********************************************************************
*	�����  CLog (CLog.cpp)  
*	
***********************************************************************/


//---------------------------------------------------------------------------
CLog::CLog(const std::string &csFileName, unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csWriteToLog);

	m_sLogName      = csFileName;
	m_sLogPath      = "C:\\xxxxx___log.log"; //sExtractFilePath(sExePath()) + "\\" + m_sLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CLog::CLog(unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csWriteToLog);

	m_sLogName      = sExtractFullFileName(sExePath());
	m_sLogPath      = "C:\\xxxxx___log.log"; //sExtractFilePath(sExePath()) + "\\" + m_sLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CLog::~CLog() {	
	/*UNLOCK*/DeleteCriticalSection(&m_csWriteToLog);	
}
//---------------------------------------------------------------------------
void CLog::vDelete() {
    if (bFileExists(m_sLogPath) == false) {
		return;
	}	
	if (!SetFileAttributes(m_sLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
        vLogLastErrStrServ();
    }
    if (remove(m_sLogPath.c_str()) != 0) {
        vLogLastErrStrServ();
    }
}
//---------------------------------------------------------------------------
void CLog::vSetPath(const std::string &csFilePath) {
	m_sLogPath = m_sLogPath;
}
//---------------------------------------------------------------------------
void CLog::vSetName(const std::string &csFileName) {
	m_sLogName = csFileName;
	m_sLogPath = sExtractFilePath(sExePath()) + "\\" + csFileName;
}
//---------------------------------------------------------------------------
void CLog::vOpen() {
	STARTUPINFO si;				memset(&si, 0, sizeof(STARTUPINFO));
	PROCESS_INFORMATION pi;     memset(&pi, 0, sizeof(PROCESS_INFORMATION));
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "Notepad.exe " + m_sLogPath; 
	if (!CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
void CLog::vClear() {
	//FileExists

	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "w") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        fprintf_s(pFile, "");	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CLog::vLog(const std::string &csFileText) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
        fprintf_s(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileText.c_str());	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CLog::vLog(unsigned long int ulData) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
        fprintf_s(pFile, "[%d:%d:%d]  %d\n", stST.wHour, stST.wMinute, stST.wSecond, ulData);	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CLog::vLogLastErrorStr(const std::string &csComment, unsigned long int ulLastError) {
	vDeleteLogIfFull();

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);

		fprintf_s(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), (LPCTSTR)lpMsgBuf);	
    }
	fclose(pFile);
	pFile = NULL;

	LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CLog::vLogLastErrStrServ() {
	////vDeleteLogIfFull();

	//////-------------------------------------
	//////ulLastError -> ������
	////LPVOID lpMsgBuf = NULL;

	////FormatMessage( 
	////	FORMAT_MESSAGE_ALLOCATE_BUFFER | 
	////	FORMAT_MESSAGE_FROM_SYSTEM | 
	////	FORMAT_MESSAGE_IGNORE_INSERTS,
	////	NULL,
	////	GetLastError(),
	////	MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
	////	(LPTSTR) &lpMsgBuf,
	////	0,
	////	NULL
	////);								

	//////-------------------------------------
	//////����� ���
	////FILE *pFile = NULL;
 ////   if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
	////	SYSTEMTIME stST;    
	////	ZeroMemory(&stST, sizeof(stST));
 ////       GetLocalTime(&stST);
 ////       fprintf_s(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, "fail");
 ////   } else {
 ////       SYSTEMTIME stST; 
	////	ZeroMemory(&stST, sizeof(stST));
 ////       GetLocalTime(&stST);
	////	fprintf_s(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, (LPCTSTR)lpMsgBuf);	
 ////   }
	////fclose(pFile);
	////pFile = NULL;

	////LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsHex(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	vDeleteLogIfFull();

	////std::string sRes = "";   
	////for (unsigned int i = 0; i < ulFileTextLen; i ++) {
	////    if (pcFileText[i] < 16) {
	////           //sRes += AnsiString(0).sprintf("0x0%x ", pcFileText[i]);
	////	} else {
	////           //sRes += AnsiString(0).sprintf("0x%2x ", pcFileText[i]);
	////       }
	////}
	////
	////FILE *pFile = NULL;
	////   if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {
	////       //vErrorMessageBox();
	////   } else {
	////       SYSTEMTIME stST;
	////       GetLocalTime(&stST);
	////       fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
	////   }
	////fclose(pFile);
	////pFile = NULL;
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsStr(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	vDeleteLogIfFull();

	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
        //sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
        sRes.push_back(pcFileText[i]);      //???????????
	}

	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CLog::vWriteToLst(HWND hLst, const std::string &csStr) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);
	
	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	//csStr
	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CLog::vWriteToLst(HWND hLst, const std::string &csComment, const std::string &csStr) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CLog::vWriteToLst(HWND hLst, const std::string &csComment, int iValue) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(iValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CLog::vWriteToLst(HWND hLst, const std::string &csComment, unsigned long int ulLastError) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + std::string((LPCTSTR)lpMsgBuf);
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	LocalFree(lpMsgBuf);
	lpMsgBuf = NULL;

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
////void CLog::vErrorMessageBox() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
////	LocalFree(lpMsgBuf);
////}
//---------------------------------------------------------------------------
////std::string CLog::sErrorMessageStr() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	////LocalFree(lpMsgBuf);
////
////	return std::string((LPCTSTR)lpMsgBuf);
////}
//---------------------------------------------------------------------------
void CLog::vSetMaxFileSize(unsigned long int ulMaxFileSize) {
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
unsigned long int CLog::ulGetFileSize(const std::string &csFilePath) {
	HANDLE h = CreateFile(csFilePath.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL); 
	if (h == NULL) {
	    vLogLastErrStrServ();
		CloseHandle(h);
		h = NULL;

		return 0;
	}
	
	unsigned long int ulFileSize = GetFileSize(h, NULL) / 1000000;  //������ ����� � ������ / 1000000
	if (ulFileSize == -1) {
		vLogLastErrStrServ();
		CloseHandle(h);
		h = NULL;
		return 0;
	}
	CloseHandle(h);
	h = NULL;
	
	return ulFileSize;
}
//---------------------------------------------------------------------------
void CLog::vDeleteLogIfFull() {
	//FileExists
	
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if (ulGetFileSize(m_sLogPath) >= m_ulMaxFileSize) {
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------
