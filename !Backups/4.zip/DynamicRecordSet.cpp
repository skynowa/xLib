// DynamicRecordSet.cpp : implementation file
//

#include "stdafx.h"
#include "DynamicRecordSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define NODEF_INT -1;
#define NODEF_FLOAT -1.e14
#define NODEF_STRING ""



/////////////////////////////////////////////////////////////////////////////
// CDynamicRecordSet

IMPLEMENT_DYNAMIC(CDynamicRecordSet, CRecordset)
CDynamicRecordSet::CDynamicRecordSet(CString ConnectStr)
	: CRecordset(&m_db)
{
	//������ ��������� ����������� ���������
	Connect(ConnectStr);
	m_nFields = 255;
	m_fFieldsInfo=false;
	m_fEnableMessage=false;
	m_nDefaultType = dynamic;
}

CDynamicRecordSet::CDynamicRecordSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//������ ��������� ����������� ���������
	if(pdb==NULL)
		m_pDatabase=&m_db;
	m_nFields = 255;
	m_fFieldsInfo=false;
	m_fEnableMessage=false;
	m_nDefaultType = dynamic;
	if(IsOpen())
		Close();
	if(m_db.IsOpen())
		m_db.Close();
}


CString CDynamicRecordSet::GetDefaultConnect()
{
	return _T("");
}

CString CDynamicRecordSet::GetDefaultSQL()
{
	return _T("");
}

void CDynamicRecordSet::DoFieldExchange(CFieldExchange* pFX)
{
	if(!m_fFieldsInfo)
		if(!GetRecordSetFieldsInfo())
			return;
	pFX->SetFieldType(CFieldExchange::outputColumn);
	for(UINT i=0;i<m_nFields;i++)
	{
		switch(m_Type.GetAt(i))
		{
		case(SQL_INTEGER):
		case(SQL_BIT):
		case(SQL_TINYINT):
			{
				RFX_Long(pFX,m_Name.GetAt(i),m_Data[i].m_int);
				break;
			}
		case(SQL_FLOAT):
			{
				RFX_Double(pFX,m_Name.GetAt(i),m_Data[i].m_float);
				break;
			}
		case(SQL_NUMERIC):
			{
				RFX_Double(pFX,m_Name.GetAt(i),m_Data[i].m_float);
				break;
			}
		case(SQL_CHAR):
		case(SQL_VARCHAR):
			{
				RFX_Text(pFX,m_Name.GetAt(i),m_Data[i].m_Text);
				break;
			}
		case(11):
			{
				RFX_Date(pFX,m_Name.GetAt(i),m_Data[i].m_Time);
				break;
			}
		default:
			{
				CString s;
				s.Format("������� "+m_LastSelect+" ������� - "+m_Name.GetAt(i)+" ��� ������ %d �� ������������� \n �� ������ �������� STOP DEBUGGING, � �� ����� BAD !",m_Type.GetAt(i));
				MessageBox(0,s,"����� CDynamicRecordSet �� ������������ ���� ��� ������.",0);
			}
		}		
	}
/*
���� �� ��������� �������� ��� ������,
�������������� ���� ����������� !

	//{{AFX_FIELD_MAP(CDynamicRecordSet)
	RFX_Binary(pFX, _T("[binary]"), m_binary);
	RFX_Bool(pFX, _T("[bit]"), m_bit);
	RFX_Text(pFX, _T("[char]"), m_char);
	RFX_Date(pFX, _T("[datetime]"), m_datetime);
	RFX_Text(pFX, _T("[decimal]"), m_decimal);
	RFX_Double(pFX, _T("[float]"), m_float);
//	RFX_LongBinary(pFX, _T("[image]"), m_image);
	RFX_Long(pFX, _T("[int]"), m_int);
	RFX_Text(pFX, _T("[money]"), m_money);
	RFX_Text(pFX, _T("[nchar]"), m_nchar);
	RFX_Text(pFX, _T("[ntext]"), m_ntext);
	RFX_Text(pFX, _T("[numeric]"), m_numeric);
	RFX_Text(pFX, _T("[nvarchar]"), m_nvarchar);
	RFX_Single(pFX, _T("[real]"), m_real);
	RFX_Date(pFX, _T("[smalldatetime]"), m_smalldatetime);
	RFX_Text(pFX, _T("[text]"), m_text);
	RFX_Binary(pFX, _T("[timestamp]"), m_timestamp);
	RFX_Byte(pFX, _T("[tinyit]"), m_tinyit);
	RFX_Text(pFX, _T("[uniqueident]"), m_uniqueident);
	RFX_Binary(pFX, _T("[varbinary]"), m_varbinary);
	RFX_Text(pFX, _T("[varchar]"), m_varchar);
	//}}AFX_FIELD_MAP
*/
}

/////////////////////////////////////////////////////////////////////////////
// CDynamicRecordSet diagnostics

#ifdef _DEBUG
void CDynamicRecordSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDynamicRecordSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

bool CDynamicRecordSet::GetRecordSetFieldsInfo()
{
	CODBCFieldInfo FieldInfo;
	m_Name.RemoveAll();
	m_Type.RemoveAll();
	m_DataMap.RemoveAll();
	if(!IsOpen())
		return false;
	m_nFields=GetODBCFieldCount();
	for(UINT i=0;i<m_nFields;i++)
	{
		try
		{
			GetODBCFieldInfo(i,FieldInfo);
		}
		catch(CDBException* e)
		{
			ProcessError(e);
			m_sLastError+="In GetFieldsInfo";
			return false;
		}
		m_Type.Add(FieldInfo.m_nSQLType);
		m_Name.Add(FieldInfo.m_strName);
		m_DataMap.SetAt(FieldInfo.m_strName,&m_Data[i]);
	}
	m_fFieldsInfo=true;
	m_ColCount=m_nFields;
	return true;
}

void CDynamicRecordSet::Close()
{
	m_fFieldsInfo=false;
	m_nFields=255;
	if(m_pDatabase!=NULL)
		CRecordset::Close();
}

bool CDynamicRecordSet::DynEdit()
{
	if(!IsOpen())
		return false;
	try
	{
		Edit();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In Edit";
		return false;
	}
	return true;
}

bool  CDynamicRecordSet::DynUpdate()
{
	if(!IsOpen())
		return false;
	if(!CanUpdate())
	{
		if(m_fEnableMessage)
			MessageBox(0,"CanUpdate return false","",0);
		m_sLastError=" CanUpdate return false";
		return false;
	}
	try
	{
		Update();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In Update";
		return false;
	}
	return true;
}

bool CDynamicRecordSet::DynOpen(LPSTR lpszSQL,bool fEnableMapping)
{
	m_LastSelect=lpszSQL;
	m_fEnableMapping=fEnableMapping;
	if(m_fConnectionFAILED)
		if(!Connect(m_ConnectString,m_QueryTimeout))
			return false;

	if(IsOpen())
		Close();
	try
	{
		if(!Open(CRecordset::dynamic,lpszSQL))
		{
			if(m_fEnableMessage)
				AfxMessageBox("Can't Open recordset "+m_LastSelect);
			m_sLastError="Can't Open recordset  "+m_LastSelect;
			return false;
		}
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError += " In Open";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynAddNew()
{
	if(!IsOpen())
		return false;
	try
	{
		CRecordset::AddNew();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+="In AddNew";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynDelete()
{
	if(!IsOpen())
		return false;
	try
	{
		Delete();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+="In Delete";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::SetField(CString Field,int Val)
{
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(Field,pData))
		return false;
	pData->m_int=Val;
	return true;
}

bool CDynamicRecordSet::SetField(CString Field,double Val)
{
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(Field,pData))
		return false;
	pData->m_float=Val;
	return true;
}
bool CDynamicRecordSet::SetField(CString Field,CString Val)
{
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(Field,pData))
		return false;
	pData->m_Text=Val;
	return true;
}
int CDynamicRecordSet::GetIntField(CString FieldName)
{
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(FieldName,pData))
		return NODEF_INT;
	return pData->m_int;
}

double CDynamicRecordSet::GetDoubleField(CString FieldName){
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(FieldName,pData))
		return NODEF_FLOAT;
	return pData->m_float;
}

CString CDynamicRecordSet::GetTextField(CString FieldName){
	CDynamicRecordSetDataStorage* pData;
	if(!m_DataMap.Lookup(FieldName,pData))
		return NODEF_STRING;
	return pData->m_Text;
}

CDynamicRecordSetDataStorage* CDynamicRecordSet::GetFieldPtr(CString Name)
{
	CDynamicRecordSetDataStorage* pData=NULL;
	if(!m_DataMap.Lookup(Name,pData))
		return pData;
	else
		return NULL;
}

bool CDynamicRecordSet::DynMove(long nRows)
{
	if(!IsOpen())
		return false;
	try
	{
		Move(nRows);
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+="In MoveFirst";
		return false;
	}	
	return true;
}
bool CDynamicRecordSet::DynMoveFirst()
{
	if(!IsOpen())
		return false;
	try
	{
		MoveFirst();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In MoveFirst";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynMoveLast()
{
	if(!IsOpen())
		return false;
	try
	{
		MoveLast();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+="In MoveLast";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynMovePrev()
{
	if(!IsOpen())
		return false;
	try
	{
		MovePrev();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In MovePrev";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynMoveNext()
{
	if(!IsOpen())
		return false;
	try
	{
		MoveNext();
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In MoveNext";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynSetAbsPos(int Row)
{
	if(!IsOpen())
		return false;
	try
	{
		SetAbsolutePosition(Row);
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_sLastError+=" In SetAbsPos";
		return false;
	}	
	return true;
}

bool CDynamicRecordSet::DynOpen(CString s,bool fEnableMapping)
{
	
	if(s=="")
		s=m_LastSelect;
	else
		m_LastSelect=s;
	return DynOpen(LPSTR(LPCTSTR(s)),fEnableMapping);
}

bool CDynamicRecordSet::Connect(CString strConnect,int QueryTimeout,bool fEnableMessages)
{
	m_fEnableMessage=fEnableMessages;
	m_ConnectString=strConnect;
	m_QueryTimeout=QueryTimeout;
	
	try
	{
		if(m_db.OpenEx(LPSTR(LPCTSTR(strConnect)),CDatabase::noOdbcDialog)==0)
			return false;
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_LastSelect+="OPEN DATABASE CONNECTION";
		return false;
	}
	m_pDatabase=&m_db;
	m_pDatabase->SetQueryTimeout(QueryTimeout);
	m_fConnectionFAILED=false;
	return true;
}

void CDynamicRecordSet::DisConnect()
{
	if(IsOpen())
		Close();
	if(m_db.IsOpen())
		m_db.Close();
	m_fConnectionFAILED=true;
}

void CDynamicRecordSet::ProcessError(CDBException* e)
{
	if(m_fEnableMessage)
		AfxMessageBox(e->m_strError);
	m_sLastError=e->m_strError;
	CString ErrCod=e->m_strStateNativeOrigin.Left(11);
	m_LastErrCod=ErrCod.Right(5);
	e->Delete();
	if(m_LastErrCod=="08S01")
		m_fConnectionFAILED=true;
}

bool CDynamicRecordSet::DirectSQL(CString sql)
{
	if(m_pDatabase==NULL)
		return false;
	if(!m_pDatabase->IsOpen())
	{
		m_sLastError="NO CONNECTION OPEN";
		return false;
	}
	if(IsOpen())
		Close();
	try
	{
		m_pDatabase->ExecuteSQL(sql);
	}
	catch(CDBException* e)
	{
		ProcessError(e);
		m_LastSelect+=sql;
		return false;
	}
	return true;
}
