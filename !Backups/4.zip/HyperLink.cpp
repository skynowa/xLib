/*
    FILE:       HyperLink.cpp
    AUTHOR:     Khachaturian Artiom

    OVERVIEW:
    ========
    NOTES:
    =====
*/
// HyperLink.cpp : implementation file
//

#include "stdafx.h"
#include "HyperLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHyperLink

CHyperLink::CHyperLink()
{
	m_pClickEventHandlerFunc0=NULL;
	m_pClickEventHandlerFunc1=NULL;
	m_bUseInsteadClassHandler=false;
	m_bActiveMode=false;
	m_crActiveForeColor=RGB(0,0,255);
	m_crInActiveForeColor=GetSysColor(COLOR_WINDOWTEXT);
	m_hHandCursor=LoadCursor(NULL,MAKEINTRESOURCE(32649));
	m_hArrowCursor=LoadCursor(NULL,IDC_ARROW);
	m_bUseIndirectBrush=false;
	m_HyperLinkBrush.CreateSolidBrush(GetSysColor(COLOR_3DFACE));
}

CHyperLink::~CHyperLink()
{
	if(m_bUseIndirectBrush)m_HyperLinkBrush.Detach();
}


BEGIN_MESSAGE_MAP(CHyperLink, CStatic)
	//{{AFX_MSG_MAP(CHyperLink)
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHyperLink message handlers
void CHyperLink::SetClickEventHandler(CObject *pCallingObject,EH_TYPE0 EventHandler)
{
	m_bUseInsteadClassHandler=true;
	m_pCallingObject=pCallingObject;
	m_pClickEventHandlerFunc1=EventHandler;
}
void CHyperLink::SetClickEventHandler(EH_TYPE1 EventHandler)
{
	m_bUseInsteadClassHandler=false;
	m_pClickEventHandlerFunc0=EventHandler;

}

BOOL CHyperLink::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	CWnd* pWnd;  
	CWnd* pParent;
	switch(pMsg->message)
	{
		case WM_MOUSEMOVE:
		pWnd = GetActiveWindow();
		pParent = GetOwner();
		if ((GetCapture()!=this)&&(pWnd!=NULL&&pParent!=NULL)) 
		{
			SetCapture();
			m_bActiveMode=true;
			Invalidate();		
			::SetCursor(m_hHandCursor);

			
	

		}
		else
		{
		

		
		CWnd* wndUnderMouse = WindowFromPoint(pMsg->pt);
			if (wndUnderMouse != this)
			{
				ReleaseCapture();
				m_bActiveMode=false;
				Invalidate();
				::SetCursor(m_hArrowCursor);
				
			}
		}


			break;
	};
	return CStatic::PreTranslateMessage(pMsg);
	
	
}

void CHyperLink::SetActiveColor(COLORREF crNewColor)
{
	m_crActiveForeColor=crNewColor;
	Invalidate();
}

COLORREF CHyperLink::GetActiveColor()
{
	return m_crActiveForeColor;
}


/*
HBRUSH CHyperLink::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CStatic::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	pDC->SetTextColor(m_bActive?m_crActiveForeColor:m_crActiveForeColor);
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
*/

HBRUSH CHyperLink::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	static COLORREF cbBk=GetSysColor(COLOR_3DFACE);
	pDC->SetBkMode(TRANSPARENT);
	if(!m_bUseIndirectBrush)pDC->SetBkColor(cbBk);
	pDC->SetTextColor(m_bActiveMode?m_crActiveForeColor:m_crInActiveForeColor);
	return m_HyperLinkBrush;
}

void CHyperLink::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CString text;
	GetWindowText(text);
	switch(m_bUseInsteadClassHandler)
	{
		case true:
			if(m_pClickEventHandlerFunc1)(m_pCallingObject->*m_pClickEventHandlerFunc1)(text);
			break;
		case false:
			if(m_pClickEventHandlerFunc0)m_pClickEventHandlerFunc0(text);
			break;
	};
	CStatic::OnLButtonDown(nFlags, point);
}

void CHyperLink::SetBackgroundBrushIndirect(CBrush *pNewBrush)
{
	m_HyperLinkBrush.DeleteObject();
	if(!pNewBrush)
	{
		m_bUseIndirectBrush=false;
		m_HyperLinkBrush.CreateSolidBrush(GetSysColor(COLOR_3DFACE));
	}
	else
	{
		m_bUseIndirectBrush=true;
		m_HyperLinkBrush.Attach(pNewBrush->GetSafeHandle());

	}
}

void CHyperLink::SetInActiveColor(COLORREF crNewColor)
{
	m_crInActiveForeColor=crNewColor;
	Invalidate();
}
