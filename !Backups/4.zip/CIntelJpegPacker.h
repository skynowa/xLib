#ifndef __CIntelJpegPacker_h__
#define __CIntelJpegPacker_h__

//
// CIntelJpegPacker
//
// Son class of CPicturePacker using Intel� JPEG Library v1.5.
//
// Written by Laurent Kemp� (lkempe@netcourrier.com) for Tech Head WebSite
// Copyright (c) 2001 Laurent Kemp�.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CPicturePacker.h"

class CIntelJpegPacker : 
	public CPicturePacker  
{

public:

	CIntelJpegPacker( int nQuality = 75 );
	virtual ~CIntelJpegPacker();

	// Methods ////////////////////////////////////////////////////////////////
	
public:
	
	virtual bool Pack( unsigned char * pSource, 
					   unsigned int nSourceBytes,
					   int BitmapWidth,
					   int BitmapWidthBytes,
					   int BitmapHeight,
					   unsigned char ** ppPacked,
					   unsigned long * pnPackedBytes );
	
	
	virtual bool UnPack( unsigned char * pSource,
						 long nSourceBytes,
						 unsigned char ** ppUnPacked,
						 unsigned int * pnUnPackedBytes,
						 unsigned long * pBitmapWidth,
						 unsigned long * pBitmapWidthBytes,
						 unsigned long * pBitmapHeight );

protected:

	//Intel � JPEGLibrary Developer�s Guide

	BOOL DecodeFromJPEGBuffer( BYTE* lpJpgBuffer,
							   DWORD dwJpgBufferSize,
							   BYTE** lppRgbBuffer,
							   DWORD* lpdwWidth,
							   DWORD* lpdwHeight,
							   DWORD* lpdwNumberOfChannels );
						  
	BOOL EncodeToJPEGBuffer( BYTE* lpRgbBuffer,
							 DWORD dwWidth,
							 DWORD dwHeight, 
							 BYTE** lppJpgBuffer,
							 DWORD* lpdwJpgBufferSize );
		
	// Data Members ///////////////////////////////////////////////////////////
	
public:
	
protected:

	int m_nQuality;

};

#endif //__CIntelJpegPacker_h__
