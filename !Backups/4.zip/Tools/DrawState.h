#ifndef _DRAWSTATE_H_
#define _DRAWSTATE_H_
//
// drawstate.h
//
// Replaced by drawtools.h"
//

#include "drawtools.h"

#define ClsDrawState ClsDrawTools

#endif // _DRAWSTATE_H_