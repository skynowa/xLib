/**********************************************************************
*	�����  CXConsole (CXConsole.cpp)  
*	
***********************************************************************/


#include "CXConsole.h"

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
//---------------------------------------------------------------------------
CXConsole::CXConsole() {
	m_hWnd  = NULL;
	m_hMenu = NULL;
	
	m_hStdIn  = GetStdHandle(STD_INPUT_HANDLE);
	if (m_hStdIn == INVALID_HANDLE_VALUE) {
		return;
	}

	m_hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	if (m_hStdOut == INVALID_HANDLE_VALUE) {
		return;
	}

	bSetTitle(APP_NAME);
}
//---------------------------------------------------------------------------
CXConsole::~CXConsole() {
	if (NULL != m_hStdIn) {
		CloseHandle(m_hStdIn);	m_hStdIn  = NULL;
	}
	if (NULL != m_hStdOut) {
	    CloseHandle(m_hStdOut);	m_hStdOut = NULL;
	}

	m_hMenu = NULL; 
	m_hWnd  = NULL; 
}
//---------------------------------------------------------------------------
void CXConsole::vSetLocale(const std::string &csLocale) {
	setlocale(LC_ALL, csLocale.c_str());
}
//---------------------------------------------------------------------------
void CXConsole::vSetTextColor(unsigned int uiColor) {
	SetConsoleTextAttribute(m_hStdOut, uiColor);	//�����
}
//---------------------------------------------------------------------------
bool CXConsole::bEnableClose(bool bFlag) {
	m_hWnd = hGetConsoleWnd();
	if (NULL == m_hWnd) {
		return false;
	}

	if (false == bFlag) {
		m_hMenu = GetSystemMenu(m_hWnd, FALSE);
		if (FALSE == DeleteMenu(m_hMenu, SC_CLOSE, MF_BYCOMMAND)) {
			return false;
		}
	} else {
		m_hMenu = GetSystemMenu(m_hWnd, TRUE);
		if (FALSE == AppendMenu(m_hMenu, SC_CLOSE, MF_BYCOMMAND, "")) {
			return false;
		}
	}

	return true;
}
//---------------------------------------------------------------------------
std::string CXConsole::sGetTitle() {
	char  szTitleBuff[1024];	memset(szTitleBuff, 0, sizeof(szTitleBuff)); 
	DWORD dwBufferSize  = 1024;      
	DWORD dwTitleSize   = 0;              

	//������ ��������� �������
	dwTitleSize = GetConsoleTitle(szTitleBuff, dwBufferSize);

	return std::string(szTitleBuff, dwTitleSize);
}
//---------------------------------------------------------------------------
bool CXConsole::bSetTitle(const std::string &csTitle) {
	if (!SetConsoleTitle(csTitle.c_str())) {
		return false;
	} else {
		return true;
	}
}
//---------------------------------------------------------------------------
bool CXConsole::bSetFullScreen() {
	COORD crdCoord = GetLargestConsoleWindowSize(m_hStdOut);
	if (crdCoord.X == 0 && crdCoord.Y == 0) {
		return false;
	}
	
	crdCoord.X -= 2;
	crdCoord.Y -= 2;

	SMALL_RECT recSmallRec = {
		0,					//Left
		0,					//Top
		crdCoord.X - 2,		//Right
		crdCoord.Y - 2		//Bottom
	};
	
	if (FALSE == SetConsoleScreenBufferSize(m_hStdOut, crdCoord)) {
		return false;
	}
	
	if (FALSE == SetConsoleWindowInfo(m_hStdOut, true, &recSmallRec)) {
		return false;
	}

	//-------------------------------------
	//���������� ����
	if (false == bCenterWindow()) {
		return false;
	}

	return true;
}
//---------------------------------------------------------------------------
bool CXConsole::bCenterWindow() {
	m_hWnd = hGetConsoleWnd() /*GetConsoleWindow()*/;
	if (NULL == m_hWnd) {
		return false;
	}

	RECT recOriginWnd;
	if (FALSE == GetWindowRect(m_hWnd, &recOriginWnd)) {
		return false;
	}

	RECT recDesktopWnd;
	if (FALSE == SystemParametersInfo(SPI_GETWORKAREA, 0, &recDesktopWnd, 0)) {
		return false;
	}
	
	int iDesktopX  = (recDesktopWnd.right  - recDesktopWnd.left) / 2;
	int iDesktopY  = (recDesktopWnd.bottom - recDesktopWnd.top)  / 2;
	int iWndWidth  = (recOriginWnd.right   - recOriginWnd.left);
	int iWndHeight = (recOriginWnd.bottom  - recOriginWnd.top);
	int X          = iDesktopX - iWndWidth / 2;		if (X < 0) {X = 0;}
	
	if (FALSE == MoveWindow(m_hWnd, X, iDesktopY - iWndHeight / 2, iWndWidth, iWndHeight, true)) {
		return false;
	}

	return true;

	
	//-------------------------------------
	//������� �2
	////POINT   Point;
	////RECT    DialogRect;
	////RECT    ParentRect;
	////int     nWidth;
	////int     nHeight;
	////HWND    hDesktop = NULL;

	////HWND hWnd = NULL;
	////while (NULL == hWnd) {
	////	hWnd = ::FindWindowEx(NULL, NULL, NULL, APP_NAME);
	////}

	//////�������� ������ ����������� ����.
	////GetWindowRect(hWnd, &DialogRect);

	//////�������� ������ �������� �����
	////hDesktop = GetDesktopWindow();
	////GetWindowRect(hDesktop, &ParentRect);

	//////��������� ������ � ������ ��� MoveWindow().
	////nWidth = DialogRect.right;   // .Width();
	////nHeight = DialogRect.bottom; //.Height();

	//////������� ����� ������ � ����������� � ���������� ������.
	////Point.x = ParentRect.right / 2;
	////Point.y = ParentRect.bottom / 2;

	////ClientToScreen(hDesktop, &Point);

	//////��������� ����� X, Y ��������� �����.
	////Point.x -= nWidth  / 2;
	////Point.y -= nHeight / 2;

	//////���������� ����.
	////MoveWindow(hWnd, Point.x, Point.y, nWidth, nHeight, TRUE);
}
//---------------------------------------------------------------------------
HWND CXConsole::hGetConsoleWnd() {
	const int ciBuffSize = 1024;         //Buffer size for console window titles.
	HWND      hRes       = NULL;         //This is what is returned to the caller.
	char      szNewWndTitle[ciBuffSize]; 
	char      szOldWndTitle[ciBuffSize]; 

	//Fetch current window title.
	if (FALSE == GetConsoleTitle(szOldWndTitle, ciBuffSize)) {
		return NULL;
	}

	//Format a "unique" szNewWndTitle.
	wsprintf(szNewWndTitle, "%d/%d", GetTickCount(), GetCurrentProcessId());

	//Change current window title.
	if (FALSE == SetConsoleTitle(szNewWndTitle)) {
		return NULL;
	}

	//Ensure window title has been updated.
	Sleep(50);

	//Look for NewWindowTitle.
	hRes = FindWindow(NULL, szNewWndTitle);
	if (INVALID_HANDLE_VALUE == hRes) {
		return NULL;
	}

	//Restore original window title.
	if (FALSE == SetConsoleTitle(szOldWndTitle)) {
		CloseHandle(hRes);	hRes = NULL;
		
		return NULL;
	}

	return hRes;


	//-------------------------------------
	//������� �2
	//////std::string sTilte("some crazy but unique string that will ID our window - maybe a GUID and process ID");

	//////if (FALSE == SetConsoleTitle(sTilte.c_str())) {
	//////	return NULL;
	//////}

	////////Give this a chance - it may fail the first time through
	//////HWND hRes = NULL;
	//////while (NULL == hRes) {
	//////	hRes = ::FindWindowEx(NULL, NULL, NULL, sTilte.c_str());
	//////}

	////////Reset old title - we'd normally save it with GetConsoleTitle
	//////if (FALSE == SetConsoleTitle(APP_NAME)) {
	//////	CloseHandle(hRes);	hRes = NULL;
	//////	return NULL;
	//////}

	return (hRes);
}
//---------------------------------------------------------------------------
bool CXConsole::bClearScreen() {
	COORD                      coordScreen;  memset(&coordScreen, 0, sizeof(coordScreen));	/*here's where we'll home the cursor*/ 
	BOOL                       bSuccess      = FALSE;
	DWORD                      cCharsWritten = 0;
	CONSOLE_SCREEN_BUFFER_INFO csbi;		 memset(&csbi, 0, sizeof(csbi));				/*to get buffer info*/ 
	DWORD                      dwConSize     = 0;                                           /*number of character cells in the current buffer*/ 

	//get the number of character cells in the current buffer
	bSuccess = GetConsoleScreenBufferInfo(m_hStdOut, &csbi);
	if (FALSE == bSuccess) {
		return false;
	}
	dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

	//fill the entire screen with blanks
	bSuccess = FillConsoleOutputCharacter(m_hStdOut, (TCHAR) ' ', dwConSize, coordScreen, &cCharsWritten);
	if (FALSE == bSuccess) {
		return false;
	}

	//get the current text attribute
	bSuccess = GetConsoleScreenBufferInfo(m_hStdOut, &csbi);
	if (FALSE == bSuccess) {
		return false;
	}

	//now set the buffer's attributes accordingly
	bSuccess = FillConsoleOutputAttribute(m_hStdOut, csbi.wAttributes,	dwConSize, coordScreen, &cCharsWritten);
	if (FALSE == bSuccess) {
		return false;
	}

	//put the cursor at (0, 0) 
	bSuccess = SetConsoleCursorPosition(m_hStdOut, coordScreen );
	if (FALSE == bSuccess) {
		return false;
	}

	return true;
}
//---------------------------------------------------------------------------
bool CXConsole::bWriteLine(const std::string &csStr) {
	bool  bRes      = false;
	DWORD dwWritten = 0;    

	//��������������� � ���������� ���������
	std::string sOut          = "";
	char        szBuff[260]; memset(szBuff, 0, sizeof(szBuff));
	
	CharToOem(csStr.c_str(), szBuff);
	sOut = (std::string(szBuff) + "\r\n");

	bRes = WriteConsole(m_hStdOut, sOut.c_str(), sOut.size(), &dwWritten, NULL);
	if (false == bRes)	{
		return false;
	}
	if (dwWritten != sOut.size()) {
		return false;
	} 

	return true;
}
//---------------------------------------------------------------------------
bool CXConsole::bWriteErrLine(const std::string &csStr) {
	if (false == bWriteLine("������: " + csStr)) {
		return false;
	}

	Beep(40, 40);
	std::cin.get();

	return true;
}
//---------------------------------------------------------------------------
std::string CXConsole::sReadLine() {
	DWORD dwRead       = 0; 
	char  szBuff[260]; memset(szBuff, 0, sizeof(szBuff));

	if (!ReadConsole(m_hStdIn, &szBuff, sizeof(szBuff), &dwRead, NULL)) {
		return "";
	}

	return std::string(szBuff, dwRead - 2);	//������ "\r\n"
}
//---------------------------------------------------------------------------
