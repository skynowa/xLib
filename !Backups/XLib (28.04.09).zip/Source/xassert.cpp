/****************************************************************************
*	xassert.cpp
*
*****************************************************************************/



//---------------------------------------------------------------------------
#include <XLib/xassert.h> 

#include <string> 
#include <XLib/CXFsoString.h> 

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
void vAssert(LPCSTR pcszExp, ULONG ulLastError, LPCSTR pcszFile, ULONG ulLine, LPCSTR pcszFunc, LPCSTR pcszComment) {
	//-------------------------------------
	//���� � exe-�����
	TCHAR szExePath[MAX_PATH + 1] = {0};
	if (FALSE == ::GetModuleFileName(NULL, szExePath, MAX_PATH) || '\0' == *szExePath) {
		::MessageBox(0, "GetModuleFileName() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
		return;
	}

	//-------------------------------------
	//���� � ��� exe-�����
	TCHAR szExeName[MAX_PATH + 1] = {0};	
	_splitpath(szExePath, NULL, NULL, szExeName, NULL);
	if (NULL == szExeName || '\0' == *szExeName) {
		::MessageBox(0, "_splitpath() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� GetLastError()
	LPVOID lpMsgBuf = NULL;
	::FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPSTR)&lpMsgBuf,
		0,
		NULL);
	if (NULL == lpMsgBuf || '\0' == (LPSTR)lpMsgBuf) {
		::MessageBox(0, "FormatMessage() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� ���������
	const UINT cuiMsgSize = 2024; 
	TCHAR      szMsg[cuiMsgSize + 1] = {0};
    ::wsprintf(szMsg,
			 "%s\n\n"
			 "%s:  %s\n"
			 "%s:  %s\n"
			 "%s:  %i\n"
			 "%s:  %s\n"
			 "%s:  %s\n"
			 "%s:  %s"		/*����� ���� \n �� ����*/
			 "%s:  %s",			 
			 
			 "Assertion failed.",
			 "Program",           sMinimizePath(szExePath, 40).c_str(),
			 "File",              sMinimizePath(pcszFile,  40).c_str(),
			 "Line",              ulLine,
			 "Function",          pcszFunc,
			 "Expression",        pcszExp,
			 "GetLastError()",    (LPSTR)lpMsgBuf,
			 "Comment",           pcszComment 
    );

	if (NULL == szMsg || '\0' == *szMsg) {
		::MessageBox(0, "wsprintf() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	if (NULL != lpMsgBuf) {
		::LocalFree(lpMsgBuf);    lpMsgBuf = NULL;
	}

	//-------------------------------------
	//������� MessageBox
	INT iRes = ::MessageBox(NULL, szMsg, szExeName, MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    	exit(- 1);
			break;
		}
		case IDRETRY: {
			_asm {
				int 3
			} 
			break;
		}
		case IDIGNORE: {
			break;
		}
	}
}
//---------------------------------------------------------------------------