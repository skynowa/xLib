#include <XLib/CXFile.h>
//---------------------------------------------------------------------------
#include <shlobj.h>
#include <shellapi.h>
#include <Strsafe.h>
#include <XLib/xassert.h>


//---------------------------------------------------------------------------
const HANDLE CXFile::hFileNull = INVALID_HANDLE_VALUE;
//---------------------------------------------------------------------------
CXFile::CXFile() {
	m_hFile          = INVALID_HANDLE_VALUE;
	m_bCloseOnDelete = FALSE;
}
//---------------------------------------------------------------------------
CXFile::CXFile(HANDLE hFile) {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);

	m_hFile          = hFile;
	m_bCloseOnDelete = FALSE;
}
//---------------------------------------------------------------------------
CXFile::CXFile(LPCTSTR lpszFileName, UINT nOpenFlags) {
	/////*DEBUG*/XASSERT(AfxIsValidString(lpszFileName));
	m_hFile = INVALID_HANDLE_VALUE;

	if (!Open(lpszFileName, nOpenFlags)) {
		
	}
}
//---------------------------------------------------------------------------
CXFile::~CXFile() {
	if (INVALID_HANDLE_VALUE != m_hFile && m_bCloseOnDelete ) {
		Close();
	}
}
//---------------------------------------------------------------------------
CXFile* CXFile::Duplicate() const {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

	CXFile* pFile = new CXFile();
	HANDLE hFile = INVALID_HANDLE_VALUE;
	if (!::DuplicateHandle(::GetCurrentProcess(), m_hFile,	::GetCurrentProcess(), &hFile, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
		if (pFile != NULL) {
			delete pFile; pFile = NULL;
		}
	}
	pFile->m_hFile = hFile;
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != pFile->m_hFile);
	pFile->m_bCloseOnDelete = m_bCloseOnDelete;

	return pFile;
}
//---------------------------------------------------------------------------
BOOL CXFile::Open(LPCTSTR lpszFileName, UINT nOpenFlags) {
	/*DEBUG*/XASSERT(NULL != this);
	/////*DEBUG*/XASSERT(AfxIsValidString(lpszFileName));

	/////*DEBUG*/XASSERT(pException == NULL || AfxIsValidAddress(pException, sizeof(CFileException)));
	/*DEBUG*/XASSERT(0 == (nOpenFlags & typeText));   // text mode not supported

	//shouldn't open an already open file (it will leak)
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE == m_hFile);

	//CFile objects are always binary and CreateFile does not need flag
	nOpenFlags &= ~(UINT)typeBinary;

	m_bCloseOnDelete = FALSE;
	m_hFile          = INVALID_HANDLE_VALUE;
	m_sFileName    = "";  ////m_sFileName.Empty();

	TCHAR szTemp[_MAX_PATH + 1];
	if (lpszFileName != NULL && SUCCEEDED(StringCchLength(lpszFileName, _MAX_PATH, NULL)) )	{
		////if( _AfxFullPath2(szTemp, lpszFileName,pException) == FALSE )
		////	return FALSE;
	} else {
		// user passed in a buffer greater then _MAX_PATH
		////if (pException != NULL)
		////{
		////	pException->m_cause = CFileException::badPath;
		////	pException->m_sFileName = lpszFileName;
		////}
		return FALSE; // path is too long
	}
		
	m_sFileName = szTemp;
	/*DEBUG*/XASSERT(0 == shareCompat);
	
	//-------------------------------------
	//map read/write mode
	/*DEBUG*/XASSERT(3 == (modeRead|modeWrite|modeReadWrite));
	DWORD dwAccess = 0;
	switch (nOpenFlags & 3) {
		case modeRead:
			dwAccess = GENERIC_READ;
			break;

		case modeWrite:
			dwAccess = GENERIC_WRITE;
			break;

		case modeReadWrite:
			dwAccess = GENERIC_READ | GENERIC_WRITE;
			break;

		default:
			/*DEBUG*/XASSERT(FALSE);  // invalid share mode
	}

	//-------------------------------------
	//map share mode
	DWORD dwShareMode = 0;
	switch (nOpenFlags & 0x70) {   // map compatibility mode to exclusive
		default:
			/*DEBUG*/XASSERT(FALSE);  // invalid share mode?
		case shareCompat:
		case shareExclusive:
			dwShareMode = 0;
			break;

		case shareDenyWrite:
			dwShareMode = FILE_SHARE_READ;
			break;

		case shareDenyRead:
			dwShareMode = FILE_SHARE_WRITE;
			break;

		case shareDenyNone:
			dwShareMode = FILE_SHARE_WRITE | FILE_SHARE_READ;
			break;
	}

	//Note: typeText and typeBinary are used in derived classes only.

	//-------------------------------------
	//map modeNoInherit flag
	SECURITY_ATTRIBUTES sa;
	sa.nLength              = sizeof(sa);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle       = (nOpenFlags & modeNoInherit) == 0;

	//-------------------------------------
	//map creation flags
	DWORD dwCreateFlag;
	if (nOpenFlags & modeCreate) {
		if (nOpenFlags & modeNoTruncate) {
			dwCreateFlag = OPEN_ALWAYS;
		} else {
			dwCreateFlag = CREATE_ALWAYS;
		}
	} else {
		dwCreateFlag = OPEN_EXISTING;
	}

	//special system-level access flags

	//Random access and sequential scan should be mutually exclusive
	/*DEBUG*/XASSERT((nOpenFlags&(osRandomAccess|osSequentialScan)) != (osRandomAccess| osSequentialScan));

	DWORD dwFlags = FILE_ATTRIBUTE_NORMAL;
	if (nOpenFlags & osNoBuffer) {
		dwFlags |= FILE_FLAG_NO_BUFFERING;
	}
	if (nOpenFlags & osWriteThrough) {
		dwFlags |= FILE_FLAG_WRITE_THROUGH;
	}
	if (nOpenFlags & osRandomAccess) {
		dwFlags |= FILE_FLAG_RANDOM_ACCESS;
	}
	if (nOpenFlags & osSequentialScan) {
		dwFlags |= FILE_FLAG_SEQUENTIAL_SCAN;
	}

	//attempt file creation
	HANDLE hFile = ::CreateFile(lpszFileName, dwAccess, dwShareMode, &sa, dwCreateFlag, dwFlags, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		/*DEBUG*/XASSERT(false);	
		return FALSE;
	}

	m_hFile          = hFile;
	m_bCloseOnDelete = TRUE;

	return TRUE;
}
//---------------------------------------------------------------------------
UINT CXFile::Read(void* lpBuf, UINT nCount) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

	if (0 == nCount) {
		return 0;   // avoid Win32 "null-read"
	}

	/*DEBUG*/XASSERT(lpBuf != NULL);
	/////*DEBUG*/XASSERT(AfxIsValidAddress(lpBuf, nCount));

	DWORD dwRead = 0;
	if (!::ReadFile(m_hFile, lpBuf, nCount, &dwRead, NULL)) {
		/*DEBUG*/XASSERT(false);
	}

	return (UINT)dwRead;
}
//---------------------------------------------------------------------------
void CXFile::Write(const void* lpBuf, UINT nCount) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

	if (nCount == 0) {
		return;     // avoid Win32 "null-write" option
	}

	/*DEBUG*/XASSERT(lpBuf != NULL);
	/////*DEBUG*/XASSERT(AfxIsValidAddress(lpBuf, nCount, FALSE));

	DWORD nWritten = 0;
	if (!::WriteFile(m_hFile, lpBuf, nCount, &nWritten, NULL)) {
		/*DEBUG*/XASSERT(false);
	}

	if (nWritten != nCount) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::Seek(LONGLONG lOff, UINT nFrom) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);
	/*DEBUG*/XASSERT(nFrom == begin || nFrom == end || nFrom == current);
	/*DEBUG*/XASSERT(begin == FILE_BEGIN && end == FILE_END && current == FILE_CURRENT);

    LARGE_INTEGER liOff;

    liOff.QuadPart = lOff;
	liOff.LowPart  = ::SetFilePointer(m_hFile, liOff.LowPart, &liOff.HighPart,  (DWORD)nFrom);
	if ((DWORD) - 1 == liOff.LowPart) {
		if (NO_ERROR != ::GetLastError()) {
		   /*DEBUG*/XASSERT(false);
		}
	}

	return liOff.QuadPart;
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::GetPosition() const {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

    LARGE_INTEGER liPos;
    liPos.QuadPart = 0;
	liPos.LowPart  = ::SetFilePointer(m_hFile, liPos.LowPart, &liPos.HighPart , FILE_CURRENT);
	if ((DWORD) - 1 == liPos.LowPart) {
		if (NO_ERROR != ::GetLastError()) {
		   /*DEBUG*/XASSERT(false);
		}
	}

	return liPos.QuadPart;
}
//---------------------------------------------------------------------------
void CXFile::Flush() {
	/*DEBUG*/XASSERT(NULL != this);

	if (INVALID_HANDLE_VALUE == m_hFile) {
		return;
	}

	if (!::FlushFileBuffers(m_hFile)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
void CXFile::Close() {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);
	
	BOOL bError = FALSE;
	if (INVALID_HANDLE_VALUE != m_hFile) {
		bError = !::CloseHandle(m_hFile);
	}

	m_hFile          = INVALID_HANDLE_VALUE;
	m_bCloseOnDelete = FALSE;
	m_sFileName    = "";

	if (bError) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
void CXFile::Abort() {
	/*DEBUG*/XASSERT(NULL != this);

	if (INVALID_HANDLE_VALUE != m_hFile) {
		//close but ignore errors
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	m_sFileName = ""; ////m_sFileName.Empty();
}
//---------------------------------------------------------------------------
void CXFile::LockRange(ULONGLONG dwPos, ULONGLONG dwCount) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

    ULARGE_INTEGER liPos;
    ULARGE_INTEGER liCount;

    liPos.QuadPart   = dwPos;
    liCount.QuadPart = dwCount;
	if (!::LockFile(m_hFile, liPos.LowPart, liPos.HighPart, liCount.LowPart,   liCount.HighPart)) {
		/*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
void CXFile::UnlockRange(ULONGLONG dwPos, ULONGLONG dwCount) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

    ULARGE_INTEGER liPos;
    ULARGE_INTEGER liCount;

    liPos.QuadPart = dwPos;
    liCount.QuadPart = dwCount;
	if (!::UnlockFile(m_hFile, liPos.LowPart, liPos.HighPart, liCount.LowPart,  liCount.HighPart)) {
		/*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
void CXFile::SetLength(ULONGLONG dwNewLen) {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

	Seek(dwNewLen, (UINT)begin);

	if (!::SetEndOfFile(m_hFile)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::GetLength() const {
	/*DEBUG*/XASSERT(NULL != this);

    ULARGE_INTEGER liSize;
    liSize.LowPart = ::GetFileSize(m_hFile, &liSize.HighPart);
	if (INVALID_FILE_SIZE == liSize.LowPart) {
	    if (NO_ERROR != ::GetLastError()) {
			/*DEBUG*/XASSERT(false);
	    }
	}

	return liSize.QuadPart;
}
//---------------------------------------------------------------------------
// CXFile does not support direct buffering (CMemFile does)
UINT CXFile::GetBufferPtr(UINT nCommand, UINT /*nCount*/, void** /*ppBufStart*/, void** /*ppBufMax*/) {
	/*DEBUG*/XASSERT(nCommand == bufferCheck);
	////UNUSED(nCommand);    // not used in retail build

	return 0;   // no support
}
//---------------------------------------------------------------------------
void PASCAL CXFile::Rename(LPCTSTR lpszOldName, LPCTSTR lpszNewName) {
	if (!::MoveFile((LPTSTR)lpszOldName, (LPTSTR)lpszNewName)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
void PASCAL CXFile::Remove(LPCTSTR lpszFileName) {
	if (!::DeleteFile((LPTSTR)lpszFileName)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------