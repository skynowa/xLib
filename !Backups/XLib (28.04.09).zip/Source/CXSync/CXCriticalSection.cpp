/****************************************************************************
*    �����: CXCriticalSection (CXCriticalSection.h)
*
*****************************************************************************/


#include <XLib/CXSync/CXCriticalSection.h>
//---------------------------------------------------------------------------
CXCriticalSection::CXCriticalSection() {
	::InitializeCriticalSection(&m_CS);
}
//---------------------------------------------------------------------------
#if (_WIN32_WINNT >= 0x0403)
CXCriticalSection::CXCriticalSection(unsigned long int ulSpinCount) {
	::InitializeCriticalSectionAndSpinCount(&m_CS, ulSpinCount);
}
#endif
//---------------------------------------------------------------------------
CXCriticalSection::~CXCriticalSection() {
	::DeleteCriticalSection(&m_CS);
}
//---------------------------------------------------------------------------
void CXCriticalSection::vEnter() {
	::EnterCriticalSection(&m_CS);
}
//---------------------------------------------------------------------------
void CXCriticalSection::vLeave() {
	::LeaveCriticalSection(&m_CS);
}
//---------------------------------------------------------------------------
#if (_WIN32_WINNT >= 0x0403)
unsigned long int CXCriticalSection::ulSetSpinCount(unsigned long int ulSpinCount) {
	return (::SetCriticalSectionSpinCount(&m_CS, ulSpinCount));
}
#endif
//---------------------------------------------------------------------------
#if(_WIN32_WINNT >= 0x0400)
BOOL CXCriticalSection::bTryEnter() {
	return (::TryEnterCriticalSection(&m_CS));
}
#endif
//---------------------------------------------------------------------------