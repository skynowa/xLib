//---------------------------------------------------------------------------
#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
//---------------------------------------------------------------------------
class CXFile {
    public:
    	enum OpenFlags {
    		modeRead         = (int)0x00000,
    		modeWrite        = (int)0x00001,
    		modeReadWrite    = (int)0x00002,
    		shareCompat      = (int)0x00000,
    		shareExclusive   = (int)0x00010,
    		shareDenyWrite   = (int)0x00020,
    		shareDenyRead    = (int)0x00030,
    		shareDenyNone    = (int)0x00040,
    		modeNoInherit    = (int)0x00080,
    		modeCreate       = (int)0x01000,
    		modeNoTruncate   = (int)0x02000,
    		typeText         = (int)0x04000, //typeText and typeBinary are
    		typeBinary       = (int)0x08000, //used in derived classes only
    		osNoBuffer       = (int)0x10000,
    		osWriteThrough   = (int)0x20000,
    		osRandomAccess   = (int)0x40000,
    		osSequentialScan = (int)0x80000,
    	};

    	enum Attribute {
    		normal    = 0x00,
    		readOnly  = 0x01,
    		hidden    = 0x02,
    		system    = 0x04,
    		volume    = 0x08,
    		directory = 0x10,
    		archive   = 0x20
    	};

    	enum SeekPosition { 
			begin   = 0x0, 
			current = 0x1, 
			end     = 0x2 
		};

    	static const HANDLE hFileNull;

						  CXFile();
						  CXFile(HANDLE hFile);
						  CXFile(LPCTSTR lpszFileName, UINT nOpenFlags);

    	HANDLE            m_hFile;
    	operator          HANDLE() const;

    	virtual ULONGLONG GetPosition() const;
    	////        BOOL      GetStatus(CFileStatus& rStatus) const;
    	////virtual CString   GetFileName() const;
    	////virtual CString   GetFileTitle() const;
    	////virtual CString   GetFilePath() const;
    	////virtual void      SetFilePath(LPCTSTR lpszNewName);

    	virtual BOOL       Open       (LPCTSTR lpszFileName, UINT nOpenFlags);
    	static void PASCAL Rename     (LPCTSTR lpszOldName, LPCTSTR lpszNewName);
    	static void PASCAL Remove     (LPCTSTR lpszFileName);
    	////static BOOL PASCAL GetStatus(LPCTSTR lpszFileName, CFileStatus& rStatus);
    	////static void PASCAL SetStatus(LPCTSTR lpszFileName, const CFileStatus& status);
    	ULONGLONG          SeekToEnd  ();
    	void               SeekToBegin();

    	virtual CXFile     *Duplicate  () const;

    	virtual ULONGLONG  Seek       (LONGLONG lOff, UINT nFrom);
    	virtual void       SetLength  (ULONGLONG dwNewLen);
    	virtual ULONGLONG  GetLength  () const;

    	virtual UINT       Read       (void* lpBuf, UINT nCount);
    	virtual void       Write      (const void* lpBuf, UINT nCount);

    	virtual void       LockRange  (ULONGLONG dwPos, ULONGLONG dwCount);
    	virtual void       UnlockRange(ULONGLONG dwPos, ULONGLONG dwCount);
    	
		virtual void       Abort      ();
    	virtual void       Flush      ();
    	virtual void       Close      ();

    public:
    	virtual ~CXFile();

    	enum BufferCommand  {
			bufferRead, 
			bufferWrite, 
			bufferCommit, 
			bufferCheck
		};
		enum BufferFlags	{ 
    		bufferDirect   = 0x01,
    		bufferBlocking = 0x02
    	};

    	virtual UINT GetBufferPtr(UINT nCommand, UINT nCount = 0, void** ppBufStart = NULL, void** ppBufMax = NULL);

    protected:
    	BOOL        m_bCloseOnDelete;
		std::string m_sFileName;
};
//---------------------------------------------------------------------------