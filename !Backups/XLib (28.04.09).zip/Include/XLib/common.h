#ifndef _COMMON_H_
#define _COMMON_H_

#define DELETE_POINTER(p)   if (p) {delete p; p = NULL;}  
#define DELETE_ARRAY(a)		if (a) {delete [] a; a = NULL;}
#define ZERO_BUFF(x)        ::ZeroMemory(&x, sizeof(x));
#define CLOSE_HANDLE(h)		if (INVALID_HANDLE_VALUE != hFile) {::CloseHandle(hFile);	hFile = INVALID_HANDLE_VALUE;}

#endif 


//#ifndef _COMMON_H_
//#define _COMMON_H_
//
//
//#endif 