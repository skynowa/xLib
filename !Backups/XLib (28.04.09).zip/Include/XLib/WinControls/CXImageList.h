/**********************************************************************
*	����� CXImageList (CXImageList.h)
*
***********************************************************************/


#ifndef CXImageListH
#define CXImageListH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <commctrl.h>
#include <assert.h>

#pragma comment(lib, "comctl32.lib")
//---------------------------------------------------------------------------
class CXImageList {
	public:
		HIMAGELIST         m_hImageList;

            		       CXImageList         (HIMAGELIST hImageList);
		CXImageList&       operator =          (HIMAGELIST hImageList);
		                   operator HIMAGELIST () const;
		void               Attach              (HIMAGELIST hImageList);
		HIMAGELIST         Detach              ();
		bool               IsNull              () const;
		int                GetImageCount       () const;
		COLORREF           GetBkColor          () const;
		COLORREF           SetBkColor          (COLORREF cr);
		BOOL               GetImageInfo        (int nImage, IMAGEINFO* pImageInfo) const;
		HICON              GetIcon             (int nIndex, UINT uFlags) const;
		BOOL               GetIconSize         (int& cx, int& cy) const;
		BOOL               GetIconSize         (SIZE& size) const;
		BOOL               SetIconSize         (int cx, int cy);
		BOOL               SetIconSize         (SIZE size);
		BOOL               SetImageCount       (UINT uNewCount);
		BOOL               SetOverlayImage     (int nImage, int nOverlay);
		BOOL               Create              (int cx, int cy, UINT nFlags, int nInitial, int nGrow);
		BOOL               Create              (UINT nBitmapID, int cx, int nGrow, COLORREF crMask);
		BOOL               CreateFromImage     (UINT nBitmapID, int cx, int nGrow, COLORREF crMask, UINT uType, UINT uFlags);		//&&&HBITMAP
		BOOL               Merge               (HIMAGELIST hImageList1, int nImage1, HIMAGELIST hImageList2, int nImage2, int dx, int dy);
		BOOL               Destroy             ();
		int                Add                 (HBITMAP hBitmap, HBITMAP hBitmapMask);
		int                Add                 (HBITMAP hBitmap, COLORREF crMask);
		BOOL               Remove              (int nImage);
		BOOL               RemoveAll           ();
		BOOL               Replace             (int nImage, HBITMAP hBitmap, HBITMAP hBitmapMask);
		int                AddIcon             (HICON hIcon);
		int                ReplaceIcon         (int nImage, HICON hIcon);
		HICON              ExtractIcon         (int nImage);
		BOOL               Draw                (HDC hDC, int nImage, int x, int y, UINT nStyle);
		BOOL               Draw                (HDC hDC, int nImage, POINT pt, UINT nStyle);
		BOOL               DrawEx              (int nImage, HDC hDC, int x, int y, int dx, int dy, COLORREF rgbBk, COLORREF rgbFg, UINT fStyle);
		BOOL               DrawEx              (int nImage, HDC hDC, RECT& rect, COLORREF rgbBk, COLORREF rgbFg, UINT fStyle);
		static BOOL        DrawIndirect        (IMAGELISTDRAWPARAMS* pimldp)             {return ImageList_DrawIndirect(pimldp);}
		BOOL			   Copy                (int nSrc, int nDst, UINT uFlags);
#if (_WIN32_WINNT >= 0x0501)
		////static HRESULT     ReadEx              (DWORD dwFlags, LPSTREAM lpStream, REFIID riid, PVOID* ppv) {return ImageList_ReadEx(dwFlags, lpStream, riid, ppv);}
		////HRESULT            WriteEx             (DWORD dwFlags, LPSTREAM lpStream);
#endif // (_WIN32_WINNT >= 0x0501)
		BOOL               BeginDrag           (int nImage, POINT ptHotSpot);
		BOOL               BeginDrag           (int nImage, int xHotSpot, int yHotSpot);
		static void        EndDrag             ()                                        {ImageList_EndDrag();}
		static BOOL        DragMove            (POINT pt)                                {return ImageList_DragMove(pt.x, pt.y);}
		static BOOL        DragMove            (int x, int y)                            {return ImageList_DragMove(x, y);}
		BOOL               SetDragCursorImage  (int nDrag, POINT ptHotSpot);
		BOOL               SetDragCursorImage  (int nDrag, int xHotSpot, int yHotSpot);
		static BOOL        DragShowNolock      (BOOL bShow = TRUE)                       {return ImageList_DragShowNolock(bShow);}
		static CXImageList GetDragImage        (LPPOINT lpPoint, LPPOINT lpPointHotSpot) {return CXImageList(ImageList_GetDragImage(lpPoint, lpPointHotSpot));}
		static BOOL        DragEnter           (HWND hWnd, POINT point)                  {return ImageList_DragEnter(hWnd, point.x, point.y);}
		static BOOL        DragEnter           (HWND hWnd, int x, int y)                 {return ImageList_DragEnter(hWnd, x, y);}
		static BOOL        DragLeave           (HWND hWnd)                               {return ImageList_DragLeave(hWnd);}
#if (_WIN32_IE >= 0x0400)
		CXImageList        Duplicate           () const;
		static CXImageList Duplicate           (HIMAGELIST hImageList)                   {assert(NULL != hImageList);	return CXImageList(ImageList_Duplicate(hImageList));}
#endif // (_WIN32_IE >= 0x0400)
};
//---------------------------------------------------------------------------
#endif