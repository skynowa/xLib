/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#ifndef CXWnd_H
#define CXWnd_H
//---------------------------------------------------------------------------
#include <windows.h>
#include <commctrl.h>
#include <string>
#include <assert.h>

using namespace std;
//---------------------------------------------------------------------------
class CXWnd {
	public:
		                        CXWnd               ();
		void                    SetText             (const string &csText);
		string                  GetText             ();
		int                     GetWidth            ();
		int                     GetHeight           ();
		int                     GetLeft             ();
		int                     GetTop              ();
		void                    SetSize             (int Width, int Height);
		void                    SetPosition         (int Left,  int Top);
		void                    Align               (HWND hParent, HWND hChild);
		void                    SetRedraw           (BOOL Redraw);
		RECT                    GetRect             ();
		void                    SetRect             (RECT Rect);
		HWND                    GetHandle           ();
		HFONT                   GetFont             ();
		void                    SetFont             (HFONT hFont);

		void                    SetDefaultFont      ();
		LOGFONT                 GetLogicalFont      ();
		HWND                    SetFocus            ();
		HMENU                   GetMenu             ();
		void                    SetMenu             (HMENU Value);

		BOOL                    Destroy             ();
		BOOL                    Enable              (BOOL Enabled);
		BOOL                    Invalidate          (BOOL Erase);
		BOOL                    Invalidate          (LPRECT Rect, BOOL Erase);
		BOOL                    Validate            ();
		BOOL                    Validate            (LPRECT Rect);
		void                    SetCursor           (HCURSOR Cursor);
		BOOL                    Show                (int CmdShow);
		BOOL                    IsVisible           ();
		BOOL                    bIsWindow           ();

		void                    (*OnDoubleClick)    ();
		void                    (*OnClose)          ();
		void                    (*OnDestroy)        ();
		void                    (*OnTimer)          (HWND hTimer, LPARAM lParam);
		void                    (*OnResize)         (int NewWidth, int NewHeight, WPARAM SizeType);
		void                    (*OnResizing)       (WPARAM Edge, LPRECT DragRect);
		void                    (*OnContextMenu)    (HWND hWnd, int X, int Y);
		void                    (*OnNotify)         (WPARAM wParam, LPARAM lParam);
		void                    (*OnCreate)         (WPARAM wParam, LPARAM lParam);
		void                    (*OnCommand)        (WPARAM wParam, LPARAM lParam);
		void                    (*OnChar)           (WPARAM wParam, LPARAM lParam);
		void                    (*OnKeyDown)        (WPARAM wParam, LPARAM lParam);
		void                    (*OnKeyUp)          (WPARAM wParam, LPARAM lParam);
		void                    (*OnDeadChar)       (WPARAM wParam, LPARAM lParam);
		void                    (*OnMouseMove)      (WPARAM VKeys, int x, int y);
		void                    (*OnMouseLeftUp)    (WPARAM VKeys, int x, int y);

protected:
		HWND                    _m_hWnd;
		HMENU                   _m_hMenu;
		string                  _m_sText;
		string                  _m_sClassName;
		int                     _m_iWidth, _m_iHeight, _m_iLeft, _m_iTop;
		HFONT                   _m_DefaultFont;

		static LRESULT CALLBACK StatiCXWndProc      (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This static method is called by Windows
		LRESULT                 WndProc             (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by StatiCXWndProc
		BOOL                    HandleMessage       (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by WndProc
		void                    vStartCommonControls(DWORD dwFlags);
		UINT_PTR                SetTimer            (UINT_PTR nIDEvent, UINT uElapse);
		BOOL                    KillTimer           (UINT_PTR uIDEvent);

	private:
		HFONT                   CreateDefaultFont   ();

};
//---------------------------------------------------------------------------
#endif
