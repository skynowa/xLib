/****************************************************************************
*    ����� CXSafeMTLong (CXSafeMTLong.h)	
*
*****************************************************************************/


#ifndef SAFELONG_H
#define SAFELONG_H
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
class CXSafeMTLong {
	public:
		CXSafeMTLong()  { 
			InterlockedExchange(&m_liValue, 0); 
		}

		~CXSafeMTLong() {

		}

		CXSafeMTLong& operator += (const CXSafeMTLong &cRight) {
			InterlockedExchangeAdd(&m_liValue, cRight.m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator -= (const CXSafeMTLong &cRight) {
			InterlockedExchange(&m_liValue, m_liValue - cRight.m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator = (const CXSafeMTLong &cRight)	{
			InterlockedExchange(&m_liValue, cRight.m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator += (const long int cliRight) {
			InterlockedExchangeAdd(&m_liValue, cliRight); 

			return *this;
		}

		CXSafeMTLong& operator -= (const long int cliRight) {
			InterlockedExchange(&m_liValue, m_liValue - cliRight); 

			return *this;
		}

		CXSafeMTLong& operator = (const long int cliRight) {
			InterlockedExchange(&m_liValue, cliRight); 

			return *this;
		}

		bool operator == (const CXSafeMTLong &cRight) {
			return m_liValue == cRight.m_liValue;
		}

		bool operator != (const CXSafeMTLong &cRight) {
			return !(m_liValue == cRight.m_liValue);
		}

		bool operator == (const long int cliRight) {
			return m_liValue == cliRight;
		}

		bool operator != (const long int cliRight) {
			return !(m_liValue == cliRight);
		}

		operator long int () {
			return m_liValue;
		}

		operator bool () {
			return m_liValue ? true : false; 
		}

		CXSafeMTLong& operator ++ (int iPos)	{
			if (0 == iPos) {
				InterlockedIncrement(&m_liValue);
			} else {
				InterlockedExchangeAdd(&m_liValue, iPos + 1);
			}

			return *this;
		}

		CXSafeMTLong& operator -- (int iPos)	{
			if (0 == iPos) {
				InterlockedDecrement(&m_liValue);
			} else {
				InterlockedExchangeAdd(&m_liValue, - (iPos + 1));
			}

			return *this;
		}

	private:
		long int m_liValue;
};
//---------------------------------------------------------------------------
#endif