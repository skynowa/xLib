#include <XLib/xassert.h>
//---------------------------------------------------------------------------
VOID bCheckNumericLimits() {
	XASSERT(CHAR_BIT      == 8);         /* number of bits in a char */

	XASSERT(SCHAR_MIN   == (-128));      /* minimum signed char value */
	XASSERT(SCHAR_MAX     == 127);       /* maximum signed char value */
	XASSERT(UCHAR_MAX     == 0xff);      /* maximum unsigned char value */

	#ifndef _CHAR_UNSIGNED
		XASSERT(CHAR_MIN    == SCHAR_MIN);   /* mimimum char value */
		XASSERT(CHAR_MAX    == SCHAR_MAX);   /* maximum char value */
	#else
		XASSERT(CHAR_MIN    == 0);
		XASSERT(CHAR_MAX    == UCHAR_MAX);
	#endif  /* _CHAR_UNSIGNED */

	XASSERT(MB_LEN_MAX    == 5);             /* max. # bytes in multibyte char */
	XASSERT(SHRT_MIN      == (-32768));        /* minimum (signed) short value */
	XASSERT(SHRT_MAX      == 32767);         /* maximum (signed) short value */
	XASSERT(USHRT_MAX     == 0xffff);        /* maximum unsigned short value */
	XASSERT(INT_MIN       == (-2147483647 - 1)); /* minimum (signed) int value */
	XASSERT(INT_MAX       == 2147483647);    /* maximum (signed) int value */
	XASSERT(UINT_MAX      ==  0xffffffff);    /* maximum unsigned int value */
	XASSERT(LONG_MIN      == (-2147483647L - 1)); /* minimum (signed) long value */
	XASSERT(LONG_MAX      == 2147483647L);   /* maximum (signed) long value */
	XASSERT(ULONG_MAX     == 0xffffffffUL);  /* maximum unsigned long value */
	XASSERT(LLONG_MAX     == 9223372036854775807i64);       /* maximum signed long long int value */
	XASSERT(LLONG_MIN     == (-9223372036854775807i64 - 1));  /* minimum signed long long int value */
	XASSERT(ULLONG_MAX    == 0xffffffffffffffffui64);       /* maximum unsigned long long int value */

	XASSERT(_I8_MIN       == (-127i8 - 1));    /* minimum signed 8 bit value */
	XASSERT(_I8_MAX       == 127i8);         /* maximum signed 8 bit value */
	XASSERT(_UI8_MAX      == 0xffui8);       /* maximum unsigned 8 bit value */

	XASSERT(_I16_MIN      == (-32767i16 - 1)); /* minimum signed 16 bit value */
	XASSERT(_I16_MAX      == 32767i16);      /* maximum signed 16 bit value */
	XASSERT(_UI16_MAX     == 0xffffui16);    /* maximum unsigned 16 bit value */

	XASSERT(_I32_MIN      == (-2147483647i32 - 1)); /* minimum signed 32 bit value */
	XASSERT(_I32_MAX      == 2147483647i32); /* maximum signed 32 bit value */
	XASSERT(_UI32_MAX     == 0xffffffffui32); /* maximum unsigned 32 bit value */

		/* minimum signed 64 bit value */
	XASSERT(_I64_MIN      == (-9223372036854775807i64 - 1));
		/* maximum signed 64 bit value */
	XASSERT(_I64_MAX      == 9223372036854775807i64);
		/* maximum unsigned 64 bit value */
	XASSERT(_UI64_MAX     == 0xffffffffffffffffui64);

	#if     _INTEGRAL_MAX_BITS >= 128
		/* minimum signed 128 bit value */
	XASSERT(_I128_MIN     == (-170141183460469231731687303715884105727i128 - 1));
		/* maximum signed 128 bit value */
	XASSERT(_I128_MAX     == 170141183460469231731687303715884105727i128);
		/* maximum unsigned 128 bit value */
	XASSERT(_UI128_MAX    == 0xffffffffffffffffffffffffffffffffui128);
	#endif

	#ifndef SIZE_MAX
	#ifdef _WIN64 
	XASSERT(SIZE_MAX == _UI64_MAX);
	#else
	XASSERT(SIZE_MAX == UINT_MAX);
	#endif
	#endif

	#if __STDC_WANT_SECURE_LIB__
		/* While waiting to the C standard committee to finalize the decision on RSIZE_MAX and rsize_t,
		* we define RSIZE_MAX as SIZE_MAX
		*/
	#ifndef RSIZE_MAX
	XASSERT(RSIZE_MAX == SIZE_MAX);
	#endif
	#endif

	#ifdef  _POSIX_
		XASSERT(_POSIX_ARG_MAX      == 4096);
		XASSERT(_POSIX_CHILD_MAX    == 6);
		XASSERT(_POSIX_LINK_MAX     == 8);
		XASSERT(_POSIX_MAX_CANON    == 255);
		XASSERT(_POSIX_MAX_INPUT    == 255);
		XASSERT(_POSIX_NAME_MAX     == 14);
		XASSERT(_POSIX_NGROUPS_MAX  == 0);
		XASSERT(_POSIX_OPEN_MAX     == 16);
		XASSERT(_POSIX_PATH_MAX     == 255);
		XASSERT(_POSIX_PIPE_BUF     == 512);
		XASSERT(_POSIX_SSIZE_MAX    == 32767);
		XASSERT(_POSIX_STREAM_MAX   == 8);
		XASSERT(_POSIX_TZNAME_MAX   == 3);

		XASSERT(ARG_MAX             == 14500);       /* 16k heap, minus overhead */
		XASSERT(LINK_MAX            == 1024);
		XASSERT(MAX_CANON           == _POSIX_MAX_CANON);
		XASSERT(MAX_INPUT           == _POSIX_MAX_INPUT);
		XASSERT(NAME_MAX            == 255);
		XASSERT(NGROUPS_MAX         == 16);
		XASSERT(OPEN_MAX            == 32);
		XASSERT(PATH_MAX            == 512);
		XASSERT(PIPE_BUF            == _POSIX_PIPE_BUF);
		XASSERT(SSIZE_MAX           == _POSIX_SSIZE_MAX);
		XASSERT(STREAM_MAX          == 20);
		XASSERT(TZNAME_MAX          == 10);
	#endif  /* POSIX */
}
//---------------------------------------------------------------------------