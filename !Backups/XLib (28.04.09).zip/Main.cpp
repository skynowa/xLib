/****************************************************************************
* Lib name:  XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/common.h>
#include <XLib/WSocket.h>
#include <XLib/CXPop3.h>
#include <XLib/CXSmtp.h>

#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>


#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>
#include <XLib/CXFile.h>
#include <XLib/CComPort.h>
#include <XLib/CXGuid.h>
#include <XLib/CXCrc32.h>
#include <XLib/CXHandleHolder.h>
#include <XLib/CXRandom.h>
#include <XLib/CXSafeMTLong.h>
#include <XLib/CXIni.h>
#include <XLib/CXLog.h>
#include <XLib/CXMsgBox.h>
#include <XLib/CXMsgBoxRtf.h>
#include <XLib/CXPerform.h>


using namespace std;
//---------------------------------------------------------------------------
int main(int /*argc*/) {




	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------