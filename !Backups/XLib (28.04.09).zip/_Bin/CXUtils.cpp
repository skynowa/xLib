/****************************************************************************
*
*
*****************************************************************************/


#include <XLib/WinControls/CXUtils.h>
//---------------------------------------------------------------------------
//Converts a value in bytes to a string
string CXUtils::SizeToString(DWORD dwSize) {
	if (dwSize <= 0) {
		return "";
	} 

	ostringstream oss;
	oss.setf(ios_base::fixed);

	float nSize;
	string sUnit;

	if (dwSize < 1000)
	 { //1KB
		nSize = dwSize;
		sUnit = " B";
	} else if (dwSize < 1000000)
	 { //1MB
		nSize = dwSize / (float)0x400;
		sUnit = " KB";
	} else if (dwSize < 1000000000)
	 { //1GB
		nSize = dwSize / (float)0x100000;
		sUnit = " MB";
	} else {
		nSize = dwSize / (float)0x40000000;
		sUnit = " GB";
	}

	if (nSize == (int)nSize) {
		oss.precision(0);
	} else if (nSize < 10) {
		oss.precision(2);
	} else if (nSize < 100) {
		oss.precision(1);
	} else {
		oss.precision(0);
	} 

	if (oss << nSize << sUnit) {
		return oss.str();
	} else {
		return "";
	} 
}

//---------------------------------------------------------------------------
//Returns the application path
string CXUtils::ApplicationPath() {
	TCHAR szFileName[MAX_PATH];
	GetModuleFileName(NULL, szFileName, MAX_PATH);
	string sPath(szFileName);
	sPath = sPath.substr(0, sPath.rfind('\\', sPath.length()) + 1);
	return sPath;
}

//---------------------------------------------------------------------------
//Returns a file's extension
string CXUtils::FileExtension(string sFileName) {
	return sFileName.substr(sFileName.rfind('.', sFileName.length()) + 1);
}

//---------------------------------------------------------------------------
//Converts a FILETIME to a time_t
string CXUtils::FiletimeToString(LPFILETIME Filetime) {
	if (Filetime->dwLowDateTime == 0 && Filetime->dwHighDateTime == 0) {
		return "";
	} 
    
    SYSTEMTIME st;
	FileTimeToSystemTime(Filetime, &st);
	CHAR szDate[20];
	GetDateFormat(LOCALE_USER_DEFAULT, DATE_SHORTDATE, &st, NULL, szDate, 20);
	return szDate;
}

//---------------------------------------------------------------------------
