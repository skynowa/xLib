/**********************************************************************
 *	����� MsgBox (MsgBox.cpp)
 *
 ***********************************************************************/
 
////#include <stdio.h>
////#include <stdlib.h>
#include <string>
////#include <vector>
////#include <iostream>
////#include <ostream>
#include <windows.h>
//---------------------------------------------------------------------------
const unsigned long int culTextBuffLen = 1024;
//---------------------------------------------------------------------------
void MsgBox(unsigned long int ulText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%u", ulText);
	MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(const char *cpszText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	MessageBox(0, cpszText, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(signed long int  lText, const char *cpszCaption, unsigned long int ulType) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%i", lText);
	MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------


