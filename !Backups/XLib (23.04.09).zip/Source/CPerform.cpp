/**********************************************************************
*	����� CPerform (CPerform.cpp)
*
***********************************************************************/


#include "CPerform.h"
#include "CXString.h"
#include "CXFsoString.h"
//---------------------------------------------------------------------------
//TODO: CPerform
CPerform::CPerform(const std::string &csFileName) {	
	vResetData();
	m_sLogName = csFileName;
	m_sLogPath = sExtractFilePath(sExePath()) + "\\" + m_sLogName;
	
	vLog("------------------------------");
}
//---------------------------------------------------------------------------
//TODO: ~CPerform
CPerform::~CPerform() {	
	vLog("------------------------------");
}
//--------------------------------------------------------------------------
//TODO: vStart
void CPerform::vStart(int iPerformMode) {
    if (iPerformMode > 2 || iPerformMode < 0) {
        m_bWasStarted = false;
        MessageBox(0, "���������� �����", "Log", MB_OK);
        return;
    }
    m_iPerfomModeNow = iPerformMode;

    switch (m_iPerfomModeNow) {
        //pmGetTickCount
		case pmGetTickCount:
			{
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
            m_dwBeginTime = GetTickCount();
			}
            break;
		
		//QueryPerformanceCounter
        case pmQueryPerformanceCounter:
			{
			if (!QueryPerformanceFrequency(&m_liStart)) {
				MessageBox(0, "��������� ����������", "Log", MB_OK);
				return;
			}
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
			QueryPerformanceFrequency(&m_liBeginCount);
			}
            break;

		//pmGetThreadTimes
		case pmGetThreadTimes:
			{
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
			GetThreadTimes(GetCurrentThread(), &m_lpCreationTime, &m_lpExitTime, &m_lpKernelTime0, &m_lpUserTime0);
			}
			break;
		
        default:	
			{
			MessageBox(0, "���������� �����", "Log", MB_OK);
			}
            break;
    }

    m_bWasStarted = true;
}
//--------------------------------------------------------------------------
//TODO: vStop
void CPerform::vStop() {
	if (m_bWasStarted == false) {
	   return;
	}

	switch (m_iPerfomModeNow) {
	   //QueryPerformanceCounter (�����)
	   case pmQueryPerformanceCounter: 
		{
        QueryPerformanceCounter(&m_liEndCount);
        m_liCount.QuadPart = m_liEndCount.QuadPart - m_liBeginCount.QuadPart;
        vLog(sTypeToStr(m_liCount.QuadPart * 1000 / m_liStart.QuadPart));
		}
		break;

	//pmGetThreadTimes (��������)
	case pmGetThreadTimes:  
		{
		GetThreadTimes(GetCurrentThread(), &m_lpCreationTime, &m_lpExitTime, &m_lpKernelTime1, &m_lpUserTime1);
		vLog(sMilliSecToTimeString((iFiletimeToint64(m_lpUserTime1) - iFiletimeToint64(m_lpUserTime0)) / 10000));	//10000 - ������������; 10 - ������������
		}
		break;
		
	//pmGetTickCount (��������)
	case pmGetTickCount:
		{
		m_dwEndTime = GetTickCount();
		vLog(sMilliSecToTimeString(m_dwEndTime - m_dwBeginTime));
		}
		break;
	}

	vResetData();
}
//---------------------------------------------------------------------------
//TODO: vResetData
void CPerform::vResetData() {
    m_iPerfomModeNow                = - 1;
    m_bWasStarted                   = false;

	//pmGetTickCount
	m_dwBeginTime                   = 0;
	m_dwEndTime                     = 0;

    //QueryPerformanceCounter
    m_liStart.QuadPart              = 0;
	m_liBeginCount.QuadPart         = 0;
	m_liEndCount.QuadPart           = 0;

	//GetThreadTimes
	m_lpCreationTime.dwLowDateTime  = 0;
    m_lpCreationTime.dwHighDateTime = 0;
	m_lpExitTime.dwLowDateTime      = 0;
    m_lpExitTime.dwHighDateTime     = 0;
	m_lpKernelTime0.dwLowDateTime   = 0;
    m_lpKernelTime0.dwHighDateTime  = 0;
	m_lpUserTime0.dwLowDateTime     = 0;
    m_lpUserTime0.dwHighDateTime    = 0;
	m_lpKernelTime1.dwLowDateTime   = 0;
    m_lpKernelTime1.dwHighDateTime  = 0;
	m_lpUserTime1.dwLowDateTime     = 0;
    m_lpUserTime1.dwHighDateTime    = 0;
    
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
}
//---------------------------------------------------------------------------
//TODO: vDeleteLog
void CPerform::vDeleteLog() {
    if (bFileExists(m_sLogPath) == false) {
		return;
    }
	if (!SetFileAttributes(m_sLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
		////vLogLastErrStrServ();
	}
	if (remove(m_sLogPath.c_str()) != 0) {
		////vLogLastErrStrServ();
	}
}
//---------------------------------------------------------------------------
//TODO: vOpenLog
void CPerform::vOpenLog() {
	STARTUPINFO si;				memset(&si, 0, sizeof(STARTUPINFO));
	PROCESS_INFORMATION pi;     memset(&pi, 0, sizeof(PROCESS_INFORMATION));
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "Notepad.exe " + m_sLogPath; 
	if (!CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
//TODO: vLog
void CPerform::vLog(const std::string &csFileText) {
	FILE *pFile = NULL;
	
    if ((pFile = fopen(m_sLogPath.c_str(), "a")) == NULL) {
        vErrorMessageBox();
    } else {
		const int ciTimeStrLength = 20;
		char      szTimeStr[ciTimeStrLength];	memset(szTimeStr, 0, sizeof(szTimeStr));

		//get current date and time
		time_t  t         = time(0);
		tm     *pCurrTime = localtime(&t);

		strftime(szTimeStr, ciTimeStrLength, "%Y-%m-%d %H:%M:%S", pCurrTime);
		fprintf(pFile, "[%s]  %s\n", szTimeStr, csFileText.c_str());
        fclose(pFile);
    }
}
//---------------------------------------------------------------------------
//TODO: vErrorMessageBox
void CPerform::vErrorMessageBox() {
	LPVOID lpMsgBuf = NULL;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "Log - Win32 API error", MB_OK | MB_ICONINFORMATION);
	LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
//TODO: asMilliSecToTimeString
std::string CPerform::sMilliSecToTimeString(__int64 i64MilliSec) {
	char szBuff[64];	memset(szBuff, 0, sizeof(szBuff));
    __int64 i64H  = 0;
    __int64 i64M  = 0;
    __int64 i64S  = 0;
    __int64 i64Ms = 0;

    i64H  = i64MilliSec / 3600000;
    i64M  = i64MilliSec % 3600000 / 60000;
    i64S  = i64MilliSec % 60000   / 1000;
    i64Ms = i64MilliSec % 1000;

    ////sprintf(szBuff, "%u:%.2u:%.2u:%.3u", i64H, i64M, i64S, i64Ms);	
    sprintf(szBuff, "%I64d:%.2I64d:%.2I64d:%.3I64d", i64H, i64M, i64S, i64Ms);	//%I64d
	
	return std::string(szBuff);
}
//---------------------------------------------------------------------------
//TODO: iFiletimeToint64
__int64 CPerform::iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//--------------------------------------------------------------------------

/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

void F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
int main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/