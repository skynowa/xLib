/****************************************************************************
*    �����: CXEvent (CXEvent.h)
*
*****************************************************************************/


#include "CXEvent.h"
//---------------------------------------------------------------------------
CXEvent::CXEvent() {
	m_hEvent = NULL;
}
//---------------------------------------------------------------------------
CXEvent::CXEvent(PSECURITY_ATTRIBUTES lpsaAttributes = NULL, BOOL bManualReset = FALSE, BOOL bInitialState = FALSE,  LPCSTR lpszName = NULL) {
	m_hEvent = NULL;
	
	BOOL bSuccess = FALSE; 
	bSuccess = bCreate(lpsaAttributes, bManualReset, bInitialState, lpszName);
	if (FALSE == bSuccess) {
		return;
	}
}
//---------------------------------------------------------------------------
CXEvent::~CXEvent() {
	if (NULL != m_hEvent) {
		::CloseHandle(m_hEvent);	m_hEvent = NULL;
	}
}
//---------------------------------------------------------------------------
HANDLE CXEvent::hGetHandle() {
	assert(NULL != m_hEvent);
    
    return m_hEvent;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCSTR lpszName) {
	m_hEvent = ::CreateEvent(lpsaAttributes, bManualReset, bInitialState, lpszName );

	return (NULL != m_hEvent);
}
//---------------------------------------------------------------------------
BOOL CXEvent::bOpen(DWORD dwAccess, BOOL bInheritHandle, LPCSTR lpszName) {
	assert(NULL != m_hEvent);
	
	/*EVENT_MODIFY_STATE, EVENT_ALL_ACCESS, EVENT_MODIFY_STATE*/
	::OpenEvent(dwAccess, bInheritHandle, lpszName);
	
	return (NULL != m_hEvent);
}
//---------------------------------------------------------------------------
BOOL CXEvent::bPulse() {
	assert(NULL != m_hEvent);
	
	return (::PulseEvent(m_hEvent));
}
//---------------------------------------------------------------------------
BOOL CXEvent::bReset() {
	assert(NULL != m_hEvent);
	
	return (::ResetEvent(m_hEvent));
}
//---------------------------------------------------------------------------
BOOL CXEvent::bSet() {
	assert(NULL != m_hEvent);

	return (::SetEvent(m_hEvent));
}
//---------------------------------------------------------------------------
DWORD CXEvent::dwWaitForSingleObject(DWORD dwTimeout = INFINITE) {
	assert(NULL != m_hEvent);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return (::WaitForSingleObject(m_hEvent, dwTimeout));
	//SignalMeAndWaitOther()	::SignalObjectAndWait() 
}
//---------------------------------------------------------------------------