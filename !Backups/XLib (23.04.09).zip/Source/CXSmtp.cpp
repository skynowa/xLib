/****************************************************************************
* Class name:  CXSmtp
* Description: SMTP ������ (RFC 2821)
* File name:   CXSmtp.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

    
#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#include <stdio.h>   
#include <string>   
#include <iostream> 
#include "xassert.h"
#include "CXSmtp.h" 
#include "CXFsoString.h" 
#include "CXLog.h" 
//---------------------------------------------------------------------------  


/****************************************************************************
*	Public methods
*
*****************************************************************************/



//---------------------------------------------------------------------------
CXSmtp::CXSmtp() {   
	WSocket::Init();   
}   
//--------------------------------------------------------------------------- 
CXSmtp::~CXSmtp() {   
	WSocket::iClean();   
}   
//--------------------------------------------------------------------------- 
bool CXSmtp::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, unsigned short int usPort) {   
	m_sUser   = csUser;   
	m_sPass   = csPass;   
	m_sServer = csServer;   
	m_usPort  = usPort;   

	return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bConnect() {   
    //Create sock   
    m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);   
    
    //Parse domain   
    char szIpAddr[16];		memset(szIpAddr, 0, sizeof(szIpAddr));
	if (true != WSocket::bDnsParse(m_sServer.c_str(), szIpAddr)) {   
        return false;   
	}
    
    //Connect   
	if (true != m_scktSocket.bConnect(szIpAddr, m_usPort)) {  
        return false;   
	}
    
    //-------------------------------------
	//[welcome message]   
    char szRecv[ms_cuiRecvSize];		memset(szRecv, 0, sizeof(szRecv)); 

    int iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
    /*DEBUG*/XASSERT(false == bIsError(szRecv));
    
#ifdef _DEBUG   
    szRecv[iRes] = '\0';   
    printf("Recv SMTP  Resp: %s", szRecv);   
#endif   
   
    return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bLogin() {   
    int  iRes = - 1;
    char szRecv[ms_cuiRecvSize];		memset(szRecv, 0, sizeof(szRecv));   

    //-------------------------------------
    //[USER\r\n]
    std::string sUserCmd = "USER " + m_sUser + "\r\n";

    iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
    /*DEBUG*/XASSERT(sUserCmd.size() == iRes);

    iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
    /*DEBUG*/XASSERT(0 < iRes);
    /*DEBUG*/XASSERT(false == bIsError(szRecv));
  
#ifdef _DEBUG   
    szRecv[iRes] = '\0';   
    printf("Recv USER Resp: %s", szRecv);   
#endif     
        
    //-------------------------------------
    //[PASS\r\n]   
    std::string sPassCmd = "PASS " + m_sPass + "\r\n";

    iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
    /*DEBUG*/XASSERT(sPassCmd.size() == iRes);
    
    iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
    /*DEBUG*/XASSERT(0 < iRes);
    /*DEBUG*/XASSERT(false == bIsError(szRecv));
        
#ifdef _DEBUG   
    szRecv[iRes] = '\0';   
    printf("Recv PASS Resp: %s", szRecv);   
#endif         
    
    return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bSendRaw(const std::string &sFilePath, const std::string &sFrom, const std::string &sTo) {   
	/*DEBUG*/XASSERT(INVALID_SOCKET != m_scktSocket);
	
	int         iRes  = - 1;   

 	char        szSend[1024];			memset(szSend,  0, sizeof(szSend));  
	char        szRecv[ms_cuiRecvSize];	memset(szRecv,  0, sizeof(szRecv)); 

	std::string sHelloCmd = "HELO\r\n";
	std::string sFromCmd  = "MAIL FROM:<" + sFrom + ">\r\n";
	std::string sToCmd    = "RCPT TO:<"   + sTo   + ">\r\n";
	std::string sDataCmd  = "DATA\r\n";
	std::string sEndCmd   = "\r\n.\r\n";

	//-------------------------------------
	//[HELO\r\n]
	iRes = m_scktSocket.iSend(sHelloCmd.c_str(), sHelloCmd.size(), 0); 
    /*DEBUG*/XASSERT(sHelloCmd.size() == iRes);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

	//-------------------------------------
	//[MAIL FROM:<my_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sFromCmd.c_str(), sFromCmd.size(), 0); 
    /*DEBUG*/XASSERT(sFromCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);	
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));
	
	//-------------------------------------	
	//[RCPT TO:<your_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sToCmd.c_str(), sToCmd.size(), 0); 
    /*DEBUG*/XASSERT(sToCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);	
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));
	
	//-------------------------------------
	//[DATA\r\n]
	iRes = m_scktSocket.iSend(sDataCmd.c_str(), sDataCmd.size(), 0); 
    /*DEBUG*/XASSERT(sDataCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

	//-------------------------------------
	//������ �� ����� � ����� ����� � �����
	FILE *pFile = fopen(sFilePath.c_str(), "r");
	/*DEBUG*/XASSERT(NULL != pFile);
	
        	size_t uiSendSize = sizeof(szSend); //1024;
        	for (;;) {
        		size_t uiReadSize = fread(szSend, 1, uiSendSize, pFile); 
        		/*DEBUG*/XASSERT(0 == ferror(pFile));
                if (uiReadSize <= 0) {
        			break;
        		}

        		iRes = m_scktSocket.iSend(szSend, uiReadSize, 0);   
        		/*DEBUG*/XASSERT(uiReadSize == iRes);
        		if (iRes < 0) {   
        			break;  
        		} 
        	}

	/*DEBUG*/XASSERT(NULL != pFile);   
	if (NULL != pFile) {
		fclose(pFile);	pFile = NULL;
	}
	
	//-------------------------------------
	//[\r\n.\r\n]
	iRes = m_scktSocket.iSend(sEndCmd.c_str(), sEndCmd.size(), 0); 
    /*DEBUG*/XASSERT(sEndCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

	return true;   
}   
//---------------------------------------------------------------------------   
bool CXSmtp::bDisconnect() {   
	int iRes = - 1;
  
	char        szRecv[ms_cuiRecvSize];			memset(szRecv, 0, sizeof(szRecv));   
	std::string sQuitCmd = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT(sQuitCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", szRecv);   
#endif     

	m_scktSocket.iClose();   

	return true;   
}   
//---------------------------------------------------------------------------   



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
int CXSmtp::iSmtpSend(char *pszInBuff, int iInBuffSize, int iFlags) {   
	/*DEBUG*/XASSERT(NULL != pszInBuff);
	/*DEBUG*/XASSERT(0     < iInBuffSize);

	int iRes    = - 1;   
	int iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iSend(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		if (iRes < 0) {  
			/*DEBUG*/XASSERT(false);
			return - 1;   
		}

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((char *)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
bool CXSmtp::bIsError(const std::string &sText) {
    /*DEBUG*/XASSERT(true == !sText.empty());

    //-------------------------------------
    //CHECK
    if (true == sText.empty()) {
        return true;
    }     
     
    /*int iResponseCode[] =
    {
        {500, "Syntax error, command unrecognized"                            },
        {501, "Syntax error in parameters or arguments"                       },
        {502, "Command not implemented"                                       },
        {503, "Bad sequence of commands"                                      },
        {504, "Command parameter not implemented"                             },
        {211, "System status, or system help reply"                           },
        {214, "Help message"                                                  },
        {220, "<domain> Service ready"                                        },
        {221, "<domain> Service closing transmission channel"                 },
        {421, "<domain> Service not available, closing transmission channel"  },
        {250, "Requested mail action okay, completed"                         },
        {251, "User not local; will forward to <forward-path>"                },
        {252, "Cannot VRFY user, but will accept message and attempt delivery"},
        {450, "Requested mail action not taken: mailbox unavailable"          },
        {550, "Requested action not taken: mailbox unavailable"               },
        {451, "Requested action aborted: error in processing"                 },
        {551, "User not local; please try <forward-path>"                     },
        {452, "Requested action not taken: insufficient system storage"       },
        {552, "Requested mail action aborted: exceeded storage allocation"    },
        {553, "Requested action not taken: mailbox name not allowed"          },
        {554, "Transaction failed"                                            },
        {354, "Start mail input; end with <CRLF>.<CRLF>"                      }
    };*/

	bool bRes = !(
			!memcmp(sText.c_str(), "220", 3) || 
			!memcmp(sText.c_str(), "250", 3) || 
			!memcmp(sText.c_str(), "354", 3) || 
			!memcmp(sText.c_str(), "221", 3)
	);
	 
	return bRes;
}
//---------------------------------------------------------------------------