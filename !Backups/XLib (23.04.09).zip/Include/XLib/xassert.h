/****************************************************************************
*	xassert.h
*
*****************************************************************************/


#ifndef XASSERT_H
#define XASSERT_H
//---------------------------------------------------------------------------
#include <stddef.h> //////MessageBox(0, /*__FUNCSIG__*/__FUNC__, "", MB_OK);
//---------------------------------------------------------------------------
#ifdef NXDEBUG
    #define XASSERT(exp)                 ((void)0)
    #define XASSERT_EX(exp, comment)     ((void)0)
	#define XASSERT_RET(exp, return_exp) if (exp) {/*missing...*/} else {return return_exp;}
#else /*NXDEBUG*/
    void vAssert(LPCSTR pcszExp, ULONG ulLastError, LPCSTR pcszFile, ULONG ulLine, LPCSTR pcszFunc, LPCSTR pcszComment = NULL);

    #ifndef __FILE__
	#	define __FILE__ "<unknown>"
	#endif

	#ifndef __LINE__
	#	define __LINE__ "<unknown>"
	#endif

	#ifndef __FUNCTION__
	#	define __FUNCTION__ __FUNC__
	#endif

	#ifndef __FUNC__
	#	define __FUNC__ "<unknown>"
	#endif

	//Only VC++
	#ifdef __FUNCSIG__
	#	define __FUNCTION__ __FUNCSIG__
	#endif

    #define XASSERT(exp)                 ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __FUNCSIG__),          (void)0))
    #define XASSERT_EX(exp, comment)     ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __FUNCTION__, comment), (void)0))
	#define XASSERT_RET(exp, return_exp) ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __FUNCTION__),          (void)0)); return return_exp;
#endif /*NXDEBUG*/
//---------------------------------------------------------------------------
#endif /*XASSERT_H*/
