/****************************************************************************
*    �����: CXSemaphore (CXSemaphore.h)
*
*****************************************************************************/


#ifndef CXSemaphoreH
#define CXSemaphoreH
//---------------------------------------------------------------------------
#include <iostream>
#include <windows.h>
#include <process.h>
#include <assert.h>
//---------------------------------------------------------------------------
class CXSemaphore {
	public:
			   CXSemaphore          ();
			   CXSemaphore          (PSECURITY_ATTRIBUTES lpsaAttributes, LONG nInitialCount, LONG nMaxCount, LPCSTR pszName);
			  ~CXSemaphore          ();
        HANDLE hGetHandle           ();
		BOOL   bCreate              (PSECURITY_ATTRIBUTES lpsaAttributes, LONG nInitialCount, LONG nMaxCount, LPCSTR pszName);
		BOOL   bOpen                (DWORD dwAccess, BOOL bInheritHandle, LPCSTR lpszName);
		BOOL   bRelease             (LONG nReleaseCount, LONG *pnOldCount);
        DWORD  dwWaitForSingleObject(DWORD dwTimeout);

	private:
		HANDLE m_hSemaphore;
};
//---------------------------------------------------------------------------
#endif