/****************************************************************************
* Class name:  CXSmtp
* Description: Pop3 ������ (RFC 2821)
* File name:   CXSmtp.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXSmtpH 
#define CXSmtpH 
//---------------------------------------------------------------------------
#include "WSocket.h"
//---------------------------------------------------------------------------
class CXSmtp { 
	public: 
                    	    CXSmtp     (); 
                    	   ~CXSmtp     (); 
		bool                bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, unsigned short int usPort); 
		bool                bConnect   (); 
		bool                bLogin     (); 
		bool                bSendRaw   (const std::string &csFilePath, const std::string &csFrom, const std::string &csTo); 
		bool                bDisconnect(); 

	private: 
		WSocket             m_scktSocket; 
		std::string         m_sUser; 
		std::string         m_sPass; 
		std::string         m_sServer; 
		unsigned short int  m_usPort; 
	    static const size_t ms_cuiRecvSize = 1024;

		int				    iSmtpSend  (char *pszInBuff, int iInBuffSize, int iFlags); 
		bool                bIsError   (const std::string &sText); 
}; 
//---------------------------------------------------------------------------
#endif 
