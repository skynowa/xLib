 /****************************************************************************
* Class name:  CXFsoString
* Description: ������ ��� ������ � �������� ��������
* File name:   CXFsoString.h
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:02:43
*
*****************************************************************************/


#ifndef CXFsoStringH
#define CXFsoStringH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <vector>
#include <stdio.h>
//---------------------------------------------------------------------------
enum EFileAttr {
	faInvalidFileAttr   = INVALID_FILE_ATTRIBUTES,
	faReadOnly          = FILE_ATTRIBUTE_READONLY,  
	faHidden            = FILE_ATTRIBUTE_HIDDEN,  
	faSystem            = FILE_ATTRIBUTE_SYSTEM,  
	faDirectory         = FILE_ATTRIBUTE_DIRECTORY,  
	faArchive           = FILE_ATTRIBUTE_ARCHIVE,  
	faDevice            = FILE_ATTRIBUTE_DEVICE,  
	faNormal            = FILE_ATTRIBUTE_NORMAL,  
	faTemporary         = FILE_ATTRIBUTE_TEMPORARY,  
	faSparseFile        = FILE_ATTRIBUTE_SPARSE_FILE,  
	faReparsePoint      = FILE_ATTRIBUTE_REPARSE_POINT,  
	faCompressed        = FILE_ATTRIBUTE_COMPRESSED,  
	faOffline           = FILE_ATTRIBUTE_OFFLINE,  
	faNotContentIndexed = FILE_ATTRIBUTE_NOT_CONTENT_INDEXED,  
	faEncrypted         = FILE_ATTRIBUTE_ENCRYPTED,  
	faVirtual           = FILE_ATTRIBUTE_VIRTUAL /*BC ++*/
};
//---------------------------------------------------------------------------

/****************************************************************************
* �������� � ������
*
*****************************************************************************/
std::string				 sExePath                 (); /*+*/
std::string              sExeDirPath              (); /*+*/
std::string				 sExtractFilePath         (const std::string &csFilePath); /*+*/
std::string              sExtractFullFileName     (const std::string &csFilePath); /*+*/
std::string              sExtractShortFileName    (const std::string &csFilePath); /*+*/
std::string              sExtractFileExt          (const std::string &csFilePath); /*+*/
std::string              sChangeFileExt           (const std::string &csFilePath, const std::string &csFileExt); /*+*/
std::string              sChangeFullFileName      (const std::string &csFilePath, const std::string &csFileName); /*+*/
std::string              sRemoveFileExt           (const std::string &csFilePath); /*+*/
std::string              sExtractFileDir          (const std::string &csFilePath); /*+*/
std::string              sExtractFileDrive        (const std::string &csFilePath); /*...*/
std::string              sExtractRelativePath     (const std::string &csFilePath); /*...*/
std::string              sGetEnvironmentVariable  (const std::string &csVar); /*+*/
BOOL                     bSetEnvironmentVariable  (const std::string &csvVar, const std::string &csValue); /*+*/
std::vector<std::string> vecsGetEnvironmentStrings(); /*+*/
std::string              sExpandEnvironmentStrings(const std::string &csvVar); /*+*/

std::string              sUnixToWinPath           (const std::string &csUnixPath, bool bNeedBackslashAtEnd); /*+*/
std::string              sWinToUnixPath           (const std::string &csWinPath,  bool bNeedBackslashAtEnd); /*+*/

std::string              sMinimizeFileName        (const std::string &csStr, const UINT cuiMaxLen);
std::string              sMinimizePath            (const std::string &csPath, const size_t cuiMaxLen);


/****************************************************************************
* ������ �����
*
*****************************************************************************/
ULONG					 ulFileLines              (const std::string &csFilePath); /*+*/
ULONG					 ulFileSize               (FILE *pFile); /*+*/
ULONG				     ulFileSize			      (const std::string &csFilePath); /*+*/
ULONGLONG				 ui64GetFileSize          (HANDLE hFile);	/*-*/
bool					 bGetCompressedFileSize   (LPCTSTR fileName, unsigned __int64 &size);
bool                     bGetCompressedFileSizeW  (LPCWSTR fileName, unsigned __int64 &size);


/****************************************************************************
* ��������
*
*****************************************************************************/
ULONG                    ulGetFileAttr            (const std::string &csFilePath);
BOOL                     bSetFileAttr             (const std::string &csFilePath, ULONG ulFileAttr); /*+*/
UINT					 uiIsFile                 (const std::string &csFilePath); /*+*/	//0, 1, 2 ???
 

/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/
VOID                     vFileToArray             (const std::string &csFilePath); /*-*/
std::vector<std::string> vecsReadFile             (const std::string &csFilePath); /*-*/
std::vector<char>        vecchReadFile		      (const std::string &csFilePath); /*-*/
std::string				 sReadText   		      (const std::string &csFilePath); /*+*/
bool					 bWriteText  		      (const std::string &csFilePath, const std::string &csText); /*+*/


/****************************************************************************
* �������� � �������
*
*****************************************************************************/
BOOL                     bFileExists              (const std::string &csFilePath); /*+*/
std::string              sCreateTempFileName      (const std::string &csPrefix); /*+*/
bool                     bCopyFile                (const std::string &csFilePathFrom, const std::string &csFilePathTo); /*+*/
BOOL                     bCopyFile                (const std::string &csFilePathFrom, const std::string &csFilePathTo, BOOL bFailIfExists); /*+*/
BOOL                     bMoveFile                (const std::string &csFilePathIn, const std::string &csFilePathOut);	//����, ������� /*+*/
BOOL                     bReplaceFile             (const std::string &csOldFileName, const std::string &csNewFilePath, const std::string &csBackupFilePath);
BOOL                     bDeleteFile              (const std::string &csFilePath); /*+*/
BOOL                     bSecureDeleteFile        (const std::string &csFilePath, UINT uiPasses); /*-*/
bool                     bCutFileFromEnd          (const std::string &csFilePath, LONG lDistanceToCut);	/*+*/
bool                     bCutFileFromEnd          (FILE *pFile, ULONG ulDistanceToCut);	/*+*/
bool                     bCheckSignature          (CHAR *pszBuff, CHAR *pszSignature, INT iSignatureSize);	/*-*/

BOOL                     bSetRandomFileDate       (const std::string &csFilePath); /*-*/
BOOL				     bSetFileUncompressedAttr (const std::string &csFilePath); /*-*/
BOOL			         bSetFileCompressedAttr   (const std::string &csFilePath, bool bCompress); /*-*/


/****************************************************************************
* �������� � �������
*
*****************************************************************************/
BOOL                     bDirExists               (const std::string &csDirPath);
std::string              sGetCurrentDir           ();  /*+*/
BOOL                     bSetCurrentDir           (const std::string &csDirPath); /*+*/
std::string              sGetTempPath             (); /*+*/

BOOL                     bCreateDir               (const std::string &csDirPath); /*+*/
VOID                     vForceCreateDir          (const std::string &csDirPath); /*+*/

BOOL                     bDeleteDir               (const std::string &csDirPath); /*+*/
BOOL                     bForceClearDir		  	  (const std::string &csDirPath); /*+*/
BOOL                     bForceDeleteDir          (const std::string &csDirPath); /*+*/


/****************************************************************************
* �������� � �������
*
*****************************************************************************/
BOOL                     bIsDriveReady            (const std::string &csDrivePath); /*+*/
BOOL                     bGetDiskFreeSpace        (const std::string &csDirPath, ULONGLONG &lpFreeBytesAvailableToCaller, ULONGLONG &lpTotalNumberOfBytes, ULONGLONG &lpTotalNumberOfFreeBytes); 


/****************************************************************************
*    ����������
*
*****************************************************************************/
template <class T> void  vRandomShuffle           (std::vector<T> &v); /*-*/
template <class T> void  vSortVector              (std::vector<T> &v); /*-*/


/****************************************************************************
*    ������
*
*****************************************************************************/
ULONG                    ulCountDigits            (ULONG ulDigit); 
std::string              sSizeToStr               (ULONG dwSize);
std::string              sFiletimeToStr           (LPFILETIME Filetime);


//---------------------------------------------------------------------------
#endif