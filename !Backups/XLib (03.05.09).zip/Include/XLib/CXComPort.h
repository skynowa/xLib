/**********************************************************************
*	����� CXComPort (CXComPort.h)
*
***********************************************************************/


#ifndef CXComPortH
#define CXComPortH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
//---------------------------------------------------------------------------
class CXComPort {
	public:
	                CXComPort         (const std::string &sPortNum);
		           ~CXComPort         ();
		
		BOOL         bOpen           ();
		BOOL         bConfig         ();
		BOOL         bClearData      ();
		std::string  bReadData       (LPSTR pszBuff, ULONG ulNumOfBytesToRead);
		INT          iReadDataWaiting();
		BOOL         bWriteData      (LPCSTR pcszBuff, ULONG ulNumOfBytesToWrite);
		BOOL         bClose          ();

		ULONG        dwInputBuffTest ();
		BOOL         bClearCLRDTR    (); //���������� ������ DTR
		BOOL         bClearCLRRTS    (); //���������� ������ RTS
    	BOOL         bSetSETDTR      ();   //������������ ������ DTR
		BOOL         bSetSETRTS      ();   //������������� ������ RTS
		
    private:
		HANDLE       m_hComPort;
		std::string  m_sPortNum;

		HANDLE       handle;
		COMMTIMEOUTS CommTimeOuts;
		DCB          dcb;
		COMSTAT      ComState;              
		OVERLAPPED   Overlap;
};
//---------------------------------------------------------------------------
#endif