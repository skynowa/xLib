/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef CXStringH
#define CXStringH  
//---------------------------------------------------------------------------
#include <windows.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <string>
//---------------------------------------------------------------------------
//-------------------------------------
//������ <--> �����
LONG                              StrToLONG        (LPCTSTR pszValue, LONG           Default = 0,  INT Radix = 0);	/*+*/
ULONG							  StrToDWORD       (LPCTSTR pszValue, ULONG  Default = 0,  INT Radix = 0);	/*+*/
UINT							  StrToUINT        (LPCTSTR pszValue, UINT   Default = 0,  INT Radix = 0);	/*+*/
INT                               StrToINT         (LPCTSTR pszValue, INT            Default = 0,  INT Radix = 0);	/*+*/
SHORT                             StrToSHORT       (LPCTSTR pszValue, SHORT          Default = 0,  INT Radix = 0);	/*+*/
USHORT							  StrToWORD        (LPCTSTR pszValue, USHORT Default = 0,  INT Radix = 0);	/*+*/
UCHAR							  StrToBYTE        (LPCTSTR pszValue, UCHAR  Default = 0,  INT Radix = 0);	/*+*/
DOUBLE                            StrToDOUBLE      (LPCTSTR pszValue, DOUBLE         Default = 0.0);	/*+*/
BOOL                              StrToBOOL        (LPCTSTR pszValue, BOOL           Default = FALSE);	/*+*/
bool                              StrToBool        (LPCTSTR pszValue, bool           Default = false);	/*+*/
bool                              bStrToUCHAR      (const std::string &csStr, UCHAR *ucBuff, UINT uiBuffLen);	/*+*/
std::string                       sUCHARToStr      (UCHAR *ucBuff, UINT uiBuffLen);	/*+*/
template <typename T> std::string sTypeToStr       (T val) {		
														std::ostringstream oss;
														oss << val;
														
														return oss.str();
													};	/*+*/	

template<typename T> T            iStrToType(const std::string &csStr) {
														std::istringstream iss(csStr);
														T val;
														iss >> val;

														return val;
													};	/*+*/

std::string                       sTrimChar        (const std::string &csStr, CHAR cChar); /*+*/
std::string                       sTrimSpace       (const std::string &csStr);	/*+*/
std::string                       sRemoveEOL       (const std::string &csStr);	/*+*/

std::string                       sReplaceAll      (std::string sStr, const std::string &csOldStr, const std::string &csNewStr); /*+*/
std::string						  sReplaceAll      (std::string &sStr, CHAR sOldStr, CHAR sNewStr); /*+*/

std::vector<std::string>          vecsSplit        (CHAR cDelimiter, const std::string &sStr); /*+*/ 
std::vector<std::string>          vecsSplit        (const std::string &csSep,  const std::string &sStr); /*+*/
std::string                       sJoin            (CHAR chSep, std::vector<std::string> vecsVec); /*+*/

std::string                       sUrlUnescape     (const std::string &csStr); /*+*/	//sBase64Decode
std::string                       sStrToBin        (const std::string &csStr); /*+*/
std::string                       sBinToStr        (const std::string &csStr); /*+*/

bool                              bCharToWide      (const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize);

bool                              bStrToFile       (const std::string &csStr, const std::string &csFilePath);	/*-*/
std::string                       bStrFromFile     (const std::string &csStr, const std::string &csFilePath);	/*-*/

std::string						  sTranslitLatToRus(const std::string &csStr);	/*+*/
bool                              bCharToWide      (const CHAR *pszSrc, wchar_t *pwszDest, INT iDestSize);	/*-*/

std::string						  sToLowerCase     (const std::string &csSrc);	/*+*/
std::string                       sToUpperCase     (const std::string &csSrc);	/*+*/
std::string						  sToLowerCase     (const std::string &csSrc, UINT uiPos);	/*-*/
std::string                       sToUpperCase     (const std::string &csSrc, UINT uiPos);	/*-*/

std::string                       sFormatStr       (LPCSTR pcszFormat, ...); /*+*/
std::string                       sFormatStr2      (LPCSTR pcszFormat, ...); /*+*/
std::string                       sMinimizeStr     (const std::string &csStr, const UINT cuiMaxLen); /*+*/

//-------------------------------------
//CHAR
// This is ASCII specific but is safe with chars >= 0x80
bool                              bIsSpaceChar     (UCHAR ch);
bool                              bIsPunctuation   (CHAR ch);
bool                              bIsADigit        (CHAR ch);
bool                              bIsLowerCase     (CHAR ch);
bool                              bIsUpperCase     (CHAR ch);
bool                              bIsASpaceOrTab   (UINT ch);
bool                              bIsADigit        (UINT ch);
bool                              bIsADigit        (UINT ch, UINT base);
bool                              bIsLetter        (CHAR ch);
bool                              bIsASpace        (UINT ch);
bool                              IsEOLChar        (CHAR ch);
bool                              IsLineEndChar    (CHAR ch);
bool							  bIsSlash         (CHAR ch); 

CHAR                              cMakeUpperCase   (CHAR ch);	//non-Unicode characters only
CHAR                              cMakeLowerCase   (CHAR ch);	//non-Unicode characters only

INT                               iGetHexChar      (UCHAR hd1, UCHAR hd2);
CHAR                              cHexToChar       (CHAR *pszStr);
INT								  iCharCodeAt      (const std::string &csStr, INT nIndex);	/*+*/

//-------------------------------------
//���������
std::string						  sStrToRtf        (std::string sStr);
std::string						  sRtfToStr        (std::string sStr);

std::string                       sCreatePlainGUID (); /*+*/ 
bool                              bIsRepeatedStr   (const std::string &csStr); /*+*/

std::string						  sUrlEscape	   (const std::string &csStr);	//���������� �����
std::string						  sUrlUnescape     (const std::string &csStr);  //���������� �����

std::string                       sLastErrorStr    (ULONG ulLastError);


////////// Some ATL string conversion enhancements
////////// ATL's string conversions allocate memory on the stack, which can
////////// be undesirable if converting huge strings.  These enhancements
////////// provide for a pre-allocated memory block to be used as the 
////////// destination for the string conversion.
////////#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
////////#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)
////////
////////typedef std::wstring StringW;
////////typedef std::string  StringA;
////////
////////#ifdef _UNICODE
////////typedef StringW String;
////////#define _W2T(dst,src) lstrcpyW(dst,src)
////////#define _T2W(dst,src) lstrcpyW(dst,src)
////////#define _T2A(dst,src) _W2A(dst,src)
////////#define _A2T(dst,src) _A2W(dst,src)
////////#else
////////typedef StringA String;
////////#define _W2T(dst,src) _W2A(dst,src)
////////#define _T2W(dst,src) _A2W(dst,src)
////////#define _T2A(dst,src) lstrcpyA(dst,src)
////////#define _A2T(dst,src) lstrcpyA(dst,src)
////////#endif
//---------------------------------------------------------------------------
#endif