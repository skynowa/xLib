

//---------------------------------------------------------------------------
#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
//---------------------------------------------------------------------------
class CXFile {
    public:
    	enum OpenFlags {
    		modeRead         = (int)0x00000,
    		modeWrite        = (int)0x00001,
    		modeReadWrite    = (int)0x00002,
    		shareCompat      = (int)0x00000,
    		shareExclusive   = (int)0x00010,
    		shareDenyWrite   = (int)0x00020,
    		shareDenyRead    = (int)0x00030,
    		shareDenyNone    = (int)0x00040,
    		modeNoInherit    = (int)0x00080,
    		modeCreate       = (int)0x01000,
    		modeNoTruncate   = (int)0x02000,
    		typeText         = (int)0x04000, //typeText and typeBinary are
    		typeBinary       = (int)0x08000, //used in derived classes only
    		osNoBuffer       = (int)0x10000,
    		osWriteThrough   = (int)0x20000,
    		osRandomAccess   = (int)0x40000,
    		osSequentialScan = (int)0x80000,
    	};

    	enum Attribute {
    		normal    = 0x00,
    		readOnly  = 0x01,
    		hidden    = 0x02,
    		system    = 0x04,
    		volume    = 0x08,
    		directory = 0x10,
    		archive   = 0x20
    	};

    	enum SeekPosition { 
			begin   = 0x0, 
			current = 0x1, 
			end     = 0x2 
		};

		enum BufferCommand  {
			bufferRead, 
			bufferWrite, 
			bufferCommit, 
			bufferCheck
		};
		enum BufferFlags	{ 
			bufferDirect   = 0x01,
			bufferBlocking = 0x02
		};
    	
		HANDLE     m_hFile;
		////operator   HANDLE() const;

				   CXFile     ();
				   CXFile     (HANDLE hFile);
				   CXFile     (LPCSTR lpszFileName, UINT nOpenFlags);
				  ~CXFile     ();
    	ULONGLONG  GetPosition();
    	BOOL       Open       (LPCSTR lpszFileName, UINT nOpenFlags);
    	ULONGLONG  Seek       (LONGLONG lOff, UINT nFrom);
        
        ULONGLONG  SeekToEnd  ();
    	VOID       SeekToBegin();
    	
    	VOID       vSetSize   (ULONGLONG dwNewLen);
    	ULONGLONG  ullGetSize ();

    	UINT       Read       (void* lpBuf, UINT nCount);
    	VOID       Write      (const void* lpBuf, UINT nCount);

    	VOID       LockRange  (ULONGLONG dwPos, ULONGLONG dwCount);
    	VOID       UnlockRange(ULONGLONG dwPos, ULONGLONG dwCount);
    	
		VOID       Abort      ();
    	VOID       Flush      ();
    	VOID       Close      ();

    private:
    	BOOL        m_bCloseOnDelete;
		std::string m_sFileName;
};
//---------------------------------------------------------------------------