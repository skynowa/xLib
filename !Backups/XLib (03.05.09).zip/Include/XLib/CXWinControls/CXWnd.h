/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#ifndef CXWnd_H
#define CXWnd_H
//---------------------------------------------------------------------------
#include <windows.h>
#include <commctrl.h>
#include <string>
#include <XLib/xassert.h>

#pragma comment(lib, "comctl32.lib")

using namespace std;
//---------------------------------------------------------------------------
class CXWnd {
	public:
		                        CXWnd               ();
		VOID                    SetText             (const string &csText);
		std::string             GetText             ();
		INT                     GetWidth            ();
		INT                     GetHeight           ();
		INT                     GetLeft             ();
		INT                     GetTop              ();
		VOID                    SetSize             (INT Width, INT Height);
		VOID                    SetPosition         (INT Left,  INT Top);
		VOID                    Align               (HWND hParent, HWND hChild);
		VOID                    SetRedraw           (BOOL Redraw);
		RECT                    GetRect             ();
		VOID                    SetRect             (RECT Rect);
		HWND                    GetHandle           ();
		HFONT                   GetFont             ();
		VOID                    SetFont             (HFONT hFont);

		VOID                    SetDefaultFont      ();
		LOGFONT                 GetLogicalFont      ();
		HWND                    SetFocus            ();
		HMENU                   GetMenu             ();
		VOID                    SetMenu             (HMENU Value);

		BOOL                    Destroy             ();
		BOOL                    Enable              (BOOL Enabled);
		BOOL                    Invalidate          (BOOL Erase);
		BOOL                    Invalidate          (LPRECT Rect, BOOL Erase);
		BOOL                    Validate            ();
		BOOL                    Validate            (LPRECT Rect);
		VOID                    SetCursor           (HCURSOR Cursor);
		BOOL                    Show                (INT CmdShow);
		BOOL                    IsVisible           ();
		BOOL                    bIsWindow           ();

		VOID                    (*OnDoubleClick)    ();
		VOID                    (*OnClose)          ();
		VOID                    (*OnDestroy)        ();
		VOID                    (*OnTimer)          (HWND hTimer, LPARAM lParam);
		VOID                    (*OnResize)         (INT NewWidth, INT NewHeight, WPARAM SizeType);
		VOID                    (*OnResizing)       (WPARAM Edge, LPRECT DragRect);
		VOID                    (*OnContextMenu)    (HWND hWnd, INT X, INT Y);
		VOID                    (*OnNotify)         (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnCreate)         (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnCommand)        (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnChar)           (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnKeyDown)        (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnKeyUp)          (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnDeadChar)       (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnMouseMove)      (WPARAM VKeys, INT x, INT y);
		VOID                    (*OnMouseLeftUp)    (WPARAM VKeys, INT x, INT y);

protected:
		HWND                    _m_hWnd;
		HMENU                   _m_hMenu;
		string                  _m_sText;
		string                  _m_sClassName;
		INT                     _m_iWidth, _m_iHeight, _m_iLeft, _m_iTop;
		HFONT                   _m_DefaultFont;

		static LRESULT CALLBACK StatiCXWndProc      (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This static method is called by Windows
		LRESULT                 WndProc             (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by StatiCXWndProc
		BOOL                    HandleMessage       (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by WndProc
		VOID                    vStartCommonControls(DWORD dwFlags);

	private:
		HFONT                   CreateDefaultFont   ();
};
//---------------------------------------------------------------------------
#endif
