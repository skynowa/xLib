/****************************************************************************
*	xassert.h
*
*****************************************************************************/


#ifndef XASSERTEX_H
#define XASSERTEX_H
//---------------------------------------------------------------------------
#include <windows.h>
#include <stddef.h>
#include <string>
//---------------------------------------------------------------------------
#ifdef NXDEBUG
    #define XASSERT(exp)                 ((void)0)
    #define XASSERT_EX(exp, comment)     ((void)0)
	#define XASSERT_RET(exp, return_exp) if (!exp) {return return_exp;}
#else /*NXDEBUG*/
    void vAssert(const std::string &csExp, ULONG ulLastError, const std::string &csFile, ULONG ulLine, const std::string &csFunc, const std::string &csComment = "");

	#if defined(__GNUC__) || (defined(__MWERKS__) && (__MWERKS__ >= 0x3000)) || (defined(__ICC) && (__ICC >= 600))
	#    define __OUT_FUNC__ __PRETTY_FUNCTION__
	#elif defined(__DMC__) && (__DMC__ >= 0x810)
	#    define __OUT_FUNC__ __PRETTY_FUNCTION__
	#elif defined(__FUNCSIG__)
	#    define __OUT_FUNC__ __FUNCSIG__
	#elif (defined(__INTEL_COMPILER) && (__INTEL_COMPILER >= 600)) || (defined(__IBMCPP__) && (__IBMCPP__ >= 500))
	#    define __OUT_FUNC__ __FUNCTION__
	#elif defined(__BORLANDC__) && (__BORLANDC__ >= 0x550)
	#    define __OUT_FUNC__ __FUNC__
	#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199901)
	#    define __OUT_FUNC__ __func__
	#else
	#    define __OUT_FUNC__ "<unknown>"
	#endif

	#define XASSERT(exp)                 ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__),          (void)0))
    #define XASSERT_EX(exp, comment)     ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__, comment), (void)0))
	#define XASSERT_RET(exp, return_exp) ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__),          (void)0); return return_exp)
#endif /*NXDEBUG*/
//---------------------------------------------------------------------------
#endif /*XASSERT_H*/
