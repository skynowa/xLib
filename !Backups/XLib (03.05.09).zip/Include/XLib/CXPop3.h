/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXPop3H 
#define CXPop3H 
//---------------------------------------------------------------------------
#include "WSocket.h"
#include <string>
#include <vector>
//---------------------------------------------------------------------------
class CPop3 { 
	public: 
                    	   CPop3      (); 
                    	  ~CPop3      (); 
		bool               bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, unsigned short int usPort); 
		bool               bConnect   (); 
		bool               bLogin     (); 
		bool               bStat      (unsigned long int &ulSum, unsigned long int &ulSize);	
		bool               bList      (std::vector<unsigned long int> &veculList);	//������ ��������, ������ �� ������� /*-*/
		bool               bListAt    (unsigned long int &ulIndex);	                //������ ������ � �������� ulIndex   /*-*/
		bool               bRetriveRaw(int iNum, const std::string &csDirPath); 
		bool               bDisconnect(); 
		bool			   bGetSubject(char *pszSubject, const char *pcszBuf); 

	private: 
		WSocket            m_scktSocket; 
		std::string        m_sUser; 
		std::string        m_sPass; 
		std::string        m_sServer; 
		unsigned short int m_usPort; 
		static const size_t ms_cuiRecvSize = 1024;

		int				   iPop3Recv  (char *pszRecv, int iRecvSize, int iFlags); 
		bool               bIsError   (const std::string &sText); /*-*/  
		unsigned long int  ulMailsSum (const std::string &csServerAnswer);
		unsigned long int  ulMailsSize(const std::string &csServerAnswer);
}; 
//---------------------------------------------------------------------------
#endif 
