/****************************************************************************
*	CXSubclassWnd
*
*****************************************************************************/


#include <XLib/CXWinControls/CXSubclassWnd.h>
//---------------------------------------------------------------------------
CXSubclassWnd::CXSubclassWnd() {

}
//---------------------------------------------------------------------------
void CXSubclassWnd::Subclass() {
	//The "this" pointer is stored in a user window long
	SetWindowLongPtr(_m_hWnd, GWLP_USERDATA, (LONG_PTR)this);
	m_wpOrigWndProc = (WNDPROC)SetWindowLong(_m_hWnd, GWL_WNDPROC, (LONG)StatiCXWndProc);
}
//---------------------------------------------------------------------------
//Window Procedure called by windows (static)
LRESULT CALLBACK CXSubclassWnd::StatiCXWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	//The window procedure has to be static
	//Here I get the "this" pointer from the user window long and redirect to a non static member
	return ((CXSubclassWnd*)GetWindowLong(hWnd, GWLP_USERDATA))->WndProc(hWnd, message, wParam, lParam);
}
//---------------------------------------------------------------------------
//Window procedure
LRESULT CXSubclassWnd::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	HandleMessage(hWnd, message, wParam, lParam);
	
	return CallWindowProc(m_wpOrigWndProc, hWnd, message, wParam, lParam);
}
//---------------------------------------------------------------------------
//This method has to be overriden
BOOL CXSubclassWnd::Create(HWND /*hParent*/, HMENU /*hmnuID*/, DWORD /*dwStyles*/, DWORD /*dwExStyles*/) {
	return FALSE;
}
//---------------------------------------------------------------------------