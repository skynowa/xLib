/****************************************************************************
* Class name:  CXMsgBoxRtf
* Description: RTF �������������� � ::MessageBox()
* File name:   CXMsgBoxRtf.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.04.2009 15:46:40
*
*****************************************************************************/


#include <XLib/CXMsgBoxRtf.h>
//---------------------------------------------------------------------------
namespace CXMsgBoxRtf {
	const int   m_IDC_redtMsg = 2000;
	HHOOK       m_hkMsgBox    = NULL;
	HWND        m_hRichEdt    = NULL;
	std::string m_sMsg        = "";


	/****************************************************************************
	*    Private methods                                                          
	*                                                                            
	*****************************************************************************/


	//---------------------------------------------------------------------------
	//RTF edit control StreamIn's callback function  - see CRichEditCtrl::StreamIn
	static DWORD CALLBACK _LoadRtfCallback(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG FAR *pcb) {
		LPCTSTR pszMsg = (LPCTSTR)dwCookie;

		//number of bytes to copy
		*pcb = _tcslen(pszMsg) * sizeof(TCHAR);

		//limiting it up to the buffer's size
		if (*pcb > cb) {
			*pcb = cb;
		}

		//copying the string to the buffer
		memcpy(pbBuff, pszMsg, *pcb);

		//advancing to the end of the string
		pszMsg += *pcb / sizeof(TCHAR);

		// if it's the end of the string, returns NULL;
		// otherwise, returns a pointer to the next char to transfer as the cookie
		return (*pszMsg != '\0') ? (DWORD)pszMsg : NULL;
	}
	//---------------------------------------------------------------------------
	LRESULT CALLBACK CBTProc(INT iCode, WPARAM wParam, LPARAM lParam) {		
		if (iCode < 0) {
			return ::CallNextHookEx(m_hkMsgBox, iCode, wParam, lParam);
		}

		switch(iCode) {
				case HCBT_ACTIVATE:
					{
						HWND      hMainWnd      = (HWND)wParam; //Get handle to the message box!
						HWND      hBtnAbort     = NULL;	//IDABORT
						HWND      hBtnRetry     = NULL;	//IDRETRY
						HWND      hBtnIgnore    = NULL;	//IDIGNORE

						const INT iLeft         = 400;
						const INT iTop          = 300;
						const INT iWidth        = 500;
						const INT iHeight       = 300;

						const INT iBtnShift     = 100;
						const INT iRichEdtShift = 68;


						//-------------------------------------
						//����
						/*
						SetWindowPos Problems Posted by Stoic Joker on 29 Jun 2001 at 7:13 PM 
						: Can someone give me an example of SetWindowPos using IDD_DIALOG1 as the window's name? I can't understand Microsofts documentation.
						: 
						: Thanks, Hungry J
						: 

						Greetings
						Assumeing plain API try this

						case WM_INITDIALOG:
						{
						SetWindowPos(hDlg,HWND_TOPMOST,
						(GetSystemMetrics(SM_CXSCREEN) /2)-205,//<-Dialog width
						(GetSystemMetrics(SM_CYSCREEN) /2)-170,//<-Dialog height
						-0,-0,SWP_SHOWWINDOW|SWP_NOSIZE);
						}

						It's crude but effective.
						*/

						
						::SetWindowPos(hMainWnd, 0, iLeft, iTop, iWidth, iHeight, SWP_SHOWWINDOW);

						//-------------------------------------
						//������
						hBtnAbort = ::GetDlgItem(hMainWnd, IDABORT);			
						::SetWindowPos(hBtnAbort, 0, 12 + iBtnShift, 220, 88, 26, SWP_SHOWWINDOW);
						//::SetWindowText(hBtnAbort, "Abort");

						hBtnRetry  = ::GetDlgItem(hMainWnd, IDRETRY);
						::SetWindowPos(hBtnRetry, 0, 107 + iBtnShift, 220, 88, 26, SWP_SHOWWINDOW);
						//::SetWindowText(hBtnRetry, "Retry");

						hBtnIgnore = ::GetDlgItem(hMainWnd, IDIGNORE);
						::SetWindowPos(hBtnIgnore, 0, 201 + iBtnShift, 220, 88, 26, SWP_SHOWWINDOW);
						//::SetWindowText(hBtnIgnore, "Ignore");

						//-------------------------------------
						//RICHEDIT
						////::InitCommonControls();
						HMODULE hmRichEdtDll = ::LoadLibrary("RICHED32.DLL");  
						if (NULL == hmRichEdtDll) {
							::MessageBox(0, "NULL == hmRichEdtDll", "Debug", MB_OK | MB_ICONERROR);
							return 0;
						}

						m_hRichEdt = ::CreateWindowEx(0x00000000, "RICHEDIT", "", WS_CHILD | WS_VISIBLE | ES_LEFT | ES_MULTILINE | ES_WANTRETURN | ES_READONLY, iRichEdtShift, 16, 400, 180, hMainWnd, (HMENU)m_IDC_redtMsg, ::GetModuleHandle(NULL)/*instance*/, NULL);
						if (NULL == m_hRichEdt) {
							::MessageBox(0, "NULL == m_hRichEdt", "Debug",  MB_OK | MB_ICONERROR);
							return 0;
						}

						::SendMessage(m_hRichEdt, EM_SETBKGNDCOLOR, 0, ::GetSysColor(COLOR_3DFACE));
						//m_edCtrl.SetFont(GetFont());
						HFONT hFont = (HFONT)::SendMessage(hMainWnd, WM_GETFONT, 0, 0);
						::SendMessage(m_hRichEdt, WM_SETFONT, (WPARAM)hFont, FALSE);

						//-------------------------------------
						//��������� RTF ��������� (m_sMsg = "RTF �����")
						EDITSTREAM es;	    ::ZeroMemory(&es, sizeof(es));
						es.dwCookie    = (DWORD)(LPCSTR)(m_sMsg.c_str());
						es.dwError     = 0; 
						es.pfnCallback = _LoadRtfCallback;

						::SendMessage(m_hRichEdt, EM_STREAMIN, (WPARAM)SF_RTF, (LPARAM)&es);

						::FreeLibrary(hmRichEdtDll);
					}

					return 0;
		}

		return ::CallNextHookEx(m_hkMsgBox, iCode, wParam, lParam);
	}
	//---------------------------------------------------------------------------


	/****************************************************************************
	*    Public methods                                                          
	*                                                                            
	*****************************************************************************/


	//---------------------------------------------------------------------------
	int iShow(HWND hWnd, LPCSTR pcszText, LPCSTR pcszCaption, UINT uType) {
		int iRet = - 1;
		m_sMsg = std::string(pcszText);

		//Install a window hook, so we can intercept the message-box creation, and customize it
		m_hkMsgBox = ::SetWindowsHookEx(WH_CBT, (HOOKPROC)CBTProc, (HINSTANCE)NULL, ::GetCurrentThreadId());

		//Display a standard message box
		iRet = ::MessageBox(hWnd, "", pcszCaption, uType);

		//remove the window hook
		::UnhookWindowsHookEx(m_hkMsgBox);

		return iRet;
	}
	//---------------------------------------------------------------------------

}
//---------------------------------------------------------------------------