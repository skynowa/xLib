


//---------------------------------------------------------------------------
#include <XLib/CXFile.h>

#include <shlobj.h>
#include <shellapi.h>
#include <Strsafe.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXFile::CXFile() {
	m_hFile          = INVALID_HANDLE_VALUE;
	m_bCloseOnDelete = FALSE;
}
//---------------------------------------------------------------------------
CXFile::CXFile(HANDLE hFile) {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);

	m_hFile          = hFile;
	m_bCloseOnDelete = FALSE;
}
//---------------------------------------------------------------------------
CXFile::CXFile(LPCSTR lpszFileName, UINT nOpenFlags) {
	m_hFile = INVALID_HANDLE_VALUE;

	if (!Open(lpszFileName, nOpenFlags)) {
		
	}
}
//---------------------------------------------------------------------------
CXFile::~CXFile() {
	if (INVALID_HANDLE_VALUE != m_hFile && m_bCloseOnDelete ) {
		Close();
	}
}
//---------------------------------------------------------------------------
BOOL CXFile::Open(LPCSTR lpszFileName, UINT nOpenFlags) {
	/////*DEBUG*/XASSERT(AfxIsValidString(lpszFileName));

	/////*DEBUG*/XASSERT(pException == NULL || AfxIsValidAddress(pException, sizeof(CFileException)));
	/*DEBUG*/XASSERT(0 == (nOpenFlags & typeText));   // text mode not supported

	//shouldn't open an already open file (it will leak)
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE == m_hFile);

	//CFile objects are always binary and CreateFile does not need flag
	nOpenFlags &= ~(UINT)typeBinary;

	m_bCloseOnDelete = FALSE;
	m_hFile          = INVALID_HANDLE_VALUE;
	m_sFileName    = "";  ////m_sFileName.Empty();

	TCHAR szTemp[_MAX_PATH + 1];
	if (lpszFileName != NULL && SUCCEEDED(StringCchLength(lpszFileName, _MAX_PATH, NULL)) )	{
		////if( _AfxFullPath2(szTemp, lpszFileName,pException) == FALSE )
		////	return FALSE;
	} else {
		// user passed in a buffer greater then _MAX_PATH
		////if (pException != NULL)
		////{
		////	pException->m_cause = CFileException::badPath;
		////	pException->m_sFileName = lpszFileName;
		////}
		return FALSE; // path is too long
	}
		
	m_sFileName = szTemp;
	/*DEBUG*/XASSERT(0 == shareCompat);
	
	//-------------------------------------
	//map read/write mode
	/*DEBUG*/XASSERT(3 == (modeRead|modeWrite|modeReadWrite));
	ULONG ulAccess = 0;
	switch (nOpenFlags & 3) {
		case modeRead:
			ulAccess = GENERIC_READ;
			break;

		case modeWrite:
			ulAccess = GENERIC_WRITE;
			break;

		case modeReadWrite:
			ulAccess = GENERIC_READ | GENERIC_WRITE;
			break;

		default:
			/*DEBUG*/XASSERT(FALSE);  // invalid share mode
	}

	//-------------------------------------
	//map share mode
	ULONG ulShareMode = 0;
	switch (nOpenFlags & 0x70) {   // map compatibility mode to exclusive
		default:
			/*DEBUG*/XASSERT(FALSE);  // invalid share mode?
		case shareCompat:
		case shareExclusive:
			ulShareMode = 0;
			break;

		case shareDenyWrite:
			ulShareMode = FILE_SHARE_READ;
			break;

		case shareDenyRead:
			ulShareMode = FILE_SHARE_WRITE;
			break;

		case shareDenyNone:
			ulShareMode = FILE_SHARE_WRITE | FILE_SHARE_READ;
			break;
	}

	//Note: typeText and typeBinary are used in derived classes only.

	//-------------------------------------
	//map modeNoInherit flag
	SECURITY_ATTRIBUTES sa;
	sa.nLength              = sizeof(sa);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle       = (nOpenFlags & modeNoInherit) == 0;

	//-------------------------------------
	//map creation flags
	ULONG ulCreateFlag;
	if (nOpenFlags & modeCreate) {
		if (nOpenFlags & modeNoTruncate) {
			ulCreateFlag = OPEN_ALWAYS;
		} else {
			ulCreateFlag = CREATE_ALWAYS;
		}
	} else {
		ulCreateFlag = OPEN_EXISTING;
	}

	//special system-level access flags

	//Random access and sequential scan should be mutually exclusive
	/*DEBUG*/XASSERT((nOpenFlags&(osRandomAccess|osSequentialScan)) != (osRandomAccess| osSequentialScan));

	ULONG ulFlags = FILE_ATTRIBUTE_NORMAL;
	if (nOpenFlags & osNoBuffer) {
		ulFlags |= FILE_FLAG_NO_BUFFERING;
	}
	if (nOpenFlags & osWriteThrough) {
		ulFlags |= FILE_FLAG_WRITE_THROUGH;
	}
	if (nOpenFlags & osRandomAccess) {
		ulFlags |= FILE_FLAG_RANDOM_ACCESS;
	}
	if (nOpenFlags & osSequentialScan) {
		ulFlags |= FILE_FLAG_SEQUENTIAL_SCAN;
	}

	//attempt file creation
	HANDLE hFile = ::CreateFile(lpszFileName, ulAccess, ulShareMode, &sa, ulCreateFlag, ulFlags, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		/*DEBUG*/XASSERT(false);	
		return FALSE;
	}

	m_hFile          = hFile;
	m_bCloseOnDelete = TRUE;

	return TRUE;
}
//---------------------------------------------------------------------------
UINT CXFile::Read(VOID* lpBuf, UINT nCount) {
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

	if (0 == nCount) {
		return 0;   // aVOID Win32 "null-read"
	}

	/*DEBUG*/XASSERT(lpBuf != NULL);
	/////*DEBUG*/XASSERT(AfxIsValidAddress(lpBuf, nCount));

	ULONG ulRead = 0;
	if (!::ReadFile(m_hFile, lpBuf, nCount, &ulRead, NULL)) {
		/*DEBUG*/XASSERT(false);
	}

	return (UINT)ulRead;
}
//---------------------------------------------------------------------------
VOID CXFile::Write(const VOID* lpBuf, UINT nCount) {
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

	if (nCount == 0) {
		return;     // aVOID Win32 "null-write" option
	}

	/*DEBUG*/XASSERT(lpBuf != NULL);
	/////*DEBUG*/XASSERT(AfxIsValidAddress(lpBuf, nCount, FALSE));

	ULONG nWritten = 0;
	if (!::WriteFile(m_hFile, lpBuf, nCount, &nWritten, NULL)) {
		/*DEBUG*/XASSERT(false);
	}

	if (nWritten != nCount) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::Seek(LONGLONG lOff, UINT nFrom) {
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);
	/*DEBUG*/XASSERT(nFrom == begin || nFrom == end || nFrom == current);
	/*DEBUG*/XASSERT(begin == FILE_BEGIN && end == FILE_END && current == FILE_CURRENT);

    LARGE_INTEGER liOff;

    liOff.QuadPart = lOff;
	liOff.LowPart  = ::SetFilePointer(m_hFile, liOff.LowPart, &liOff.HighPart,  (ULONG)nFrom);
	if ((ULONG) - 1 == liOff.LowPart) {
		if (NO_ERROR != ::GetLastError()) {
		   /*DEBUG*/XASSERT(false);
		}
	}

	return liOff.QuadPart;
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::GetPosition() {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

    LARGE_INTEGER liPos;
    liPos.QuadPart = 0;
	liPos.LowPart  = ::SetFilePointer(m_hFile, liPos.LowPart, &liPos.HighPart , FILE_CURRENT);
	if ((ULONG) - 1 == liPos.LowPart) {
		if (NO_ERROR != ::GetLastError()) {
		   /*DEBUG*/XASSERT(false);
		}
	}

	return liPos.QuadPart;
}
//---------------------------------------------------------------------------
VOID CXFile::Flush() {
	/*DEBUG*/XASSERT(NULL != this);

	if (INVALID_HANDLE_VALUE == m_hFile) {
		return;
	}

	if (!::FlushFileBuffers(m_hFile)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
VOID CXFile::Close() {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);
	
	BOOL bError = FALSE;
	if (INVALID_HANDLE_VALUE != m_hFile) {
		bError = !::CloseHandle(m_hFile);
	}

	m_hFile          = INVALID_HANDLE_VALUE;
	m_bCloseOnDelete = FALSE;
	m_sFileName    = "";

	if (bError) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
VOID CXFile::Abort() {
	if (INVALID_HANDLE_VALUE != m_hFile) {
		//close but ignore errors
		::CloseHandle(m_hFile);
		m_hFile = INVALID_HANDLE_VALUE;
	}
	m_sFileName = ""; ////m_sFileName.Empty();
}
//---------------------------------------------------------------------------
VOID CXFile::LockRange(ULONGLONG dwPos, ULONGLONG dwCount) {
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

    ULARGE_INTEGER liPos;
    ULARGE_INTEGER liCount;

    liPos.QuadPart   = dwPos;
    liCount.QuadPart = dwCount;
	if (!::LockFile(m_hFile, liPos.LowPart, liPos.HighPart, liCount.LowPart,   liCount.HighPart)) {
		/*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
VOID CXFile::UnlockRange(ULONGLONG dwPos, ULONGLONG dwCount) {
	/*DEBUG*/XASSERT(m_hFile != INVALID_HANDLE_VALUE);

    ULARGE_INTEGER liPos;
    ULARGE_INTEGER liCount;

    liPos.QuadPart = dwPos;
    liCount.QuadPart = dwCount;
	if (!::UnlockFile(m_hFile, liPos.LowPart, liPos.HighPart, liCount.LowPart,  liCount.HighPart)) {
		/*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
VOID CXFile::vSetSize(ULONGLONG dwNewLen) {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

	Seek(dwNewLen, (UINT)begin);

	if (!::SetEndOfFile(m_hFile)) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
ULONGLONG CXFile::ullGetSize() {
	/*DEBUG*/XASSERT(NULL != this);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hFile);

    ULARGE_INTEGER liSize;
    liSize.LowPart = ::GetFileSize(m_hFile, &liSize.HighPart);
	if (INVALID_FILE_SIZE == liSize.LowPart) {
	    if (NO_ERROR != ::GetLastError()) {
			/*DEBUG*/XASSERT(false);
	    }
	}

	return liSize.QuadPart;
}
//---------------------------------------------------------------------------