/****************************************************************************
*	CXComboBox
*
*****************************************************************************/


#include <Xlib/CXWinControls/CXComboBox.h>
#include <fstream>
#include <Xlib/CXFsoString.h>

//---------------------------------------------------------------------------
CXComboBox::CXComboBox() {
	_m_sClassName = "COMBOBOX";
	_m_iLeft      = 0;
	_m_iTop		  = 0;
	_m_iWidth     = 130;
	_m_iHeight    = 20 * 20;
}
//---------------------------------------------------------------------------
BOOL CXComboBox::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	_m_hWnd = ::CreateWindowEx(
					dwExStyles, 
					_m_sClassName.c_str(),	
					_m_sText.c_str(),					
					WS_CHILD | WS_VISIBLE | WS_TABSTOP | dwStyles,		
					_m_iLeft,							
					_m_iTop,							
					_m_iWidth,							
					_m_iHeight,							
					hParent,							
					(HMENU)hmnuID,								
					(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
					this); 

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------
LRESULT CXComboBox::AddString(LPARAM lString) {
	/*DEBUG*/XASSERT(bIsWindow());

	return ::SendMessage(_m_hWnd, CB_ADDSTRING, 0, lString);
}
//---------------------------------------------------------------------------
LRESULT CXComboBox::ResetContent() {
    /*DEBUG*/XASSERT(bIsWindow());

	return ::SendMessage(_m_hWnd, CB_RESETCONTENT, 0, 0);
}
//---------------------------------------------------------------------------
LRESULT CXComboBox::SetCurSel(WPARAM wIndex) {
    /*DEBUG*/XASSERT(bIsWindow());

	return ::SendMessage(_m_hWnd, CB_SETCURSEL, wIndex, 0);
}
//---------------------------------------------------------------------------
BOOL CXComboBox::bLoadFromFile(const string &csFilePath, int iItemIndex) {    //overflow!!!
	/*DEBUG*/XASSERT(bIsWindow());

	//-------------------------------------
	//CHECK
	if (bFileExists(csFilePath) == false) {
		_m_iHeight = 0;
		return FALSE;
	}

	//-------------------------------------
	//JOB
	BOOL bRes = FALSE;

	try {
		ResetContent();

		//��������� ���� ���������
		std::ifstream ifsStream(csFilePath.c_str(), std::ios::in);
		const unsigned long int culBuffSize = MAX_PATH;
		char                    szBuff[culBuffSize];	
		while ((!ifsStream.eof()) && (!ifsStream.fail())) {
			ifsStream.getline(szBuff, sizeof(szBuff));					//overflow!!!
			if (0 != lstrlen(szBuff)) {
				szBuff[lstrlen(szBuff) - 1] = '\0';		//������� "\r\n"	
			}			

			AddString((LPARAM)szBuff);
		}
		ifsStream.close();

		SetCurSel(iItemIndex);

		bRes = TRUE;
	} catch (...) {
		bRes = FALSE;
	}

	return bRes;
}
//---------------------------------------------------------------------------