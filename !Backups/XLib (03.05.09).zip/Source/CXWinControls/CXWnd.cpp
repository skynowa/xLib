/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#include <Xlib/CXWinControls/CXWnd.h>
//---------------------------------------------------------------------------
CXWnd::CXWnd() {
	_m_hWnd        = NULL;
	_m_hMenu       = NULL;
	_m_sClassName  = "CXWnd";
	_m_DefaultFont = CreateDefaultFont();
	_m_sText       = "";
	OnCreate       = NULL;
	OnDoubleClick  = NULL;
	OnResize       = NULL;
	OnCommand      = NULL;
	OnMouseMove    = NULL;
	OnMouseLeftUp  = NULL;
	OnClose        = NULL;
	OnDestroy      = NULL;
}
//---------------------------------------------------------------------------
//Window Procedure called by windows (static)
LRESULT CALLBACK CXWnd::StatiCXWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	//A pointer to the current class (this) is saved into the window with
	//SetWindowLongPtr. Why ? Because WndProc is called as a static method (it's not supposed to be a class method at first)
	//The message handling is then deferred to OnMessage which can use the this pointer.
	CXWnd *pwndThis = NULL;
	if (WM_CREATE == message) {
		CREATESTRUCT *cs = (CREATESTRUCT*)lParam;
		pwndThis = (CXWnd*)cs->lpCreateParams;
		::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)pwndThis);
	} else {
		pwndThis = (CXWnd*)::GetWindowLongPtr(hWnd, GWLP_USERDATA);
	}

	if (NULL == pwndThis) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return pwndThis->WndProc(hWnd, message, wParam, lParam);
	} 
}
//---------------------------------------------------------------------------
//Window Procedure
LRESULT CXWnd::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	if (FALSE == HandleMessage(hWnd, message, wParam, lParam)) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return FALSE;
	} 
}
//---------------------------------------------------------------------------
BOOL CXWnd::HandleMessage(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) { 
		case WM_CREATE:
			{
				if (NULL != OnCreate) {
					OnCreate(wParam, lParam);
				} 
			}
			break;

		case WM_COMMAND:
			{
				if (NULL != OnCommand) {
					OnCommand(wParam, lParam);
				} 
			}
			break;

		case WM_MOUSEMOVE:
			{
				if (NULL != OnMouseMove) {
					OnMouseMove(wParam, (INT)LOWORD(lParam), (INT)HIWORD(lParam));
				} 
			}
			break;

		case WM_NOTIFY:
			{
				if (NULL != OnNotify) {
					OnNotify(wParam, lParam);
				} 
			}
			break;

		case WM_LBUTTONUP:
			{
				if (NULL != OnMouseLeftUp) {
					OnMouseLeftUp(wParam, (INT)LOWORD(lParam), (INT)HIWORD(lParam));
				} 
			}
 
			break;
		case WM_LBUTTONDBLCLK:
			{
				if (NULL != OnDoubleClick) {
					OnDoubleClick();
				}
			} 
			break;

		case WM_MOVE:
			{
				_m_iLeft = LOWORD(lParam);
				_m_iTop  = HIWORD(lParam);
			}
			break;

		case WM_CHAR:
			{
				if (NULL != OnChar) {
					OnChar(wParam, lParam);
				} 
			}
			break;

		case WM_KEYDOWN:
			{
				if (NULL != OnKeyDown) {
					OnKeyDown(wParam, lParam);
				} 
			}
			break;

		case WM_KEYUP:
			{
				if (NULL != OnKeyUp) {
					OnKeyUp(wParam, lParam);
				} 
			}
			break;

		case WM_DEADCHAR:
			{
				if (NULL != OnDeadChar) {
					OnDeadChar(wParam, lParam);
				} 
			}
			break;

		case WM_CONTEXTMENU:
			{
				if (NULL != OnContextMenu) {
					OnContextMenu((HWND)wParam, LOWORD(lParam), HIWORD(lParam));
				} 
			}
			break;

		case WM_SIZE:
			{
				_m_iWidth  = LOWORD(lParam); //_rect.right-_rect.left;
				_m_iHeight = HIWORD(lParam); //_rect.bottom-_rect.top;
				if (NULL != OnResize) {
					OnResize(_m_iWidth, _m_iHeight, wParam);
				} 
			}
			break;

		case WM_SIZING:
			{
				if (NULL != OnResizing) {
					OnResizing(wParam, (LPRECT)lParam);
				} 
			}
			break;

		case WM_TIMER:
			{
				if (NULL != OnTimer) {
					OnTimer((HWND)wParam, lParam);
				} 
			}
			break;

		case WM_CLOSE:
			{
				if (NULL != OnClose) {
					OnClose();
				} 
			}
		break;


		case WM_DESTROY:
			{
				if (NULL != OnDestroy) {
					OnDestroy();
				} 
				::PostQuitMessage(0); 
			}
			break;

		default:
			return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
VOID CXWnd::vStartCommonControls(DWORD dwFlags) {
	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = dwFlags;
	
	::InitCommonControlsEx(&iccx);
}
//---------------------------------------------------------------------------
VOID CXWnd::SetText(const string &csText) {
	/*DEBUG*///XASSERT(INVALID_HANDLE_VALUE == _m_hWnd);
		
	_m_sText = csText;
	if (NULL != _m_hWnd) {
		::SetWindowText(_m_hWnd, csText.c_str());
	} 
}
//---------------------------------------------------------------------------
string CXWnd::GetText() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	std::string sRes   = "";
	const INT   ciSize = ::GetWindowTextLength(_m_hWnd);
	if (ciSize > 0) {
		sRes.resize(ciSize + 1);
		::GetWindowText(_m_hWnd, &sRes[0], ciSize + 1);
		sRes.resize(ciSize);
	}

	return sRes;
}
//---------------------------------------------------------------------------
HWND CXWnd::GetHandle() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_hWnd;
}
//---------------------------------------------------------------------------
HFONT CXWnd::GetFont() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return (HFONT)::SendMessage(_m_hWnd, WM_GETFONT, 0, 0);
}
//---------------------------------------------------------------------------
VOID CXWnd::SetFont(HFONT hFont) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	::SendMessage(_m_hWnd, WM_SETFONT, (WPARAM)hFont, FALSE);
}
//---------------------------------------------------------------------------
HFONT CXWnd::CreateDefaultFont() {
	return ::CreateFont( -11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
}
//---------------------------------------------------------------------------
VOID CXWnd::SetDefaultFont() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	SetFont(_m_DefaultFont);
}
//---------------------------------------------------------------------------
LOGFONT CXWnd::GetLogicalFont() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	LOGFONT lf = {0};
	::GetObject(GetFont(), sizeof(LOGFONT), &lf);
	
	return lf;
}
//---------------------------------------------------------------------------
INT CXWnd::GetWidth() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_iWidth;
}
//---------------------------------------------------------------------------
INT CXWnd::GetHeight() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_iHeight;
}
//---------------------------------------------------------------------------
INT CXWnd::GetLeft() {
	/*DEBUG*/XASSERT(::IsWindow(_m_hWnd));
	
	return _m_iLeft;
}
//---------------------------------------------------------------------------
INT CXWnd::GetTop() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_iTop;
}
//---------------------------------------------------------------------------
VOID CXWnd::SetSize(INT Width, INT Height) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	_m_iWidth  = Width;
	_m_iHeight = Height;
	
	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, 0, 0, Width, Height, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	} 
}
//---------------------------------------------------------------------------
VOID CXWnd::SetPosition(INT Left, INT Top) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	_m_iLeft = Left;
	_m_iTop  = Top;

	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, Left, Top, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	} 
}
//---------------------------------------------------------------------------
VOID CXWnd::Align(HWND hParent, HWND hChild) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	RECT rect = {0};	
		
	::GetClientRect(hParent, &rect);
	::MoveWindow(hChild, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
}
//---------------------------------------------------------------------------
VOID CXWnd::SetRect(RECT Rect) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	_m_iWidth  = Rect.right  - Rect.left;
	_m_iHeight = Rect.bottom - Rect.top;
	_m_iLeft   = Rect.left;
	_m_iTop    = Rect.top;

	if (NULL != _m_hWnd) {
		::SetWindowPos(_m_hWnd, 0, _m_iLeft, _m_iTop, _m_iWidth, _m_iHeight, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
 	} 
}
//---------------------------------------------------------------------------
RECT CXWnd::GetRect() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	RECT rect = {0};
	::GetWindowRect(_m_hWnd, &rect);

	return rect;
}
//---------------------------------------------------------------------------
BOOL CXWnd::Destroy() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::DestroyWindow(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Enable(BOOL Enabled) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::EnableWindow(_m_hWnd, Enabled);
}
//---------------------------------------------------------------------------
HMENU CXWnd::GetMenu() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_hMenu;
}
//---------------------------------------------------------------------------
VOID CXWnd::SetMenu(HMENU Value) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	_m_hMenu = Value;
}
//---------------------------------------------------------------------------
HWND CXWnd::SetFocus() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::SetFocus(_m_hWnd);
}
//---------------------------------------------------------------------------
VOID CXWnd::SetRedraw(BOOL Redraw) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	::SendMessage(_m_hWnd, WM_SETREDRAW, Redraw, 0);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(BOOL Erase) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::InvalidateRect(_m_hWnd, NULL, Erase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(LPRECT Rect, BOOL Erase) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::InvalidateRect(_m_hWnd, Rect, Erase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::ValidateRect(_m_hWnd, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate(LPRECT Rect) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::ValidateRect(_m_hWnd, Rect);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Show(INT iCmdShow) {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::ShowWindow(_m_hWnd, iCmdShow);
}
//---------------------------------------------------------------------------
BOOL CXWnd::IsVisible() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return ::IsWindowVisible(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::bIsWindow() {
	/*DEBUG*///XASSERT(::IsWindow(_m_hWnd));
	
	return _m_hWnd && ::IsWindow(_m_hWnd);
	////return ::IsWindow(_m_hWnd);
}
//---------------------------------------------------------------------------