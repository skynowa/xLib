/**********************************************************************
*	����� CXImageList (CXImageList.cpp)
*
***********************************************************************/


#include <Xlib/CXWinControls/CXImageList.h>
//---------------------------------------------------------------------------
CXImageList::CXImageList(HIMAGELIST hImageList = NULL) : m_hImageList(hImageList) { 
	//
}
//---------------------------------------------------------------------------
CXImageList& CXImageList::operator = (HIMAGELIST hImageList) {
	m_hImageList = hImageList;
	
	return *this;
}
//---------------------------------------------------------------------------
CXImageList::operator HIMAGELIST() const { 
	return m_hImageList;
}
//---------------------------------------------------------------------------
void CXImageList::Attach(HIMAGELIST hImageList) {
	assert(NULL == m_hImageList);
	assert(NULL != hImageList);
	
	m_hImageList = hImageList;
}
//---------------------------------------------------------------------------
HIMAGELIST CXImageList::Detach() {
	HIMAGELIST hImageList = m_hImageList;
	m_hImageList = NULL;
	
	return hImageList;
}
//---------------------------------------------------------------------------
bool CXImageList::IsNull() const { 
	return (NULL == m_hImageList); 
}
//---------------------------------------------------------------------------
int CXImageList::GetImageCount() const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetImageCount(m_hImageList);
}
//---------------------------------------------------------------------------
COLORREF CXImageList::GetBkColor() const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetBkColor(m_hImageList);
}
//---------------------------------------------------------------------------
COLORREF CXImageList::SetBkColor(COLORREF cr) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetBkColor(m_hImageList, cr);
}
//---------------------------------------------------------------------------
BOOL CXImageList::GetImageInfo(int nImage, IMAGEINFO* pImageInfo) const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetImageInfo(m_hImageList, nImage, pImageInfo);
}
//---------------------------------------------------------------------------
HICON CXImageList::GetIcon(int nIndex, UINT uFlags = ILD_NORMAL) const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetIcon(m_hImageList, nIndex, uFlags);
}
//---------------------------------------------------------------------------
BOOL CXImageList::GetIconSize(int& cx, int& cy) const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetIconSize(m_hImageList, &cx, &cy);
}
//---------------------------------------------------------------------------
BOOL CXImageList::GetIconSize(SIZE& size) const {
	assert(NULL != m_hImageList);
	
	return ImageList_GetIconSize(m_hImageList, (int*)&size.cx, (int*)&size.cy);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetIconSize(int cx, int cy) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetIconSize(m_hImageList, cx, cy);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetIconSize(SIZE size) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetIconSize(m_hImageList, size.cx, size.cy);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetImageCount(UINT uNewCount) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetImageCount(m_hImageList, uNewCount);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetOverlayImage(int nImage, int nOverlay) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetOverlayImage(m_hImageList, nImage, nOverlay);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Create(int cx, int cy, UINT nFlags, int nInitial, int nGrow) {
	assert(NULL == m_hImageList);
	
	m_hImageList = ImageList_Create(cx, cy, nFlags, nInitial, nGrow);
	
	return (NULL != m_hImageList) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
BOOL CXImageList::Create(UINT nBitmapID, int cx, int nGrow, COLORREF crMask) {
	assert(NULL == m_hImageList);
	/* �������� ImageList�a ��� ������, ������������ ����� ������� � TreeView. 
	����������� 3 �������� �� �������� �������� ������� (�������������� ���� 
	������� �� � ������� Bitmap �������� Resource View, ������ ��� ��� ������� 
	������ ������������� ��������������� � ����� BMP �������, � ������ � ������
	������� ������ ���� cx_x_cx (16x16) �����).*/ 
	/*cx     - ������ � ������ �������
	nGrow  - ���-�� ��������
	crMask - ���� ������������*/
	m_hImageList = ImageList_LoadBitmap(GetModuleHandle(NULL)/*g_hInst*/, MAKEINTRESOURCE(nBitmapID), cx, nGrow, crMask);

	return (NULL != m_hImageList) ? TRUE : FALSE; 
}
//---------------------------------------------------------------------------
BOOL CXImageList::CreateFromImage(UINT nBitmapID, int cx, int nGrow, COLORREF crMask, UINT uType, UINT uFlags = LR_DEFAULTCOLOR | LR_DEFAULTSIZE) {
	assert(NULL == m_hImageList);

	m_hImageList = ImageList_LoadImage(GetModuleHandle(NULL)/*g_hInst*/, MAKEINTRESOURCE(nBitmapID), cx, nGrow, crMask, uType, uFlags);

	return (NULL != m_hImageList) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
BOOL CXImageList::Merge(HIMAGELIST hImageList1, int nImage1, HIMAGELIST hImageList2, int nImage2, int dx, int dy) {
	assert(NULL == m_hImageList);
	
	m_hImageList = ImageList_Merge(hImageList1, nImage1, hImageList2, nImage2, dx, dy);
	
	return (NULL != m_hImageList) ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
BOOL CXImageList::Destroy() {
	if (NULL == m_hImageList) {
		return FALSE;
	}
	BOOL bRet = ImageList_Destroy(m_hImageList);
	if (bRet) {
		m_hImageList = NULL;
	}
	
	return bRet;
}
//---------------------------------------------------------------------------
int CXImageList::Add(HBITMAP hBitmap, HBITMAP hBitmapMask = NULL) {
	assert(NULL != m_hImageList);
	
	return ImageList_Add(m_hImageList, hBitmap, hBitmapMask);
}
//---------------------------------------------------------------------------
int CXImageList::Add(HBITMAP hBitmap, COLORREF crMask) {
	assert(NULL != m_hImageList);
	
	return ImageList_AddMasked(m_hImageList, hBitmap, crMask);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Remove(int nImage) {
	assert(NULL != m_hImageList);
	
	return ImageList_Remove(m_hImageList, nImage);
}
//---------------------------------------------------------------------------
BOOL CXImageList::RemoveAll() {
	assert(NULL != m_hImageList);

	return ImageList_RemoveAll(m_hImageList);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Replace(int nImage, HBITMAP hBitmap, HBITMAP hBitmapMask) {
	assert(NULL != m_hImageList);
	
	return ImageList_Replace(m_hImageList, nImage, hBitmap, hBitmapMask);
}
//---------------------------------------------------------------------------
int CXImageList::AddIcon(HICON hIcon) {
	assert(NULL != m_hImageList);
	
	return ImageList_AddIcon(m_hImageList, hIcon);
}
//---------------------------------------------------------------------------
int CXImageList::ReplaceIcon(int nImage, HICON hIcon) {
	assert(NULL != m_hImageList);
	
	return ImageList_ReplaceIcon(m_hImageList, nImage, hIcon);
}
//---------------------------------------------------------------------------
HICON CXImageList::ExtractIcon(int nImage) {
	assert(NULL != m_hImageList);
	
	return ImageList_ExtractIcon(NULL, m_hImageList, nImage);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Draw(HDC hDC, int nImage, int x, int y, UINT nStyle) {
	assert(NULL != m_hImageList);
	assert(NULL != hDC);
	
	return ImageList_Draw(m_hImageList, nImage, hDC, x, y, nStyle);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Draw(HDC hDC, int nImage, POINT pt, UINT nStyle) {
	assert(NULL != m_hImageList);
	assert(NULL != hDC);
	
	return ImageList_Draw(m_hImageList, nImage, hDC, pt.x, pt.y, nStyle);
}
//---------------------------------------------------------------------------
BOOL CXImageList::DrawEx(int nImage, HDC hDC, int x, int y, int dx, int dy, COLORREF rgbBk, COLORREF rgbFg, UINT fStyle) {
	assert(NULL != m_hImageList);
	assert(NULL != hDC);
	
	return ImageList_DrawEx(m_hImageList, nImage, hDC, x, y, dx, dy, rgbBk, rgbFg, fStyle);
}
//---------------------------------------------------------------------------
BOOL CXImageList::DrawEx(int nImage, HDC hDC, RECT& rect, COLORREF rgbBk, COLORREF rgbFg, UINT fStyle) {
	assert(NULL != m_hImageList);
	assert(NULL != hDC);
	
	return ImageList_DrawEx(m_hImageList, nImage, hDC, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, rgbBk, rgbFg, fStyle);
}
//---------------------------------------------------------------------------
BOOL CXImageList::Copy(int nSrc, int nDst, UINT uFlags = ILCF_MOVE) {
	assert(NULL != m_hImageList);
	
	return ImageList_Copy(m_hImageList, nDst, m_hImageList, nSrc, uFlags);
}
//---------------------------------------------------------------------------
#if (_WIN32_WINNT >= 0x0501)
 ////HRESULT CXImageList::WriteEx(DWORD dwFlags, LPSTREAM lpStream) {
	////assert(NULL != m_hImageList);

	////return ImageList_WriteEx(m_hImageList, dwFlags, lpStream);
 ////}
#endif // (_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
BOOL CXImageList::BeginDrag(int nImage, POINT ptHotSpot) {
	assert(NULL != m_hImageList);
	
	return ImageList_BeginDrag(m_hImageList, nImage, ptHotSpot.x, ptHotSpot.y);
}
//---------------------------------------------------------------------------
BOOL CXImageList::BeginDrag(int nImage, int xHotSpot, int yHotSpot) {
	assert(NULL != m_hImageList);
	
	return ImageList_BeginDrag(m_hImageList, nImage, xHotSpot, yHotSpot);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetDragCursorImage(int nDrag, POINT ptHotSpot){
	assert(NULL != m_hImageList);
	
	return ImageList_SetDragCursorImage(m_hImageList, nDrag, ptHotSpot.x, ptHotSpot.y);
}
//---------------------------------------------------------------------------
BOOL CXImageList::SetDragCursorImage(int nDrag, int xHotSpot, int yHotSpot) {
	assert(NULL != m_hImageList);
	
	return ImageList_SetDragCursorImage(m_hImageList, nDrag, xHotSpot, yHotSpot);
}
//---------------------------------------------------------------------------
#if (_WIN32_IE >= 0x0400)
CXImageList CXImageList::Duplicate() const {
	assert(NULL != m_hImageList);
	
	return CXImageList(ImageList_Duplicate(m_hImageList));
}
#endif // (_WIN32_IE >= 0x0400)
//---------------------------------------------------------------------------