/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/xassert.h> 

#include <XLib/CXString.h>
#include <XLib/CXFsoString.h> 
#include <XLib/CXMsgBoxRtfEx.h>
//---------------------------------------------------------------------------
void vAssert(const std::string &csExp, ULONG ulLastError, const std::string &csFile, ULONG ulLine, const std::string &csFunc, const std::string &csComment) {
	//-------------------------------------
	//�������� ���������
	std::string sProgram      = sWinToUnixPath(sMinimizePath(sExePath(), 45), false);
	std::string sFile         = sWinToUnixPath(sMinimizePath(csFile,     45), false);
	std::string sGetLastError = sLastErrorStr(ulLastError);
	std::string sExeName      = sExtractShortFileName(sExePath());

	std::string sFStr = sFormatStr(
				////"%s\n\n"
				////"%s:  %s\n"
				////"%s:  %s\n"
				////"%s:  %i\n"
				////"%s:  %s\n"
				////"%s:  %s\n"
				////"%s:  %s"		/*����� ���� \n �� ����*/
				////"%s:  %s",	
				"{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}"
				"{\\colortbl ;\\red255\\green0\\blue0;}"
				"\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par"
				"\\par"
				"\\b %s\\b0   \\lang1033\\f1         \\cf1\\lang1049\\f0 %s\\par"
				"\\cf0\\b %s\\b0   \\lang1033\\f1                 \\cf1\\lang1049\\f0 %s\\par"
				"\\cf0\\b %s\\b0   \\lang1033\\f1                \\cf1\\lang1049\\f0 %i\\cf0\\par"
				"\\b %s\\b0  \\lang1033\\f1        \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0   \\lang1033\\f1      \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0\\lang1033\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par"
				"\\b %s\\b0  \\lang1033\\f1         \\cf1 %s\\cf0\\lang1049\\f0\\par}",			 

				"Assertion failed.",
				"Program:",           sProgram.c_str(),
				"File:",              sFile.c_str(),
				"Line:",              ulLine,
				"Function:",          csFunc.c_str(),
				"Expression:",        csExp.c_str(),
				"GetLastError():",    sGetLastError.c_str(),
				"Comment:",           csComment.c_str() 
	);

	//-------------------------------------
	//������� MessageBox
	//INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	INT iRes = NMsgBoxRtf::iShow(NULL, sFStr, sExeName);
	switch (iRes) {
		case NMsgBoxRtf::mrAbort: {
	    	exit(- 1);
			break;
		}
		case NMsgBoxRtf::mrRetry: {
			////_asm {int 3} 
			_CrtDbgBreak();
			break;
		}
		case NMsgBoxRtf::mrIgnore: {
			break;
		}
	}
}
//---------------------------------------------------------------------------