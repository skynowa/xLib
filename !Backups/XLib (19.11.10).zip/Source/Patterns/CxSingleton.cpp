/****************************************************************************
* Class name:  CxSingleton
* Description: ���������
* File name:   CxSingleton.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.06.2010 11:17:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/





/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - Instance ()
/*static*/ 
template <class T>
CxSingleton<T> &CxSingleton<T>::Instance() {
	static CxSingleton theSingleInstance;

	return theSingleInstance;
}

template <class T>
T &Singleton<T>::Instance()
{
	Create();
	T *p;
	if (!Locked() && (p = Obj().p))
		return *p;
	throw E_AccessViolation("Uutl::Singleton<T>::Instance");
}

//---------------------------------------------------------------------------


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxSingleton (comment)
template <class T>
CxSingleton<T>::CxSingleton() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CxSingleton (comment)
////CxSingleton::~CxSingleton() {
////	//code
////}
//---------------------------------------------------------------------------