/****************************************************************************
* Class name:  CxThread
* Description: �����
* File name:   CxThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CxThread.h>

#include <XLib/CxSystemInfo.h>
#include <XLib/CxString.h>

#ifndef _MT
#	define _MT
#endif 

#if defined(_MT) || defined(_DLL)
#	include <process.h>
#endif 


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxThread (�����������)
CxThread::CxThread(BOOL bIsPaused, BOOL bIsAutoDelete) :
	_m_bRes                 (FALSE),
	
	//���������
	_m_culStillActiveTimeout(2),	
	_m_culExitTimeout       (5000),   

	//������ ������
	_m_hThread              (),
	_m_ulID					(0),
	_m_uiExitCode			(0),
	_m_pvParam				(NULL),
	_m_fpFuncPtr			(0),
	_m_cbIsAutoDelete		(bIsAutoDelete),

	//����� ��������� ������
	_m_bIsCreated			(FALSE),
	_m_bIsRunning			(FALSE),
	_m_bIsPaused			(bIsPaused/*TRUE == bIsPaused ? CREATE_SUSPENDED : 0*/),
	/*_m_bIsSleeping*/// n/a
	/*_m_bIsExited*///   n/a

	//
	///_vOnExit                (NULL),

	//���������     
	_m_clLog                (FALSE),
	_m_pevStarter			(NULL),

	m_ulTag                 (0)
{
	////this->hMainThread	= ::GetCurrentThread();
	////this->hMainThreadId = ::GetCurrentThreadId();   
}
//---------------------------------------------------------------------------
//TODO: + ~CxThread (����������)
/*virtual*/ 
CxThread::~CxThread() {
	/*DEBUG*/

    //-------------------------------------
	//��������� �����, ���� �� �������� - ??? typa na vsykiy sluchay???
	_m_bRes = bIsRunning();
	if (TRUE == _m_bRes) {
		_m_bRes = bExit(_m_culExitTimeout);   
		if (FALSE == _m_bRes) {
            _m_bRes = bKill(_m_culExitTimeout);
		}
	}

	//-------------------------------------
	//����� ��������� ������
	_vSetStatesDefault();
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bCreate (������ ������)
BOOL 
CxThread::bCreate(UINT uiStackSize, const TFuncPtr fpFuncPtr, VOID *pvParam) {
	/*DEBUG*/xASSERT_RET(FALSE == _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///uiStackSize  - n/a
	/*DEBUG*///ptfStartAddr - n/a
	/*DEBUG*///pvParam      - n/a

	HANDLE hRes = NULL;

	_m_fpFuncPtr = fpFuncPtr;
	_m_pvParam   = pvParam; 

	//-------------------------------------
	//_m_evStarter
	_m_pevStarter = new CxEvent();
	/*DEBUG*/xASSERT_RET(NULL != _m_pevStarter, FALSE);

	_m_bRes = _m_pevStarter->bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

#ifdef _MT              
	hRes = reinterpret_cast<HANDLE>(_beginthreadex(NULL, uiStackSize, _s_uiStartFunc, this, 0, xreinterpret_cast<UINT *>(&_m_ulID)));
#else
	hRes = ::CreateThread(NULL, uiStackSize, xreinterpret_cast<LPTHREAD_START_ROUTINE>(_s_uiStartFunc), this, 0, &_m_ulID);
#endif 

	//-------------------------------------
	//WatchDog
	/*WatchDog*/ULONG ulLastError = ::GetLastError();
	/*WatchDog*/xCHECK_DO(8 == ulLastError, iMsgBox(CxString::sLastErrorStr(ulLastError), xT("WatchDog"), MB_OK); return FALSE);


	/*DEBUG*/xASSERT_RET(NULL != hRes,    FALSE);
	/*DEBUG*/xASSERT_RET(0    <  _m_ulID, FALSE);

	_m_hThread.m_hHandle = hRes;
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);    

	//-------------------------------------
	//_m_evPause
	_m_bRes = _m_evPause.bCreate(NULL, TRUE/*-FALSE*/, TRUE/*FALSE*/, NULL);      //_m_bIsPaused
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	_m_bRes = _m_evExit.bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	_m_bIsCreated = TRUE;
	_m_bIsRunning = TRUE;
	/*_m_bIsPaused*///    n/a
	if (TRUE == _m_bIsPaused) {	
		//��������� ����� ����� - "�����"  
		_m_bRes = _m_evPause.bSet();	 
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	}
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a	

	//-------------------------------------
	//������� ����� ����� �������������
	_m_bRes = _m_pevStarter->bSet();  
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bResume (�������������)
BOOL 
CxThread::bResume() {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);    

	_m_bRes = _m_evPause.bSet();  
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPause (�����)
BOOL 
CxThread::bPause() {
	/*DEBUG*/xASSERT_MSG_RET(FALSE != _m_hThread.bIsValid(), CxString::lexical_cast(_m_hThread.m_hHandle).c_str(), FALSE); 

	_m_bRes = _m_evPause.bReset();	 
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExit (����� �� ������ - ��������� ����� ������ �� ������)
BOOL 
CxThread::bExit(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - n/a

	_m_bRes = _m_evExit.bSet();	 
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsExited*///   n/a					
	/*_m_bIsCreated*///  n/a	
	/*_m_bIsRunning*///  n/a
	/*_m_bIsPaused*/	xCHECK_DO(TRUE == bIsPaused(),   bResume()       );	//���� ����� ���������������� (bPause) - ������������
	/*_m_bIsSleeping*/	xCHECK_DO(TRUE == bIsSleeping(), bSleeperWakeUp());	//���� ����� ����             (bSleep) - �����
																			//���� ������� ����-�� 
	//-------------------------------------
	//TODO: - �������� ������ ����
	//--bRes = bWait(ulTimeout);
	//--/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bKill (����������� ������)
BOOL 
CxThread::bKill(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);        
	/*DEBUG*///ulTimeout - n/a

	ULONG ulRes = 0;

	_m_uiExitCode = 0;
	_m_bRes = ::TerminateThread(_m_hThread.m_hHandle, _m_uiExitCode);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	for (;;) {
		ulRes = ulGetExitCode();
		xCHECK_DO(STILL_ACTIVE != ulRes, break);            

		_m_bRes = bSleep(_m_culStillActiveTimeout);
		/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, break);
	}

	//-------------------------------------
	//TODO: - �������� ������ ����
	//--bRes = bWait(ulTimeout);  
	//--/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//������ ��������
	_m_bRes = _m_hThread.bClose();
	/*DEBUG*/xASSERT(FALSE != _m_bRes);

	_m_ulID       = 0;
	_m_uiExitCode = ulRes;	//���������� ��������
	_m_fpFuncPtr  = 0;
	_m_pvParam    = NULL;
	//_m_bIsAutoDelete - n/a 

	//-------------------------------------
	//����� ��������� ������
	_vSetStatesDefault();

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait (�������� ������)
BOOL 
CxThread::bWait(ULONG ulTimeout) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - n/a

	//-------------------------------------
	//����� ��������� ������
	//?????????

	/*DEBUG*/xASSERT(CxThread::ulGetCurrId() != _m_ulID);		//TODO: ?????
	xCHECK_RET(CxThread::ulGetCurrId() == _m_ulID, TRUE);		//TODO: ?????

	ULONG ulRes = WAIT_FAILED;
	ulRes = ::WaitForSingleObject(_m_hThread.m_hHandle, ulTimeout); 
	/*DEBUG*/xASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ����� ��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsCreated (������ �� �����)
BOOL 
CxThread::bIsCreated() const {
	/*DEBUG*/// _m_hThread - n/a

	return _m_bIsCreated && (FALSE != _m_hThread.bIsValid());
}
//---------------------------------------------------------------------------
//TODO: + bIsRunning (�������� ���������� ������)
BOOL 
CxThread::bIsRunning() const {
	/*DEBUG*/// _m_hThread - n/a

	ULONG ulRes = 0;
	::GetExitCodeThread(_m_hThread.m_hHandle, &ulRes);
	/*DEBUG*/// n/a

	BOOL bCond1 = ( FALSE         != _m_hThread.bIsValid()                          );		
	BOOL bCond2 = ( 0L            <  _m_ulID                                        );
	BOOL bCond3 = ( TRUE          == _m_bIsRunning                                  );
	BOOL bCond4 = ( WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread.m_hHandle, 0) ); 
	BOOL bCond5 = ( STILL_ACTIVE  == ulRes                                          );
	
	_m_bRes = bCond1 && bCond2 && bCond3 && bCond4 && bCond5;

	return _m_bRes;
}
//---------------------------------------------------------------------------
//TODO: + bIsPaused (������������� �� �����)
BOOL 
CxThread::bIsPaused() const {
	/*DEBUG*/// _m_hThread - n/a

	return !_m_evPause.bIsSignaled() && (FALSE != _m_hThread.bIsValid());
}
//---------------------------------------------------------------------------
//TODO: + bIsSleeping (���� �� �����)
BOOL 
CxThread::bIsSleeping() const {
	/*DEBUG*/// _m_hThread - n/a

	return _m_slSleeper.bIsSleeping() && (FALSE != _m_hThread.bIsValid());
}
//---------------------------------------------------------------------------
//TODO: + bIsExited (��������� �� ���� ������ ��� ������)
BOOL 
CxThread::bIsExited() const {
	/*DEBUG*/// _m_hThread - n/a

	return _m_evExit.bIsSignaled() && (FALSE != _m_hThread.bIsValid());
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bPostMessage (������� ��������� �� ������ � ����)
BOOL 
CxThread::bPostMessage(HWND hHwnd, UINT uiMsg, UINT uiParam1, LONG liParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);		
	/*DEBUG*/xASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	_m_bRes = ::PostMessage(hHwnd, uiMsg, static_cast<WPARAM>(uiParam1), static_cast<LPARAM>(liParam2));
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSendMessage (������� ��������� �� ������ � ����)
BOOL 
CxThread::bSendMessage(HWND hHwnd, UINT uiMsg, UINT uiParam1, LONG liParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	::SendMessage(hHwnd, uiMsg, static_cast<WPARAM>(uiParam1), static_cast<LPARAM>(liParam2));
	/*DEBUG*/// n/a 
	/*DEBUG*/xASSERT_RET(0 == ::GetLastError(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPostThreadMessage (������� ��������� � �����)
BOOL 
CxThread::bPostThreadMessage(UINT uiMsg, UINT uiParam1, LONG liParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	_m_bRes = ::PostThreadMessage(ulGetId(), uiMsg, static_cast<WPARAM>(uiParam1), static_cast<LPARAM>(liParam2));
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bTryPostThreadMessage (������� ��������� � �����)
BOOL 
CxThread::bTryPostThreadMessage(UINT uiMsg, UINT uiParam1, LONG liParam2, ULONG ulAttemps, ULONG ulAttempTimeout) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

    for (ULONG i = 0; i < ulAttemps; ++ i) {
		_m_bRes = ::PostThreadMessage(ulGetId(), uiMsg, static_cast<WPARAM>(uiParam1), static_cast<LPARAM>(liParam2));
		
		xCHECK_RET(TRUE  == _m_bRes, TRUE);
		xCHECK_DO (FALSE == _m_bRes, ::Sleep(ulAttempTimeout));
    }

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue (�������� ��������� c ����������� �� ������� ������)
BOOL 
CxThread::bMessageWaitQueue(UINT uiMsg, UINT *puiParam1, LONG *pliParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/xASSERT_RET(0     <  uiMsg,                 FALSE);

	std::vector<UINT> vecuiMsg;
	vecuiMsg.push_back(uiMsg);

	_m_bRes = bMessageWaitQueue(vecuiMsg, NULL, puiParam1, pliParam2);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue (�������� ��������� c ����������� �� ������� ������)
BOOL 
CxThread::bMessageWaitQueue(const std::vector<UINT> &cvecuiMsg, UINT *puiMsg, UINT *puiParam1, LONG *pliParam2) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/xASSERT_RET(false == cvecuiMsg.empty(),     FALSE);

	MSG msgMsg = {0};

	while (_m_bRes = ::GetMessage(&msgMsg, NULL, 0, 0 )) {     
		/*DEBUG*/xASSERT_RET(- 1 != _m_bRes, FALSE);

		for (size_t i = 0; i < cvecuiMsg.size(); ++ i) {
			if (cvecuiMsg.at(i) == msgMsg.message) {

				xCHECK_DO(NULL != puiMsg,    *puiMsg    = msgMsg.message                  );
				xCHECK_DO(NULL != puiParam1, *puiParam1 = static_cast<UINT>(msgMsg.wParam));
				xCHECK_DO(NULL != pliParam2, *pliParam2 = static_cast<LONG>(msgMsg.lParam));
				
				return TRUE;
			}
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetPriority (��������� ���������� ������)
BOOL 
CxThread::bSetPriority(EPriority tpPriority) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	_m_bRes = ::SetThreadPriority(_m_hThread.m_hHandle, tpPriority);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iGetPriority (��������� ���������� ������)
CxThread::EPriority 
CxThread::tpGetPriority() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), tpPRIORITY_ERROR); 

	CxThread::EPriority tpRes = tpPRIORITY_ERROR;

	tpRes = static_cast<EPriority>(::GetThreadPriority(_m_hThread.m_hHandle));
	/*DEBUG*/xASSERT_RET(tpPRIORITY_ERROR != tpRes, tpPRIORITY_ERROR);

	return tpRes;
}
//---------------------------------------------------------------------------
//TODO: + sGetPriorityString (��������� ���������� ������ ��� ������)
tString 
CxThread::sGetPriorityString() const {
	/*DEBUG*/// n/a

	switch ( tpGetPriority() ) {
		case tpPRIORITY_IDLE:			return xT("Idle");
		case tpPRIORITY_LOWEST:			return xT("Lowest");
		case tpPRIORITY_BELOW_NORMAL:	return xT("Below normal");
		case tpPRIORITY_NORMAL:			return xT("Normal");
		case tpPRIORITY_ABOVE_NORMAL:	return xT("Above normal");
		case tpPRIORITY_HIGHEST:		return xT("Highest");
		case tpPRIORITY_TIME_CRITICAL:	return xT("Time critical");
	}

	return xT("N/A");
}
//---------------------------------------------------------------------------
//TODO: + bPriorityUp (��������� ���������� �� ���� �������)
BOOL 
CxThread::bPriorityUp() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = tpPRIORITY_ERROR;
	EPriority tpiNewLevel = tpPRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case tpPRIORITY_IDLE: 			tpiNewLevel = tpPRIORITY_LOWEST;		break;
		case tpPRIORITY_LOWEST: 		tpiNewLevel = tpPRIORITY_BELOW_NORMAL;	break;
		case tpPRIORITY_BELOW_NORMAL: 	tpiNewLevel = tpPRIORITY_NORMAL;		break;
		case tpPRIORITY_NORMAL: 		tpiNewLevel = tpPRIORITY_ABOVE_NORMAL;	break;
		case tpPRIORITY_ABOVE_NORMAL: 	tpiNewLevel = tpPRIORITY_HIGHEST;		break;
		case tpPRIORITY_HIGHEST: 		tpiNewLevel = tpPRIORITY_TIME_CRITICAL;	break;
		case tpPRIORITY_TIME_CRITICAL:	return TRUE;							break;

		default:			/*xASSERT*/xASSERT_RET(FALSE, tpPRIORITY_NORMAL);	break;
	}

	return bSetPriority(tpiNewLevel);
} 
//---------------------------------------------------------------------------
//TODO: + bPriorityDown (��������� ���������� �� ���� �������)
BOOL 
CxThread::bPriorityDown() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = tpPRIORITY_ERROR;
	EPriority tpiNewLevel = tpPRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case tpPRIORITY_IDLE: 			return TRUE;							break;
		case tpPRIORITY_LOWEST: 		tpiNewLevel = tpPRIORITY_IDLE;			break;
		case tpPRIORITY_BELOW_NORMAL: 	tpiNewLevel = tpPRIORITY_LOWEST;		break;
		case tpPRIORITY_NORMAL: 		tpiNewLevel = tpPRIORITY_BELOW_NORMAL;	break;
		case tpPRIORITY_ABOVE_NORMAL: 	tpiNewLevel = tpPRIORITY_NORMAL;		break;
		case tpPRIORITY_HIGHEST: 		tpiNewLevel = tpPRIORITY_ABOVE_NORMAL;	break;
		case tpPRIORITY_TIME_CRITICAL:	tpiNewLevel = tpPRIORITY_HIGHEST;		break;

		default:			/*xASSERT*/xASSERT_RET(FALSE, tpPRIORITY_NORMAL);	break;
	}

	return bSetPriority(tpiNewLevel);
}
//---------------------------------------------------------------------------
//TODO: + bIsPriorityBoost (Retrieves the priority boost control state of the specified thread)
BOOL 
CxThread::bIsPriorityBoost() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bDisablePriorityBoost = TRUE;

	_m_bRes = ::GetThreadPriorityBoost(_m_hThread.m_hHandle, &bDisablePriorityBoost);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	//bDisablePriorityBoost == TRUE  - dynamic boosting is disabled
	//bDisablePriorityBoost == FALSE - normal behavior

	return ! bDisablePriorityBoost;
}
//---------------------------------------------------------------------------
//TODO: + bSetPriorityBoost (Disables or enables the ability of the system to temporarily boost the priority of a thread)
BOOL 
CxThread::bSetPriorityBoost(BOOL bIsEnabled) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	_m_bRes = ::SetThreadPriorityBoost(_m_hThread.m_hHandle, ! bIsEnabled);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: CPU
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetAffinityMask (Sets a processor affinity mask for the specified thread)
BOOL 
CxThread::bSetAffinityMask(DWORD_PTR pulMask) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	DWORD_PTR pulRes = 0;

	pulRes = ::SetThreadAffinityMask(_m_hThread.m_hHandle, pulMask);	//ERROR_INVALID_PARAMETER	
	/*DEBUG*/xASSERT_RET(0 != pulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetIdealProcessor (Sets a preferred processor for a thread, ulIdealProcessor - this value is zero-based)
BOOL 
CxThread::bSetIdealCPU(ULONG ulIdealCPU) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, ulIdealCPU);
	/*DEBUG*/xASSERT_RET((ULONG) - 1 != ulRes, FALSE); 
	
	//TODO: - xASSERT_RET
	///*DEBUG*/xASSERT_RET(ulIdealCPU != ulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ulGetIdealProcessor (current ideal processor without changing it)
ULONG 
CxThread::ulGetIdealCPU() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, MAXIMUM_PROCESSORS);
	/*DEBUG*/xASSERT_RET((ULONG) - 1 != ulRes, FALSE); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCPUCount (���-�� ����������� �� �����)
ULONG 
CxThread::ulGetCPUCount() const {
	/*DEBUG*///_m_hThread - n/a 

	ULONG ulRes = 0;

	ulRes = CxSystemInfo::ulGetNumOfCPUs();
	xCHECK_RET(ulRes < 1 || ulRes > 32, 1);

	return ulRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetHandle (����� ������)
HANDLE 
CxThread::hGetHandle() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), NULL); 

	return _m_hThread.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + ulGetId (ID ������)
ULONG 
CxThread::ulGetId() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	return _m_ulID;
}
//---------------------------------------------------------------------------
//TODO: + bGetExitCode (Retrieves the termination status of the specified thread)
ULONG 
CxThread::ulGetExitCode() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = 0;	

	_m_bRes = ::GetExitCodeThread(_m_hThread.m_hHandle, &ulRes);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, ulRes);

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetDebugName (Name your threads in the VC debugger thread list)
BOOL 
CxThread::bSetDebugName(const tString &csName) const {
    /*DEBUG*/

	//convert to Ansi
	std::string asName(csName.begin(), csName.end());

	_m_bRes = _bSetDebugNameA(asName);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: static
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hOpen (Opens an existing thread object.)
/*static*/ 
HANDLE 
CxThread::hOpen(ULONG ulAccess, BOOL bInheritHandle, ULONG ulId) {
	/*DEBUG*///ulAccess       - n/a 
	/*DEBUG*///bInheritHandle - n/a
	/*DEBUG*/xASSERT_RET(0 < ulId, NULL); 

	HANDLE hRes = NULL;

	hRes = ::OpenThread(ulAccess, bInheritHandle, ulId);
	/*DEBUG*/xASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCurrId (Retrieves the thread identifier of the calling thread.)
/*static*/ 
ULONG 
CxThread::ulGetCurrId() {
	/*DEBUG*/// n/a 

	ULONG ulRes = 0;

	ulRes = ::GetCurrentThreadId();
	/*DEBUG*/xASSERT_RET(0 < ulRes, 0); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + hGetCurrHandle (Retrieves a pseudo handle for the calling thread)
/*static*/ 
HANDLE 
CxThread::hGetCurrHandle() {
	/*DEBUG*/// n/a 

	HANDLE hRes = NULL;

	hRes = ::GetCurrentThread();
	/*DEBUG*/xASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnEnter ()
VOID 
CxThread::vAttachHandler_OnEnter(SClosureT<VOID(CxThread *pthSender)> vCallback) {
	_m_vCallback_OnEnter = vCallback;
	//_m_bFlag_OnEnter  = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnEnter ()
////VOID vDetachHandler_OnEnter(CxThread *pthSender) {
////	//_m_bFlag_OnEnter         = FALSE;
////	_m_Callback_OnEnter.p_this = NULL;
////}
//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnExit ()
VOID 
CxThread::vAttachHandler_OnExit(SClosureT<VOID(CxThread *pthSender)> vCallback) {
	_m_vCallback_OnExit = vCallback;
	//_m_bFlag_OnExit    = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnExit ()
////VOID vDetachHandler_OnExit(CxThread *pthSender) {
////	//_m_bFlag_OnExit         = FALSE;
////	_m_Callback_OnExit.p_this = NULL;
////}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected
*
*****************************************************************************/

/****************************************************************************
*	protected: �������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + uiOnRun (������� ������)	//must override this
/*virtual*/ 
UINT 
CxThread::uiOnRun(VOID *pvParam) /* = 0*/ {
	/*DEBUG*/// n/a
	/*DEBUG*/xASSERT_RET(FALSE, 0);

	/*UINT uiRes = 0;

	for (;;) {
		//-------------------------------------
		//�� ���� �� ����� ��� ���������������
		bRes = bIsTimeToExit();
		xCHECK_DO(TRUE == bRes, break);

		//...
	}	

	return uiRes;*/

	return 0;
}
//---------------------------------------------------------------------------
//TODO: + vOnEnter (������� �� ��������������� ������)	//must override this
/*virtual*/ 
//--VOID 
//--CxThread::vOnEnter() {
//--	/*DEBUG*/// n/a
//--	/*DEBUG*/xASSERT_DO(FALSE, return);
//--
//--	return;
//--}
//---------------------------------------------------------------------------
//TODO: + vOnExit (������� �� ���������� ������)	//must override this
/*virtual*/ 
//--VOID 
//--CxThread::vOnExit() {
//--	/*DEBUG*/// n/a
//--	/*DEBUG*/xASSERT_DO(FALSE, return);
//--
//--	return;
//--}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected: ���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bYield (�������� ������� ������� ������, ������� ����� � ���������� �� !������� ����������!)
BOOL 
CxThread::bYield() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	::SwitchToThread();
	/*DEBUG*/// n/a

	//-------------------------------------
	//����� ��������� ������
	//n/a

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleep (Suspends the execution of the current thread until the time-out interval elapses)
BOOL 
CxThread::bSleep(ULONG ulTimeout) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - n/a

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	_m_bRes = _m_slSleeper.bSleep(ulTimeout);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleeperWakeUp (���������� ������� bSleep - ����� �� ������� ���������)
BOOL 
CxThread::bSleeperWakeUp() {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	_m_bRes = _m_slSleeper.bWakeUp();
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsTimeToExit (���� �� �������� �� ������)
BOOL 
CxThread::bIsTimeToExit() {   
	/*DEBUG*/// n/a

	//-------------------------------------
	//�����
	///bSleep(1);

	_m_bRes = bIsExited();
	xCHECK_RET(FALSE != _m_bRes, TRUE);

	//-------------------------------------
	//����� / �������������
	///bSleep(1);

	_m_bRes = bIsPaused();
	xCHECK_RET(FALSE != _m_bRes, !_bWaitResumption());

	//-------------------------------------
	//����� ��������� ������
	// n/a

	return FALSE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_uiStartFunc (����������� ������� ������)
/*static*/
UINT WINAPI 
CxThread::_s_uiStartFunc(VOID *pvParam) {
	/*DEBUG*/xASSERT_RET(NULL != pvParam, 0);

	UINT uiRes = 0;
	BOOL bRes  = FALSE;

	CxThread *pthThis = static_cast<CxThread *>(pvParam); 
	/*DEBUG*/xASSERT_RET(NULL != pthThis, 0);

	//-------------------------------------
	//���� ���� ����� ��� ��������
	//::Sleep(5);
	bRes = pthThis->_m_pevStarter->bWait(/*+INFINITE*/10000);  
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	xDELETE_PTR(pthThis->_m_pevStarter);

	/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 

	//-------------------------------------
	//������ �� ���������������� �����?
	xCHECK_DO(TRUE == pthThis->bIsPaused(), pthThis->_bWaitResumption());

	{
		//-------------------------------------
		//������ ������� ������
		try {
			//--pthThis->vOnEnter();
			pthThis->_vHandler_OnEnter(pthThis);
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	
		//-------------------------------------
		//���������� ������� ������
		try {
			if (0 == pthThis->_m_fpFuncPtr) {
				uiRes = pthThis->uiOnRun(pthThis->_m_pvParam);
			} else {
				uiRes = pthThis->_m_fpFuncPtr(pthThis->_m_pvParam);
			}
		} catch (std::exception e) {
			std::string asWhat = e.what();	
			xASSERT_MSG(FALSE, xS2TS(asWhat).c_str());	
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	
		//-------------------------------------
		//��������� ������� ������
		try {
			//--pthThis->vOnExit();
			pthThis->_vHandler_OnExit(pthThis);
		} catch (...) {
			/*DEBUG*/xASSERT(FALSE);
		}
		/*DEBUG*/xASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	}

	//-------------------------------------
	//������ �������� (���� �� ���������???)												
	bRes = pthThis->_m_hThread.bClose();
	/*DEBUG*/xASSERT(FALSE != bRes);

	pthThis->_m_ulID       = 0;
	pthThis->_m_uiExitCode = uiRes;	//???
	pthThis->_m_fpFuncPtr  = 0;
	pthThis->_m_pvParam    = NULL;
	//pthThis->_m_bIsAutoDelete - n/a

	//-------------------------------------
	//����� ��������� ������
	pthThis->_vSetStatesDefault();

	//-------------------------------------
	//��������������� ������
	xCHECK_DO(TRUE == pthThis->_m_cbIsAutoDelete, xDELETE_PTR(pthThis));

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: + _bWaitForResume (���� ������ �����)
BOOL 
CxThread::_bWaitResumption() {
	/*DEBUG*/

	ULONG ulRes = 0;

	//-------------------------------------
	//����� ��������� ������
	/*_m_bIsCreated*///   n/a
	/*_m_bIsRunning*///   n/a
	/*_m_bIsPaused*///    n/a
	/*_m_bIsSleeping*///  n/a
	/*_m_bIsExited*///    n/a

	ulRes = ::WaitForSingleObject(_m_evPause.hGetHandle(), INFINITE); 
	/*DEBUG*///- n/a

	return TRUE;

	/*
	//a mechanism for terminating thread should be implemented
	//not allowing the method to be run from the main thread
	if (::GetCurrentThreadId () == this->hMainThreadId) {
		return 0;
	} else {
		::MessageBoxW (0, xT("I'm running in a different thread!"), xT("CMyThread"), MB_OK);

		return 0;
	}
	*/
}
//---------------------------------------------------------------------------
//TODO: + _vSetStatesDefault ()
VOID 
CxThread::_vSetStatesDefault() {
	/*DEBUG*/// n/a 

	//-------------------------------------
	//����� ��������� ������
	_m_bIsCreated  = FALSE;
	_m_bIsRunning  = FALSE;
	/*_m_bIsPaused*///   n/a
	/*_m_bIsSleeping*/// n/a
	/*_m_bIsExited*///   n/a
}
//---------------------------------------------------------------------------
//TODO: + _bSetDebugNameA (Name your threads in the VC debugger thread list)
BOOL 
CxThread::_bSetDebugNameA(const std::string &csName) const {
	/*DEBUG*/xASSERT_RET(0    <  _m_ulID,       FALSE); 
	/*DEBUG*/xASSERT_RET(32   >  csName.size(), FALSE); //MAX_NAME_SIZE 32

	typedef struct tagTHREADNAME_INFO {
		DWORD  dwType;     //must be 0x1000
		LPCSTR szName;     //pointer to name (in user addr space)
		DWORD  dwThreadID; //thread ID (-1=caller thread)
		DWORD  dwFlags;    //reserved for future use, must be zero
	} THREADNAME_INFO;

	THREADNAME_INFO tiInfo = {0};
	tiInfo.dwType     = 0x1000;
	tiInfo.szName     = csName.c_str();	////cpszName; 
	tiInfo.dwThreadID = ulGetId() /*- 1*/;	//_m_ulID;
	tiInfo.dwFlags    = 0;

	__try {
		::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), xreinterpret_cast<DWORD *>(&tiInfo));
		/*DEBUG*/// n/a
	}
	__except (EXCEPTION_CONTINUE_EXECUTION)	{
		/*DEBUG*/xASSERT_RET(FALSE, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*    callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vHandler_OnEnter ()
VOID 
CxThread::_vHandler_OnEnter(CxThread *pthSender)	{
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnEnter) {
	xCHECK_DO(NULL == _m_vCallback_OnEnter, return); 

	_m_vCallback_OnEnter(pthSender);
}
//---------------------------------------------------------------------------
//TODO: + vHandler_OnExit ()
VOID 
CxThread::_vHandler_OnExit(CxThread *pthSender) {
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnExit) {
	xCHECK_DO(NULL == _m_vCallback_OnExit, return)

	_m_vCallback_OnExit(pthSender);
}
//---------------------------------------------------------------------------