/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ ��������
* File name:   CXLockScope.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/Sync/CxCriticalSection.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxCriticalSection ()
CxCriticalSection::CxCriticalSection() :
	_m_CS()	
{
	::InitializeCriticalSection(&_m_CS);
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + CxCriticalSection ()
#if (_WIN32_WINNT >= 0x0403)
CxCriticalSection::CxCriticalSection(ULONG ulSpinCount) {
	/*DEBUG*///ulSpinCount - not need

	BOOL bRes = FALSE;	
	
	bRes = ::InitializeCriticalSectionAndSpinCount(&_m_CS, ulSpinCount);
	/*DEBUG*/xASSERT_DO(FALSE != bRes, return);
}
#endif
//---------------------------------------------------------------------------
//TODO: + ~CxCriticalSection ()
CxCriticalSection::~CxCriticalSection() {
	::DeleteCriticalSection(&_m_CS);
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + vEnter ()
VOID 
CxCriticalSection::vEnter() {
	::EnterCriticalSection(&_m_CS);
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + vLeave ()
VOID 
CxCriticalSection::vLeave() {
	::LeaveCriticalSection(&_m_CS);
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + ulSetSpinCount ()
#if (_WIN32_WINNT >= 0x0403)
ULONG 
CxCriticalSection::ulSetSpinCount(ULONG ulSpinCount) {
	/*DEBUG*///ulSpinCount - n/a

	return ::SetCriticalSectionSpinCount(&_m_CS, ulSpinCount);
	/*DEBUG*/// n/a
}
#endif
//---------------------------------------------------------------------------
//TODO: + bTryEnter ()
#if(_WIN32_WINNT >= 0x0400)
BOOL 
CxCriticalSection::bTryEnter() {
	return ::TryEnterCriticalSection(&_m_CS);
	/*DEBUG*/// n/a
}
#endif
//---------------------------------------------------------------------------