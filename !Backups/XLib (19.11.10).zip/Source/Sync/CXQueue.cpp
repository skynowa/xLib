/****************************************************************************
* Class name:  CXQueue
* Description: ������ � ��������
* File name:   CXQueue.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXQueue.h>

//---------------------------------------------------------------------------
//TODO: - CXQueue
CXQueue::CXQueue(INT nMaxElements) : 
    _m_hMutex    (_m_hSyncArrary[0]), 
	_m_hSemaphore(_m_hSyncArrary[1])
{
	_m_pElements    = (PELEMENT)::HeapAlloc(::GetProcessHeap(), 0, sizeof(ELEMENT) * nMaxElements);
	_m_nMaxElements = nMaxElements;
	_m_hMutex       = ::CreateMutex    (NULL, FALSE, NULL);
	_m_hSemaphore   = ::CreateSemaphore(NULL, 0, nMaxElements, NULL);
}
//---------------------------------------------------------------------------
//TODO: - ~CXQueue
CXQueue::~CXQueue() {
	::CloseHandle(_m_hSemaphore);
	::CloseHandle(_m_hMutex);
	::HeapFree   (::GetProcessHeap(), 0, _m_pElements);
}
//---------------------------------------------------------------------------
//TODO: - bAppend
BOOL 
CXQueue::bAppend(PELEMENT pElement, ULONG ulTimeout) {
	BOOL  bRes  = FALSE;
	ULONG ulRes = ::WaitForSingleObject(_m_hMutex, ulTimeout);

	if (WAIT_OBJECT_0 == ulRes) {
		//This thread has exclusive access to the queue

		//Increment the number of elements in the queue
		LONG lPrevCount = 0;
		bRes = ::ReleaseSemaphore(_m_hSemaphore, 1, &lPrevCount);
		if (TRUE == bRes) {
			//The queue is not full, append the new element
			_m_pElements[lPrevCount] = *pElement;
		} else {
			//The queue is full, set the error code and return failure
			::SetLastError(ERROR_DATABASE_FULL);
		}

		//Allow other threads to access the queue
		::ReleaseMutex(_m_hMutex);
	} else {
		//Timeout, set error code and return failure
		::SetLastError(ERROR_TIMEOUT);
	}

	return bRes;   //Call GetLastError for more info
}
//---------------------------------------------------------------------------
//TODO: - bRemove
BOOL 
CXQueue::bRemove(PELEMENT pElement, ULONG ulTimeout) {
	//Wait for exclusive access to queue and for queue to have element.
	BOOL bRes = (::WaitForMultipleObjects(chDIMOF(_m_hSyncArrary), _m_hSyncArrary, TRUE, ulTimeout) == WAIT_OBJECT_0);
	if (TRUE == bRes) {
		//The queu has an element, pull it from the queue
		*pElement = _m_pElements[0];

		//Shift the remaining elements down
		::MoveMemory(&_m_pElements[0], &_m_pElements[1], sizeof(ELEMENT) * (_m_nMaxElements - 1));

		//Allow other threads to access the queue
		::ReleaseMutex(_m_hMutex);
	} else {
		//Timeout, set error code and return failure
		::SetLastError(ERROR_TIMEOUT);
	}

	return bRes;   //Call GetLastError for more info
}
//---------------------------------------------------------------------------