/****************************************************************************
* Class name:  CxSocketInit
* Description: initiates use of the Winsock DLL by a process
* File name:   CxSocketInit.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     22.06.2010 10:25:42
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CxSocketInit.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxSocketInit (Init winsock DLL)
CxSocketInit::CxSocketInit(USHORT usMajorVersion, USHORT usMinorVersion) : 
	_m_iRes   (- 1),
	_m_wsaData()
{
#if defined(_WIN32)
	//WSAStartup - [+] returns zero. [-] Otherwise, it returns one of the error codes listed below.
	_m_iRes = ::WSAStartup(MAKEWORD(usMajorVersion, usMinorVersion), &_m_wsaData);      
	/*DEBUG*/xASSERT_DO(0 == _m_iRes, return);

	//-------------------------------------
	//Confirm that the WinSock DLL supports 2.2.
	if (usMinorVersion != HIBYTE(_m_wsaData.wVersion) || usMajorVersion != LOBYTE(_m_wsaData.wVersion)) {
		_m_iRes = ::WSACleanup();
		/*DEBUG*/xASSERT_DO(0 == _m_iRes, return);

		/*DEBUG*/xASSERT_DO(FALSE, return);
	} 
#endif // _WIN32
}
//---------------------------------------------------------------------------
//TODO: - ~CxSocketInit (Clean winsock DLL)
CxSocketInit::~CxSocketInit() {
#if defined(_WIN32)
	//WSACleanup - [+] 0 [-] SOCKET_ERROR
	_m_iRes = ::WSACleanup();
	/*DEBUG*/xASSERT_DO(0 == _m_iRes, return);
#endif // _WIN32
}
//---------------------------------------------------------------------------
