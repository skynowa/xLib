/****************************************************************************
* Class name:  CxSocket
* Description: ����������� �����
* File name:   CxSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/Net/CxSocket.h> 

#include <iostream> 
#include <XLib/CxString.h> 
//---------------------------------------------------------------------------
BOOL CxSocket::_ms_iRes = FALSE; 
//---------------------------------------------------------------------------  
//TODO: + CxSocket
CxSocket::CxSocket() :
	_m_bRes     (FALSE),
	_m_iRes     (etError),
	_m_puiSocket(etInvalid),
	_m_siFamily (afUnspecified), 
	_m_sIp      (),
	_m_usPort   (0),
	_m_tvTimeout()
{   
	_m_bRes = bSetTimeout(0, CxOptions::SOCKET_TIMEOUT);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
} 
//---------------------------------------------------------------------------   
//TODO: + ~CxSocket
CxSocket::~CxSocket() {
	/*DEBUG*/////xASSERT_DO(etInvalid == _m_puiSocket, return);
	
	_m_puiSocket = etInvalid;
}   
//---------------------------------------------------------------------------
//TODO: bAssign
BOOL 
CxSocket::bAssign(SOCKET scktSocket) {
	/*DEBUG*////////////-------xASSERT_DO(etInvalid == _m_puiSocket, FALSE);

	_m_puiSocket = scktSocket; 

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
* operators
*
*****************************************************************************/

//--------------------------------------------------------------------------- 
//TODO: + operator =
CxSocket &
CxSocket::operator = (SOCKET puiSocket) {   
	/*DEBUG*/xASSERT_RET(etInvalid != puiSocket, (*this)); //?????????????7

	_m_puiSocket = puiSocket;  

	return *this;   
}   
//--------------------------------------------------------------------------- 
//TODO: + operator SOCKET
CxSocket::operator SOCKET () {   
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, etInvalid);

	return _m_puiSocket;   
} 
//---------------------------------------------------------------------------


/****************************************************************************
* 
*
*****************************************************************************/
  
//--------------------------------------------------------------------------- 
//TODO: bCreate
BOOL 
CxSocket::bCreate(EAddressFamily afFamily, EType tpType, EProtocol ptProtocol) {
	/*DEBUG*/xASSERT_RET(etInvalid == _m_puiSocket, FALSE);

	//socket - [+] socket returns a descriptor referencing the new socket. [-] INVALID_SOCKET
	_m_puiSocket = ::socket(afFamily, tpType, ptProtocol);   
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, FALSE);

	//-------------------------------------
	//���������� ������
	_m_siFamily = afFamily;

	return TRUE;   
}  
//--------------------------------------------------------------------------- 
//TODO: iGetSocket
SOCKET 
CxSocket::iGetSocket() {
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, etInvalid);

	return _m_puiSocket;  
}
//---------------------------------------------------------------------------
//TODO: - bIsValid ()
BOOL 
CxSocket::bIsValid() const {
	/*DEBUG*/// n/a

	return _m_puiSocket >= 0;
}
//---------------------------------------------------------------------------
//TODO: + bIsReadable
BOOL 
CxSocket::bIsReadable() {   
	timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	fd_set  fds       = {0};  FD_ZERO(&fds);   

	FD_SET(_m_puiSocket, &fds); 

	_m_iRes = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	xCHECK_RET(etError == _m_iRes || 0 == _m_iRes, FALSE);   

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: bIoctl (The ioctlsocket function controls the I/O mode of a socket.)
BOOL 
CxSocket::bIoctl(LONG liCmd, ULONG *pulArgp) {
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, FALSE);

	_m_iRes = ::ioctlsocket(_m_puiSocket, liCmd, pulArgp);
	/*DEBUG*/xASSERT_RET(0 == _m_iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetNonBlockingMode
BOOL 
CxSocket::bSetNonBlockingMode(const BOOL cbFlag) {
#ifdef WIN32	
	ULONG ulNonBlockingMode = static_cast<ULONG>(cbFlag);
	_m_bRes = bIoctl(FIONBIO, static_cast<ULONG FAR *>(&ulNonBlockingMode));
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
#else
	INT opts;

	opts = fcntl(m_sock, F_GETFL);

	xCHECK_RET(opts < 0, FALSE);
		
	if (cbFlag) {
		opts = (opts | O_NONBLOCK);
	} else {
		opts = (opts & ~O_NONBLOCK);
	}

	fcntl(m_sock, F_SETFL, opts);
#endif

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bGetTimeout
BOOL 
CxSocket::bGetTimeout(LONG *pliSec, LONG *pliMicroSec) {
	/*DEBUG*/
	/*DEBUG*/// pliSec      - n/a
	/*DEBUG*/// pliMicroSec - n/a

	xCHECK_DO(NULL != pliSec,      *pliSec      = _m_tvTimeout.tv_sec );
	xCHECK_DO(NULL != pliMicroSec, *pliMicroSec = _m_tvTimeout.tv_usec);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: bSetTimeout
BOOL 
CxSocket::bSetTimeout(LONG liSec, LONG liMicroSec) {
	/*DEBUG*/
	/*DEBUG*/// liSec      - n/a
	/*DEBUG*/// liMicroSec - n/a

	_m_tvTimeout.tv_sec  = liSec;
	_m_tvTimeout.tv_usec = liMicroSec;

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL 
CxSocket::bClose() {		
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, FALSE);

#ifdef WIN32 
	//shutdown - [+] 0. [-] SOCKET_ERROR
	_m_iRes = ::shutdown(_m_puiSocket, SD_BOTH);	 
	/*DEBUG*/xASSERT_RET(0 == _m_iRes, FALSE);

	//closesocket - [+] zero. [-] SOCKET_ERROR
	_m_iRes = ::closesocket(_m_puiSocket); 
	/*DEBUG*/xASSERT_RET(0 == _m_iRes, FALSE);

	_m_puiSocket = etInvalid;

	return TRUE;
#else   
	return ::close(_m_puiSocket);   
#endif   
}  
//---------------------------------------------------------------------------



/****************************************************************************
* I/O
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: iSend
INT 
CxSocket::iSend(LPCTSTR pcszBuff, INT iBuffSize, INT iFlags) { 
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket,        etError);
	/*DEBUG*/xASSERT_RET(NULL      != pcszBuff,            etError);
	/*DEBUG*//////xASSERT_RET(0         <  ::lstrlen(pcszBuff), etError);

#ifdef WIN32
	//send - [+] total number of bytes sent, which can be less than the number requested to be sent in the len parameter. [-] SOCKET_ERROR
	_m_iRes = ::send(_m_puiSocket, (LPCSTR)pcszBuff, iBuffSize * sizeof(TCHAR), iFlags);
	/*DEBUG*/xASSERT_RET(etError                        != _m_iRes && WSAEWOULDBLOCK != iGetLastError(), etError);
	/*DEBUG*/xASSERT_RET(iBuffSize * (INT)sizeof(TCHAR) >= _m_iRes,                                      etError); 
#else
	_m_iRes = ::send(_m_puiSocket, pcszBuff, iBuffSize, MSG_NOSIGNAL);
	/*DEBUG*/
#endif

	return _m_iRes / sizeof(TCHAR);   
}  
//---------------------------------------------------------------------------
//TODO: bSendAll
BOOL 
CxSocket::bSendAll(const tString &csBuff, INT iFlags) { 
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket,   etError);
	/*DEBUG*/xASSERT_RET(false     == csBuff.empty(), etError);
	/*DEBUG*/xASSERT_RET(0         <  csBuff.size(),  etError);

	//-------------------------------------
	//������ �� ������ ������� � ����� � ������
	INT iCurrPos  = 0;
	INT iLeftSize = csBuff.size() * sizeof(TCHAR);			//TODO: !!!!!!  bSendAll (overflow)

	//���� ������ ������ ������ ������� ������ - ������ ������ SOCKET_BUFF_SIZE
	INT iBuffOutSize  = 0;
	if (iLeftSize >= CxOptions::SOCKET_BUFF_SIZE) {
		iBuffOutSize = CxOptions::SOCKET_BUFF_SIZE;
	} else {
		iBuffOutSize = iLeftSize;
	}

	for (;;) {		/*uiLeftSize > 0*/
		_m_iRes = iSend(&csBuff[0] + iCurrPos, iBuffOutSize, iFlags);  
		xCHECK_DO(etError == _m_iRes, break);
		xCHECK_DO(0       == _m_iRes, break);

		iCurrPos  += _m_iRes;
		iLeftSize -= _m_iRes;

		xCHECK_DO(iLeftSize < iBuffOutSize, iBuffOutSize = iLeftSize);

		//���� ����������� ������, �� �������
		if (0 >= iLeftSize) {
			/*DEBUG*/xASSERT_RET(csBuff.size() * sizeof(TCHAR) == iCurrPos, FALSE);
			break;
		}
	} 

	return TRUE;    
} 
//---------------------------------------------------------------------------  
//TODO: + iRecv
INT 
CxSocket::iRecv(LPTSTR pszBuff, INT iBuffSize, INT iFlags) {  
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, etError);
	/*DEBUG*/xASSERT_RET(NULL      != pszBuff,      etError);
	/*DEBUG*/xASSERT_RET(0          < iBuffSize,    etError);

	//����� ������� �������� �����
	memset(pszBuff, '\0', iBuffSize * sizeof(TCHAR));

	//recv - [+] number of bytes received and the buffer pointed to by the buf parameter will contain this data received. [-] SOCKET_ERROR [-] 0 gracefully closed 
	_m_iRes = ::recv(_m_puiSocket, (LPSTR)pszBuff, iBuffSize * sizeof(TCHAR), iFlags);
	/*DEBUG*/xASSERT_RET(etError                       !=  _m_iRes && WSAEWOULDBLOCK != iGetLastError(), etError);
	/*DEBUG*/////xASSERT_RET(0                         !=  _m_iRes,                                      etError);
	/*DEBUG*/xASSERT_RET(iBuffSize * (INT)sizeof(TCHAR) >= _m_iRes,                                      etError);

	return _m_iRes / sizeof(TCHAR);   
}   
//--------------------------------------------------------------------------- 
//TODO: + sRecvBytes (��������� ������ �� ������ ������)
tString 
CxSocket::sRecvAll(INT iFlags) {
	tString      sRes;
	
	const size_t cuiBuffSize             = 1024 * sizeof(TCHAR);
	TCHAR        szBuff[cuiBuffSize + 1] = {0};

	for (;;) {
		ULONG ulArg = (ULONG)FALSE;    
		
		_m_iRes = ::ioctlsocket(_m_puiSocket, FIONREAD, &ulArg);
		xCHECK_DO(0 != _m_iRes,        break);
		xCHECK_DO(0 == ulArg,          break);
		xCHECK_DO(cuiBuffSize < ulArg, ulArg = cuiBuffSize);

		_m_iRes = ::recv(_m_puiSocket, (LPSTR)&szBuff[0], ulArg, 0);
		xCHECK_DO(_m_iRes <= 0, break);

		sRes.append(tString(szBuff, _m_iRes));
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sRecvBytes (��������� ������ �� �����������, ���. ���)
tString 
CxSocket::sRecvAll(INT iFlags, const tString &csDelimiter) {   
	tString      sRes;
	const size_t cuiInSize = CxOptions::SOCKET_BUFF_SIZE * sizeof(TCHAR);
	tString      sIn(cuiInSize, xT('\0'));

	//-------------------------------------
	//������ �� ������ ������� � ����� � ������
	for (;;) {   
		_m_iRes = iRecv(&sIn[0], cuiInSize, iFlags);  
		xCHECK_DO(etError == _m_iRes, break);
		xCHECK_DO(0       == _m_iRes, break);

		sRes.append(sIn.begin(), sIn.begin() + _m_iRes);
		
		//���� ����� �����������, �� �������
		size_t uiDelimiterPos = sRes.find(csDelimiter);		//TODO: from unicode ???
		xCHECK_DO(tString::npos != uiDelimiterPos, break);
	} 
	
	return sRes;  
} 
//---------------------------------------------------------------------------
//TODO: SendNBytes
INT 
CxSocket::iSendBytes(LPSTR pszBuff, INT iMessageLength) {
	INT     iRC         = 0;
	INT     iSendStatus = 0;
	timeval SendTimeout = {0};

	//��������� �������� ��������
	SendTimeout.tv_sec  = 0;
	SendTimeout.tv_usec = CxOptions::SOCKET_TIMEOUT;              

	fd_set fds          = {0};
	FD_ZERO(&fds);
	FD_SET(_m_puiSocket, &fds);

	//..�� ��� ���, ���� ��� ����� �������� ������...
	while (iMessageLength > 0) {
		iRC = ::select(0, NULL, &fds, NULL, &SendTimeout);

		//����� �������, ������� ������
		xCHECK_RET(!iRC, etError);

		//��������� ������
		xCHECK_RET(iRC < 0, iGetLastError());

		//��������� ��������� ����
		iSendStatus = ::send(_m_puiSocket, pszBuff, iMessageLength, 0);   

		//��������� ������ � ������ �������� ������
		xCHECK_RET(iSendStatus < 0, iGetLastError());

		//�������� ����� � �������
		iMessageLength -= iSendStatus;
		pszBuff        += iSendStatus;
	}

	return 0;
}
//---------------------------------------------------------------------------
//TODO: ReceiveNBytes
INT 
CxSocket::iReceiveBytes(LPSTR pszBuff, INT iStillToReceive) {
	INT     iRC               = 0;
	INT     iReceiveStatus    = 0;
	timeval ReceiveTimeout    = {0};

	//��������� �������� ��������
	ReceiveTimeout.tv_sec  = 0;
	ReceiveTimeout.tv_usec = CxOptions::SOCKET_TIMEOUT;             //500 ms

	fd_set fds = {0};
	FD_ZERO(&fds);
	FD_SET(_m_puiSocket, &fds);

	//..���� ������ �� �������..
	while (iStillToReceive > 0) {
		iRC = ::select(0, &fds, NULL, NULL, &ReceiveTimeout);

		//����� �� ��������
		xCHECK_RET(!iRC, etError);

		//��������� ����� �� ������
		xCHECK_RET(iRC < 0, iGetLastError());

		//����� ���������� ����
		iReceiveStatus = ::recv(_m_puiSocket, pszBuff, iStillToReceive, 0);

		//��������� ������ � ������ ������� recv()
		xCHECK_RET(iReceiveStatus < 0, iGetLastError());

		//�������� �������� �������� � �����
		iStillToReceive -= iReceiveStatus;
		pszBuff         += iReceiveStatus;
	}

	return 0;
}
//---------------------------------------------------------------------------


/****************************************************************************
* ... 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - bGetPeerName ()
BOOL 
CxSocket::bGetPeerName(tString *psPeerAddr, USHORT *pusPeerPort) {
	/*DEBUG*///psPeerAddr  - n/a
	/*DEBUG*///pusPeerPort - n/a

	SOCKADDR_IN sockAddr = {0};

	INT iSockAddrLen = sizeof(sockAddr);
	_m_iRes = ::getpeername(_m_puiSocket, (SOCKADDR *)&sockAddr, &iSockAddrLen);
	/*DEBUG*/xASSERT_RET(0 == _m_iRes, FALSE);

	if (NULL != psPeerAddr) {
		//������� � UNICODE	
		std::string asPeerAddr = ::inet_ntoa(sockAddr.sin_addr);

		(*psPeerAddr).assign(asPeerAddr.begin(), asPeerAddr.end());
	}

	if (NULL != pusPeerPort) {
		*pusPeerPort = ::ntohs(sockAddr.sin_port);
	}	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetSocketName ()
BOOL 
CxSocket::bGetSocketName(tString *psSocketAddr, USHORT *pusSocketPort) {
	/*DEBUG*///psPeerAddr  - n/a
	/*DEBUG*///pusPeerPort - n/a

	SOCKADDR_IN sockAddr = {0};

	INT iSockAddrLen = sizeof(sockAddr);
	_m_iRes = ::getsockname(_m_puiSocket, (SOCKADDR *)&sockAddr, &iSockAddrLen);
	/*DEBUG*/xASSERT_RET(0 == _m_iRes, FALSE);

	if (NULL != psSocketAddr) {
		//������� � UNICODE	
		std::string asSocketAddr = ::inet_ntoa(sockAddr.sin_addr);

		(*psSocketAddr).assign(asSocketAddr.begin(), asSocketAddr.end());
	}

	if (NULL != pusSocketPort) {
		*pusSocketPort = ::ntohs(sockAddr.sin_port);
	}	

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
* static 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + iGetLastError
/*static*/
INT 
CxSocket::iGetLastError() {  
#ifdef WIN32
	return ::WSAGetLastError(); 
#else
	return ::errno();  
#endif     
}   
//---------------------------------------------------------------------------
//TODO: + iSelect (determines the status of one or more sockets, waiting if necessary, to perform synchronous I/O.)
INT 
CxSocket::iSelect(INT nfds, fd_set *pReadfds, fd_set *pWritefds, fd_set *pExceptfds/*,  const struct timeval *pTimeout*/) {
	 /*DEBUG*/
	 
	 _m_iRes = ::select(nfds, pReadfds, pWritefds, pExceptfds, &_m_tvTimeout);
	 /*DEBUG*/xASSERT_RET(etError != _m_iRes, etError);
	 /*DEBUG*/xASSERT_RET(0       != _m_iRes, 0);  //zero if the time limit expired

	 return _m_iRes;	 
}
//---------------------------------------------------------------------------











/*
INT 
CxSocket::WaitForData(SOCKET *pSocketForReceiving, SOCKET *pSocketForSending, SOCKET *pSocketForExceptions) {
	int nSocketsReady = 0;
	
	fd_set FdSetReceive;	FD_ZERO(&FdSetReceive);
	fd_set FdSetSend;   	FD_ZERO(&FdSetSend);
	fd_set FdSetError;  	FD_ZERO(&FdSetError);

	if (pSocketForReceiving) {
		FD_SET(*pSocketForReceiving, &FdSetReceive);
	}
	if (pSocketForSending) {
		FD_SET(*pSocketForSending, &FdSetSend);
	}
	if (pSocketForExceptions) {
		FD_SET(*pSocketForExceptions, &FdSetError);
	}

	TIMEVAL tv;
	TIMEVAL *ptv = NULL;

	if (_m_tvTimeout) {
		tv.tv_sec =  _m_tvTimeout / 1000;
		tv.tv_usec = _m_tvTimeout * 1000 - tv.tv_sec * 1000000;
		ptv = &tv;
	} else {
		ptv = NULL; // NULL for blocking operation (never times out)
	}

	nSocketsReady = select(0, &FdSetReceive, &FdSetSend, &FdSetError, ptv);

	//If the operation timed out, set a more natural error message
	if (nSocketsReady == 0) {
		SetLastError(WSAETIMEDOUT);
		nSocketsReady = SOCKET_ERROR;
	}

	return nSocketsReady;
}
*/



/*
procedure FlushRecvBufferUntil(s:TSOCKET;condition:Char);
var
	iReceiveRes : integer;
	cDummy : char;
	begin
repeat
	iReceiveRes := recv(s, cDummy, sizeof(cDummy), 0);
	until NOT ((iReceiveRes<>SOCKET_ERROR) and (iReceiveRes<>0) and
	(cDummy<>condition));
end;
*/


