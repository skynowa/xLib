/****************************************************************************
* Class name:  CXImageButton
* Description: 
* File name:   CXImageButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Gui/CXImageButton.h>

#include <XLib/GUI/CXWindowImpl.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: CXImageButton
CXImageButton::CXImageButton(EImageType itImageType) {
	/*DEBUG*/

	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXIMAGEBUTTON_CONTROL_CLASS;
	_m_ulStyle        = xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE | BS_ICON  /*| BS_PUSHLIKE*/ /*| BS_PUSHBUTTON*/;  //(itBitmap == itImageType) ? (xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE | BS_BITMAP) : (xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE /*| BS_ICON*/);
	_m_ulStyleEx      = xCXIMAGEBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXIMAGEBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = xCXIMAGEBUTTON_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
//TODO: ~CXImageButton
CXImageButton::~CXImageButton() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXImageButton::bCreateRes(INT iID, CXWindow *pwndParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*///xASSERT_RET(NULL != hParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
							    CXResources::sGetText  (iID), 
							    CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
							    CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
							    CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
							    this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO:
BOOL CXImageButton::bSetImage(EImageType itImageType, HANDLE hImage) {
	HANDLE hRes = NULL;

	//hRes = (HANDLE)( pSendMessage(BM_SETIMAGE, (WPARAM)itImageType, (LPARAM)hImage) );
	///*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	(HANDLE)pSendMessage(BM_SETIMAGE, static_cast<WPARAM>(itImageType), reinterpret_cast<LPARAM>(/*(HICON)*/hImage));
	/*DEBUG*/// n/a

	return TRUE;
}
//---------------------------------------------------------------------------