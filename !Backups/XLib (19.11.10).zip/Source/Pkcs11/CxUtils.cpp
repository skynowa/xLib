/****************************************************************************
* Class name:  CxUtils
* Description: Pkcs11 �������
* File name:   CxUtils.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:15:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Pkcs11/CxUtils.h>

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxUtils ()
CxUtils::CxUtils() {

}
//---------------------------------------------------------------------------
//TODO: - ~CxUtils ()
CxUtils::~CxUtils() {

}
//---------------------------------------------------------------------------


/****************************************************************************
*    private                                                         
*                                                                            
*****************************************************************************/


/****************************************************************************
*    private static                                                         
*                                                                            
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + CxUtils::sErrorStr (���������� �� ������, SDK 4.53) 
/*static*/ 
tString CxUtils::sErrorStr(CK_RV ulRes) {
	/*DEBUG*/// ulRes - n/a

	switch (ulRes) {
		case CKR_OK: 	                           return xT("CKR_OK");
		case CKR_CANCEL:                           return xT("CKR_CANCEL"); 
		case CKR_HOST_MEMORY:                      return xT("CKR_HOST_MEMORY");
		case CKR_SLOT_ID_INVALID:                  return xT("CKR_SLOT_ID_INVALID");
		case CKR_GENERAL_ERROR:                    return xT("CKR_GENERAL_ERROR");
		case CKR_FUNCTION_FAILED:                  return xT("CKR_FUNCTION_FAILED");
		case CKR_ARGUMENTS_BAD:                    return xT("CKR_ARGUMENTS_BAD");
		case CKR_NO_EVENT:                         return xT("CKR_NO_EVENT");
		case CKR_NEED_TO_CREATE_THREADS:           return xT("CKR_NEED_TO_CREATE_THREADS");
		case CKR_CANT_LOCK:                        return xT("CKR_CANT_LOCK");
		case CKR_ATTRIBUTE_READ_ONLY:              return xT("CKR_ATTRIBUTE_READ_ONLY");
		case CKR_ATTRIBUTE_SENSITIVE:              return xT("CKR_ATTRIBUTE_SENSITIVE");
		case CKR_ATTRIBUTE_TYPE_INVALID:           return xT("CKR_ATTRIBUTE_TYPE_INVALID");
		case CKR_ATTRIBUTE_VALUE_INVALID:          return xT("CKR_ATTRIBUTE_VALUE_INVALID");
		case CKR_DATA_INVALID:                     return xT("CKR_DATA_INVALID");
		case CKR_DATA_LEN_RANGE:                   return xT("CKR_DATA_LEN_RANGE");
		case CKR_DEVICE_ERROR:                     return xT("CKR_DEVICE_ERROR");
		case CKR_DEVICE_MEMORY:                    return xT("CKR_DEVICE_MEMORY");
		case CKR_DEVICE_REMOVED:                   return xT("CKR_DEVICE_REMOVED");
		case CKR_ENCRYPTED_DATA_INVALID:           return xT("CKR_ENCRYPTED_DATA_INVALID");
		case CKR_ENCRYPTED_DATA_LEN_RANGE:         return xT("CKR_ENCRYPTED_DATA_LEN_RANGE");	
		case CKR_FUNCTION_CANCELED:                return xT("CKR_FUNCTION_CANCELED");				
		case CKR_FUNCTION_NOT_PARALLEL:            return xT("CKR_FUNCTION_NOT_PARALLEL");			
		case CKR_FUNCTION_NOT_SUPPORTED:           return xT("CKR_FUNCTION_NOT_SUPPORTED");			
		case CKR_KEY_HANDLE_INVALID:               return xT("CKR_KEY_HANDLE_INVALID");				
		case CKR_KEY_SIZE_RANGE:                   return xT("CKR_KEY_SIZE_RANGE");						
		case CKR_KEY_TYPE_INCONSISTENT:            return xT("CKR_KEY_TYPE_INCONSISTENT");		
		case CKR_KEY_NOT_NEEDED:                   return xT("CKR_KEY_NOT_NEEDED");						
		case CKR_KEY_CHANGED:                      return xT("CKR_KEY_CHANGED");						
		case CKR_KEY_NEEDED:                       return xT("CKR_KEY_NEEDED");							
		case CKR_KEY_INDIGESTIBLE:                 return xT("CKR_KEY_INDIGESTIBLE");
		case CKR_KEY_FUNCTION_NOT_PERMITTED:       return xT("CKR_KEY_FUNCTION_NOT_PERMITTED");			
		case CKR_KEY_NOT_WRAPPABLE:                return xT("CKR_KEY_NOT_WRAPPABLE");					
		case CKR_KEY_UNEXTRACTABLE:                return xT("CKR_KEY_UNEXTRACTABLE");					
		case CKR_MECHANISM_INVALID:                return xT("CKR_MECHANISM_INVALID");					
		case CKR_MECHANISM_PARAM_INVALID:          return xT("CKR_MECHANISM_PARAM_INVALID");	
		case CKR_OBJECT_HANDLE_INVALID:            return xT("CKR_OBJECT_HANDLE_INVALID");				
		case CKR_OPERATION_ACTIVE:                 return xT("CKR_OPERATION_ACTIVE");					
		case CKR_OPERATION_NOT_INITIALIZED:        return xT("CKR_OPERATION_NOT_INITIALIZED");			
		case CKR_PIN_INCORRECT:                    return xT("CKR_PIN_INCORRECT");						
		case CKR_PIN_INVALID:                      return xT("CKR_PIN_INVALID");						
		case CKR_PIN_LEN_RANGE:                    return xT("CKR_PIN_LEN_RANGE");						
		case CKR_PIN_EXPIRED:                      return xT("CKR_PIN_EXPIRED");						
		case CKR_PIN_LOCKED:                       return xT("CKR_PIN_LOCKED");							
		case CKR_SESSION_CLOSED:                   return xT("CKR_SESSION_CLOSED");						
		case CKR_SESSION_COUNT:                    return xT("CKR_SESSION_COUNT");						
		case CKR_SESSION_HANDLE_INVALID:           return xT("CKR_SESSION_HANDLE_INVALID");
		case CKR_SESSION_PARALLEL_NOT_SUPPORTED:   return xT("CKR_SESSION_PARALLEL_NOT_SUPPORTED");		
		case CKR_SESSION_READ_ONLY:                return xT("CKR_SESSION_READ_ONLY");					
		case CKR_SESSION_EXISTS:                   return xT("CKR_SESSION_EXISTS");						
		case CKR_SESSION_READ_ONLY_EXISTS:         return xT("CKR_SESSION_READ_ONLY_EXISTS");			
		case CKR_SESSION_READ_WRITE_SO_EXISTS:     return xT("CKR_SESSION_READ_WRITE_SO_EXISTS");		
		case CKR_SIGNATURE_INVALID:                return xT("CKR_SIGNATURE_INVALID");					
		case CKR_SIGNATURE_LEN_RANGE:              return xT("CKR_SIGNATURE_LEN_RANGE");				
		case CKR_TEMPLATE_INCOMPLETE:              return xT("CKR_TEMPLATE_INCOMPLETE");				
		case CKR_TEMPLATE_INCONSISTENT:            return xT("CKR_TEMPLATE_INCONSISTENT");				
		case CKR_TOKEN_NOT_PRESENT:                return xT("CKR_TOKEN_NOT_PRESENT");					
		case CKR_TOKEN_NOT_RECOGNIZED:             return xT("CKR_TOKEN_NOT_RECOGNIZED");				
		case CKR_TOKEN_WRITE_PROTECTED:            return xT("CKR_TOKEN_WRITE_PROTECTED");				
		case CKR_UNWRAPPING_KEY_HANDLE_INVALID:    return xT("CKR_UNWRAPPING_KEY_HANDLE_INVALID");		
		case CKR_UNWRAPPING_KEY_SIZE_RANGE:        return xT("CKR_UNWRAPPING_KEY_SIZE_RANGE");			
		case CKR_UNWRAPPING_KEY_TYPE_INCONSISTENT: return xT("CKR_UNWRAPPING_KEY_TYPE_INCONSISTENT");	
		case CKR_USER_ALREADY_LOGGED_IN:           return xT("CKR_USER_ALREADY_LOGGED_IN");	        	
		case CKR_USER_NOT_LOGGED_IN:               return xT("CKR_USER_NOT_LOGGED_IN");	            	
		case CKR_USER_PIN_NOT_INITIALIZED:         return xT("CKR_USER_PIN_NOT_INITIALIZED");	        
		case CKR_USER_TYPE_INVALID:                return xT("CKR_USER_TYPE_INVALID");                 	
		case CKR_USER_ANOTHER_ALREADY_LOGGED_IN:   return xT("CKR_USER_ANOTHER_ALREADY_LOGGED_IN");    	
		case CKR_USER_TOO_MANY_TYPES:              return xT("CKR_USER_TOO_MANY_TYPES");			    
		case CKR_WRAPPED_KEY_INVALID:              return xT("CKR_WRAPPED_KEY_INVALID");				
		case CKR_WRAPPED_KEY_LEN_RANGE:            return xT("CKR_WRAPPED_KEY_LEN_RANGE");				
		case CKR_WRAPPING_KEY_HANDLE_INVALID:      return xT("CKR_WRAPPING_KEY_HANDLE_INVALID");		
		case CKR_WRAPPING_KEY_SIZE_RANGE:          return xT("CKR_WRAPPING_KEY_SIZE_RANGE");			
		case CKR_WRAPPING_KEY_TYPE_INCONSISTENT:   return xT("CKR_WRAPPING_KEY_TYPE_INCONSISTENT");		
		case CKR_RANDOM_SEED_NOT_SUPPORTED:        return xT("CKR_RANDOM_SEED_NOT_SUPPORTED");			
		case CKR_RANDOM_NO_RNG:                    return xT("CKR_RANDOM_NO_RNG");						
		case CKR_DOMAIN_PARAMS_INVALID:            return xT("CKR_DOMAIN_PARAMS_INVALID");					/*new SDK 4.53*/
		case CKR_BUFFER_TOO_SMALL:                 return xT("CKR_BUFFER_TOO_SMALL");					
		case CKR_SAVED_STATE_INVALID:              return xT("CKR_SAVED_STATE_INVALID");				
		case CKR_INFORMATION_SENSITIVE:            return xT("CKR_INFORMATION_SENSITIVE");				
		case CKR_STATE_UNSAVEABLE:                 return xT("CKR_STATE_UNSAVEABLE");					
		case CKR_CRYPTOKI_NOT_INITIALIZED:         return xT("CKR_CRYPTOKI_NOT_INITIALIZED");			
		case CKR_CRYPTOKI_ALREADY_INITIALIZED:     return xT("CKR_CRYPTOKI_ALREADY_INITIALIZED");		
		case CKR_MUTEX_BAD:                        return xT("CKR_MUTEX_BAD");							
		case CKR_MUTEX_NOT_LOCKED:                 return xT("CKR_MUTEX_NOT_LOCKED");					
		case CKR_FUNCTION_REJECTED:                return xT("CKR_FUNCTION_REJECTED");						/*new SDK 4.53*/
		case CKR_VENDOR_DEFINED:                   return xT("CKR_VENDOR_DEFINED");						
		case CKR_SAPI_OBJECT_DOES_NOT_EXIST:       return xT("CKR_SAPI_OBJECT_DOES_NOT_EXIST");				/*new SDK 4.53*/
		case CKR_SAPI_OBJECT_ALREADY_EXISTS:       return xT("CKR_SAPI_OBJECT_ALREADY_EXISTS");				/*new SDK 4.53*/
		case CKR_SAPI_NOT_SUPPORTED_BY_TOKEN:      return xT("CKR_SAPI_NOT_SUPPORTED_BY_TOKEN");			/*new SDK 4.53*/
		case CKR_SAPI_PIN_QUALITY:                 return xT("CKR_SAPI_PIN_QUALITY");						/*new SDK 4.53*/
		case CKR_SAPI_PIN_DEFAULT:                 return xT("CKR_SAPI_PIN_DEFAULT");						/*new SDK 4.53*/
		case CKR_SAPI_PIN_EXPIRATION:              return xT("CKR_SAPI_PIN_EXPIRATION");					/*new SDK 4.53*/
		case CKR_SAPI_PIN_CHANGE_NOT_ALLOWED:      return xT("CKR_SAPI_PIN_CHANGE_NOT_ALLOWED");			/*new SDK 4.53*/
		case CKR_SAPI_CANCELLED: 				   return xT("CKR_SAPI_CANCELLED");							/*new SDK 4.53*/
		case CKR_NEW_PIN_MODE:      			   return xT("CKR_NEW_PIN_MODE");							/*new SDK 4.53*/
		case CKR_NEXT_OTP:          	           return xT("CKR_NEXT_OTP");								/*new SDK 4.53*/

		default:								   return xT("CKR_UNKNOWN_ERROR");						    
	}
}
//--------------------------------------------------------------------------