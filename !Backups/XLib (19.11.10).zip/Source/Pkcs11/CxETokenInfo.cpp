/****************************************************************************
* Class name:  CxETokenInfo
* Description: ���������� � eToken
* File name:   CxETokenInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:53:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Pkcs11/CxETokenInfo.h>

#include <XLib/Pkcs11/CxUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxETokenInfo ()
CxETokenInfo::CxETokenInfo(const CxPkcs11 &cPkcs11) :
	_m_bRes (FALSE),
	_m_ulRes(!CKR_OK),
	_m_pFunc(cPkcs11.pGetFuncList())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CxETokenInfo ()
CxETokenInfo::~CxETokenInfo() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
