/****************************************************************************
* Class name:  CxEnvironment
* Description: ���������� ���������
* File name:   CxEnvironment.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.04.2010 17:43:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CxEnvironment.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - sGetVar
/*static*/
tString CxEnvironment::sGetVar(const tString &csVar) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), tString()); 

	tString sRes(MAX_PATH, _T('\0'));
	ULONG   ulStored = 0;

	//not including the terminating null character
	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/xASSERT_RET(0 != ulStored, tString()); 

	sRes.resize(ulStored);

	if (sRes.size() < ulStored) {
		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/xASSERT_RET(0 != ulStored, tString());
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: - bSetVar
/*static*/
BOOL CxEnvironment::bSetVar(const tString &csVar, const tString &csValue) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csVar.c_str(), csValue.c_str());
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: - bGetStrings
/*static*/
BOOL CxEnvironment::bGetStrings(std::vector<tString> *pvecsEnvStrings) {
	/*DEBUG*/xASSERT_RET(NULL != pvecsEnvStrings, FALSE); 

	BOOL   bRes   = FALSE;
	LPTSTR pszVar = NULL; 
	LPTCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/xASSERT_RET(NULL != lpvEnv, FALSE); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPTSTR)lpvEnv;

	pvecsEnvStrings->clear();

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		pvecsEnvStrings->push_back(tString(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: - sExpandStrings
/*static*/
tString CxEnvironment::sExpandStrings(const tString &csVar) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), tString()); 

	ULONG       ulStored = FALSE;
	tString sRes(MAX_PATH, _T('\0'));

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/xASSERT_RET(0 != ulStored, tString()); 

	sRes.resize(ulStored);	

	if (sRes.size() < ulStored) {
		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/xASSERT_RET(0 != ulStored, tString());
	}

	sRes.resize(ulStored - 1);	//������� '\0', including the terminating null character

	return sRes;
}
//--------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxEnvironment (comment)
CxEnvironment::CxEnvironment() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CxEnvironment (comment)
CxEnvironment::~CxEnvironment() {
	//code
}
//---------------------------------------------------------------------------