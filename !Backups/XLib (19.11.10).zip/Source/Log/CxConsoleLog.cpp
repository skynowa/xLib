/****************************************************************************
* Class name:  CxConsoleLog
* Description: ����������� ����� �������
* File name:   CxConsoleLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:53:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CxConsoleLog.h>

#include <XLib/CxString.h>
#include <XLib/Fso/CxPath.h>
#include <XLib/Sync/CxAutoCriticalSection.h>
#include <XLib/Fso/CxStdioFile.h>
#include <XLib/CxDateTime.h>


/****************************************************************************
*    public                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: static
CxCriticalSection CxConsoleLog::_ms_csConsole;
//---------------------------------------------------------------------------
//TODO: + CxConsoleLog ()
CxConsoleLog::CxConsoleLog(BOOL bIsUseTimeStr) :
	_m_bIsUseTimeStr(bIsUseTimeStr)
{
	
}
//---------------------------------------------------------------------------
//TODO: + ~CxConsoleLog ()
CxConsoleLog::~CxConsoleLog() {

}
//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CxConsoleLog::bWrite(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tString sTime;

	if (TRUE == _m_bIsUseTimeStr) {
		sTime = xT("[") + CxDateTime::dtGetCurrent().sGetTimeStr() + xT("] ");
	} else {
		sTime = xT("");
	}

	//-------------------------------------
	//���������
	tString sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = CxString::sFormatV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CxAutoCriticalSection SL(_ms_csConsole);

	CxStdioFile::iPrintf(xT("%s%s\n"), sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------