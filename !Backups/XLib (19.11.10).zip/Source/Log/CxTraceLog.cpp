/****************************************************************************
* Class name:  CxTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CxTraceLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Log/CxTraceLog.h>

#include <XLib/CxString.h>
#include <XLib/Fso/CxPath.h>
#include <XLib/CxDateTime.h>

//---------------------------------------------------------------------------
//TODO: + CxTraceLog ()
CxTraceLog::CxTraceLog(BOOL bIsUseTimeStr) :
	_m_bIsEnable    (TRUE),
	_m_bIsUseTimeStr(bIsUseTimeStr)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CxTraceLog ()
CxTraceLog::~CxTraceLog() {

}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - bSetEnabled ()
BOOL CxTraceLog::bSetEnabled(BOOL bFlag) {
	/*DEBUG*/// bFlag - n/a 

	_m_bIsEnable = bFlag;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CxTraceLog::bWrite(LPCTSTR pcszFormat, ...) {  
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, FALSE);
	
	xCHECK_RET(FALSE == _m_bIsEnable, TRUE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tString sTime;

	if (TRUE == _m_bIsUseTimeStr) {
		sTime = xT("[") + CxDateTime::dtGetCurrent().sGetTimeStr() + xT("] ");
	} else {
		sTime = xT("");
	}

	//-------------------------------------
	//���������
	tString sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = CxString::sFormatV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	::OutputDebugString((sTime + sParam + xLF).c_str());
	/*DEBUG*/// n/a

	return TRUE;
}
//---------------------------------------------------------------------------