/****************************************************************************
* Class name:  CxPerform
* Description: ����� ������������������ ����
* File name:   CxPerform.cpp
* String type: Ansi (tString)
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#include <XLib/Debug/CxPerform.h>

#include <XLib/Fso/CxPath.h>
#include <XLib/Fso/CxStdioFile.h>
#include <time.h>


/****************************************************************************
* public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxPerform (�����������)
CxPerform::CxPerform(const tString &csFilePath, EMode pmMode) :
	_m_bRes      (FALSE),
    _m_pmModeNow (pmMode),
    _m_bIsStarted(FALSE),
	_flLog       (csFilePath, CxFileLog::lsDefaultSize)
{
	/*DEBUG*/xASSERT_DO(false == csFilePath.empty(), return);
	/*DEBUG*/xASSERT_DO(- 1 < pmMode || pmMode < 4,  return);
	
	_m_bRes = _flLog.bWrite(_T("----------------------------------------"));
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CxPerform (����������)
CxPerform::~CxPerform() {	
	_m_bRes = _flLog.bWrite(_T("----------------------------------------\r\n"));
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//--------------------------------------------------------------------------
//TODO: + bStart (����� ���������)
BOOL CxPerform::bStart() {
	/*DEBUG*/xASSERT_RET(FALSE == _m_bIsStarted, FALSE);
	
	_m_bRes = _bResetData();
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	
	_m_bRes = ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
	/*DEBUG*/xASSERT(FALSE != _m_bRes);

	Sleep(100);

    switch (_m_pmModeNow) {
		case pmTime: {
				_m_dtTimesStart.dtGetCurrent();
				/*DEBUG*/// n/a
			}
			break;

		case pmTickCount: {
				_m_ulTicksStart = ::GetTickCount();
                /*DEBUG*/// n/a
			}
            break;
		
        case pmPerformanceCount: {
				_m_bRes = ::QueryPerformanceFrequency(&_m_liCountersPerfFreq);
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

				_m_bRes = ::QueryPerformanceCounter(&_m_liCountersStart);
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
			}
            break;

		case pmThreadTimes: {
				_m_bRes = ::GetThreadTimes(::GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTimeStart, &_m_lpUserTimeStart);
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
			}
			break;

		case pmClock: {
				_m_ctClocksStart = std::clock();
				/*DEBUG*/xASSERT_RET(- 1 != _m_ctClocksStart, FALSE);
			}
			break;
		
        default: {
				/*DEBUG*/xASSERT_MSG_RET(FALSE, _T("���������� �����"), FALSE);
			}
            break;
    }

    _m_bIsStarted = TRUE;

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bStop (���� ���������)
BOOL CxPerform::bStop(LPCTSTR pcszComment, ...) {
	/*DEBUG*/(FALSE != _m_bIsStarted, FALSE);

	tString sTimeString = xT("0:00:00:000");
	
	switch (_m_pmModeNow) {
		case pmTime: {
				_m_dtTimesStop.dtGetCurrent();
				/*DEBUG*/// n/a

                sTimeString = (_m_dtTimesStop - _m_dtTimesStart).sGetTimeStr();
			}
			break;

        case pmTickCount: {
				_m_ulTicksStop = ::GetTickCount();
				/*DEBUG*/// n/a

				sTimeString = CxDateTime(_m_ulTicksStop - _m_ulTicksStart).sGetTimeStr();				
            }
            break;

	    case pmPerformanceCount: {
				_m_bRes = ::QueryPerformanceCounter(&_m_liCountersStop);
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
				
				sTimeString = CxDateTime((_m_liCountersStop.QuadPart - _m_liCountersStart.QuadPart) * 1000 / _m_liCountersPerfFreq.QuadPart).sGetTimeStr();
            }
            break;

        case pmThreadTimes: {
				_m_bRes = ::GetThreadTimes(::GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTimeStop, &_m_lpUserTimeStop);
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
				
				sTimeString = CxDateTime((CxDateTime::i64FiletimeToInt64(_m_lpUserTimeStop) - CxDateTime::i64FiletimeToInt64(_m_lpUserTimeStart)) / 10000).sGetTimeStr();
            }
            break;  
		
		case pmClock: {
				_m_ctClocksStop = std::clock();
				/*DEBUG*/xASSERT_RET(- 1 != _m_ctClocksStop, FALSE);

				sTimeString = CxDateTime( (_m_ctClocksStop - _m_ctClocksStart) / (CLOCKS_PER_SEC / 1000) ).sGetTimeStr();
		    }
		    break;

		default: {
				/*DEBUG*/xASSERT(FALSE);
			}
			break;
	}

	//-------------------------------------
	//������ ��������
	tString sRes;

	va_list palArgs = NULL;
	va_start(palArgs, pcszComment);

	sRes = CxString::sFormatV(pcszComment, palArgs);

	va_end(palArgs);
	
	//-------------------------------------
	//������ � ����
	_m_bRes = _flLog.bWrite(xT("%s: %s"), sTimeString.c_str(), sRes.c_str());
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, FALSE);

	_m_bIsStarted = FALSE;

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bPulse (��������� � �����, �� ��������� ���������)
BOOL CxPerform::bPulse(LPCTSTR pcszComment, ...) {
	//-------------------------------------
	//������ ��������
	tString sRes;

	va_list palArgs = NULL;
	va_start(palArgs, pcszComment);

	sRes = CxString::sFormatV(pcszComment, palArgs);

	va_end(palArgs);
	
	//-------------------------------------
	//����/�����
	_m_bRes = bStop(sRes.c_str());
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	_m_bRes = bStart();
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private	
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _bResetData (��������� ���� ������)
BOOL CxPerform::_bResetData() {
	_m_bRes = ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);
	/*DEBUG*/xASSERT(FALSE != _m_bRes);

    _m_bIsStarted                       = FALSE;
	
	//pmTime
	xZERO_BUFF(_m_dtTimesStart);
	xZERO_BUFF(_m_dtTimesStop);

	//pmGetTickCount
	_m_ulTicksStart                     = 0;
	_m_ulTicksStop                      = 0;

    //pmPerformanceCount
	_m_liCountersPerfFreq.QuadPart      = 0;
	_m_liCountersStart.QuadPart         = 0;
	_m_liCountersStop.QuadPart          = 0;

	//pmThreadTimes
	_m_lpCreationTime.dwLowDateTime     = 0;
    _m_lpCreationTime.dwHighDateTime    = 0;
	_m_lpExitTime.dwLowDateTime         = 0;
    _m_lpExitTime.dwHighDateTime        = 0;
	_m_lpKernelTimeStart.dwLowDateTime  = 0;
    _m_lpKernelTimeStart.dwHighDateTime = 0;
	_m_lpUserTimeStart.dwLowDateTime    = 0;
    _m_lpUserTimeStart.dwHighDateTime   = 0;
	_m_lpKernelTimeStop.dwLowDateTime   = 0;
    _m_lpKernelTimeStop.dwHighDateTime  = 0;
	_m_lpUserTimeStop.dwLowDateTime     = 0;
    _m_lpUserTimeStop.dwHighDateTime    = 0;   

	//pmClock
	xZERO_BUFF(_m_ctClocksStart);
	xZERO_BUFF(_m_ctClocksStop);

	return TRUE;
}
//--------------------------------------------------------------------------


/*
#include <time.h>
...
...
time_t startTime;
startTime = time(NULL);
// do some long process...
time_t stopTime;
stopTime = time(NULL);
time_t elapsedTime = stopTime - startTime;
printf("The number elapsed seconds is %ld",elapsedTime);
...
*/

/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

BOOL F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
INT main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/