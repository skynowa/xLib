/****************************************************************************
* Class name:  CxAutoPerform
* Description: ����� ������������������ ���� � �����
* File name:   CxAutoPerform.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     05.07.2010 16:27:50
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/CxAutoPerform.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxAutoPerform (comment)
CxAutoPerform::CxAutoPerform(const tString &csFilePath, CxPerform::EMode pmMode, LPCTSTR pcszComment, ...) :
	_m_pfPerform(csFilePath, pmMode)	
{
	//-------------------------------------
	//������ ��������
	va_list palArgs = NULL;
	va_start(palArgs, pcszComment);

	_m_sComment = CxString::sFormatV(pcszComment, palArgs);

	va_end(palArgs);
	
	//-------------------------------------
	//����� ���������
	_m_pfPerform.bStart();
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: - ~CxAutoPerform (comment)
CxAutoPerform::~CxAutoPerform() {
	_m_pfPerform.bStop(_m_sComment.c_str());
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------