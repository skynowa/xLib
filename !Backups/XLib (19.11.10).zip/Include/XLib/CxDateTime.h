	/****************************************************************************
* Class name:  CxDateTime
* Description: ������ � ������
* File name:   CxDateTime.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CxDateTimeH
#define XLib_CxDateTimeH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#ifdef __BORLANDC__
	#include <vcl.h>
#endif
//---------------------------------------------------------------------------
class CxDateTime {
	public:
		//���������
		enum EFormatType {
			MMDDYY,
			DDMMYY,
			YYMMDD,
			MMDDYYYY,
			DDMMYYYY,
			YYYYMMDD,
		};

		//������������
				           CxDateTime          (); 
						   CxDateTime          (const CxDateTime &dtDT);
				           CxDateTime          (ULONGLONG ui64MSec); /*LARGE_INTEGER*/
						   CxDateTime          (USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec); 
						   CxDateTime          (USHORT usYear, USHORT usMonth, USHORT usDay); 
						   CxDateTime          (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec); 
		virtual 	   	  ~CxDateTime          (); 

		//��������� ���������
		BOOL               operator ==         (const CxDateTime &dtDT) const;	
		BOOL               operator !=         (const CxDateTime &dtDT) const;	
		BOOL               operator <          (const CxDateTime &dtDT) const;	
		BOOL               operator <=         (const CxDateTime &dtDT) const;	
		BOOL               operator >          (const CxDateTime &dtDT) const;	
		BOOL               operator >=         (const CxDateTime &dtDT) const;	

		//��������� ������������
		CxDateTime        &operator =          (const CxDateTime &dtDT);
	#ifdef __BORLANDC__
		CxDateTime        &operator =          (const TDateTime  &dtDT);	
	#endif
		CxDateTime        &operator =          (ULONGLONG ui64MSec);

		CxDateTime         operator +          (const CxDateTime &dtDT) const;	
		CxDateTime         operator -          (const CxDateTime &dtDT) const;	
		CxDateTime        &operator +=         (const CxDateTime &dtDT);
		CxDateTime        &operator -=         (const CxDateTime &dtDT);
		//++
		//--

		//get/set
		BOOL               bGet                (USHORT *pusYear, USHORT *pusMonth, USHORT *pusDay, USHORT *pusHour, USHORT *pusMinute, USHORT *pusSecond, USHORT *pusMSec) const;
		BOOL               bSet                (ULONGLONG ui64MSec);
		BOOL               bSet                (USHORT  usYear,  USHORT  usMonth,  USHORT  usDay,  USHORT  usHour,  USHORT  usMinute,  USHORT  usSecond,  USHORT  usMSec);
		
		//��������������
		tString            sGetTimeStr         () const;	
		tString            sGetDateStr         () const; 	
		tString			   sGetDateTimeStr     () const; 	
	////tString            sGetDateStrLong     () const; 	
	////tString			   sGetDateTimeStrLong () const;
		
		//static
		static BOOL        bIsValid            (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
		static CxDateTime  dtGetCurrent        (); 
		////--static BOOL        bMSecToSystemTime   (ULONGLONG ui64MSec, SYSTEMTIME *stST); 
		/*static*/ BOOL        bMSecToSystemTime   (ULONGLONG ui64MSec); 
		////--static ULONGLONG   ui64SystemTimeToMSec(const SYSTEMTIME &stST); 
		/*static*/ ULONGLONG   ui64SystemTimeToMSec(); 
		////ToUniversalTime();     
		////ToLocalTime();         

		////////static tString     sMSecToTimeString  (ULONGLONG ui64MSec); 
		static LONGLONG    i64FiletimeToInt64  (FILETIME ftTime);	

		static USHORT      usDaysInMonth       (USHORT usYear, USHORT usMonth);
		static BOOL        bIsLeapYear         (USHORT usYear);

		//������
		static tString     sGetZodiacSign      (USHORT usMonth, USHORT usDay);
		static tString     sGetMonthStr        (USHORT usMonth, BOOL bIsShortName);
		static tString     sGetWeekDayStr      (USHORT usDay,   BOOL bIsShortName);

   	private:
		BOOL               _m_bRes;

		////--SYSTEMTIME         _m_stDateTime;
		ULONGLONG          _m_ui64DateTimeMSec;	//LARGE_INTEGER

		USHORT			   _m_usYear;
		USHORT	           _m_usMonth;
		USHORT	           _m_usDay;
		USHORT	           _m_usHour;
		USHORT	           _m_usMinute;
		USHORT	           _m_usSecond;
		USHORT	           _m_usMSec;

		/////__time64_t         _m_time;	/*__int64*/
};
//---------------------------------------------------------------------------
#endif	//XLib_CxDateTimeH

/*
//---------------------------------------------------------------------------
__int64 i64DateTimeToSeconds(const TDateTime &dtDateTime) {
    WORD wYear, wMonth, wDay, wHour, wMin, wSec, wMSec;
    
	DecodeTime(dtDateTime, wHour, wMin, wSec, wMSec);
    
	return (wHour * 60 * 60) + (wMin * 60) + (wSec);
}
//---------------------------------------------------------------------------
*/


/*
#define INTERVAL_CENTI      1
#define INTERVAL_SEC        100
#define INTERVAL_MIN        6000
#define INTERVAL_HOUR       360000L
#define INTERVAL_DAY        8640000L

#define INTERVAL_SEC_SEC	1
#define INTERVAL_MIN_SEC	60
#define INTERVAL_HOUR_SEC	3600
#define INTERVAL_DAY_SEC	86400
*/






/*
typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/





//GetTimeFormatEx
//GetDateFormat