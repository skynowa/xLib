/****************************************************************************
* Class name:  CxTls
* Description: ��������� ������ ������
* File name:   CxTls.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     18.01.2010 14:42:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLib_Sync_CxTlsH
#define CXLib_Sync_CxTlsH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxTls : public CxNonCopyable {
	public:
		         CxTls();
		virtual ~CxTls();
	   
		BOOL     bAlloc    ();
		BOOL     bFree     (); 
		VOID    *pvGetValue(); 
		BOOL     bSetValue (VOID *pvValue);
	   
	private:
		ULONG _m_ulIndex;
};
//---------------------------------------------------------------------------
#endif	//CXLib_Sync_CxTlsH