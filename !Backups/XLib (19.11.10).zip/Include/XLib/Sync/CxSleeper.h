/****************************************************************************
* Class name:  CxSleeper
* Description: ������ ::Sleep()
* File name:   CxSleeper.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.07.2009 12:54:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CxSleeperH
#define XLib_Sync_CxSleeperH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Sync/CxEvent.h>
//---------------------------------------------------------------------------
class CxSleeper : public CxNonCopyable {
	public:
         	     CxSleeper  ();
		virtual ~CxSleeper  ();

		BOOL     bSleep     (ULONG ulTimeout) const;
		BOOL     bWakeUp    () const;
		BOOL     bIsSleeping() const;

	private:
        CxEvent _m_objEvent; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CxSleeperH