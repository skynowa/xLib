/****************************************************************************
* Class name:  CxMallocT
* Description: ������ � ��������
* File name:   CxMallocT.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2009 17:20:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

/*
Usage:

	PSP_DEVICE_INTERFACE_DETAIL_DATA pData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(ulBytesReturned);
	...
	free(pData);

	CxMallocT<PSP_DEVICE_INTERFACE_DETAIL_DATA> diddDeviceInterfaceDetailData((size_t)ulBytesReturned);
*/

#ifndef XLib_CxMallocH
#define XLib_CxMallocH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
template<class PointerT>
class CxMallocT : public CxNonCopyable {
	public:
		         CxMallocT(const std::size_t cuiSize);
		        ~CxMallocT();

		PointerT pGetPtr();
            
	private:
        PointerT _m_pDataT;
};
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO: + CxMallocT (����������)
template<class PointerT>
CxMallocT<PointerT>::CxMallocT(const std::size_t cuiSize) :
	_m_pDataT(NULL)
{
	/*DEBUG*/xASSERT_DO(NULL == _m_pDataT, return);
	/*DEBUG*/// cuiSize - n/a

	_m_pDataT = static_cast<PointerT>( malloc(cuiSize) );
	/*DEBUG*/xASSERT(NULL != _m_pDataT);		//MessageBox(0, "Constructor", "", MB_OK);
}
//---------------------------------------------------------------------------
//TODO: + ~CxMallocT (����������)
template<class PointerT>
CxMallocT<PointerT>::~CxMallocT() {		
	/*DEBUG*/xASSERT_DO(NULL != _m_pDataT, return);

	if (NULL != _m_pDataT) {
		free(_m_pDataT);	
		_m_pDataT = NULL;							//MessageBox(0, "Destructor", "", MB_OK);
	}
}
//---------------------------------------------------------------------------
//TODO: + pGetPtr (��������� ���������)
template<class PointerT>
PointerT CxMallocT<PointerT>::pGetPtr() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pDataT, NULL);

	return _m_pDataT; 
}
//---------------------------------------------------------------------------
#endif	//XLib_CxMallocH