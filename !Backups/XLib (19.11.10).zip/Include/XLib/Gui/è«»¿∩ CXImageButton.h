/****************************************************************************
* Class name:  CXImageButton
* Description: 
* File name:   CXImageButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXImageButtonH
#define XLib_Gui_CXImageButtonH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXImageButton: public CXWindow {
	public:
		//���������
		typedef enum EImageType {
			itBitmap = IMAGE_BITMAP,
			itIcon	 = IMAGE_ICON
		};	

			   CXImageButton(EImageType itImageType);
			  ~CXImageButton();
			
	    BOOL   bCreateRes  (INT iID, CXWindow *pwndParent);

		//-------------------------------------
		//���������
		BOOL   bSetImage(EImageType itImageType, HANDLE hImage); 

		//-------------------------------------
		//�������

};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXImageButtonH