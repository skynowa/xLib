/****************************************************************************
* Class name:  CXMsgBoxT
* Description: ����� ���������, ������ ���� ������
* File name:   CXMsgBoxT.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     27.04.2009 10:24:49
* Version:     1.0
*
*****************************************************************************/
 

#ifndef XLib_Gui_CXMsgBoxTH	
#define XLib_Gui_CXMsgBoxTH   
//---------------------------------------------------------------------------
#include <XLib/Gui/xCommon.h>
//---------------------------------------------------------------------------
//TODO: + iMsgBox 
template <typename TextT, typename TitleT> 
INT iMsgBox(HWND hWnd, TextT Text, TitleT Title, UINT uiType) {			
	return ::MessageBox(hWnd, CxString::lexical_cast(Text).c_str(), CxString::lexical_cast(Title).c_str(), uiType);
}
//---------------------------------------------------------------------------
//TODO: + iMsgBox 
template <typename TextT, typename TitleT> 
INT iMsgBox(TextT Text, TitleT Title, UINT uiType) {			
	return ::MessageBox(NULL, CxString::lexical_cast(Text).c_str(), CxString::lexical_cast(Title).c_str(), uiType);
}
//---------------------------------------------------------------------------
//TODO: + iMsgBox 
template <typename TextT, typename TitleT> 
INT iMsgBox(TextT Text, TitleT Title) {			
	return ::MessageBox(NULL, CxString::lexical_cast(Text).c_str(), CxString::lexical_cast(Title).c_str(), MB_OK);
}
//---------------------------------------------------------------------------
//TODO: + iMsgBox 
template <typename TextT> 
INT iMsgBox(TextT Text) {			
	return ::MessageBox(NULL, CxString::lexical_cast(Text).c_str(), xT(""), MB_OK);
}
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXMsgBoxTH