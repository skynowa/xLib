/****************************************************************************
* Class name:  CxString
* Description: ��������� ������
* File name:   CxString.h
* String type: Ansi (tString, wstring)
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef XLib_CxStringH
#define XLib_CxStringH  
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <iomanip>	//std::setbase
//---------------------------------------------------------------------------
class CxString : public CxNonCopyable {
	public: 
		//---------------------------------------------------------------------------
		//UCHAR -> TCHAR_HEX
		////template<class CharT>
		////static tString sStrToBase(const std::basic_string<CharT> &csStr, INT iBase)	{
		////	/*DEBUG*/xASSERT_RET(false == csStr.empty(),                   FALSE);
		////	/*DEBUG*/xASSERT_RET(8 == iBase || 10 == iBase || 16 == iBase, FALSE);
		////	
		////	std::basic_stringstream<CharT> ssStream;
		////	ssStream << std::setbase(iBase) << std::showbase << std::uppercase;

		////	copy(csStr.begin(), csStr.end(), std::ostream_iterator<INT, CharT>(ssStream, _T(" ")/*csSep.at(0)*/));
		////	
		////	return ssStream.str();
		////}


		////template<class CharT> 
		////static std::basic_string<CharT> sBaseToStr(const std::basic_string<CharT> &csStr, INT iBase) {
		////	/*DEBUG*/xASSERT_RET(false == csStr.empty(),                   FALSE);
		////	/*DEBUG*/xASSERT_RET(8 == iBase || 10 == iBase || 16 == iBase, FALSE);
		////	
		////	std::basic_string<CharT> sResT;

		////	tistringstream issStream(csStr);
		////	issStream >> std::setbase(iBase);

		////	std::copy(std::istream_iterator<INT>(issStream), std::istream_iterator<INT>(), std::back_inserter(sResT));

		////	return sResT; 
		////};

		//---------------------------------------------------------------------------
		/*
		std::string str("i am string");
		std::vector<unsigned char> data;//i am array
		std::copy(str.begin(), str.end(), std::back_inserter(data));
		*/

		/*
		std::string str = ("trololo");
		std::wstring wstr(str.begin(),str.end());
		str = std::string(wstr.begin(),wstr.end());
		*/

		////std::string str = "10 11 b";
		////std::istringstream iss(str);
		////std::vector<int> vi;

		////iss >> std::hex;
		////std::copy(std::istream_iterator<int>(iss), std::istream_iterator<int>(), std::back_inserter(vi));
				
		//-------------------------------------
		//tString -> tString_Base
		template<class CharT>
		static tString sStringToBase(const std::basic_string<CharT> &csStr, INT iBase)	{
			/*DEBUG*/xASSERT_RET(false == csStr.empty(),                   FALSE);
			/*DEBUG*/xASSERT_RET(8 == iBase || 10 == iBase || 16 == iBase, FALSE);

			tostringstream ssStream;
			ssStream << std::setbase(iBase) << std::showbase << std::uppercase;
			
			tString sRes(csStr.begin(), csStr.end());

			copy(sRes.begin(), sRes.end(), std::ostream_iterator<INT, TCHAR>( ssStream, xT(" ") ));

			return ssStream.str();
		}	

		//-------------------------------------
		//tString_Base -> tString
		template<class StringT/*CharT*/> 
		static StringT/*std::basic_string<CharT>*/ sBaseToString(const tString &csStr, INT iBase) {
			/*DEBUG*/xASSERT_RET(false == csStr.empty(),                   FALSE);
			/*DEBUG*/xASSERT_RET(8 == iBase || 10 == iBase || 16 == iBase, FALSE);
			
			tistringstream issStream(csStr);
			issStream >> std::setbase(iBase);

			return StringT/*std::basic_string<CharT>*/(
						std::istream_iterator<INT, TCHAR>(issStream),
						std::istream_iterator<INT, TCHAR>()
				   );
		};	


		//---------------------------------------------------------------------------
		//����� -> ������
		template<class T> 
		static tString lexical_cast(T const &cValueT) {		
			tostringstream ossStream;	
			ossStream.exceptions(/*tostringstream::eofbit |*/ tostringstream::failbit | tostringstream::badbit);

			try {
				ossStream << cValueT;
			} catch (tostringstream::failure e) {
				/*DEBUG*/xASSERT_RET(FALSE, tString());
			} catch (...) {
				/*DEBUG*/xASSERT_RET(FALSE, tString());
			}

			return ossStream.str();
		};

		//---------------------------------------------------------------------------
		//������ -> �����
		template<class T> 
		static T lexical_cast(const tString &csStr) {
			tistringstream issStream(csStr);
			issStream.exceptions(/*tistringstream::eofbit |*/ tistringstream::failbit | tistringstream::badbit);

			T ResT;
			try {
				issStream >> ResT;
			} catch (tistringstream::failure e) {
				/*DEBUG*/xASSERT_RET(FALSE, T());
			} catch (...) {
				/*DEBUG*/xASSERT_RET(FALSE, T());
			}

			return ResT;
		};

		static BOOL         bBoolToStr       (BOOL bBool, tString *psStr);
		static BOOL         bStrToBool       (const tString &csStr, BOOL *pbBool);

		static tString      sTrimLeftChars   (const tString &csStr, const tString &csChars); 
		static tString      sTrimRightChars  (const tString &csStr, const tString &csChars); 
		static tString      sTrimChars       (const tString &csStr, const tString &csChars);
		static tString      sTrimSpace       (const tString &csStr);	
		static tString      sRemoveEOL       (const tString &csStr);	

		static tString      sReplaceAll      (const tString &csStr, const tString &csOldStr, const tString &csNewStr); 
		static tString      sReplaceAll      (const tString &csStr, TCHAR cOldStr, TCHAR cNewStr); 
		static tString      sRemoveAll       (const tString &csStr, const tString &csRemoveStr); 

		static BOOL         bSplit           (const tString &csStr, const tString &csSep, std::vector<tString> *vecsOut); 

		static BOOL         bSplitKeyValue   (const tString &csStr, const tString &csSep, std::vector<tString> *pvecsKeyValue); 
		static tString      sJoin            (const std::vector<tString> &cvecsVec, TCHAR chSep); 
		static tString      sJoin            (const std::vector<tString> &cvecsVec, const tString &csSep); 
		static tString      sCut             (const tString &csStr, const tString &csFirstLeftDelimiter, const tString &csFirstRightDelimiter); /*-*/
		static tString      sCut             (const tString &csStr, std::size_t uiStartPos = 0, std::size_t uiEndPos = std::string::npos); 

		static tString      sToLowerCase     (const tString &csStr);	
		static tString      sToUpperCase     (const tString &csStr);	
		static tString      sToLowerCase     (const tString &csStr, ULONG ulSize);	
		static tString      sToUpperCase     (const tString &csStr, ULONG ulSize);	

		static tString      sFormat          (LPCTSTR pcszFormat, ...); 
		static std::string  sFormatA         (LPCSTR  pcszFormat, ...); 
		static tString      sFormatV         (LPCTSTR pcszFormat, va_list palArgs);
		static tString      sMinimize        (const tString &csStr, const UINT cuiMaxLen); 

		/****************************************************************************
		*    
		*
		*****************************************************************************/

		static BOOL         bCompareNoCase   (const tString &csStr1, const tString &csStr2); 
		static BOOL         bCompareNoCase2  (const tString &csStr1, const tString &csStr2); 
		static INT          iWildCompare     (LPCTSTR pcszStr, LPCTSTR pcszWild);

		/****************************************************************************
		*	�������������
		*
		*****************************************************************************/

		static tString		sTranslitLatToRus(const tString &csStr);	
		static tString      sFormatBytes     (double dBytes);
		static tString      sFormatBytes     (ULONGLONG ullBytes);

		static std::wstring sStrToWStr       (const std::string  &csStr,  UINT uiCodePage);
		static std::string  sWStrToStr       (const std::wstring &cwsStr, UINT uiCodePage);

		static std::string  sConvertCodePage (const std::string &csSource, UINT uiCodePageSource, UINT uiCodePageDest);

		static std::string  asCharToOemBuff  (const tString     &csSrc);
		static tString      sOemToCharBuff   (const std::string &csSrc);



		/****************************************************************************
		*    <stdlib.h>
		*
		*****************************************************************************/
		
		static tString      sIntToStr        (INT       iValue,    INT iRadix);
		static tString      sIntToStr        (LONG      liValue,   INT iRadix);
		static tString      sIntToStr        (ULONG     ulValue,   INT iRadix);
		static tString      sIntToStr        (LONGLONG  i64Value,  INT iRadix);
		static tString      sIntToStr        (ULONGLONG ui64Value, INT iRadix);


		/****************************************************************************
		*    ������
		*
		*****************************************************************************/

		static tString      sCreateGUID      ();  
		static BOOL         bIsRepeated      (const tString &csStr); 
		static tString      sLastErrorStr    (ULONG ulLastError);	

		//---------------------------------------------------------------------------
		//TODO: + vPrintStdVectorT (������ � ������� std::vector) 
		template<class T>
		static 
		VOID vPrintStdVectorT(const std::vector<T> &t) {
			std::cout << std::endl << _T("Printing std::vector contents...") << std::endl << std::endl;

			std::vector<T>::const_iterator it;
			
			for (it = t.begin(); it != t.end(); ++ it){
				tcout << _T("Value: [") << (*it) << _T("]") << std::endl;
			}
			
			tcout << std::endl << std::endl;
		}
		//---------------------------------------------------------------------------
		//TODO: + vPrintStdMultiMapT (������ � ������� std::multimap) 
		template<class T1, class T2>
		static 
		VOID vPrintStdMultiMapT(const std::multimap<T1, T2> &t) { 
			tcout << std::endl << _T("Printing std::multimap contents...") << std::endl << std::endl;
			
			std::multimap<T1, T2>::const_iterator it;
			
			for (it = t.begin(); it != t.end(); ++ it) {
				tcout << _T("Key: [") << (*it).first << _T("]") << _T("\t\t") 
					  << _T("Value: [") << (*it).second << _T("]") << std::endl;
			}

			tcout << std::endl << std::endl;
		}
		//---------------------------------------------------------------------------

	private:	   
		 CxString();
		~CxString();
};
//---------------------------------------------------------------------------
#endif	//XLib_CxStringH



/*
std::string str("i am string");
std::vector<unsigned char> data;//i am array
std::copy(str.begin(), str.end(), std::back_inserter(data));
*/

/*
std::string str = ("trololo");
std::wstring wstr(str.begin(),str.end());
str = std::string(wstr.begin(),wstr.end());
*/


// Some ATL string conversion enhancements
// ATL's string conversions allocate memory on the stack, which can
// be undesirable if converting huge strings.  These enhancements
// provide for a pre-allocated memory block to be used as the 
// destination for the string conversion.
//#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
//#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)

//typedef std::wstring StringW;
//typedef std::string  StringA;
//
//#ifdef _UNICODE
//	typedef StringW String;
//	#define _W2T(dst,src) lstrcpyW(dst,src)
//	#define _T2W(dst,src) lstrcpyW(dst,src)
//	#define _T2A(dst,src) _W2A(dst,src)
//	#define _A2T(dst,src) _A2W(dst,src)
//#else
//	typedef StringA String;
//	#define _W2T(dst,src) _W2A(dst,src)
//	#define _T2W(dst,src) _A2W(dst,src)
//	#define _T2A(dst,src) lstrcpyA(dst,src)
//	#define _A2T(dst,src) lstrcpyA(dst,src)
//#endif



