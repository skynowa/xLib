/****************************************************************************
* Class name:  CxGdiplus
* Description: GDI+
* File name:   CxGdiplus.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.05.2010 15:58:39
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_GdiPlus_CxGdiplusH
#define XLib_GdiPlus_CxGdiplusH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <GDIPlus.h>

#pragma comment (lib, "Gdiplus.lib")
//---------------------------------------------------------------------------
class CxGdiplus : public CxNonCopyable {
	public:
		          CxGdiplus();
	             ~CxGdiplus();
	private:
		ULONG_PTR _m_pulToken;
};
//---------------------------------------------------------------------------
#endif //XLib_GdiPlus_CxGdiplusH
