/****************************************************************************
* Class name:  CxFunctorT
* Description: �������
* File name:   CxFunctorT.h
* Compilers:   Visual C++ 2010, C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     30.09.2010 15:28:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxFunctorH
#define CxFunctorH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
template <class ClassT, typename ReturnT, typename ParameterT>
class CxFunctorT {
	public:
		typedef ReturnT   (ClassT::*Method)(ParameterT);

		        CxFunctorT(ClassT *pObject, Method method);

		ReturnT operator()(ParameterT Parameter);
		ReturnT Execute   (ParameterT Parameter);

	private:
		ClassT *_m_pObject;
		Method  _m_Method;
};
//---------------------------------------------------------------------------
#include <CxFunctorT.inl>
//---------------------------------------------------------------------------
#endif //CxFunctorH
