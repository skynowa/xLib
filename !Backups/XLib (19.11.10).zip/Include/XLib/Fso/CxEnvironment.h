/****************************************************************************
* Class name:  CxEnvironment
* Description: ���������� ���������
* File name:   CxEnvironment.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.04.2010 17:43:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CxEnvironmentH
#define XLib_Fso_CxEnvironmentH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxEnvironment : public CxNonCopyable {
	public:
	   	static tString sGetVar		 (const tString &csVar);
		static BOOL    bSetVar		 (const tString &csVar, const tString &csValue);
		static BOOL    bGetStrings   (std::vector<tString> *pvecsEnvStrings);
		static tString sExpandStrings(const tString &csvVar);

	private:
		CxEnvironment();
	   ~CxEnvironment();
};
//---------------------------------------------------------------------------
#endif //XLib_Fso_CxEnvironmentH



