/****************************************************************************
* Class name:  CxSingleton
* Description: ���������
* File name:   CxSingleton.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.06.2010 11:17:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Patterns_CxSingletonH
#define XLib_Patterns_CxSingletonH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
template <class T>
class CxSingleton {
	public:
		static CxSingleton &Instance();

	private:
		CxSingleton();
	   ////~CxSingleton();
	
};
//---------------------------------------------------------------------------
#include <XLib/Patterns/CxSingleton.h>
//---------------------------------------------------------------------------
#endif //XLib_Patterns_CxSingletonH




/*
class OnlyOne {
	private:
		OnlyOne()
		{
		}
 
	public:
		static OnlyOne& Instance()
		{
			static OnlyOne theSingleInstance;
			return theSingleInstance;
		}
 
		// ...
};
*/
