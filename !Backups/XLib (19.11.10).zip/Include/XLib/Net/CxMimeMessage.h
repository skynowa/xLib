/****************************************************************************
* Class name:  CxMimeMessage
* Description: �������� ��������� (RFC 822)
* File name:   CxMimeMessage.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     06.07.2009 19:09:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Net_CxMimeMessageH
#define XLib_Net_CxMimeMessageH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Net/CxMimeHeader.h>
#include <XLib/Net/CxMimeBody.h>
//---------------------------------------------------------------------------
class CxMimeMessage : public CxNonCopyable {
	public:
				CxMimeMessage();
			   ~CxMimeMessage(); 
		static BOOL bParse          (const tString &csRawMessage, CxMimeHeader &Header, CxMimeBody &Body); 
		static BOOL	bLoadFromRawFile(const tString &csFilePath);	   //csFilePath - raw msg
		static BOOL bSaveToRawFile  (const tString &csFilePath);       //csFilePath - raw msg
	   
	private:
		tString _m_csRawMessage;
};
//---------------------------------------------------------------------------
#endif	//XLib_Net_CxMimeMessageH
