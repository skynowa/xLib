/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef XLib_Net_CXServerSocketH
#define XLib_Net_CXServerSocketH 
//---------------------------------------------------------------------------
#include <XLib/Net/CxSocket.h>
//#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxTcpServerSocket : public CxSocket { 
    public: 
                	CxTcpServerSocket ();
        virtual    ~CxTcpServerSocket (); 

    	BOOL        bBind             (USHORT usPort); 
     	BOOL        bListen           (INT iBacklog/* = SOMAXCONN*/);  
		BOOL        bAccept           (CxTcpServerSocket *pscktAcceptSocket, tString *psFromIp); 

	protected: 
		timeval     _m_tvTimeout;
}; 
//---------------------------------------------------------------------------
#endif	//XLib_Net_CXServerSocketH



/*
Server

Initialize Winsock.
Create a socket.
Bind the socket.
Listen on the socket for a client.
Accept a connection from a client.
Receive and send data.
Disconnect.
*/