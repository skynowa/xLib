/****************************************************************************
* Class name:  CxDnsClient
* Description: DNS
* File name:   CxDnsClient.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     17.06.2010 12:59:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Net_CxDnsClientH
#define XLib_Net_CxDnsClientH
//---------------------------------------------------------------------------
#include <winsock2.h>
#pragma comment(lib, "Ws2_32.lib") 
#include <ws2tcpip.h>
#include <Wspiapi.h>

#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDnsClient : public CxNonCopyable {
	public:
		enum EAddressFamily {
			afInet    = AF_INET,		//The Internet Protocol version 4 (IPv4) address family.
			afNetBios = AF_NETBIOS,		//The NetBIOS address family
			afInet6   = AF_INET6		//The Internet Protocol version 6 (IPv6) address family.
		};

		static BOOL bGetHostAddrByName  (const tString &csHostName, tString *psHostAddr);
		static BOOL bGetHostNameByAddr  (const tString &csHostAddr, EAddressFamily afFamily, tString *psHostName);
		static BOOL bGetLocalHostName   (tString *psHostName);
		////static BOOL bGetNameInfo    (EAddressFamily afFamily, const tString &csHostAddr, USHORT usPort);
		static BOOL bGetHostAddrInfo    (const tString &csHostName, const tString &csPort, const ADDRINFOT *pHints, PADDRINFOT *ppResult);


		//TODO: ������� ����� �������
		static BOOL bGetProtocolByName  (const tString &csProtocolName, tString *psName, std::vector<tString> *pvecsAliases, SHORT *psiNumber);
		static BOOL bGetProtocolByNumber(SHORT siNumber, tString *psName, std::vector<tString> *pvecsAliases, SHORT *psiNum);

		//TODO: ������� ����� �������
		static BOOL bGetServiceByName   (const tString &csServiceName, const tString &csProtocolName, tString *psName, std::vector<tString> *pvecsAliases, SHORT *psiPort,  tString *psProtocolName);
		static BOOL bGetServiceByPort   (SHORT siPort, const tString &csProtocolName, tString *psName, std::vector<tString> *pvecsAliases, SHORT *psiPort,  tString *psProtocolName);




	private:
		static BOOL _ms_bRes; 
		static INT  _ms_iRes; 

					CxDnsClient   ();
		virtual    ~CxDnsClient   ();
};
//---------------------------------------------------------------------------
#endif //XLib_Net_CxDnsClientH




////- GetAddressByName

////+ getaddrinfo
////+ GetAddrInfoW
////+ freeaddrinfo
////+ FreeAddrInfoW

////- GetAddrInfoEx
////- SetAddrInfoEx
////- FreeAddrInfoEx

////+ gethostbyname
////+ gethostbyaddr
////+ gethostname

////GetNameByType
////GetTypeByName

////getnameinfo
////GetNameInfoW


////+ getprotobyname
////+ getprotobynumber
////+ getservbyname
////+ getservbyport

