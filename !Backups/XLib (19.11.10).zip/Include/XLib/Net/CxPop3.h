/****************************************************************************
* Class name:  CxPop3
* Description: Pop3 ������
* File name:   CxPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef XLib_Net_CxPop3H 
#define XLib_Net_CxPop3H 
//---------------------------------------------------------------------------
#include <XLib/Net/CxSocketInit.h> 
#include <XLib/Net/CxTcpClientSocket.h> 
#include <XLib/Net/CxDnsClient.h> 
#include <XLib/xCommon.h>
#include <XLib/Net/CxMimeMessage.h> 
#include <XLib/Log/CxConsoleLog.h>
#include <XLib/Log/CxTraceLog.h>
//---------------------------------------------------------------------------
class CxPop3 : public CxNonCopyable { 
	public: 
                    	  CxPop3              (); 
                    	 ~CxPop3              (); 

		BOOL              bCreate             (const tString &csUser, const tString &csPass, const tString &csServer, USHORT usPort); 
		BOOL              bConnect            (); 
 		BOOL              bLogin              (); 
 		
		BOOL              bStat               (ULONG &ulSum, ULONG &ulSize); 
		BOOL              bList               (std::vector<ULONG> &veculList);	
		BOOL              bListAt             (ULONG &ulIndex); 
		BOOL              bNoop               ();
		BOOL              bRset               ();
		BOOL              bTop                (INT iNum, INT iLines, tString &sBuff); 
		
		BOOL      /*RETR*/bRetrive            (INT iNum, const tString &csRawMimeMessage); 
		BOOL      /*RETR*/bRetriveRaw         (INT iNum, const tString &csDirPath, const tString &csFileName);  
		BOOL      /*RETR*/bRetriveRawAndBackup(INT iNum, const tString &csDirPath, const tString &csBackupDirPath, const tString &csFileName);  
		BOOL      /*TOP*/ bRetrieveHeader     (INT iNum, CxMimeHeader &mhMimeHeader); 
		
		BOOL              bDelete             (INT iNum); 
		BOOL              bDisconnect         (); 
		
	private:
		BOOL              _m_bRes;
		tString           _m_sRes;
		/////CxSocketInit      _m_siInit;
		CxTcpClientSocket _m_scktSocket; 
		CxConsoleLog      _m_clLog;
		tString			  _m_sUser; 
		tString           _m_sPass; 
		tString           _m_sServer; 
		USHORT            _m_usPort; 
	    BOOL              _m_bConnected;

		BOOL              _bCommand           (const tString &csCmd, const tString &csReplyDelimiter, tString *psReply);   
		BOOL              _bIsError           (const tString &csText);   
		ULONG             _ulMailsSum         (const tString &csServerAnswer); 
		ULONG             _ulMailsSize        (const tString &csServerAnswer); 
}; 
//---------------------------------------------------------------------------
#endif	//XLib_Net_CxPop3H 

/*
RFC 1225

USER <SP> name <CRLF>
PASS <SP> secret <CRLF>
STAT <CRLF>
LIST <SP> [msg] <CRLF>
LIST <CRLF>
RETR <SP> msg <CRLF>
DELE <SP> msg <CRLF>
NOOP <CRLF>
LAST <CRLF>
RSET <CRLF>
QUIT <CRLF>
*/