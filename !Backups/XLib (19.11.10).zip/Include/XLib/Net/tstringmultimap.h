#ifndef TStringMultiMapH 
#define TStringMultiMapH 
//---------------------------------------------------------------------------
struct CompareNoCase
{
	bool operator () (const tString &csStr1, const tString &csStr2) const 
	{
		bool bRes = ::lstrcmpi(csStr1.c_str(), csStr2.c_str()) < 0;

		return bRes;
	}
};

typedef std::multimap<tString, tString, CompareNoCase> TStringMultiMap;
//---------------------------------------------------------------------------
#endif