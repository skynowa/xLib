/****************************************************************************
* Class name:  CxSocket
* Description: ����������� �����
* File name:   CxSocket.h
* String type: Ansi (������ �� ������ ��������������!!!)
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef XLib_Net_CxSocket
#define XLib_Net_CxSocket 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxSocket : public CxNonCopyable { 
    public: 
		/****************************************************************************
		* ���������
		*
		*****************************************************************************/

		//���������
		enum EAddressFamily {
			afUnspecified = AF_UNSPEC, 			//The address family is unspecified.
			afIPv4        = AF_INET,			//The Internet Protocol version 4 (IPv4) address family
			afIPX         = AF_IPX,				//The IPX/SPX address family
			afAppleTalk   = AF_APPLETALK,		//The AppleTalk address family
			afNetBIOS     = AF_NETBIOS,			//The NetBIOS address family 
			afIPv6        = AF_INET6,			//The Internet Protocol version 6 (IPv6) address family
			afIrDA        = AF_IRDA,			//The Infrared Data Association (IrDA) address family
			////BC++: afBluetooth   = AF_BTH				//The Bluetooth address family
		};

		//��� ������
		enum EType {
			tpStream 	  = SOCK_STREAM,		//A socket type that provides sequenced, reliable, two-way, connection-based byte streams with an OOB data transmission mechanism
			tpDgram  	  = SOCK_DGRAM,			//A socket type that supports datagrams, which are connectionless, unreliable buffers of a fixed (typically small) maximum length
			tpRaw    	  = SOCK_RAW,			//A socket type that provides a raw socket that allows an application to manipulate the next upper-layer protocol header
			tpRdm    	  = SOCK_RDM,			//A socket type that provides a reliable message datagram
			tpSeqPacket   = SOCK_SEQPACKET		//A socket type that provides a pseudo-stream packet based on datagrams
		};

		//��������
		enum EProtocol {
			ptIp          = IPPROTO_IP,			//dummy for IP
			ptIcmp        = IPPROTO_ICMP,		//The Internet Control Message Protocol (ICMP)
			ptIgmp        = IPPROTO_IGMP,		//The Internet Group Management Protocol (IGMP)
			//ptRfcomm      = BTHPROTO_RFCOMM,	//The Bluetooth Radio Frequency Communications (Bluetooth RFCOMM) protocol
			ptTcp         = IPPROTO_TCP,		//The Transmission Control Protocol (TCP)
			ptUdp         = IPPROTO_UDP,		//The User Datagram Protocol (UDP)
			ptIcmpv6      = IPPROTO_ICMPV6,		//The Internet Control Message Protocol Version 6 (ICMPv6)
			//ptRm          = IPPROTO_RM		//The PGM protocol for reliable multicast
		};

    	//������ ������
		enum EErrorType {
			etInvalid = INVALID_SOCKET,          
			etError   = SOCKET_ERROR        
		};	

		//���������
		struct CxOptions {
			static const INT SOCKET_TIMEOUT   = 0;		 //(1000000 / 10)  		//�������� �������� � �������������          
			static const INT SOCKET_BUFF_SIZE = 32768;    // 32 KB      /*8192*//*1024*/    
		};

        
					CxSocket           (); 
        virtual    ~CxSocket           () = 0;  

		BOOL        bAssign            (SOCKET scktSocket);

		/****************************************************************************
		* operators
		*
		*****************************************************************************/

		CxSocket& operator =           (SOCKET s); 
		          operator SOCKET      (); 


		/****************************************************************************
		* 
		*
		*****************************************************************************/

    	BOOL        bCreate            (EAddressFamily afFamily, EType tpType, EProtocol ptProtocol); 
		SOCKET      iGetSocket         ();  
		BOOL        bIsValid           () const;
		BOOL        bIsReadable        ();
		BOOL        bIoctl             (LONG liCmd, ULONG *pulArgp);
		BOOL        bSetNonBlockingMode(const BOOL cbFlag);
		BOOL        bGetTimeout        (LONG *pliSec, LONG *pliMicroSec);
		BOOL        bSetTimeout        (LONG liSec,   LONG liMicroSec);
 		BOOL        bClose             ();    	


		/****************************************************************************
		* I/O
		*
		*****************************************************************************/

		INT         iSend              (LPCTSTR pcszBuff, INT iBuffSize, INT iFlags);	//<<
		BOOL        bSendAll           (const tString &csBuff, INT iFlags);			//<<
    	
		INT         iRecv              (LPTSTR  pszBuff,  INT iBuffSize, INT iFlags);		//<<
		tString     sRecvAll           (INT iFlags);									//<<
		tString     sRecvAll           (INT iFlags, const tString &csDelimiter);	//<<

		INT         iSendBytes         (LPSTR pszBuff, INT iMessageLength);				//<<
		INT         iReceiveBytes      (LPSTR pszBuff, INT iStillToReceive);			//<<


		/****************************************************************************
		* Other 
		*
		*****************************************************************************/

		BOOL		bGetPeerName       (tString *psPeerAddr, USHORT *pusPeerPort);
		BOOL		bGetSocketName     (tString *psSocketAddr, USHORT *pusSocketPort);
		////getsockopt
		/*static*/ INT  iSelect        (INT nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds);

		
		/****************************************************************************
		* static 
		*
		*****************************************************************************/
		
    	static INT  iGetLastError      (); 
		
	protected: 
		BOOL        _m_bRes;
		INT         _m_iRes;
		static INT  _ms_iRes;

		SOCKET      _m_puiSocket; 
		SHORT       _m_siFamily;
		tString     _m_sIp;
		USHORT      _m_usPort;
    	timeval     _m_tvTimeout;

	private:
}; 
//---------------------------------------------------------------------------
#endif	//XLib_Net_CxSocket


/*

tString sStr = _T("Some string!!!");
::send(0, reinterpret_cast<char const*>(sStr.data()), sStr.size() * sizeof(tString::value_type), 0);

sizeof(tString::value_type)

*/
/*
---Server-----

Initialize Winsock.
Create a socket.
Bind the socket.
Listen on the socket for a client.
Accept a connection from a client.
Receive and send data.
Disconnect.
---Client----

Initialize Winsock.
Create a socket.
Connect to the server.
Send and receive data.
Disconnect.
*/