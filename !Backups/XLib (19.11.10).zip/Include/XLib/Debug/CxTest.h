/****************************************************************************
* Class name:  CxTest
* Description: ������������
* File name:   CxTest.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 9:29:52
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Debug_CxTestH
#define XLib_Debug_CxTestH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Fso/CxEnvironment.h>
#include <XLib/Fso/CxDir.h>
#include <XLib/Fso/CxPath.h>
//---------------------------------------------------------------------------
class CxTest : public CxNonCopyable {
	public:
		BOOL							m_bRes;
		INT								m_iRes;
		SHORT							m_siRes;
		USHORT							m_usiRes;
		UINT							m_uiRes;
		ULONG							m_ulRes;
		LONGLONG						m_llRes;
		ULONGLONG						m_ui64Res;
		double							m_dRes;
		HANDLE							m_hRes;
		HWND							m_hwndRes;
		tString							m_sRes;
		uString							m_usRes;
		std::vector<tString>			m_vecsRes; 
		std::map<tString, tString>		m_mapsRes;
		std::multimap<tString, tString> m_mmsRes;

		                                CxTest         ();
		virtual                        ~CxTest         () = 0;

		BOOL                            bRun		   (ULONGLONG ui64Loops /*0 - infinite*/);
		virtual BOOL                    bUnit		   () = 0;
		tString                         sGetWorkDirName();
		BOOL                            bSetWorkDirName(const tString &csDirName);
	
	private:
		BOOL                           _m_bRes;
		tString                        _m_sWorkDir;
};
//---------------------------------------------------------------------------
#endif //XLib_Debug_CxTestH
