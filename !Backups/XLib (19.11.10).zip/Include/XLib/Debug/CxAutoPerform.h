/****************************************************************************
* Class name:  CxAutoPerform
* Description: ����� ������������������ ���� � �����
* File name:   CxAutoPerform.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     05.07.2010 16:27:50
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Debug_CxAutoPerformH
#define XLib_Debug_CxAutoPerformH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Debug/CxPerform.h>
//---------------------------------------------------------------------------
class CxAutoPerform : public CxNonCopyable {
	public:
		          CxAutoPerform(const tString &csFilePath, CxPerform::EMode pmMode, LPCTSTR pcszComment, ...);
	             ~CxAutoPerform();
	
	private:
		CxPerform _m_pfPerform;
		tString   _m_sComment;
};
//---------------------------------------------------------------------------
#endif //XLib_Debug_CxAutoPerformH
