/****************************************************************************
* Class name:  CxTodo
* Description: TODO ����� Error List
* File name:   CxTodo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.12.2009 16:19:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Debug_CxTodoH
#define XLib_Debug_CxTodoH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxTodo : public CxNonCopyable {
	public:
	
	private:
		CxTodo();
	   ~CxTodo();
};
//---------------------------------------------------------------------------
#define xSTRINGIZE2(x) #x
#define xSTRINGIZE(x)  xSTRINGIZE2(x)
#define xTODO(text_)   message(__FILE__ "(" xSTRINGIZE(__LINE__) ") [" __FUNCTION__ "]: warning TODO: [" __FUNCTION__ "] " ## text_)
#define xTODO_IMPL     xTODO("Implement " __FUNCTION__ " function!")
//---------------------------------------------------------------------------
#endif	//XLib_Debug_CxTodoH