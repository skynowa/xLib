/****************************************************************************
* Class name:  CxPerform
* Description: ����� ������������������ ����
* File name:   CxPerform.h
* String type: Ansi (tString)
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#ifndef XLib_Debug_CxPerformH
#define XLib_Debug_CxPerformH       
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Log/CxFileLog.h>
#include <XLib/CxDateTime.h>
//---------------------------------------------------------------------------
class CxPerform : public CxNonCopyable {
	public:
		//Perfomance mode
		enum EMode {
			pmTime,				//�����    
			pmTickCount,		//��������   (msec)
			pmPerformanceCount,	//�����      (msec)
			pmThreadTimes,		//��������   (msec)
			pmClock             //std::clock (msec)
		};
		
		              CxPerform(const tString &csFilePath, EMode pmMode); //TODO: csFileName + iPerfomMode
		             ~CxPerform();

		BOOL          bStart   ();
		BOOL          bStop    (LPCTSTR pcszComment, ...);
        BOOL          bPulse   (LPCTSTR pcszComment, ...);   

    private:
	    BOOL          _m_bRes;
		EMode		  _m_pmModeNow;		 
        BOOL          _m_bIsStarted;
		CxFileLog     _flLog;

		//pmTime
		CxDateTime    _m_dtTimesStart;
		CxDateTime    _m_dtTimesStop;

		//pmTickCount
		ULONG         _m_ulTicksStart;
		ULONG         _m_ulTicksStop;
		
        //pmPerformanceCount
		LARGE_INTEGER _m_liCountersPerfFreq;	//Ticks per second
		LARGE_INTEGER _m_liCountersStart;
		LARGE_INTEGER _m_liCountersStop;
		
		//pmThreadTimes
		FILETIME      _m_lpCreationTime;  
		FILETIME      _m_lpExitTime;
		FILETIME      _m_lpKernelTimeStart;
		FILETIME      _m_lpUserTimeStart;
		FILETIME      _m_lpKernelTimeStop;
		FILETIME      _m_lpUserTimeStop;

		//pmClock
		std::clock_t  _m_ctClocksStart;
		std::clock_t  _m_ctClocksStop;

		BOOL          _bResetData();
};
//---------------------------------------------------------------------------
#endif	//XLib_Debug_CxPerformH