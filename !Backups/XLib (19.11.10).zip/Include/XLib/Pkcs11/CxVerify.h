/****************************************************************************
* Class name:  CxVerify
* Description: Pkcs11 �������� �������
* File name:   CxVerify.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:14:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Pkcs11_CxVerifyH
#define XLib_Pkcs11_CxVerifyH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Pkcs11/Common.h>
#include <XLib/Pkcs11/CxPkcs11.h>
#include <XLib/Pkcs11/CxSession.h>
//---------------------------------------------------------------------------
class CxVerify : public CxNonCopyable {
	public:
		                     CxVerify    (const CxPkcs11 &cPkcs11, const CxSession &cSession);
	                        ~CxVerify    ();
	
		BOOL                 bInit	     (CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);
		BOOL                 bMake	     (CK_BYTE_PTR pData, CK_ULONG ulDataLen, CK_BYTE_PTR pSignature, CK_ULONG ulSignatureLen);         
		BOOL                 bFinal	     (CK_BYTE_PTR pSignature, CK_ULONG ulSignatureLen);    
		BOOL                 bRecoverInit(CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);
		BOOL                 bRecover	 (CK_BYTE_PTR pSignature, CK_ULONG ulSignatureLen, CK_BYTE_PTR pData, CK_ULONG_PTR pulDataLen);		
		BOOL                 bUpdate	 (CK_BYTE_PTR pPart, CK_ULONG ulPartLen);   
	private:
		BOOL                 _m_bRes;
		CK_RV                _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_Pkcs11_CxVerifyH