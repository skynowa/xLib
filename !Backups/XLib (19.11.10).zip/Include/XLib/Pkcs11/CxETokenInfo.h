/****************************************************************************
* Class name:  CxETokenInfo
* Description: ���������� � eToken
* File name:   CxETokenInfo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:53:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Pkcs11_CxETokenInfoH
#define XLib_Pkcs11_CxETokenInfoH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Pkcs11/Common.h>
#include <XLib/Pkcs11/CxPkcs11.h>
//---------------------------------------------------------------------------
class CxETokenInfo : public CxNonCopyable {
	public:
		tString               sCkaSapiCardId;
		tString               sCkaSapiCardType;
		tString               sCkaSapiCardVersion;
		tString               sCkaSapiCaseModel;
		tString               sCkaSapiColor;
		tString               sCkaSapiFips;
		tString               sCkaSapiFipsSupported;
		tString               sCkaSapiFwRevision;
		tString               sCkaSapiFwVersion;
		tString               sCkaSapiHasBattery;
		tString               sCkaSapiHasLcd;
		tString               sCkaSapiHasSo;
		tString               sCkaSapiHasUser;
		tString               sCkaSapiHmacSha1;
		tString               sCkaSapiHmacSha1Supported;
		tString               sCkaSapiHwInternal;
		tString               sCkaSapiHwVersion;
		tString               sCkaSapiInitPinReq;
		tString               sCkaSapiMayInit;
		tString               sCkaSapiModel;
		tString               sCkaSapiProductionDate;
		tString               sCkaSapiProductName;
		tString               sCkaSapiRealColor;
		tString               sCkaSapiRsa2048;
		tString               sCkaSapiRsa2048Supported;
		tString               sCkaSapiSerial;
		tString               sCkaSapiTokenId;
		tString               sClockOnToken;
		tString               sDualCryptoOperations;
		tString               sFirmwareVersionMajor;
		tString               sFirmwareVersionMinor;
		tString               sFreePrivateMemory;
		tString               sFreePublicMemory;
		tString               sHardwareVersionMajor;
		tString               sHardwareVersionMinor;
		tString               sHasProtectedAuthenticationPath;
		tString               sIsWriteProtected;
		tString               sLabel;
		tString               sLoginRequired;
		tString               sManufacturerId;
		tString               sMaxPinLen;
		tString               sMaxRwSessionCount;
		tString               sMaxSessionCcount;
		tString               sMinPinLen;
		tString               sModel2;
		tString               sRandomNumberGenerator;
		tString               sRestoreKeyNotNeeded;
		tString               sRsaMechanismMaxKeySize;
		tString               sSerialNumber;
		tString               sSessionCount;
		tString               sTotalPrivateMemory;
		tString               sTotalPublicMemory;
		tString               sUsersPinIsSet;
		
		                      CxETokenInfo(const CxPkcs11 &cPkcs11);
	                         ~CxETokenInfo();
			
	private:
		BOOL                  _m_bRes;
		CK_RV                 _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
};
//---------------------------------------------------------------------------
#endif	//XLib_Pkcs11_CxETokenInfoH
