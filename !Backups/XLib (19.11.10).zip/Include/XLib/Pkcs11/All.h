/****************************************************************************
* Class name:  All
* Description: ��� ������������ �����
* File name:   All.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:56:53
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Pkcs11_AllH
#define XLib_Pkcs11_AllH
//---------------------------------------------------------------------------
#include <XLib/Pkcs11/Common.h>

#include <XLib/Pkcs11/CxUtils.h>
#include <XLib/Pkcs11/CxPkcs11.h>
#include <XLib/Pkcs11/CxFunction.h>
#include <XLib/Pkcs11/CxSlot.h>
#include <XLib/Pkcs11/CxSession.h>
#include <XLib/Pkcs11/CxLogin.h>
#include <XLib/Pkcs11/CxInfo.h>
////#include <XLib/Pkcs11/CxeTokenInfo.h>
#include <XLib/Pkcs11/CxPin.h>
#include <XLib/Pkcs11/CxMechanism.h>
#include <XLib/Pkcs11/CxObject.h>
#include <XLib/Pkcs11/CxKey.h>
#include <XLib/Pkcs11/CxEncrypt.h>
#include <XLib/Pkcs11/CxDecrypt.h>
#include <XLib/Pkcs11/CxDigest.h>
#include <XLib/Pkcs11/CxSign.h>
#include <XLib/Pkcs11/CxVerify.h>
//---------------------------------------------------------------------------
#endif	//XLib_Pkcs11_AllH