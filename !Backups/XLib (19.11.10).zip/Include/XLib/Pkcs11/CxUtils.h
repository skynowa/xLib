/****************************************************************************
* Class name:  CxUtils
* Description: Pkcs11 �������
* File name:   CxUtils.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:15:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Pkcs11_CXUtilsH
#define XLib_Pkcs11_CXUtilsH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Pkcs11/Common.h>
#include <XLib/Pkcs11/CxPkcs11.h>
//---------------------------------------------------------------------------
class CxUtils : public CxNonCopyable {
	public:
        static tString sErrorStr(CK_RV ulRes);

	private:
			           CxUtils  ();
			          ~CxUtils  ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Pkcs11_CXUtilsH