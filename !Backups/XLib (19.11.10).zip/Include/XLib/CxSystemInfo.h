/****************************************************************************
* Class name:  CxSystemInfo
* Description: ��������� ����������
* File name:   CxSystemInfo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CxSystemInfoH
#define XLib_CxSystemInfoH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxSystemInfo : public CxNonCopyable {
   public:
	  enum EOsType {
		 osUnknown     = 0,
		 osWindows95   = 1,
		 osWindows98   = 2,
		 osWindowsNT   = 3,
		 osWindows2000 = 4,
		 osWindowsXP   = 5,
		 osWindows2003 = 6,
		 osWindows3    = 7
	  };

	  static EOsType osGetOS         ();
	  static tString sFormatOSVerson (ULONG ulOSVersion);
	  static tString sGetComputerName();
	  static tString sGetUserName    ();
	  static ULONG   ulGetNumOfCPUs  ();
	  ////static ULONG   ulGetCurrCPUNum ();  Vista
	  static BOOL    bIsUnicodeOS    ();

   private:
	                 CxSystemInfo    ();
	                ~CxSystemInfo    ();
};
//---------------------------------------------------------------------------
#endif	//XLib_CxSystemInfoH