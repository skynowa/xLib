/****************************************************************************
* Class name:  xLog.h
* Description: �� �����������
* File name:   CxTraceLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_xLogH
#define XLib_Log_xLogH
//---------------------------------------------------------------------------
#include <XLib/Log/CxConsoleLog.h>
#include <XLib/Log/CxDbLog.h>
#include <XLib/Log/CxEventLog.h>
#include <XLib/Log/CxFileLog.h>
#include <XLib/Log/CxTraceLog.h>
#include <XLib/Log/CxWndLog.h>
//---------------------------------------------------------------------------
#endif	//XLib_Log_xLogH