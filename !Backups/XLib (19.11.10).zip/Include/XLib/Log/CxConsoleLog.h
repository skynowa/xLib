/****************************************************************************
* Class name:  CxConsoleLog
* Description: ����������� ����� �������
* File name:   CxConsoleLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:53:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CxConsoleLogH
#define XLib_Log_CxConsoleLogH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Sync/CxCriticalSection.h>
//---------------------------------------------------------------------------
class CxConsoleLog : public CxNonCopyable {
	public:	
		                         CxConsoleLog(BOOL bIsUseTimeStr);
		virtual                 ~CxConsoleLog();

		BOOL                     bWrite      (LPCTSTR pcszFormat, ...); 
		
	private:		
		static CxCriticalSection _ms_csConsole;  
		BOOL                     _m_bIsUseTimeStr;	//���� �� �������� �����  
};
//---------------------------------------------------------------------------
#endif	//XLib_Log_CxConsoleLogH