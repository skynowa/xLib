/****************************************************************************
* Class name:  CxEventLog
* Description: ����������� ����� "Event Log"
* File name:   CxEventLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:52:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CxEventLogH
#define XLib_Log_CxEventLogH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxEventLog : public CxNonCopyable {
	public:
		        CxEventLog();
	   virtual ~CxEventLog();

	private:
};
//---------------------------------------------------------------------------
#endif	//XLib_Log_CxEventLogH