/****************************************************************************
* Lib name:    XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/xConstants.h>
#include <XLib/CxCOM.h>
#include <XLib/CxDateTime.h>
#include <XLib/CxHandleT.h>
#include <XLib/CxLocale.h>
#include <XLib/CxMallocT.h>
#include <XLib/CxNonAssignable.h>
#include <XLib/CxNonCopyable.h>
#include <XLib/CxShell.h>
#include <XLib/CxString.h>
#include <XLib/CxSystemInfo.h>
#include <XLib/xClosure.h>


//Crypt


//Debug
#include <XLib/Debug/CxAssert.h>
#include <XLib/Debug/CxPerform.h>
#include <XLib/Debug/CxTest.h>
#include <XLib/Debug/CxTodo.h>
#include <XLib/Debug/xDebug.h>

//DB


//Fso
#include <XLib/Fso/CxDir.h>
#include <XLib/Fso/CxDll.h>
#include <XLib/Fso/CxDrive.h>
#include <XLib/Fso/CxFile.h>
#include <XLib/Fso/CxIni.h>
#include <XLib/Fso/CxPath.h>
#include <XLib/Fso/CxStdioFile.h>
#include <XLib/Fso/CxEnvironment.h>
#include <XLib/Fso/CxFileAttribute.h>

//GDI+
#include <XLib/GDI+/CxGdiplus.h>
#include <XLib/GDI+/CxImage.h>

//Gui
////#include <XLib/Gui/Common.h>
////#include <XLib/Gui/CxFont.h>
////#include <XLib/Gui/CxApplication.h>
////#include <XLib/Gui/CxWindow.h>
////#include <XLib/Gui/XMessageMap.h>
////#include <XLib/Gui/CxWindowImpl.h>
////#include <XLib/Gui/CxButton.h>
////#include <XLib/Gui/CxCheckBox.h>
////#include <XLib/Gui/CxComboBox.h>
////#include <XLib/Gui/CxDialog.h>
////#include <XLib/Gui/CxEdit.h>
////#include <XLib/Gui/CxGroupBox.h>
////#include <XLib/Gui/CxImageList.h>
////#include <XLib/Gui/CxLayout.h>
////#include <XLib/Gui/CxListBox.h>
////#include <XLib/Gui/CxListView.h>
////#include <XLib/Gui/CxMsgBoxRtf.h>
////#include <XLib/Gui/CxMsgBoxT.h>
////#include <XLib/Gui/CxProgressBar.h>
////#include <XLib/Gui/CxRadioButton.h>
////#include <XLib/Gui/CxRebar.h>
////#include <XLib/Gui/CxResources.h>
////#include <XLib/Gui/CxRichEdit.h>
////#include <XLib/Gui/CxStatic.h>
////#include <XLib/Gui/CxStatusBar.h>
////#include <XLib/Gui/CxTab.h>
////#include <XLib/Gui/CxToolBar.h>
////#include <XLib/Gui/CxWaitCursor.h>
////////#include <XLib/Gui/Resource.xrc.h>
////////#include <XLib/Gui/Resource.xrc.cpp>

//Log
#include <XLib/Log/CxConsoleLog.h>
#include <XLib/Log/CxDbLog.h>
#include <XLib/Log/CxEventLog.h>
#include <XLib/Log/CxFileLog.h>
#include <XLib/Log/CxTraceLog.h>
#include <XLib/Log/CxWndLog.h>

//Net
#include <XLib/Net/CxSocket.h>
#include <XLib/Net/CxTcpClientSocket.h>
#include <XLib/Net/CxTcpServerSocket.h>
#include <XLib/Net/CxDnsClient.h>
//////#include <XLib/CxNet/CQueryList.hpp>
//////#include <XLib/CxNet/CSMTPConn.h>
//#include <XLib/Net/CxMimeHeader.h>
//#include <XLib/Net/CxPop3.h>
//#include <XLib/Net/CxSmtp.h>

//Patterns
#include <XLib/Patterns/CxSingleton.h>

//PKCS11
//#include <XLib/PKCS11/Common.h>
//#include <XLib/PKCS11/CxDecrypt.h>
//#include <XLib/PKCS11/CxDigest.h>
//#include <XLib/PKCS11/CxEncrypt.h>
//#include <XLib/PKCS11/CxeTokenInfo.h>
//#include <XLib/PKCS11/CxFunction.h>
//#include <XLib/PKCS11/CxInfo.h>
//#include <XLib/PKCS11/CxKey.h>
//#include <XLib/PKCS11/CxLogin.h>
//#include <XLib/PKCS11/CxMechanism.h>
//#include <XLib/PKCS11/CxObject.h>
//#include <XLib/PKCS11/CxPin.h>
//#include <XLib/PKCS11/CxPKCS11.h>
//#include <XLib/PKCS11/CxSession.h>
//#include <XLib/PKCS11/CxSign.h>
//#include <XLib/PKCS11/CxSlot.h>
//#include <XLib/PKCS11/CxUtils.h>
//#include <XLib/PKCS11/CxVerify.h>
//#include <XLib/PKCS11/All.h>

//Random
#include <XLib/Random/CxRandom.h>

//Sync
#include <XLib/Sync/CxCompletionPort.h>
#include <XLib/Sync/CxCriticalSection.h>
#include <XLib/Sync/CxAutoCriticalSection.h>
#include <XLib/Sync/CxEvent.h>
#include <XLib/Sync/CxMutex.h>
#include <XLib/Sync/CxAutoMutex.h>
#include <XLib/Sync/CxSemaphore.h>
#include <XLib/Sync/CxSleeper.h>
#include <XLib/Sync/CxThread.h>
#include <XLib/Sync/CxThreadPool.h>
#include <XLib/Sync/CxTls.h>
#include <XLib/Sync/CxWaitableTimer.h>
#include <XLib/Sync/CxAtomicLongInt.h>


//Other
#include <XLib/CxDateTime.h>


////#include <shellapi.h>
//---------------------------------------------------------------------------
INT _tmain(INT argc /*, char* argv[]*/) {




	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------