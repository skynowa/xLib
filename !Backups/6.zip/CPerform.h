/**********************************************************************
*	����� CPerform (CPerform.h)
*
***********************************************************************/


#pragma once

#ifndef CPerformH
#define CPerformH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <time.h>
//---------------------------------------------------------------------------
class CPerform {
	public:
		             CPerform                     (const std::string &csFileName);
		             ~CPerform                    ();
		void          vStart                      (int iPerfomMode);
		void          vStop                       ();
        void          vOpenLog                    ();
		void          vDeleteLog                  ();

    private:
		enum          {pmGetTickCount, pmQueryPerformanceCounter, pmGetThreadTimes} m_ePerfomMode;
		int           m_iPerfomModeNow;		 
        bool          m_bWasStarted;
		void          vResetData                  ();
     	void          vErrorMessageBox            ();
        std::string   sMilliSecToTimeString       (__int64 i64MilliSec); 
		
		//pmGetTickCount
		DWORD         m_dwBeginTime;
		DWORD         m_dwEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER m_liStart;
		LARGE_INTEGER m_liBeginCount;
		LARGE_INTEGER m_liEndCount;
		LARGE_INTEGER m_liCount;
		
		//GetThreadTimes
		FILETIME      m_lpCreationTime;  
		FILETIME      m_lpExitTime;
		FILETIME      m_lpKernelTime0;
		FILETIME      m_lpUserTime0;
		FILETIME      m_lpKernelTime1;
		FILETIME      m_lpUserTime1;
		__int64       iFiletimeToint64    (FILETIME F);

		//���
		std::string    m_sLogName;
		std::string    m_sLogPath;
		void           vLog               (const std::string &csFileText);
};
//---------------------------------------------------------------------------
#endif