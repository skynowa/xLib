/**********************************************************************
*	�����  CXLog (CXLog.hpp)
*
***********************************************************************/


#pragma once

#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
//---------------------------------------------------------------------------
class CXLog {
	public:
					      CXLog                 (const std::string &csFileName, unsigned long int ulMaxFileSize);
						  CXLog					(unsigned long int ulMaxFileSize);
					      ~CXLog                ();

		void              vLog                  (const std::string &csStr);
		void              vLog                  (const std::string &csComment, const std::string &csStr);
		void              vLog                  (const std::string &csComment, int iValue);
		void              vLog                  (const std::string &csComment, unsigned long int ulLastError);
					
		void              vLogCharAsHex         (const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
        void              vLogCharAsStr         (const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
		void              vLogLastErrorStr      (const std::string &csComment, unsigned long int ulLastError);	
        
		void              vLogToLst             (HWND hLst, const std::string &csStr); 
		void              vLogToLst             (HWND hLst, const std::string &csComment, const std::string &csStr); 
		void              vLogToLst             (HWND hLst, const std::string &csComment, int iValue);
		void              vLogToLst             (HWND hLst, const std::string &csComment, unsigned long int ulValue);
		void              vLogLastErrorToLst    (HWND hLst, const std::string &csComment, unsigned long int ulLastError);  

		void              vTrace                (const std::string &csStr); 
		void              vTrace                (const std::string &csComment, const std::string &csStr); 
		void              vTrace                (const std::string &csComment, int iValue);
		void              vTrace                (const std::string &csComment, unsigned long int ulValue);
		void              vTraceLastError       (const std::string &csComment, unsigned long int ulLastError);

		void              vOpen                 ();
		void              vSetMaxFileSize       (unsigned long int ulMaxFileSize);	//Mb
		void              vClear                ();
		void              vSetName              (const std::string &csFileName);
		void              vSetPath              (const std::string &csFilePath);
		void              vDelete               ();
	
	private:
		std::string       m_sLogName;
		std::string       m_sLogPath;
		unsigned long int m_ulMaxFileSize;
		
		void              vDeleteLogIfFull		();
		void              vLogLastErrStrServ	(); 
		
		CRITICAL_SECTION  m_csWriteToLog;
};
//---------------------------------------------------------------------------
#endif