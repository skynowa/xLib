/**********************************************************************
 *	����� CXFsoString (CFsoString.h)       http://www.richelbilderbeek.nl/CppFileExists.htm
 *
 ***********************************************************************/


#pragma once

#ifndef CXFsoStringH
#define CXFsoStringH       
//---------------------------------------------------------------------------
#include <string>
#include <vector>
//---------------------------------------------------------------------------
bool                            bFileExists          (const std::string &csFilePath); /*+*/
void                            vCopyFile            (const std::string &csFilePathFrom, const std::string &csFilePathTo); /*+*/
unsigned long int               ulFileLines          (const std::string &csFilePath); /*+*/

const std::vector <std::string> vecFileToVector      (const std::string &csFilePath); /*-*/
void                            vFileToArray         (const std::string &csFilePath); /*-*/
template <class T> void         vRandomShuffle       (std::vector<T> &v); /*-*/
template <class T> void         vSortVector          (std::vector<T> &v); /*-*/

std::string						sExePath             (); /*+*/
std::string						sExtractFilePath     (const std::string &csFilePath); /*+*/
std::string                     sExtractFullFileName (const std::string &csFilePath); /*+*/
std::string                     sExtractShortFileName(const std::string &csFilePath); /*+*/
std::string                     sExtractFileExt      (const std::string &csFilePath); /*+*/

std::string                     sChangeFileExt       (const std::string &csFilePath, const std::string &csFileExt); /*+*/
std::string                     sChangeFullFileName  (const std::string &csFilePath, const std::string &csFileName); /*+*/

std::string                     sRemoveFileExt       (const std::string &csFileName); /*+*/

bool                            bSetFileNormalAttr   (const std::string &csFilePath); /*+*/
bool                            bMoveFile            (const std::string &csFilePathIn, const std::string &csFilePathOut);	//����, ������� /*+*/
unsigned long int				ulFileSize           (FILE *pFile); /*+*/
unsigned long int				ulFileSize			 (const std::string &csFilePath); /*+*/
bool                            bCutFileFromEnd      (const std::string &csFilePath, long int lDistanceToCut);	/*+*/
bool                            bCutFileFromEnd      (FILE *pFile, unsigned long int ulDistanceToCut);	/*+*/
bool                            bDeleteFile          (const std::string &csFilePath); /*+*/
int							    iIsFile              (const std::string &csFilePath); /*+*/	//0, 1, 2	

bool							bWriteText  		 (const std::string &csFilePath, const std::string &csText);
std::string						sReadText   		 (const std::string &csFilePath);

/*
ExtractFileDir 
ExtractFileDrive 
ExtractFileExt 
ExtractFileName 
ExtractFilePath 
ExtractRelativePath 
ExtractShortPathName
*/
//---------------------------------------------------------------------------
#endif