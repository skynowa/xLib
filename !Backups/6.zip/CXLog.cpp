/**********************************************************************
*	�����  CXLog (CXLog.cpp)  
*	
***********************************************************************/


#include "CXLog.h"
#include "CXString.h"
#include "CXFsoString.h"

#include <stdio.h>
#include <stdlib.h>
//---------------------------------------------------------------------------
CXLog::CXLog(const std::string &csFileName, unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csWriteToLog);

	m_sLogName      = csFileName;
	m_sLogPath      = sExtractFilePath(sExePath()) + "\\" + m_sLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::CXLog(unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/InitializeCriticalSection(&m_csWriteToLog);

	m_sLogName      = sExtractFullFileName(sExePath());
	m_sLogPath      = sExtractFilePath(sExePath()) + "\\" + m_sLogName;
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	
	/*UNLOCK*/DeleteCriticalSection(&m_csWriteToLog);	
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vLog
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csStr) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
        fprintf_s(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csStr.c_str());	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, const std::string &csStr) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
		fprintf_s(pFile, "[%d:%d:%d]  %s --> %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csStr.c_str());	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, int iValue) {
	vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
		fprintf_s(pFile, "[%d:%d:%d]  %s --> %i\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), iValue);	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, unsigned long int ulValue) {
	vDeleteLogIfFull();
	
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
		fprintf_s(pFile, "[%d:%d:%d]  %s --> %ul\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), ulValue);	//ul?????
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrorStr(const std::string &csComment, unsigned long int ulLastError) {
	vDeleteLogIfFull();

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);

		fprintf_s(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), (LPCTSTR)lpMsgBuf);	
    }
	fclose(pFile);
	pFile = NULL;

	LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrStrServ() {
	////vDeleteLogIfFull();

	//////-------------------------------------
	//////ulLastError -> ������
	////LPVOID lpMsgBuf = NULL;

	////FormatMessage( 
	////	FORMAT_MESSAGE_ALLOCATE_BUFFER | 
	////	FORMAT_MESSAGE_FROM_SYSTEM | 
	////	FORMAT_MESSAGE_IGNORE_INSERTS,
	////	NULL,
	////	GetLastError(),
	////	MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
	////	(LPTSTR) &lpMsgBuf,
	////	0,
	////	NULL
	////);								

	//////-------------------------------------
	//////����� ���
	////FILE *pFile = NULL;
	////   if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
	////	SYSTEMTIME stST;    
	////	ZeroMemory(&stST, sizeof(stST));
	////       GetLocalTime(&stST);
	////       fprintf_s(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, "fail");
	////   } else {
	////       SYSTEMTIME stST; 
	////	ZeroMemory(&stST, sizeof(stST));
	////       GetLocalTime(&stST);
	////	fprintf_s(pFile, "[%d:%d:%d]  [Log error]  %s", stST.wHour, stST.wMinute, stST.wSecond, (LPCTSTR)lpMsgBuf);	
	////   }
	////fclose(pFile);
	////pFile = NULL;

	////LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
void CXLog::vLogCharAsHex(const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen) {
	vDeleteLogIfFull();

	////std::string sRes = "";   
	////for (unsigned int i = 0; i < ulFileTextLen; i ++) {
	////    if (pcFileText[i] < 16) {
	////           //sRes += AnsiString(0).sprintf("0x0%x ", pcFileText[i]);
	////	} else {
	////           //sRes += AnsiString(0).sprintf("0x%2x ", pcFileText[i]);
	////       }
	////}
	////
	////FILE *pFile = NULL;
	////   if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {
	////       //vErrorMessageBox();
	////   } else {
	////       SYSTEMTIME stST;
	////       GetLocalTime(&stST);
	////       fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
	////   }
	////fclose(pFile);
	////pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vLogCharAsStr(const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen) {
	vDeleteLogIfFull();

	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
        //sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
        sRes.push_back(pucFileText[i]);      //???????????
	}

	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        SYSTEMTIME stST;	memset(&stST, 0, sizeof(stST));
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vTrace
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csStr) {
	OutputDebugString((csStr + "\r\n").c_str());	//VERIFY
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csComment, const std::string &csStr) {
	OutputDebugString((csComment + "--->" + csStr + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csComment, int iValue) {
	OutputDebugString((csComment + "--->" + sTypeToStr(iValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void vTrace(const std::string &csComment, unsigned long int ulValue) {
	OutputDebugString((csComment + "--->" + sTypeToStr(ulValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void vTraceLastError(const std::string &csComment, unsigned long int ulLastError) {
	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);

	OutputDebugString((csComment + "--->" + std::string((const char *)lpMsgBuf) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csStr) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);
	
	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	//csStr
	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, const std::string &csStr) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, int iValue) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(iValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, unsigned long int ulValue) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(ulValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrorToLst(HWND hLst, const std::string &csComment, unsigned long int ulLastError) {
	/*LOCK*///EnterCriticalSection(&m_csWriteToLog);

	//-------------------------------------
	//CHECK
	if (hLst == NULL) {
		return;
	}

	//-------------------------------------
	//ulLastError -> ������
	LPVOID lpMsgBuf = NULL;

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError/*GetLastError()*/,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);								

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + std::string((LPCTSTR)lpMsgBuf);
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());

	LocalFree(lpMsgBuf);
	lpMsgBuf = NULL;

	//���������
    SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	/*UNLOCK*///LeaveCriticalSection(&m_csWriteToLog);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vDelete() {
	//-------------------------------------
	//CHECK
    if (bFileExists(m_sLogPath) == false) {
		return;
	}	
	//-------------------------------------
	//JOB
	if (false == bSetFileNormalAttr(m_sLogPath)) {
        vLogLastErrStrServ();
    }
    if (false == bDeleteFile(m_sLogPath)) {
        vLogLastErrStrServ();
    }
}
//---------------------------------------------------------------------------
void CXLog::vSetPath(const std::string &csFilePath) {
	m_sLogPath = m_sLogPath;
}
//---------------------------------------------------------------------------
void CXLog::vSetName(const std::string &csFileName) {
	m_sLogName = csFileName;
	m_sLogPath = sExtractFilePath(sExePath()) + "\\" + csFileName;
}
//---------------------------------------------------------------------------
void CXLog::vOpen() {
	STARTUPINFO si;				memset(&si, 0, sizeof(STARTUPINFO));
	PROCESS_INFORMATION pi;     memset(&pi, 0, sizeof(PROCESS_INFORMATION));
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "Notepad.exe " + m_sLogPath; 
	if (!CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	CloseHandle(pi.hThread);
	CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
void CXLog::vClear() {
	//FileExists

	FILE *pFile = NULL;
    if ((fopen_s(&pFile, m_sLogPath.c_str(), "w") != 0) && (pFile == NULL)) {
        vLogLastErrStrServ();
    } else {
        fprintf_s(pFile, "");	
    }
	fclose(pFile);
	pFile = NULL;
}
//---------------------------------------------------------------------------
void CXLog::vSetMaxFileSize(unsigned long int ulMaxFileSize) {
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
void CXLog::vDeleteLogIfFull() {
	//-------------------------------------
	//CHECK
	if (false == bFileExists(m_sLogPath)) {
		return;
	}
	
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ulFileSize(m_sLogPath) / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Other
*
*****************************************************************************/

//---------------------------------------------------------------------------
////void CXLog::vErrorMessageBox() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
////	LocalFree(lpMsgBuf);
////}
//---------------------------------------------------------------------------
////std::string CXLog::sErrorMessageStr() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	////LocalFree(lpMsgBuf);
////
////	return std::string((LPCTSTR)lpMsgBuf);
////}
//---------------------------------------------------------------------------