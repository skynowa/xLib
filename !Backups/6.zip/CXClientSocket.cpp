/**********************************************************************
*	����� CXClientSocket (CXClientSocket.cpp)
*
***********************************************************************/


#include "CXClientSocket.h"
#include "CXLog.h"

CXLog g_LogFile("___Log.log", 10);

#define LOG_STR(comment, x)   if (true == true) {g_LogFile.vLog(comment, x);}	
#define LOG_ERROR(comment, x) if (true == true) {g_LogFile.vLogLastErrorStr(comment, x);}	 
//---------------------------------------------------------------------------
CXClientSocket::CXClientSocket(const char *pcszHostName, unsigned short usPort) {	
	//-------------------------------------
	//�������� ������
	memset(&m_wsaData,    0, sizeof(m_wsaData));
	m_puiSocket = INVALID_SOCKET;
	memset(&m_saSockAddr, 0, sizeof(m_saSockAddr));
	m_phstHost  = NULL;			
	/////////--memset(m_szBuffIn, 0, 2048);

	//-------------------------------------
	//������ �����
	int iResult = WSAStartup(MAKEWORD(2, 2), &m_wsaData);	
	if (0 != iResult) {
		/*LOG*/LOG_ERROR("WSAStartup", WSAGetLastError());
		return;
	}
	m_puiSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);		//SOCK_STREAM (TCP), SOCK_DGRAM  (UDP)  m_puiSocket !== 0
	if (0 > m_puiSocket) {	//������������ ��������: ���������� ������ � ������ ������, -1 (Unix) ��� INVALID_SOCKET (Windows) � ������ ������.	//INVALID_SOCKET (- 1)
		/*LOG*/LOG_ERROR("socket", WSAGetLastError());
		bDisconnect();	
	}

	//-------------------------------------
	//resolve (IP ��� �����)
	if ('@' == pcszHostName[0]) {
		m_saSockAddr.sin_addr.s_addr = inet_addr(pcszHostName + 1);
	} else {
		//Look up for POP3 server
		m_phstHost = gethostbyname(pcszHostName);
		if (NULL == m_phstHost) {
			/*LOG*/LOG_ERROR("gethostbyname", WSAGetLastError());
			bDisconnect();	
		}

		PCHAR p = NULL;
		memmove(&p, *m_phstHost->h_addr_list, sizeof(PCHAR));
		memmove(&m_saSockAddr.sin_addr.s_addr, &p, sizeof(PCHAR));
	}

	//--printf((char *)inet_ntoa(m_saSockAddr.sin_addr));
	m_saSockAddr.sin_family = AF_INET;
	m_saSockAddr.sin_port   = htons(usPort);
}
//---------------------------------------------------------------------------
CXClientSocket::~CXClientSocket() {	
	int	iResult = SOCKET_ERROR;
	
	iResult = WSACleanup();
	if (iResult != 0) {	//0 - success
		/*LOG*/LOG_ERROR("WSACleanup", WSAGetLastError());
	}
}
//--------------------------------------------------------------------------
bool CXClientSocket::bConnect() {
	//-------------------------------------
	//����������� � ��������
	int iResult = connect(m_puiSocket, (struct sockaddr *)&m_saSockAddr, sizeof(m_saSockAddr));
	if (0 != iResult) {	//������������ ��������: 0 � �����, -1 (Unix) ��� �� 0 (Windows) � ������ ������. (SOCKET_ERROR (-1))
		/*LOG*/LOG_ERROR("connect", WSAGetLastError());
		bDisconnect();	

		return false;
	}

	return true;
}
//--------------------------------------------------------------------------
bool CXClientSocket::bSend(char *pszText) {
	/*LOG*///LOG(pszText);	
	
	//-------------------------------------
	//CHECK
	if (0 > m_puiSocket) {
		/*LOG*/LOG_STR("bSend", "iSocket == 0");
		return false;
	}
	if (NULL == pszText) {		
		/*LOG*/LOG_STR("bSend", "pszText == NULL");
		return false;
	}
	if (0 == strlen(pszText)) {
		/*LOG*/LOG_STR("bSend", "strlen(pszText) == 0");
		return false;
	}

	//-------------------------------------
	//JOB
	int iResult      = SOCKET_ERROR;
	int iSendBuffLen = static_cast<int>(strlen(pszText));	///?????

	iResult = send(m_puiSocket, pszText, iSendBuffLen, 0);	
	if (0 > iResult) {	//iResult: ����� ��������� ���� � ������ ������, -1 � ������ ������. (SOCKET_ERROR (-1))
		/*LOG*/LOG_ERROR("bSend", WSAGetLastError());
		return false;
	}
	
	//�������� ������� ���� ������
	if (strlen(pszText) != iResult) {
		/*LOG*/LOG_ERROR("�� ��� ����� ����", WSAGetLastError());
		return false;
	}

	return true;
}
//--------------------------------------------------------------------------
bool CXClientSocket::bReceive(char *pszText, const int ciRecvTextLen) {
	//-------------------------------------
	//CHECK
	if (0 > m_puiSocket) {
		/*LOG*/LOG_STR("bReceive", "iSocket < 0");
		return false;
	}
	if (NULL == pszText) {		
		/*LOG*/LOG_STR("bReceive", "pszText == NULL");
		return false;	//?????????
	}

	//-------------------------------------
	//JOB
	int iResult = SOCKET_ERROR; 

	iResult = recv(m_puiSocket, pszText, ciRecvTextLen, /*MSG_WAITALL*/0);
	if (iResult > 0) {	//iResult: ����� �������� ���� � ������ ������, -1 � ������ ������.
		/*LOG*/LOG_STR("Bytes received:", iResult);		
		*(pszText + iResult - 1) = 0;				
	} 
	if (iResult == 0) {	
		/*LOG*/LOG_ERROR("Connection closed:", WSAGetLastError());
		return false;
	} 
	if (iResult < 0) {	
		/*LOG*/LOG_ERROR("recv failed", WSAGetLastError());
		return false;
	}	

	return !bIsError(pszText);
}
//--------------------------------------------------------------------------
bool CXClientSocket::bDisconnect() {
	int	iResult = SOCKET_ERROR;

	iResult = shutdown(m_puiSocket, SD_BOTH);	 
	if (0 != iResult) {	//0 - success
		/*LOG*/LOG_ERROR("shutdown", WSAGetLastError());
		return false;
	}
	
	iResult = closesocket(m_puiSocket); 
	if (iResult != 0) {	//0 - success
		/*LOG*/LOG_ERROR("closesocket", WSAGetLastError());
		return false;
	}	
	m_puiSocket = INVALID_SOCKET;

	return true;
}
//--------------------------------------------------------------------------
bool CXClientSocket::bIsError(char *pszText) {// if (arg > 1024) arg = 1024;
	//-------------------------------------
	//CHECK
	if (NULL == pszText) {		
		/*LOG*/LOG_STR("bIsError", "pszText == NULL");
		return true;
	}
	if (0 == strlen(pszText)) {
		/*LOG*/LOG_STR("bIsError", "0 == strlen(pszText)");
		return true;
	}

	//-------------------------------------
	//JOB
	if (0 == memcmp(pszText, "+OK", 3)) {
		return false;
	} 
		
	return true;
}
//--------------------------------------------------------------------------