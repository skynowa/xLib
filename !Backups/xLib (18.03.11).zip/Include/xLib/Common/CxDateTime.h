/****************************************************************************
* Class name:  CxDateTime
* Description: date, time
* File name:   CxDateTime.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_CxDateTimeH
#define xLib_CxDateTimeH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#ifdef __BORLANDC__
	#include <vcl.h>
#endif
//---------------------------------------------------------------------------
class CxDateTime {
	public:
		//format type
		enum EFormatType {
			MMDDYY,
			DDMMYY,
			YYMMDD,
			MMDDYYYY,
			DDMMYYYY,
			YYYYMMDD
		};

		//constructors, destructor
				           CxDateTime          ();
		/*explicit*/       CxDateTime          (const CxDateTime &dtDT);
		explicit           CxDateTime          (ULONGLONG ui64MSec); /*LARGE_INTEGER*/
						   CxDateTime          (USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
						   CxDateTime          (USHORT usYear, USHORT usMonth, USHORT usDay); 
						   CxDateTime          (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec); 
		virtual 	   	  ~CxDateTime          (); 

		//comparison operators
		BOOL               operator ==         (const CxDateTime &dtDT) const;	
		BOOL               operator !=         (const CxDateTime &dtDT) const;	
		BOOL               operator <          (const CxDateTime &dtDT) const;	
		BOOL               operator <=         (const CxDateTime &dtDT) const;	
		BOOL               operator >          (const CxDateTime &dtDT) const;	
		BOOL               operator >=         (const CxDateTime &dtDT) const;	

		//assignment operators
		CxDateTime        &operator =          (const CxDateTime &dtDT);
	#ifdef __BORLANDC__
		CxDateTime        &operator =          (const TDateTime  &dtDT);	
	#endif
		CxDateTime        &operator =          (ULONGLONG ui64MSec);

		CxDateTime         operator +          (const CxDateTime &dtDT) const;	
		CxDateTime         operator -          (const CxDateTime &dtDT) const;	
		CxDateTime        &operator +=         (const CxDateTime &dtDT);
		CxDateTime        &operator -=         (const CxDateTime &dtDT);
		//++
		//--

		//get/set
		BOOL               bGet                (USHORT *pusYear, USHORT *pusMonth, USHORT *pusDay, USHORT *pusHour, USHORT *pusMinute, USHORT *pusSecond, USHORT *pusMSec) const;
		BOOL               bSet                (ULONGLONG ui64MSec);
		BOOL               bSet                (USHORT  usYear,  USHORT  usMonth,  USHORT  usDay,  USHORT  usHour,  USHORT  usMinute,  USHORT  usSecond,  USHORT  usMSec);
		
		//formating
		tString            sGetTimeStr         () const;	
		tString            sGetDateStr         () const; 	
		tString			   sGetDateTimeStr     () const; 	
	////tString            sGetDateStrLong     () const; 	
	////tString			   sGetDateTimeStrLong () const;
		
		//static
		static BOOL        bIsValid            (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
		static CxDateTime  dtGetCurrent        (); 
		////--static BOOL        bMSecToSystemTime   (ULONGLONG ui64MSec, SYSTEMTIME *stST); 
		/*static*/ BOOL        bMSecToSystemTime   (ULONGLONG ui64MSec); 
		////--static ULONGLONG   ui64SystemTimeToMSec(const SYSTEMTIME &stST); 
		/*static*/ ULONGLONG   ui64SystemTimeToMSec(); 
		////ToUniversalTime();     
		////ToLocalTime();         

		////////static tString     sMSecToTimeString  (ULONGLONG ui64MSec); 
    #if defined(xOS_WIN)
        static LONGLONG    i64FiletimeToInt64  (FILETIME ftTime);
    #endif

		static USHORT      usDaysInMonth       (USHORT usYear, USHORT usMonth);
		static BOOL        bIsLeapYear         (USHORT usYear);

		//other
		static tString     sGetZodiacSign      (USHORT usMonth, USHORT usDay);
		static tString     sGetMonthStr        (USHORT usMonth, BOOL bIsShortName);
		static tString     sGetWeekDayStr      (USHORT usDay,   BOOL bIsShortName);

   	private:
		BOOL               _m_bRes;

		////--SYSTEMTIME         _m_stDateTime;
		ULONGLONG          _m_ui64DateTimeMSec;	//LARGE_INTEGER

		USHORT			   _m_usYear;
		USHORT	           _m_usMonth;
		USHORT	           _m_usDay;
		USHORT	           _m_usHour;
		USHORT	           _m_usMinute;
		USHORT	           _m_usSecond;
		USHORT	           _m_usMSec;

		/////__time64_t         _m_time;	/*__int64*/

		/*
		http://www.rsdn.ru/forum/cpp/2099875.flat.aspx

		inline unix_t      _os_get()
		    {
		        typedef unsigned __int64 uint64_type;

		        // Смещение UNIX-эпохи (1970.01.01 00:00:00) от Win32-эпохи
		        // (1601.01.01 00:00:00).
		        const uint64_type delta =
		            (((uint64_type) 0x019DB1DE) << 32) |
		            ((uint64_type) 0xD53E8000);

		        // Определяем текущее время.
		        FILETIME ft_current;
		        ::GetSystemTimeAsFileTime( &ft_current );

		        uint64_type current =
		            ((((uint64_type) ft_current.dwHighDateTime) << 32) |
		            ((uint64_type) ft_current.dwLowDateTime)) - delta;

		        return unix_t(
		            // Определяем, сколько прошло секунд.
		            (time_t)( ( current ) / 10000000 ),
		            // А сколько микросекунд.
		            (unsigned long)( ( current % 10000000 + 5 ) / 10 ) );
		    }*/
};
//---------------------------------------------------------------------------
#endif	//xLib_CxDateTimeH

/*
//---------------------------------------------------------------------------
__int64 i64DateTimeToSeconds(const TDateTime &dtDateTime) {
    WORD wYear, wMonth, wDay, wHour, wMin, wSec, wMSec;
    
	DecodeTime(dtDateTime, wHour, wMin, wSec, wMSec);
    
	return (wHour * 60 * 60) + (wMin * 60) + (wSec);
}
//---------------------------------------------------------------------------
*/


/*
#define INTERVAL_CENTI      1
#define INTERVAL_SEC        100
#define INTERVAL_MIN        6000
#define INTERVAL_HOUR       360000L
#define INTERVAL_DAY        8640000L

#define INTERVAL_SEC_SEC	1
#define INTERVAL_MIN_SEC	60
#define INTERVAL_HOUR_SEC	3600
#define INTERVAL_DAY_SEC	86400
*/






/*
typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/

//microSec
//#define FILETIME_TO_USEC(ft) (((unsigned __int64) ft.dwHighDateTime << 32 | ft.dwLowDateTime) / 10)



//GetTimeFormatEx
//GetDateFormat

 
