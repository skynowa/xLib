/****************************************************************************
* Class name:  CxNonAssignable
* Description: ����� ��� ������� ��������� ������������
* File name:   CxNonAssignable.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     09.11.2009 11:11::00
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_CxNonAssignableH
#define xLib_CxNonAssignableH
//---------------------------------------------------------------------------
class CxNonAssignable {
   protected:
       CxNonAssignable() {}
      ~CxNonAssignable() {}
      
   private:  
       const CxNonAssignable &operator = (const CxNonAssignable &);
};
//---------------------------------------------------------------------------
#endif	//xLib_CxNonAssignableH
