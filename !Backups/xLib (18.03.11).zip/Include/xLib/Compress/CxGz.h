/****************************************************************************
* Class name:  CxGz
* Description: gz
* File name:   CxGz.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     25.01.2011 23:28:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Compress_CxGzH
#define xLib_Compress_CxGzH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
//---------------------------------------------------------------------------
class CxGz : public CxNonCopyable {
	public:
				 CxGz();
		virtual ~CxGz();
};
//---------------------------------------------------------------------------
#endif //xLib_Compress_CxGzH
