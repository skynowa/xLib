/****************************************************************************
* Class name:  CxReport
* Description: debug message
* File name:   CxReport.h
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     1 лют. 2011 13:58:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Debug_CxReportH
#define xLib_Debug_CxReportH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Common/CxNonCopyable.h>
//---------------------------------------------------------------------------
class CxReport : public CxNonCopyable  {
    public:
                 CxReport          (const tString &csExp, ULONG ulLastError, const tString &csFile, ULONG ulLine, const tString &csFunc, const tString &csDate, const tString &csTime, ULONG ulOSVersion, LPCTSTR pcszComment, ...);
        virtual ~CxReport          ();

        tString  sGetReport        () const;
        tString  sGetProgram       () const;
        ULONG    ulGetProcessId    () const;
        ULONG    ulGetThreadId     () const;
        tString  sGetSourceFile    () const;
        ULONG    ulGetSourceLine   () const;
        tString  sGetFunctionName  () const;
        tString  sGetExpression    () const;
        ULONG    ulGetLastError    () const;
        tString  sGetLastErrorStr  () const;
        tString  sGetCurrentDate   () const;
        tString  sGetBuildDate     () const;
        tString  sGetOsVersion     () const;
        tString  sGetOsArchitecture() const;
        tString  sGetComment       () const;

    private:
        tString  _m_sReport;

        //exe
        tString  _m_sProgram;
        ULONG    _m_ulProcessId;
        ULONG    _m_ulThreadId;

        //source
        tString  _m_sSourceFile;
        ULONG    _m_ulSourceLine;
        tString  _m_sFunctionName;
        tString  _m_sExpression;
        ULONG    _m_ulLastError;
        tString  _m_sLastErrorStr;

        //other
        tString  _m_sCurrentDate;
        tString  _m_sBuildDate;
        tString  _m_sOsVersion;
        tString  _m_sOsArchitecture;

        //comment
        tString  _m_sComment;

        BOOL     _bInit             (const tString &csExp, ULONG ulLastError, const tString &csFile, ULONG ulLine, const tString &csFunc, const tString &csDate, const tString &csTime, ULONG ulOSVersion, const tString &csComment);
        tString  _sGetOsArchitecture();
};
//---------------------------------------------------------------------------
#endif //xLib_CxReportH




