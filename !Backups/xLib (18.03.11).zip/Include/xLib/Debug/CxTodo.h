/****************************************************************************
* Class name:  CxTodo
* Description: TODO
* File name:   CxTodo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     23.12.2009 16:19:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Debug_CxTodoH
#define xLib_Debug_CxTodoH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Common/CxNonCopyable.h>
//---------------------------------------------------------------------------
class CxTodo : public CxNonCopyable {
	public:
	
	private:
		CxTodo();
	   ~CxTodo();
};
//---------------------------------------------------------------------------
#define xSTRINGIZE2(x) #x
#define xSTRINGIZE(x)  xSTRINGIZE2(x)








#if defined(xOS_WIN)
////#   define xTODO(text)    { message(__FILE__ "(" xSTRINGIZE(__LINE__) ") [" xFUNCTION "]: warning TODO: [" xFUNCTION "] " ## text) }
////#   define xTODO_IMPL     { xTODO("Implement " xFUNCTION " function!") }
#elif defined(xOS_LINUX)
#   define xPRAGMA(s)      { _Pragma (#s) }
#   define xTODO(s)        { xPRAGMA( message(" TODO: "s) ) }
#   define xNOT_IMPL(s)    { xPRAGMA( message(" Not implemented: "s) ) }
#endif
//---------------------------------------------------------------------------
#endif	//xLib_Debug_CxTodoH
