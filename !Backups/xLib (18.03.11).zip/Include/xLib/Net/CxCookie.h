/****************************************************************************
* Class name:  CxCookie
* Description: cookie (http://www.ietf.org/rfc/rfc2109.txt)
* File name:   CxCookie.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     26.01.2011 0:04:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Net_CxCookieH
#define xLib_Net_CxCookieH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>

typedef std::map<tString, tString> TStringMap;
//---------------------------------------------------------------------------
class CxCookie : public CxNonCopyable {
    public:
        HTTPCookie();
        explicit HTTPCookie(const std::string& name);
        explicit HTTPCookie(const NameValueCollection& nvc);
        HTTPCookie(const std::string& name, const std::string& value);
        HTTPCookie(const HTTPCookie& cookie);
        ~HTTPCookie();
        HTTPCookie& operator = (const HTTPCookie& cookie);

        void setVersion(int version);
        int getVersion() const;

        void setName(const std::string& name);
        const std::string& getName() const;

        void setValue(const std::string& value);
        const std::string& getValue() const;

        void setComment(const std::string& comment);
        const std::string& getComment() const;

        void setDomain(const std::string& domain);
        const std::string& getDomain() const;

        void setPath(const std::string& path);
        const std::string& getPath() const;

        void setSecure(bool secure);
        bool getSecure() const;

        void setMaxAge(int maxAge);
        int getMaxAge() const;

        void setHttpOnly(bool flag = true);
        bool getHttpOnly() const;

        std::string toString() const;

    private:
        int         _version;
        std::string _name;
        std::string _value;
        std::string _comment;
        std::string _domain;
        std::string _path;
        bool        _secure;
        int         _maxAge;
        bool        _httpOnly;


};
//---------------------------------------------------------------------------
#endif //xLib_Net_CxCookieH




/*
HttpRequest
HttpResponse
Cookie

*/


