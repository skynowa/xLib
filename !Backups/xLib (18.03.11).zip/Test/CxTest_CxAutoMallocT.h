/****************************************************************************
* Class name:  CxTest_CxAutoMallocT
* Description: test CxAutoMallocT
* File name:   CxTest_CxAutoMallocT.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxAutoMallocTH
#define CxTest_CxAutoMallocTH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Common/CxAutoMallocT.h>
//---------------------------------------------------------------------------
class CxTest_CxAutoMallocT : public CxTest {
	public:
		CxTest_CxAutoMallocT();
	   ~CxTest_CxAutoMallocT();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxAutoMallocTH



/****************************************************************************
* Class name:  CxTest_CxAutoMallocT
* Description: test CxAutoMallocT
* File name:   CxTest_CxAutoMallocT.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//test struct
typedef struct {
    INT x;
    INT y;
} SMy, *PSMy;

//---------------------------------------------------------------------------
//TODO: + CxTest_CxAutoMallocT (constructor)
CxTest_CxAutoMallocT::CxTest_CxAutoMallocT() {

}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxAutoMallocT (destructor)
CxTest_CxAutoMallocT::~CxTest_CxAutoMallocT() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxAutoMallocT::bUnit() {


    //-------------------------------------
	//CxAutoMallocT
	{
	    CxAutoMallocT<PSMy> stM(sizeof(SMy));
	}

    return TRUE;
}
//---------------------------------------------------------------------------

