//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CXWindowImpl.rc
//
#define IDC_MYICON                      20
#define ID_TOOLBAR                      100
#define IDD_SMPLULFRAMEWND_DIALOG       102
#define ID_wndMain                      102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SMPLULFRAMEWND              107
#define IDD_PROPPAGE_LARGE              107
#define IDI_SMALL                       108
#define IDR_MAINFRAME                   128
#define IDB_MYTB                        130
#define IDB_BITMAP1                     132
#define IDB_TB                          133
#define IDB_BITMAP_BG                   134
#define IDD_DIALOG2                     137
#define ID_MENU_NEW                     1000
#define IDC_LIST1                       1004
#define IDC_BUTTON20                    1005
#define IDC_COMBO1                      1006
#define IDC_COMBO2                      1007
#define IDC_COMBO3                      1008
#define IDC_staServer                   1009
#define IDC_staPort                     1010
#define IDC_sta                         1011
#define IDC_staLogin                    1011
#define IDC_TAB1                        1012
#define IDC_PROGRESS1                   1013
#define IDC_prbProgressBar              1013
#define IDC_btnStart                    1014
#define IDC_btnStop                     1015
#define ID_btnExit                      1016
#define IDC_BUTTON21                    10010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
