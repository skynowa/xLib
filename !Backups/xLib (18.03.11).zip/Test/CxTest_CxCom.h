/****************************************************************************
* Class name:  CxTest_CxCom
* Description: test CxCom
* File name:   CxTest_CxCom.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxComH
#define CxTest_CxComH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Common/Win/CxCom.h>
//---------------------------------------------------------------------------
class CxTest_CxCom : public CxTest {
	public:
		CxTest_CxCom();
	   ~CxTest_CxCom();

	   /*virtual*/ BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxComH


/****************************************************************************
* Class name:  CxTest_CxCom
* Description: test CxCom
* File name:   CxTest_CxCom.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxTest_CxCom (comment)
CxTest_CxCom::CxTest_CxCom() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CxTest_CxCom (comment)
CxTest_CxCom::~CxTest_CxCom() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL CxTest_CxCom::bUnit() {
	/*DEBUG*/

	//-------------------------------------
	//bIsInit
	{
		{
			CxCom cmCom(CxCom::cmMultiThreaded);

			m_bRes = CxCom::bIsInit();
			xASSERT(FALSE != m_bRes);
		}

		m_bRes = CxCom::bIsInit();
		xASSERT(FALSE == m_bRes);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

