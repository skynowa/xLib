// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#pragma comment(lib,"Ws2_32.lib")

#include <iostream>
#include <tchar.h>

#include "../globals.h"

extern char g_szDomain[100];
extern char g_szDirectoryPath[300];
extern char g_szDomainPath[400];


// TODO: reference additional headers your program requires here
