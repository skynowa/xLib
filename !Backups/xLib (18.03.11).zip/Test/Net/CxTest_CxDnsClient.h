/****************************************************************************
* Class name:  CxTest_CxDnsClient
* Description: test CxDnsClient
* File name:   CxTest_CxDnsClient.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxDnsClientH
#define CxTest_CxDnsClientH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Net/CxDnsClient.h>
//---------------------------------------------------------------------------
class CxTest_CxDnsClient : public CxTest {
	public:
		CxTest_CxDnsClient();
	   ~CxTest_CxDnsClient();

	   /*virtual*/ BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxDnsClientH

/****************************************************************************
* Class name:  CxTest_CxDnsClient
* Description: test CxDnsClient
* File name:   CxTest_CxDnsClient.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Net/CxSocketInit.h>

//---------------------------------------------------------------------------
//TODO: + CxTest_CxDnsClient (comment)
CxTest_CxDnsClient::CxTest_CxDnsClient() {
    bSetName(xT(xFUNCTION));
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxDnsClient (comment)
CxTest_CxDnsClient::~CxTest_CxDnsClient() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL CxTest_CxDnsClient::bUnit() {
	//-------------------------------------
	//CxSocketInit
	CxSocketInit siInit(2, 2);

	//-------------------------------------
	//bGetHostAddrByName
	{	
		tString sHostName = xT("msdn.microsoft.com");
		tString sHostAddr = xT("");

		m_bRes = CxDnsClient::bGetHostAddrByName(sHostName, &sHostAddr);
		xASSERT(FALSE != m_bRes);

		//tcout << xT("[bGetHostAddrByName]: ") << sHostAddr << tendl;
	}

	//-------------------------------------
	//bGetHostNameByAddr
	{		
		tString sHostName = xT("");
		tString sHostAddr = xT("127.0.0.1");

		m_bRes = CxDnsClient::bGetHostNameByAddr(sHostAddr, CxSocket::afInet, &sHostName);
		xASSERT(FALSE != m_bRes);

		//tcout << xT("[bGetHostNameByAddr]: ") << sHostName << tendl;
	}	

	//-------------------------------------
	//bGetLocalHostName
	{		
		tString sLocalHostName = xT("");

		m_bRes = CxDnsClient::bGetLocalHostName(&sLocalHostName);
		xASSERT(FALSE != m_bRes);

		//tcout << xT("[bGetLocalHostName]: ") << sLocalHostName << tendl;
	}

	//-------------------------------------
	//bGetNameInfo
	{		
		////CxDnsClient::EAddressFamily afFamily  = CxDnsClient::afInet;
		////tString                     sHostAddr = /*xT("207.46.172.252");*/    xT("forum.vingrad.ru");
		////USHORT                      usPort    = 27015;

		////m_bRes = CxDnsClient::bGetNameInfo(afFamily, sHostAddr, usPort);
		////xASSERT(FALSE != m_bRes);

		//////xSTD_COUT(xT("[bGetNameInfo]: ") << sLocalHostName);
	}

	//-------------------------------------
	//bGetHostAddrInfo
	{		
		tString sHostName = xT("www.google.ru");
		tString sPort     = xT("80");

		////ADDRINFOT aiHints  = {0};
		ADDRINFOT *paiList = NULL;

		m_bRes = CxDnsClient::bGetHostAddrInfo(sHostName, sPort, NULL, &paiList);
		xASSERT(FALSE != m_bRes);

		///xSTD_COUT(xT("[bGetLocalHostName]: ") << sLocalHostName);

	
		{
			///*int*/                 paiList->ai_flags;       // AI_PASSIVE, AI_CANONNAME, AI_NUMERICHOST
			///*int*/                 paiList->ai_family;      // PF_xxx
			///*int*/                 paiList->ai_socktype;    // SOCK_xxx
			///*int*/                 paiList->ai_protocol;    // 0 or IPPROTO_xxx for IPv4 and IPv6
			///*size_t*/              paiList->ai_addrlen;     // Length of ai_addr
			///*char **/              paiList->ai_canonname;   // Canonical name for nodename
			///*__field_bcount(ai_addrlen) struct sockaddr **/   paiList->ai_addr;        // Binary address
			///*struct addrinfo **/   paiList->ai_next;        // Next structure in linked list
		}

        #if defined(xOS_WIN)
		    ////freeaddrinfo(paiList);
       		::FreeAddrInfo(paiList);
        #elif defined(xOS_LINUX)
       		freeaddrinfo(paiList);
        #endif
		/*DEBUG*/// n/a
	}

	//-------------------------------------
	//bGetProtocolByName
	{	
		const TCHAR cszProtocolNames[][10] =
		{
            xT("ip"), xT("icmp"), xT("ggp"), xT("tcp"), xT("egp"),
            xT("pup"), xT("udp"), xT("hmp"), xT("xns-idp"), xT("rdp")
		};

		for (size_t i = 0; i < xARRAY_SIZE(cszProtocolNames); ++ i) {
			tString              sName; 
			std::vector<tString> vecsAliases; 
			SHORT                siNumber = - 1;

			m_bRes = CxDnsClient::bGetProtocolByName(cszProtocolNames[i], &sName, &vecsAliases, &siNumber);
			xASSERT(FALSE != m_bRes);

			//tcout << xT("[bGetProtocolByName]: ")             << tendl;
			//tcout << xT("	sName:    ") << sName             << tendl;
			for (size_t i = 0; i < vecsAliases.size(); ++ i) {
			//tcout << xT("	sAlias:   ") << vecsAliases.at(i) << tendl;
			}		 
			//tcout << xT("	siNumber: ") << siNumber          << tendl;
			//tcout << xT("	--------------------")            << tendl;
		}
        //tcout << tendl;
	}

	//-------------------------------------
	//cszProtocolNumbers
	{	
		const INT ciProtocolNumbers[] = {
		    0, 1, 3, 6, 8, 12, 17, 20, 22, 27
		};
	
		for (size_t i = 0; i < xARRAY_SIZE(ciProtocolNumbers); ++ i) {
			tString              sName; 
			std::vector<tString> vecsAliases; 
			SHORT                siNumber = - 1;

			m_bRes = CxDnsClient::bGetProtocolByNumber(ciProtocolNumbers[i], &sName, &vecsAliases, &siNumber);
			xASSERT(FALSE != m_bRes);

			//tcout << xT("[bGetProtocolByNumber]: ")           << tendl;
			//tcout << xT("	sName:    ") << sName             << tendl;;
			for (size_t i = 0; i < vecsAliases.size(); ++ i) {
			//tcout << xT("	sAlias:   ") << vecsAliases.at(i) << tendl;
			}		 
			//tcout << xT("	siNumber: ") << siNumber          << tendl;
			//tcout << xT("	--------------------")            << tendl;
		}
        //tcout << tendl;
	}

	//-------------------------------------
	//bGetServiceByName
	{	
		tString              csServiceName  = xT("http"); 
		const TCHAR          cszProtocolNames[][10] = {xT("ip"), xT("icmp"), xT("ggp"), xT("tcp"), xT("egp"), xT("pup"), xT("udp"), xT("hmp"), xT("xns-idp"), xT("rdp") };
		tString              sName; 
		std::vector<tString> vecsAliases; 
		SHORT                siPort;  
		tString              sProtocolName;

		m_bRes = CxDnsClient::bGetServiceByName(csServiceName, cszProtocolNames[3], &sName, &vecsAliases, &siPort, &sProtocolName);
		xASSERT(FALSE != m_bRes);

		//tcout << xT("[bGetServiceByName]: ")                   << tendl;
		//tcout << xT("	sName:         ") << sName             << tendl;
		for (size_t i = 0; i < vecsAliases.size(); ++ i) {
		//tcout << xT("	sAlias:        ") << vecsAliases.at(i) << tendl;
		}		 
		//tcout << xT("	siPort:        ") << siPort            << tendl;
		//tcout << xT("	sProtocolName: ") << sProtocolName     << tendl;
		//tcout << xT("	--------------------")                 << tendl;
        //tcout << tendl;
	}


	//-------------------------------------
	//bGetServiceByPort
	{	
		SHORT                csiPort  = 20480; 
		const TCHAR          cszProtocolNames[][10] = {xT("ip"), xT("icmp"), xT("ggp"), xT("tcp"), xT("egp"), xT("pup"), xT("udp"), xT("hmp"), xT("xns-idp"), xT("rdp") };
		tString              sName; 
		std::vector<tString> vecsAliases; 
		SHORT                siPort = - 1;  
		tString              sProtocolName;

		m_bRes = CxDnsClient::bGetServiceByPort(csiPort, cszProtocolNames[3], &sName, &vecsAliases, &siPort, &sProtocolName);
		xASSERT(FALSE != m_bRes);

		//tcout << xT("[bGetServiceByPort]: ") << tendl;
		//tcout << xT("	sName:         ") << sName << tendl;
		for (size_t i = 0; i < vecsAliases.size(); ++ i) {
		//tcout << xT("	sAlias:        ") << vecsAliases.at(i) << tendl;
		}		 
		//tcout << xT("	siPort:        ") << siPort            << tendl;
		//tcout << xT("	sProtocolName: ") << sProtocolName     << tendl;
        //tcout << xT("  --------------------")                << tendl;
        //tcout << tendl;
	}

	return TRUE;
}
//---------------------------------------------------------------------------

