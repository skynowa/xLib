/****************************************************************************
* Class name:  CxTest_CxCookie
* Description: test CxCookie
* File name:   CxTest_CxCookie.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxCookieH
#define CxTest_CxCookieH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Net/CxCookie.h>
//---------------------------------------------------------------------------
class CxTest_CxCookie : public CxTest {
	public:
		CxTest_CxCookie();
	   ~CxTest_CxCookie();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxCookieH



/****************************************************************************
* Class name:  CxTest_CxCookie
* Description: test CxCookie
* File name:   CxTest_CxCookie.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxCookie (constructor)
CxTest_CxCookie::CxTest_CxCookie() {

}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxCookie (destructor)
CxTest_CxCookie::~CxTest_CxCookie() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxCookie::bUnit() {
    {
        ////CxCookie ckCookie;
    }


//    tString csRawCookie;
//
//    ///csRawCookie = xT("name1=value1; name2=value2; nameN=valueN");
//    csRawCookie = xT("NAME=value; EXPIRES=date; DOMAIN=domain_name; PATH=path; SECURE");
//                   // DOMAIN=domain_name1; EXPIRES=date1; NAME=value1; PATH=path1; SECURE
//
//    CxCookie ckCookie(csRawCookie);
//
//    ///CxString::vStdMapPrintT(_m_msCookie);
//
//    //--------------------------------------------------
//    //bAttrIsExists
//    {
//        const tString sTestData[][2] = {
//            {xT("NAME"),          xT("TRUE")},
//            {xT("EXPIRES"),       xT("TRUE")},
//            {xT(""),              xT("FALSE")},
//            {xT("TEST_STRING_4"), xT("FALSE")},
//            {xT("TEST_STRING_5"), xT("FALSE")}
//        };
//
//        for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
//            BOOL bRes1 = ckCookie.bAttrIsExists(sTestData[i][0]);
//
//            BOOL bRes2;
//            CxString::bStrToBool(sTestData[i][1], &bRes2);
//            //xTRACEV("bRes1: %i,  bRes2: %i", bRes1, bRes2);
//            xASSERT_MSG(bRes1 == bRes2, sTestData[i][0].c_str());
//        }
//    }
//
//    //--------------------------------------------------
//    //sAttrGet
//    {
//        const tString sTestData[][2] = {
//            {xT("NAME"),        xT("value")},
//            {xT("EXPIRES"),     xT("date")},
//            {xT("DOMAIN"),      xT("domain_name")},
//            {xT("PATH"),        xT("path")},
//            {xT("SECURE"),      xT("")}
//        };
//
//        for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
//            tString sStr1 = ckCookie.sAttrGet(sTestData[i][0]);
//            tString sStr2 = sTestData[i][1];
//            xASSERT(sStr1 == sStr2);
//        }
//    }
//
//    //--------------------------------------------------
//    //sAttrSet
//    {
//        const tString sTestData[][2] = {
//            {xT("NAME"),        xT("value1")},
//            {xT("EXPIRES"),     xT("date1")},
//            {xT("DOMAIN"),      xT("domain_name1")},
//            {xT("PATH"),        xT("path1")},
//            {xT("SECURE"),      xT("")}
//        };
//
//        for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
//            m_bRes = ckCookie.sAttrSet(sTestData[i][0], sTestData[i][1]);
//            xASSERT(FALSE != m_bRes);
//
//            tString sStr1 = ckCookie.sAttrGet(sTestData[i][0]);
//            tString sStr2 = sTestData[i][1];
//            xASSERT(sStr1 == sStr2);
//        }
//    }
//
//    //--------------------------------------------------
//    //bGet
//    {
//        tString sRawCookie;
//
//        m_bRes = ckCookie.bGet(&sRawCookie);
//        xASSERT(FALSE != m_bRes);
//        xASSERT_MSG(FALSE != CxString::bCompareNoCase(csRawCookie, sRawCookie), sRawCookie.c_str());
//    }


    return TRUE;
}
//---------------------------------------------------------------------------

