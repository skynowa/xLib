/****************************************************************************
* Class name:  CxTest_CxCgi
* Description: test CxCgi
* File name:   CxTest_CxCgi.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxCgiH
#define CxTest_CxCgiH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Net/CxCgi.h>
//---------------------------------------------------------------------------
class CxTest_CxCgi : public CxTest {
	public:
		CxTest_CxCgi();
	   ~CxTest_CxCgi();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxCgiH



/****************************************************************************
* Class name:  CxTest_CxCgi
* Description: test CxCgi
* File name:   CxTest_CxCgi.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxCgi (constructor)
CxTest_CxCgi::CxTest_CxCgi() {
    bSetName(xFUNCTION);
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxCgi (destructor)
CxTest_CxCgi::~CxTest_CxCgi() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxCgi::bUnit() {
	tString sQueryStr =
	        xT("");
	
	CxCgi cgCgi;
	
//	cgCgi.bInitQuery(sQueryStr);
//
//
//
//	/****************************************************************************
//	*	Query
//	*
//	*****************************************************************************/
//
//	//MessageBox(0, objCgi.sGetQueryParamByName("inpLogin").c_str(),  "sGetQueryParamByName()", MB_OK);
//	//MessageBox(0, objCgi.sGetQueryParamByName("inpPin").c_str(),    "sGetQueryParamByName()", MB_OK);
//	//MessageBox(0, objCgi.sGetQueryParamByName("inpId").c_str(),     "sGetQueryParamByName()", MB_OK);
//	//MessageBox(0, objCgi.sGetQueryParamByName("inpServId").c_str(), "sGetQueryParamByName()", MB_OK);
//	//MessageBox(0, objCgi.sGetQueryParamByName("btnSubmit").c_str(), "sGetQueryParamByName()", MB_OK);
//	//unsigned long int ulQueryCount = objCgi.ulGetQueryParamCount();
//	bool bRes1 = objCgi.bIsPostQuery();
//	bool bRes2 = objCgi.bIsGetQuery();
//
//
//	/****************************************************************************
//	*	Environ
//	*
//	*****************************************************************************/
//
//	////MessageBox(0, objCgi.sGetEnvironStringByName("OS").c_str(), "sGetEnvironItemByName()", MB_OK);
//	////unsigned long int ulEnvironCount = objCgi.ulGetEnvironStringCount();
//	////MessageBox(0, objCgi.sGetEnvironStrings().c_str(), "sGetEnvironStrings()", MB_OK);
//
//
//	/****************************************************************************
//	*	Coockie
//	*
//	*****************************************************************************/
//
//	//std::string sCoockie = "username=Serg; IP=127.0.0.1; Url=localhost";
//	////std::string sCoockie = "username=Serg";
//	////MessageBox(0, objCgi.sGetCookieValueByName("username").c_str(), "sGetCookieValueByName", MB_OK);
//	////unsigned long int ulCookieCount = objCgi.ulGetCookieCount();
//	////objCgi.bSetCookie("Pass", "1111", "Thu, 01-Jan-70 00:00:01 GMT", "\\", "Serg", true);
//	////objCgi.bDeleteCookie("Pass");
//
//
//	/****************************************************************************
//	*	Log
//	*
//	*****************************************************************************/
//
//	//objCgi.vLog("xxxxxxx");
//
//
//	/****************************************************************************
//	*	Other
//	*
//	*****************************************************************************/
//
//	////objCgi.bRedirect("http://127.0.0.1");
//	////objCgi.bRedirectToReferer();
	
	

    return TRUE;
}
//---------------------------------------------------------------------------

