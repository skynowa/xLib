// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <iostream>
#include <tchar.h>

#pragma comment(lib,"Ws2_32.lib")

#include "../globals.h"
