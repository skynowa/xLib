
BOOL ProcessHELO()
{

	return TRUE;
}

BOOL ProcessRCPT()
{

	return TRUE;
}

BOOL ProcessMAIL()
{

	return TRUE;
}

BOOL ProcessRSET()
{

	return TRUE;
}

BOOL ProcessNOOP()
{

	return TRUE;
}

BOOL ProcessQUIT()
{

	return TRUE;
}

BOOL ProcessDATA()
{

	return TRUE;
}

BOOL ProcessNotImplemented(BOOL bParam=FALSE)
{

	return TRUE;
}

BOOL ProcessLine(char *buf, int len)
{

	return TRUE;
}
