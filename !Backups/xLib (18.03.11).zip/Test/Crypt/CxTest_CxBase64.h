/****************************************************************************
* Class name:  CxTest_CxBase64
* Description: test CxBase64
* File name:   CxTest_CxBase64.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxBase64H
#define CxTest_CxBase64H
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Crypt/CxBase64.h>
//---------------------------------------------------------------------------
class CxTest_CxBase64 : public CxTest {
	public:
		CxTest_CxBase64();
	   ~CxTest_CxBase64();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxBase64H



/****************************************************************************
* Class name:  CxTest_CxBase64
* Description: test CxBase64
* File name:   CxTest_CxBase64.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxBase64 (constructor)
CxTest_CxBase64::CxTest_CxBase64() {
    bSetName(xT(xFUNCTION));
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxBase64 (destructor)
CxTest_CxBase64::~CxTest_CxBase64() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxBase64::bUnit() {
	//-------------------------------------
	//sEncode, sDecode
	{
		const std::string sTestData[][1] = {
			{"ADP GmbH\nAnalyse Design & Programmierung\nGesellschaft mit beschrankter Haftung"},
			{"TEST_STRING_2"},
			{"evrtvertre=-430956=-lmj';l'654"},
			{"ngb213,jhv560vlk254mlkvj6254klj'lcmkc34;lr,m34;'rtlm2cv456467809=-0i=-09i=-24i09v5grfmkldfgjghmjgyuiyuirvbty34v5"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"},
			{"TEST_STRING_2"},
			{"TEST_STRING_3"},
			{"TEST_STRING_4"}

		};

		for (size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
			std::string sSource = sTestData[i][0];

			std::string sEncoded = CxBase64::sEncode(sSource);
			std::string sDecoded = CxBase64::sDecode(sEncoded);
			xASSERT(sSource == sDecoded);
		}
	}

    return TRUE;
}
//---------------------------------------------------------------------------

