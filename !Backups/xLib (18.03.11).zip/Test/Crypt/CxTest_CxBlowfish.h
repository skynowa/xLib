/****************************************************************************
* Class name:  CxTest_CxBlowfish
* Description: test CxBlowfish
* File name:   CxTest_CxBlowfish.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxBlowfishH
#define CxTest_CxBlowfishH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Crypt/OpenSSL/CxBlowfish.h>
//---------------------------------------------------------------------------
class CxTest_CxBlowfish : public CxTest {
	public:
		CxTest_CxBlowfish();
	   ~CxTest_CxBlowfish();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxBlowfishH



/****************************************************************************
* Class name:  CxTest_CxBlowfish
* Description: test CxBlowfish
* File name:   CxTest_CxBlowfish.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxBlowfish (constructor)
CxTest_CxBlowfish::CxTest_CxBlowfish() {
    bSetName(xFUNCTION);
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxBlowfish (destructor)
CxTest_CxBlowfish::~CxTest_CxBlowfish() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxBlowfish::bUnit() {
	//-------------------------------------
	//bEncryptCfb64
	{
		uString usPlain[] = {
			uString(1,  'a'),
			uString(2,  'b'),
			uString(3,  'c'),
			uString(8,  'd'),
			uString(11, 'e'),
			uString(12, 'f'),
			uString(16, 'j'),
			uString(17, 'h'),
			uString(28, 'i'),
			uString(32, 'j'),
			uString(51, 'k')
		};

		for (INT i = 0; i < xARRAY_SIZE(usPlain); i ++) {
			CxBlowfish BF;
			tString sKey       = xT("888888888");
			uString sEncrypted;
			uString sDecrypted;

			m_bRes = BF.bSetKey(sKey);
			xASSERT(FALSE != m_bRes);

			m_bRes = BF.bEncryptCfb64(usPlain[i], &sEncrypted, CxBlowfish::cmEncrypt);
			xASSERT(FALSE != m_bRes);

			m_bRes = BF.bEncryptCfb64(sEncrypted, &sDecrypted, CxBlowfish::cmDecrypt);
			xASSERT(FALSE != m_bRes);

			xASSERT(usPlain[i] == sDecrypted);
		}	
	}

	//-------------------------------------
	//bEncryptFileCfb64
	{
		CxBlowfish BF;
		tString sKey           = xT("888888888");
		tString sFilePlain     = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.Plain.txt");
		tString sFileEncrypted = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.Encrypted.txt");
		tString sFileDecrypted = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.FileDecrypted.txt");

		m_bRes = BF.bSetKey(sKey);
		xASSERT(FALSE != m_bRes);

		m_bRes = BF.bEncryptFileCfb64(sFilePlain, sFileEncrypted, CxBlowfish::cmEncrypt);
		xASSERT(FALSE != m_bRes);

		m_bRes = BF.bEncryptFileCfb64(sFileEncrypted, sFileDecrypted, CxBlowfish::cmDecrypt);
		xASSERT(FALSE != m_bRes);
	}

	//-------------------------------------
	//bEncryptFileCfb64 (with stamp)
	{
		CxBlowfish BF;

		CxBlowfish::ECryptMode cmRes = CxBlowfish::cmUnknown;
		tString sKey           = xT("888888888");
		tString sStamp         = xT("stamp");
		uString usStamp        = xS2US(sStamp);
		tString sFilePlain     = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.Plain.txt");
		tString sFileEncrypted = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.Encrypted.txt");
		tString sFileDecrypted = sGetWorkDirPath() + CxConst::xSLASH + xT("Test.FileDecrypted.txt");

		m_bRes = BF.bSetKey(sKey);
		xASSERT(FALSE != cmRes);

		cmRes = BF.cmGetFileCryptStatus(sFilePlain, usStamp);
		xASSERT(CxBlowfish::cmDecrypt == cmRes);

//		m_bRes = BF.bEncryptFileCfb64(sFilePlain,     sFileEncrypted, usStamp);
//		xASSERT(FALSE != m_bRes);
//
//		m_bRes = BF.bEncryptFileCfb64(sFileEncrypted, sFileDecrypted, usStamp);
//		xASSERT(FALSE != m_bRes);
	}


    return TRUE;
}
//---------------------------------------------------------------------------

