//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CxThreadPool_GUI.rc
//
#define IDC_MYICON                      2
#define IDD_CxThreadPOOL_GUI_DIALOG     102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_CxThreadPOOL_GUI            107
#define IDI_SMALL                       108
#define IDC_CxThreadPOOL_GUI            109
#define IDR_MAINFRAME                   128
#define IDD_dlgMain                     129
#define IDC_btnQuit                     1001
#define IDC_LIST1                       1002
#define IDC_lbLog                       1002
#define IDC_btnCreateGroup              1003
#define IDC_btnResumeGroup              1004
#define IDC_btnPauseGroup               1005
#define IDC_btnExitGroup                1006
#define IDC_btnKillGroup                1008
#define IDC_btnWaitGroup                1009
#define IDC_EDIT1                       1012
#define IDC_edtMaxTasks                 1012
#define IDC_btnCreate                   1016
#define IDC_btnResume                   1017
#define IDC_btnPause                    1018
#define IDC_btnExit                     1019
#define IDC_btnKill                     1020
#define IDC_btnWait                     1021
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
