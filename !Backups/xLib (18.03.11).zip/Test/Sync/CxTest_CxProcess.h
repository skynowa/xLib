/****************************************************************************
* Class name:  CxTest_CxProcess
* Description: test CxTest_CxProcess
* File name:   CxTest_CxProcess.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxTest_CxProcessH
#define CxTest_CxTest_CxProcessH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Sync/CxProcess.h>
//---------------------------------------------------------------------------
class CxTest_CxProcess : public CxTest {
	public:
		CxTest_CxProcess();
	   ~CxTest_CxProcess();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxTest_CxProcessH



/****************************************************************************
* Class name:  CxTest_CxProcess
* Description: test CxTest_CxProcess
* File name:   CxTest_CxProcess.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxProcess (constructor)
CxTest_CxProcess::CxTest_CxProcess() {
    bSetName(xT(xFUNCTION));
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxProcess (destructor)
CxTest_CxProcess::~CxTest_CxProcess() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL
CxTest_CxProcess::bUnit() {
    //--------------------------------------------------
    //ulGetCurrId
    {
        m_ulRes = CxProcess::ulGetCurrId();
        xASSERT(0 <= m_ulRes);
    }

    //--------------------------------------------------
    //ulGetCurrParentId
    {
        m_ulRes = CxProcess::ulGetCurrParentId();
        xASSERT(0 <= m_ulRes);
    }

    //--------------------------------------------------
    //bExec
    {
    #if defined(xOS_WIN)
        const tString csFilePath = xT("explorer.exe");
        const tString csCmdLine  = xT("");
    #elif defined(xOS_LINUX)
        const tString csFilePath = xT("dolphin");
        const tString csCmdLine  = xT("");
    #endif

        ////m_bRes = CxProcess::bExec(csFilePath, csCmdLine.c_str(), 0);
        ////xASSERT(FALSE != m_bRes);
    }

    //--------------------------------------------------
    //bExit
    {
        ////m_bRes = CxProcess::bExit(CxProcess::ulGetCurrParentId(), 0);
        ////xASSERT(FALSE != m_bRes);
    }

    //--------------------------------------------------
    //bTerminate
    {
        //m_bRes = CxProcess::bTerminate(CxProcess::ulGetCurrParentId());
        //xASSERT(FALSE != m_bRes);
    }

    return TRUE;
}
//---------------------------------------------------------------------------

