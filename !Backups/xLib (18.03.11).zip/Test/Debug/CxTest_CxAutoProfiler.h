/****************************************************************************
* Class name:  CxTest_CxAutoProfiler
* Description: test CxAutoProfiler
* File name:   CxTest_CxAutoProfiler.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxAutoProfilerH
#define CxTest_CxAutoProfilerH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Debug/CxAutoProfiler.h>
//---------------------------------------------------------------------------
class CxTest_CxAutoProfiler : public CxTest {
	public:
		CxTest_CxAutoProfiler();
	   ~CxTest_CxAutoProfiler();

	    virtual BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxAutoProfilerH



/****************************************************************************
* Class name:  CxTest_CxAutoProfiler
* Description: test CxAutoProfiler
* File name:   CxTest_CxAutoProfiler.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + CxTest_CxAutoProfiler (comment)
CxTest_CxAutoProfiler::CxTest_CxAutoProfiler() {
    bSetName(xT(xFUNCTION));
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxAutoProfiler (comment)
CxTest_CxAutoProfiler::~CxTest_CxAutoProfiler() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL 
CxTest_CxAutoProfiler::bUnit() {
	const CxProfiler::EMode pmPerformMode[] = {
	        CxProfiler::pmClock,
	        CxProfiler::pmTime,
        #if defined(xOS_WIN)
	        CxProfiler::pmTickCount,
	        CxProfiler::pmPerformanceCount,
	        CxProfiler::pmThreadTimes,
        #elif defined(xOS_LINUX)
	        CxProfiler::pmGetTimeOfDay
        #endif
	};

	//-------------------------------------
	//CxAutoProfiler
	{
		for (size_t i = 0; i < xARRAY_SIZE(pmPerformMode); ++ i) {
			CxAutoProfiler _apfAP(xT("__FuncLog.log"), pmPerformMode[i], xT("%i"), 777);

			for (int i = 0; i < 1000/*00*/; ++ i) {
				for (int i = 0; i < 2000; ++ i) {
					int x = 0;

					x++; --x;
				}
			}
		}
	}

	//-------------------------------------
	//xAUTO_PERFORM_FUNC
	for (size_t i = 0; i < xARRAY_SIZE(pmPerformMode); ++ i) {
		xAUTO_PERFORM_FUNC(xT("__FuncLog.log"), pmPerformMode[i]);

		for (int i = 0; i < 1000/*00*/; ++ i) {
			for (int i = 0; i < 2000; ++ i) {
				int x = 0;

				x++; --x;
			}
		}
	}
	
	return TRUE;
}
//---------------------------------------------------------------------------


