/****************************************************************************
* Class name:  CxTest_CxDateTime
* Description: testing CxDateTime
* File name:   CxTest_CxDateTime.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxTest_CxDateTimeH
#define CxTest_CxDateTimeH
//---------------------------------------------------------------------------
#include <xLib/Common/xCommon.h>
#include <xLib/Debug/CxTest.h>
#include <xLib/Common/CxDateTime.h>
//---------------------------------------------------------------------------
class CxTest_CxDateTime : public CxTest {
	public:
		CxTest_CxDateTime();
	   ~CxTest_CxDateTime();

	   /*virtual*/ BOOL bUnit();

	private:
};
//---------------------------------------------------------------------------
#endif //CxTest_CxDateTimeH


/****************************************************************************
* Class name:  CxTest_CxDateTime
* Description: testing CxDateTime
* File name:   CxTest_CxDateTime.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 11:03:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxTest_CxDateTime (comment)
CxTest_CxDateTime::CxTest_CxDateTime() {
    bSetName(xT(xFUNCTION));
}
//---------------------------------------------------------------------------
//TODO: + ~CxTest_CxDateTime (comment)
CxTest_CxDateTime::~CxTest_CxDateTime() {

}
//---------------------------------------------------------------------------
//TODO: - bUnit ()
/*virtual*/
BOOL CxTest_CxDateTime::bUnit() {
    /****************************************************************************
    *   public: ������������
    *
    *****************************************************************************/

    //-------------------------------------
    //CxDateTime()
    {
        CxDateTime dtDT;
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 0:00:00:000") == m_sRes);
    }

    //CxDateTime(const CxDateTime &dtDT);
    {
        CxDateTime dtDT1(2010, 7, 8, 3, 15, 6, 111);
        CxDateTime dtDT2(dtDT1);
        m_sRes = dtDT2.sGetDateTimeStr();
        xASSERT(xT("08.07.2010 3:15:06:111") == m_sRes);
    }

    //CxDateTime(ULONGLONG ui64MSec);
    {
        CxDateTime dtDT(1000 * 60 * 60);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 1:00:00:000") == m_sRes);
    }

    //CxDateTime(USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
    {
        CxDateTime dtDT(12, 20, 37, 555);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 12:20:37:555") == m_sRes);
    }

    //CxDateTime(USHORT usYear, USHORT usMonth, USHORT usDay);
    {
        CxDateTime dtDT(2010, 7, 8);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("08.07.2010 0:00:00:000") == m_sRes);
    }

    //CxDateTime(USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
    {
        CxDateTime dtDT(2010, 8, 18, 14, 0, 5, 777);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("18.08.2010 14:00:05:777") == m_sRes);
    }


    /****************************************************************************
    *   public: ��������� ���������
    *
    *****************************************************************************/

    //-------------------------------------
    //operator ==
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 == dtDt2);
        xASSERT(FALSE != m_bRes);
    }

    //-------------------------------------
    //operator !=
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 != dtDt2);
        xASSERT(FALSE == m_bRes);
    }

    //-------------------------------------
    //operator <
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 < dtDt2);
        xASSERT(FALSE == m_bRes);
    }

    //-------------------------------------
    //operator <=
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 <= dtDt2);
        xASSERT(FALSE != m_bRes);
    }

    //-------------------------------------
    //operator >
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 > dtDt2);
        xASSERT(FALSE == m_bRes);
    }

    //-------------------------------------
    //operator >=
    {
        CxDateTime dtDt1;
        CxDateTime dtDt2;

        m_bRes = (dtDt1 >= dtDt2);
        xASSERT(FALSE != m_bRes);
    }


    /****************************************************************************
    *   public: ��������� ������������
    *
    *****************************************************************************/

    //-------------------------------------
    //operator +=
    {
        CxDateTime dtDt(0, 30, 0, 0);
        ULONGLONG  ui64MSec = (1000 * 60) * 60; //1 ���

        dtDt = ui64MSec;
        m_sRes = dtDt.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 1:00:00:000") == m_sRes);
    }

    //-------------------------------------
    //��������� (=, +, -)
    {
        CxDateTime dtDT;

        dtDT = CxDateTime() + CxDateTime(1000 * 60 * 60);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 1:00:00:000") == m_sRes);

        dtDT = dtDT - CxDateTime(1000 * 60 * 60 / 2);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 0:30:00:000") == m_sRes);
    }

    //-------------------------------------
    //operator +=
    {
        CxDateTime dtDt1(1, 0, 0, 0);
        CxDateTime dtDt2(1, 30, 0, 0);

        dtDt1 += dtDt2;
        m_sRes = dtDt1.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 2:30:00:000") == m_sRes);
    }

    //-------------------------------------
    //operator -=
    {
        CxDateTime dtDt1(1, 50, 0, 0);
        CxDateTime dtDt2(1, 30, 0, 0);

        dtDt1 -= dtDt2;
        m_sRes = dtDt1.sGetDateTimeStr();
        xASSERT(xT("00.00.0000 0:20:00:000") == m_sRes);
    }


    /****************************************************************************
    *   public: get, set
    *
    *****************************************************************************/

    //-------------------------------------
    //bSet, bGet
    {
        CxDateTime dtDT;

        USHORT     usYear   = 2010;
        USHORT     usMonth  = 1;
        USHORT     usDay    = 14;
        USHORT     usHour   = 17;
        USHORT     usMinute = 0;
        USHORT     usSecond = 55;
        USHORT     usMSec   = 666;

        m_bRes = dtDT.bSet(usYear, usMonth, usDay, usHour, usMinute, usSecond, usMSec);
        /*DEBUG*/xASSERT(FALSE != m_bRes);

        m_bRes = dtDT.bGet(&usYear, &usMonth, &usDay, &usHour, &usMinute, &usSecond, &usMSec);
        /*DEBUG*/xASSERT(FALSE != m_bRes);

        /*DEBUG*/xASSERT(2010  == usYear);
        /*DEBUG*/xASSERT(1     == usMonth);
        /*DEBUG*/xASSERT(14    == usDay);
        /*DEBUG*/xASSERT(17    == usHour);
        /*DEBUG*/xASSERT(0     == usMinute);
        /*DEBUG*/xASSERT(55    == usSecond);
        /*DEBUG*/xASSERT(666   == usMSec);
    }

    //-------------------------------------
    //bSet
    {
        CxDateTime dtDT;

        ULONGLONG  ui64DT = 1000 * 60 * 60; //1 ���

        USHORT     usYear   = 0;
        USHORT     usMonth  = 0;
        USHORT     usDay    = 0;
        USHORT     usHour   = 0;
        USHORT     usMinute = 0;
        USHORT     usSecond = 0;
        USHORT     usMSec   = 0;

        m_bRes = dtDT.bSet(ui64DT);
        /*DEBUG*/xASSERT(FALSE != m_bRes);

        m_bRes = dtDT.bGet(&usYear, &usMonth, &usDay, &usHour, &usMinute, &usSecond, &usMSec);
        /*DEBUG*/xASSERT(FALSE != m_bRes);

        /*DEBUG*/xASSERT(0 == usYear);
        /*DEBUG*/xASSERT(0 == usMonth);
        /*DEBUG*/xASSERT(0 == usDay);
        /*DEBUG*/xASSERT(1 == usHour);
        /*DEBUG*/xASSERT(0 == usMinute);
        /*DEBUG*/xASSERT(0 == usSecond);
        /*DEBUG*/xASSERT(0 == usMSec);
    }

    //-------------------------------------
    //��������������
    {
        CxDateTime dtDT(2010, 1, 14, 17, 0, 55, 666);
        m_sRes = dtDT.sGetTimeStr();
        xASSERT(xT("17:00:55:666") == m_sRes);
    }
    {
        CxDateTime dtDT(2010, 1, 14, 17, 0, 55, 666);
        m_sRes = dtDT.sGetDateStr();
        xASSERT(xT("14.01.2010") == m_sRes);
    }
    {
        CxDateTime dtDT(2010, 1, 14, 17, 0, 55, 666);
        m_sRes = dtDT.sGetDateTimeStr();
        xASSERT(xT("14.01.2010 17:00:55:666") == m_sRes);
    }





    /****************************************************************************
    * static
    *
    *****************************************************************************/

    //-------------------------------------
    //static
    {
        ////static BOOL        bIsValid          (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
    }

    //-------------------------------------
    //dtGetCurrent
    {
        CxDateTime dtNowDT;

        m_sRes = dtNowDT.dtGetCurrent().sGetDateTimeStr();
        xASSERT(xT("00.00.0000 0:00:00:000") != m_sRes);
        ////LOG("dtDT.sFormatToStr()", m_sRes);
    }

    //-------------------------------------
    //bMSecToSystemTime, ui64SystemTimeToMSec
    {
        ////ULONGLONG  ullMs       = (999UL                           )     ;
        ////ULONGLONG  ullSec      = (1000ULL                         ) * 59;
        ////ULONGLONG  ullMin      = (1000ULL * 60                    ) * 59;
        ////ULONGLONG  ullHour     = (1000ULL * 60 * 60               ) * 23;
        ////ULONGLONG  ullDay      = (1000ULL * 60 * 60 * 24          ) * 27;
        ////ULONGLONG  ullMonth    = (1000ULL * 60 * 60 * 24 * 30     ) * 11;
        ////ULONGLONG  ullYear     = (1000ULL * 60 * 60 * 24 * 30 * 12) * 65535ULL;

        ////ULONGLONG  ullMilliSec = ullMs + ullSec + ullMin + ullHour + ullDay + ullMonth + ullYear;
        ////SYSTEMTIME stST        = {0};

        ////m_bRes = CxDateTime::bMSecToSystemTime(ullMilliSec, &stST);
        ////////LOG("CxDateTime::bMSecToDateTime(ullMilliSec, stST)", m_bRes);

        ////m_ui64Res = CxDateTime::ui64SystemTimeToMSec(stST);
        ////////LOG("CxDateTime::ui64SystemTimeToMSec(stST)", m_ui64Res);

        ////xASSERT(ullMilliSec == m_ui64Res);
    }

    //-------------------------------------
    //sMSecToTimeString
    {
        ////static tString     sMSecToTimeString (ULONGLONG ui64MSec);
    }

    //-------------------------------------
    //i64FiletimeToInt64
    {
        ////static LONGLONG    i64FiletimeToInt64(FILETIME ftTime);
    }

    //-------------------------------------
    //usDaysInMonth
    {
        for (USHORT y = 0; y < 3000; ++ y) {
            for (USHORT m = 1; m < 13; ++ m) {
                m_usiRes = CxDateTime::usDaysInMonth(y, m);

                if (2 == m && CxDateTime::bIsLeapYear(y)) {
                    xASSERT(29 == m_usiRes);
                } else {
                    USHORT arusDaysOfMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

                    xASSERT(m_usiRes == arusDaysOfMonth[m]);
                }
            } //m
        } //y

    }

    //-------------------------------------
    //bIsLeapYear
    {
        ////static BOOL        bIsLeapYear       (USHORT usYear);
    }


    /****************************************************************************
    *   ������
    *
    *****************************************************************************/

    //-------------------------------------
    //sGetZodiacSign
    {
        /*
        -----------------------------------------------------
        |  Знак     |  Символ  |  Западная астрология       |
        -----------------------------------------------------
        |  Овеен    |  U+2648  |  21 марта    — 20 апреля   |
        |  Телец    |  U+2649  |  21 апреля   — 21 мая      |
        |  Близнецы |  U+264A  |  22 мая      — 21 июня     |
        |  Рак      |  U+264B  |  22 июня     — 23 июля     |
        |  Лев      |  U+264С  |  24 июля     — 23 августа  |
        |  Дева     |  U+264D  |  24 августа  — 23 сентября |
        |  Весы     |  U+264E  |  24 сентября — 23 октября  |
        |  Скорпион |  U+264F  |  24 октября  — 22 ноября   |
        |  Стрелец  |  U+2650  |  23 ноября   — 21 декабря  |
        |  Козерог  |  U+2651  |  22 декабря  — 20 января   |
        |  Водолей  |  U+2652  |  21 января   — 19 февраля  |
        |  Рыбы     |  U+2653  |  20 февраля  — 20 марта    |
        -----------------------------------------------------
        */

        tString sTestData[][3] = {
            {xT("7"), xT("31"), xT("Лев")},
            {xT("5"), xT("18"), xT("Телец")},
        };

        for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
            tString sStr1 = CxDateTime::sGetZodiacSign(CxString::lexical_cast<INT>(sTestData[i][0]),
                                                       CxString::lexical_cast<INT>(sTestData[i][1]));
            tString sStr2 = sTestData[i][2];
            xASSERT(sStr1 == sStr2);
        }
    }

    //-------------------------------------
    //sGetMonthStr
    {
        //bIsShortName = FALSE
        m_sRes = CxDateTime::sGetMonthStr(- 1, FALSE);
        xASSERT(xT("December") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(0, FALSE);
        xASSERT(xT("January") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(1, FALSE);
        xASSERT(xT("January") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(2, FALSE);
        xASSERT(xT("February") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(3, FALSE);
        xASSERT(xT("March") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(4, FALSE);
        xASSERT(xT("April") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(5, FALSE);
        xASSERT(xT("May") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(6, FALSE);
        xASSERT(xT("June") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(7, FALSE);
        xASSERT(xT("July") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(8, FALSE);
        xASSERT(xT("August") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(9, FALSE);
        xASSERT(xT("September") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(10, FALSE);
        xASSERT(xT("October") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(11, FALSE);
        xASSERT(xT("November") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(12, FALSE);
        xASSERT(xT("December") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(13, FALSE);
        xASSERT(xT("December") == m_sRes);

        //bIsShortName = TRUE
        m_sRes = CxDateTime::sGetMonthStr(- 1, TRUE);
        xASSERT(xT("Dec") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(0, TRUE);
        xASSERT(xT("Jan") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(1, TRUE);
        xASSERT(xT("Jan") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(2, TRUE);
        xASSERT(xT("Feb") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(3, TRUE);
        xASSERT(xT("Mar") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(4, TRUE);
        xASSERT(xT("Apr") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(5, TRUE);
        xASSERT(xT("May") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(6, TRUE);
        xASSERT(xT("Jun") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(7, TRUE);
        xASSERT(xT("Jul") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(8, TRUE);
        xASSERT(xT("Aug") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(9, TRUE);
        xASSERT(xT("Sep") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(10, TRUE);
        xASSERT(xT("Oct") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(11, TRUE);
        xASSERT(xT("Nov") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(12, TRUE);
        xASSERT(xT("Dec") == m_sRes);
        m_sRes = CxDateTime::sGetMonthStr(13, TRUE);
        xASSERT(xT("Dec") == m_sRes);
    }

    //-------------------------------------
    //sGetWeekDayStr
    {
        //bIsShortName = FALSE
        m_sRes = CxDateTime::sGetWeekDayStr(- 1, FALSE);
        xASSERT(xT("Sunday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(0, FALSE);
        xASSERT(xT("Monday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(1, FALSE);
        xASSERT(xT("Monday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(2, FALSE);
        xASSERT(xT("Tuesday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(3, FALSE);
        xASSERT(xT("Wednesday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(4, FALSE);
        xASSERT(xT("Thursday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(5, FALSE);
        xASSERT(xT("Friday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(6, FALSE);
        xASSERT(xT("Saturday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(7, FALSE);
        xASSERT(xT("Sunday") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(8, FALSE);
        xASSERT(xT("Sunday") == m_sRes);

        //bIsShortName = TRUE
        m_sRes = CxDateTime::sGetWeekDayStr(- 1, TRUE);
        xASSERT(xT("Sun") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(0, TRUE);
        xASSERT(xT("Mon") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(1, TRUE);
        xASSERT(xT("Mon") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(2, TRUE);
        xASSERT(xT("Tue") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(3, TRUE);
        xASSERT(xT("Wed") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(4, TRUE);
        xASSERT(xT("Thu") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(5, TRUE);
        xASSERT(xT("Fri") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(6, TRUE);
        xASSERT(xT("Sat") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(7, TRUE);
        xASSERT(xT("Sun") == m_sRes);
        m_sRes = CxDateTime::sGetWeekDayStr(8, TRUE);
        xASSERT(xT("Sun") == m_sRes);
    }

//---------------------------------------------------------------------------
//int Func () {
//    time_t start,end;
//    char szInput [256];
//    double dif;
//
//    time (&start);
//
//    printf ("Please, enter your name: ");   gets (szInput);
//    time (&end);
//
//    dif = difftime (end, start);
//
//    printf ("Hi %s.\n", szInput);
//    printf ("It took you %.2lf seconds to type your name.\n", dif );
//
//    return 0;
//}
//---------------------------------------------------------------------------

//////ATLTIME_INLINE CTime CTime::operator-( CTimeSpan span ) const throw()
//////  {
//////  return( CTime( m_time-span.GetTimeSpan() ) );
//////  }

//////ATLTIME_INLINE CTime CTime::operator+( CTimeSpan span ) const throw()
//////  {
//////  return( CTime( m_time+span.GetTimeSpan() ) );
//////  }


	{
		CxDateTime dtDT(2010, 1, 14, 17, 0, 55, 666);
		m_sRes = dtDT.sGetDateTimeStr(); 
		xASSERT(xT("14.01.2010 17:00:55:666") == m_sRes);
	}





	/****************************************************************************
	* static
	*
	*****************************************************************************/

	//-------------------------------------
	//static
	{
		////static BOOL        bIsValid          (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec);
	}
	
	//-------------------------------------
	//dtGetCurrent
	{
		CxDateTime dtNowDT;

		m_sRes = dtNowDT.dtGetCurrent().sGetDateTimeStr(); 
		xASSERT(xT("00.00.0000 0:00:00:000") != m_sRes);
		////LOG("dtDT.sFormatToStr()", m_sRes);
	}

	//-------------------------------------
	//bMSecToSystemTime, ui64SystemTimeToMSec
	{
		////ULONGLONG  ullMs       = (999UL                           )     ;
		////ULONGLONG  ullSec      = (1000ULL                         ) * 59;
		////ULONGLONG  ullMin      = (1000ULL * 60                    ) * 59;
		////ULONGLONG  ullHour     = (1000ULL * 60 * 60               ) * 23;
		////ULONGLONG  ullDay      = (1000ULL * 60 * 60 * 24          ) * 27;
		////ULONGLONG  ullMonth    = (1000ULL * 60 * 60 * 24 * 30     ) * 11;
		////ULONGLONG  ullYear     = (1000ULL * 60 * 60 * 24 * 30 * 12) * 65535ULL;

		////ULONGLONG  ullMilliSec = ullMs + ullSec + ullMin + ullHour + ullDay + ullMonth + ullYear;
		////SYSTEMTIME stST        = {0};

		////m_bRes = CxDateTime::bMSecToSystemTime(ullMilliSec, &stST); 
		////////LOG("CxDateTime::bMSecToDateTime(ullMilliSec, stST)", m_bRes);

		////m_ui64Res = CxDateTime::ui64SystemTimeToMSec(stST);
		////////LOG("CxDateTime::ui64SystemTimeToMSec(stST)", m_ui64Res);

		////xASSERT(ullMilliSec == m_ui64Res);
	}

	//-------------------------------------
	//sMSecToTimeString
	{
		////static tString     sMSecToTimeString (ULONGLONG ui64MSec); 
	}

	//-------------------------------------
	//i64FiletimeToInt64
	{
		////static LONGLONG    i64FiletimeToInt64(FILETIME ftTime);	
	}

	//-------------------------------------
	//usDaysInMonth
	{
		for (USHORT y = 0; y < 3000; ++ y) {
			for (USHORT m = 1; m < 13; ++ m) {
				m_usiRes = CxDateTime::usDaysInMonth(y, m);

				if (2 == m && CxDateTime::bIsLeapYear(y)) {
					xASSERT(29 == m_usiRes);
				} else {
					USHORT arusDaysOfMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
					
					xASSERT(m_usiRes == arusDaysOfMonth[m]);
				}
			} //m			
		} //y
		
	}

	//-------------------------------------
	//bIsLeapYear
	{
		////static BOOL        bIsLeapYear       (USHORT usYear);
	}


	/****************************************************************************
	*	??????
	*
	*****************************************************************************/

	//-------------------------------------
	//sGetZodiacSign
	{
		/*
        -----------------------------------------------------
        |  Знак     |  Символ  |  Западная астрология       |
        -----------------------------------------------------
        |  Овеен    |  U+2648  |  21 марта    — 20 апреля   |
        |  Телец    |  U+2649  |  21 апреля   — 21 мая      |
        |  Близнецы |  U+264A  |  22 мая      — 21 июня     |
        |  Рак      |  U+264B  |  22 июня     — 23 июля     |
        |  Лев      |  U+264С  |  24 июля     — 23 августа  |
        |  Дева     |  U+264D  |  24 августа  — 23 сентября |
        |  Весы     |  U+264E  |  24 сентября — 23 октября  |
        |  Скорпион |  U+264F  |  24 октября  — 22 ноября   |
        |  Стрелец  |  U+2650  |  23 ноября   — 21 декабря  |
        |  Козерог  |  U+2651  |  22 декабря  — 20 января   |
        |  Водолей  |  U+2652  |  21 января   — 19 февраля  |
        |  Рыбы     |  U+2653  |  20 февраля  — 20 марта    |
        -----------------------------------------------------
		*/
		
		const tString sTestData[][3] = {
			{xT("7"), xT("31"),	xT("Лев")},
			{xT("5"), xT("18"), xT("Телец")},
		};

		for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
			tString sStr1 = CxDateTime::sGetZodiacSign(CxString::lexical_cast<INT>(sTestData[i][0]), 
													   CxString::lexical_cast<INT>(sTestData[i][1]));
			tString sStr2 = sTestData[i][2];
			xASSERT(sStr1 == sStr2);
		}
	}

	//-------------------------------------
	//sGetMonthStr
	{
		//bIsShortName = FALSE
		m_sRes = CxDateTime::sGetMonthStr(- 1, FALSE); 
		xASSERT(xT("December") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(0, FALSE); 
		xASSERT(xT("January") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(1, FALSE); 
		xASSERT(xT("January") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(2, FALSE); 
		xASSERT(xT("February") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(3, FALSE); 
		xASSERT(xT("March") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(4, FALSE); 
		xASSERT(xT("April") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(5, FALSE); 
		xASSERT(xT("May") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(6, FALSE); 
		xASSERT(xT("June") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(7, FALSE); 
		xASSERT(xT("July") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(8, FALSE); 
		xASSERT(xT("August") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(9, FALSE); 
		xASSERT(xT("September") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(10, FALSE); 
		xASSERT(xT("October") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(11, FALSE); 
		xASSERT(xT("November") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(12, FALSE); 
		xASSERT(xT("December") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(13, FALSE); 
		xASSERT(xT("December") == m_sRes); 

		//bIsShortName = TRUE
		m_sRes = CxDateTime::sGetMonthStr(- 1, TRUE); 
		xASSERT(xT("Dec") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(0, TRUE); 
		xASSERT(xT("Jan") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(1, TRUE); 
		xASSERT(xT("Jan") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(2, TRUE); 
		xASSERT(xT("Feb") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(3, TRUE); 
		xASSERT(xT("Mar") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(4, TRUE); 
		xASSERT(xT("Apr") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(5, TRUE); 
		xASSERT(xT("May") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(6, TRUE); 
		xASSERT(xT("Jun") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(7, TRUE); 
		xASSERT(xT("Jul") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(8, TRUE); 
		xASSERT(xT("Aug") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(9, TRUE); 
		xASSERT(xT("Sep") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(10, TRUE); 
		xASSERT(xT("Oct") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(11, TRUE); 
		xASSERT(xT("Nov") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(12, TRUE); 
		xASSERT(xT("Dec") == m_sRes); 
		m_sRes = CxDateTime::sGetMonthStr(13, TRUE); 
		xASSERT(xT("Dec") == m_sRes); 
	}

	//-------------------------------------
	//sGetWeekDayStr
	{
		//bIsShortName = FALSE
		m_sRes = CxDateTime::sGetWeekDayStr(- 1, FALSE); 
		xASSERT(xT("Sunday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(0, FALSE); 
		xASSERT(xT("Monday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(1, FALSE); 
		xASSERT(xT("Monday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(2, FALSE); 
		xASSERT(xT("Tuesday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(3, FALSE); 
		xASSERT(xT("Wednesday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(4, FALSE); 
		xASSERT(xT("Thursday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(5, FALSE); 
		xASSERT(xT("Friday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(6, FALSE); 
		xASSERT(xT("Saturday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(7, FALSE); 
		xASSERT(xT("Sunday") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(8, FALSE); 
		xASSERT(xT("Sunday") == m_sRes); 

		//bIsShortName = TRUE
		m_sRes = CxDateTime::sGetWeekDayStr(- 1, TRUE); 
		xASSERT(xT("Sun") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(0, TRUE); 
		xASSERT(xT("Mon") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(1, TRUE); 
		xASSERT(xT("Mon") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(2, TRUE); 
		xASSERT(xT("Tue") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(3, TRUE); 
		xASSERT(xT("Wed") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(4, TRUE); 
		xASSERT(xT("Thu") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(5, TRUE); 
		xASSERT(xT("Fri") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(6, TRUE); 
		xASSERT(xT("Sat") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(7, TRUE); 
		xASSERT(xT("Sun") == m_sRes); 
		m_sRes = CxDateTime::sGetWeekDayStr(8, TRUE); 
		xASSERT(xT("Sun") == m_sRes); 
	}	

	return TRUE;
}
//---------------------------------------------------------------------------
int Func ()	{
//	time_t start,end;
//	char szInput [256];
//	double dif;
//
//	time (&start);
//
//	printf ("Please, enter your name: ");	gets (szInput);
//	time (&end);
//
//	dif = difftime (end, start);
//
//	printf ("Hi %s.\n", szInput);
//	printf ("It took you %.2lf seconds to type your name.\n", dif );

	return 0;
}
//---------------------------------------------------------------------------

//////ATLTIME_INLINE CTime CTime::operator-( CTimeSpan span ) const throw()
//////	{
//////	return( CTime( m_time-span.GetTimeSpan() ) );
//////	}

//////ATLTIME_INLINE CTime CTime::operator+( CTimeSpan span ) const throw()
//////	{
//////	return( CTime( m_time+span.GetTimeSpan() ) );
//////	}

