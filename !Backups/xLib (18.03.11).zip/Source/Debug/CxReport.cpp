/****************************************************************************
* Class name:  CxReport
* Description: debug message
* File name:   CxReport.cpp
* Compilers:   Visual C++ 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     1 лют. 2011 13:58:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Debug/CxReport.h>

#include <xLib/Common/CxException.h>
#include <xLib/Common/CxDateTime.h>
#include <xLib/Common/CxSystemInfo.h>
#include <xLib/Filesystem/CxPath.h>
#include <xLib/Sync/CxProcess.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: CxReport (constructor)
CxReport::CxReport(
        const tString &csExp, 
        ULONG          ulLastError, 
        const tString &csFile, 
        ULONG          ulLine, 
        const tString &csFunc, 
        const tString &csDate, 
        const tString &csTime, 
        ULONG          ulOSVersion, 
        LPCTSTR        pcszComment, 
        ...
) :
    _m_sReport        (),
    _m_sProgram       (),
    _m_ulProcessId    (0),
    _m_ulThreadId     (0),
    _m_sSourceFile    (),
    _m_ulSourceLine   (0),
    _m_sFunctionName  (),
    _m_sExpression    (),
    _m_ulLastError    (),
    _m_sLastErrorStr  (),
    _m_sCurrentDate   (),
    _m_sBuildDate     (),
    _m_sOsVersion     (),
    _m_sOsArchitecture(),
    _m_sComment       ()
{
    /*DEBUG*/
    
    tString sComment;
    va_list palArgs;

    va_start(palArgs, pcszComment);
    sComment = CxString::sFormatV(pcszComment, palArgs);
    va_end(palArgs);

    _bInit(csExp, ulLastError, csFile, ulLine, csFunc, csDate, csTime, ulOSVersion, sComment.c_str());
}
//---------------------------------------------------------------------------
//DONE: ~CxReport (destructor)
CxReport::~CxReport() {
    /*DEBUG*/
}
//---------------------------------------------------------------------------
//DONE: sGetReport (get report)
tString
CxReport::sGetReport() const {
    /*DEBUG*/

    return _m_sReport;
}
//---------------------------------------------------------------------------
//DONE: sGetProgram (get program name)
tString
CxReport::sGetProgram() const {
    /*DEBUG*/

    return _m_sProgram;
}
//---------------------------------------------------------------------------
//DONE: ulGetProcessId (get process id)
ULONG
CxReport::ulGetProcessId() const {
    /*DEBUG*/

    return _m_ulProcessId;
}
//---------------------------------------------------------------------------
//DONE: ulGetThreadId (get thread id)
ULONG
CxReport::ulGetThreadId() const {
    /*DEBUG*/

    return _m_ulThreadId;
}
//---------------------------------------------------------------------------
//DONE: sGetSourceFile (get source file path)
tString
CxReport::sGetSourceFile() const {
    /*DEBUG*/

    return _m_sSourceFile;
}
//---------------------------------------------------------------------------
//DONE: ulGetSourceLine (get source file line)
ULONG
CxReport::ulGetSourceLine() const {
    /*DEBUG*/

    return _m_ulSourceLine;
}
//---------------------------------------------------------------------------
//DONE: sGetFunctionName (get source function name)
tString
CxReport::sGetFunctionName() const {
    /*DEBUG*/

    return _m_sFunctionName;
}
//---------------------------------------------------------------------------
//DONE: sGetExpression (get expression)
tString
CxReport::sGetExpression() const {
    /*DEBUG*/

    return _m_sExpression;
}
//---------------------------------------------------------------------------
//DONE: ulGetLastError (get last error)
ULONG
CxReport::ulGetLastError() const {
    /*DEBUG*/

    return _m_ulLastError;
}
//---------------------------------------------------------------------------
//TODO: - sGetLastErrorStr (get formatting last error)
tString
CxReport::sGetLastErrorStr() const {
    /*DEBUG*/

    return _m_sLastErrorStr;
}
//---------------------------------------------------------------------------
//DONE: sGetCurrentDate (get current datetime)
tString
CxReport::sGetCurrentDate() const {
    /*DEBUG*/

    return _m_sCurrentDate;
}
//---------------------------------------------------------------------------
//DONE: sGetBuildDate (get build datetime)
tString
CxReport::sGetBuildDate() const {
    /*DEBUG*/

    return _m_sBuildDate;
}
//---------------------------------------------------------------------------
//DONE: sGetOsVersion (get build OS version)
tString
CxReport::sGetOsVersion() const {
    /*DEBUG*/

    return _m_sOsVersion;
}

//---------------------------------------------------------------------------
//DONE: sGetOsArchitecture (get OS architecture)
tString
CxReport::sGetOsArchitecture() const {
    /*DEBUG*/

    return _m_sOsArchitecture;
}
//---------------------------------------------------------------------------
//DONE: sGetComment (get comment)
tString
CxReport::sGetComment() const {
    /*DEBUG*/

    return _m_sComment;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: _bInit (formatting message, init class members)
BOOL
CxReport::_bInit(
    const tString &csExp, 
    ULONG          ulLastError, 
    const tString &csFile, 
    ULONG          ulLine, 
    const tString &csFunc, 
    const tString &csDate, 
    const tString &csTime, 
    ULONG          ulOSVersion, 
    const tString &csComment)
{
    /*DEBUG*/

    _m_sProgram        = CxPath::sGetExe();
    _m_ulProcessId     = CxProcess::ulGetCurrId();
    _m_ulThreadId      = 0;  //TODO: ulThreadId

    _m_sSourceFile     = csFile;
    _m_ulSourceLine    = ulLine;
    _m_sFunctionName   = csFunc;
    _m_sExpression     = csExp;
    _m_ulLastError     = ulLastError;
    _m_sLastErrorStr   = CxString::sFormat(xT("%u - \"%s\""),  ulLastError, CxLastError::sFormat(ulLastError).c_str());

    _m_sCurrentDate    = CxDateTime::dtGetCurrent().sGetDateTimeStr();
    _m_sBuildDate      = CxString::sFormat(xT("%s/%s"), csDate.c_str(), csTime.c_str());
    _m_sOsVersion      = CxSystemInfo::sFormatOsVersion(ulOSVersion);
    _m_sOsArchitecture = _sGetOsArchitecture();

    _m_sComment        = (true == csComment.empty()) ? xT("-") : csComment.data();

    _m_sReport         = CxString::sFormat(
                            xT("%s\n")        //CxReport
                            xT("\n")

                            xT("%s%s\n")      //Program
                            xT("%s%u\n")      //Process id
                            xT("%s%u\n")      //Thread id
                            xT("\n")

                            xT("%s%s\n")      //Source file
                            xT("%s%u\n")      //Source line
                            xT("%s%s\n")      //Function name
                            xT("%s%s\n")      //Expression
                            xT("%s%s\n")      //Last error
                            xT("\n")

                            xT("%s%s\n")      //Current date
                            xT("%s%s\n")      //Build date
                            xT("%s%s\n")      //OS version
                            xT("%s%s\n")      //OS architecture
                            xT("\n")

                            xT("%s%s"),       //Comment

                            xT("CxReport         "),
                            xT("Program:         "), _m_sProgram.data(),
                            xT("Process id:      "), _m_ulProcessId,
                            xT("Thread id:       "), _m_ulThreadId,

                            xT("Source file:     "), _m_sSourceFile.data(),
                            xT("Source line:     "), _m_ulSourceLine,
                            xT("Function name:   "), _m_sFunctionName.data(),
                            xT("Expression:      "), _m_sExpression.data(),
                            xT("Last error:      "), _m_sLastErrorStr.data(),

                            xT("Current date:    "), _m_sCurrentDate.data(),
                            xT("Build date:      "), _m_sBuildDate.data(),
                            xT("OS version:      "), _m_sOsVersion.data(),
                            xT("OS architecture: "), _m_sOsArchitecture.data(),

                            xT("Comment:         "), _m_sComment.data());

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: _sGetOsArchitecture (get OS architecture)
tString
CxReport::_sGetOsArchitecture() {
    /*DEBUG*/// n/a

    tString sRes;

    switch (CxSystemInfo::oaGetOsArchitecture()) {
        case CxSystemInfo::oa32bit:     sRes = xT("32-bit");    break;
        case CxSystemInfo::oa64bit:     sRes = xT("64-bit");    break;
        case CxSystemInfo::oaUnknown:   sRes = xT("Unknown");   break;

        default:                        sRes = xT("Unknown");   break;
    }

    return sRes;
}
//---------------------------------------------------------------------------

