/****************************************************************************
* Class name:  CxCookie
* Description: cookie (http://www.ietf.org/rfc/rfc2109.txt)
* File name:   CxCookie.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     26.01.2011 0:04:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Net/CxCookie.h>

#include <xLib/Filesystem/CxEnvironment.h>


/****************************************************************************
*   public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: CxCookie (constructor)
CxCookie::CxCookie() :
    _m_msCookie()
{
    /*DEBUG*/

    BOOL bRes = FALSE;

    bRes = CxCookie::_bParse(CxEnvironment::sGetVar("HTTP_COOKIE"), &_m_msCookie);   // call only one time
    /*DEBUG*/xASSERT_DO(FALSE != bRes, return);

    xTRACEV(xT("HTTP_COOKIE (%zu bytes): %s"), CxEnvironment::sGetVar("HTTP_COOKIE").size(), CxEnvironment::sGetVar("HTTP_COOKIE").c_str());
}
//---------------------------------------------------------------------------
//DONE: CxCookie (constructor)
CxCookie::CxCookie(const tString &csRawCookie) :
    _m_msCookie()
{
    /*DEBUG*/

    BOOL bRes = FALSE;

    bRes = CxCookie::_bParse(csRawCookie, &_m_msCookie);   // call only one time
    /*DEBUG*/xASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//DONE: ~CxCookie (destructor)
/*virtual*/
CxCookie::~CxCookie() {
    /*DEBUG*/

}
//---------------------------------------------------------------------------
//DONE: bAttrIsExists (is attribute exists)
BOOL
CxCookie::bAttrIsExists(const tString &csName) const {
    /*DEBUG*/

    xCHECK_RET(_m_msCookie.end() == _m_msCookie.find(csName), FALSE);

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: sAttrGet (get attribute)
tString
CxCookie::sAttrGet(const tString &csName) const {
    /*DEBUG*/

    xCHECK_RET(FALSE == bAttrIsExists(csName), tString());

    return _m_msCookie.find(csName)->second;
}
//---------------------------------------------------------------------------
//DONE: sAttrSet (set attribute)
BOOL
CxCookie::sAttrSet(const tString &csName, const tString &csValue) {
    /*DEBUG*/

    _m_msCookie[csName] = csValue;

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: sToString (get raw cookie string)
tString
CxCookie::sToString(const tString &csName) {
    /*DEBUG*/

    //join into string (name1=value1; name2=value2; nameN=valueN)
//    TStringMap::const_iterator it;
//    for (it = _m_msCookie.begin(); it != _m_msCookie.end(); ++ it) {
//        if (FALSE == CxString::bCompareNoCase(xT("secure"), (*it).first)) {
//            (*psRawCookie).append((*it).first);
//            (*psRawCookie).append(xT("="));
//            (*psRawCookie).append((*it).second);
//            (*psRawCookie).append(xT("; "));
//        } else {
//            (*psRawCookie).append((*it).first);
//        }
//    }
//
//    *psRawCookie = CxString::sTrimSpace(*psRawCookie);

//    tString sRes;
//
//    sRes.append(_value);
//
//    if (!_domain.empty()) {
//        sRes.append("; domain=");
//        sRes.append(_domain);
//    }
//    if (!_path.empty()) {
//        sRes.append("; path=");
//        sRes.append(_path);
//    }
//    if (_maxAge >= 0) {
//        Timestamp ts;
//        ts += _maxAge*Timestamp::resolution();
//        sRes.append("; expires=");
//        DateTimeFormatter::append(sRes, ts, DateTimeFormat::HTTP_FORMAT);
//    }
//    if (_secure) {
//        sRes.append("; secure");
//    }
//    if (_httpOnly)  {
//        sRes.append("; HttpOnly");


    return tString();
}
//---------------------------------------------------------------------------


/****************************************************************************
*    private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: _bParse (parsing raw cookie string)
BOOL
_bParse(const tString &csRawCookie, TStringMap *pmsCookie) {
    /*DEBUG*/// _m_msCookie  - n/a
    /*DEBUG*/// csRawCookie - n/a
    /*DEBUG*/xASSERT_RET(NULL != pmsCookie,            FALSE);
    /*DEBUG*/xASSERT_RET(true == (*pmsCookie).empty(), FALSE);

    BOOL bRes = FALSE;

    (*pmsCookie).clear();

    //split into pairs (name1=value1; name2=value2; nameN=valueN)
    std::vector<tString> vecsPairs;

    bRes = CxString::bSplit(csRawCookie, xT(";"), &vecsPairs);
    /*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

    for (size_t i = 0; i < vecsPairs.size(); ++ i) {
        //split into name, value (name=value)
        std::vector<tString> vecsTemp;

        bRes = CxString::bSplit(vecsPairs.at(i), xT("="), &vecsTemp);
        /*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

        tString sCookieName  = CxString::sTrimSpace(vecsTemp.at(0));
        tString sCookieValue = ( (1 == vecsTemp.size()) ? tString() : vecsTemp.at(1) );

        (*pmsCookie).insert( std::pair<tString, tString>(sCookieName, sCookieValue) );
    }

    return TRUE;
}
//---------------------------------------------------------------------------


