/****************************************************************************
* Class name:  CxDateTime
* Description: date, time
* File name:   CxDateTime.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Common/CxDateTime.h>


/****************************************************************************
*	public	
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime() :
	_m_bRes            (FALSE),
	////--_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/
}
//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime(const CxDateTime &dtDT) :
	_m_bRes            (FALSE),
	////--_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/

	_m_bRes = bSet(dtDT._m_usYear, dtDT._m_usMonth,  dtDT._m_usDay, 
		           dtDT._m_usHour, dtDT._m_usMinute, dtDT._m_usSecond, dtDT._m_usMSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime(ULONGLONG ui64MSec) :
	_m_bRes            (FALSE),
	////--_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/

	_m_bRes = bSet(ui64MSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime(USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec) : 
	_m_bRes            (FALSE),
	////--_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/

	_m_bRes = bSet(0, 0, 0, usHour, usMinute, usSecond, usMSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime(USHORT usYear, USHORT usMonth, USHORT usDay) :
	_m_bRes            (FALSE),
	////--_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/

	_m_bRes = bSet(usYear, usMonth, usDay, 0, 0, 0, 0);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
} 
//---------------------------------------------------------------------------
//TODO: + CxDateTime (constructor)
CxDateTime::CxDateTime(USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec) : 
	_m_bRes            (FALSE),
	////---_m_stDateTime      (),
	_m_ui64DateTimeMSec(0),
	_m_usYear          (0),
	_m_usMonth         (0),
	_m_usDay           (0),
	_m_usHour          (0),
	_m_usMinute        (0),
	_m_usSecond        (0),
	_m_usMSec          (0)
{
	/*DEBUG*/

	_m_bRes = bSet(usYear, usMonth, usDay, usHour, usMinute, usSecond, usMSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CxDateTime (destructor)
CxDateTime::~CxDateTime() { 
	/*DEBUG*/
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: операторы сравнения	
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + operator ==  
BOOL
CxDateTime::operator == (const CxDateTime &dtDT) const {
	return static_cast<BOOL>(_m_ui64DateTimeMSec == dtDT._m_ui64DateTimeMSec);
}
//---------------------------------------------------------------------------
//TODO: + operator !=  
BOOL
CxDateTime::operator != (const CxDateTime &dtDT) const {
	return static_cast<BOOL>( _m_ui64DateTimeMSec != dtDT._m_ui64DateTimeMSec );
}
//---------------------------------------------------------------------------
//TODO: + operator <
BOOL
CxDateTime::operator <  (const CxDateTime &dtDT) const {
	return static_cast<BOOL>( _m_ui64DateTimeMSec < dtDT._m_ui64DateTimeMSec );
}
//---------------------------------------------------------------------------
//TODO: + operator <= 
BOOL
CxDateTime::operator <= (const CxDateTime &dtDT) const {
	return static_cast<BOOL>( _m_ui64DateTimeMSec <= dtDT._m_ui64DateTimeMSec );
}
//---------------------------------------------------------------------------
//TODO: + operator >
BOOL
CxDateTime::operator > (const CxDateTime &dtDT) const {
	return static_cast<BOOL>( _m_ui64DateTimeMSec > dtDT._m_ui64DateTimeMSec );
}
//---------------------------------------------------------------------------
//TODO: + operator >=
BOOL
CxDateTime::operator >= (const CxDateTime &dtDT) const {
	return static_cast<BOOL>( _m_ui64DateTimeMSec >= dtDT._m_ui64DateTimeMSec );
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: операторы присваивания
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + operator = ()
CxDateTime &
CxDateTime::operator = (const CxDateTime &dtDT) {
	/*DEBUG*/

	xCHECK_RET(this == &dtDT, *this);

	_m_bRes = bSet(dtDT._m_ui64DateTimeMSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, CxDateTime());

	return *this;
}
//--------------------------------------------------------------------------
//TODO: + operator = ()
#ifdef __BORLANDC__
CxDateTime &
CxDateTime::operator = (const TDateTime &dtDT) {
	/*DEBUG*/

	USHORT usYear   = 0;
	USHORT usMonth  = 0;
	USHORT usDay    = 0;
	USHORT usHour   = 0;
	USHORT usMinute = 0;
	USHORT usSecond = 0;
	USHORT usMSec   = 0;	

	dtDT.DecodeDate(&usYear, &usMonth, &usDay);
	/*DEBUG*/// n/a
	dtDT.DecodeTime(&usHour, &usMinute, &usSecond, &usMSec);
	/*DEBUG*/// n/a

	_m_bRes = bSet(usYear, usMonth, usDay, usHour, usMinute, usSecond, usMSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, CxDateTime());

	return *this;
}
#endif
//---------------------------------------------------------------------------
//TODO: - operator = ()
CxDateTime &
CxDateTime::operator = (ULONGLONG ui64MSec) {
	/*DEBUG*/

	_m_bRes = bSet(ui64MSec);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, CxDateTime());

	return *this;
}
//--------------------------------------------------------------------------
//TODO: + operator + ()
CxDateTime
CxDateTime::operator + (const CxDateTime &dtDT) const {
	/*DEBUG*/

	return CxDateTime(_m_ui64DateTimeMSec + dtDT._m_ui64DateTimeMSec);
}
//--------------------------------------------------------------------------
//TODO: + operator - ()
CxDateTime
CxDateTime::operator - (const CxDateTime &dtDT) const {
	/*DEBUG*/

	return CxDateTime(_m_ui64DateTimeMSec - dtDT._m_ui64DateTimeMSec);
}
//--------------------------------------------------------------------------
//TODO: + operator += ()
CxDateTime &
CxDateTime::operator += (const CxDateTime &dtDT) {
	/*DEBUG*/

	//_m_ui64DateTimeMSec
	_m_ui64DateTimeMSec += dtDT._m_ui64DateTimeMSec;
	
	//_m_stDateTime
	_m_bRes = bMSecToSystemTime(_m_ui64DateTimeMSec/*--, &_m_stDateTime--*/);
	/*DEBUG*/// n/a

	return *this;
}
//--------------------------------------------------------------------------
//TODO: + operator -= ()
CxDateTime &
CxDateTime::operator -= (const CxDateTime &dtDT) {
	/*DEBUG*/

	//_m_ui64DateTimeMSec
	_m_ui64DateTimeMSec -= dtDT._m_ui64DateTimeMSec;

	//_m_stDateTime
	_m_bRes = bMSecToSystemTime(_m_ui64DateTimeMSec/*--, &_m_stDateTime--*/);
	/*DEBUG*/// n/a

	return *this;
}
//--------------------------------------------------------------------------


/****************************************************************************
*	public: 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bGet ()
BOOL
CxDateTime::bGet(USHORT *pusYear, USHORT *pusMonth, USHORT *pusDay, USHORT *pusHour, USHORT *pusMinute, USHORT *pusSecond, USHORT *pusMSec) const {
	/*DEBUG*/

	xCHECK_DO(NULL != pusYear,   *pusYear   = _m_usYear);
	xCHECK_DO(NULL != pusMonth,  *pusMonth  = _m_usMonth); 
	xCHECK_DO(NULL != pusDay,    *pusDay    = _m_usDay); 
	xCHECK_DO(NULL != pusHour,   *pusHour   = _m_usHour); 
	xCHECK_DO(NULL != pusMinute, *pusMinute = _m_usMinute); 
	xCHECK_DO(NULL != pusSecond, *pusSecond = _m_usSecond); 
	xCHECK_DO(NULL != pusMSec,   *pusMSec   = _m_usMSec); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bGet (миллисекунды в CxDateTime)
BOOL
CxDateTime::bSet(ULONGLONG ui64MSec) {
    /*DEBUG*/

	//_m_stDateTime
	_m_bRes = bMSecToSystemTime(ui64MSec/*--, &_m_stDateTime--*/);
	/*DEBUG*/// n/a

	//_m_ui64DateTimeMSec
	_m_ui64DateTimeMSec = ui64MSec;

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bSet (данные в CxDateTime)
BOOL
CxDateTime::bSet(USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec) {
	/*DEBUG*/xASSERT_RET(TRUE == bIsValid(usYear, usMonth, usDay, usHour, usMinute, usSecond, usMSec), FALSE);

	//_m_stDateTime
	_m_usYear         = usYear;
	_m_usMonth        = usMonth;
	_m_usDay          = usDay;
	_m_usHour         = usHour;
	_m_usMinute       = usMinute;
	_m_usSecond       = usSecond;
	_m_usMSec         = usMSec;	

	//_m_ui64DateTimeMSec
	_m_ui64DateTimeMSec = ui64SystemTimeToMSec(/*--_m_stDateTime--*/);

	return TRUE;
}
//--------------------------------------------------------------------------


/****************************************************************************
*	public: formating
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + sGetTimeStr (форматирование времени)
tString
CxDateTime::sGetTimeStr() const {
	/*DEBUG*/// n/a

	return CxString::sFormat(xT("%d:%.2d:%.2d:%.3d"), _m_usHour, _m_usMinute, _m_usSecond, _m_usMSec);
}
//---------------------------------------------------------------------------
//TODO: + sGetDateStr (форматирование даты)
tString CxDateTime::sGetDateStr() const {
	/*DEBUG*/// n/a

	return CxString::sFormat(xT("%.2d.%.2d.%.4d"), _m_usDay, _m_usMonth, _m_usYear);
}
//---------------------------------------------------------------------------
//TODO: + sGetDateTimeStr (форматирование даты, времени)
tString
CxDateTime::sGetDateTimeStr() const {
	/*DEBUG*/// n/a

	return CxString::sFormat(
	            xT("%.2d.%.2d.%.4d %d:%.2d:%.2d:%.3d"),
	            _m_usDay,  _m_usMonth,  _m_usYear, _m_usHour, _m_usMinute, _m_usSecond, _m_usMSec);
}
//---------------------------------------------------------------------------
//TODO: - sGetDateStrLong (форматирование времени)
////tString
////CxDateTime::sGetDateStrLong() {
////	/*DEBUG*/// n/a
////
////	return xT("n/i");
////}
//--------------------------------------------------------------------------
//TODO: - sGetDateTimeStrLong (форматирование даты, времени)
////tString
////CxDateTime::sGetDateTimeStrLong() {
////	/*DEBUG*/// n/a
////
////	return xT("n/i");
////}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: static	
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: - bIsValid
/*static*/
BOOL
CxDateTime::bIsValid(USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMSec) {
	/*DEBUG*/

	bool bCond1 = (usYear   >= 0 && usYear   <= 9999);
	bool bCond2 = (usMonth  >= 0/*1*/ && usMonth  <= 12);
	bool bCond3 = (usDay    >= 0/*1*/ && usDay    <= usDaysInMonth(usYear, usMonth));
	bool bCond4 = (usHour   >= 0 && usHour   <= 23);
	bool bCond5 = (usMinute >= 0 && usMinute <= 59);
	bool bCond6 = (usSecond >= 0 && usSecond <= 59);
	bool bCond7 = (usMSec   >= 0 && usMSec   <= 999);

	bool bRes = bCond1 && bCond2 && bCond3 && bCond4 && bCond5 && bCond6 && bCond7;

	return static_cast<BOOL>(bRes);
}
//---------------------------------------------------------------------------
//TODO: + dtGetCurrent (текущяя дата, время)
/*static*/
CxDateTime
CxDateTime::dtGetCurrent() {
	/*DEBUG*/

#if defined(xOS_WIN)
    SYSTEMTIME stDateTime = {0};

    ::GetLocalTime(&stDateTime);
    /*DEBUG*/// n/a

    return CxDateTime(stDateTime.wYear, stDateTime.wMonth, stDateTime.wDay, stDateTime.wHour, stDateTime.wMinute, stDateTime.wSecond, stDateTime.wMilliseconds);
#elif defined(xOS_LINUX)
    //get datetime
    std::tm *ptmDateTime = {0};
    time_t   tmSec       = {0};

    time(&tmSec);
    ptmDateTime = localtime(&tmSec);

    //get msec
    timeval tvTime = {0};
    INT iRes = gettimeofday(&tvTime, NULL);
    /*DEBUG*/xASSERT_RET(- 1 != iRes, CxDateTime());

    //set datetime
    USHORT usYear   = ptmDateTime->tm_year + 1900;
    USHORT usMonth  = ptmDateTime->tm_mon  + 1;
    USHORT usDay    = ptmDateTime->tm_mday;
    USHORT usHour   = ptmDateTime->tm_hour;
    USHORT usMinute = ptmDateTime->tm_min;
    USHORT usSecond = ptmDateTime->tm_sec;
    USHORT usMSec   = tvTime.tv_usec / 1000;

    return CxDateTime(usYear, usMonth, usDay, usHour, usMinute, usSecond, usMSec);
#endif
}
//--------------------------------------------------------------------------
//TODO: + bMSecToSystemTime (миллисекунды в CxDateTime)
/*static*/
////BOOL
////CxDateTime::bMSecToSystemTime(ULONGLONG ui64MSec, SYSTEMTIME *stST) {
////	/*DEBUG*/
////
////	stST->wYear         = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60 * 24 * 30) * 12));
////	ui64MSec           %= ((1000ULL * 60 * 60 * 24 * 30) * 12);
////
////	stST->wMonth        = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60 * 24) * 30));
////	ui64MSec           %= ((1000ULL * 60 * 60 * 24) * 30);
////
////	stST->wDay          = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60) * 24));
////	ui64MSec           %= ((1000ULL * 60 * 60) * 24);
////
////	stST->wHour         = static_cast<USHORT>(ui64MSec / ((1000ULL * 60) * 60));
////	ui64MSec           %= ((1000ULL * 60) * 60);
////
////	stST->wMinute 	    = static_cast<USHORT>(ui64MSec / ((1000ULL * 60)));
////	ui64MSec	       %= ((1000ULL * 60));
////
////	stST->wSecond	    = static_cast<USHORT>(ui64MSec / 1000ULL);
////	ui64MSec           %= 1000ULL;
////
////	stST->wMilliseconds = static_cast<USHORT>(ui64MSec);
////
////	return TRUE;
////}
//--------------------------------------------------------------------------
//TODO: + bMSecToSystemTime (миллисекунды в CxDateTime)
/*static*/
BOOL
CxDateTime::bMSecToSystemTime(ULONGLONG ui64MSec) {
	/*DEBUG*/

	_m_usYear    = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60 * 24 * 30) * 12));
	ui64MSec    %= ((1000ULL * 60 * 60 * 24 * 30) * 12);

	_m_usMonth   = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60 * 24) * 30));
	ui64MSec    %= ((1000ULL * 60 * 60 * 24) * 30);

	_m_usDay     = static_cast<USHORT>(ui64MSec / ((1000ULL * 60 * 60) * 24));
	ui64MSec    %= ((1000ULL * 60 * 60) * 24);

	_m_usHour    = static_cast<USHORT>(ui64MSec / ((1000ULL * 60) * 60));
	ui64MSec    %= ((1000ULL * 60) * 60);

	_m_usMinute  = static_cast<USHORT>(ui64MSec / ((1000ULL * 60)));
	ui64MSec	%= ((1000ULL * 60));

	_m_usSecond  = static_cast<USHORT>(ui64MSec / 1000ULL);
	ui64MSec    %= 1000ULL;

	_m_usMSec    = static_cast<USHORT>(ui64MSec);

	return TRUE;
}
//////////--------------------------------------------------------------------------
//////////TODO: + ui64SystemTimeToMSec ()
/////////*static*/
////////ULONGLONG
////////CxDateTime::ui64SystemTimeToMSec(const SYSTEMTIME &stST) {
////////	/*DEBUG*/
////////
////////	ULONGLONG ui64Res = 0ULL;
////////
////////	ui64Res += stST.wYear         * 1000ULL * 60 * 60 * 24 * 30 * 12;
////////	ui64Res += stST.wMonth        * 1000ULL * 60 * 60 * 24 * 30;
////////	ui64Res += stST.wDay          * 1000ULL * 60 * 60 * 24;
////////	ui64Res += stST.wHour         * 1000ULL * 60 * 60; 
////////	ui64Res += stST.wMinute       * 1000ULL * 60;
////////	ui64Res += stST.wSecond       * 1000ULL * 1;
////////	ui64Res += stST.wMilliseconds * 1;
////////
////////	return ui64Res;
////////}
//--------------------------------------------------------------------------
//TODO: + ui64SystemTimeToMSec ()
/*static*/
ULONGLONG
CxDateTime::ui64SystemTimeToMSec() {
	/*DEBUG*/

	ULONGLONG ui64Res = 0ULL;

	ui64Res += _m_usYear   * 1000ULL * 60 * 60 * 24 * 30 * 12;
	ui64Res += _m_usMonth  * 1000ULL * 60 * 60 * 24 * 30;
	ui64Res += _m_usDay    * 1000ULL * 60 * 60 * 24;
	ui64Res += _m_usHour   * 1000ULL * 60 * 60;
	ui64Res += _m_usMinute * 1000ULL * 60;
	ui64Res += _m_usSecond * 1000ULL * 1;
	ui64Res += _m_usMSec   * 1;

	return ui64Res;
}
//---------------------------------------------------------------------------
//TODO: + sMSecToTimeString ()
/*static*/
//////////tString
//////////CxDateTime::sMSecToTimeString(ULONGLONG ui64MSec) {
//////////	tString sRes;
//////////		
//////////	const ULONGLONG cui64H  = ui64MSec / 3600000;
//////////	const ULONGLONG cui64M  = ui64MSec % 3600000 / 60000;
//////////	const ULONGLONG cui64S  = ui64MSec % 60000   / 1000;
//////////	const ULONGLONG cui64Ms = ui64MSec % 1000;
//////////
//////////	sRes = CxString::sFormat(xT("%I64d:%.2I64d:%.2I64d:%.3I64d"), cui64H, cui64M, cui64S, cui64Ms);
//////////
//////////	return sRes;
//////////}
//---------------------------------------------------------------------------
//TODO: + i64FiletimeToInt64 ()
#if defined(xOS_WIN)
/*static*/
LONGLONG
CxDateTime::i64FiletimeToInt64(FILETIME ftTime) {
    return Int64ShllMod32(ftTime.dwHighDateTime, 32) | ftTime.dwLowDateTime;
}
#endif
//--------------------------------------------------------------------------
//TODO: usDaysInMonth
/*static*/
USHORT CxDateTime::usDaysInMonth(USHORT usYear, USHORT usMonth) {
	/*DEBUG*/

	static USHORT arusDaysOfMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	if (2 == usMonth && bIsLeapYear(usYear)) {
		return 29;
	} else {
		return arusDaysOfMonth[usMonth];
	}
}
//--------------------------------------------------------------------------
//TODO: bIsLeapYear
/*static*/
BOOL
CxDateTime::bIsLeapYear(USHORT usYear) {
	/*DEBUG*/

	return static_cast<BOOL>( 0 == (usYear % 4) && ( 0 != (usYear % 100) || 0 == (usYear % 400)) );
}
//--------------------------------------------------------------------------


/****************************************************************************
*	public: other
*
*****************************************************************************/

//--------------------------------------------------------------------------- 
//TODO: + sGetZodiacSign (sign of the zodiac by date)
/*
NOTE: sign of the zodiac

        -----------------------------------------------------
        |  Знак	    |  Символ  |  Западная астрология	    |
        -----------------------------------------------------
        |  Овеен	|  U+2648  |  21 марта    — 20 апреля   |
        |  Телец	|  U+2649  |  21 апреля   — 21 мая      |
        |  Близнецы |  U+264A  |  22 мая      — 21 июня     |
        |  Рак	    |  U+264B  |  22 июня     — 23 июля     |
        |  Лев	    |  U+264С  |  24 июля     — 23 августа  |
        |  Дева	    |  U+264D  |  24 августа  — 23 сентября |
        |  Весы	    |  U+264E  |  24 сентября — 23 октября  |
        |  Скорпион |  U+264F  |  24 октября  — 22 ноября   |
        |  Стрелец  |  U+2650  |  23 ноября   — 21 декабря  |
        |  Козерог  |  U+2651  |  22 декабря  — 20 января   |
        |  Водолей  |  U+2652  |  21 января   — 19 февраля  |
        |  Рыбы	    |  U+2653  |  20 февраля  — 20 марта    |
        -----------------------------------------------------
*/

/*static*/
tString
CxDateTime::sGetZodiacSign(USHORT usMonth, USHORT usDay) {
	/*DEBUG*/// usDay
	/*DEBUG*/// usMonth

	//Овен	    |  U+2648  |  21 марта    — 20 апреля
	xCHECK_RET(usMonth == 3 && usDay >= 21,  xT("Овен"));
	xCHECK_RET(usMonth == 4 && usDay <= 20,  xT("Овен"));

	//Телец	|  U+2649  |  21 апреля   — 21 мая 	
	xCHECK_RET(usMonth == 4 && usDay >= 21,  xT("Телец"));
	xCHECK_RET(usMonth == 5 && usDay <= 21,  xT("Телец"));

	//Близнецы |  U+264A  |  22 мая      — 21 июня     
	xCHECK_RET(usMonth == 5 && usDay >= 22,  xT("Близнецы"));
	xCHECK_RET(usMonth == 6 && usDay <= 21,  xT("Близнецы"));

	//Рак	    |  U+264B  |  22 июня     — 23 июля     
	xCHECK_RET(usMonth == 6 && usDay >= 22,  xT("Рак"));
	xCHECK_RET(usMonth == 7 && usDay <= 23,  xT("Рак"));

	//Лев	    |  U+264С  |  24 июля     — 23 августа  
	xCHECK_RET(usMonth == 7 && usDay >= 24,  xT("Лев"));
	xCHECK_RET(usMonth == 8 && usDay <= 23,  xT("Лев"));

	//Дева	    |  U+264D  |  24 августа  — 23 сентября 
	xCHECK_RET(usMonth == 8 && usDay >= 24,  xT("Дева"));
	xCHECK_RET(usMonth == 9 && usDay <= 23,  xT("Дева"));

	//Весы	    |  U+264E  |  24 сентября — 23 октября  
	xCHECK_RET(usMonth == 9 && usDay >= 24,  xT("Весы"));
	xCHECK_RET(usMonth == 10 && usDay <= 23, xT("Весы"));

	//Скорпион |  U+264F  |  24 октября  — 22 ноября   
	xCHECK_RET(usMonth == 10 && usDay >= 24, xT("Скорпион"));
	xCHECK_RET(usMonth == 11 && usDay <= 22, xT("Скорпион"));

	//Стрелец  |  U+2650  |  23 ноября   — 21 декабря  
	xCHECK_RET(usMonth == 11 && usDay >= 23, xT("Стрелец"));
	xCHECK_RET(usMonth == 12 && usDay <= 21, xT("Стрелец"));
	//Козерог  |  U+2651  |  22 декабря  — 20 января   
	xCHECK_RET(usMonth == 12 && usDay >= 22, xT("Козерог"));
	xCHECK_RET(usMonth == 1 && usDay <= 20,  xT("Козерог"));

	//Водолей  |  U+2652  |  21 января   — 19 февраля  
	xCHECK_RET(usMonth == 1 && usDay >= 21,  xT("Водолей"));
	xCHECK_RET(usMonth == 2 && usDay <= 19,  xT("Водолей"));

	//Рыбы	    |  U+2653  |  20 февраля  — 20 марта    
	xCHECK_RET(usMonth == 2 && usDay >= 20,  xT("Рыбы"));
	xCHECK_RET(usMonth == 3 && usDay <= 20,  xT("Рыбы"));

	/*DEBUG*/xASSERT(FALSE);

	return tString();
}
//---------------------------------------------------------------------------
//TODO: - sGetMonthStr ()
/*static*/ 
tString
CxDateTime::sGetMonthStr(USHORT usMonth, BOOL bIsShortName) {
	/*DEBUG*/// usMonth       - n/a
	/*DEBUG*/// bIsShortName - n/a

	xCHECK_DO(12 < usMonth, usMonth = 12);
	xCHECK_DO(1 > usMonth,  usMonth = 1);
	
	tString sMonths[12][2] = {
		{ xT("January"),	xT("Jan") },
		{ xT("February"),	xT("Feb") },
		{ xT("March"),		xT("Mar") },
		{ xT("April"),		xT("Apr") },
		{ xT("May"),		xT("May") },
		{ xT("June"),		xT("Jun") },
		{ xT("July"),		xT("Jul") },
		{ xT("August"),		xT("Aug") },
		{ xT("September"),	xT("Sep") },
		{ xT("October"),	xT("Oct") },
		{ xT("November"),	xT("Nov") },
		{ xT("December"),	xT("Dec") }
	};

	return (FALSE == bIsShortName) ? sMonths[usMonth - 1][0] : sMonths[usMonth - 1][1];
}
//---------------------------------------------------------------------------
//TODO: - sGetWeekDayStr ()
/*static*/ 
tString
CxDateTime::sGetWeekDayStr(USHORT usDay, BOOL bIsShortName) {
	/*DEBUG*/// usDay       - n/a
	/*DEBUG*/// bIsShortName - n/a

	xCHECK_DO(7 < usDay, usDay = 7);
	xCHECK_DO(1 > usDay, usDay = 1);

	tString sDays[7][2] = {
		{ xT("Monday"),		xT("Mon") },
		{ xT("Tuesday"),	xT("Tue"} ),
		{ xT("Wednesday"),	xT("Wed") },
		{ xT("Thursday"),	xT("Thu") },
		{ xT("Friday"),		xT("Fri") },
		{ xT("Saturday"),	xT("Sat") },
		{ xT("Sunday"),		xT("Sun") }
	};

	return (FALSE == bIsShortName) ? sDays[usDay - 1][0] : sDays[usDay - 1][1];
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private	
*
*****************************************************************************/


/*
How to convert local system time to UTC or GMT.

May 28th

Posted by Jijo Raj in Codeproject 

2 comments


In Messengers did you notice that the time stamp will be expressed in UTC or GMT. UTC stands for Universal Coordinated Time and GMT stands for Greenwich Mean Time and both are same. Since the users engaged in chat can be from across world, this one is really helpful to understand the real time. If they are expressed in local time, it can result in confusion.

For instance, User1 says – “Login to chat by 13:00″. It can be his local time and 13:00 for user2 might be a different time according to his timezone. And think what will happen?  UTC or GMT is very much useful if you communicate about time across world. But how can you convert your local system time to UTC or GMT?


First you’ve to get your timezone information by calling – GetTimeZoneInformation(). Then get the local time by calling – GetSystemTime() and translate it to UMT or GMT by calling – TzSpecificLocalTimeToSystemTime(). See the sample code snippet below.
// Get the local system time.
SYSTEMTIME LocalTime = { 0 };
GetSystemTime( &LocalTime );

// Get the timezone info.
TIME_ZONE_INFORMATION TimeZoneInfo;
GetTimeZoneInformation( &TimeZoneInfo );

// Convert local time to UTC.
SYSTEMTIME GmtTime = { 0 };
TzSpecificLocalTimeToSystemTime( &TimeZoneInfo,
&LocalTime,
&GmtTime );

// GMT = LocalTime + TimeZoneInfo.Bias
// TimeZoneInfo.Bias is the difference between local time
// and GMT in minutes.

// Local time expressed in terms of GMT bias.
float TimeZoneDifference = -( float(TimeZoneInfo.Bias) / 60 );
CString csLocalTimeInGmt;
csLocalTimeInGmt.Format( _T("%ld:%ld:%ld + %2.1f Hrs"),
GmtTime.wHour,
GmtTime.wMinute,
GmtTime.wSecond,
TimeZoneDifference );


Use SystemTimeToTzSpecificLocalTime() to convert UTC or GMT time back to your local timezone. You can also use UTC or GMT while logging messages. Anyway it all depends upto your needs.
*/



//struct tm {
//int tm_year;    /* years since 1900 */
//int tm_mon;     /* months since January - [0,11] */
//int tm_wday;    /* days since Sunday - [0,6] */
//int tm_mday;    /* day of the month - [1,31] */
//int tm_hour;    /* hours since midnight - [0,23] */
//int tm_min;     /* minutes after the hour - [0,59] */
//int tm_sec;     /* seconds after the minute - [0,59] */
//int tm_yday;    /* days since January 1 - [0,365] */
//int tm_isdst;   /* daylight savings time flag */
//};



/*
CSimpleDate::operator LPCSTR()
{
	if(!IsValid())
		return (LPCSTR)0;
	switch(m_Format)
	{
	case MMDDYY:
		m_DateString.Format("%02d/%02d/%02d",m_Month,m_Day,m_Year > 99 ? m_Year-1900:m_Year);		
		return (LPCSTR)m_DateString;
	case DDMMYY:
		m_DateString.Format("%02d/%02d/%02d",m_Day,m_Month,m_Year > 99 ? m_Year-1900:m_Year);		
		return (LPCSTR)m_DateString;
	case YYMMDD:
		m_DateString.Format("%02d/%02d/%02d",m_Year > 99 ? m_Year-1900:m_Year,m_Month,m_Day);		
		return (LPCSTR)m_DateString;
	case MMDDYYYY:
		m_DateString.Format("%02d/%02d/%04d",m_Month,m_Day,m_Year );		
		return (LPCSTR)m_DateString;
	case DDMMYYYY:
		m_DateString.Format("%02d/%02d/%04d",m_Day,m_Month,m_Year);		
		return (LPCSTR)m_DateString;
	case YYYYMMDD:
		m_DateString.Format("%04d/%02d/%02d",m_Year ,m_Month,m_Day);		
		return (LPCSTR)m_DateString;
	default:
		return (LPCSTR)NULL;
	}
}

*/


 
