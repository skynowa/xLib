/****************************************************************************
* Class name:  CxDbLog
* Description: logging to DB
* File name:   CxDbLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:55:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Log/CxDbLog.h>

#include <xLib/Common/CxDateTime.h>
#include <xLib/Filesystem/CxPath.h>


/****************************************************************************
*    public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxDbLog ()
CxDbLog::CxDbLog() {

}
//---------------------------------------------------------------------------
//TODO: + CxDbLog ()
CxDbLog::~CxDbLog() {

}
//---------------------------------------------------------------------------
