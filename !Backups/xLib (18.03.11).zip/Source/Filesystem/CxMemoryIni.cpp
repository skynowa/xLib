/****************************************************************************
* Class name:  CxMemoryIni
* Description: �������� �������� � ������
* File name:   CxMemoryIni.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     27.07.2010 13:01:42
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Filesystem/CxMemoryIni.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CxMemoryIni (comment)
CxMemoryIni::CxMemoryIni() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - CxMemoryIni (comment)
CxMemoryIni::CxMemoryIni(const tString &csFilePath) {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CxMemoryIni (comment)
/*virtual*/
CxMemoryIni::~CxMemoryIni() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bFlush (comment)
BOOL CxMemoryIni::bFlush() {
	//code;

	return TRUE;
}
//---------------------------------------------------------------------------
