/****************************************************************************
* Class name:  CXDir
* Description: �������� � �������
* File name:   CXDir.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXDirH
#define XLib_Fso_CXDirH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXDir : public CXNonCopyable {
	public:
		static BOOL    bIsExists   (const tstring &csDirPath);
		static BOOL    bIsEmpty    (const tstring &csDirPath, const tstring &csMask); 
		static tstring sGetCurrent ();  
		static BOOL    bSetCurrent (const tstring &csDirPath); 
		static tstring sGetTempPath(); 
		static BOOL    bCreate     (const tstring &csDirPath); 
		static VOID    vForceCreate(const tstring &csDirPath); 
		static BOOL    bCopy       (const tstring &csDirPathFrom, const tstring &cscsDirPathTo, BOOL bFailIfExists); 
		static BOOL    bMove       (const tstring &csDirPathIn,   const tstring &csDirPathOut);  

		static BOOL    bDelete     (const tstring &csDirPath); 
		static BOOL    bForceClear (const tstring &csDirPath); 
		static BOOL    bForceDelete(const tstring &csDirPath); 
		static BOOL    bListFiles  (const tstring &csDirPath, const tstring &csMask, std::vector<tstring> *pvecsFiles); 
		static BOOL    bListDirs   (const tstring &csDirPath, std::vector<tstring> *pvecsDirs);

	private:
			           CXDir       ();
					  ~CXDir       ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXDirH
