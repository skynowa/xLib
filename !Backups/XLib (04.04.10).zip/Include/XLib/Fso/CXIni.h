/****************************************************************************
* Class name:  CXIni
* Description: ������ � ini-�������
* File name:   CXIni.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.04.2009 12:10:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXIniH
#define XLib_Fso_CXIniH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXIni : public CXNonCopyable {
	public:
						 CXIni                     (const tstring &csFileName, const tstring &csDefaultContent);
						~CXIni                     ();

		BOOL             bCreateDefaultIni         (const tstring &csFilePath, const tstring &csContent);

		tstring			 sReadString               (const tstring &csSection, const tstring &csKey, const tstring &csDefaultValue);
		BOOL             bWriteString              (const tstring &csSection, const tstring &csKey, const tstring &csValue);

		INT              iReadInteger              (const tstring &csSection, const tstring &csKey, INT    iDefaultValue);
		BOOL             bWriteInteger             (const tstring &csSection, const tstring &csKey, INT    iValue);

		DOUBLE           dReadFloat                (const tstring &csSection, const tstring &csKey, DOUBLE dDefaultValue);
		BOOL             bWriteFloat               (const tstring &csSection, const tstring &csKey, FLOAT  fValue);

		BOOL             bReadBoolean              (const tstring &csSection, const tstring &csKey, BOOL   bDefaultValue);
		BOOL             bWriteBoolean             (const tstring &csSection, const tstring &csKey, BOOL   bValue);

	

		//	DAte
		//	Float
		//	Time

		BOOL             bClearSection             (const tstring &csSection);
		BOOL             bReadSectionsNames        ();
		BOOL             bReadSectionKeysAndValues (const tstring &csSection);
		ULONG            ulSectionSize             (const tstring &csSection);
		

	private:
		static const INT _ms_ciLineSize        = 512;
		static const INT _ms_ciLinesPerSection = 50;	//����������� �������� � ������
		tstring          _m_sFilePath;
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXIniH