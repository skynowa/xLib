/****************************************************************************
* Class name:  CXEnvironment
* Description: ���������� ���������
* File name:   CXEnvironment.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.04.2010 17:43:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXEnvironmentH
#define XLib_Fso_CXEnvironmentH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXEnvironment : public CXNonCopyable {
	public:
	   	static tstring sGetVar		 (const tstring &csVar);
		static BOOL    bSetVar		 (const tstring &csVar, const tstring &csValue);
		static BOOL    bGetStrings   (std::vector<tstring> *pvecsEnvStrings);
		static tstring sExpandStrings(const tstring &csvVar);

	private:
		CXEnvironment();
	   ~CXEnvironment();
};
//---------------------------------------------------------------------------
#endif //XLib_Fso_CXEnvironmentH



