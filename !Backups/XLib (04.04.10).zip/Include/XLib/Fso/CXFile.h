/****************************************************************************
* Class name:  CXFile
* Description: �������� � ������, �������
* File name:   CXFile.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     03.06.2009 16:30:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXFileH
#define XLib_Fso_CXFileH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXFile : public CXNonCopyable {
    public:
		//�������� ������
		enum EAttributes {
			faInvalid           = INVALID_FILE_ATTRIBUTES,
			faReadOnly          = FILE_ATTRIBUTE_READONLY,  
			faHidden            = FILE_ATTRIBUTE_HIDDEN,  
			faSystem            = FILE_ATTRIBUTE_SYSTEM,  
			faDirectory         = FILE_ATTRIBUTE_DIRECTORY,  
			faArchive           = FILE_ATTRIBUTE_ARCHIVE,  
			faDevice            = FILE_ATTRIBUTE_DEVICE,  
			faNormal            = FILE_ATTRIBUTE_NORMAL,  
			faTemporary         = FILE_ATTRIBUTE_TEMPORARY,  
			faSparseFile        = FILE_ATTRIBUTE_SPARSE_FILE,  
			faReparsePoint      = FILE_ATTRIBUTE_REPARSE_POINT,  
			faCompressed        = FILE_ATTRIBUTE_COMPRESSED,  
			faOffline           = FILE_ATTRIBUTE_OFFLINE,  
			faNotContentIndexed = FILE_ATTRIBUTE_NOT_CONTENT_INDEXED,  
			faEncrypted         = FILE_ATTRIBUTE_ENCRYPTED,  
			//faVirtual           = FILE_ATTRIBUTE_VIRTUAL /*BC ++*/
		};
	
		//generic rights.
		typedef enum {
			grAll     = GENERIC_ALL,				//Read, write, and execute access
			grExecute = GENERIC_EXECUTE,			//Execute access
			grRead    = GENERIC_READ,				//Read access
			grWrite   = GENERIC_WRITE				//Write access
		} EGenericRights;

		//share modes
		typedef enum {
			smDenyAll = 0,							//Prevents other processes from opening a file or device if they request delete, read, or write access.
			smDelete  = FILE_SHARE_DELETE,			//Enables subsequent open operations on a file or device to request delete access. 
			smRead    = FILE_SHARE_READ,			//Enables subsequent open operations on a file or device to request read access. 
			smWrite   = FILE_SHARE_WRITE			//Enables subsequent open operations on a file or device to request write access. 
		} EShareMode;
	
		//Creation flags
		typedef enum {
			cfCreateAlways  = CREATE_ALWAYS,		//Creates a new file, always.
			cfCreateNew     = CREATE_NEW,			//Creates a new file, only if it does not already exist.
			cfOpenAlways    = OPEN_ALWAYS,			//Opens a file, always.
			cfOpenExisting  = OPEN_EXISTING,		//Opens a file or device, only if it exists.
			cfTruncExisting = TRUNCATE_EXISTING,	//Opens a file and truncates it so that its size is zero bytes, only if it exists.
		} ECreationFlags;

		//file position data for the given stream
		typedef enum {
			ppBegin = FILE_BEGIN,	
			ppCurr  = FILE_CURRENT,	
			ppEnd   = FILE_END,
		} EPointerPosition;

		//file types
		typedef enum {
			ftChar    = FILE_TYPE_CHAR,				//character file, typically an LPT device or a console.
			ftDisk    = FILE_TYPE_DISK,    		 	//disk file.
			ftPipe    = FILE_TYPE_PIPE,     		//socket, a named pipe, or an anonymous pipe.
			ftRemote  = FILE_TYPE_REMOTE,   		//Unused.
			ftUnknown = FILE_TYPE_UNKNOWN			//unknown, or the function failed.
		} EType;

					     CXFile              ();
				        ~CXFile              ();

		BOOL             bOpen               (const tstring &csFilePath, ULONG ulAccess = grRead,  ULONG ulShareMode = smRead,    ULONG ulFlags = cfOpenExisting, ULONG ulAttributes = faNormal);
		BOOL             bCreate             (const tstring &csFilePath, ULONG ulAccess = grWrite, ULONG ulShareMode = smDenyAll, ULONG ulFlags = cfCreateAlways, ULONG ulAttributes = faNormal);
		BOOL             bClose              ();
		BOOL             bIsOpen             ();
		BOOL             bAttach             (HANDLE hHandle);
		HANDLE           bDetach             ();
		BOOL             bRead               (LPVOID pvBuf, ULONG ulCount);
		BOOL             bRead               (LPVOID pvBuf, ULONG ulCount, LPDWORD pulRead);
		BOOL             bWrite              (LPCVOID pcvBuf, ULONG ulCount);
		BOOL             bWrite              (LPCVOID pcvBuf, ULONG ulCount, LPDWORD pulWritten);
		ULONG            ulSetPosition       (LONG liOff, EPointerPosition fpPos);
		ULONG            ulGetPosition       ();
		BOOL             bLock               (ULONG ulOffset, ULONG ulSize);
		BOOL             bUnlock             (ULONG ulOffset, ULONG ulSize);
		BOOL             bSetEOF             ();
		BOOL             bFlush              ();
		ULONG            ulGetSize           ();
		ULONG            ulGetType           ();
		BOOL             bGetTime            (FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified);
		BOOL             bSetTime            (FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified);
		BOOL             bDuplicateHandle    (HANDLE hOther);
		
		static BOOL      bIsExists           (const tstring &csFilePath);  
		static BOOL      bDelete             (const tstring &csFilePath); 
		static BOOL      bMove               (const tstring &csFilePathIn, const tstring &csFilePathOut); //����, ������� 
		static tstring   sCreateTempName     (const tstring &csPrefix); 
		static BOOL      bCopy               (const tstring &csFilePathFrom, const tstring &csFilePathTo);
		static BOOL      bCopy               (const tstring &csFilePathFrom, const tstring &csFilePathTo, BOOL bFailIfExists); 
		static BOOL      bReplace            (const tstring &csOldFileName, const tstring &csNewFilePath, const tstring &csBackupFilePath);
		static BOOL      bSecureDelete       (const tstring &csFilePath, UINT uiPasses); /*-*/
		static BOOL      bCutFromEnd         (const tstring &csFilePath, LONG lDistanceToCut);	
		static BOOL      bCutFromEnd         (FILE *pFile, ULONG ulDistanceToCut);	
		static BOOL      bCheckSignature     (LPCTSTR pcszBuff, LPCTSTR pcszSignature, INT iSignatureSize);
		static BOOL      bSetRandomDate      (const tstring &csFilePath);
		static ULONGLONG ullGetCompressedSize(const tstring &csFilePath);


		/****************************************************************************
		* ��������
		*
		*****************************************************************************/
		static ULONG     ulGetAttr           (const tstring &csFilePath);
		static BOOL      bSetAttr            (const tstring &csFilePath, ULONG ulFileAttr); 
		static BOOL	     bSetUncompressedAttr(const tstring &csFilePath); 
		static BOOL	     bSetCompressedAttr  (const tstring &csFilePath, BOOL bCompress); 


		static tstring	 sReadText   		 (const tstring &csFilePath);
		static bool		 bWriteText  		 (const tstring &csFilePath, const tstring &csText); 
		
		
		//other
		static BOOL      bBackup             (const tstring &csFilePath, const tstring &csDestDirPath);
		static BOOL      bCreateShortcut     (const tstring &csFilePath, const tstring &csShortCutPath, const tstring &csDescription);
		static BOOL      bExec               (const tstring &csFilePath, const tstring &csParams);  




	private:
		HANDLE           _m_hFile;
		BOOL             _m_bRes;
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXFileH



/*
BOOL CXLog::bOpen() {
	STARTUPINFO         si = {0};
	PROCESS_INFORMATION pi = {0};
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	tstring sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.2\\notepad++.exe " + m_sLogPath; 
	if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
	    return FALSE;
	}	

	::Sleep(500);  //������� �������� � �������� ���� ������

	//������� ����������� ����������� �������� � ������� ��������
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);

	return TRUE;
}

*/
