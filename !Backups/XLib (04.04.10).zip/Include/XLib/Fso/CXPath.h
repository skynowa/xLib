/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXPathH
#define XLib_Fso_CXPathH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXPath : public CXNonCopyable {
	public:	
		static tstring sGetExe      ();
		static tstring sGetExeDir   ();
		static tstring sGetDrive    (const tstring &csFilePath);
		static tstring sGetDir      (const tstring &csFilePath);
		static tstring sGetFullName (const tstring &csFilePath);
		static tstring sGetName     (const tstring &csFilePath);
		static tstring sGetExt      (const tstring &csFilePath);

		static tstring sSetDrive    (const tstring &csFilePath, const tstring &csDrivePath); 
		static tstring sSetDir      (const tstring &csFilePath, const tstring &csDirPath); 
		static tstring sSetFullName (const tstring &csFilePath, const tstring &csFullName);
		static tstring sSetName     (const tstring &csFilePath, const tstring &csName); 
		static tstring sSetExt      (const tstring &csFilePath, const tstring &csExt);

		static tstring sRemoveExt   (const tstring &csFilePath);
		static tstring sRemoveExtIf (const tstring &csFilePath, const tstring &csExt);

		//normalize
		static tstring sToWin       (const tstring &csFilePath, BOOL bIsSlashAtEnd);
		static tstring sToNix       (const tstring &csFilePath, BOOL bIsSlashAtEnd);

		static tstring sMinimizeName(const tstring &csFileName, const std::size_t cuiMaxSize);
		static tstring sMinimize    (const tstring &csFilePath, const std::size_t cuiMaxSize);
		static tstring sSetValidName(const tstring &csFileName);

		static tstring sAppendSlash (const tstring &csDirPath);
		static tstring sRemoveSlash (const tstring &csDirPath);

	private:	   
					   CXPath       ();
					  ~CXPath       ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXPathH

//static tstring sGetRelativePath     (const tstring &csFilePath); /*-*/
//
/*
//---------------------------------------------------------------------------
//TODO:   convert path separators to forward slashes
void convert_path_separators(tstring &s) {
	for (tstring::iterator itr = s.begin(); itr != s.end(); ++ itr) {
		if (*itr == _T('\\') || *itr == _T('!')) {
			*itr = _T('/');
		}
	}
}
//---------------------------------------------------------------------------
*/
/*ExpandUNCFileName	���������� ������ ��� ����� �� ������� �����.*/
/*ExtractShortPathName	������������ ������� ��� ����� � ������ DOS.*/
/*ProcessPath	��������� �� ������� ����� ����� ��� �����, ��� �������� � ��� �����.*/
