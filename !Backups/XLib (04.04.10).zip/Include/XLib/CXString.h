/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (tstring, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef XLib_CXStringH
#define XLib_CXStringH  
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXString : public CXNonCopyable {
	public: 
			/****************************************************************************
			*    ������ <--> �����
			*
			*****************************************************************************/

			template <typename T> 
			static tstring                       lexical_cast     (T const &cValueT) {		
																		tostringstream ossStream;	
																		ossStream.exceptions(/*tostringstream::eofbit |*/ tostringstream::failbit | tostringstream::badbit);

																		try {
																			ossStream << cValueT;
																		} catch (tostringstream::failure e) {
																			/*DEBUG*/xASSERT_RET(FALSE, tstring());
																		}

																		return ossStream.str();
															      };		
			template<typename T> 
			static T                             lexical_cast     (const tstring &csStr) {
																		tistringstream issStream(csStr);
																		issStream.exceptions(/*tostringstream::eofbit |*/ tostringstream::failbit | tostringstream::badbit);

																		T ValueT;
																		try {
																			issStream >> ValueT;
																		} catch (tostringstream::failure e) {
																			/*DEBUG*/xASSERT_RET(FALSE, T());
																		}

																		return ValueT;
															      };

			static BOOL                          bBoolToStr       (bool bBool, tstring *psStr);
			static BOOL                          bStrToBool       (const tstring &csStr, bool *pbBool);

			static BOOL                          bStrToUChar      (const tstring &csStr, UCHAR *pucBuff, UINT uiBuffLen);	
			static tstring                       sUCharToStr      (UCHAR *pucBuff, UINT uiBuffLen);

			static tstring                       sTrimLeftChars   (const tstring &csStr, const tstring &csChars); 
			static tstring                       sTrimRightChars  (const tstring &csStr, const tstring &csChars); 
			static tstring                       sTrimChars       (const tstring &csStr, const tstring &csChars);
			static tstring                       sTrimSpace       (const tstring &csStr);	
			static tstring                       sRemoveEOL       (const tstring &csStr);	

			static tstring                       sReplaceAll      (const tstring &csStr, const tstring &csOldStr, const tstring &csNewStr); 
			static tstring                       sReplaceAll      (const tstring &csStr, TCHAR cOldStr, TCHAR cNewStr); 
			static tstring                       sRemoveAll       (const tstring &csStr, const tstring &csRemoveStr); 

			static BOOL                          bSplit           (const tstring &csStr, const tstring &csSep, std::vector<tstring> *vecsOut); 

			static std::vector<tstring>          vecsSplitKeyValue(const tstring &csStr, const tstring &csSep); 
			static tstring                       sJoin            (const std::vector<tstring> &cvecsVec, const tstring &csSep); 
			static tstring                       sCut             (const tstring &csStr, const tstring &csFirstLeftDelimiter, const tstring &csFirstRightDelimiter); /*-*/
			static tstring                       sCut             (const tstring &csStr, size_t uiStartPos = 0, size_t uiEndPos = std::string::npos); 

			static BOOL                          bStrToFile       (const tstring &csStr, const tstring &csFilePath);	/*-*/
			static tstring                       bStrFromFile     (const tstring &csStr, const tstring &csFilePath);	/*-*/

			static tstring						 sToLowerCase     (const tstring &csStr);	
			static tstring                       sToUpperCase     (const tstring &csStr);	
			static tstring						 sToLowerCase     (const tstring &csStr, ULONG ulSize);	
			static tstring                       sToUpperCase     (const tstring &csStr, ULONG ulSize);	

			static tstring                       sFormatStr       (LPCTSTR pcszFormat, ...); 
			static std::string                   sFormatStrA      (LPCSTR  pcszFormat, ...); 
			static tstring                       sFormatStr2      (LPCTSTR pcszFormat, ...); 
			static tstring                       sFormatStrV      (LPCTSTR pcszFormat, va_list palArgs);
			static tstring                       sMinimizeStr     (const tstring &csStr, const UINT cuiMaxLen); 

			/****************************************************************************
			*    TCHAR
			*
			*****************************************************************************/

			//This is ASCII specific but is safe with chars >= 0x80
			static BOOL                              bIsPunctuation   (TCHAR ch); 
			static BOOL                              bIsADigit        (TCHAR ch); 
			static BOOL                              bIsLowerCase     (TCHAR ch); 
			static BOOL                              bIsUpperCase     (TCHAR ch); 
			static BOOL                              bIsSpaceOrTab    (UINT ch); 
			static BOOL                              bIsDigit         (UINT ch); 
			static BOOL                              bIsDigit         (UINT ch, UINT base); 
			static BOOL                              bIsLetter        (TCHAR ch); 
			static BOOL                              bIsSpace         (UINT ch); 
			static BOOL                              IsEOLChar        (TCHAR ch); 
			static BOOL								 bIsSlash         (TCHAR ch);  

			static INT                               iGetHexChar      (UCHAR hd1, UCHAR hd2);
			static TCHAR                             cHexToChar       (TCHAR *pszStr);
			static INT								 iCharCodeAt      (const tstring &csStr, INT nIndex);	
			static BOOL                              bCompareNoCase   (const tstring &csStr1, const tstring &csStr2); 
			static BOOL                              bCompareNoCase2  (const tstring &csStr1, const tstring &csStr2); 
			static INT                               iWildCompare     (LPCTSTR pcszStr, LPCTSTR pcszWild);



			/****************************************************************************
			* ����������
			*
			*****************************************************************************/

			//--------------------------------------------------------------------------
			//TODO: + vRandomShuffleT (������������ ������)
			template<class T> 
			static VOID vRandomShuffleT(std::vector<T> &v) {
				std::random_shuffle(v.begin(), v.end());
			}
			//--------------------------------------------------------------------------
			//TODO: + vSortVectorT (��������� ������)
			template<class T> 
			static VOID vSortVectorT(std::vector<T> &v) {
				std::sort(v.begin(), v.end());
			}
			//--------------------------------------------------------------------------


			/****************************************************************************
			*	�������������
			*
			*****************************************************************************/

			static tstring						  sTranslitLatToRus(const tstring &csStr);	
			static tstring						  sStrToRtf        (tstring sStr);
			static tstring						  sRtfToStr        (tstring sStr);
			static tstring                        sFormatBytes     (double dBytes);
			static tstring                        sFormatBytes     (ULONGLONG ullBytes);

			static std::wstring                   sStrToWStr       (const std::string  &csStr,  UINT uiCodePage);
			static std::string                    sWStrToStr       (const std::wstring &cwsStr, UINT uiCodePage);

			static std::string                    sConvertCodePage (const std::string &csSource, UINT uiCodePageSource, UINT uiCodePageDest);



			/****************************************************************************
			*    ������
			*
			*****************************************************************************/

			static tstring                       sCreatePlainGUID ();  
			static BOOL                          bIsRepeatedStr   (const tstring &csStr); 
			static tstring                       sLastErrorStr    (ULONG ulLastError);	
			static ULONG                         ulCountDigits    (ULONG ulDigit);	

			//---------------------------------------------------------------------------
			//TODO: + vPrintStdVectorT (������ � ������� std::vector) 
			template<class T>
			static VOID vPrintStdVectorT(const std::vector<T> &t) {
				std::cout << std::endl << _T("Printing std::vector contents...") << std::endl << std::endl;

				std::vector<T>::const_iterator it;
				
				for (it = t.begin(); it != t.end(); ++ it){
					tcout << _T("Value: [") << (*it) << _T("]") << std::endl;
				}
				
				tcout << std::endl << std::endl;
			}
			//---------------------------------------------------------------------------
			//TODO: + vPrintStdMultiMapT (������ � ������� std::multimap) 
			template<class T1, class T2>
			static VOID vPrintStdMultiMapT(const std::multimap<T1, T2> &t) { 
				tcout << std::endl << _T("Printing std::multimap contents...") << std::endl << std::endl;
				
				std::multimap<T1, T2>::const_iterator it;
				
				for (it = t.begin(); it != t.end(); ++ it) {
					tcout << _T("Key: [") << (*it).first << _T("]") << _T("\t\t") 
						  << _T("Value: [") << (*it).second << _T("]") << std::endl;
				}

				tcout << std::endl << std::endl;
			}
			//---------------------------------------------------------------------------
			// Some ATL string conversion enhancements
			// ATL's string conversions allocate memory on the stack, which can
			// be undesirable if converting huge strings.  These enhancements
			// provide for a pre-allocated memory block to be used as the 
			// destination for the string conversion.
			//#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
			//#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)

			//typedef std::wstring StringW;
			//typedef std::string  StringA;
			//
			//#ifdef _UNICODE
			//	typedef StringW String;
			//	#define _W2T(dst,src) lstrcpyW(dst,src)
			//	#define _T2W(dst,src) lstrcpyW(dst,src)
			//	#define _T2A(dst,src) _W2A(dst,src)
			//	#define _A2T(dst,src) _A2W(dst,src)
			//#else
			//	typedef StringA String;
			//	#define _W2T(dst,src) _W2A(dst,src)
			//	#define _T2W(dst,src) _A2W(dst,src)
			//	#define _T2A(dst,src) lstrcpyA(dst,src)
			//	#define _A2T(dst,src) lstrcpyA(dst,src)
			//#endif

	private:	   
		 CXString();
		~CXString();
};
//---------------------------------------------------------------------------
#endif	//XLib_CXStringH