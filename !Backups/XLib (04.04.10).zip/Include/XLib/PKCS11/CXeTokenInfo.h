/****************************************************************************
* Class name:  CXeTokenInfo
* Description: ���������� � eToken
* File name:   CXeTokenInfo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:53:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXeTokenInfoH
#define XLib_PKCS11_CXeTokenInfoH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
//---------------------------------------------------------------------------
class CXeTokenInfo : public CXNonCopyable {
	public:
		tstring sCkaSapiCardId;
		tstring sCkaSapiCardType;
		tstring sCkaSapiCardVersion;
		tstring sCkaSapiCaseModel;
		tstring sCkaSapiColor;
		tstring sCkaSapiFips;
		tstring sCkaSapiFipsSupported;
		tstring sCkaSapiFwRevision;
		tstring sCkaSapiFwVersion;
		tstring sCkaSapiHasBattery;
		tstring sCkaSapiHasLcd;
		tstring sCkaSapiHasSo;
		tstring sCkaSapiHasUser;
		tstring sCkaSapiHmacSha1;
		tstring sCkaSapiHmacSha1Supported;
		tstring sCkaSapiHwInternal;
		tstring sCkaSapiHwVersion;
		tstring sCkaSapiInitPinReq;
		tstring sCkaSapiMayInit;
		tstring sCkaSapiModel;
		tstring sCkaSapiProductionDate;
		tstring sCkaSapiProductName;
		tstring sCkaSapiRealColor;
		tstring sCkaSapiRsa2048;
		tstring sCkaSapiRsa2048Supported;
		tstring sCkaSapiSerial;
		tstring sCkaSapiTokenId;
		tstring sClockOnToken;
		tstring sDualCryptoOperations;
		tstring sFirmwareVersionMajor;
		tstring sFirmwareVersionMinor;
		tstring sFreePrivateMemory;
		tstring sFreePublicMemory;
		tstring sHardwareVersionMajor;
		tstring sHardwareVersionMinor;
		tstring sHasProtectedAuthenticationPath;
		tstring sIsWriteProtected;
		tstring sLabel;
		tstring sLoginRequired;
		tstring sManufacturerId;
		tstring sMaxPinLen;
		tstring sMaxRwSessionCount;
		tstring sMaxSessionCcount;
		tstring sMinPinLen;
		tstring sModel2;
		tstring sRandomNumberGenerator;
		tstring sRestoreKeyNotNeeded;
		tstring sRsaMechanismMaxKeySize;
		tstring sSerialNumber;
		tstring sSessionCount;
		tstring sTotalPrivateMemory;
		tstring sTotalPublicMemory;
		tstring sUsersPinIsSet;
		
		CXeTokenInfo(const CXPKCS11 &cPKCS11);
	   ~CXeTokenInfo();
			
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXeTokenInfoH
