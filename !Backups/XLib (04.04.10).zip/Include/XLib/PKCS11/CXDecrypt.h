/****************************************************************************
* Class name:  CXDecrypt
* Description: PKCS11 ������������
* File name:   CXDecrypt.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:11:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXDecryptH
#define XLib_PKCS11_CXDecryptH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXDecrypt : public CXNonCopyable {
	public:
		CXDecrypt(const CXPKCS11 &cPKCS11, const CXSession &cSession);
	   ~CXDecrypt();

		BOOL bInit	      (CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);/*C_DecryptInit*/		   
	   	BOOL bMake	      (CK_BYTE_PTR pEncryptedData, CK_ULONG ulEncryptedDataLen, CK_BYTE_PTR pData, CK_ULONG_PTR pulDataLen);/*C_Decrypt*/
		BOOL bUpdate	  (CK_BYTE_PTR pEncryptedPart, CK_ULONG ulEncryptedPartLen, CK_BYTE_PTR pPart, CK_ULONG_PTR pulPartLen);/*C_DecryptUpdate*/		
		BOOL bFinal	      (CK_BYTE_PTR pLastPart, CK_ULONG_PTR pulLastPartLen);/*C_DecryptFinal*/
		
		BOOL bDigestUpdate(CK_BYTE_PTR pEncryptedPart, CK_ULONG ulEncryptedPartLen, CK_BYTE_PTR pPart, CK_ULONG_PTR pulPartLen );/*C_DecryptDigestUpdate*/		
		BOOL bVerifyUpdate(CK_BYTE_PTR pEncryptedPart, CK_ULONG ulEncryptedPartLen, CK_BYTE_PTR pPart, CK_ULONG_PTR pulPartLen );/*C_DecryptVerifyUpdate*/	
   	
		//Utils
		BOOL bMakeFile    (const tstring &csInFilePath, const tstring &csOutFilePath, CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);
		
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXDecryptH