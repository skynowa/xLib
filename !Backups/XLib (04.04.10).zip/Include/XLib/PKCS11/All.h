/****************************************************************************
* Class name:  All
* Description: ��� ������������ �����
* File name:   All.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:56:53
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_AllH
#define XLib_PKCS11_AllH
//---------------------------------------------------------------------------
#include <XLib/PKCS11/Common.h>

#include <XLib/PKCS11/CXUtils.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXFunction.h>
#include <XLib/PKCS11/CXSlot.h>
#include <XLib/PKCS11/CXSession.h>
#include <XLib/PKCS11/CXLogin.h>
#include <XLib/PKCS11/CXInfo.h>
////#include <XLib/PKCS11/CXeTokenInfo.h>
#include <XLib/PKCS11/CXPin.h>
#include <XLib/PKCS11/CXMechanism.h>
#include <XLib/PKCS11/CXObject.h>
#include <XLib/PKCS11/CXKey.h>
#include <XLib/PKCS11/CXEncrypt.h>
#include <XLib/PKCS11/CXDecrypt.h>
#include <XLib/PKCS11/CXDigest.h>
#include <XLib/PKCS11/CXSign.h>
#include <XLib/PKCS11/CXVerify.h>
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_AllH