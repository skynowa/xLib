/****************************************************************************
* Class name:  CXSemaphoreEx
* Description: ������ � ����������
* File name:   CXSemaphoreEx.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXSemaphoreExH
#define XLib_Sync_CXSemaphoreExH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXHandleT.h>
#include <XLib/Sync/CXEvent.h>
#include <XLib/Sync/CXSleeper.h>
#include <XLib/Sync/CXMutex.h>
#include <XLib/Sync/CXMutexLocker.h>
//---------------------------------------------------------------------------
class CXSemaphoreEx : public CXNonCopyable {
	public:
			                  CXSemaphoreEx();
			                 ~CXSemaphoreEx();
					   
        HANDLE                hGetHandle   () const;
		BOOL                  bCreate      (PSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCTSTR pcszName);
		BOOL                  bRelease     (LONG liReleaseCount/* = 1*/, LONG *pliOldCount/* = NULL*/);
        BOOL				  bWait        (ULONG ulTimeout);

		LONG				  liGetValue   () const;
		BOOL				  bReset       (LONG liInitialCount, LONG liMaxCount);

	private:
		CXHandleT<NULL>       _m_hSemaphore; 
		LPSECURITY_ATTRIBUTES _m_lpsaAttributes;
		LPCTSTR               _m_pcszName;
		LONG                  _m_liInitialCount;
		LONG                  _m_liMaxCount;
		LONG                  _m_liCounter;
	
		CXSleeper             _m_slSleeper;
		CXEvent               _m_evtEvent;
		mutable CXMutex       _m_csCounter;					
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXSemaphoreExH


/*
Semaphores

wait():   n = n - 1; if n < 0  then sleep ()  (atomic until asleep)
signal(): n = n + 1; if n <= 0 then wakeup()  (all atomic)
*/



















