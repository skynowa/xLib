/****************************************************************************
* Class name:  CXMutex
* Description: ������ � ����������
* File name:   CXMutex.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:48:30
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXMutexH
#define XLib_Sync_CXMutexH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXHandleT.h>
//---------------------------------------------------------------------------
class CXMutex : public CXNonCopyable {
	public:
		       CXMutex   ();
			  ~CXMutex   ();
	    HANDLE hGetHandle() const;
		BOOL   bCreate   (LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialOwner, LPCTSTR pcszName);
		BOOL   bOpen     (ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName);
		BOOL   bRelease  () const;
		BOOL   bWait     (ULONG ulTimeout) const;

	private:
		CXHandleT<NULL>  _m_hMutex; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXMutexH