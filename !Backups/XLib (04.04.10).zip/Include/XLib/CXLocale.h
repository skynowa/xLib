/****************************************************************************
* Class name:  CXLocale
* Description: ������
* File name:   CXLocale.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.08.2009 19:47:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXLocaleH
#define XLib_Fso_CXLocaleH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXLocale : public CXNonCopyable {
	public:
		              CXLocale   ();
	                 ~CXLocale   ();
	   
	   static tstring sGetCurrent();
	   static BOOL    bSetCurrent(LPCTSTR pcszLocale);
	   static BOOL    bSetDefault();

	private:

};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXLocaleH