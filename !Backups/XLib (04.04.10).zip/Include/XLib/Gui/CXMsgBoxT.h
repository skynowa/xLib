/****************************************************************************
* Class name:  CXMsgBoxT
* Description: ����� ���������, ������ ���� ������
* File name:   CXMsgBoxT.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.04.2009 10:24:49
* Version:     1.0
*
*****************************************************************************/
 

#ifndef XLib_Gui_CXMsgBoxTH	
#define XLib_Gui_CXMsgBoxTH   
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
//TODO: + vMsgBox 
template <typename TextT, typename TitleT> 
VOID vMsgBox(TextT Text, TitleT Title, UINT uiType) {			
	::MessageBox(NULL, CXString::lexical_cast(Text).c_str(), CXString::lexical_cast(Title).c_str(), uiType);
}
//---------------------------------------------------------------------------
//TODO: + vMsgBox 
template <typename TextT, typename TitleT> 
VOID vMsgBox(TextT Text, TitleT Title) {			
	::MessageBox(NULL, CXString::lexical_cast(Text).c_str(), CXString::lexical_cast(Title).c_str(), MB_OK);
}
//---------------------------------------------------------------------------
//TODO: + vMsgBox 
template <typename TextT> 
VOID vMsgBox(TextT Text) {			
	::MessageBox(NULL, CXString::lexical_cast(Text).c_str(), _T(""), MB_OK);
}
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXMsgBoxTH