/****************************************************************************
* Class name:  CXRebar
* Description: ������ � �������
* File name:   CXRebar.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:20:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXRebarH
#define XLib_Gui_CXRebarH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXRebar : public CXWindow {
	public:
		enum AlignFlags	{
			AlignTop    = CCS_TOP,
			AlignBottom = CCS_BOTTOM,
			AlignLeft   = CCS_LEFT,
			AlignRight  = CCS_RIGHT,
		};

			 CXRebar ();
			~CXRebar();

		HWND Create(HWND hwndOwner,AlignFlags afFlag);
		VOID InsertBand(HWND hClientWnd,TCHAR* szName);
		BOOL DeleteBand(int numBand);
		VOID AutoSize();
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXRebarH