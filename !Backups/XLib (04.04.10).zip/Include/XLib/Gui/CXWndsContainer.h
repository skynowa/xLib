/****************************************************************************
* Class name:  CXWndsContainer
* Description: ��������� ��� ����
* File name:   CXWndsContainer.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     16.03.2010 15:42:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXWndsContainerH
#define XLib_Gui_CXWndsContainerH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Gui/CXWindow.h>
//---------------------------------------------------------------------------
class CXWndsContainer : public CXNonCopyable {
	public:
			      CXWndsContainer();
			     ~CXWndsContainer();

		BOOL      bAdd           (CXWindow *pwndCtrl);
		BOOL      bRemove        (CXWindow *pwndCtrl);
		CXWindow *pwndGet        (UINT uiIndex);
		UINT      uiGetSize      ();

	private:
		std::vector<CXWindow *>  _m_vecpWnds;
};
//---------------------------------------------------------------------------
#endif //XLib_Gui_CXWndsContainerH
