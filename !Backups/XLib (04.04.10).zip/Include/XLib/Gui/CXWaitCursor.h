/****************************************************************************
* Class name:  CXWaitCursor
* Description: wait cursor
* File name:   CXWaitCursor.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.06.2009 19:08:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXWaitCursorH
#define XLib_Gui_CXWaitCursorH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXWaitCursor : public CXNonCopyable {
	public:
		        CXWaitCursor();
	           ~CXWaitCursor();

		BOOL    bRestore    ();
		
	private:
		HCURSOR _m_hCursor;
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXWaitCursorH