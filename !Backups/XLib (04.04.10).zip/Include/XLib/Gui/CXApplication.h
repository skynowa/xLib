/****************************************************************************
* Class name:  CXApplication
* Description: ������ � �����������
* File name:   CXApplication.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:08:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


//---------------------------------------------------------------------------
#ifndef XLib_Gui_CXApplication_H
#define XLib_Gui_CXApplication_H
//---------------------------------------------------------------------------
//--#include <XLib/GUI/CXWindow.h>
#include <XLib/Gui/Common.h>
//--#include <XLib/Gui/CXResources.h>
#include <vector>
//---------------------------------------------------------------------------
class CXApplication : public CXNonCopyable { 
	public:
	    static BOOL		 bInit           (HINSTANCE hInstance, const tstring &csCmdLine);
		static HINSTANCE hGetInstance    ();
		static BOOL      bGetCmdLine     (std::vector<std::wstring> *pvecwsCmdLine); 
		static VOID      vProcessMessages();
		static BOOL      bRun            ();
		static BOOL      bIsRunning      (const tstring &csInstanceName);
		static VOID      vTerminate      ();

		static VOID      vCreateWnd      ();

	private:
		static HINSTANCE _m_hInstance;

						 CXApplication   ();
						~CXApplication   ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXApplication_H