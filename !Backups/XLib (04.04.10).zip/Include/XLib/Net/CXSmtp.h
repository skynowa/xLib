/****************************************************************************
* Class name:  CXSmtp
* Description: Pop3 ������ (RFC 2821)
* File name:   CXSmtp.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXSmtpH 
#define CXSmtpH 
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <Xlib/Net/CXTcpClientSocket.h>
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <map>
//---------------------------------------------------------------------------
class CXSmtp : public CXNonCopyable { 
	public: 
                    	    CXSmtp     (); 
                    	   ~CXSmtp     (); 
                    	   
		BOOL                bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); 
		BOOL                bConnect   ();
		BOOL                bLogin     (); 
		BOOL                bNoop      ();
		BOOL                bRset      ();
		BOOL                bSendRaw   (const std::string &csFilePath, const std::string &csFrom, const std::string &csTo); 
		BOOL                bSend      (const std::string &csText, const std::string &sFrom, const std::string &sTo);
		BOOL                bDisconnect(); 

	private: 
		CXTcpClientSocket   _m_scktSocket; 
		CXConsoleLog        _m_ConsoleLog;
		std::string         _m_sUser; 
		std::string         _m_sPass; 
		std::string         _m_sServer; 
		USHORT              _m_usPort; 
		BOOL                _m_bConnected;

		BOOL                _bCommand   (const std::string &csCmd, const std::string &csReplyDelimiter, std::string &sReply); /*+*/  
		BOOL                _bIsError   (const std::string &csText); 
}; 
//---------------------------------------------------------------------------
#endif 

/*
RFC 821 

HELO <SP> <domain> <CRLF>
MAIL <SP> FROM:<reverse-path> <CRLF>
RCPT <SP> TO:<forward-path> <CRLF>
DATA <CRLF>
RSET <CRLF>
SEND <SP> FROM:<reverse-path> <CRLF>
SOML <SP> FROM:<reverse-path> <CRLF>
SAML <SP> FROM:<reverse-path> <CRLF>
VRFY <SP> <string> <CRLF>
EXPN <SP> <string> <CRLF>
HELP [<SP> <string>] <CRLF>
NOOP <CRLF>
QUIT <CRLF>
TURN <CRLF>
*/
