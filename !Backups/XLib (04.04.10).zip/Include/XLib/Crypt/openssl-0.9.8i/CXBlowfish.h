/****************************************************************************
* Class name:  CXBlowfish
* Description: 
* File name:   CXBlowfish.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.08.2009 10:41:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXBlowfishWrap_openssl_0_9_8i_H
#define CXBlowfishWrap_openssl_0_9_8i_H
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Crypt/openssl-0.9.8i/blowfish.h>
//---------------------------------------------------------------------------
class CXBlowfish {
    public:
		       CXBlowfish       ();
              ~CXBlowfish       ();
       
	    BOOL   bSetKey          (UCHAR *pucKey, INT iKeySize); 
        BOOL   bSetKey          (const tstring &csKey);
		BOOL   bSetKey          (const tstring &csFilePath, ULONG ulKeySize);

		BOOL   bEncryptCbc      (UCHAR *pucIn, UCHAR *pucOut, ULONG ulInSize);
		BOOL   bDecryptCbc      (UCHAR *pucIn, UCHAR *pucOut, ULONG ulInSize);
		
        BOOL   bEncryptCbc      (const tstring &sIn, tstring &sOut); 
		BOOL   bDecryptCbc      (const tstring &sIn, tstring &sOut);

    private:   
        enum { 
            MAX_KEY_SIZE = 56, //������������ ����� ����� 448 ���
			IVEC_SIZE    = 8
        };
        
		//����� ����������
		typedef enum {
			emEncrypt = BF_ENCRYPT,
			emDecrypt = BF_DECRYPT 
		} ECryptMode;
        
        BF_KEY _m_bfKey;
		UCHAR  _m_ucIvec[IVEC_SIZE];

		//--CHAR   _m_chAdditionalSymbol;
		tstring    _m_chAdditionalSymbol;
        INT    _iAdditionalBytes(ULONG ulInSize);
};
//---------------------------------------------------------------------------
#endif




#include <XLib/CXString.h>
#include <XLib/Fso/CXStdioFile.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXBlowfish
CXBlowfish::CXBlowfish() :
	//--_m_chAdditionalSymbol('\0')
	_m_chAdditionalSymbol(_T("\0"))
{
	::ZeroMemory(&_m_bfKey,  sizeof(BF_KEY));
	::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
}
//---------------------------------------------------------------------------
//TODO: + ~CXBlowfish
CXBlowfish::~CXBlowfish() {
	/*SECURE*/::ZeroMemory(&_m_bfKey,  sizeof(BF_KEY));
	/*SECURE*/::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
}
//---------------------------------------------------------------------------
//TODO: + bSetKey (���� - tstring)
BOOL CXBlowfish::bSetKey(const tstring &csKey) {
	/*DEBUG*/XASSERT_RET(false == csKey.empty(), FALSE);

	BOOL        bRes = FALSE;
	tstring sKey;
	
	sKey.assign(csKey);
	
	//--BF_set_key(&_m_bfKey, sKey.size(), (UCHAR *)sKey.c_str());
	bRes = bSetKey((UCHAR *)sKey.c_str(), sKey.size());
	CHECK_RET(FALSE == bRes, FALSE);
	
	/*SECURE*/::ZeroMemory((LPVOID)&sKey[0], sKey.size());

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetKey (���� - UCHAR)
BOOL CXBlowfish::bSetKey(UCHAR *pucKey, INT iKeySize) {
	/*DEBUG*/XASSERT_RET(NULL != pucKey, FALSE);

	BF_set_key(&_m_bfKey, iKeySize, pucKey);
	
	/*SECURE*///::ZeroMemory((LPVOID)pucKey, iKeySize);         ?????????????

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetKey (���� - ����)
BOOL CXBlowfish::bSetKey(const tstring &csFilePath, ULONG ulKeySize) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	BOOL        bRes         = FALSE;
	size_t      uiRes        = 0;
	tstring sFileContent;
	CXStdioFile sfFile;

	bRes = sfFile.bOpen(csFilePath, _T("rb"));
	CHECK_RET(FALSE == bRes, FALSE);

	sFileContent.resize(sfFile.liGetSize());
	uiRes = sfFile.uiRead(&sFileContent[0], sFileContent.size());
	CHECK_RET(sFileContent.size() != uiRes, FALSE);

	bRes = bSetKey((UCHAR *)sFileContent.c_str(), sFileContent.size());
	CHECK_RET(FALSE == bRes, FALSE);

	/*SECURE*/::ZeroMemory((LPVOID)&sFileContent[0], sFileContent.size());

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bEncryptCbc (tstring)
BOOL CXBlowfish::bEncryptCbc(const tstring &csIn, tstring &sOut) {
	//CHECK_RET(true == sIn.empty(), TRUE);
	
	BOOL    bRes = FALSE;
	tstring sIn;
	
    //��������� ����� �� 8
    sIn.assign(csIn);
    sIn.append(_iAdditionalBytes(sIn.size()), _m_chAdditionalSymbol.at(0)); 

	::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
	sOut.resize(sIn.size());
	////--BF_cbc_encrypt((UCHAR *)&sIn[0], (UCHAR *)&sOut[0], sIn.size(), &_m_bfKey, _m_ucIvec, emEncrypt);
	bRes = bEncryptCbc((UCHAR *)&sIn[0], (UCHAR *)&sOut[0], (ULONG)sIn.size());
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bEncryptCbc (tstring)
BOOL CXBlowfish::bDecryptCbc(const tstring &csIn, tstring &sOut) {
	//CHECK_RET(true == sIn.empty(), TRUE);

	BOOL bRes = FALSE;
	
	::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
	sOut.resize(csIn.size());
	////--BF_cbc_encrypt((UCHAR *)&csIn[0], (UCHAR *)&sOut[0], csIn.size(), &_m_bfKey, _m_ucIvec, emDecrypt);
	bRes = bDecryptCbc((UCHAR *)&csIn[0], (UCHAR *)&sOut[0], (ULONG)csIn.size());
	CHECK_RET(FALSE == bRes, FALSE);
	
	/* sOut.assign(sTrimRightChar(sOut, _m_chAdditionalSymbol)); */
	sOut.assign(sTrimRightChars(sOut, _m_chAdditionalSymbol));	/*sTrimRightChar*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bEncryptCbc (UCHAR)
BOOL CXBlowfish::bEncryptCbc(UCHAR *pucIn, UCHAR *pucOut, ULONG ulInSize) {
	/*DEBUG*/XASSERT_RET(NULL != pucIn,    FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pucIn,    FALSE);
    /*DEBUG*/////XASSERT_RET(0    != ulInSize, FALSE);

	::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
	BF_cbc_encrypt(pucIn, pucOut, ulInSize, &_m_bfKey, _m_ucIvec, emEncrypt);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bDecryptCbc (UCHAR
BOOL CXBlowfish::bDecryptCbc(UCHAR *pucIn, UCHAR *pucOut, ULONG ulInSize) {
	/*DEBUG*/XASSERT_RET(NULL != pucIn,    FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pucIn,    FALSE);
    /*DEBUG*/////XASSERT_RET(0    != ulInSize, FALSE);

	::ZeroMemory(&_m_ucIvec, sizeof(_m_ucIvec));
	BF_cbc_encrypt(pucIn, (UCHAR *)pucOut, ulInSize, &_m_bfKey, _m_ucIvec, emDecrypt);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - _iAdditionalBytes (������� ���� ���� �������� �� 8)
INT CXBlowfish::_iAdditionalBytes(ULONG ulInSize) {
	return (0 == (ulInSize % 8) ? 0 : (8 - (ulInSize % 8))) ;
}
//---------------------------------------------------------------------------