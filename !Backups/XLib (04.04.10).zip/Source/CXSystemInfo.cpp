/****************************************************************************
* Class name:  CXSystemInfo
* Description: ��������� ����������
* File name:   CXSystemInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSystemInfo.h>

#include <Lmcons.h>
//---------------------------------------------------------------------------
//TODO: + CXSystemInfo (�����������)
CXSystemInfo::CXSystemInfo() {

}
//---------------------------------------------------------------------------
//TODO: + ~CXSystemInfo (����������)
CXSystemInfo::~CXSystemInfo(){

}
//---------------------------------------------------------------------------
//TODO: - GetOS ()
/*static*/CXSystemInfo::EOsType CXSystemInfo::GetOS() {
	OSVERSIONINFO OSversion = {0};

	OSversion.dwOSVersionInfoSize = sizeof(OSversion);
	::GetVersionEx(&OSversion);

	// This switch statement comes from
	// http://www.codeproject.com/win32/osdetect.asp
	// Originally written by Agus Kurniawan, but I've
	// modified it a bit.

	switch (OSversion.dwPlatformId) {
		case VER_PLATFORM_WIN32s: 
			return osWindows3;

		case VER_PLATFORM_WIN32_WINDOWS:
			{
				if (0 == OSversion.dwMinorVersion) {
					return osWindows95;
				} else if (10 == OSversion.dwMinorVersion) { 
					return osWindows98;
				} else if (90 == OSversion.dwMinorVersion) {  
					return osWindows98;
				}
			}
			break;

		case VER_PLATFORM_WIN32_NT:
			{
				if (5 == OSversion.dwMajorVersion && 0 == OSversion.dwMinorVersion) {
					return osWindows2000;
				} else if (5 == OSversion.dwMajorVersion &&  1 == OSversion.dwMinorVersion) {
					return osWindowsXP;
				} else if (OSversion.dwMajorVersion <= 4) {
					return osWindowsNT;
				} else {	
					//for unknown windows/newest windows version
					return osWindows2003;
				}
			}
			break;

		default:	
			return osUnknown;
			break;
	}      

	return osUnknown;
}
//---------------------------------------------------------------------------
//TODO: + sGetComputerName (Retrieves the NetBIOS name of the local computer)
/*static*/ tstring CXSystemInfo::sGetComputerName() {
	/*DEBUG*///not need

	BOOL  bRes                                = FALSE;
	ULONG ulBuffSize                          = MAX_COMPUTERNAME_LENGTH;
	TCHAR szBuff[MAX_COMPUTERNAME_LENGTH + 1] = {0};

	bRes = ::GetComputerName(szBuff, &ulBuffSize);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, _T("LOCALHOST")); 

	return tstring(szBuff, ulBuffSize);
}
//---------------------------------------------------------------------------
//TODO: + sGetUserName (Retrieves the name of the user associated with the current thread)
/*static*/ tstring CXSystemInfo::sGetUserName() {
	/*DEBUG*///not need

	BOOL  bRes              = FALSE;
	ULONG ulBuffSize        = UNLEN;
	TCHAR szBuff[UNLEN + 1] = {0};

	bRes = ::GetUserName(&szBuff[0], &ulBuffSize);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, tstring());  

	return tstring(szBuff, ulBuffSize);
}
//---------------------------------------------------------------------------
//TODO: + ulGetNumOfCPUs ()
/*static*/ ULONG CXSystemInfo::ulGetNumOfCPUs() {
	/*DEBUG*///not need

	SYSTEM_INFO siSysInfo = {0};

	::GetSystemInfo(&siSysInfo); 
	/*DEBUG*///not need

	//The processor architecture of the installed operating system
	USHORT    usProcessorArchitecture     = siSysInfo.wProcessorArchitecture;
	//The page size and the granularity of page protection and commitment
	ULONG     ulPageSize                  = siSysInfo.dwPageSize;
	//A pointer to the lowest memory address accessible to applications and dynamic-link libraries (DLLs)
	LPVOID    pvMinimumApplicationAddress = siSysInfo.lpMinimumApplicationAddress;
	//A pointer to the highest memory address accessible to applications and DLLs
	LPVOID    pvMaximumApplicationAddress = siSysInfo.lpMaximumApplicationAddress;
	//A mask representing the set of processors configured into the system
	DWORD_PTR pulActiveProcessorMask      = siSysInfo.dwActiveProcessorMask;    
	//The number of physical processors in the system
	ULONG     ulNumberOfProcessors        = siSysInfo.dwNumberOfProcessors;
	//An obsolete member that is retained for compatibility
	ULONG     ulProcessorType             = siSysInfo.dwProcessorType;
	//The granularity for the starting address at which virtual memory can be allocated.
	ULONG     ulAllocationGranularity     = siSysInfo.dwAllocationGranularity;
	//The architecture-dependent processor level
	USHORT    usProcessorLevel            = siSysInfo.wProcessorLevel;
	//The architecture-dependent processor revision
	USHORT    usProcessorRevision         = siSysInfo.wProcessorRevision;

	return ulNumberOfProcessors;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCurrCPUNum (Retrieves the number of the processor the current thread was running on during the call to this function)
/////*static*/ ULONG CXSystemInfo::ulGetCurrCPUNum() {
////	/*DEBUG*///not need 
////
////	ULONG ulRes = (ULONG) - 1;
////
////	ulRes = ::GetCurrentProcessorNumber();
////	/*DEBUG*///not need 
////
////	return ulRes;
////}
//---------------------------------------------------------------------------