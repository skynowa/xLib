/****************************************************************************
* Class name:  CXCOM
* Description: ���
* File name:   CXCOM.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2009 15:27:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXCOM.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXCOM (�����������)
CXCOM::CXCOM(EConcurrencyModel cmCoModel/* = cmMultiThreaded*/) :
	_m_ulConModel(static_cast<ULONG>(cmCoModel))
{
	/*DEBUG*/// n/a ?

	////xCHECK_DO(TRUE == CXCOM::bIsInit(cmCoModel), return);

	HRESULT hrRes = S_FALSE;

	hrRes = ::CoInitializeEx(NULL, _m_ulConModel);
	/*DEBUG*/xASSERT_DO(S_OK == hrRes || RPC_E_CHANGED_MODE == hrRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXCOM (����������)
CXCOM::~CXCOM() {
	::CoUninitialize(); 
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Static methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - bIsInit ()
/*static*/
BOOL CXCOM::bIsInit(EConcurrencyModel cmCoModel) {
	/*DEBUG*/// n/a

	BOOL    bRes  = FALSE;
	HRESULT hrRes = S_FALSE;

	hrRes = ::CoInitializeEx(NULL, static_cast<ULONG>(cmCoModel));
	/*DEBUG*/// n/a
	
	if (RPC_E_CHANGED_MODE == hrRes) {		//vMsgBox(_T("RPC_E_CHANGED_MODE"));
		bRes = TRUE;
	} else {
		::CoUninitialize(); 
		/*DEBUG*/// n/a	
		
		bRes = FALSE;
	}
	
	return bRes;
}
//---------------------------------------------------------------------------








/****************************************************************************
*    Protected methods                                                       
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------




/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
