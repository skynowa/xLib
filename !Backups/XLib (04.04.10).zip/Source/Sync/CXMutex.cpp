/****************************************************************************
* Class name:  CXMutex
* Description: ������ � ����������
* File name:   CXMutex.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:48:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Sync/CXMutex.h>

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXMutex ()
CXMutex::CXMutex() {

}
//---------------------------------------------------------------------------
//TODO: + ~CXMutex ()
CXMutex::~CXMutex() {
	/*DEBUG*/xASSERT(FALSE != _m_hMutex.bIsValid());
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXMutex::hGetHandle() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hMutex.bIsValid(), NULL);

	return _m_hMutex.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + bCreate ()
BOOL CXMutex::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialOwner, LPCTSTR pcszName) {
	/*DEBUG*/xASSERT_RET(FALSE == _m_hMutex.bIsValid(), FALSE);
	/*DEBUG*///lpsaAttributes - not need
	/*DEBUG*///bInitialOwner  - not need
	/*DEBUG*///pcszName       - not need

	HANDLE hRes = NULL;

	hRes = ::CreateMutex(lpsaAttributes, bInitialOwner, pcszName);
	/*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	_m_hMutex.m_hHandle = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXMutex::bOpen(ULONG dwAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hMutex.bIsValid(), FALSE);
	/*DEBUG*///dwAccess       - not need
	/*DEBUG*///bInheritHandle - not need
	/*DEBUG*///pcszName       - not need

	HANDLE hRes = NULL;

	hRes = ::OpenMutex(dwAccess, bInheritHandle, pcszName);
	/*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	_m_hMutex.m_hHandle = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRelease ()
BOOL CXMutex::bRelease() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hMutex.bIsValid(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::ReleaseMutex(_m_hMutex.m_hHandle);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXMutex::bWait(ULONG ulTimeout) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hMutex.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - not need

	ULONG ulRes = WAIT_FAILED;

	ulRes = ::WaitForSingleObject(_m_hMutex.m_hHandle, ulTimeout); 
	/*DEBUG*/xASSERT_RET(WAIT_OBJECT_0  == ulRes, FALSE);
	/*DEBUG*/xASSERT_RET(WAIT_ABANDONED != ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------