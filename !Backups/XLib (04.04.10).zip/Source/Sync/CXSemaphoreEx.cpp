/****************************************************************************
* Class name:  CXSemaphoreEx
* Description: ������ � ����������
* File name:   CXSemaphoreEx.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXSemaphoreEx.h>

//---------------------------------------------------------------------------
//TODO: + CXSemaphoreEx ()
CXSemaphoreEx::CXSemaphoreEx() :
	_m_lpsaAttributes(NULL),
	_m_pcszName      (NULL),
	_m_liInitialCount(0),
	_m_liMaxCount    (0),
	_m_liCounter     (- 1)
{
	BOOL bRes = FALSE;

	bRes = _m_csCounter.bCreate(NULL, FALSE, NULL);
	/*DEBUG*/xASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXSemaphoreEx ()
CXSemaphoreEx::~CXSemaphoreEx() {

}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXSemaphoreEx::hGetHandle() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), NULL);

	return _m_hSemaphore.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + bCreate (Creates or opens a named or unnamed semaphore object)
BOOL CXSemaphoreEx::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCTSTR pcszName) {
	/*DEBUG*/xASSERT_RET(FALSE == _m_hSemaphore.bIsValid(),					  FALSE);
	/*DEBUG*///lpsaAttributes - not need
	/*DEBUG*/////xASSERT_RET(0 <= liInitialCount && liInitialCount <= liMaxCount, FALSE);
	/*DEBUG*/xASSERT_RET(MAX_PATH > ::lstrlen(pcszName),					  FALSE);

	/////_m_hSemaphore.m_hHandle = hRes;
	_m_lpsaAttributes       = lpsaAttributes;
	_m_pcszName             = pcszName;
	_m_liInitialCount       = liInitialCount;
	_m_liMaxCount           = liMaxCount;

	_m_liCounter            = liInitialCount; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRelease ()
BOOL CXSemaphoreEx::bRelease(LONG liReleaseCount, LONG *pliOldCount)  {
	///*DEBUG*/xASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), FALSE);
	/*DEBUG*///liReleaseCount - not need
	/*DEBUG*///pliOldCount    - not need

	BOOL bRes = FALSE;
	
	{
		CXMutexLocker CS(_m_csCounter);

		_m_liCounter = _m_liCounter + liReleaseCount; 
		
		if (_m_liCounter <= 0) {		
			bRes = _m_slSleeper.bWakeUp();	//(all atomic)
			/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXSemaphoreEx::bWait(ULONG ulTimeout)  {
	///*DEBUG*/xASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - not need

	BOOL bRes = FALSE;

	-- _m_liCounter; 
	
	if (_m_liCounter < 0) {	
		bRes = _m_slSleeper.bSleep(ulTimeout);	//(atomic until asleep)
		/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + liGetValue ()
LONG CXSemaphoreEx::liGetValue() const {
	///*DEBUG*/xASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), - 1);

	LONG liRes = - 1; 
	//////BOOL bRes  = FALSE;

	//////bRes = bRelease(0, &liRes);
	///////*DEBUG*/xASSERT_RET(FALSE != bRes, - 1);

	return liRes; 
}
//---------------------------------------------------------------------------
//TODO: + bReset ()
BOOL CXSemaphoreEx::bReset(LONG liInitialCount, LONG liMaxCount) {
	///*DEBUG*/xASSERT_RET(FALSE != _m_hSemaphore.bIsValid(),                   FALSE);
	////*DEBUG*/xASSERT_RET(0 <= liInitialCount && liInitialCount <= liMaxCount, FALSE);

	BOOL bRes = FALSE;

	CXMutexLocker CS(_m_csCounter);
	{
		_m_liCounter = liInitialCount; 
	}

	return TRUE;
}
//---------------------------------------------------------------------------