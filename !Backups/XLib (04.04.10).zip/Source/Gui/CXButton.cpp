/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXButton.h>

#include <XLib/GUI/CXApplication.h>
#include <XLib/GUI/CXWindowImpl.h>


//---------------------------------------------------------------------------
//TODO: + CXButton
CXButton::CXButton() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXBUTTON_CONTROL_CLASS;
	_m_ulStyle        = xCXBUTTON_DEFAULT_WINDOW_STYLE;    
	_m_ulStyleEx      = xCXBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = xCXBUTTON_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXButton
/*virtual*/
CXButton::~CXButton() {
	LOG();

	/*DEBUG*/xASSERT_DO(NULL != _m_pwndParent, return);
	_m_bRes = reinterpret_cast<CXWindowImpl *>(_m_pwndParent)->m_vecpContainer.bRemove(this);
	xCHECK_DO(FALSE == _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + bCreate
BOOL CXButton::bCreateRes(INT iID, CXWindow *pwndParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,            FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pwndParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
								CXResources::sGetText  (iID), 
								CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
								CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
								CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
								this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	//////-------------------------------------
	//////�������������� ���� ������
	////_m_pwndParent = pwndParent;

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	���������
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: - bSetStyle (Sets the style of a button)
////BOOL CXButton::bSetStyle(DWORD ulStyle, BOOL bRedraw) {
////	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
////	/*DEBUG*///ulStyle
////	/*DEBUG*///bRedraw
////
////	/*static_cast<BOOL>*/( Button_SetStyle(_m_hWnd, ulStyle, bRedraw) );
////	/*DEBUG*///n/a
////
////	return TRUE;
////}
//---------------------------------------------------------------------------
//TODO: - bSetViewStyle ()
BOOL CXButton::bSetViewStyle(EViewStyle vsViewStyle) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	////_m_bRes = bAddStyle(/*WS_CHILD | WS_VISIBLE | WS_TABSTOP |*/ vsViewStyle);  
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	
	_m_bRes = bAddStyle(vsViewStyle);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bSetImage
BOOL CXButton::bSetImage(EImageType itImageType, HANDLE hImage) {
	HANDLE hRes = NULL;

	//hRes = (HANDLE)( pSendMessage(BM_SETIMAGE, (WPARAM)itImageType, (LPARAM)hImage) );
	///*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	(HANDLE)pSendMessage(BM_SETIMAGE, static_cast<WPARAM>(itImageType), reinterpret_cast<LPARAM>(/*(HICON)*/hImage));
	/*DEBUG*/// n/a

	return TRUE;
}
//---------------------------------------------------------------------------









/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vSet_OnClick ()
VOID CXButton::vSet_OnClick(SClosureT<VOID(CXButton *pbtnSender)> vCallback) {
	_m_vCallback_OnClick = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnClick ()
VOID CXButton::_vHandler_OnClick(CXButton *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnClick, return); 

	_m_vCallback_OnClick(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnDbClick ()
VOID CXButton::vSet_OnDbClick(SClosureT<VOID(CXButton *pbtnSender)> vCallback) {
	_m_vCallback_OnDbClick = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnClick ()
VOID CXButton::_vHandler_OnDbClick(CXButton *pbtnSender) {
	xCHECK_DO(NULL == _m_vCallback_OnDbClick, return); 

	_m_vCallback_OnDbClick(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnKillFocus ()
VOID CXButton::vSet_OnKillFocus(SClosureT<VOID(CXButton *pbtnSender)> vCallback) {
	_m_vCallback_OnKillFocus = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnKillFocus()
VOID CXButton::_vHandler_OnKillFocus(CXButton *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnKillFocus, return); 

	_m_vCallback_OnKillFocus(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnSetFocus ()
VOID CXButton::vSet_OnSetFocus(SClosureT<VOID(CXButton *pbtnSender)> vCallback) {
	_m_vCallback_OnSetFocus = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnSetFocus ()
VOID CXButton::_vHandler_OnSetFocus(CXButton *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnSetFocus, return); 

	_m_vCallback_OnSetFocus(pbtnSender);
}
//---------------------------------------------------------------------------