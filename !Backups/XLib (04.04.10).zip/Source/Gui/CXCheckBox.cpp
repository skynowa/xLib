/****************************************************************************
* Class name:  CXCheckBox
* Description: 
* File name:   CXCheckBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:47:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXCheckBox.h>

#include <XLib/GUI/CXWindowImpl.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXCheckBox
CXCheckBox::CXCheckBox() {
	LOG();
	
	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXCHECKBOX_CONTROL_CLASS;
	_m_ulStyle        = xCXCHECKBOX_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = xCXCHECKBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXCHECKBOX_DEFAULT_WIDTH;
	_m_iHeight        = xCXCHECKBOX_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXCheckBox
CXCheckBox::~CXCheckBox() {
	LOG();
	
	/*DEBUG*/xASSERT_DO(NULL != _m_pwndParent, return);
	_m_bRes = reinterpret_cast<CXWindowImpl *>(_m_pwndParent)->m_vecpContainer.bRemove(this);
	xCHECK_DO(FALSE == _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXCheckBox::bCreateRes(INT iID, CXWindow *pwndParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,            FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pwndParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
							    CXResources::sGetText  (iID), 
							    CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
							    CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
							    CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
							    this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + lpGetState (Gets the check state of a radio button or check box)
CXCheckBox::ECheckState CXCheckBox::csGetState() {
	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), csUknown);

	ECheckState csRes = csUknown;

	csRes = static_cast<ECheckState>( pSendMessage(BM_GETCHECK, 0, 0) );
	/*DEBUG*/xASSERT_RET(csRes == csChecked || csRes == csGrayed || csRes == csUnchecked, csUknown);

	return csRes;	
} 
//---------------------------------------------------------------------------
//TODO: + bSetState (Sets the check state of a radio button or check box)
BOOL CXCheckBox::bSetState(CXCheckBox::ECheckState csCheckState) {
	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
	/*DEBUG*///bstState

	////xASSERT_RET(TRUE == bIsStyleExists(BS_AUTOCHECKBOX), TRUE);

	////xCHECK_RET((TRUE == bIsStyleExists(BS_AUTOCHECKBOX)) && (csGrayed == csCheckState), TRUE);


	pSendMessage(BM_SETCHECK, csCheckState, 0);
	/*DEBUG*/// n/a
	
	////Button_SetCheck(_m_hWnd, csCheckState);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetAllowGrayed ()
BOOL CXCheckBox::bSetAllowGrayed(BOOL bFlag) {
	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
	/*DEBUG*///bFlag - n/a
	
	if (FALSE == bFlag) {
		bModifyStyle(BS_AUTO3STATE, BS_AUTOCHECKBOX);
	} else {
		bModifyStyle(BS_AUTOCHECKBOX, BS_AUTO3STATE); 
	}

	return TRUE;
}
//---------------------------------------------------------------------------