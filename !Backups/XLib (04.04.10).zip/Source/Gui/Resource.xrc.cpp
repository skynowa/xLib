/****************************************************************************
* Class name:  
* Description: ���� �������� (��������� �++)
* File name:   Resource.xrc
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.09.2009 9:44:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_ResourceXrcH
#define XLib_Gui_ResourceXrcH

#include <XLib/GUI/Resource.xrc.h>
#include <tchar.h>

/****************************************************************************
*   IDD_DIALOG1
*
*****************************************************************************/


//---------------------------------------------------------------------------
_bInitControl(IDD_DIALOG1,          _T("wndMain"),          0,   0,    600, 500, 0, 0);
_bInitControl(IDC_btnButton1,       _T("btnButton1"),       11,  11,   75,  23,  0, 0);
_bInitControl(IDC_btnPushButton1,   _T("btnPushButton1"),   240, 11,   75,  23,  0, 0);
_bInitControl(IDC_btnImageButton1,  _T("btnImageButton1"),  240, 42,   75,  75,  0, 0);
_bInitControl(IDC_edtEdit1,         _T("edtEdit1"),         11,  42,   74,  23,  0, 0);
_bInitControl(IDC_cboComboBox1,     _T("cboComboBox1"),     11,  72,   74,  49,  0, 0);
_bInitControl(IDC_btnExit,          _T("Exit"),             500, 400,  75,  23,  0, 0);
_bInitControl(IDC_staStatic1,       _T("staStatic1"),       11,  106,  74,  13,  0, 0);
_bInitControl(IDC_grpbGroupBox1,    _T("grpbGroupBox1"),    17,  128,  72,  65,  0, 0);
_bInitControl(IDC_chkCheckBox1,     _T("chkCheckBox1"),     11,  202,  59,  16,  BS_AUTOCHECKBOX | WS_TABSTOP, 0);
_bInitControl(IDC_lstListBox1,      _T("lstListBox1"),      11,  234,  87,  55,  LBS_SORT | LBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_TABSTOP, 0);
_bInitControl(IDC_lvListView1,      _T("lvListView1"),      113,  11,  90,  81,  LVS_LIST | LVS_ALIGNLEFT | WS_BORDER | WS_TABSTOP, 0);
_bInitControl(IDC_prgProgressBar1,  _T("prgProgressBar1"),  114,  98,  87,  23,  WS_BORDER, 0);
_bInitControl(IDC_rbtnRadioButton1, _T("rbtnRadioButton1"), 116,  133, 57,  16,  BS_AUTORADIOBUTTON, 0);
_bInitControl(IDC_redtRichEdit1,    _T("redtRichEdit1"),    122,  164, 60,  23,  ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP, 0);
_bInitControl(IDC_stabStatusBar1,   _T("stabStatusBar1"),   0,    0,   0,   0,   0, 0);
_bInitControl(IDC_tabTab1,          _T("tabTab1"),          116,  200, 300, 200, 0, 0);
//---------------------------------------------------------------------------


/****************************************************************************
*   IDD_WND_DIALOG
*
*****************************************************************************/

//---------------------------------------------------------------------------
_bInitControl(IDD_WND_DIALOG,      _T("About Dialog"),    100,   200,   300, 200, 0, 0);
//---------------------------------------------------------------------------

/****************************************************************************
*   IDD_WND_SHEET
*
*****************************************************************************/

//---------------------------------------------------------------------------
_bInitControl(IDD_WND_SHEET,      _T("Sheet"),    100,   200,   300, 200, 0, 0);
//---------------------------------------------------------------------------
#endif //XLib_Gui_ResourceXrcH