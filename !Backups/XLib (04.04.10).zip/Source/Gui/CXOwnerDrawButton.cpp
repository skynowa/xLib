/****************************************************************************
* Class name:  CXOwnerDrawButton
* Description: 
* File name:   CXOwnerDrawButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Gui/CXOwnerDrawButton.h>

#include <XLib/GUI/CXWindowImpl.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXOwnerDrawButton
CXOwnerDrawButton::CXOwnerDrawButton() {
	/*DEBUG*/

	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXOWNERDRAWBUTTON_CONTROL_CLASS;
	_m_ulStyle        = xCXOWNERDRAWBUTTON_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = xCXOWNERDRAWBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXOWNERDRAWBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = xCXOWNERDRAWBUTTON_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXOwnerDrawButton
/*virtual*/
CXOwnerDrawButton::~CXOwnerDrawButton() {
	LOG();
	
	/*DEBUG*/xASSERT_DO(NULL != _m_pwndParent, return);
	_m_bRes = reinterpret_cast<CXWindowImpl *>(_m_pwndParent)->m_vecpContainer.bRemove(this);
	xCHECK_DO(FALSE == _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXOwnerDrawButton::bCreateRes(INT iID, CXWindow *pwndParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,            FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pwndParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
							    CXResources::sGetText  (iID), 
							    CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
							    CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
							    CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
							    this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/
