/****************************************************************************
* Class name:  CXButtonBase
* Description: ������ � �������
* File name:   CXButtonBase.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXButtonBase.h>

#include <XLib/GUI/CXApplication.h>
#include <XLib/GUI/CXWindowImpl.h>


//---------------------------------------------------------------------------
//TODO: + CXButtonBase
CXButtonBase::CXButtonBase() {
	LOG();


	//-------------------------------------
	//�������������� ��������� ����
	/*
	� ����������� �������
	*/
}
//---------------------------------------------------------------------------
//TODO: + ~CXButtonBase
/*virtual*/
CXButtonBase::~CXButtonBase() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreate
////BOOL CXButtonBase::bCreateRes(INT iID, CXWindow *pwndParent) {
////	/*DEBUG*/xASSERT_RET(0 < iID,            FALSE);
////	/*DEBUG*/xASSERT_RET(NULL != pwndParent, FALSE);
////
////	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
////								CXResources::sGetText  (iID), 
////								CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
////								CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
////								CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
////								this);
////	xCHECK_RET(FALSE == _m_bRes, FALSE);
////
////	//////-------------------------------------
////	//////�������������� ���� ������
////	////_m_pwndParent = pwndParent;
////
////	return TRUE;
////}
//---------------------------------------------------------------------------



/****************************************************************************
*	���������
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: - bSetAlignment ()
BOOL CXButtonBase::bSetAlignment(ETextAligment taTextAligment) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE); 

	_m_bRes = bAddStyle(taTextAligment);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetNotify ()
BOOL CXButtonBase::bSetNotify(BOOL bFlag) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE); 

	if (TRUE == bFlag) {
		_m_bRes = bAddStyle(BS_NOTIFY);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	} else {
		_m_bRes = bRemoveStyle(BS_NOTIFY);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetFlat ()
BOOL CXButtonBase::bSetFlat(BOOL bFlag) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE); 

	if (TRUE == bFlag) {
		_m_bRes = bAddStyle(BS_FLAT);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	} else {
		_m_bRes = bRemoveStyle(BS_FLAT);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetMultiLine ()
BOOL CXButtonBase::bSetMultiLine(BOOL bFlag) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE); 

	if (TRUE == bFlag) {
		_m_bRes = bAddStyle(BS_MULTILINE);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	} else {
		_m_bRes = bRemoveStyle(BS_MULTILINE);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bClick ()
BOOL CXButtonBase::bClick() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	////_m_bRes = bSetActive();
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	////_m_bRes = bPostMessage(BM_CLICK, 0, 0);
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	//GetParent()->PostMessage(WM_COMMAND, MAKELONG (GetDlgCtrlID(), BN_CLICKED), (LPARAM)m_hWnd);
	///_m_bRes = _m_pwndParent->bPostMessage(WM_COMMAND, (WPARAM)MAKELONG(_m_iID, BN_CLICKED), (LPARAM)_m_hWnd);
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 


	////_m_bRes = ::PostMessage(GetWindowOwner(_m_hWnd), WM_COMMAND, (WPARAM)MAKELONG(_m_iID, BN_CLICKED), (LPARAM)_m_hWnd);
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	_m_bRes = _m_pwndParent->bPostMessage(WM_COMMAND, (WPARAM)MAKELONG(::GetDlgCtrlID(_m_hWnd)/*_m_iID*/, BN_CLICKED), (LPARAM)_m_hWnd);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------











/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vSet_OnClick ()
VOID CXButtonBase::vSet_OnClick(SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback) {
	_m_vCallback_OnClick = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnClick ()
VOID CXButtonBase::_vHandler_OnClick(CXButtonBase *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnClick, return); 

	_m_vCallback_OnClick(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnDbClick ()
VOID CXButtonBase::vSet_OnDbClick(SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback) {
	_m_vCallback_OnDbClick = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnClick ()
VOID CXButtonBase::_vHandler_OnDbClick(CXButtonBase *pbtnSender) {
	xCHECK_DO(NULL == _m_vCallback_OnDbClick, return); 

	_m_vCallback_OnDbClick(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnKillFocus ()
VOID CXButtonBase::vSet_OnKillFocus(SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback) {
	_m_vCallback_OnKillFocus = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnKillFocus()
VOID CXButtonBase::_vHandler_OnKillFocus(CXButtonBase *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnKillFocus, return); 

	_m_vCallback_OnKillFocus(pbtnSender);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + vSet_OnSetFocus ()
VOID CXButtonBase::vSet_OnSetFocus(SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback) {
	_m_vCallback_OnSetFocus = vCallback;
}
//---------------------------------------------------------------------------
//TODO: + _vHandler_OnSetFocus ()
VOID CXButtonBase::_vHandler_OnSetFocus(CXButtonBase *pbtnSender)	{
	xCHECK_DO(NULL == _m_vCallback_OnSetFocus, return); 

	_m_vCallback_OnSetFocus(pbtnSender);
}
//---------------------------------------------------------------------------