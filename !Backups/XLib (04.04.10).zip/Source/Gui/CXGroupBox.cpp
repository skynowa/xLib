/****************************************************************************
* Class name:  CXGroupBox
* Description: 
* File name:   CXGroupBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:10:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXGroupBox.h>

#include <XLib/GUI/CXWindowImpl.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXGroupBox
CXGroupBox::CXGroupBox() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ���� 
	_m_sClassName     = xCXGROUPBOX_CONTROL_CLASS;           
	_m_ulStyle        = xCXGROUPBOX_DEFAULT_WINDOW_STYLE;     
	_m_ulStyleEx      = xCXGROUPBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXGROUPBOX_DEFAULT_WIDTH;     
	_m_iHeight        = xCXGROUPBOX_DEFAULT_HEIGHT;  

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - CXGroupBox
/*virtual*/
CXGroupBox::~CXGroupBox() {
	LOG();
	
	/*DEBUG*/xASSERT_DO(NULL != _m_pwndParent, return);
	_m_bRes = reinterpret_cast<CXWindowImpl *>(_m_pwndParent)->m_vecpContainer.bRemove(this);
	xCHECK_DO(FALSE == _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXGroupBox::bCreateRes(INT iID, CXWindow *pwndParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,            FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pwndParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, pwndParent, _m_sClassName, 
							    CXResources::sGetText  (iID), 
							    CXResources::iGetLeft  (iID), CXResources::iGetTop     (iID), 
							    CXResources::iGetWidth (iID), CXResources::iGetHeight  (iID), 
							    CXResources::ulGetStyle(iID), CXResources::ulGetStyleEx(iID),
							    this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------