/****************************************************************************
* Class name:  CXWindowImpl
* Description: ������ � ������
* File name:   CXWindowImpl.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Gui/CXWindowImpl.h>

#include <XLib/GUI/Common.h>
#include <XLib/GUI/CXApplication.h>
#include <XLib/CXString.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXWindowImpl
CXWindowImpl::CXWindowImpl() :
	CXWindow       (),
    _m_bIsDestroyed(FALSE),
	m_vecpContainer()
{
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName = xCXWINDOW_CONTROL_CLASS + tstring(_T("_")) + CXString::sCreatePlainGUID();
	_m_ulStyle    = xCXFRAME_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx  = xCXFRAME_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft      = CW_USEDEFAULT;
	_m_iTop       = CW_USEDEFAULT;
	_m_iWidth     = xCXFRAME_DEFAULT_WIDTH;
	_m_iHeight    = xCXFRAME_DEFAULT_HEIGHT;

	_m_bIsControl = FALSE;
}
//---------------------------------------------------------------------------
//TODO: - ~CXWindowImpl
CXWindowImpl::~CXWindowImpl() {
	_m_bRes = _bUnregisterClass(_m_sClassName);
	xCHECK_DO(FALSE == _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: - bCreate
BOOL CXWindowImpl::bCreate(INT iID, HWND hParent, const tstring &csText, 
							INT iLeft, INT iTop, INT iWidth, INT iHeight, 
							ULONG ulStyle, ULONG ulExStyle)
{
	//-------------------------------------
	//������������ ����� ����
	WNDCLASSEX wcex = {0};

	wcex.cbSize         = sizeof(WNDCLASSEX);																		//������ ��������� � ������ 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;																	//����� ������ ���� 
	wcex.lpfnWndProc	= xreinterpret_cast<WNDPROC>(_s_pWndProc);													//��������� �� ������� ���� 
	wcex.cbClsExtra		= 0;																						//�������������� ������ � ������ ��� ������ ����  
	wcex.cbWndExtra		= 0;																						//�������������� ������ � ������ ��� ������� ���� ����� ������ 
	wcex.hInstance		= CXApplication::hGetInstance();															//���������� ���������� ���������� 
	wcex.hIcon			= ::LoadIcon(CXApplication::hGetInstance(), static_cast<LPCTSTR>(NULL)/*siIconID*/);		//���������� ����������� ���������� 
	wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);															//���������� ������� ���������� 
	wcex.hbrBackground	= reinterpret_cast<HBRUSH>( (COLOR_WINDOW + reinterpret_cast<HBRUSH>(3)/*siBGColor*/) );	//���������� ����� ��� �������� ���� ����
	wcex.lpszMenuName	= reinterpret_cast<LPCTSTR>(iID);															//��������� �� ������  � ������ ���� ���� 
	wcex.lpszClassName	= _m_sClassName.c_str();																	//��������� �� ������  � ������ ������ ���� 
	wcex.hIconSm		= ::LoadIcon(CXApplication::hGetInstance(), static_cast<LPCTSTR>(0)/*siIconSmID*/);			//���������� ����� ����������� 

	_m_bRes = _bRegisterClass(&wcex);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	//-------------------------------------
	//������� ����
	_m_bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, csText, 
							 iLeft, iTop, iWidth, iHeight,
							 _m_ulStyle | ulStyle, 
							 /*WS_EX_CLIENTEDGE | WS_EX_APPWINDOW*/_m_ulStyleEx | ulExStyle, 
							 (LPVOID)this);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

    //-------------------------------------
	//���� ��� �������� ����, �� ��������� ������������
	////if (NULL != _m_hParentWnd) {
	////    bRes = ::EnableWindow(_m_hParentWnd, FALSE);
	////	  /*DEBUG*/xASSERT_RET(0 == bRes, FALSE);
	////}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bCreateRes
BOOL CXWindowImpl::bCreateRes(INT iID, HWND hParent) { 
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*///xASSERT_RET(NULL != hParent, FALSE);

	_m_bRes = CXWindowImpl::bCreate(iID, hParent, 
								    CXResources::sGetText    (iID), 
								    CXResources::iGetLeft    (iID), CXResources::iGetTop   (iID), 
								    CXResources::iGetWidth   (iID), CXResources::iGetHeight(iID), 
								    CXResources::ulGetStyle  (iID), 
								    CXResources::ulGetStyleEx(iID));
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bShowModal
BOOL CXWindowImpl::bShowModal() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	MSG msgMsg = {0};   

	_m_bRes = bShow(SW_SHOW);
	xCHECK_RET(FALSE == _m_bRes, FALSE);

	for (_m_bIsDestroyed = FALSE; !_m_bIsDestroyed && ::GetMessage(&msgMsg, NULL, 0, 0); ) {
		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return _m_bIsDestroyed;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/


/****************************************************************************
*	�������
*
*****************************************************************************/




//---------------------------------------------------------------------------
//TODO: ����� ���������
xBEGIN_MSG_MAP(CXWindowImpl)
	////xMSG(WM_CREATE,  vOnCreate)	
	////xMSG(WM_PAINT,   vOnPaint);
	////xMSG(WM_COMMAND, vOnCommand);
	////xMSG(WM_NOTIFY,  vOnNotify);
	////xMSG(WM_SIZE,    vOnSize);
	////xMSG(WM_CLOSE,   vOnClose); 
	////xMSG(WM_DESTROY, vOnDestroy);
	
	xMSG(WM_NULL                        , vOnNull)
	xMSG(WM_CREATE                      , vOnCreate)
	xMSG(WM_DESTROY                     , vOnDestroy)
	xMSG(WM_MOVE                        , vOnMove)
	xMSG(WM_SIZE                        , vOnSize)
	xMSG(WM_ACTIVATE                    , vOnActivate)
	xMSG(WM_SETFOCUS                    , vOnSetFocus)
	xMSG(WM_KILLFOCUS                   , vOnKillFocus)
	xMSG(WM_ENABLE                      , vOnEnable)
	xMSG(WM_SETREDRAW                   , vOnSetreDraw)
	xMSG(WM_SETTEXT                     , vOnSetText)
	xMSG(WM_GETTEXT                     , vOnGetText)
	xMSG(WM_GETTEXTLENGTH               , vOnGetTextlength)
	xMSG(WM_PAINT                       , vOnPaint)
	xMSG(WM_CLOSE                       , vOnClose)

#ifndef _WIN32_WCE
	xMSG(WM_QUERYENDSESSION             , vOnQueryEndSession)
	xMSG(WM_QUERYOPEN                   , vOnQueryOpen)
	xMSG(WM_ENDSESSION                  , vOnEndSession)
#endif

	xMSG(WM_QUIT                        , vOnQuit)
	////xMSG(WM_ERASEBKGND                  , vOnEraseBkGnd)
	xMSG(WM_SYSCOLORCHANGE              , vOnSysColorChange)
	xMSG(WM_SHOWWINDOW                  , vOnShowWindow)
	xMSG(WM_WININICHANGE                , vOnWininiChange)
	
#if(WINVER >= 0x0400)
	xMSG(WM_SETTINGCHANGE               , vOnSettingChange)
#endif /* WINVER >= 0x0400 */

	xMSG(WM_DEVMODECHANGE               , vOnDevModeChange)
	xMSG(WM_ACTIVATEAPP                 , vOnActivateApp)
	xMSG(WM_FONTCHANGE                  , vOnFontChange)
	xMSG(WM_TIMECHANGE                  , vOnTimeChange)
	xMSG(WM_CANCELMODE                  , vOnCancelMode)
	xMSG(WM_SETCURSOR                   , vOnSetCursor)
	xMSG(WM_MOUSEACTIVATE               , vOnMouseActivate)
	xMSG(WM_CHILDACTIVATE               , vOnChildActivate)
	xMSG(WM_QUEUESYNC                   , vOnQueueSync)
	xMSG(WM_GETMINMAXINFO               , vOnGetMinMaxInfo)
	xMSG(WM_PAINTICON                   , vOnPaintIcon)
	xMSG(WM_ICONERASEBKGND              , vOnIconEraseBkGnd)
	xMSG(WM_NEXTDLGCTL                  , vOnNextDlgCtl)
	xMSG(WM_SPOOLERSTATUS               , vOnSpoolerStatus)
	xMSG(WM_DRAWITEM                    , vOnDrawItem)
	xMSG(WM_MEASUREITEM                 , vOnMeasureItem)
	xMSG(WM_DELETEITEM                  , vOnDeleteItem)
	xMSG(WM_VKEYTOITEM                  , vOnVKeyToItem)
	xMSG(WM_CHARTOITEM                  , vOnCharToItem)
	xMSG(WM_SETFONT                     , vOnSetFont)
	xMSG(WM_GETFONT                     , vOnGetFont)
	xMSG(WM_SETHOTKEY                   , vOnSetHotKey)
	xMSG(WM_GETHOTKEY                   , vOnGetHotKey)
	xMSG(WM_QUERYDRAGICON               , vOnQueryDragIcon)
	xMSG(WM_COMPAREITEM                 , vOnCompareItem)
	
#if(WINVER >= 0x0500)
#ifndef _WIN32_WCE
	xMSG(WM_GETOBJECT                   , vOnGetObject)
#endif
#endif /* WINVER >= 0x0500 */

	xMSG(WM_COMPACTING                  , vOnCompacting)
	xMSG(WM_COMMNOTIFY                  , vOnCommNotify)  /* no longer suported */
	xMSG(WM_WINDOWPOSCHANGING           , vOnWindowPosChanging)
	xMSG(WM_WINDOWPOSCHANGED            , vOnWindowPosChanged)
	xMSG(WM_POWER                       , vOnPower)
	xMSG(WM_COPYDATA                    , vOnCopyData)
	xMSG(WM_CANCELJOURNAL               , vOnCancelJournal)
	
#if(WINVER >= 0x0400)
	xMSG(WM_NOTIFY                      , vOnNotify)
	xMSG(WM_INPUTLANGCHANGEREQUEST      , vOnInputLangChangeRequest)
	xMSG(WM_INPUTLANGCHANGE             , vOnInputLangChange)
	xMSG(WM_TCARD                       , vOnTCard)
	xMSG(WM_HELP                        , vOnHelp)
	xMSG(WM_USERCHANGED                 , vOnUserChanged)
	xMSG(WM_NOTIFYFORMAT                , vOnNotifyFormat)
	xMSG(WM_CONTEXTMENU                 , vOnContextMenu)
	xMSG(WM_STYLECHANGING               , vOnStyleChanging)
	xMSG(WM_STYLECHANGED                , vOnStyleChanged)
	xMSG(WM_DISPLAYCHANGE               , vOnDisplayChange)
	xMSG(WM_GETICON                     , vOnGetIcon)
	xMSG(WM_SETICON                     , vOnSetIcon)
#endif /* WINVER >= 0x0400 */

	////xMSG(WM_NCCREATE                    , vOnNcCreate)
	////xMSG(WM_NCDESTROY                   , vOnNcDestroy)
	////xMSG(WM_NCCALCSIZE                  , vOnNcCalcSize)
	////xMSG(WM_NCHITTEST                   , vOnNcHitTest)
	////xMSG(WM_NCPAINT                     , vOnNcPaint)
	////xMSG(WM_NCACTIVATE                  , vOnNcActivate)
	xMSG(WM_GETDLGCODE                  , vOnGetDlgCode)
	
#ifndef _WIN32_WCE
	xMSG(WM_SYNCPAINT                   , vOnSyncPaint)
#endif

	////xMSG(WM_NCMOUSEMOVE                 , vOnNcMouseMove)
	////xMSG(WM_NCLBUTTONDOWN               , vOnNcLButtonDown)
	////xMSG(WM_NCLBUTTONUP                 , vOnNcLButtonUp)
	////xMSG(WM_NCLBUTTONDBLCLK             , vOnNcLButtonDblClk)
	////xMSG(WM_NCRBUTTONDOWN               , vOnNcRButtonDown)
	////xMSG(WM_NCRBUTTONUP                 , vOnNcRButtonUp)
	////xMSG(WM_NCRBUTTONDBLCLK             , vOnNcRButtonDblClk)
	////xMSG(WM_NCMBUTTONDOWN               , vOnNcMButtonDown)
	////xMSG(WM_NCMBUTTONUP                 , vOnNcMButtonUp)
	////xMSG(WM_NCMBUTTONDBLCLK             , vOnNcMButtonDblClk)

#if(_WIN32_WINNT >= 0x0500)
	////xMSG(WM_NCXBUTTONDOWN               , vOnNcXButtonDown)
	////xMSG(WM_NCXBUTTONUP                 , vOnNcXButtonUp)
	////xMSG(WM_NCXBUTTONDBLCLK             , vOnNcXButtonDblClk)
#endif /* _WIN32_WINNT >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_INPUT_DEVICE_CHANGE         , vOnInputDeviceChange)
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_INPUT                       , vOnInput)
#endif /* _WIN32_WINNT >= 0x0501 */

	////xMSG(WM_KEYFIRST                    , vOnKeyFirst)
	////xMSG(WM_KEYDOWN                     , vOnKeyDown)
	////xMSG(WM_KEYUP                       , vOnKeyUp)
	////xMSG(WM_CHAR                        , vOnChar)
	////xMSG(WM_DEADCHAR                    , vOnDeadChar)
	////xMSG(WM_SYSKEYDOWN                  , vOnSysKeyDown)
	////xMSG(WM_SYSKEYUP                    , vOnSysKeyUp)
	////xMSG(WM_SYSCHAR                     , vOnSysChar)
	////xMSG(WM_SYSDEADCHAR                 , vOnSysDeadChar)
	
#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_UNICHAR                     , vOnUniChar)
	xMSG(WM_KEYLAST                     , vOnKeyLast)
#else
	xMSG(WM_KEYLAST                     , vOnKeyLast)
#endif /* _WIN32_WINNT >= 0x0501 */

#if(WINVER >= 0x0400)
	xMSG(WM_IME_STARTCOMPOSITION        , vOnImeStartComposition)
	xMSG(WM_IME_ENDCOMPOSITION          , vOnImeEndComposition)
	xMSG(WM_IME_COMPOSITION             , vOnImeComposition)
	xMSG(WM_IME_KEYLAST                 , vOnImeKeyLast)
#endif /* WINVER >= 0x0400 */

	xMSG(WM_INITDIALOG                  , vOnInitdialog)
	xMSG(WM_COMMAND                     , vOnCommand)
	////xMSG(WM_SYSCOMMAND                  , vOnSysCommand)
	xMSG(WM_TIMER                       , vOnTimer)
	xMSG(WM_HSCROLL                     , vOnHScroll)
	xMSG(WM_VSCROLL                     , vOnVScroll)
	xMSG(WM_INITMENU                    , vOnInitMenu)
	xMSG(WM_INITMENUPOPUP               , vOnInitMenuPopup)
	xMSG(WM_MENUSELECT                  , vOnMenuSelect)
	xMSG(WM_MENUCHAR                    , vOnMenuChar)
	xMSG(WM_ENTERIDLE                   , vOnEnterIdle)
	
#if(WINVER >= 0x0500)
#ifndef _WIN32_WCE
	xMSG(WM_MENURBUTTONUP               , vOnMenuRButtonUp)
	xMSG(WM_MENUDRAG                    , vOnMenuDrag)
	xMSG(WM_MENUGETOBJECT               , vOnMenuGetObject)
	xMSG(WM_UNINITMENUPOPUP             , vOnUnInitMenuPopup)
	xMSG(WM_MENUCOMMAND                 , vOnMenuCommand)

#ifndef _WIN32_WCE
#if(_WIN32_WINNT >= 0x0500)
	xMSG(WM_CHANGEUISTATE               , vOnChangeUiState)
	xMSG(WM_UPDATEUISTATE               , vOnUpdateUiState)
	xMSG(WM_QUERYUISTATE                , vOnQueryUiState)
#endif /* _WIN32_WINNT >= 0x0500 */
#endif

#endif
#endif /* WINVER >= 0x0500 */

	xMSG(WM_CTLCOLORMSGBOX              , vOnCtlColorMsgBox)
	xMSG(WM_CTLCOLOREDIT                , vOnCtlColorEdit)
	xMSG(WM_CTLCOLORLISTBOX             , vOnCtlColorListbox)
	xMSG(WM_CTLCOLORBTN                 , vOnCtlColorBtn)
	xMSG(WM_CTLCOLORDLG                 , vOnCtlColorDlg)
	xMSG(WM_CTLCOLORSCROLLBAR           , vOnCtlColorScrollBar)
	xMSG(WM_CTLCOLORSTATIC              , vOnCtlColorStatic)
	xMSG(WM_MOUSEFIRST                  , vOnMouseFirst)
	xMSG(WM_MOUSEMOVE                   , vOnMouseMove)
	xMSG(WM_LBUTTONDOWN                 , vOnLButtonDown)
	xMSG(WM_LBUTTONUP                   , vOnLButtonUp)
	xMSG(WM_LBUTTONDBLCLK               , vOnLButtonDblClk)
	xMSG(WM_RBUTTONDOWN                 , vOnRButtonDown)
	xMSG(WM_RBUTTONUP                   , vOnRButtonUp)
	xMSG(WM_RBUTTONDBLCLK               , vOnRButtonDblClk)
	xMSG(WM_MBUTTONDOWN                 , vOnMButtonDown)
	xMSG(WM_MBUTTONUP                   , vOnMButtonUp)
	xMSG(WM_MBUTTONDBLCLK               , vOnMButtonDblClk)
	
#if (_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)
	xMSG(WM_MOUSEWHEEL                  , vOnMouseWheel)
#endif

#if (_WIN32_WINNT >= 0x0500)
	xMSG(WM_XBUTTONDOWN                 , vOnXButtonDown)
	xMSG(WM_XBUTTONUP                   , vOnXButtonUp)
	xMSG(WM_XBUTTONDBLCLK               , vOnXButtonDblClk)
#endif

#if (_WIN32_WINNT >= 0x0600)
	xMSG(WM_MOUSEHWHEEL                 , vOnMouseHWheel)
#endif

	xMSG(WM_MOUSELAST                   , vOnMouseLast) 
	xMSG(WM_PARENTNOTIFY                , vOnParentNotify)
	xMSG(WM_ENTERMENULOOP               , vOnEnterMenuLoop)
	xMSG(WM_EXITMENULOOP                , vOnExitMenuLoop)

#if(WINVER >= 0x0400)
	xMSG(WM_NEXTMENU                    , vOnNextMenu)
	xMSG(WM_SIZING                      , vOnSizing)
	xMSG(WM_CAPTURECHANGED              , vOnCaptureChanged)
	xMSG(WM_MOVING                      , vOnMoving)
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0400)
	xMSG(WM_POWERBROADCAST              , vOnPowerBroadcast)
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0400)
	xMSG(WM_DEVICECHANGE                , vOnDeviceChange)
#endif /* WINVER >= 0x0400 */

	xMSG(WM_MDICREATE                   , vOnMdiCreate)
	xMSG(WM_MDIDESTROY                  , vOnMdiDestroy)
	xMSG(WM_MDIACTIVATE                 , vOnMdiActivate)
	xMSG(WM_MDIRESTORE                  , vOnMdiRestore)
	xMSG(WM_MDINEXT                     , vOnMdiNext)
	xMSG(WM_MDIMAXIMIZE                 , vOnMdiMaximize)
	xMSG(WM_MDITILE                     , vOnMdiTile)
	xMSG(WM_MDICASCADE                  , vOnMdiCascade)
	xMSG(WM_MDIICONARRANGE              , vOnMdiIconArrange)
	xMSG(WM_MDIGETACTIVE                , vOnMdiGetActive)
	xMSG(WM_MDISETMENU                  , vOnMdiSetMenu)
	xMSG(WM_ENTERSIZEMOVE               , vOnEnterSizeMove)
	xMSG(WM_EXITSIZEMOVE                , vOnExitSizeMove)
	xMSG(WM_DROPFILES                   , vOnDropFiles)
	xMSG(WM_MDIREFRESHMENU              , vOnMdiRefreshMenu)

#if(WINVER >= 0x0400)
	xMSG(WM_IME_SETCONTEXT              , vOnImeSetContext)
	xMSG(WM_IME_NOTIFY                  , vOnImeNotify)
	xMSG(WM_IME_CONTROL                 , vOnImeControl)
	xMSG(WM_IME_COMPOSITIONFULL         , vOnImeCompositionFull)
	xMSG(WM_IME_SELECT                  , vOnImeSelect)
	xMSG(WM_IME_CHAR                    , vOnImeChar)
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0500)
	xMSG(WM_IME_REQUEST                 , vOnImeRequest)
#endif /* WINVER >= 0x0500 */

#if(WINVER >= 0x0400)
	xMSG(WM_IME_KEYDOWN                 , vOnImeKeyDown)
	xMSG(WM_IME_KEYUP                   , vOnImeKeyUp)
#endif /* WINVER >= 0x0400 */

#if((_WIN32_WINNT >= 0x0400) || (WINVER >= 0x0500))
	xMSG(WM_MOUSEHOVER                  , vOnMouseHover)
	xMSG(WM_MOUSELEAVE                  , vOnMouseLeave)
#endif

#if(WINVER >= 0x0500)
	xMSG(WM_NCMOUSEHOVER                , vOnNcMouseHover)
	xMSG(WM_NCMOUSELEAVE                , vOnNcMouseLeave)
#endif /* WINVER >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_WTSSESSION_CHANGE           , vOnWtsSessionChange)
	xMSG(WM_TABLET_FIRST                , vOnTabletFirst)
	xMSG(WM_TABLET_LAST                 , vOnTabletLast)
#endif /* _WIN32_WINNT >= 0x0501 */

	xMSG(WM_CUT                         , vOnCut)
	xMSG(WM_COPY                        , vOnCopy)
	xMSG(WM_PASTE                       , vOnPaste)
	xMSG(WM_CLEAR                       , vOnClear)
	xMSG(WM_UNDO                        , vOnUndo)
	xMSG(WM_RENDERFORMAT                , vOnRenderFormat)
	xMSG(WM_RENDERALLFORMATS            , vOnRenderAllFormats)
	xMSG(WM_DESTROYCLIPBOARD            , vOnDestroyClipboard)
	xMSG(WM_DRAWCLIPBOARD               , vOnDrawClipboard)
	xMSG(WM_PAINTCLIPBOARD              , vOnPaintClipboard)
	xMSG(WM_VSCROLLCLIPBOARD            , vOnVScrollClipboard)
	xMSG(WM_SIZECLIPBOARD               , vOnSizeClipboard)
	xMSG(WM_ASKCBFORMATNAME             , vOnAskCBFormatName)
	xMSG(WM_CHANGECBCHAIN               , vOnChangeCBChain)
	xMSG(WM_HSCROLLCLIPBOARD            , vOnHScrollClipboard)
	xMSG(WM_QUERYNEWPALETTE             , vOnQueryNewPalette)
	xMSG(WM_PALETTEISCHANGING           , vOnPaletteIsChanging)
	xMSG(WM_PALETTECHANGED              , vOnPaletteChanged)
	xMSG(WM_HOTKEY                      , vOnHotKey)

#if(WINVER >= 0x0400)
	xMSG(WM_PRINT                       , vOnPrint)
	xMSG(WM_PRINTCLIENT                 , vOnPrintClient)
#endif /* WINVER >= 0x0400 */

#if(_WIN32_WINNT >= 0x0500)
	xMSG(WM_APPCOMMAND                  , vOnAppCommand)
#endif /* _WIN32_WINNT >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_THEMECHANGED                , vOnThemeChanged)
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0501)
	xMSG(WM_CLIPBOARDUPDATE             , vOnClipboardUpdate)
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0600)
	xMSG(WM_DWMCOMPOSITIONCHANGED       , vOnDwmCompositionChanged)
	xMSG(WM_DWMNCRENDERINGCHANGED       , vOnDwmNcRenderingChanged)
	xMSG(WM_DWMCOLORIZATIONCOLORCHANGED , vOnDwmColorizationColorChanged)
	xMSG(WM_DWMWINDOWMAXIMIZEDCHANGE    , vOnDwmWindowMaximizedChange)
#endif /* _WIN32_WINNT >= 0x0600 */

#if(WINVER >= 0x0600)
	xMSG(WM_GETTITLEBARINFOEX           , vOnGetTitleBarInfoEx)
#endif /* WINVER >= 0x0600 */

#if(WINVER >= 0x0400)
	xMSG(WM_HANDHELDFIRST               , vOnHandHeldFirst)
	xMSG(WM_HANDHELDLAST                , vOnHandHeldFast)
	xMSG(WM_AFXFIRST                    , vOnAfxFirst)
	xMSG(WM_AFXLAST                     , vOnAfxLast)
#endif /* WINVER >= 0x0400 */

	xMSG(WM_PENWINFIRST                 , vOnPenWinFirst)
	xMSG(WM_PENWINLAST                  , vOnPenWinLast)

#if(WINVER >= 0x0400)
	xMSG(WM_APP                         , vOnApp)
#endif /* WINVER >= 0x0400 */

	xMSG(WM_USER                        , vOnUser)
xEND_MSG_MAP(CXWindow)
//---------------------------------------------------------------------------
//TODO: - vOnNull
/*virtual*/ 
VOID CXWindowImpl::vOnNull                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCreate
/*virtual*/ 
VOID CXWindowImpl::vOnCreate                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDestroy
/*virtual*/ 
VOID CXWindowImpl::vOnDestroy                      (WPARAM wParam, LPARAM lParam) {
	LOG();
		
	_m_bIsDestroyed = TRUE;

	if (NULL == _m_hParentWnd) {	//TODO: � ���� � �������� ���� ���� ��������?
		CXApplication::vTerminate();

		return;
	}

	HWND hRes = NULL;

	/*DEBUG*/xASSERT_DO(NULL != _m_hParentWnd, return);

	_m_bRes = ::EnableWindow(_m_hParentWnd, TRUE);
	/*DEBUG*///--xASSERT_DO(FALSE != _m_bRes, return);

	hRes = ::SetActiveWindow(_m_hParentWnd); 
	/*DEBUG*///--xASSERT_DO(NULL != hRes, return);

	_m_bRes = ::UpdateWindow(_m_hParentWnd);
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);

	_m_bRes = bClose();
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: - vOnMove
/*virtual*/ 
VOID CXWindowImpl::vOnMove                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSize
/*virtual*/ 
VOID CXWindowImpl::vOnSize                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnActivate
/*virtual*/ 
VOID CXWindowImpl::vOnActivate                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetFocus
/*virtual*/ 
VOID CXWindowImpl::vOnSetFocus                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnKillFocus
/*virtual*/ 
VOID CXWindowImpl::vOnKillFocus                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEnable
/*virtual*/ 
VOID CXWindowImpl::vOnEnable                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetreDraw
/*virtual*/ 
VOID CXWindowImpl::vOnSetreDraw                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetText
/*virtual*/ 
VOID CXWindowImpl::vOnSetText                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetText
/*virtual*/ 
VOID CXWindowImpl::vOnGetText                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetTextlength
/*virtual*/ 
VOID CXWindowImpl::vOnGetTextlength                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaint
/*virtual*/ 
VOID CXWindowImpl::vOnPaint                        (WPARAM wParam, LPARAM lParam) {
	//LOG();
	
	PAINTSTRUCT ps  = {0};
	HDC         hdc = NULL;

	hdc = ::BeginPaint(_m_hWnd, &ps);
	//TODO: Add any drawing code here...
	::EndPaint(_m_hWnd, &ps);
}
//---------------------------------------------------------------------------
//TODO: - vOnClose
/*virtual*/ 
VOID CXWindowImpl::vOnClose                        (WPARAM wParam, LPARAM lParam) {
	LOG();

	bDestroy();
}

//---------------------------------------------------------------------------
#ifndef _WIN32_WCE
//---------------------------------------------------------------------------
//TODO: - vOnQueryEndSession
/*virtual*/ 
VOID CXWindowImpl::vOnQueryEndSession              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnQueryOpen
/*virtual*/ 
VOID CXWindowImpl::vOnQueryOpen                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEndSession
/*virtual*/ 
VOID CXWindowImpl::vOnEndSession                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
//TODO: - vOnQuit
/*virtual*/ 
VOID CXWindowImpl::vOnQuit                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEraseBkGnd
/*virtual*/ 
VOID CXWindowImpl::vOnEraseBkGnd                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSysColorChange
/*virtual*/ 
VOID CXWindowImpl::vOnSysColorChange               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnShowWindow
/*virtual*/ 
VOID CXWindowImpl::vOnShowWindow                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnWininiChange
/*virtual*/ 
VOID CXWindowImpl::vOnWininiChange                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnSettingChange
/*virtual*/ 
VOID CXWindowImpl::vOnSettingChange                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnDevModeChange
/*virtual*/ 
VOID CXWindowImpl::vOnDevModeChange                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnActivateApp
/*virtual*/ 
VOID CXWindowImpl::vOnActivateApp                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnFontChange
/*virtual*/ 
VOID CXWindowImpl::vOnFontChange                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnTimeChange
/*virtual*/ 
VOID CXWindowImpl::vOnTimeChange                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCancelMode
/*virtual*/ 
VOID CXWindowImpl::vOnCancelMode                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetCursor
/*virtual*/ 
VOID CXWindowImpl::vOnSetCursor                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMouseActivate
/*virtual*/ 
VOID CXWindowImpl::vOnMouseActivate                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnChildActivate
/*virtual*/ 
VOID CXWindowImpl::vOnChildActivate                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnQueueSync
/*virtual*/ 
VOID CXWindowImpl::vOnQueueSync                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetMinMaxInfo
/*virtual*/ 
VOID CXWindowImpl::vOnGetMinMaxInfo                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaintIcon
/*virtual*/ 
VOID CXWindowImpl::vOnPaintIcon                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnIconEraseBkGnd
/*virtual*/ 
VOID CXWindowImpl::vOnIconEraseBkGnd               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNextDlgCtl
/*virtual*/ 
VOID CXWindowImpl::vOnNextDlgCtl                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSpoolerStatus
/*virtual*/ 
VOID CXWindowImpl::vOnSpoolerStatus                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDrawItem
/*virtual*/ 
VOID CXWindowImpl::vOnDrawItem                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMeasureItem
/*virtual*/ 
VOID CXWindowImpl::vOnMeasureItem                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDeleteItem
/*virtual*/ 
VOID CXWindowImpl::vOnDeleteItem                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnVKeyToItem
/*virtual*/ 
VOID CXWindowImpl::vOnVKeyToItem                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnXXXXXXXXX
/*virtual*/ 
VOID CXWindowImpl::vOnCharToItem                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetFont
/*virtual*/ 
VOID CXWindowImpl::vOnSetFont                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetFont
/*virtual*/ 
VOID CXWindowImpl::vOnGetFont                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetHotKey
/*virtual*/ 
VOID CXWindowImpl::vOnSetHotKey                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetHotKey
/*virtual*/ 
VOID CXWindowImpl::vOnGetHotKey                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnQueryDragIcon
/*virtual*/ 
VOID CXWindowImpl::vOnQueryDragIcon                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCompareItem
/*virtual*/ 
VOID CXWindowImpl::vOnCompareItem                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
	
#if(WINVER >= 0x0500)
#ifndef _WIN32_WCE
//---------------------------------------------------------------------------
//TODO: - vOnGetObject
/*virtual*/ 
VOID CXWindowImpl::vOnGetObject                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif
#endif /* WINVER >= 0x0500 */

//---------------------------------------------------------------------------
//TODO: - vOnCompacting
/*virtual*/ 
VOID CXWindowImpl::vOnCompacting                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCommNotify
/*virtual*/ 
VOID CXWindowImpl::vOnCommNotify                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}  /* no longer suported */
//---------------------------------------------------------------------------
//TODO: - vOnWindowPosChanging
/*virtual*/ 
VOID CXWindowImpl::vOnWindowPosChanging            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnWindowPosChanged
/*virtual*/ 
VOID CXWindowImpl::vOnWindowPosChanged             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPower
/*virtual*/ 
VOID CXWindowImpl::vOnPower                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCopyData
/*virtual*/ 
VOID CXWindowImpl::vOnCopyData                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCancelJournal
/*virtual*/ 
VOID CXWindowImpl::vOnCancelJournal                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnNotify
/*virtual*/ 
VOID CXWindowImpl::vOnNotify                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnInputLangChangeRequest
/*virtual*/ 
VOID CXWindowImpl::vOnInputLangChangeRequest       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnInputLangChange
/*virtual*/ 
VOID CXWindowImpl::vOnInputLangChange              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnTCard
/*virtual*/ 
VOID CXWindowImpl::vOnTCard                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnHelp
/*virtual*/ 
VOID CXWindowImpl::vOnHelp                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnUserChanged
/*virtual*/ 
VOID CXWindowImpl::vOnUserChanged                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNotifyFormat
/*virtual*/ 
VOID CXWindowImpl::vOnNotifyFormat                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnContextMenu
/*virtual*/ 
VOID CXWindowImpl::vOnContextMenu                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnStyleChanging
/*virtual*/ 
VOID CXWindowImpl::vOnStyleChanging                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnStyleChanged
/*virtual*/ 
VOID CXWindowImpl::vOnStyleChanged                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDisplayChange
/*virtual*/ 
VOID CXWindowImpl::vOnDisplayChange                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetIcon
/*virtual*/ 
VOID CXWindowImpl::vOnGetIcon                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSetIcon
/*virtual*/ 
VOID CXWindowImpl::vOnSetIcon                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnNcCreate
/*virtual*/ 
VOID CXWindowImpl::vOnNcCreate                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcDestroy
/*virtual*/ 
VOID CXWindowImpl::vOnNcDestroy                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcCalcSize
/*virtual*/ 
VOID CXWindowImpl::vOnNcCalcSize                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcHitTest
/*virtual*/ 
VOID CXWindowImpl::vOnNcHitTest                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcPaint
/*virtual*/ 
VOID CXWindowImpl::vOnNcPaint                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcActivate
/*virtual*/ 
VOID CXWindowImpl::vOnNcActivate                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnGetDlgCode
/*virtual*/ 
VOID CXWindowImpl::vOnGetDlgCode                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
	
#ifndef _WIN32_WCE
//---------------------------------------------------------------------------
//TODO: - vOnSyncPaint
/*virtual*/ 
VOID CXWindowImpl::vOnSyncPaint                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
//TODO: - vOnNcMouseMove
/*virtual*/ 
VOID CXWindowImpl::vOnNcMouseMove                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcLButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnNcLButtonDown               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcLButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnNcLButtonUp                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcLButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnNcLButtonDblClk              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcRButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnNcRButtonDown                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcRButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnNcRButtonUp                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcRButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnNcRButtonDblClk              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcMButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnNcMButtonDown                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcMButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnNcMButtonUp                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcMButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnNcMButtonDblClk              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(_WIN32_WINNT >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnNcXButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnNcXButtonDown                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcXButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnNcXButtonUp                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcXButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnNcXButtonDblClk              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnInputDeviceChange
/*virtual*/ 
VOID CXWindowImpl::vOnInputDeviceChange            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnInput
/*virtual*/ 
VOID CXWindowImpl::vOnInput                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

//---------------------------------------------------------------------------
//TODO: - vOnKeyFirst
/*virtual*/ 
VOID CXWindowImpl::vOnKeyFirst                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnKeyDown
/*virtual*/ 
VOID CXWindowImpl::vOnKeyDown                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnKeyUp
/*virtual*/ 
VOID CXWindowImpl::vOnKeyUp                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnChar
/*virtual*/ 
VOID CXWindowImpl::vOnChar                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDeadChar
/*virtual*/ 
VOID CXWindowImpl::vOnDeadChar                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSysKeyDown
/*virtual*/ 
VOID CXWindowImpl::vOnSysKeyDown                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSysKeyUp
/*virtual*/ 
VOID CXWindowImpl::vOnSysKeyUp                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSysChar
/*virtual*/ 
VOID CXWindowImpl::vOnSysChar                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSysDeadChar
/*virtual*/ 
VOID CXWindowImpl::vOnSysDeadChar                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnUniChar
/*virtual*/ 
VOID CXWindowImpl::vOnUniChar                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnKeyLast
/*virtual*/ 
VOID CXWindowImpl::vOnKeyLast                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
#else
//---------------------------------------------------------------------------
//TODO: - vOnKeyLast
/*virtual*/ 
VOID CXWindowImpl::vOnKeyLast                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnImeStartComposition
/*virtual*/ 
VOID CXWindowImpl::vOnImeStartComposition          (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeEndComposition
/*virtual*/ 
VOID CXWindowImpl::vOnImeEndComposition            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeComposition
/*virtual*/ 
VOID CXWindowImpl::vOnImeComposition               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeKeyLast
/*virtual*/ 
VOID CXWindowImpl::vOnImeKeyLast                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnInitdialog
/*virtual*/ 
VOID CXWindowImpl::vOnInitdialog                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCommand
/*virtual*/ 
VOID CXWindowImpl::vOnCommand                      (WPARAM wParam, LPARAM lParam) {
	LOG();
		
	for (UINT i = 0; i < m_vecpContainer.uiGetSize(); ++ i) {
		INT iId1 = LOWORD(wParam);	
		INT iId2 = m_vecpContainer.pwndGet(i)->iGetID();

		if (iId1 != iId2) {
			continue;
		}

		//-------------------------------------
		//����������� ��� CXStatic
		if (xCXSTATIC_CONTROL_CLASS == m_vecpContainer.pwndGet(i)->sGetClassName()) {
			switch (HIWORD(wParam))	{
				case STN_CLICKED:	vMsgBox(_T("STN_CLICKED"));	break;
				case STN_DBLCLK:	vMsgBox(_T("STN_DBLCLK"));	break;
				case STN_DISABLE:	vMsgBox(_T("STN_DISABLE"));	break;
				case STN_ENABLE:	vMsgBox(_T("STN_ENABLE"));	break;
			}

			return;
		}

		//-------------------------------------
		//����������� ��� CXButton, CXGroupBox, CXCheckBox, CXRadioButton 
		if (xCXBUTTON_CONTROL_CLASS == m_vecpContainer.pwndGet(i)->sGetClassName()) {
			switch (HIWORD(wParam))	{
				case BN_CLICKED:	m_vecpContainer.pwndGet(i)->vOnClick    ();	break;
				case BN_DBLCLK:		m_vecpContainer.pwndGet(i)->vOnDbClick  ();	break;
				case BN_KILLFOCUS:	m_vecpContainer.pwndGet(i)->vOnKillFocus();	break;
				case BN_SETFOCUS:	m_vecpContainer.pwndGet(i)->vOnSetFocus ();	break;
			}

			return;
		}
	} //for
}
//---------------------------------------------------------------------------
//TODO: - vOnSysCommand
/*virtual*/ 
VOID CXWindowImpl::vOnSysCommand                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnTimer
/*virtual*/ 
VOID CXWindowImpl::vOnTimer                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnHScroll
/*virtual*/ 
VOID CXWindowImpl::vOnHScroll                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnVScroll
/*virtual*/ 
VOID CXWindowImpl::vOnVScroll                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnInitMenu
/*virtual*/ 
VOID CXWindowImpl::vOnInitMenu                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnInitMenuPopup
/*virtual*/ 
VOID CXWindowImpl::vOnInitMenuPopup                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMenuSelect
/*virtual*/ 
VOID CXWindowImpl::vOnMenuSelect                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMenuChar
/*virtual*/ 
VOID CXWindowImpl::vOnMenuChar                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEnterIdle
/*virtual*/ 
VOID CXWindowImpl::vOnEnterIdle                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0500)
#ifndef _WIN32_WCE
//---------------------------------------------------------------------------
//TODO: - vOnMenuRButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnMenuRButtonUp                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMenuDrag
/*virtual*/ 
VOID CXWindowImpl::vOnMenuDrag                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMenuGetObject
/*virtual*/ 
VOID CXWindowImpl::vOnMenuGetObject                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnUnInitMenuPopup
/*virtual*/ 
VOID CXWindowImpl::vOnUnInitMenuPopup              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMenuCommand
/*virtual*/ 
VOID CXWindowImpl::vOnMenuCommand                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#ifndef _WIN32_WCE
#if(_WIN32_WINNT >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnChangeUiState
/*virtual*/ 
VOID CXWindowImpl::vOnChangeUiState                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnUpdateUiState
/*virtual*/ 
VOID CXWindowImpl::vOnUpdateUiState                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnQueryUiState
/*virtual*/ 
VOID CXWindowImpl::vOnQueryUiState                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0500 */
#endif

#endif
#endif /* WINVER >= 0x0500 */

//---------------------------------------------------------------------------
//TODO: - vOnCtlColorMsgBox
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorMsgBox               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorEdit
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorEdit                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorListbox
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorListbox              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorBtn
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorBtn                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorDlg
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorDlg                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorScrollBar
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorScrollBar            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCtlColorStatic
/*virtual*/ 
VOID CXWindowImpl::vOnCtlColorStatic               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMouseFirst
/*virtual*/ 
VOID CXWindowImpl::vOnMouseFirst                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMouseMove
/*virtual*/ 
VOID CXWindowImpl::vOnMouseMove                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnLButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnLButtonDown                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnLButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnLButtonUp                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnLButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnLButtonDblClk                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnRButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnRButtonDown                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnRButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnRButtonUp                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnRButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnRButtonDblClk                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnMButtonDown                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnMButtonUp                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnMButtonDblClk                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if (_WIN32_WINNT >= 0x0400) || (_WIN32_WINDOWS > 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnMouseWheel
/*virtual*/ 
VOID CXWindowImpl::vOnMouseWheel                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

#if (_WIN32_WINNT >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnXButtonDown
/*virtual*/ 
VOID CXWindowImpl::vOnXButtonDown                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnXButtonUp
/*virtual*/ 
VOID CXWindowImpl::vOnXButtonUp                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnXButtonDblClk
/*virtual*/ 
VOID CXWindowImpl::vOnXButtonDblClk                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

#if (_WIN32_WINNT >= 0x0600)
//---------------------------------------------------------------------------
//TODO: - vOnMouseHWheel
/*virtual*/ 
VOID CXWindowImpl::vOnMouseHWheel                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------
//TODO: - vOnMouseLast
/*virtual*/ 
VOID CXWindowImpl::vOnMouseLast                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnParentNotify
/*virtual*/ 
VOID CXWindowImpl::vOnParentNotify                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEnterMenuLoop
/*virtual*/ 
VOID CXWindowImpl::vOnEnterMenuLoop                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnExitMenuLoop
/*virtual*/ 
VOID CXWindowImpl::vOnExitMenuLoop                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnNextMenu
/*virtual*/ 
VOID CXWindowImpl::vOnNextMenu                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSizing
/*virtual*/ 
VOID CXWindowImpl::vOnSizing                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCaptureChanged
/*virtual*/ 
VOID CXWindowImpl::vOnCaptureChanged               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMoving
/*virtual*/ 
VOID CXWindowImpl::vOnMoving                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnPowerBroadcast
/*virtual*/ 
VOID CXWindowImpl::vOnPowerBroadcast               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnDeviceChange
/*virtual*/ 
VOID CXWindowImpl::vOnDeviceChange                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnMdiCreate
/*virtual*/ 
VOID CXWindowImpl::vOnMdiCreate                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiDestroy
/*virtual*/ 
VOID CXWindowImpl::vOnMdiDestroy                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiActivate
/*virtual*/ 
VOID CXWindowImpl::vOnMdiActivate                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiRestore
/*virtual*/ 
VOID CXWindowImpl::vOnMdiRestore                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiNext
/*virtual*/ 
VOID CXWindowImpl::vOnMdiNext                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiMaximize
/*virtual*/ 
VOID CXWindowImpl::vOnMdiMaximize                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiTile
/*virtual*/ 
VOID CXWindowImpl::vOnMdiTile                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiCascade
/*virtual*/ 
VOID CXWindowImpl::vOnMdiCascade                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiIconArrange
/*virtual*/ 
VOID CXWindowImpl::vOnMdiIconArrange               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiGetActive
/*virtual*/ 
VOID CXWindowImpl::vOnMdiGetActive                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiSetMenu
/*virtual*/ 
VOID CXWindowImpl::vOnMdiSetMenu                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnEnterSizeMove
/*virtual*/ 
VOID CXWindowImpl::vOnEnterSizeMove                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnExitSizeMove
/*virtual*/ 
VOID CXWindowImpl::vOnExitSizeMove                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDropFiles
/*virtual*/ 
VOID CXWindowImpl::vOnDropFiles                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMdiRefreshMenu
/*virtual*/ 
VOID CXWindowImpl::vOnMdiRefreshMenu               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnImeSetContext
/*virtual*/ 
VOID CXWindowImpl::vOnImeSetContext                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeNotify
/*virtual*/ 
VOID CXWindowImpl::vOnImeNotify                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeControl
/*virtual*/ 
VOID CXWindowImpl::vOnImeControl                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeCompositionFull
/*virtual*/ 
VOID CXWindowImpl::vOnImeCompositionFull           (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeSelect
/*virtual*/ 
VOID CXWindowImpl::vOnImeSelect                    (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeChar
/*virtual*/ 
VOID CXWindowImpl::vOnImeChar                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

#if(WINVER >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnImeRequest
/*virtual*/ 
VOID CXWindowImpl::vOnImeRequest                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0500 */

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnImeKeyDown
/*virtual*/ 
VOID CXWindowImpl::vOnImeKeyDown                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnImeKeyUp
/*virtual*/ 
VOID CXWindowImpl::vOnImeKeyUp                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

#if((_WIN32_WINNT >= 0x0400) || (WINVER >= 0x0500))
//---------------------------------------------------------------------------
//TODO: - vOnMouseHover
/*virtual*/ 
VOID CXWindowImpl::vOnMouseHover                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnMouseLeave
/*virtual*/ 
VOID CXWindowImpl::vOnMouseLeave                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif

#if(WINVER >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnNcMouseHover
/*virtual*/ 
VOID CXWindowImpl::vOnNcMouseHover                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnNcMouseLeave
/*virtual*/ 
VOID CXWindowImpl::vOnNcMouseLeave                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnWtsSessionChange
/*virtual*/ 
VOID CXWindowImpl::vOnWtsSessionChange             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnTabletFirst
/*virtual*/ 
VOID CXWindowImpl::vOnTabletFirst                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnTabletLast
/*virtual*/ 
VOID CXWindowImpl::vOnTabletLast                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

//---------------------------------------------------------------------------
//TODO: - vOnCut
/*virtual*/ 
VOID CXWindowImpl::vOnCut                          (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnCopy
/*virtual*/ 
VOID CXWindowImpl::vOnCopy                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaste
/*virtual*/ 
VOID CXWindowImpl::vOnPaste                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnClear
/*virtual*/ 
VOID CXWindowImpl::vOnClear                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnUndo
/*virtual*/ 
VOID CXWindowImpl::vOnUndo                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnRenderFormat
/*virtual*/ 
VOID CXWindowImpl::vOnRenderFormat                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnRenderAllFormats
/*virtual*/ 
VOID CXWindowImpl::vOnRenderAllFormats             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDestroyClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnDestroyClipboard             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDrawClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnDrawClipboard                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaintClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnPaintClipboard               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnVScrollClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnVScrollClipboard             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnSizeClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnSizeClipboard                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnAskCBFormatName
/*virtual*/ 
VOID CXWindowImpl::vOnAskCBFormatName              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnChangeCBChain
/*virtual*/ 
VOID CXWindowImpl::vOnChangeCBChain                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnHScrollClipboard
/*virtual*/ 
VOID CXWindowImpl::vOnHScrollClipboard             (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnQueryNewPalette
/*virtual*/ 
VOID CXWindowImpl::vOnQueryNewPalette              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaletteIsChanging
/*virtual*/ 
VOID CXWindowImpl::vOnPaletteIsChanging            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPaletteChanged
/*virtual*/ 
VOID CXWindowImpl::vOnPaletteChanged               (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnHotKey
/*virtual*/ 
VOID CXWindowImpl::vOnHotKey                       (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnPrint
/*virtual*/ 
VOID CXWindowImpl::vOnPrint                        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPrintClient
/*virtual*/ 
VOID CXWindowImpl::vOnPrintClient                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

#if(_WIN32_WINNT >= 0x0500)
//---------------------------------------------------------------------------
//TODO: - vOnAppCommand
/*virtual*/ 
VOID CXWindowImpl::vOnAppCommand                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0500 */

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnThemeChanged
/*virtual*/ 
VOID CXWindowImpl::vOnThemeChanged                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0501)
//---------------------------------------------------------------------------
//TODO: - vOnClipboardUpDate
/*virtual*/ 
VOID CXWindowImpl::vOnClipboardUpDate              (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0501 */

#if(_WIN32_WINNT >= 0x0600)
//---------------------------------------------------------------------------
//TODO: - vOnDwmCompositionChanged
/*virtual*/ 
VOID CXWindowImpl::vOnDwmCompositionChanged        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDwmNcRenderingChanged
/*virtual*/ 
VOID CXWindowImpl::vOnDwmNcRenderingChanged        (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDwmColorizationColorChanged
/*virtual*/ 
VOID CXWindowImpl::vOnDwmColorizationColorChanged  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnDwmWindowMaximizedChange
/*virtual*/ 
VOID CXWindowImpl::vOnDwmWindowMaximizedChange     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* _WIN32_WINNT >= 0x0600 */

#if(WINVER >= 0x0600)
//---------------------------------------------------------------------------
//TODO: - vOnGetTitleBarInfoEx
/*virtual*/ 
VOID CXWindowImpl::vOnGetTitleBarInfoEx            (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0600 */

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnHandHeldFirst
/*virtual*/ 
VOID CXWindowImpl::vOnHandHeldFirst                (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnHandHeldFast
/*virtual*/ 
VOID CXWindowImpl::vOnHandHeldFast                 (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnAfxFirst
/*virtual*/ 
VOID CXWindowImpl::vOnAfxFirst                     (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnAfxLast
/*virtual*/ 
VOID CXWindowImpl::vOnAfxLast                      (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnPenWinFirst
/*virtual*/ 
VOID CXWindowImpl::vOnPenWinFirst                  (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: - vOnPenWinLast
/*virtual*/ 
VOID CXWindowImpl::vOnPenWinLast                   (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------

#if(WINVER >= 0x0400)
//---------------------------------------------------------------------------
//TODO: - vOnApp
/*virtual*/ 
VOID CXWindowImpl::vOnApp                          (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------
#endif /* WINVER >= 0x0400 */

//---------------------------------------------------------------------------
//TODO: - vOnUser
/*
 * NOTE: All Message Numbers below 0x0400 are RESERVED.
 *
 * Private Window Messages Start Here:
 */
/*virtual*/ 
VOID CXWindowImpl::vOnUser                         (WPARAM wParam, LPARAM lParam) {
	LOG();
}
//---------------------------------------------------------------------------




/****************************************************************************
*	private
*
*****************************************************************************/