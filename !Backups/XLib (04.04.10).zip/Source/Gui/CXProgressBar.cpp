/****************************************************************************
* Class name:  CXProgressBar
* Description: ��������� ����������
* File name:   CXProgressBar.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.07.2009 11:05:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXProgressBar.h>

//---------------------------------------------------------------------------
CXProgressBar::CXProgressBar() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXPROGRESSBAR_CONTROL_CLASS;
	_m_ulStyle        = xCXPROGRESSBAR_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = xCXPROGRESSBAR_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXPROGRESSBAR_DEFAULT_WIDTH;
	_m_iHeight        = xCXPROGRESSBAR_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
	
	//TODO: _bInitCommonControls
	_bInitCommonControls(ICC_PROGRESS_CLASS);
}
//---------------------------------------------------------------------------
CXProgressBar::~CXProgressBar() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXProgressBar::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/xASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
		CXResources::sGetText(iID), 
		CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
		CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
		CXResources::ulGetStyle(iID), 
		CXResources::ulGetStyleEx(iID),
		this);
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetRange(INT nMin, INT nMax) {	 //�������� ��������� �������� � ��������� �������� (� �������� �� 0 �� 65535).
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETRANGE, (WPARAM)0, (LPARAM)MAKELPARAM(nMin, nMax));
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetRange32(INT nMin, INT nMax) {	 
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETRANGE32, (WPARAM)nMin, (LPARAM)nMax);
}
//---------------------------------------------------------------------------
BOOL CXProgressBar::bGetRange(PPBRANGE pPBRange) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(PBM_GETRANGE, (WPARAM)TRUE, (LPARAM)pPBRange);
	
	return TRUE;
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetRangeLimit(BOOL bLimit) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_GETRANGE, (WPARAM)bLimit, (LPARAM)NULL);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetMaxValue() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_GETRANGE, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetMinValue() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_GETRANGE, (WPARAM)1, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetPos(INT nPos) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETPOS, nPos, 0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetPos() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_GETPOS, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::DeltaPos(INT nDelta) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_DELTAPOS, nDelta, 0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetStep(INT nStep) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETSTEP, (WPARAM)nStep, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::StepIt() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_STEPIT, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBarColour(COLORREF clrBar) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETBARCOLOR , (WPARAM)0, (LPARAM)(COLORREF)clrBar);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBkColour(COLORREF clrBk) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return pSendMessage(PBM_SETBKCOLOR, (WPARAM)0, (LPARAM)(COLORREF)clrBk);
}
//---------------------------------------------------------------------------