/****************************************************************************
* Class name:  CXDateTime
* Description: ������ � ������
* File name:   CXDateTime.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXDateTime.h>


/****************************************************************************
*	Public	
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXDateTime (���������)
CXDateTime::CXDateTime() : 
	_m_ullDateTime(0)
{
	/*DEBUG*/

	::ZeroMemory(&_m_stDateTime, sizeof(SYSTEMTIME));
}
//---------------------------------------------------------------------------
//TODO: + CXDateTime (���������)
CXDateTime::CXDateTime(ULONGLONG ullDateTime) : 
	_m_ullDateTime(ullDateTime)
{
	/*DEBUG*/
	
	bMSecToDateTime(_m_ullDateTime, &_m_stDateTime);
}
//---------------------------------------------------------------------------
//TODO: + CXDateTime (���������)
CXDateTime::CXDateTime(USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMilliseconds) : 
	_m_ullDateTime(0)
{
	/*DEBUG*/xASSERT(usYear         >= 0);
	/*DEBUG*/xASSERT(usMonth        >= 1 && usMonth        <= 31);
	/*DEBUG*/xASSERT(usDay          >= 1 && usDay          <= 365);
	/*DEBUG*/xASSERT(usHour         >= 0 && usHour         <= 23);
	/*DEBUG*/xASSERT(usMinute       >= 0 && usMinute       <= 59);
	/*DEBUG*/xASSERT(usSecond       >= 0 && usSecond       <= 59);
	/*DEBUG*/xASSERT(usMilliseconds >= 0 && usMilliseconds <= 999);

	_m_stDateTime.wYear         = usYear;
	_m_stDateTime.wMonth        = usMonth;
	_m_stDateTime.wDayOfWeek    = 0; 
	_m_stDateTime.wDay          = usDay;
	_m_stDateTime.wHour         = usHour;
	_m_stDateTime.wMinute       = usMinute;
	_m_stDateTime.wSecond       = usSecond;
	_m_stDateTime.wMilliseconds = usMilliseconds;	

	_m_ullDateTime = ullDateTimeToMSec(_m_stDateTime);
}
//---------------------------------------------------------------------------
//TODO: + ~CXDateTime (����������)
CXDateTime::~CXDateTime() { 
	/*DEBUG*/
}
//---------------------------------------------------------------------------
//TODO: + dtNow (������� ����, �����)
CXDateTime CXDateTime::dtNow() { 
	/*DEBUG*/

	::GetLocalTime(&_m_stDateTime);
	_m_ullDateTime = ullDateTimeToMSec(_m_stDateTime);

	return CXDateTime(_m_ullDateTime);
}
//---------------------------------------------------------------------------
//TODO: + sFormatDateTimeStr (�������������� ����, �������)
tstring CXDateTime::sFormatDateTimeStr() {
	/*DEBUG*///not need

	return CXString::sFormatStr(_T("%d-%.2d-%.2d %d-%.2d-%.2d-%.3d"), 
						_m_stDateTime.wYear, _m_stDateTime.wMonth,  _m_stDateTime.wDay,
						_m_stDateTime.wHour, _m_stDateTime.wMinute, _m_stDateTime.wSecond, _m_stDateTime.wMilliseconds);
}
//--------------------------------------------------------------------------
//TODO: + sFormatDateStr (�������������� ����)
tstring CXDateTime::sFormatDateStr() {
	/*DEBUG*///not need

	return CXString::sFormatStr(_T("%.1d-%.2d-%.2d"), 
				      _m_stDateTime.wYear, _m_stDateTime.wMonth, _m_stDateTime.wDay);
}
//---------------------------------------------------------------------------
//TODO: + sFormatTimeStr (�������������� �������)
tstring CXDateTime::sFormatTimeStr() {
	/*DEBUG*///not need

	return CXString::sFormatStr(_T("%d:%.2d:%.2d:%.3d"), 
					  _m_stDateTime.wHour, _m_stDateTime.wMinute, _m_stDateTime.wSecond, _m_stDateTime.wMilliseconds);
}
//---------------------------------------------------------------------------

/****************************************************************************
*	Operators	
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + operator = ()
CXDateTime &CXDateTime::operator = (CXDateTime dtDT) { 
	/*DEBUG*/

	bMSecToDateTime(dtDT._m_ullDateTime, &_m_stDateTime);
	_m_ullDateTime = dtDT._m_ullDateTime;

	return *this;
}
//--------------------------------------------------------------------------
//TODO: + operator + ()
CXDateTime CXDateTime::operator + (CXDateTime dtDT) {  
	/*DEBUG*/

	bMSecToDateTime(_m_ullDateTime + dtDT._m_ullDateTime, &_m_stDateTime);

	return CXDateTime(_m_ullDateTime + dtDT._m_ullDateTime);
}
//--------------------------------------------------------------------------
//TODO: + operator - ()
CXDateTime CXDateTime::operator - (CXDateTime dtDT) {  
	/*DEBUG*/

	bMSecToDateTime(_m_ullDateTime - dtDT._m_ullDateTime, &_m_stDateTime);

	return CXDateTime(_m_ullDateTime - dtDT._m_ullDateTime);
}
//--------------------------------------------------------------------------




/****************************************************************************
*	Private	
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + bMSecToDateTime ()
/*static*/
BOOL CXDateTime::bMSecToDateTime(ULONGLONG ullMilliSec, SYSTEMTIME *stST) { 
	/*DEBUG*/

	BOOL bRes = FALSE;

	stST->wYear         = static_cast<USHORT>(ullMilliSec / ((1000ULL * 60 * 60 * 24 * 30) * 12));
	ullMilliSec        %= ((1000ULL * 60 * 60 * 24 * 30) * 12);

	stST->wMonth        = static_cast<USHORT>(ullMilliSec / ((1000ULL * 60 * 60 * 24) * 30));
	ullMilliSec        %= ((1000ULL * 60 * 60 * 24) * 30);

	stST->wDay          = static_cast<USHORT>(ullMilliSec / ((1000ULL * 60 * 60) * 24));
	ullMilliSec        %= ((1000ULL * 60 * 60) * 24);

	stST->wHour         = static_cast<USHORT>(ullMilliSec / ((1000ULL * 60) * 60));
	ullMilliSec        %= ((1000ULL * 60) * 60);

	stST->wMinute 	    = static_cast<USHORT>(ullMilliSec / ((1000ULL * 60)));
	ullMilliSec	       %= ((1000ULL * 60));

	stST->wSecond	    = static_cast<USHORT>(ullMilliSec / 1000ULL);
	ullMilliSec        %= 1000ULL;

	stST->wMilliseconds = static_cast<USHORT>(ullMilliSec);

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + ullDateTimeToMSec ()
/*static*/
ULONGLONG CXDateTime::ullDateTimeToMSec(const SYSTEMTIME &stST) { 
	/*DEBUG*/

	ULONGLONG ullRes = 0/*ULL*/;

	ullRes += stST.wYear         * 1000ULL * 60 * 60 * 24 * 30 * 12;
	ullRes += stST.wMonth        * 1000ULL * 60 * 60 * 24 * 30;
	ullRes += stST.wDay          * 1000ULL * 60 * 60 * 24;
	ullRes += stST.wHour         * 1000ULL * 60 * 60; 
	ullRes += stST.wMinute       * 1000ULL * 60;
	ullRes += stST.wSecond       * 1000ULL * 1;
	ullRes += stST.wMilliseconds * 1;

	return ullRes;
}
//--------------------------------------------------------------------------


