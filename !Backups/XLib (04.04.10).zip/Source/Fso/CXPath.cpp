/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXPath.h>



/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - sGetExe
/*static*/
tstring CXPath::sGetExe() {
	TCHAR szRes[MAX_PATH + 1] = {0};
	
	ULONG ulStored = ::GetModuleFileName(NULL, szRes, MAX_PATH);
	/*DEBUG*/xASSERT_RET(0        != ulStored, tstring());
	/*DEBUG*/xASSERT_RET(NULL     != szRes,    tstring());        
	/*DEBUG*/xASSERT_RET(_T('\0') != *szRes,   tstring());    

	return tstring(szRes, ulStored);	
}
//---------------------------------------------------------------------------
//TODO: - sGetExeDir
/*static*/
tstring CXPath::sGetExeDir() {
	return sGetDir(sGetExe());
}
//---------------------------------------------------------------------------
//TODO: - sGetDrive (����)
/*static*/
tstring CXPath::sGetDrive(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiDriveDelimPos = csFilePath.find(xDRIVE_DELIM);
	xASSERT_RET(tstring::npos != uiDriveDelimPos, tstring());
	xASSERT_RET(1             == uiDriveDelimPos, tstring());

	return csFilePath.substr(0, uiDriveDelimPos + xDRIVE_DELIM.size());
}
//--------------------------------------------------------------------------
//TODO: - sGetDir (Returns the path, without a trailing backslash '\')
/*static*/
tstring CXPath::sGetDir(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	//*DEBUG*/// n/a
	xASSERT_RET(tstring::npos != uiSlashPos, tstring());

	return csFilePath.substr(0, uiSlashPos);
}
//---------------------------------------------------------------------------
//TODO: - sGetFullName (��� + ���������)
/*static*/
tstring CXPath::sGetFullName(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tstring::npos != uiSlashPos, tstring());

	return csFilePath.substr(uiSlashPos + xWIN_SLASH.size(), csFilePath.size());
}
//--------------------------------------------------------------------------
//TODO: - sGetName (���)
/*static*/
tstring CXPath::sGetName(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiSlashPos = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tstring::npos != uiSlashPos, tstring());

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tstring::npos != uiDotPos, tstring());

	return CXString::sCut(csFilePath, uiSlashPos + xWIN_SLASH.size(), uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: - sGetExt (���������� ��� �����)
/*static*/
tstring CXPath::sGetExt(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/// ???????????

	return csFilePath.substr(uiDotPos + xDOT.size());
}
//--------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: - sSetDrive ()
/*static*/
tstring CXPath::sSetDrive(const tstring &csFilePath, const tstring &csDrivePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// csDrivePath

	tstring sRes;
	sRes.assign(csFilePath);

	tstring sDrive = sGetDrive(sRes);
	xASSERT_RET(false == sDrive.empty(), tstring());

	std::size_t uiPos = sRes.find(sDrive);
	xASSERT_RET(tstring::npos != uiPos, tstring());

	return sRes.replace(uiPos, sDrive.size(), csDrivePath);
}
//---------------------------------------------------------------------------
//TODO: - sSetDir ()
/*static*/
tstring CXPath::sSetDir(const tstring &csFilePath, const tstring &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// csDirPath

	tstring sRes;
	sRes.assign(csFilePath);

	tstring sDir = sGetDir(sRes);
	xASSERT_RET(false == sDir.empty(), tstring());

	std::size_t uiPos = sRes.find(sDir);
	xASSERT_RET(tstring::npos != uiPos, tstring());

	return sRes.replace(uiPos, sDir.size(), sRemoveSlash(csDirPath));
}
//---------------------------------------------------------------------------
//TODO: - sSetFullName ()
/*static*/
tstring CXPath::sSetFullName(const tstring &csFilePath, const tstring &csFullName) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// csFullName

	tstring sRes;
	sRes.assign(csFilePath);

	tstring sFullName = sGetFullName(sRes);
	xASSERT_RET(false == sFullName.empty(), tstring());

	std::size_t uiPos = sRes.rfind(sFullName);
	xASSERT_RET(tstring::npos != uiPos, tstring());

	return sRes.replace(uiPos, sFullName.size(), csFullName);
}
//---------------------------------------------------------------------------
//TODO: - sSetName ()
/*static*/
tstring CXPath::sSetName(const tstring &csFilePath, const tstring &csName) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring());
	/*DEBUG*/// csName

	tstring sRes;
	sRes.assign(csFilePath);

	tstring sName = sGetName(sRes);
	xASSERT_RET(false == sName.empty(), tstring());

	std::size_t uiPos = sRes.rfind(sName);
	xASSERT_RET(tstring::npos != uiPos, tstring());

	return sRes.replace(uiPos, sName.size(), csName);
}
//---------------------------------------------------------------------------
//TODO: - sSetExt
/*static*/
tstring CXPath::sSetExt(const tstring &csFilePath, const tstring &csExt) {	
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// csExt - n/a 

	tstring sRes;
	sRes.assign(csFilePath);

	tstring sExt = sGetExt(sRes);
	xASSERT_RET(false == sExt.empty(), tstring());

	std::size_t uiPos = sRes.rfind(sExt);
	xASSERT_RET(tstring::npos != uiPos, tstring());

	return sRes.replace(uiPos, sExt.size(), csExt);
}
//---------------------------------------------------------------------------


//--------------------------------------------------------------------------
//TODO: + sRemoveExt
/*static*/
tstring CXPath::sRemoveExt(const tstring &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/// n/a

	return csFilePath.substr(0, uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: + sRemoveExtIf
/*static*/
tstring CXPath::sRemoveExtIf(const tstring &csFilePath, const tstring &csExt) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 

	//���� ��� ������ ����������, �� ���������� �������� ������
	std::size_t uiExtPos = csFilePath.rfind(xDOT + csExt, csFilePath.size());
	xCHECK_RET(tstring::npos == uiExtPos, csFilePath);

	std::size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());
	/*DEBUG*/xASSERT_RET(tstring::npos != uiDotPos, tstring());

	return csFilePath.substr(0, uiDotPos);
}
//---------------------------------------------------------------------------
//TODO: + sSetValidName
/*static*/
tstring CXPath::sSetValidName(const tstring &csFileName) {
	/*DEBUG*/// n/a

	tstring sRes;
	sRes.assign(csFileName);

	//-------------------------------------
	//��� ����� �� ������ ������
	xCHECK_RET(true == sRes.empty(), tstring());

	//-------------------------------------
	//��� ����� �� ������ 255 ��������
	xCHECK_RET(255/*ciFileNameMaxSize*/ <= sRes.size(), tstring());

	//-------------------------------------
	//��� ����� �� ����� �������� ������ �� ����� �����
	std::size_t uiDotPos = sRes.find_first_not_of(xDOT);
	xCHECK_RET(tstring::npos == uiDotPos, tstring());

	//-------------------------------------
	//������ ������ - �� �����  	// if the first character is a dot, the filename is okay or space
	xCHECK_RET(xDOT.at(0) == sRes.at(0), tstring()); 

	//-------------------------------------
	//A device name was used. You can pass this value to GetIsValidFileNameErrStr to obtain a pointer to the name of this device.


	//-------------------------------------
	//All characters greater than ASCII 31 to be used except for the following:    "/*:<>?\|
	const tstring csFatalChars = _T("\\/:*<>|?\"\t\n\r");

	std::size_t uiFound = sRes.find_first_of(csFatalChars);
	while (tstring::npos != uiFound) 	{
		sRes.erase(uiFound, 1);
		uiFound = sRes.find_first_of(csFatalChars, uiFound);
	}

	//-------------------------------------
	//The following device names cannot be used for a file name nor may they
	//be used for the first segment of a file name (that part which precedes the  first dot):
	//CLOCK$, AUX, CON, NUL, PRN, COM1, COM2, COM3, COM4, COM5, COM6, COM7, COM8,
	//COM9, LPT1, LPT2, LPT3, LPT4, LPT5, LPT6, LPT7, LPT8, LPT9
	//Device names are case insensitve. aux, AUX, Aux, etc. are identical.

	const tstring csReserved[] = { 
		_T("CON"),  _T("PRN"),  _T("AUX"),  _T("CLOCK$"), _T("NUL"),
		_T("COM0"), _T("COM1"), _T("COM2"), _T("COM3"),   _T("COM4"), _T("COM5"), _T("COM6"), _T("COM7"), _T("COM8"), _T("COM9"),
		_T("LPT0"), _T("LPT1"), _T("LPT2"), _T("LPT3"),   _T("LPT4"), _T("LPT5"), _T("LPT6"), _T("LPT7"), _T("LPT8"), _T("LPT9") 
	};

	tstring sFileName = sRemoveExt(sRes);

	for (std::size_t i = 0; i < xARRAY_SIZE(csReserved); ++ i) {
		xCHECK_RET(TRUE == CXString::bCompareNoCase(sFileName, csReserved[i]), tstring());
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: - sToWin
/*static*/
tstring CXPath::sToWin(const tstring &csFilePath, BOOL bIsSlashAtEnd) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// bIsSlashAtEnd - n/a 

	tstring sRes;

	if (TRUE == bIsSlashAtEnd) {
		sRes = sAppendSlash(csFilePath);
	} else {
		sRes = sRemoveSlash(csFilePath);
	}

	sRes = CXString::sReplaceAll(sRes, xNIX_SLASH, xWIN_SLASH);

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: - sToNix
/*static*/
tstring CXPath::sToNix(const tstring &csFilePath, BOOL bIsSlashAtEnd) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring()); 
	/*DEBUG*/// bIsSlashAtEnd - n/a 

	tstring sRes;

	if (TRUE == bIsSlashAtEnd) {
		sRes = sAppendSlash(csFilePath);
	} else {
		sRes = sRemoveSlash(csFilePath);
	}

	sRes = CXString::sReplaceAll(sRes, xWIN_SLASH, xNIX_SLASH);

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: - sMinimizeName 
/*static*/
tstring CXPath::sMinimizeName(const tstring &csFileName, const std::size_t cuiMaxSize) {	
	/*DEBUG*/xASSERT_RET(false == csFileName.empty(),          tstring());
	/*DEBUG*///xASSERT_RET(false == sGetExt(csFileName).empty(), tstring());
	/*DEBUG*/xASSERT_RET(0 < cuiMaxSize,                       tstring());

	tstring     sRes;
	tstring     sTildaDotExt      = _T("~") + xDOT + sGetExt(csFileName);
	std::size_t uiTildaDotExtSize = sTildaDotExt.size();

	if (csFileName.size() > cuiMaxSize) {
		if (cuiMaxSize < uiTildaDotExtSize) {
			sRes = csFileName.substr(0, cuiMaxSize);
		} else {
			sRes = csFileName.substr(0, cuiMaxSize - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csFileName;
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: - sMinimize
/*static*/
tstring CXPath::sMinimize(const tstring &csFilePath, const size_t cuiMaxSize) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), tstring());
	/*DEBUG*/xASSERT_RET(0 < cuiMaxSize,              tstring());

	tstring sRes;
	sRes.assign(csFilePath);	

	tstring sDrive = sGetDrive(sRes);										//D:
	tstring sDir   = sGetDir(sRes).erase(0, sDrive.size()) + xWIN_SLASH;	//\XLib\Test\CXString\Project\Debug\ 
	tstring sName  = sGetFullName(sRes);									//Test.exe

	while (((false == sDir.empty()) || (false == sDrive.empty())) && (sRes.size() > cuiMaxSize)) { 
		if ((xWIN_SLASH + _T("...") + xWIN_SLASH) == sDir ) {
			sDrive.clear();
			sDir = _T("...") + xWIN_SLASH;
		} 
		else if (true == sDir.empty()) {
			sDrive.clear();
		} 
		else {
			BOOL        bRoot = FALSE;
			std::size_t uiPos = tstring::npos;

			if (xWIN_SLASH == sDir) {
				sDir.clear();
			} 
			else {
				if (sDir.at(0) == xWIN_SLASH.at(0)  /*_T('\\')*/) {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = FALSE;
				}

				if (/*_T('.')*/xDOT.at(0) == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//uiPos = AnsiPos("\\", S); 
				uiPos = sDir.find_first_of(xWIN_SLASH);		//-- uiPos = sDir.find_first_of(xWIN_SLASH) + 1;
				if (tstring::npos == uiPos) {
					sDir.clear();
				} else {
					//Delete(S, 1, uiPos); - c ������� 1(0) uiPos ��������
					sDir.erase(0, uiPos + xWIN_SLASH.size()/*1*/);				//-- sDir.erase(0, uiPos);
					sDir = _T("...") + xWIN_SLASH + sDir; 
				}

				if (TRUE == bRoot) {
					sDir = xWIN_SLASH + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO:  - sAppendSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
/*static*/
tstring CXPath::sAppendSlash(const tstring &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(), tstring()); 

	if (xWIN_SLASH.at(0) == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	} else {
		return csDirPath + xWIN_SLASH;
	}
}
//--------------------------------------------------------------------------
//TODO: -  sRemoveSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
/*static*/
tstring CXPath::sRemoveSlash(const tstring &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(), tstring()); 

	const std::size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if (xWIN_SLASH.at(0) == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	} else {
		return csDirPath;
	}
}
//--------------------------------------------------------------------------




/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXPath
CXPath::CXPath() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXPath
CXPath::~CXPath() {
	//code
}
//---------------------------------------------------------------------------


/*
CommandLineToArgvA
    PCHAR*
    CommandLineToArgvA(
        PCHAR CmdLine,
        int* _argc
        )
    {
        PCHAR* argv;
        PCHAR  _argv;
        ULONG   len;
        ULONG   argc;
        CHAR   a;
        ULONG   i, j;

        BOOLEAN  in_QM;
        BOOLEAN  in_TEXT;
        BOOLEAN  in_SPACE;

        len = strlen(CmdLine);
        i = ((len+2)/2)*sizeof(PVOID) + sizeof(PVOID);

        argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
            i + (len+2)*sizeof(CHAR));

        _argv = (PCHAR)(((PUCHAR)argv)+i);

        argc = 0;
        argv[argc] = _argv;
        in_QM = FALSE;
        in_TEXT = FALSE;
        in_SPACE = TRUE;
        i = 0;
        j = 0;

        while( a = CmdLine[i] ) {
            if(in_QM) {
                if(a == '\"') {
                    in_QM = FALSE;
                } else {
                    _argv[j] = a;
                    j++;
                }
            } else {
                switch(a) {
                case '\"':
                    in_QM = TRUE;
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    in_SPACE = FALSE;
                    break;
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    if(in_TEXT) {
                        _argv[j] = '\0';
                        j++;
                    }
                    in_TEXT = FALSE;
                    in_SPACE = TRUE;
                    break;
                default:
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    _argv[j] = a;
                    j++;
                    in_SPACE = FALSE;
                    break;
                }
            }
            i++;
        }
        _argv[j] = '\0';
        argv[argc] = NULL;

        (*_argc) = argc;
        return argv;
    }
*/

/*

 String
   FileUtilities::GetShortPath(const String &sInPath)
   {
      TCHAR szModuleShort[_MAX_PATH];
      GetShortPathName(sInPath, szModuleShort, _MAX_PATH );

      return szModuleShort;
   }

   String
   FileUtilities::GetLongPath(const String &sInPath)
   {
      TCHAR szLong[_MAX_PATH];
      GetLongPathName(sInPath, szLong, _MAX_PATH );

      return szLong;
   }




//--------------------------------------------------------------------------
*/