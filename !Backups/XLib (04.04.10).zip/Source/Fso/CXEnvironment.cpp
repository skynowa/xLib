/****************************************************************************
* Class name:  CXEnvironment
* Description: ���������� ���������
* File name:   CXEnvironment.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.04.2010 17:43:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXEnvironment.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - sGetVar
/*static*/
tstring CXEnvironment::sGetVar(const tstring &csVar) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), tstring()); 

	tstring sRes(MAX_PATH, _T('\0'));
	ULONG   ulStored = 0;

	//not including the terminating null character
	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/xASSERT_RET(0 != ulStored, tstring()); 

	sRes.resize(ulStored);

	if (sRes.size() < ulStored) {
		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/xASSERT_RET(0 != ulStored, tstring());
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: - bSetVar
/*static*/
BOOL CXEnvironment::bSetVar(const tstring &csVar, const tstring &csValue) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csVar.c_str(), csValue.c_str());
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: - bGetStrings
/*static*/
BOOL CXEnvironment::bGetStrings(std::vector<tstring> *pvecsEnvStrings) {
	/*DEBUG*/xASSERT_RET(NULL != pvecsEnvStrings, FALSE); 

	BOOL   bRes   = FALSE;
	LPTSTR pszVar = NULL; 
	LPTCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/xASSERT_RET(NULL != lpvEnv, FALSE); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPTSTR)lpvEnv;

	pvecsEnvStrings->clear();

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		pvecsEnvStrings->push_back(tstring(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: - sExpandStrings
/*static*/
tstring CXEnvironment::sExpandStrings(const tstring &csVar) {
	/*DEBUG*/xASSERT_RET(false == csVar.empty(), tstring()); 

	ULONG       ulStored = FALSE;
	tstring sRes(MAX_PATH, _T('\0'));

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/xASSERT_RET(0 != ulStored, tstring()); 

	sRes.resize(ulStored);	

	if (sRes.size() < ulStored) {
		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/xASSERT_RET(0 != ulStored, tstring());
	}

	sRes.resize(ulStored - 1);	//������� '\0', including the terminating null character

	return sRes;
}
//--------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXEnvironment (comment)
CXEnvironment::CXEnvironment() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXEnvironment (comment)
CXEnvironment::~CXEnvironment() {
	//code
}
//---------------------------------------------------------------------------