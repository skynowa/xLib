/****************************************************************************
* Class name:  CXDrive
* Description: �������� � �������
* File name:   CXDrive.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:25:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXDrive.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXDir.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + bIsReady (���������� ���������� �����)
/*static*/
BOOL CXDrive::bIsReady(const tstring &csDrivePath) {
	/*DEBUG*/xASSERT_RET(false == csDrivePath.empty(), FALSE);

	BOOL    bRes           = FALSE;
	UINT    uiOldErrorMode = 0;
	tstring sOldDirectory;

	uiOldErrorMode = ::SetErrorMode(SEM_FAILCRITICALERRORS /*SEM_NOOPENFILEERRORBOX*/);
	sOldDirectory  = CXDir::sGetCurrent();

	//-------------------------------------
	//�������� ����� �� ��������� ����
	ULONG ulRes = ::SetCurrentDirectory(CXPath::sAppendSlash(csDrivePath).c_str());
	if (0 == ulRes) {  // 0 - error
		bRes = FALSE;
	} else {
		bRes = TRUE;
	}

	CXDir::bSetCurrent(sOldDirectory);
	::SetErrorMode(uiOldErrorMode);

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: + bIsEmpty (���� �� ����)
/*static*/
BOOL CXDrive::bIsEmpty(const tstring &csDrivePath) {
	/*DEBUG*/xASSERT_RET(false == csDrivePath.empty(), FALSE);

	BOOL            bRes       = TRUE;
	HANDLE          hFile      = INVALID_HANDLE_VALUE; 
	WIN32_FIND_DATA stFindData = {0};   

	hFile = ::FindFirstFile((CXPath::sAppendSlash(csDrivePath) + xALL_FILES_MASK).c_str(), &stFindData);   
	xCHECK_RET(INVALID_HANDLE_VALUE == hFile, TRUE);

	bRes = ::FindClose(hFile); 
	/*DEBUG*/xASSERT_RET(FALSE != bRes, TRUE); 

	return FALSE;   
}
//--------------------------------------------------------------------------
//TODO: + bDefineDosDevice (Defines, redefines, or deletes MS-DOS device names.)
/*static*/
BOOL CXDrive::bDefineDosDevice(ULONG ulFlags, const tstring &csDeviceName, const tstring &csTargetPath) {
	/*DEBUG*/xASSERT_RET(false == csDeviceName.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csTargetPath.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::DefineDosDevice(ulFlags, csDeviceName.c_str(), csTargetPath.c_str());
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;   
}
//--------------------------------------------------------------------------
//TODO: + bDeleteVolumeMountPoint (Deletes a drive letter or mounted folder.)
/*static*/
BOOL CXDrive::bDeleteVolumeMountPoint(const tstring &csVolumeMountPoint) {
	/*DEBUG*/xASSERT_RET(false == csVolumeMountPoint.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::DeleteVolumeMountPoint(csVolumeMountPoint.c_str());
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;  
}
//--------------------------------------------------------------------------
//TODO: + hFindFirstVolume (Retrieves the name of a volume on a computer)
/*static*/
HANDLE CXDrive::hFindFirstVolume(tstring *psVolumeName) {
	/*DEBUG*/xASSERT_RET(NULL != psVolumeName, INVALID_HANDLE_VALUE);
	
	HANDLE hRes = INVALID_HANDLE_VALUE;

	psVolumeName->clear();
	psVolumeName->resize(MAX_PATH);

	hRes = ::FindFirstVolume(&(*psVolumeName)[0], psVolumeName->size());
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hRes, INVALID_HANDLE_VALUE); 

	return hRes;
}
//--------------------------------------------------------------------------
//TODO: + hFindFirstVolumeMountPoint (Retrieves the name of a mounted folder on the specified volume)
/*static*/
HANDLE CXDrive::hFindFirstVolumeMountPoint(const tstring &csRootPathName, tstring *psVolumeMountPoint) {
	/*DEBUG*/xASSERT_RET(false == csRootPathName.empty(), INVALID_HANDLE_VALUE);
	/*DEBUG*/xASSERT_RET(NULL != psVolumeMountPoint,      INVALID_HANDLE_VALUE);

	HANDLE hRes = INVALID_HANDLE_VALUE;

	psVolumeMountPoint->clear();
	psVolumeMountPoint->resize(MAX_PATH);

	hRes = ::FindFirstVolumeMountPoint(csRootPathName.c_str(), &(*psVolumeMountPoint)[0], psVolumeMountPoint->size());
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hRes, INVALID_HANDLE_VALUE); 

	return hRes;
}
//--------------------------------------------------------------------------
//TODO: + sFindNextVolume (Continues a volume search started by a call to the FindFirstVolume function.)
/*static*/
tstring CXDrive::sFindNextVolume(HANDLE hFindVolume) {
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hFindVolume, tstring());

	BOOL        bRes                          = FALSE;
	const ULONG culBuffSize                   = MAX_PATH;
	TCHAR       szVolumeName[culBuffSize + 1] = {0};

	bRes = ::FindNextVolume(hFindVolume, &szVolumeName[0], culBuffSize);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, tstring()); 

	return tstring(szVolumeName); 
}
//--------------------------------------------------------------------------
//TODO: + bFindNextVolumeMountPoint (Continues a mounted folder search started by a call to the FindFirstVolumeMountPoint function)
/*static*/
BOOL CXDrive::bFindNextVolumeMountPoint(HANDLE hFindVolumeMountPoint, tstring *psVolumeMountPoint) {
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hFindVolumeMountPoint, FALSE);
	/*DEBUG*/xASSERT_RET(NULL != psVolumeMountPoint,                    FALSE);

	BOOL bRes = FALSE;

	psVolumeMountPoint->clear();
	psVolumeMountPoint->resize(MAX_PATH);

	bRes = ::FindNextVolumeMountPoint(hFindVolumeMountPoint, &(*psVolumeMountPoint)[0], psVolumeMountPoint->size());
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;  
}
//--------------------------------------------------------------------------
//TODO: + bFindVolumeClose (Closes the specified volume search handle)
/*static*/
BOOL CXDrive::bFindVolumeClose(HANDLE hFindVolume) {
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hFindVolume, FALSE);

	BOOL bRes = FALSE;

	bRes = ::FindVolumeClose(hFindVolume);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE; 
}
//--------------------------------------------------------------------------
//TODO: + bFindVolumeMountPointClose (Closes the specified mounted folder search handle)
/*static*/
BOOL CXDrive::bFindVolumeMountPointClose(HANDLE hFindVolumeMountPoint) {
	/*DEBUG*/xASSERT_RET(INVALID_HANDLE_VALUE != hFindVolumeMountPoint, FALSE);

	BOOL bRes = FALSE;

	bRes = ::FindVolumeMountPointClose(hFindVolumeMountPoint);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE; 
}
//--------------------------------------------------------------------------
//TODO: + bGetFreeSpace (���������� � ������� �����)
/*static*/
BOOL CXDrive::bGetFreeSpace(const tstring &csDirPath, ULONGLONG *pullFreeBytesAvailable, ULONGLONG *pullTotalBytes, ULONGLONG *pullTotalFreeBytes) {			   
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;

	ULARGE_INTEGER ullFreeBytesAvailable = {0}; 
	ULARGE_INTEGER ullTotalBytes         = {0}; 
	ULARGE_INTEGER ullTotalFreeBytes	 = {0};		   
	
	bRes = ::GetDiskFreeSpaceEx(csDirPath.c_str(), &ullFreeBytesAvailable, &ullTotalBytes, &ullTotalFreeBytes);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	*pullFreeBytesAvailable = ullFreeBytesAvailable.QuadPart;
	*pullTotalBytes         = ullTotalBytes.QuadPart;
	*pullTotalFreeBytes     = ullTotalFreeBytes.QuadPart;			   

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + dtGetType (��� �����)
/*static*/
CXDrive::EType CXDrive::dtGetType(const tstring &csDrivePath) {
	/*DEBUG*/xASSERT_RET(false == csDrivePath.empty(), dtUnknown);  
	
	return static_cast<EType>( ::GetDriveType(CXPath::sAppendSlash(csDrivePath).c_str()) );
	/*DEBUG*/// n/a
}
//--------------------------------------------------------------------------
//TODO: + bGetLogicalDrives (������ ���� ��������� ������)
/*static*/
BOOL CXDrive::bGetLogicalDrives(std::vector<tstring> *pvecsDrives) {
	/*DEBUG*/xASSERT_RET(NULL != pvecsDrives, FALSE);

	ULONG ulDrives = 0;		//bGetLogicalDrives +++++++++
		
	ulDrives = ::GetLogicalDrives();
	/*DEBUG*/xASSERT_RET(0 != ulDrives, FALSE);

	pvecsDrives->clear();
	for (INT i = 0; i < 26; ++ i) {
		if (1 == ((ulDrives >> i) & 0x00000001)) {
			tstring sDrivePath;

			sDrivePath.push_back(static_cast<TCHAR>(65 + i)); 
			sDrivePath.append(xDRIVE_DELIM);

			pvecsDrives->push_back(sDrivePath);
		}
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bGetLogicalDrives (������ ���� ��������� ������ �� ����)
/*static*/
BOOL CXDrive::bGetLogicalDrives(std::vector<tstring> *vecsDrives, EType dtDriveType) {
	/*DEBUG*/xASSERT_RET(NULL != vecsDrives, FALSE);

	ULONG ulDrives = 0;

	ulDrives = ::GetLogicalDrives();
	/*DEBUG*/xASSERT_RET(0 != ulDrives, FALSE);

	vecsDrives->clear();
	for (INT i = 0; i < 26; ++ i) {
		if (1 == ((ulDrives >> i)&0x00000001)) {
			tstring sDrivePath;

			sDrivePath.push_back(static_cast<TCHAR>(65 + i)); 
			sDrivePath.append(xDRIVE_DELIM);      
			
			xCHECK_DO(dtDriveType != CXDrive::dtGetType(sDrivePath), continue);

			vecsDrives->push_back(sDrivePath);
		}
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + sGetLogicalStrings (Fills a buffer with strings that specify valid drives in the _tsystem.)
/*static*/  //FIXME
tstring CXDrive::sGetLogicalStrings() {
	tstring sRes;
	ULONG   ulRes = 0;

	ulRes = ::GetLogicalDriveStrings(0, NULL);
	/*DEBUG*/xASSERT_RET(0 != ulRes, tstring());

	sRes.resize(ulRes);

	ulRes = ::GetLogicalDriveStrings(sRes.size(), &sRes[0]);
	/*DEBUG*/xASSERT_RET(0 != ulRes, tstring());

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: + bGetInfo (���������� � �����)
/*static*/
BOOL CXDrive::bGetInfo(const tstring &csDrivePath,
					   tstring       *psVolumeName,
					   ULONG         *pulVolumeSerialNumber,
					   ULONG         *pulMaximumComponentLength,
					   ULONG         *pulFileSystemFlags,
					   tstring       *psFileSystemName)
{
	/*DEBUG*/xASSERT_RET(false == csDrivePath.empty(), FALSE); 
	/*DEBUG*/// psVolumeName              - n/a
	/*DEBUG*/// pulVolumeSerialNumber     - n/a
	/*DEBUG*/// pulMaximumComponentLength - n/a
	/*DEBUG*/// pulFileSystemFlags        - n/a
	/*DEBUG*/// psFileSystemName          - n/a

	BOOL bRes = FALSE; 

	if (NULL != psVolumeName) {
		(*psVolumeName).clear();
		(*psVolumeName).resize(MAX_PATH + 1);
	}

	if (NULL != psFileSystemName) {
		(*psFileSystemName).clear();
		(*psFileSystemName).resize(MAX_PATH + 1);
	}
	
	bRes = ::GetVolumeInformation(
				        CXPath::sAppendSlash(csDrivePath).c_str(), 
						(NULL == psVolumeName)     ? (NULL) :  &(*psVolumeName).at(0), 
						(NULL == psVolumeName)     ? (NULL) :   (*psVolumeName).size(), 
						pulVolumeSerialNumber,                
						pulMaximumComponentLength, 
						pulFileSystemFlags, 
						(NULL == psFileSystemName) ? (NULL) : &(*psFileSystemName).at(0),            
						(NULL == psFileSystemName) ? (NULL) :  (*psFileSystemName).size()
	);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + sGetVolumeNameForVolumeMountPoint (Retrieves a volume GUID path for the volume that is associated with the specified volume mount point (drive letter, volume GUID path, or mounted folder)
/*static*/
tstring CXDrive::sGetVolumeNameForVolumeMountPoint(const tstring &csVolumeMountPoint) {
	/*DEBUG*/xASSERT_RET(false == csVolumeMountPoint.empty(), tstring());

	TCHAR szRes[50 + 1] = {0};
	BOOL  bRes          = FALSE;

	bRes = ::GetVolumeNameForVolumeMountPoint(CXPath::sAppendSlash(csVolumeMountPoint).c_str(), &szRes[0], MAX_PATH);
	/*DEBUG*/////xASSERT_RET(FALSE != bRes, tstring());
	xCHECK_RET(FALSE == bRes, tstring()); 

	return tstring(szRes);
} 
//--------------------------------------------------------------------------
//TODO: + sGetVolumePathName (Retrieves the volume mount point where the specified path is mounted.)
/*static*/
tstring CXDrive::sGetVolumePathName(const tstring &csFileName) {
	/*DEBUG*/xASSERT_RET(false == csFileName.empty(), tstring());

	BOOL        bRes                               = FALSE;
	const ULONG culBuffSize                        = MAX_PATH;
	TCHAR        szVolumePathName[culBuffSize + 1] = {0};

	bRes = ::GetVolumePathName(csFileName.c_str(), &szVolumePathName[0], culBuffSize);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, tstring());

	return tstring(szVolumePathName);
}
//--------------------------------------------------------------------------
//TODO: + sGetVolumePathNamesForVolumeName (Retrieves a list of drive letters and volume GUID paths for the specified volume.)
/*static*/
tstring CXDrive::sGetVolumePathNamesForVolumeName(const tstring &csVolumeName) {
	/*DEBUG*/xASSERT_RET(false == csVolumeName.empty(), tstring());

	BOOL        bRes                           = FALSE;
	const ULONG culBuffSize                    = MAX_PATH;
	tstring     sVolumePathNames(culBuffSize, 0);
	ULONG       ulReturnLength                 = 0;
	ULONG       ulLastError                    = 0;

//	bRes        = ::GetVolumePathNamesForVolumeName(csVolumeName.c_str(), &sVolumePathNames[0], culBuffSize, &ulReturnLength);
//	ulLastError = ::GetLastError();
//	if (FALSE == bRes && ERROR_MORE_DATA == ulLastError) {
//		sVolumePathNames.resize(ulReturnLength);
//		bRes        = ::GetVolumePathNamesForVolumeName(csVolumeName.c_str(), &sVolumePathNames[0], culBuffSize, &ulReturnLength);
//		ulLastError = ::GetLastError();
//	}
//	/*DEBUG*/xASSERT_RET(FALSE != bRes && ulLastError != ERROR_MORE_DATA, tstring());

	return tstring(sVolumePathNames, ulReturnLength);
}
//--------------------------------------------------------------------------
//TODO: + sQueryDosDevice (Retrieves information about MS-DOS device names)
/*static*/
tstring CXDrive::sQueryDosDevice(const tstring &csDeviceName) {
	/*DEBUG*/xASSERT_RET(false == csDeviceName.empty(), tstring());

	ULONG       ulRes                     = 0;
	const ULONG culMax                    = MAX_PATH;
	TCHAR        szTargetPath[culMax + 1] = {0};
	ULONG       ulLastError               = 0;
	
	ulRes       = ::QueryDosDevice(csDeviceName.c_str(), &szTargetPath[0], culMax);
	ulLastError = ::GetLastError();
	/*DEBUG*/xASSERT_RET(0 != ulRes && ERROR_INSUFFICIENT_BUFFER != ulLastError, tstring()); 

	return tstring(szTargetPath, ulRes);
}
//--------------------------------------------------------------------------
//TODO: + bSetVolumeLabel (Sets the label of a file _tsystem volume.)
/*static*/
BOOL CXDrive::bSetVolumeLabel(const tstring &csRootPathName, const tstring &cslpVolumeName) {
	/*DEBUG*/xASSERT_RET(false == csRootPathName.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == cslpVolumeName.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetVolumeLabel(csRootPathName.c_str(), cslpVolumeName.c_str()); 
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bSetVolumeMountPoint (Associates a volume with a drive letter or a directory on another volume.)
/*static*/
BOOL CXDrive::bSetVolumeMountPoint(const tstring &csVolumeMountPoint, const tstring &csVolumeName) {
	/*DEBUG*/xASSERT_RET(false == csVolumeMountPoint.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csVolumeName.empty(),       FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetVolumeMountPoint(csVolumeMountPoint.c_str(), csVolumeName.c_str()); 
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: +
CXDrive::CXDrive() {
	//code
}
//---------------------------------------------------------------------------
//TODO: +
CXDrive::~CXDrive() {
	//code
}
//---------------------------------------------------------------------------