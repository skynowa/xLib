/****************************************************************************
* Class name:  CXDll
* Description: DLL
* File name:   CXDll.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Fso/CXDll.h>

//---------------------------------------------------------------------------
//TODO: + CXDll 
CXDll::CXDll() :
    _m_hDLL(NULL)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CXDll 
CXDll::~CXDll() {
	bFree();
}
//---------------------------------------------------------------------------
//TODO: + bIsLoaded
BOOL CXDll::bIsLoaded() {
	/*DEBUG*///not need

	return _m_hDLL != NULL;
}
//---------------------------------------------------------------------------
//TODO: + bLoad 
BOOL CXDll::bLoad(LPCTSTR pszDllPath) {
	/*DEBUG*///not need
	/*DEBUG*/xASSERT_RET(NULL != pszDllPath, FALSE);

	BOOL bRes = FALSE; 
	
	bRes = bFree();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	_m_hDLL = ::LoadLibrary(pszDllPath);
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + fpGetProcAddress
FARPROC CXDll::fpGetProcAddress(LPCSTR pszProcName) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, NULL);

	FARPROC fpRes = NULL;

	fpRes = ::GetProcAddress(_m_hDLL, pszProcName);
	/*DEBUG*/xASSERT_RET(NULL != fpRes, NULL);

	return fpRes;
}
//---------------------------------------------------------------------------
//TODO: + bFree 
BOOL CXDll::bFree() {
	/*DEBUG*///not need

	BOOL bRes = FALSE; 
	
	xCHECK_RET(FALSE == bIsLoaded(), TRUE);

	bRes = ::FreeLibrary(_m_hDLL);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	
	_m_hDLL = NULL;	

	return TRUE;
}
//---------------------------------------------------------------------------