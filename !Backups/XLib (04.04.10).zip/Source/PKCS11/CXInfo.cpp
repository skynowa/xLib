/****************************************************************************
* Class name:  CXInfo
* Description: PKCS11 ����������
* File name:   CXInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:08:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXInfo.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXInfo ()
CXInfo::CXInfo(const CXPKCS11 &cPKCS11) :
	_m_bRes (FALSE),
	_m_ulRes(!CKR_OK),
	_m_pFunc(cPKCS11.pGetFuncList())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXInfo ()
CXInfo::~CXInfo() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bGet (returns general information about Cryptoki)
BOOL CXInfo::bGet(
	CK_INFO_PTR pInfo  /* location that receives information */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetInfo(pInfo); 
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetToken (obtains information about a particular token in the system)
BOOL CXInfo::bGetToken(
	CK_SLOT_ID        slotID,  /* ID of the token's slot */
	CK_TOKEN_INFO_PTR pInfo    /* receives the token information */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetTokenInfo(slotID, pInfo); 
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
