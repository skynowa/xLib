/****************************************************************************
* Class name:  CXDigest
* Description: PKCS11 �����������
* File name:   CXDigest.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:12:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXDigest.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXDigest ()
CXDigest::CXDigest(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes (FALSE),
	_m_ulRes(!CKR_OK),
	_m_pFunc(cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXDigest ()
CXDigest::~CXDigest() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bMake (digests data in a single part)
BOOL CXDigest::bMake(
	CK_BYTE_PTR       pData,        /* data to be digested */
	CK_ULONG          ulDataLen,    /* bytes of data to digest */
	CK_BYTE_PTR       pDigest,      /* gets the message digest */
	CK_ULONG_PTR      pulDigestLen  /* gets digest length */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_Digest(_m_hSession, pData, ulDataLen, pDigest, pulDigestLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bEncryptUpdate (continues a multiple-part digesting and encryption operation)
BOOL CXDigest::bEncryptUpdate(
	CK_BYTE_PTR       pPart,               /* the plaintext data */
	CK_ULONG          ulPartLen,           /* plaintext length */
	CK_BYTE_PTR       pEncryptedPart,      /* gets ciphertext */
	CK_ULONG_PTR      pulEncryptedPartLen  /* gets c-text length */)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DigestEncryptUpdate(_m_hSession, pPart, ulPartLen, pEncryptedPart, pulEncryptedPartLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}	
//---------------------------------------------------------------------------
//TODO: - bFinal (finishes a multiple-part message-digesting operation)
BOOL CXDigest::bFinal(
	CK_BYTE_PTR       pDigest,      /* gets the message digest */
	CK_ULONG_PTR      pulDigestLen  /* gets byte count of digest */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DigestFinal(_m_hSession, pDigest, pulDigestLen );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}	
//---------------------------------------------------------------------------
//TODO: - bInit (initializes a message-digesting operation)
BOOL CXDigest::bInit(
	CK_MECHANISM_PTR  pMechanism  /* the digesting mechanism */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DigestInit(_m_hSession,	pMechanism);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bKey (continues a multi-part message-digesting operation, by digesting the value of a secret key as part of the data already digested)
BOOL CXDigest::bKey(
	CK_OBJECT_HANDLE  hKey       /* secret key to digest */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DigestKey(_m_hSession, hKey );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bUpdate (continues a multiple-part message-digesting operation)
BOOL CXDigest::bUpdate(
	CK_BYTE_PTR       pPart,     /* data to be digested */
	CK_ULONG          ulPartLen  /* bytes of data to be digested */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DigestUpdate(_m_hSession, pPart, ulPartLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
