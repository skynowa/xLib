/****************************************************************************
* Class name:  CXVerify
* Description: PKCS11 �������� �������
* File name:   CXVerify.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:14:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXVerify.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXVerify ()
CXVerify::CXVerify(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXVerify ()
CXVerify::~CXVerify() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bInit (initializes a verification operation, where the signature is an appendix to the data, and plaintext cannot cannot be recovered from the signature (e.g. DSA))
BOOL CXVerify::bInit(
	CK_MECHANISM_PTR  pMechanism,  /* the verification mechanism */
	CK_OBJECT_HANDLE  hKey         /* verification key */ 
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_VerifyInit(_m_hSession, pMechanism, hKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}	
//---------------------------------------------------------------------------
//TODO: - bMake (verifies a signature in a single-part operation,  where the signature is an appendix to the data, and plaintext cannot be recovered from the signature)
BOOL CXVerify::bMake(
	CK_BYTE_PTR       pData,          /* signed data */
	CK_ULONG          ulDataLen,      /* length of signed data */
	CK_BYTE_PTR       pSignature,     /* signature */
	CK_ULONG          ulSignatureLen  /* signature length*/
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_Verify(_m_hSession, pData, ulDataLen, pSignature, ulSignatureLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bFinal (finishes a multiple-part verification operation, checking the signature)
BOOL CXVerify::bFinal(
	CK_BYTE_PTR       pSignature,     /* signature to verify */
	CK_ULONG          ulSignatureLen  /* signature length */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_VerifyFinal(_m_hSession, pSignature, ulSignatureLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bRecoverInit (initializes a signature verification operation, where the data is recovered from the signature)
BOOL CXVerify::bRecoverInit(
	CK_MECHANISM_PTR  pMechanism,  /* the verification mechanism */
	CK_OBJECT_HANDLE  hKey         /* verification key */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_VerifyRecoverInit(_m_hSession, pMechanism, hKey );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bVerifyRecover (verifies a signature in a single-part operation, where the data is recovered from the signature)
BOOL CXVerify::bRecover(
	CK_BYTE_PTR       pSignature,      /* signature to verify */
	CK_ULONG          ulSignatureLen,  /* signature length */
	CK_BYTE_PTR       pData,           /* gets signed data */
	CK_ULONG_PTR      pulDataLen       /* gets signed data len */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_VerifyRecover(_m_hSession, pSignature,ulSignatureLen, pData, pulDataLen );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bVerifyUpdate (continues a multiple-part verification operation, where the signature is an appendix to the data, and plaintext cannot be recovered from the signature)
BOOL CXVerify::bUpdate(
	CK_BYTE_PTR       pPart,     /* signed data */
	CK_ULONG          ulPartLen  /* length of signed data */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_VerifyUpdate(_m_hSession, pPart, ulPartLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------