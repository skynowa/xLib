/**********************************************************************
*	�����  CXConsole (CXConsole.h)
*
***********************************************************************/


#pragma once

#ifndef CXConsoleH
#define CXConsoleH      
//---------------------------------------------------------------------------
#define APP_NAME "Crypt ++"

#include <windows.h>
#include <string>
//---------------------------------------------------------------------------
class CXConsole {
	public:
			        CXConsole           ();
		            ~CXConsole          ();
		void        vSetLocale          (const std::string &csLocale);
		void        vSetTextColor       (unsigned int uiColor);
		bool        bEnableClose        (bool bFlag);
		std::string sGetTitle           ();
		bool        bSetTitle           (const std::string &csTitle);
		bool        bSetFullScreen      ();
		bool        bClearScreen        ();
		bool		bWriteLine		    (const std::string &csStr);
		bool        bWriteErrLine       (const std::string &csStr);
		std::string sReadLine           ();
		char        sReadChar           ();/*-*/

	private:
		HWND        m_hWnd;
		HMENU       m_hMenu;
		HANDLE      m_hStdIn;
		HANDLE      m_hStdOut;

		HWND        hGetConsoleWnd      (); 
		bool        bCenterWindow       ();
};
//---------------------------------------------------------------------------
#endif