/****************************************************************************
*    �����: CXSemaphore (CXSemaphore.h)
*
*****************************************************************************/


#include "CXSemaphore.h"
//---------------------------------------------------------------------------
CXSemaphore::CXSemaphore() {
	m_hSemaphore = NULL;
}
//---------------------------------------------------------------------------
CXSemaphore::CXSemaphore(PSECURITY_ATTRIBUTES lpsaAttributes = NULL, LONG nInitialCount = 1, LONG nMaxCount = 1, LPCSTR lpszName = NULL) {
	m_hSemaphore = NULL;
	
	BOOL bSuccess = FALSE; 
	bSuccess = bCreate(lpsaAttributes, nInitialCount, nMaxCount, lpszName);
	if (FALSE == bSuccess) {
		return;
	}
}
//---------------------------------------------------------------------------
CXSemaphore::~CXSemaphore() {
	if (NULL != m_hSemaphore) {
		::CloseHandle(m_hSemaphore);	m_hSemaphore = NULL;
	}
}
//---------------------------------------------------------------------------
HANDLE CXSemaphore::hGetHandle() {
	assert(NULL != m_hSemaphore);
    
    return m_hSemaphore;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG nInitialCount, LONG nMaxCount, LPCSTR lpszName) {
	m_hSemaphore = ::CreateSemaphore(lpsaAttributes, nInitialCount, nMaxCount, lpszName);

	return (m_hSemaphore != NULL );
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bOpen(DWORD dwAccess, BOOL bInheritHandle, LPCSTR lpszName) {
	assert(NULL != m_hSemaphore);
	
	::OpenSemaphore(dwAccess, bInheritHandle, lpszName);
	
	return (m_hSemaphore != NULL);
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bRelease(LONG nReleaseCount = 1, LONG *pnOldCount = NULL ) {
	assert(NULL != m_hSemaphore);

	return (::ReleaseSemaphore(m_hSemaphore, nReleaseCount, pnOldCount));
}
//---------------------------------------------------------------------------
DWORD CXSemaphore::dwWaitForSingleObject(DWORD dwTimeout = INFINITE) {
	assert(NULL != m_hSemaphore);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return (::WaitForSingleObject(m_hSemaphore, dwTimeout));
	//SignalMeAndWaitOther()	::SignalObjectAndWait() 
}
//---------------------------------------------------------------------------