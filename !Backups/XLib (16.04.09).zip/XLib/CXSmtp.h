/****************************************************************************
* Class name:  CXSmtp
* Description: Pop3 ������ (RFC 2821)
* File name:   CXSmtp.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXSmtpH 
#define CXSmtpH 
//---------------------------------------------------------------------------
#include "wsocket.h"
//---------------------------------------------------------------------------
class CXSmtp { 
	public: 
                    	   CXSmtp     (); 
                    	  ~CXSmtp     (); 
		bool               bCreate    (const std::string &sUser, const std::string &sPass, const std::string &sServer, unsigned short int usPort); 
		bool               bConnect   (); 
		bool               bLogin     (); 
		bool               bSendRaw   (const std::string &sFilePath, const std::string &sFrom, const std::string &sTo); 
		bool               bDisconnect(); 

	protected: 
		WSocket            m_scktSocket; 
		std::string        m_sUser; 
		std::string        m_sPass; 
		std::string        m_sServer; 
		unsigned short int m_usPort; 

	private: 
	    static const size_t ms_cuiRecvSize = 1024;

		int				   iSmtpSend  (char *pszInBuff, int iInBuffSize, int iFlags = 0); 
		bool               bIsError   (const std::string &sText); 
}; 
//---------------------------------------------------------------------------
#endif 
