/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.h
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#ifndef CXPerformH
#define CXPerformH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <time.h>
#include "xassert.h"
//---------------------------------------------------------------------------
class CXPerform {
	public:
		enum          {pmTime, pmGetTickCount, pmQueryPerformanceCounter, pmGetThreadTimes} m_ePerfomMode;
		
					  CXPerform            (const std::string &csFileName);
		             ~CXPerform            ();
		void          vStart               (int iPerfomMode);
		void          vStop                (const std::string &csComment);
        void          vPulse               (const std::string &csComment, int iPerformMode);
        void          vPulse               (unsigned long int ulComment, int iPerformMode);
        void          vOpenLog             ();
		void          vDeleteLog           ();

    private:
		int           m_iPerfomModeNow;		 
        bool          m_bWasStarted;
		void          vResetData           ();
        std::string   sMilliSecToTimeString(__int64 i64MilliSec); 
		
		//pmTime
		//TDateTime     dtBeginTime;
		//TDateTime     dtEndTime;

		//pmGetTickCount
		DWORD         m_dwBeginTime;
		DWORD         m_dwEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER m_liStart;
		LARGE_INTEGER m_liBeginCount;
		LARGE_INTEGER m_liEndCount;
		LARGE_INTEGER m_liCount;
		
		//GetThreadTimes
		FILETIME      m_lpCreationTime;  
		FILETIME      m_lpExitTime;
		FILETIME      m_lpKernelTime0;
		FILETIME      m_lpUserTime0;
		FILETIME      m_lpKernelTime1;
		FILETIME      m_lpUserTime1;
		__int64       iFiletimeToint64     (FILETIME F);

		//���
		std::string    m_sLogPath;
		void           vLog                (const std::string &csText);
        void           vLog                (const std::string &csComment, const std::string &csText); 
};
//---------------------------------------------------------------------------
#endif