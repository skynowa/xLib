/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef WSocketH
#define WSocketH 
//---------------------------------------------------------------------------
#ifdef WIN32 
	#include <winsock2.h>
	#include <windows.h>
	typedef int				socklen_t; 
#else 
	typedef int				SOCKET; 
	#define INVALID_SOCKET	-1 
	#define SOCKET_ERROR	-1 
#endif 
//---------------------------------------------------------------------------
class WSocket { 
    public: 
                	WSocket      (SOCKET puiSocket = INVALID_SOCKET); 
                   ~WSocket      (); 
    	static int  Init         (); //Init winsock DLL 
    	static int  iClean       (); //Clean winsock DLL 
    	bool        bCreate      (int iAf, int iType, int iProtocol = 0); 
    	bool        bConnect     (const char *cpszIp, unsigned short int usPort); 
    	bool        bBind        (unsigned short int usPort); 
     	bool        bListen      (int iBacklog = 5);  
    	bool        bAccept      (WSocket &s, char *pszFromIp = NULL); 
    	int         iSend        (const char *cpszBuff, int iSize, int iFlags = 0); 
    	int         iRecv        (char *pszBuf, int iSize, int iFlags = 0); 
    	int         iClose       (); 
    	int         iGetLastError(); 
    	static bool bDnsParse    (const char *pcszDomain, char *pszIp); // Domain parse 

        WSocket& operator = (SOCKET s); 
    	operator SOCKET (); 

	protected: 
    	SOCKET m_puiSocket; 
}; 
//---------------------------------------------------------------------------
#endif