/****************************************************************************
*	CXApp
*
*****************************************************************************/


//---------------------------------------------------------------------------
#ifndef CXApp_H
#define CXApp_H
//---------------------------------------------------------------------------
#include <windows.h>
#include "CXWnd.h"

using namespace std;
//---------------------------------------------------------------------------
class CXApp: public CXWnd {
	public:
		          CXApp       ();
		BOOL      Create      (HINSTANCE hInstance, INT nCmdShow);
		void      Run         ();
		HICON     Icon        ();
		void      Icon        (HICON hIcon);
		HACCEL    Accelerators();
		void      Accelerators(HACCEL hAccel);
		BOOL      IsMaximized ();

		void      vProcessMessages();

    protected:
		HICON     _m_hIcon;
		HACCEL    _m_hAccel;
		HINSTANCE _m_hInstance;
};
//---------------------------------------------------------------------------
#endif