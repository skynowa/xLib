/****************************************************************************
*	CXSubclassWnd
*
*****************************************************************************/


//---------------------------------------------------------------------------
#ifndef CSUBCLASSEDWINDOW_H
#define CSUBCLASSEDWINDOW_H
//---------------------------------------------------------------------------
#include "CXWnd.h"
//---------------------------------------------------------------------------
class CXSubclassWnd: public CXWnd {
	public:
		                        CXSubclassWnd();
		BOOL                    Create       (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);

	protected:
		WNDPROC                 m_wpOrigWndProc;

		static LRESULT CALLBACK StatiCXWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
		LRESULT                 WndProc       (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
		void                    Subclass      ();
		
};
//---------------------------------------------------------------------------
#endif
