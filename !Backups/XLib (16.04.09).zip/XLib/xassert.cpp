/****************************************************************************
*	xassert.cpp
*
*****************************************************************************/


#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#include <windows.h>
#include <string> 
//---------------------------------------------------------------------------
std::string sCutFirstDirectory(const std::string &csS) {
	std::string S = "";
	S.assign(csS);	

	bool   bRoot = false;
	size_t P     = - 1;

	if ("\\" == S) {
		S.clear();
	} else {
		if (S[0] == '\\') {
			bRoot = true;
			//������� � 1(0) ������� 1 ������
			//Delete(S, 1, 1);
			S.erase(0, 1);
		} else {
			bRoot = false;
		}

		if ('.' == S[0]) {
			//Delete(S, 1, 4);
			S.erase(0, 4);
		}

		//P = AnsiPos("\\", S); 
		P = S.find_first_of("\\") + 1;

		if (std::string::npos != P) {
			//Delete(S, 1, P); - c ������� 1(0) P ��������
			S.erase(0, P);
			S = "...\\" + S;        
		} else {
			S.clear();
		}

		if (bRoot) {
			S = "\\" + S;
		}
	}

	return S;
}
//---------------------------------------------------------------------------
std::string sMinimizeName(const std::string &csFilePath, size_t uiMaxLen) {
	std::string sRes   = csFilePath;	

	TCHAR szDrive[MAX_PATH];	::ZeroMemory(szDrive, sizeof(szDrive));
	TCHAR szDir  [MAX_PATH];	::ZeroMemory(szDir,   sizeof(szDir));
	TCHAR szName [MAX_PATH];	::ZeroMemory(szName,  sizeof(szName));
	TCHAR szExt  [MAX_PATH];	::ZeroMemory(szExt,   sizeof(szExt));
	_splitpath(csFilePath.c_str(), szDrive, szDir, szName, szExt);	

	std::string sDrive = std::string(szDrive);
	std::string sDir   = std::string(szDir);
	std::string sName  = std::string(szName) + std::string(szExt);

	//while ((Dir <> '') or (Drive <> '')) and (Canvas.TextWidth(Result) > MaxLen) do
	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/ > uiMaxLen)) { 
		if ("\\...\\" == sDir ) {
			sDrive.clear();
			sDir = "...\\";
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			sDir = sCutFirstDirectory(sDir);		  
		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//---------------------------------------------------------------------------
void vAssert(const char *pcszExp, unsigned long int ulLastError, const char *pcszFile, unsigned long int ulLine, const char *pcszFunc, const char *pcszComment) {
	//-------------------------------------
	//���� � exe-�����
	TCHAR szExePath[MAX_PATH];	::ZeroMemory(szExePath, sizeof(szExePath));
	if (!::GetModuleFileName(::GetModuleHandle(NULL), szExePath, MAX_PATH) || 0 == ::lstrlen(szExePath)) {
		::MessageBox(0, "GetModuleFileName() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
		return;
	}

	//-------------------------------------
	//���� � ��� exe-�����
	TCHAR szExeName[MAX_PATH];	::ZeroMemory(szExeName, sizeof(szExeName));
	_splitpath(szExePath, NULL, NULL, szExeName, NULL);
	if (NULL == szExeName || 0 == ::lstrlen(szExeName)) {
		::MessageBox(0, "_splitpath() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� GetLastError()
	LPVOID lpMsgBuf = NULL;
	::FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPSTR)&lpMsgBuf,
		0,
		NULL);
	if (NULL == lpMsgBuf || 0 == ::lstrlen((LPSTR)lpMsgBuf)) {
		::MessageBox(0, "FormatMessage() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� ���������
	const unsigned int cuiMsgSize = 2024; 
	TCHAR              szMsg[cuiMsgSize];	::ZeroMemory(szMsg, sizeof(szMsg));
    ::wsprintf(szMsg,
			 "%s\n\n"
			 "%s:  %s\n"
			 "%s:  %s\n"
			 "%s:  %i\n"
			 "%s:  %s\n"
			 "%s:  %s\n"
			 "%s:  %s"		/*����� ���� \n �� ����*/
			 "%s:  %s",			 
			 
			 "Assertion failed.",
			 "Program",           sMinimizeName(szExePath, 75).c_str(),
			 "File",              sMinimizeName(pcszFile,  75).c_str(),
			 "Line",              ulLine,
			 "Function",          pcszFunc,
			 "Expression",        pcszExp,
			 "GetLastError()",    (LPSTR)lpMsgBuf,
			 "Comment",           pcszComment 
    );

	if (NULL == szMsg || 0 == ::lstrlen(szMsg)) {
		::MessageBox(0, "wsprintf() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	if (NULL != lpMsgBuf) {
		::LocalFree(lpMsgBuf);    lpMsgBuf = NULL;
	}

	//-------------------------------------
	//������� MessageBox
	int iRes = ::MessageBox(NULL, szMsg, szExeName, MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    	exit(- 1);
			break;
		}
		case IDRETRY: {
			_asm {
				int 3
			} 
			break;
		}
		case IDIGNORE: {
			break;
		}
	}
}
//---------------------------------------------------------------------------

