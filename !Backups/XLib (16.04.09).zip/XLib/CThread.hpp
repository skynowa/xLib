/**********************************************************************
*	����� CThread (CThread.h)
*
***********************************************************************/


#ifndef CThreadH
#define CThreadH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
//---------------------------------------------------------------------------
class CThread {
	public:
	    CThread();
		~CThread();
		
		bool Run();

		// Suspend - Suspends the thread (if one is active)
		void Suspend();

		// Resume - Resumes a previously suspended thread
		void Resume();

		// Terminate - Terminates the thread (if one is active).
		// Prefer another means of exiting the thread, as
		// calling Terminate() does not allow the thread to free
		// any resources it may hold
		void Terminate();

		// IsThreadActive - Called in the context of another
		// (external) thread to test whether the thread is
		// currently running
		bool IsThreadActive() const;

		void ExitThread();
		bool ExitThreadAndWait(DWORD timeoutMS);
		bool IsExitEventSet();
		
		/*-----------------------------------------------------------*/
		//SetPriority and GetPriority
		//IsRunning	Returns true if the thread is running.
		//IsTerminated	Returns true if the thread is terminated.
		//IsSuspend
		
    private:
		// Handle to the created Thread
		HANDLE m_hThread;

		// ID of the created thread
		unsigned int m_uiThreadID;

		// ThreadFunc invoketion members
		HANDLE m_hExitThreadEvent;
};
//---------------------------------------------------------------------------
#endif




/**********************************************************************
*	����� CThread (CThread.cpp)
*
***********************************************************************/

extern CThread thT;

unsigned Counter; 
//---------------------------------------------------------------------------
unsigned int __stdcall DoExitableWork(void *pParam) {
	while (Counter < 1000000) {
		if (thT.IsExitEventSet() == true) {
			MessageBox(0, "IsExitEventSet() == true", "_endthreadex(0);", MB_OK);
			_endthreadex(0);
			return 0;
		}

		Counter++;
		Sleep(20);
	}


	MessageBox(0, "DoExitableWork - ending....", "_endthreadex(0)", MB_OK);
	_endthreadex(0);

	return 0;
}
//---------------------------------------------------------------------------
CThread::CThread() {
	m_hExitThreadEvent = NULL;
	m_hExitThreadEvent = ::CreateEvent(NULL, false, false, NULL);

	//MessageBox(0, "CThread()", "", MB_OK);
}
//---------------------------------------------------------------------------
CThread::~CThread() {
	if (m_hExitThreadEvent)	{
		::CloseHandle(m_hExitThreadEvent);
		m_hExitThreadEvent = NULL;
	}

	if (IsThreadActive()) {
		Terminate();
	}

	//MessageBox(0, "~CThread()", "", MB_OK);
}
//--------------------------------------------------------------------------
bool CThread::Run(/*struct*/) {
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &DoExitableWork, (LPVOID)this/*struct*/, /*0*/CREATE_SUSPENDED, &m_uiThreadID);
	
	return (m_hThread != NULL);
}
//--------------------------------------------------------------------------
//Suspend - Suspends the thread (if one is active)
void CThread::Suspend() {
	::SuspendThread(m_hThread);
}
//--------------------------------------------------------------------------
//Resume - Resumes a previously suspended thread
void CThread::Resume() {
	int resumeCount = ::ResumeThread(m_hThread);
	while (resumeCount > 1) {
		resumeCount = ::ResumeThread(m_hThread);
	}
}
//--------------------------------------------------------------------------
//Terminate - Terminates the thread (if one is active).
//Prefer another means of exiting the thread, as
//calling Terminate() does not allow the thread to free
//any resources it may hold
void CThread::Terminate() {
    if (m_hThread) {
	    ::TerminateThread(m_hThread, 0);
	    ::CloseHandle(m_hThread);
        m_hThread = NULL;
    }
}
//--------------------------------------------------------------------------
bool CThread::IsThreadActive() const {
	return ((m_hThread != NULL) && (::WaitForSingleObject(m_hThread, 0) != WAIT_OBJECT_0));
}
//--------------------------------------------------------------------------	
void CThread::ExitThread() {
	::SetEvent(m_hExitThreadEvent);
}
//--------------------------------------------------------------------------
bool CThread::ExitThreadAndWait(DWORD timeoutMS) {
	// Set the event telling the thread to exit
	::SetEvent(m_hExitThreadEvent);

	// Wait for the thread to actually exit
	DWORD result = ::WaitForSingleObject(m_hThread, timeoutMS);

	// Cleanup handle
	::CloseHandle(m_hThread);
	m_hThread = NULL;

	return (result == WAIT_OBJECT_0);
}
//--------------------------------------------------------------------------
bool CThread::IsExitEventSet() {
	DWORD res = ::WaitForSingleObject(m_hExitThreadEvent, 0);
	
	return (res == WAIT_OBJECT_0);
}
//--------------------------------------------------------------------------
		
		
		
		
		
		
		
		
		
		

/*
	static enum {DW_OK					= 0x00000000,
				 DW_ERROR				= 0xFFFFFFFF,
				 DW_UNDEFINED			= 0xFFFFFFFE,
				 DW_TIMEOUT_ELAPSED		= 0xFFFFFFFD,
				 DW_INFINITE			= INFINITE,
				 THREAD_CREATED			= 0,
				 THREAD_STOPPED			= 1,
				 THREAD_RUNNING			= 2,
				 THREAD_PAUSED			= 3,
				 THREAD_CONTINUING		= 4,
				 THREAD_PENDING			= 5,
				 THREAD_USER_ACTIVITY	= 6};
*/