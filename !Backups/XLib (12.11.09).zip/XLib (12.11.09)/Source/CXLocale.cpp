/****************************************************************************
* Class name:  CXLocale
* Description: ������
* File name:   CXLocale.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.08.2009 19:47:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXLocale.h>

#include <locale.h>
//---------------------------------------------------------------------------
//TODO: + CXLocale
CXLocale::CXLocale() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXLocale
CXLocale::~CXLocale() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + sGetCurrent (������ ������� ������)
/*static*/ tstring CXLocale::sGetCurrent() {
	/*DEBUG*///not need
	
	tstring sRes;
	INT     iRes = - 1;
	LCID    lc   = 0;
	
	lc = ::GetSystemDefaultLCID();
	/*DEBUG*///not need
	
	//������ ��������� ������ ������
	iRes = ::GetLocaleInfo(lc, LOCALE_SENGLANGUAGE, 0, 0);
	/*DEBUG*/XASSERT_RET(0 != iRes, _T(""));

	sRes.resize(iRes);
	iRes = ::GetLocaleInfo(lc, LOCALE_SENGLANGUAGE, &sRes[0], sRes.size());
	/*DEBUG*/XASSERT_RET(0 != iRes, _T(""));
	
	sRes.assign(sRes.c_str());	//������� ��������� ������ '\0'
	
	return sRes;
	
	//-------------------------------------
	//2-�������
	//////const TCHAR  *pszLocale = NULL;
	//////
	//////pszLocale = _tsetlocale(LC_ALL, NULL);
	///////*DEBUG*/XASSERT_RET(NULL != pszLocale, _T(""));
	//////
	//////return tstring(pszLocale);
}
//---------------------------------------------------------------------------
//TODO: - bSetCurrent (������������� ������� ������)
/*static*/ BOOL CXLocale::bSetCurrent(LPCTSTR pszLocale) {
	/*DEBUG*/XASSERT_RET(NULL     != pszLocale,  FALSE);
	/*DEBUG*/XASSERT_RET(_T('\0') != *pszLocale, FALSE);

	BOOL         bRes       = FALSE;
	const TCHAR *_pszLocale = NULL;

    _pszLocale = _tsetlocale(LC_ALL, pszLocale);
    /*DEBUG*/XASSERT_RET(NULL != _pszLocale, FALSE);
 
    return TRUE;
 
	//-------------------------------------
	//2-�������
	////BOOL bRes = FALSE;

	////bRes = ::SetLocaleInfo((LCID)csLocale.c_str(), LC_ALL,  0);
	/////*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	////return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetDefault (������������� ������ ��-���������)
/*static*/ BOOL CXLocale::bSetDefault() {
	BOOL bRes = FALSE;
	
	bRes = CXLocale::bSetCurrent(CXLocale::sGetCurrent().c_str());
   /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
   
   return TRUE;
}
//---------------------------------------------------------------------------


//int GetLocaleInfo(
//				  __in   LCID Locale,
//				  __in   LCTYPE LCType,
//				  __out  LPTSTR lpLCData,
//				  __in   int cchData
//				  );

//BOOL SetLocaleInfo(
//				   __in  LCID Locale,
//				   __in  LCTYPE LCType,
//				   __in  LPCTSTR lpLCData
//				   );