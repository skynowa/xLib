/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/xassert.h> 

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h> 
#include <XLib/CXMsgBoxRtfEx.h>


/****************************************************************************
*	release
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID vAppendLogFile(LPCTSTR pszFilePath, LPCTSTR pszText) {
	FILE *pFile = _tfopen(pszFilePath, _T("a"));
	if (NULL == pFile) {
		return;
	}

	__try {
		SYSTEMTIME stST = {0};
		::GetLocalTime(&stST);
		_ftprintf(pFile, _T("[%d:%d:%d]  %s\n---------------------------------------------------------------------------\n\n"), 
			            stST.wHour, stST.wMinute, stST.wSecond, pszText);
	}
	__finally {
		if (NULL != pFile) {
			fflush(pFile);
			fclose(pFile);	pFile = NULL;
		}
	}
}
//---------------------------------------------------------------------------
VOID vAssertLog(LPCTSTR pszExpr, ULONG ulLastError, LPCTSTR pszFile, ULONG ulLine, LPCTSTR csFunc,	LPCTSTR pszComment) {
	::SetLastError(0);

	//-------------------------------------
	//�������� ���������
	tstring sProgram      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), FALSE);
	tstring sFile         = CXPath::sWinToUnixPath(CXPath::sMinimizePath(pszFile,     45), FALSE);
	tstring sGetLastError = sLastErrorStr(ulLastError);
	tstring sExeName      = CXPath::sExtractFileName(CXPath::sExePath());							
																					
	tstring sFStr = sFormatStr(
				_T("%s\n\n")
				_T("%s:  %s\n")
				_T("%s:  %s\n")
				_T("%s:  %i\n")
				_T("%s:  %s\n")
				_T("%s:  %s\n")
				_T("%s:  %s\n")		/*����� ���� \n �� ����*/
				_T("%s:  %s"),	

				_T("Assertion failed."),
				_T("Program:"),         sProgram.c_str(),
				_T("File:"),            sFile.c_str(),
				_T("Line:"),            ulLine,
				_T("Function:"),        csFunc,
				_T("Expression:"),      pszExpr,
				_T("GetLastError:"),    sGetLastError.c_str(),
				_T("Comment:"),         pszComment);
																							
	//-------------------------------------
	//�������� ��� �����
	tstring sFilePath = CXPath::sChangeFileExt(CXPath::sExePath(), _T("debug"));
			
	//-------------------------------------
	//������� � ���
	vAppendLogFile(sFilePath.c_str(), sFStr.c_str());												
}
//---------------------------------------------------------------------------


/****************************************************************************
* debug
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL bCheckForDebugger() {
	__try {
		::DebugBreak();
	}
	__except (GetExceptionCode() == EXCEPTION_BREAKPOINT ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
		// No debugger is attached, so return FALSE and continue.
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
VOID vAssert(LPCTSTR pszExpr, ULONG ulLastError, LPCTSTR pszFile, ULONG ulLine, LPCTSTR csFunc, LPCTSTR pszComment) {
	//-------------------------------------
	//�������� ���������
	tstring sProgram      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), false);
	tstring sFile         = CXPath::sWinToUnixPath(CXPath::sMinimizePath(pszFile,     45),        false);
	tstring sGetLastError = sLastErrorStr(ulLastError);
	tstring sExeName      = CXPath::sExtractFileName(CXPath::sExePath());

#ifdef XLib_Debug_MsgBoxLite
	tstring sFStr = sFormatStr(
							_T("%s\n\n")
							_T("%s  %s\n")
							_T("%s  %s\n")
							_T("%s  %i\n")
							_T("%s  %s\n")
							_T("%s  %s\n")
							_T("%s  %s\n")		/*����� ���� \n �� ����*/
							_T("%s  %s"),	

							_T("Assertion failed."),
							_T("Program:"),         sProgram.c_str(),
							_T("File:"),            sFile.c_str(),
							_T("Line:"),            ulLine,
							_T("Function:"),        csFunc.c_str(),
							_T("Expression:"),      pszExpr.c_str(),
							_T("GetLastError:"),    sGetLastError.c_str(),
							_T("Comment:"),         pszComment.c_str());

	//-------------------------------------
	//������� MessageBox
	INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    		exit(- 1);
				break;
			}
		case IDRETRY: {
				////_asm {int 3} 
				_CrtDbgBreak();
			}
			break;

		case IDIGNORE: {
				//����������
			}
			break;
	}

#else //XLib_Debug_MsgBoxLite
	tstring sFStr = sFormatStr(
				////_T("%s\n\n")
				////_T("%s:  %s\n")
				////_T("%s:  %s\n")
				////_T("%s:  %i\n")
				////_T("%s:  %s\n")
				////_T("%s:  %s\n")
				////_T("%s:  %s")		/*����� ���� \n �� ����*/
				////_T("%s:  %s"),	
				_T("{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}")
				_T("{\\colortbl ;\\red255\\green0\\blue0;}")
				_T("\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par")
				_T("\\par")
				_T("\\b %s\\b0   \\lang1033\\f1      \\cf1\\lang1049\\f0 %s\\par")
				_T("\\cf0\\b %s\\b0   \\lang1033\\f1              \\cf1\\lang1049\\f0 %s\\par")
				_T("\\cf0\\b %s\\b0   \\lang1033\\f1             \\cf1\\lang1049\\f0 %i\\cf0\\par")
				_T("\\b %s\\b0  \\lang1033\\f1     \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par")
				_T("\\b %s\\b0   \\lang1033\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par")
				_T("\\b %s\\b0\\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par")
				_T("\\b %s\\b0  \\lang1033\\f1      \\cf1 %s\\cf0\\lang1049\\f0\\par}"),			 

				_T("Assertion failed."),
				_T("Program:"),         sProgram.c_str(),
				_T("File:"),            sFile.c_str(),
				_T("Line:"),            ulLine,
				_T("Function:"),        csFunc,
				_T("Expression:"),      pszExpr,
				_T("GetLastError:"),    sGetLastError.c_str(),
				_T("Comment:"),         pszComment 
	);

	//-------------------------------------
	//������� MessageBox
	//INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	INT iRes = NMsgBoxRtf::iShow(NULL, sFStr, sExeName);
	switch (iRes) {
		case NMsgBoxRtf::mrAbort: {
	    		exit(- 1);
			}
			break;

		case NMsgBoxRtf::mrIgnore: {
				//����������
			}
			break;

		case NMsgBoxRtf::mrRetry: {
				////if (FALSE == bCheckForDebugger()) { //CheckRemoteDebuggerPresent  /*::IsDebuggerPresent*/
				////	MsgBox("Debugger is not present.\nThe application will be terminated.", "XLib", MB_OK | MB_ICONWARNING);
				////	exit(- 1);
				////} else {
				////	////_asm {int 3}
				////	////CrtDbgBreak();
				////	////::DebugBreak();
				////}

				_asm {int 3}
			}
			break;	
	}
#endif //XLib_Debug_MsgBoxLite
}
//---------------------------------------------------------------------------