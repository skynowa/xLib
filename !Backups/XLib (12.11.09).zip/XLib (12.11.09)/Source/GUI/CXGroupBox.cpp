/****************************************************************************
* Class name:  CXGroupBox
* Description: 
* File name:   CXGroupBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:10:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXGroupBox.h>
//---------------------------------------------------------------------------
CXGroupBox::CXGroupBox() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ���� 
	_m_sClassName     = CXGROUPBOX_CONTROL_CLASS;           
	_m_ulStyle        = CXGROUPBOX_DEFAULT_WINDOW_STYLE;     
	_m_ulStyleEx      = CXGROUPBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXGROUPBOX_DEFAULT_WIDTH;     
	_m_iHeight        = CXGROUPBOX_DEFAULT_HEIGHT;      
}
//---------------------------------------------------------------------------
CXGroupBox::~CXGroupBox() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXGroupBox::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
								CXResources::sGetText(iID), 
								CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
								CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
								CXResources::ulGetStyle(iID), 
								CXResources::ulGetStyleEx(iID),
								this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------