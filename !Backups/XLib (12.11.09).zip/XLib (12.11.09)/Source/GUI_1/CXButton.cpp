/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXButton.h>
//---------------------------------------------------------------------------
CXButton::CXButton() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXBUTTON_CONTROL_CLASS;
	_m_ulStyle        = CXBUTTON_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = CXBUTTON_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXButton::~CXButton() {
	LOG();
}
//---------------------------------------------------------------------------
//	g_Edt.bInit(g_hDlgMain, IDC_EDIT1);
BOOL CXButton::bCreateRes(HWND hParent, INT iResID) {
	_m_hWnd = ::GetDlgItem(hParent, iResID);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------