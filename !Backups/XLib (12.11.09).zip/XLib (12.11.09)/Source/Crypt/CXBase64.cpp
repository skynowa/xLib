/****************************************************************************
* Class name:  CXBase64
* Description: ������ � ���������� Base64
* File name:   CXBase64.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.07.2009 12:22:00
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Crypt/CXBase64.h>
#include <XLib/Debug/xassert.h>
#include <iostream>
//---------------------------------------------------------------------------
static const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
//---------------------------------------------------------------------------
/*static*/bool CXBase64::bIsBase64(UCHAR chChar) {
	return (isalnum(chChar) || ('+' == chChar) || ('/' == chChar));
}
//---------------------------------------------------------------------------
///*static*/std::string CXBase64::sEncode(const UCHAR *pcucBuff, UINT uiBuffSize) {
/*static*/std::string CXBase64::sEncode(const std::string &csStr) {
	const unsigned char * pcucBuff = reinterpret_cast<const unsigned char*>(csStr.c_str());	//????

	std::string   sRes;
	int           i               = 0;
	int           j               = 0;
	unsigned char char_array_3[3] = {0};
	unsigned char char_array_4[4] = {0};
	size_t        uiBuffSize      = csStr.size();

	while (uiBuffSize --) {
		char_array_3[i ++] = *(pcucBuff ++);

		if (i == 3) {
			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;

			for (i = 0; (i < 4) ; i ++) {
				sRes += base64_chars[char_array_4[i]];
			}

			i = 0;
		}
	}

	if (i) {
		for(j = i; j < 3; j ++) {
			char_array_3[j] = '\0';
		}

		char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
		char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
		char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
		char_array_4[3] = char_array_3[2] & 0x3f;

		for (j = 0; (j < i + 1); j ++) {
			sRes += base64_chars[char_array_4[j]];
		}

		while ((i ++ < 3)) {
			sRes += '=';
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXBase64::sDecode(const std::string &csStr) {
	std::string   sRes;
	int           in_len          = csStr.size();
	int           i               = 0;
	int           j               = 0;
	int           in_             = 0;
	unsigned char char_array_4[4] = {0};
	unsigned char char_array_3[3] = {0};

	while (in_len-- && (csStr[in_] != '=') && bIsBase64(csStr[in_])) {
		char_array_4[i++] = csStr[in_]; in_++;

		if (4 == i) {
			for (i = 0; i <4; i++) {
				char_array_4[i] = base64_chars.find(char_array_4[i]);
			}

			char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
			char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
			char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

			for (i = 0; (i < 3); i++) {
				sRes += char_array_3[i];
			}

			i = 0;
		}
	}

	if (i) {
		for (j = i; j < 4; j ++) {
			char_array_4[j] = 0;
		}

		for (j = 0; j < 4; j ++) {
			char_array_4[j] = base64_chars.find(char_array_4[j]);
		}

		char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
		char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
		char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

		for (j = 0; (j < i - 1); j ++) {
			sRes += char_array_3[j];
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------