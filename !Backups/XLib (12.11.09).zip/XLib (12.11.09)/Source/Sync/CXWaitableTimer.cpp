/****************************************************************************
* Class name:  CXWaitableTimer
* Description: ������ � �������� ��������
* File name:   CXWaitableTimer.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.05.2009 17:07:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXWaitableTimer.h>

#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXWaitableTimer::CXWaitableTimer() 
	: _m_hWaitableTimer(NULL)
{

}  
//---------------------------------------------------------------------------
CXWaitableTimer::~CXWaitableTimer() {
	/*DEBUG*/XASSERT(NULL != _m_hWaitableTimer);

	if (NULL != _m_hWaitableTimer) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(_m_hWaitableTimer);	_m_hWaitableTimer = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXWaitableTimer::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, NULL);

	return _m_hWaitableTimer;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bCreate(BOOL bManualReset, LPCTSTR pcszName, LPSECURITY_ATTRIBUTES lpTimerAttributes) {
	/*DEBUG*/XASSERT_RET(NULL == _m_hWaitableTimer, FALSE);

	_m_hWaitableTimer = ::CreateWaitableTimer(lpTimerAttributes, bManualReset, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bOpen(LPCTSTR pcszName, ULONG ulDesiredAccess, BOOL bInheritHandle) {
	/*DEBUG*/XASSERT_RET(NULL == _m_hWaitableTimer, FALSE);

	_m_hWaitableTimer = ::OpenWaitableTimer(ulDesiredAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bCancel() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, FALSE);

	BOOL bRes = FALSE;

	bRes = ::CancelWaitableTimer(_m_hWaitableTimer);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bSet(LONGLONG i64DueTime, LONG liPeriod, PTIMERAPCROUTINE pfnCompletionRoutine, LPVOID pvArgToCompletionRoutine, BOOL bResume) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, FALSE);

	/*
	#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	//����� �������� ��� ������� = 2 �������
	qwTimeInterval = -2 * _SECOND;
	*/
	BOOL bRes = FALSE;  //#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	LARGE_INTEGER liDueTime = {0};
	liDueTime.QuadPart = i64DueTime;
	
	bRes = ::SetWaitableTimer(_m_hWaitableTimer, &liDueTime, liPeriod, pfnCompletionRoutine, pvArgToCompletionRoutine, bResume);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXWaitableTimer::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWaitableTimer, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
	return ::WaitForSingleObject(_m_hWaitableTimer, ulTimeout);
}
//---------------------------------------------------------------------------