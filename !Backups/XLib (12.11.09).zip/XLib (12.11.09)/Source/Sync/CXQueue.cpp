/****************************************************************************
* Class name:  CXQueue
* Description: ������ � ��������
* File name:   CXQueue.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXQueue.h>
//---------------------------------------------------------------------------
//TODO: - CXQueue
CXQueue::CXQueue(INT nMaxElements) : 
    m_hmtxQ          (m_h[0]), 
	m_hsemNumElements(m_h[1])
{
	m_pElements       = (PELEMENT)::HeapAlloc(::GetProcessHeap(), 0, sizeof(ELEMENT) * nMaxElements);
	m_nMaxElements    = nMaxElements;
	m_hmtxQ           = ::CreateMutex(NULL, FALSE, NULL);
	m_hsemNumElements = ::CreateSemaphore(NULL, 0, nMaxElements, NULL);
}
//---------------------------------------------------------------------------
//TODO: - ~CXQueue
CXQueue::~CXQueue() {
	::CloseHandle(m_hsemNumElements);
	::CloseHandle(m_hmtxQ);
	::HeapFree   (::GetProcessHeap(), 0, m_pElements);
}
//---------------------------------------------------------------------------
//TODO: - bAppend
BOOL CXQueue::bAppend(PELEMENT pElement, ULONG dwTimeout) {
	BOOL  bRes  = FALSE;
	ULONG ulRes = ::WaitForSingleObject(m_hmtxQ, dwTimeout);

	if (WAIT_OBJECT_0 == ulRes) {
		//This thread has exclusive access to the queue

		//Increment the number of elements in the queue
		LONG lPrevCount = 0;
		bRes = ::ReleaseSemaphore(m_hsemNumElements, 1, &lPrevCount);
		if (TRUE == bRes) {
			//The queue is not full, append the new element
			m_pElements[lPrevCount] = *pElement;
		} else {
			//The queue is full, set the error code and return failure
			::SetLastError(ERROR_DATABASE_FULL);
		}

		//Allow other threads to access the queue
		::ReleaseMutex(m_hmtxQ);
	} else {
		//Timeout, set error code and return failure
		::SetLastError(ERROR_TIMEOUT);
	}

	return bRes;   //Call GetLastError for more info
}
//---------------------------------------------------------------------------
//TODO: - bRemove
BOOL CXQueue::bRemove(PELEMENT pElement, ULONG dwTimeout) {
	//Wait for exclusive access to queue and for queue to have element.
	BOOL bRes = (::WaitForMultipleObjects(chDIMOF(m_h), m_h, TRUE, dwTimeout) == WAIT_OBJECT_0);
	if (TRUE == bRes) {
		//The queu has an element, pull it from the queue
		*pElement = m_pElements[0];

		//Shift the remaining elements down
		::MoveMemory(&m_pElements[0], &m_pElements[1], sizeof(ELEMENT) * (m_nMaxElements - 1));

		//Allow other threads to access the queue
		::ReleaseMutex(m_hmtxQ);
	} else {
		//Timeout, set error code and return failure
		::SetLastError(ERROR_TIMEOUT);
	}

	return bRes;   // Call GetLastError for more info
}
//---------------------------------------------------------------------------