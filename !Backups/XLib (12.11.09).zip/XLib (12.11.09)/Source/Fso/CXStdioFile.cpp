/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXStdioFile.h>

#include <cstdarg>
#include <stdlib.h>
#include <process.h>
#include <iostream>
#include <sstream>
#include <ostream>
#include <fstream>
#include <io.h>   
#include <ctime>
//#include <sharc.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Debug/xassert.h>
////#include <Xlib/Debug/CXPerform.h>
#include <XLib/CXLocale.h>
//---------------------------------------------------------------------------
const tstring csEOL = _T("\r\n");
//---------------------------------------------------------------------------
//TODO: + CXStdioFile
CXStdioFile::CXStdioFile() :
	_m_pFile    (NULL),
	_m_sFilePath(_T(""))
{
	////BOOL bRes = FALSE;
	////
	////bRes = CXLocale::bSetDefault();
	////XASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXStdioFile 
CXStdioFile::~CXStdioFile() { 
	if (NULL != _m_pFile) {
		BOOL bRes = FALSE;

		bRes = bClose();
		/*DEBUG*/XASSERT(FALSE != bRes);	
	}
}
//---------------------------------------------------------------------------
//TODO: + operator FILE*
CXStdioFile::operator FILE * () {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, NULL);     
	
	return _m_pFile;
}
//---------------------------------------------------------------------------
//TODO: + pGetFile (�������� ��������� �� ����)
FILE *CXStdioFile::pGetFile() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, NULL);      

	return _m_pFile;
}
//---------------------------------------------------------------------------
//TODO: + bOpen (Open file)
BOOL CXStdioFile::bOpen(const tstring &csFilePath, const tstring &csMode) {
	/*DEBUG*/XASSERT_RET(NULL  == _m_pFile,           FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/XASSERT_RET(false == csMode.empty(),     FALSE); 
	
	_m_pFile = _tfopen(csFilePath.c_str(), csMode.c_str());
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE); 

	_m_sFilePath = csFilePath; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReopen (Reopen stream with different file or mode)
BOOL CXStdioFile::bReopen(const tstring &csFilePath, const tstring &csMode) {
	/*DEBUG*/XASSERT_RET(NULL  != _m_pFile,           FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/XASSERT_RET(false == csMode.empty(),     FALSE); 

	_m_pFile = _tfreopen(csFilePath.c_str(), csMode.c_str(), _m_pFile);
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);   

	_m_sFilePath = csFilePath; 

	return TRUE;
}
//---------------------------------------------------------------------------
tstring CXStdioFile::sGetFilePath() {
	return _m_sFilePath;
}
//---------------------------------------------------------------------------


/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + uiRead (Read block of data from stream)
size_t CXStdioFile::uiRead(LPVOID pvBuff, size_t uiCount) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, 0); 
	/*DEBUG*/XASSERT_RET(NULL != pvBuff,   0); 
	
	size_t uiRes = 0;

	uiRes = fread(pvBuff, sizeof(TCHAR), uiCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(uiCount >= uiRes, 0); 
	
	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: - uiWrite (Write block of data to stream)
size_t CXStdioFile::uiWrite(const LPVOID pcvBuf, size_t uiCount) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, 0);
	/*DEBUG*/XASSERT_RET(NULL != pcvBuf,   0); 

	size_t uiRes = 0;

	uiRes = fwrite(pcvBuf, sizeof(TCHAR), uiCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(uiCount == uiRes, 0); 

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: - uiReadAll (������ ���� ���� �������)
BOOL CXStdioFile::bReadAll(LPVOID pvBuff, size_t uiBuffSize, const size_t cuiBlockSize) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,     FALSE); 
	/*DEBUG*/XASSERT_RET(NULL != pvBuff,       FALSE); 
	/*DEBUG*/XASSERT_RET(0    != cuiBlockSize, FALSE); 

	BOOL   bRes  = FALSE;
	size_t uiRes = 0;

	////uiRes = fread(pvBuff, sizeof(TCHAR), uiCount, _m_pFile);
	/////*DEBUG*/XASSERT_RET(uiCount >= uiRes, 0); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - uiWriteAll (����� ���� ���� �������)
BOOL CXStdioFile::bWriteAll(const LPVOID pcvBuf, size_t uiBuffSize, const size_t cuiBlockSize) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,     FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pcvBuf,       FALSE); 
	/*DEBUG*/XASSERT_RET(0    != cuiBlockSize, FALSE); 

	BOOL   bRes  = FALSE;
	size_t uiRes = 0;

	////uiRes = fwrite(pcvBuf, sizeof(TCHAR), uiCount, _m_pFile);
	/////*DEBUG*/XASSERT_RET(uiCount == uiRes, 0); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReadLine (Reads data from the file to pszStr till '\n' is encountered)
BOOL CXStdioFile::bReadLine(LPTSTR pszStr, size_t uiMaxCount) {		//TODO: overflow
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pszStr,   FALSE); 

	LPTSTR pszRes = NULL;
	
	pszRes = _fgetts/*fgets*/(pszStr, uiMaxCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteLine (Writes csStr and then writes '\n' to the file)
BOOL CXStdioFile::bWriteLine(const tstring &csStr) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	size_t uiSize = csStr.size() + csEOL.size();
	size_t uiRes  = uiWrite((LPVOID)(csStr + csEOL).c_str(), uiSize);
	CHECK_RET(uiRes < uiSize, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteChar (Write character to stream)
BOOL CXStdioFile::bWriteChar(TCHAR cChar) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _fputtc((INT)cChar , _m_pFile);
	/*DEBUG*/XASSERT_RET((INT)cChar != etError, FALSE);
	/*DEBUG*/XASSERT_RET((INT)cChar == iRes,    FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + cGetChar (Get character from stream)
TCHAR CXStdioFile::cReadChar() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _fgettc/*getc*/(_m_pFile);
	/*DEBUG*///not need XASSERT_RET(iRes != etError, (TCHAR)etError);
	/*DEBUG*///not need XASSERT_RET(EOF < iRes,      (TCHAR)etError);

	return (TCHAR)iRes; 
} 
//---------------------------------------------------------------------------
//TODO: + bUngetChar (Unget character from stream)
BOOL CXStdioFile::bUngetChar(TCHAR cChar) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _ungettc/*ungetc*/(cChar, _m_pFile);
	/*DEBUG*/XASSERT_RET(iRes  != etError,     FALSE);
	/*DEBUG*/XASSERT_RET(cChar == (TCHAR)iRes, FALSE);	

	return TRUE; 
}
//---------------------------------------------------------------------------
//TODO: + bWriteString (Write string to stream)
BOOL CXStdioFile::bWriteString(const tstring &csStr) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _fputts/*fputs*/(csStr.c_str(), _m_pFile); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);
	/*DEBUG*/XASSERT_RET(EOF < iRes,      FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------





//---------------------------------------------------------------------------
//TODO: + bReadFile (���� � std::vector)
/*static*/BOOL CXStdioFile::bReadFile(const tstring &csFilePath, std::vector<tstring> *pvecsVector) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(NULL  != pvecsVector,        FALSE);
		
	BOOL bRes = FALSE;
	INT  iRes = etError;

	CXStdioFile stdFile;

	bRes = stdFile.bOpen(csFilePath.c_str(), _T("rb"));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	tstring sLine;

	////CXPerform   P("__TEST.test", CXPerform::pmGetTickCount);
	/*SPEED*/////P.bStart();
	for (;;) {
		bRes = stdFile.bIsEof();
		if (TRUE == bRes) {
			break;
		}

		iRes = (INT)stdFile.cReadChar();      
		if (etError == iRes) {
			//�������� ��������� ������ (� ��� ��� EOL)
			pvecsVector->push_back(sLine);	
			sLine.clear();

			break;
		}

		sLine += (TCHAR)iRes;
		if (csEOL.at(1)/*'\n'*/ == (TCHAR)iRes) {
			pvecsVector->push_back(sRemoveEOL(sLine));	
			sLine.clear();		
		}
	}
	/*SPEED*/////P.bStop("CXStdioFile::bReadFile ---> ");

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteFile (std::vector � ����)
/*static*/BOOL CXStdioFile::bWriteFile(const tstring &csFilePath, const std::vector<tstring> *pcvecsVector) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(NULL  != pcvecsVector,       FALSE);
	
	BOOL bRes = FALSE;
	INT  iRes = etError;
	
	CXStdioFile stdFile;

	bRes = stdFile.bOpen(csFilePath.c_str(), _T("wb"));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
		
	std::vector<tstring>::const_iterator it;
	for (it = pcvecsVector->begin(); it < pcvecsVector->end(); it ++) {		
		size_t  uiRes   = 0;
		tstring sLine   = *it + csEOL;
		size_t  uiCount = sLine.size();

		uiRes = stdFile.uiWrite((LPVOID)sLine.c_str(), uiCount);
		if (uiCount != uiRes) {   
			return FALSE;
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO:  bReadFile (���� � std::map)
/*static*/BOOL CXStdioFile::bReadFile(const tstring &csFilePath, std::map<tstring, tstring> *pmsMap) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(NULL  != pmsMap,             FALSE);

	BOOL bRes = FALSE;
	INT  iRes = etError;
	
   /*for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);

		std::vector<tstring> vecsLine = vecsSplit(sStr, csDelimiter);

		mapLines[vecsLine.at(0)] = vecsLine.at(1);
	}*/

		
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bReadFile (std::map � ����)
/*static*/BOOL CXStdioFile::bWriteFile(const tstring &csFilePath, const std::map<tstring, tstring> &cmsMap) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	BOOL bRes = FALSE;
	INT  iRes = etError;


	return TRUE;
}
//---------------------------------------------------------------------------






















//---------------------------------------------------------------------------
//TODO: - bSetVBuff (Change stream buffering)
BOOL CXStdioFile::bSetVBuff(LPTSTR pszBuff, EBufferingMode bmMode, size_t uiSize) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile,               FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pszBuff,                FALSE);
    /*DEBUG*/XASSERT_RET(2 < uiSize && uiSize < INT_MAX, FALSE);
    
    INT iRes = etError;
    
	////iRes = setvbuf(_m_pFile, pszBuff, bmMode, uiSize);
	/////*DEBUG*/XASSERT_RET(0 == iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetMode (Sets the file translation mode)
BOOL CXStdioFile::bSetMode(ETranslationMode tmMode) {    
	INT iRes = etError;

	iRes = /*BC++_setmode*/setmode(_iGetHandle(), tmMode);
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetPosition (REFilePosition stream position indicator)
BOOL CXStdioFile::bSetPosition(LONG lOffset, EPointerPosition fpPos/* = fpBegin*/) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
	INT iRet = ppError;

	iRet = fseek(_m_pFile, lOffset, fpPos);
	/*DEBUG*/XASSERT_RET(0 == iRet, FALSE); 
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + liGetPosition (Get current position in stream)
LONG CXStdioFile::liGetPosition() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
	LONG liRes = ppError;

	liRes = ftell(_m_pFile);
	/*DEBUG*/XASSERT_RET(ppError != liRes, ppError); 
		
	return liRes;
}
//---------------------------------------------------------------------------
//TODO: + bClose (Close file)
BOOL CXStdioFile::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	
	
	iRes = fclose(_m_pFile);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	_m_pFile = NULL;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bFlush (Flush stream)
BOOL CXStdioFile::bFlush() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	

	iRes = fflush(_m_pFile);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + liGetSize (������ �����)
LONG CXStdioFile::liGetSize() {
	LONG liStreamSize    = ppError;
	LONG liCurrStreamPos = ppError;
	
	//Get current position
	liCurrStreamPos = liGetPosition();
	
	//seek to the end of file
	if (FALSE == bSetPosition(0, ppEnd)) {
		return ppError; 
	}
	
	liStreamSize = liGetPosition();
	
	//Get back to the stored position
	if (FALSE == bSetPosition(liCurrStreamPos, ppBegin)) {
		return ppError;
	}

	return liStreamSize;
}
//---------------------------------------------------------------------------
//TODO: + bChsize(Changes the file size)
BOOL CXStdioFile::bChsize(LONG liSize) {
	/*DEBUG*///not need 

	INT iRes = etError;

	iRes = /*BC++ _chsize*/chsize(_iGetHandle(), liSize); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: + bLocking (Locks or unlocks bytes of a file)
BOOL CXStdioFile::bLocking(ELockingMode lmMode, LONG liBytes) {
	INT iRes = etError;

	/*BC++*/////iRes = _locking(_iGetHandle(), lmMode, liBytes);
	/*DEBUG*/////XASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//TODO: + bIsExists (�������� ������������� �����)
/*static*/BOOL CXStdioFile::bIsExists(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	
	INT iRes = etError;

	iRes = _taccess(csFilePath.c_str(), amExistence); 
	ULONG ulLasError = ::GetLastError();
	CHECK_RET((etError == iRes) && (2 == ulLasError || 3 == ulLasError), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAccess (Determine file-access permission)
/*static*/BOOL CXStdioFile::bAccess(const tstring &csFilePath, EAccessMode amMode) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _taccess(csFilePath.c_str(), amMode); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: + bChmod (Change the file-permission settings)
/*static*/BOOL CXStdioFile::bChmod(const tstring &csFilePath, EPermissionMode pmMode) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _tchmod(csFilePath.c_str(), pmMode);   
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------		
//TODO: + bRemove (Remove file)
/*static*/BOOL CXStdioFile::bRemove(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);  
	
	INT iRes = etError;

	iRes = bChmod(csFilePath.c_str(), pmWrite);
	/*DEBUG*/XASSERT_RET(FALSE != iRes, FALSE);  

	iRes = _tremove(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUnlink (Delete a file)
/*static*/BOOL CXStdioFile::bUnlink(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	
	INT iRes = etError;

	iRes = _tunlink(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//TODO: + bRename (Rename file) 
/*static*/BOOL CXStdioFile::bRename(const tstring &csOldFilePath, const tstring &csNewFilePath) {
	/*DEBUG*/XASSERT_RET(false == csOldFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csNewFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = _trename(csOldFilePath.c_str(), csNewFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCopy (�������� ����)
//TODO: - FilePath -> DirPath
/*static*/BOOL CXStdioFile::bCopy(const tstring &csFromFilePath, const tstring &csToFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFromFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csToFilePath.empty(),   FALSE); 

	BOOL    bRes     = FALSE;	
	size_t  uiReaded = 0;
	size_t  uiWrited = 0;
	tstring sBuff;
	
	CXStdioFile stdfFile;

	//-------------------------------------
	//������
	bRes = stdfFile.bOpen(csFromFilePath.c_str(), _T("rb"));
	CHECK_RET(FALSE == bRes, FALSE);

	sBuff.resize(stdfFile.liGetSize());

	uiReaded = stdfFile.uiRead(&sBuff[0], sBuff.size());
	CHECK_RET(sBuff.size() != uiReaded, FALSE);

	bRes = stdfFile.bClose();
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//�����
	bRes = stdfFile.bOpen(csToFilePath.c_str(), _T("wb"));
	CHECK_RET(FALSE == bRes, FALSE);

	uiWrited = stdfFile.uiWrite(&sBuff[0], sBuff.size());
	if (sBuff.size() != uiWrited) {
		//���� �� �������� ���� - �������
		stdfFile.bClose();
		CXStdioFile::bRemove(csToFilePath);
		
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMove (����������� ����� � �����) 
/*static*/BOOL CXStdioFile::bMove(const tstring &csFilePath, const tstring &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),  FALSE);

	BOOL bRes = FALSE;
	INT  iRes = etError;

	tstring sFileName = CXPath::sExtractFullFileName(csFilePath);

	bRes = bRename(csFilePath, csDirPath + _T("\\") + sFileName);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExec (��������� ����)
/*static*/BOOL CXStdioFile::bExec(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = _tsystem(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sCreateTempFileName (Generate temporary filename (������ ����� ����� [\s150.]))
/*static*/tstring CXStdioFile::sCreateTempFileName() {
	TCHAR  szBuff[L_tmpnam] = {0};
	TCHAR *pszRes           = NULL;

	pszRes = _ttmpnam(szBuff);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, _T("")); 

	return tstring(szBuff);  
}
//---------------------------------------------------------------------------
//TODO: + bFlushAllOutput (Flushes all streams opened for output)
/*static*/BOOL CXStdioFile::bFlushAllOutput() {
	INT iRes = etError;	

	iRes = fflush(NULL);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iFlushAll (returns the number of open streams (input and output))
/*static*/INT CXStdioFile::iFlushAll() {
	INT iRes = etError;	

	iRes = _flushall();
	/*DEBUG*///not need

	return iRes;
}
//--------------------------------------------------------------------------
//TODO: - ulLines (���-�� ����� � �����)
/*static*/ULONG CXStdioFile::ulLines(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),    0);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePath), 0);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	XASSERT_RET(FALSE != bRes, FALSE);
	
	ULONG ulLines = 0;   //������� �����

	tifstream ifsStream(csFilePath.c_str(), std::ios::in);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return 0;
	}

	TCHAR cChar = _T('\0');
	while (ifsStream.get(cChar)) {
		if (_T('\n') == cChar) {
			ulLines ++;
		}
	} 
	ulLines ++;
	ifsStream.close();

	return ulLines;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO: + cGetCharFromStdin (Get character from stdin)
TCHAR CXStdioFile::cGetCharFromStdin() {
	INT iRes = etError;
	
	iRes = _gettchar();
	/*DEBUG*/XASSERT_RET(etError != iRes, (TCHAR)etError);
	
	return (TCHAR)iRes;
}
//---------------------------------------------------------------------------
//TODO: + sGetStringFromStdin (Get string from stdin)
tstring CXStdioFile::sGetStringFromStdin(LPTSTR pszBuff) {
	LPTSTR pszRes = NULL;

	pszRes = _getts(pszBuff);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, _T(""));

	return tstring(pszRes);
}
//---------------------------------------------------------------------------
//TODO: + bWriteCharToStdout (Write character to stdout)
BOOL CXStdioFile::bWriteCharToStdout(TCHAR cChar) {
	INT iRes = etError;

	iRes = _puttchar((INT)cChar);
	/*DEBUG*/XASSERT_RET(etError    != iRes, FALSE);
	/*DEBUG*/XASSERT_RET((INT)cChar == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteStringToStdout (Write string to stdout)
BOOL CXStdioFile::bWriteStringToStdout(const tstring &csStr) {
	INT iRes = etError;
	
	iRes = _putts/*puts*/(csStr.c_str());
	/*DEBUG*/XASSERT_RET(etError < iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------

//TODO: Formatted input/output:

//---------------------------------------------------------------------------
//TODO: + iFprintf(Write formatted output to stream)
INT CXStdioFile::iFprintf(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,   etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);
	
    iRes = _vftprintf/*vfprintf*/(_m_pFile, pcszFormat, args);
    /*DEBUG*/XASSERT_RET(etError < iRes, etError);
    
    va_end(args);
    
    return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iPrintf (Print formatted data to stdout)
INT CXStdioFile::iPrintf(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = _vtprintf/*vprintf*/(pcszFormat, args);
	/*DEBUG*/////////////////////////////////////XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iSprintf(Write formatted data to string)
INT CXStdioFile::iSprintf(LPTSTR pszStr, LPCTSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = _vstprintf/*vsprintf*/(pszStr, pcszFormat, args);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iVfprintf (Write formatted variable argument list to stream)
INT CXStdioFile::iVfprintf(LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,   etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vftprintf/*vfprintf*/(_m_pFile, pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iVprintf (Print formatted variable argument list to stdout)
INT CXStdioFile::iVprintf(LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vtprintf/*vprintf*/(pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: iVsprintf (Print formatted variable argument list to string)
INT CXStdioFile::iVsprintf(LPTSTR pszStr, LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vstprintf/*vsprintf*/(pszStr, pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------



//Error-handling:


//---------------------------------------------------------------------------
//TODO: + bClearErr (Clear error indicators)
BOOL CXStdioFile::bClearErr() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
    clearerr(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsEof (Check End-of-File indicator)
BOOL CXStdioFile::bIsEof() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
 
    return (BOOL)feof(_m_pFile);
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
//TODO: + bIsError (Check error indicator)
BOOL CXStdioFile::bIsError() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
    BOOL bRes = FALSE;
    
    bRes = (BOOL)ferror(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}		
//---------------------------------------------------------------------------
//TODO: + bPrintError (Print error message)
BOOL CXStdioFile::bPrintError(const tstring &csStr) {
    _tperror(csStr.c_str());
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: - vecsReadFile (---------------)
/*static*/std::vector<tstring> CXStdioFile::vecsReadFile(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),    std::vector<tstring>());
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePath), std::vector<tstring>());

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	XASSERT_RET(FALSE != bRes, std::vector<tstring>());

	std::vector<tstring> vecRes;
	tstring              sStr;
	tifstream            ifsStream(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(ifsStream,           std::vector<tstring>());
	/*DEBUG*/XASSERT_RET(!ifsStream.fail(),   std::vector<tstring>());
	/*DEBUG*/XASSERT_RET(ifsStream.good(),    std::vector<tstring>());
	/*DEBUG*/XASSERT_RET(ifsStream.is_open(), std::vector<tstring>());
	/*DEBUG*/XASSERT_RET(!ifsStream.eof(),    std::vector<tstring>());	

	////CXPerform   P("__TEST.test", CXPerform::pmGetTickCount);
	/*SPEED*/////P.bStart();
	
	for (INT i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		vecRes.push_back(sStr);
	}

	/*SPEED*/////P.bStop("CXStdioFile::vecsReadFile ---> ");

	return vecRes;
}
//--------------------------------------------------------------------------
//TODO: - bReadFile
/*static*/BOOL CXStdioFile::bReadFile(const tstring &csFilePath, std::vector<TCHAR> *pvecchVector) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePath), FALSE);
	/*DEBUG*/XASSERT_RET(NULL  != pvecchVector,          FALSE);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	XASSERT_RET(FALSE != bRes, FALSE);

	tifstream ifsStream(csFilePath.c_str(), std::ios::in | std::ios::binary);
	/*DEBUG*/XASSERT_RET(ifsStream,           FALSE);
	/*DEBUG*/XASSERT_RET(!ifsStream.fail(),   FALSE);
	/*DEBUG*/XASSERT_RET(ifsStream.good(),    FALSE);
	/*DEBUG*/XASSERT_RET(ifsStream.is_open(), FALSE);
	/*DEBUG*/XASSERT_RET(!ifsStream.eof(),    FALSE);

	size_t uiSize = 0;

	if (ifsStream.seekg(0, std::ios::end)) {
		uiSize = ifsStream.tellg();
	}

	if (uiSize && ifsStream.seekg(0, std::ios::beg)) {
		(*pvecchVector).resize(uiSize);
		ifsStream.read(&((*pvecchVector))[0], uiSize);
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: - mapReadFile (���������� ����� Name1=Value1\r\r\nName2=Value2\r\n...)
/*static*/std::map<tstring, tstring> CXStdioFile::mapReadFile(const tstring &csFilePath, const tstring &csDelimiter) {
	/*DEBUG*//*TODO: BC++*///XASSERT_RET(false == csFilePath.empty(),               (std::map<tstring, tstring>()));
	/*DEBUG*//*TODO: BC++*///XASSERT_RET(TRUE  == bAccess(csFilePath, amExistence), (std::map<tstring, tstring>()));
	
	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	//////////////////////////XASSERT_RET(FALSE != bRes, (std::map<tstring, tstring>()));
	
	std::map<tstring, tstring> mapLines;
	tstring                    sStr;
	tifstream                  ifsStream(csFilePath.c_str());
	/*DEBUG*//*BC++*///XASSERT_RET(ifsStream,           (std::map<tstring, tstring>()));
	/*DEBUG*//*BC++*///XASSERT_RET(!ifsStream.fail(),   (std::map<tstring, tstring>()));
	/*DEBUG*//*BC++*///XASSERT_RET(ifsStream.good(),    (std::map<tstring, tstring>()));
	/*DEBUG*//*BC++*///XASSERT_RET(ifsStream.is_open(), (std::map<tstring, tstring>()));
	/*DEBUG*//*BC++*///XASSERT_RET(!ifsStream.eof(),    (std::map<tstring, tstring>()));

	////setlocale(LC_ALL, "Russian");
	
	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);

		std::vector<tstring> vecsLine = vecsSplit(sStr, csDelimiter);

		mapLines[vecsLine.at(0)] = vecsLine.at(1);
	}

	return mapLines;
}
//--------------------------------------------------------------------------
//TODO: - bReadFile (Writes csStr and then writes '\n' to the file)
/*static*/BOOL CXStdioFile::bReadFile(const tstring &csFilePath, tstring &cStr) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	XASSERT_RET(FALSE != bRes, FALSE);
	
	tifstream  ifsStream(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(ifsStream,           FALSE);
	/*DEBUG*/XASSERT_RET(!ifsStream.fail(),   FALSE);
	/*DEBUG*/XASSERT_RET(ifsStream.good(),    FALSE);
	/*DEBUG*/XASSERT_RET(ifsStream.is_open(), FALSE);
	/*DEBUG*/XASSERT_RET(!ifsStream.eof(),    FALSE);

	tstring sTemp;
	
	cStr.clear();
	for (; !ifsStream.eof(); ) {
		std::getline(ifsStream, sTemp);
		cStr.append(sTemp);
		cStr.append(csEOL);
	}

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _iGetHandle (Gets the file descriptor associated with a stream)
INT CXStdioFile::_iGetHandle() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, etError);
    
    INT iRes = etError;
    
	iRes = _fileno(_m_pFile);
	/*DEBUG*/XASSERT_RET(etError != iRes, etError);
	
	return iRes; 
}
//---------------------------------------------------------------------------