/****************************************************************************
* Class name:  CXMimeBody
* Description: ���� ��������� ������ (RFC 822)
* File name:   CXMimeBody.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.07.2009 19:11:02
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CXMimeBody.h>
//---------------------------------------------------------------------------
CXMimeBody::CXMimeBody() {
	//code
}
//---------------------------------------------------------------------------
CXMimeBody::~CXMimeBody() {
	//code
}
//---------------------------------------------------------------------------
