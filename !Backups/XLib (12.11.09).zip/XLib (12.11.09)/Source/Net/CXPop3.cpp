/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

   

//---------------------------------------------------------------------------
#include <XLib/Net/CXPop3.h> 

#include <stdio.h>   
#include <string>   
#include <iostream>
#include <XLib/Debug/xassert.h>   
#include <XLib/CXString.h>
#include <XLib/Fso/CXStdioFile.h>
//---------------------------------------------------------------------------  


/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + CXPop3 
CXPop3::CXPop3() :
	_m_sUser     (""), 
	_m_sPass     (""), 
	_m_sServer   (""), 
	_m_usPort    (0),
	_m_bConnected(FALSE)
{ 
	CXTcpClientSocket::bInit();
}   
//--------------------------------------------------------------------------- 
//TODO: + ~CXPop3 
CXPop3::~CXPop3() {   
	if (TRUE == _m_bConnected) {
		bDisconnect();
	}
	
	CXTcpClientSocket::bClean();   
}   
//--------------------------------------------------------------------------- 
//TODO: + bCreate 
BOOL CXPop3::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort) {  
	 /*DEBUG*/XASSERT_RET(FALSE == csUser.empty(),          FALSE);
	 /*DEBUG*/XASSERT_RET(FALSE == csPass.empty(),          FALSE);
	 /*DEBUG*/XASSERT_RET(FALSE == csServer.empty(),        FALSE);
	 /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	 _m_sUser   = csUser;   
	 _m_sPass   = csPass;   
	 _m_sServer = csServer;   
	 _m_usPort  = usPort;   

	 return TRUE;  
}   
//--------------------------------------------------------------------------- 
//TODO: + bConnect  
BOOL CXPop3::bConnect() {   
	 BOOL        bRes = FALSE;
	 std::string sRes = "";

	 //-------------------------------------
	 //Create sock   
     bRes = _m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);  
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //Parse domain   
     std::string sIpAddr = "";

	 bRes = CXTcpClientSocket::bDnsParse(_m_sServer, /*ref*/sIpAddr);
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //Connect   
	 bRes = _m_scktSocket.bConnect(sIpAddr, _m_usPort);
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //[welcome message] 
     sRes = _m_scktSocket.sRecvAll(0, "\r\n");   
	 /*DEBUG*/XASSERT_EX_RET(FALSE == _bIsError(sRes), sRes, FALSE); //��� "+OK"
    
    _m_bConnected = TRUE;
    
     return TRUE;   
 }  
//---------------------------------------------------------------------------   
//TODO: + bLogin 
BOOL CXPop3::bLogin() {  
	//-------------------------------------
	//RFC
	/*
	�: USER frated 
	S: -ERR sorry, no mailbox for frated here

	��� 

	�: USER mrose
	S: +OK mrose is a real hoopy frood
	*/

	/*
	�: USER mrose 
	S: +OK mrose is a real hoopy frood
	�: PASS secret
	S: -ERR maildrop already locked

	���

	�: USER mrose 
	S: +OK mrose is a real hoopy frood
	C: PASS secret
	S: +OK mrose's maildrop has 2 messages (320 octets)
	*/
	
	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[USER user\r\n]
	const std::string sUserCmd = "USER " + _m_sUser + "\r\n";

	bRes = _bCommand(sUserCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//[PASS\r\n]   
	std::string sPassCmd = "PASS " + _m_sPass + "\r\n";
	
	bRes = _bCommand(sPassCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE; 
} 
//---------------------------------------------------------------------------
//TODO: + bStat     
BOOL CXPop3::bStat(ULONG &ulSum, ULONG &ulSize) { 
	//-------------------------------------
	//RFC
	/*
	�: STAT
	S: +�� 2 320
	*/

	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[LIST\r\n]   
	const std::string sStatCmd = "STAT\r\n";

	bRes = _bCommand(sStatCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	ulSum  = _ulMailsSum (sRes);	//???????????????????????????
	ulSize = _ulMailsSize(sRes);

#ifdef _DEBUG   
	//+OK 2 1141841
	/*DEBUG*/_m_ConsoleLog.bWrite("Recv STAT Resp: MailsSum  = %u\n", ulSum); 
	/*DEBUG*/_m_ConsoleLog.bWrite("Recv STAT Resp: MailsSize = %u\n", ulSize);
#endif  

	return TRUE;       
}
//---------------------------------------------------------------------------
//TODO: bList (������ ��������, ������ �� �������)
BOOL CXPop3::bList(std::vector<ULONG> &veculList) {
	//-------------------------------------
	//RFC
	/*
	�: LIST
	S: +�� 2 messages (320 octets)
	S: 1 120
	S: 2 200
	S: .

	���

	�: LIST 2
	S: +�� 2 200

	���

	�: LIST 3
	S: -ERR no such message, only 2 messages in maildrop
	*/


	return FALSE;  
}	
//---------------------------------------------------------------------------
//TODO: bListAt (������ ������ � �������� ulIndex)   
BOOL CXPop3::bListAt(ULONG &ulIndex) {
	//-------------------------------------
	//RFC
	/*
	�: LIST
	S: +�� 2 messages (320 octets)
	S: 1 120
	S: 2 200
	S: .

	���

	�: LIST 2
	S: +�� 2 200

	���

	�: LIST 3
	S: -ERR no such message, only 2 messages in maildrop
	*/

	return FALSE;
}	
//---------------------------------------------------------------------------
//TODO: + bNoop (�������� ��������� ���������� � ����)   
BOOL CXPop3::bNoop() {
	//-------------------------------------
	//RFC
	/*
	�: NOOP
	S: +��
	*/

	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[NOOP\r\n]   
	std::string sNoopCmd = "NOOP\r\n";

	bRes = _bCommand(sNoopCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRset (������ ����� �������� �����)   
BOOL CXPop3::bRset() {
	//-------------------------------------
	//RFC
	/*
	�: RSET 
	S: +OK maildrop has 2 messages (320 octets)
	*/

	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[RSET\r\n]   
	std::string sRsetCmd = "RSET\r\n";

	bRes = _bCommand(sRsetCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bTop (�������� ��������� ������)   
BOOL CXPop3::bTop(INT iNum, INT iLines, std::string &sBuff) {
	/*DEBUG*/XASSERT_RET(iNum   > 0,   FALSE);
	/*DEBUG*/XASSERT_RET(iLines > - 1, FALSE);

	//-------------------------------------
	//RFC
	/*
	� ��� 1 10
	S +OK
	S <header>
	S <blank>
	S <message body>
	S .
	*/

	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[TOP 1 10\r\n]   
	std::string sTopCmd = "TOP " + lexical_cast(iNum) + " " + lexical_cast(iLines) + "\r\n";

	bRes = _bCommand(sTopCmd, "\r\n.\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	sBuff.assign(sRes);

	return TRUE; 
}
//---------------------------------------------------------------------------  
//TODO: + bRetriveRaw () 
BOOL CXPop3::bRetriveRaw(INT iNum, const std::string &csDirPath, const std::string &csFileName) {  //csDirPath ��� ����� 
	/*DEBUG*/XASSERT_RET(iNum > 0,                    FALSE);
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),  FALSE);
	/*DEBUG*/XASSERT_RET(false == csFileName.empty(), FALSE);

	//-------------------------------------
	//RFC
	/*
	�: RETR 1
	S: +�� 120 octets 
	S: <text message>
	S: .
	*/

	BOOL        bRes    = FALSE;
	std::string sRes    = "";

	//-------------------------------------
	//[RETR 3\r\n]
	const std::string sRetrCmd = "RETR " + lexical_cast(iNum) + "\r\n";
    
	bRes = _bCommand(sRetrCmd, "\r\n.\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//TODO: + ������� 1-�� ������ [+OK message 1 (652 octets)]
	size_t uiOkPos      = sRes.find("+OK");
	size_t uiFirstCRPos = sRes.find("\r\n");
	if (std::string::npos != uiOkPos && 0 == uiOkPos && std::string::npos != uiFirstCRPos) {
		sRes.erase(uiOkPos, uiFirstCRPos - uiOkPos + 2);	//"\r\n - 2 c������"
	} else {
		/*DEBUG*/XASSERT(FALSE);
	}	

	//-------------------------------------
	//TODO: + ������� [\r\n.\r\n]
	size_t uiEndOfMessagePos = sRes.rfind("\r\n.\r\n");
	if (std::string::npos != uiEndOfMessagePos) {
		sRes.erase(uiEndOfMessagePos, 5);	//"\r\n.\r\n" - 5 c������"
	} else {
		/*DEBUG*/XASSERT(FALSE);
	}		
	
	//-------------------------------------
	//��������� ���� �� ����
	CXStdioFile stdFile;
	
	bRes = stdFile.bOpen((csDirPath + "\\" + csFileName).c_str(), "wb");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	size_t uiWriteSize = stdFile.uiWrite(&sRes[0], sRes.size()); 
	/*DEBUG*///???
	
    return TRUE;  
}   
//---------------------------------------------------------------------------
//TODO: + bRetriveRawAndBackup ()
BOOL CXPop3::bRetriveRawAndBackup(INT iNum, const std::string &csDirPath, const std::string &csBackupDirPath, const std::string &csFileName) {
	/*DEBUG*/XASSERT_RET(iNum > 0,                                                         FALSE);
	/*DEBUG*/XASSERT_RET(! (true == csDirPath.empty() && true == csBackupDirPath.empty()), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFileName.empty(),                                      FALSE);
	
	//-------------------------------------
	//RFC
	/*
	�: RETR 1
	S: +�� 120 octets 
	S: <text message>
	S: .
	*/

	BOOL        bRes    = FALSE;
	std::string sRes    = "";

	//-------------------------------------
	//[RETR 3\r\n]
	const std::string sRetrCmd = "RETR " + lexical_cast(iNum) + "\r\n";

	bRes = _bCommand(sRetrCmd, "\r\n.\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//TODO: + ������� 1-�� ������ [+OK message 1 (652 octets)]
	size_t uiOkPos      = sRes.find("+OK");
	size_t uiFirstCRPos = sRes.find("\r\n");
	if (std::string::npos != uiOkPos && 0 == uiOkPos && std::string::npos != uiFirstCRPos) {
		sRes.erase(uiOkPos, uiFirstCRPos - uiOkPos + 2);	//"\r\n - 2 c������"
	} else {
		/*DEBUG*/XASSERT(FALSE);
	}	

	//-------------------------------------
	//TODO: + ������� [\r\n.\r\n]
	size_t uiEndOfMessagePos = sRes.rfind("\r\n.\r\n");
	if (std::string::npos != uiEndOfMessagePos) {
		sRes.erase(uiEndOfMessagePos, 5);	//"\r\n.\r\n" - 5 c������"
	} else {
		/*DEBUG*/XASSERT(FALSE);
	}		

	//-------------------------------------
	//��������� ���� �� ���� (��������), ���� ���� ���� - �� ���������
	if (false == csDirPath.empty()) {
		CXStdioFile stdfOriginal;

		bRes = stdfOriginal.bOpen((csDirPath + "\\" + csFileName).c_str(), "wb");
		CHECK_RET(FALSE == bRes, FALSE);

		size_t uiOriginalWriteSize = stdfOriginal.uiWrite(&sRes[0], sRes.size()); 
		CHECK_RET(0 == uiOriginalWriteSize, FALSE);
	}

	//-------------------------------------
	//��������� ���� �� ���� (�����), ���� ���� ���� - �� ���������
	if (false == csBackupDirPath.empty()) {
		CXStdioFile stdfBackup;

		bRes = stdfBackup.bOpen((csBackupDirPath + "\\" + csFileName).c_str(), "wb");
		CHECK_RET(FALSE == bRes, FALSE);

		size_t uiBackupWriteSize = stdfBackup.uiWrite(&sRes[0], sRes.size()); 
		CHECK_RET(0 == uiBackupWriteSize, FALSE);
	}

	return TRUE;  
}
//---------------------------------------------------------------------------
//TODO: + bRetrieveHeader ()
BOOL CXPop3::bRetrieveHeader(INT iNum, CXMimeHeader &mhMimeHeader) {
	/*DEBUG*/XASSERT_RET(iNum > 0, FALSE);

	//-------------------------------------
	//RFC
	/*
	� ��� 1 10
	S +OK
	S <header>
	S <blank>
	S <message body>
	S .
	*/

	BOOL        bRes  = FALSE;
	std::string sRes  = "";

	//-------------------------------------
	//[TOP 1 0\r\n]   
	std::string sTopCmd = "TOP " + lexical_cast(iNum) + " " + "0" + "\r\n";

	bRes = _bCommand(sTopCmd, "\r\n.\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//������ �����
	mhMimeHeader.bParse(sRes);

	return TRUE; 
}
//---------------------------------------------------------------------------
//TODO: + bDelete (������� ������)
BOOL CXPop3::bDelete(INT iNum) {
	/*DEBUG*/XASSERT_RET(iNum > 0, FALSE);

	//-------------------------------------
	//RFC
	/*
	�: DELE 1
	S: +�� message 1 deleted

	���

	�: DELE 2 
	S: -ERR message 2 already deleted
	*/

	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[DELE 2\r\n]   
	const std::string sDeleCmd = "DELE " + lexical_cast(iNum) + "\r\n";

	bRes = _bCommand(sDeleCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;     
}
//---------------------------------------------------------------------------
//TODO: + bDisconnect (������������� �� �������)
BOOL CXPop3::bDisconnect() {  
	//-------------------------------------
	//RFC
	/*
	[QUIT\r\n]
	+�� dewey POP3 server signing off
	*/
	
	BOOL        bRes = FALSE;
	std::string sRes = "";

	//-------------------------------------
	//[QUIT\r\n]  
	const std::string sQuitCmd = "QUIT\r\n";
	
	bRes = _bCommand(sQuitCmd, "\r\n", /*ref*/sRes);
	CHECK_RET(FALSE == bRes, FALSE);

	bRes = _m_scktSocket.bClose();
	CHECK_RET(FALSE == bRes, FALSE);
	
	_m_bConnected = FALSE;

	return TRUE; 
}   
//---------------------------------------------------------------------------
//TODO: + _ulMailsSum (������� ����� �����)
ULONG CXPop3::_ulMailsSum(const std::string &csServerAnswer) {
	/*DEBUG*/XASSERT_RET(false == csServerAnswer.empty(), FALSE);	

	//+OK 2 1141841
	ULONG       ulSum = 0;   
	std::string sSum  = ""; 
	
	sSum  = vecsSplit(csServerAnswer, " ").at(1); 
	ulSum = atol(sSum.c_str());		//!!! ul -> l
	
	return ulSum;
}
//---------------------------------------------------------------------------
//TODO: + _ulMailsSize (����� ������ ����� � ������)
ULONG CXPop3::_ulMailsSize(const std::string &csServerAnswer) {
	/*DEBUG*/XASSERT_RET(false == csServerAnswer.empty(), FALSE);	

	//+OK 2 1141841
	ULONG       ulSize = 0;   
	std::string sSize  = ""; 

	sSize  = vecsSplit(csServerAnswer, " ").at(2); 
	ulSize = atol(sSize.c_str());	//!!! ul+\r\n -> l

	return ulSize;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Private methods
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _bCommand ()
BOOL CXPop3::_bCommand(const std::string &csCmd, const std::string &csReplyDelimiter, std::string &sReply) {
	/*DEBUG*/XASSERT_RET(false == csCmd.empty(),            FALSE);	
	/*DEBUG*/XASSERT_RET(false == csReplyDelimiter.empty(), FALSE);	

	BOOL        bRes = FALSE;
	std::string sRes = "";

	bRes = _m_scktSocket.bSendAll(csCmd, 0);
	/*DEBUG*/XASSERT_RET(TRUE == bRes, FALSE);

	sRes = _m_scktSocket.sRecvAll(0, csReplyDelimiter);
	/*DEBUG*/XASSERT_EX_RET(FALSE == _bIsError(sRes), sRes, FALSE);

	sReply.assign(sRes);
	
#ifdef _DEBUG   
	/*DEBUG*/_m_ConsoleLog.bWrite("Command :  %s          Response: %s\n", csCmd.c_str(), sRes.c_str());
#endif 

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: + _bIsError ()
BOOL CXPop3::_bIsError(const std::string &csText) {
	/*DEBUG*/XASSERT_RET(FALSE == csText.empty(), TRUE);

	if (0 == memcmp(csText.c_str(), "+OK", 3)) {
		return FALSE;
	} 
	if (0 == memcmp(csText.c_str(), "-ERR", 4)) {
		return TRUE;
	} 
	
	/*DEBUG*/XASSERT_RET(FALSE, TRUE);
}
//---------------------------------------------------------------------------