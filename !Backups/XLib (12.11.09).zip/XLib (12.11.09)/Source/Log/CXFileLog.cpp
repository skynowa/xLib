/****************************************************************************
* Class name:  CXFileLog
* Description: ����������� � ����
* File name:   CXFileLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:40:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXFileLog.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Sync/CXLockScope.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXStdioFile.h>
//---------------------------------------------------------------------------
CXFileLog::CXFileLog() : 
	_m_sLogPath(""), 
	_m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);

	//�� ������ ���� (��� �����)
	_m_sLogPath      = CXPath::sChangeFileExt(CXPath::sExePath(), "exe.log");
	_m_ulMaxFileSize = DEFAULT_MAX_LOG_SIZE;
}
//---------------------------------------------------------------------------
CXFileLog::CXFileLog(const std::string &csFilePath, ULONG ulMaxFileSize): 
	_m_sLogPath(""), 
	_m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > ulMaxFileSize);
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);

	//��� ����� - �� �������� "\"
	if (std::string::npos == csFilePath.find("\\")) {
		//�� ������ ���� (��� �����)
		_m_sLogPath      = CXPath::sExtractFileDir(CXPath::sExePath()) + "\\" + csFilePath/* + ".log"*/;
		_m_ulMaxFileSize = ulMaxFileSize;
	} else {
		//������ ����
		_m_sLogPath      = csFilePath;
		_m_ulMaxFileSize = ulMaxFileSize;
	}
}
//---------------------------------------------------------------------------
CXFileLog::~CXFileLog() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXFileLog::bWrite(LPCSTR pcszFormat, ...) {   
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	bRes = _bDeleteIfFull();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%.2d:%.2d:%.2d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXLockScope SL(_m_csFile);

	CXStdioFile sfFile;

	bRes = sfFile.bOpen(_m_sLogPath, "a");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	sfFile.iFprintf("%s %s\n", sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bOpen() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec(_m_sLogPath);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bClear() {
	BOOL bRes = FALSE;

	/*LOCK*/CXLockScope SL(_m_csFile);

	CXStdioFile sfFile;
	
	bRes = sfFile.bOpen(_m_sLogPath, "w");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	
	sfFile.iFprintf("");

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bDelete() {
	BOOL bRes = FALSE;

	/*LOCK*/CXLockScope SL(_m_csFile);

	bRes = CXStdioFile::bRemove(_m_sLogPath);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/


//---------------------------------------------------------------------------
BOOL CXFileLog::_bDeleteIfFull() {
	BOOL bRes = FALSE;

	/*LOCK*/CXLockScope SL(_m_csFile);

	bRes = CXStdioFile::bIsExists(_m_sLogPath);
	CHECK_RET(FALSE == bRes, TRUE);

	CXStdioFile sfFile;
	LONG        liSize = CXStdioFile::ppError;

	bRes = sfFile.bOpen(_m_sLogPath, "r");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	liSize = sfFile.liGetSize();
	/*DEBUG*/XASSERT_RET(CXStdioFile::ppError != liSize, FALSE);

	bRes = sfFile.bClose();
	/*DEBUG*/XASSERT_RET(CXStdioFile::ppError != liSize, FALSE);

	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ULONG)(liSize / 1000000) >= _m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		bRes = CXStdioFile::bRemove(_m_sLogPath);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------