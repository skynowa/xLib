/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXPathH
#define XLib_Fso_CXPathH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <vector>
//---------------------------------------------------------------------------
class CXPath : public CXNonCopyable {
	public:	
								   CXPath                   ();
								  ~CXPath                   ();

	   static tstring			   sExePath                 ();
	   static tstring              sExeDirPath              ();
	   static tstring              sExtractFullFileName     (const tstring &csFilePath);
	   static tstring              sExtractFileName         (const tstring &csFilePath);
	   static tstring              sExtractFileExt          (const tstring &csFilePath);
	   static tstring              sExtractFileDir          (const tstring &csFilePath);
	   static tstring              sExtractFileDrive        (const tstring &csFilePath);
	   static tstring              sExtractRelativePath     (const tstring &csFilePath); /*....*/
	   static tstring              sAddSlash                (const tstring &csDirPath);
	   static tstring              sDeleteSlash             (const tstring &csDirPath);
	   /*ExpandUNCFileName	���������� ������ ��� ����� �� ������� �����.*/
	   /*ExtractShortPathName	������������ ������� ��� ����� � ������ DOS.*/
	   /*ProcessPath	��������� �� ������� ����� ����� ��� �����, ��� �������� � ��� �����.*/
	   static tstring              sChangeFileExt           (const tstring &csFilePath, const tstring &csFileExt);
	   static tstring              sChangeFullFileName      (const tstring &csFilePath, const tstring &csFileName);
	   static tstring              sRemoveFileExt           (const tstring &csFilePath);
	   static tstring              sRemoveFileExtIf         (const tstring &csFilePath, const tstring &csFileExt);
	   static tstring              sMakeValidFileName       (const tstring &csFileName);

	   static tstring              sGetEnvironmentVariable  (const tstring &csVar);
	   static BOOL                 bSetEnvironmentVariable  (const tstring &csVar, const tstring &csValue);
	   static std::vector<tstring> vecsGetEnvironmentStrings();
	   static tstring              sExpandEnvironmentStrings(const tstring &csvVar);

	   static tstring              sUnixToWinPath           (const tstring &csUnixPath, BOOL bNeedBackslashAtEnd);
	   static tstring              sWinToUnixPath           (const tstring &csWinPath,  BOOL bNeedBackslashAtEnd);

	   static tstring              sMinimizeFileName        (const tstring &csStr,  const size_t cuiMaxLen);
	   static tstring              sMinimizePath            (const tstring &csPath, const size_t cuiMaxLen);
	   
	   //normalize
	private:	   
		//////{$IFDEF MSWINDOWS}
		////static const tstring       ms_csWinSlash;
		////static const tstring       ms_csUnixSlash;
		////static const tstring       ms_csPathDelim;
		////static const tstring       ms_csDriveDelim;
		////static const tstring       ms_csPathSep;
		////static const tstring       ms_csDot;
		////static const tstring       ms_csAllFilesMask;  
		//////{$ENDIF MSWINDOWS}
		//////{$IFDEF UNIX}
		//////	PathDelim    = '/';
		//////	AllFilesMask = '*';
		//////{$ENDIF UNIX}
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXPathH
