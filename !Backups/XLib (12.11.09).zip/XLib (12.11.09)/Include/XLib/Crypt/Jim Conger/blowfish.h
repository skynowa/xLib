// blowfish.h     interface file for blowfish.cpp
// _THE BLOWFISH ENCRYPTION ALGORITHM_
// by Bruce Schneier
// Revised code--3/20/94
// Converted to C++ class 5/96, Jim Conger
// http://www.schneier.com/blowfish-download.html


#ifndef CXBlowFish_by_Jim_Conger_H
#define CXBlowFish_by_Jim_Conger_H
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
#define MAXKEYBYTES 	56		// 448 bits max
#define NPASS           16		// SBox passes
//---------------------------------------------------------------------------
class CXBlowFish {
	public:
			   CXBlowFish       ();
			  ~CXBlowFish       ();
		
		VOID   vInitialize      (UCHAR ucKey[], INT iKeybytes);
		VOID   vInitialize      (const std::string &csKey);
		ULONG  ulGetOutputLength(ULONG lInputLong);								//added for XLib
		ULONG  ulEncode         (UCHAR *pInput, UCHAR *pOutput, ULONG lSize);
		VOID   vDecode          (UCHAR *pInput, UCHAR *pOutput, ULONG lSize);
		BOOL   bEncode          (const std::string &csIn, std::string *psOut);	//added for XLib
		BOOL   bDecode          (const std::string &csIn, std::string *psOut);	//added for XLib

	private:
		ULONG *PArray;
		ULONG  (*SBoxes)[256];
		VOID   Blowfish_encipher(ULONG *xl, ULONG *xr);
		VOID   Blowfish_decipher(ULONG *xl, ULONG *xr);
};
//---------------------------------------------------------------------------
// choose a byte order for your hardware
#define ORDER_DCBA	// chosing Intel in this case

#ifdef ORDER_DCBA  	// DCBA - little endian - intel
	union aword {
	  ULONG dword;
	  UCHAR byte [4];
	  struct {
	    unsigned int byte3:8;
	    unsigned int byte2:8;
	    unsigned int byte1:8;
	    unsigned int byte0:8;
	  } w;
	};
#endif

#ifdef ORDER_ABCD  	// ABCD - big endian - motorola
	union aword {
	  ULONG dword;
	  UCHAR byte [4];
	  struct {
	    unsigned int byte0:8;
	    unsigned int byte1:8;
	    unsigned int byte2:8;
	    unsigned int byte3:8;
	  } w;
	};
#endif

#ifdef ORDER_BADC  	// BADC - vax
	union aword {
	  ULONG dword;
	  UCHAR byte [4];
	  struct {
	    unsigned int byte1:8;
	    unsigned int byte0:8;
	    unsigned int byte3:8;
	    unsigned int byte2:8;
	  } w;
};
#endif
//---------------------------------------------------------------------------
#endif //