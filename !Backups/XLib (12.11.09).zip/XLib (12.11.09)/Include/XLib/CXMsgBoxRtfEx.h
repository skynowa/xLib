/****************************************************************************
* Class name:  NMsgBoxRtf
* Description: ������ ���� � RTF-�� �������
* File name:   NMsgBoxRtf.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     08.05.2009 12:38:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef NMsgBoxRtf_H
#define NMsgBoxRtf_H

#include <windows.h>
#include <richedit.h>
#include <string>
//---------------------------------------------------------------------------
namespace NMsgBoxRtf {
    enum EXMsgRes {mrNone = 0, mrAbort = 1, mrRetry = 2, mrIgnore = 3, mrCopyToClip = 4};

	INT         g_iRes           = mrNone;
	tstring     g_sTitle         = _T(""); 
	tstring     g_sMessage       = _T(""); 
	
	const INT   ID_staImg        = 200;           
	const INT   ID_redtText      = 201;
	const INT   ID_btnAbort      = 202;
	const INT   ID_btnRetry      = 203;
	const INT   ID_btnIgnore     = 204;
	const INT   ID_btnCopyToClip = 205;
	
	HWND        g_hMainWnd       = NULL;
	HINSTANCE   g_hInst          = NULL/*::GetModuleHandle(NULL)*/;
	HFONT       g_hFont          = NULL;
	HWND        g_hStaImg        = NULL;	
	HWND        g_hRedtText      = NULL;	
	HWND	    g_hBtnAbort      = NULL;	
	HWND	    g_hBtnBreak      = NULL;	
	HWND	    g_hBtnIgnore     = NULL;
	HWND	    g_hBtnCopyToClip = NULL;	

	const INT   iLeft            = 150;
	const INT   iTop             = 100;
	const INT   iWidth           = 250;
	const INT   iHeight          = 130;

	const INT   iBtnWidth        = 75;
	const INT   iBtnHeight       = 25;
	const INT   iBtnShift        = 100;
	const INT   iRichEdtShift    = 68;
	
	const INT   iBtnLeftMargin   = 75;
	const INT   iBtnSpace        = 8;
	
	//---------------------------------------------------------------------------
	void vCreateDlgContent(HWND hParent) {
		g_hFont = (HFONT)::SendMessage(g_hMainWnd, WM_GETFONT, 0, 0);

		//-------------------------------------
		//������
		g_hStaImg = ::CreateWindowEx(
							0x00000000, 
							_T("Static"), 
							_T("ID_staImg"), 
							WS_CHILD | WS_VISIBLE | SS_ICON | SS_CENTER | SS_RIGHT | SS_CENTERIMAGE | SS_NOTIFY, 
							16, 16, 56, 40, 
							hParent, 
							(HMENU)ID_staImg, 
							g_hInst, 
							NULL);
		::SendMessage(g_hStaImg, WM_SETFONT, (WPARAM)g_hFont, TRUE);
		::SendMessage(g_hStaImg, STM_SETICON, (WPARAM)::LoadIcon(NULL, IDI_ERROR), 0);

		//-------------------------------------
		//��������� ���� (RICHEDIT)
		g_hRedtText = ::CreateWindowEx(
							0x00000000, 
							_T("RICHEDIT"), 
							_T(""), 
							WS_CHILD | WS_VISIBLE | ES_LEFT | ES_MULTILINE | ES_WANTRETURN | ES_READONLY, 
							90, 8, 400, 200, 
							hParent, 
							(HMENU) ID_redtText, 
							g_hInst, 
							NULL);
		::SendMessage(g_hRedtText, EM_SETBKGNDCOLOR, 0, ::GetSysColor(COLOR_3DFACE));
		::SendMessage(g_hRedtText, WM_SETFONT, (WPARAM)g_hFont, TRUE);
		::ShowScrollBar(g_hRedtText, SB_VERT/*SB_BOTH*/, TRUE);

		CHARRANGE cr = {0};
		cr.cpMin = ::GetWindowTextLength(g_hRedtText);
		cr.cpMax = ::GetWindowTextLength(g_hRedtText);

		::SendMessage(g_hRedtText, EM_EXSETSEL, 0, (LPARAM) &cr);
		::SendMessage(g_hRedtText, EM_REPLACESEL, (WPARAM)/*bCanUndo*/FALSE, (LPARAM)g_sMessage.c_str());

		//-------------------------------------
		//������ "Abort"
		g_hBtnAbort = ::CreateWindowEx(
							0x00000000, 
							_T("Button"), 
							_T("Abort"), 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							iBtnLeftMargin, 216, iBtnWidth, iBtnHeight, 
							hParent, 
							(HMENU)ID_btnAbort, 
							g_hInst, 
							NULL);
		::SendMessage(g_hBtnAbort, WM_SETFONT, (WPARAM)g_hFont, TRUE);

		//-------------------------------------
		//������ "Retry"
		g_hBtnBreak = ::CreateWindowEx(
							0x00000000, 
							_T("Button"), 
							_T("Break"), 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							iBtnLeftMargin + (iBtnWidth + iBtnSpace) * 1, 216, iBtnWidth, iBtnHeight, 
							hParent, 
							(HMENU)ID_btnRetry, 
							g_hInst, 
							NULL);
		::SendMessage(g_hBtnBreak, WM_SETFONT, (WPARAM)g_hFont, TRUE);

		//-------------------------------------
		//������ "Ignore"
		g_hBtnIgnore = ::CreateWindowEx(
							0x00000000, 
							_T("Button"), 
							_T("Ignore"), 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							iBtnLeftMargin + (iBtnWidth + iBtnSpace) * 2, 216, iBtnWidth, iBtnHeight,
							hParent, 
							(HMENU)ID_btnIgnore, 
							g_hInst, 
							NULL);			
		::SendMessage(g_hBtnIgnore, WM_SETFONT, (WPARAM)g_hFont, TRUE);
		
		//-------------------------------------
		//������ "Copy to clip"
		g_hBtnIgnore = ::CreateWindowEx(
							0x00000000, 
							_T("Button"), 
							_T("Copy"), 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							iBtnLeftMargin + (iBtnWidth + iBtnSpace) * 3, 216, iBtnWidth, iBtnHeight,
							hParent, 
							(HMENU)ID_btnCopyToClip, 
							g_hInst, 
							NULL);			
		::SendMessage(g_hBtnIgnore, WM_SETFONT, (WPARAM)g_hFont, TRUE);
	}
	//---------------------------------------------------------------------------
	BOOL CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
		switch(message)	{
							case WM_INITDIALOG:
								vCreateDlgContent(hDlg);	
								return TRUE;

							case WM_CLOSE:
								::EndDialog(hDlg,0);	
								return TRUE;

							case WM_COMMAND:
								{
									switch (LOWORD(wParam))	{
										case ID_btnAbort:
											g_iRes = NMsgBoxRtf::mrAbort;
											::SendMessage(hDlg, WM_CLOSE, 0, 0);
											return TRUE;
										case ID_btnRetry:
											g_iRes = NMsgBoxRtf::mrRetry;
											::SendMessage(hDlg, WM_CLOSE, 0, 0);
											return TRUE;
										case ID_btnIgnore:
											g_iRes = NMsgBoxRtf::mrIgnore;
											::SendMessage(hDlg, WM_CLOSE, 0, 0);
											return TRUE;
										case ID_btnCopyToClip:
											g_iRes = NMsgBoxRtf::mrCopyToClip;
											//�������� � ����� ������
											::SendMessage(g_hRedtText, WM_COPY, 0, 0L);
											return TRUE;
										
										////default:
										////	g_iRes = NMsgBoxRtf::mrNone;
										////	::SendMessage(hDlg, WM_CLOSE, 0, 0);
										////	return TRUE;
									}
									return TRUE;
								}
								return FALSE; //[C++ Warning] XLib/CXMsgBoxRtfEx.h(192): W8066 Unreachable code
		}
		return FALSE;
	}
	//---------------------------------------------------------------------------
	/*LRESULT*/INT iShow(HWND hwndOwner, const tstring &csMessage, const tstring &csTiltle) {
		HMODULE hmRichEdtDll = ::LoadLibrary(_T("RICHED32.DLL")); 

		HGLOBAL           hgbl  = INVALID_HANDLE_VALUE;
		LPDLGTEMPLATE     lpdt  = {0};
		LPDLGITEMTEMPLATE lpdit = {0};
		LPWORD            lpw   = NULL;
		LPWSTR            lpwsz = NULL;
		LRESULT           ret   = NULL;
		int               nchar = - 1;

		hgbl = ::GlobalAlloc(GMEM_ZEROINIT, 1024);
		if (NULL == hgbl) {
			return - 1; 
		}

		lpdt = (LPDLGTEMPLATE)::GlobalLock(hgbl);

		//-------------------------------------
		//������� dialog box
		lpdt->style = WS_POPUP | WS_BORDER | WS_SYSMENU | DS_MODALFRAME | WS_CAPTION;
		lpdt->cdit = 0;         // Number of controls
		lpdt->x  = iLeft;  
		lpdt->y  = iTop;
		lpdt->cx = iWidth; 
		lpdt->cy = iHeight;

		lpw = (LPWORD)(lpdt + 1);
		*lpw++ = 0;             // No menu
		*lpw++ = 0;             // Predefined dialog box class (by default)

		lpwsz = (LPWSTR)lpw;
		////TODO: nchar = 1 + ::MultiByteToWideChar(CP_ACP, 0, csTiltle.c_str(), -1, lpwsz, 50);
		nchar = 1 + csTiltle.size();
		lpw += nchar;

		g_sTitle     = csTiltle; 
		g_sMessage   = csMessage; 

		::GlobalUnlock(hgbl); 
		ret = ::DialogBoxIndirect(g_hInst, (LPDLGTEMPLATE)hgbl, hwndOwner, (DLGPROC)DialogProc); 
		::GlobalFree(hgbl); 

		::FreeLibrary(hmRichEdtDll);

		return /*ret*/g_iRes; 
	}
	//---------------------------------------------------------------------------
};
//---------------------------------------------------------------------------
#endif
