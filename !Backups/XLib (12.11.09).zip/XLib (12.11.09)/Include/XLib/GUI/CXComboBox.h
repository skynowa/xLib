/****************************************************************************
* Class name:  CXComboBox
* Description: ������ � ���������� �������
* File name:   CXComboBox.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 17:01:13
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXComboBoxH
#define XLib_Gui_CXComboBoxH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXComboBox: public CXWindow { 
	public:
				 CXComboBox  ();
				~CXComboBox  ();

		BOOL    bCreateRes   (INT iID, HWND hParent);
		BOOL    bAddString   (const tstring &csItem);
		BOOL    bResetContent();
		BOOL    bSetCurSel   (WPARAM wIndex);
		BOOL    bLoadFromFile(const tstring &csFilePath, INT iItemIndex = - 1);  
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXComboBoxH
