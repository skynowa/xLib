/****************************************************************************
* Class name:  CXListBox
* Description: 
* File name:   CXListBox.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 22:59:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXListBoxH
#define XLib_Gui_CXListBoxH
///---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
///---------------------------------------------------------------------------
class CXListBox: public CXWindow {
	public:
			 CXListBox           ();
			~CXListBox           ();

		BOOL bCreateRes(INT iID, HWND hParent);

		BOOL bAddString          (const tstring &csItem);
		BOOL bResetContent       ();
		BOOL bAddFile            (const tstring &csFileName);
		BOOL bDeleteString       (INT iStartIndex);
		BOOL bDir                (UINT uiDir);
		BOOL bFindString         (WPARAM wStartIndex, LPARAM lString);
		BOOL bFindStringExact    (WPARAM wStartIndex, LPARAM lString);
		BOOL bGetAnchorIndex     ();
		BOOL bGetCaretIndex      ();
		BOOL bGetCount           ();
		BOOL bGetCurSel          ();
		BOOL bGetHorizontalExtent();
		BOOL bGetItemData        (WPARAM wItemIndex);
		BOOL bGetItemHeight      (WPARAM wItemIndex);
		BOOL bGetItemRect        (WPARAM wItemIndex, LPARAM lRect);
		BOOL bGetListBoxInfo     ();
		BOOL bGetLocale          ();
		BOOL bGetSel             (WPARAM wItemIndex);
		BOOL bGetSelCount        ();
		BOOL bGetSelItems        (LPARAM lItems);
		BOOL bGetText            (WPARAM wItemIndex, LPARAM lItems);
		BOOL bGetTextLen         (WPARAM wItemIndex);
		BOOL bGetTopIndex        ();
		BOOL bInitStorage        (WPARAM wItemsCount, LPARAM lMem);
		BOOL bInsertString       (WPARAM wItemIndex, LPARAM lString);
		BOOL bItemFromPoint      (LPARAM lPoint);
		BOOL bSelectString       (WPARAM wStartIndex, LPARAM lString);
		BOOL bSelItemRange       (WPARAM wOption, LPARAM lFirstLastItems);
		BOOL bSelItemRangeEx     (WPARAM wFirstItem, LPARAM lLastItem);
		BOOL bSetAnchorIndex     (WPARAM wItemIndex);
		BOOL bSetCaretIndex      (WPARAM wItemIndex);
		BOOL bSetColumnWidth     (WPARAM wWidth);
		BOOL bSetCount           (WPARAM wCount);
		BOOL bSetCurSel          (WPARAM wItemIndex);
		BOOL bSetHorizontalExtent(WPARAM wScrollWidth);
		BOOL bSetItemData        (WPARAM wItemIndex, LPARAM lValue);
		BOOL bSetItemHeight      (WPARAM wItemIndex, LPARAM lHeight);
		BOOL bSetLocale          (WPARAM wLocaleIdentifier);
		BOOL bSetSel             (WPARAM wSelOption, LPARAM lItemIndex);
		BOOL bSetTabStops        (WPARAM wTabStopsNum, LPARAM lTabStopsArr);
		BOOL bSetTopIndex        (WPARAM wItemIndex);
		BOOL bVScroll            (WPARAM wPos);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXListBoxH