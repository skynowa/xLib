/****************************************************************************
* Class name:  CXFont
* Description: 
* File name:   CXFont.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.09.2009 13:45:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXFontH
#define CXFontH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXFont : public CXNonCopyable {
    public:
        	  CXFont     ();
        	 ~CXFont     ();
               
       	HFONT hGet       ();
		BOOL  bSet       (HFONT hFont);
		BOOL  bSetDefault();
		BOOL  bDelete    ();
    
    private:
        HFONT _m_hFont;
};
//---------------------------------------------------------------------------
#endif
