/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

    
//---------------------------------------------------------------------------
#include <stdio.h>   
#include <string>   
#include <iostream>   
#include "CXPop3.h"   
//---------------------------------------------------------------------------  


/****************************************************************************
*	Private methods
*
*****************************************************************************/



//---------------------------------------------------------------------------
CPop3::CPop3() {   
	WSocket::Init();   
}   
//--------------------------------------------------------------------------- 
CPop3::~CPop3() {   
	WSocket::iClean();   
}   
//--------------------------------------------------------------------------- 
 bool CPop3::bCreate(const char *pcszUser, const char *pcszPass, const char *pcszServer, unsigned short int usPort) {   
     strcpy(m_szUser,  pcszUser);   
     strcpy(m_szPass,  pcszPass);   
     strcpy(m_svraddr, pcszServer);   
     m_usPort = usPort;   
    
     return true;   
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bConnect() {   
     //Create sock   
     m_sock.bCreate(AF_INET, SOCK_STREAM, 0);   
    
     //Parse domain   
     char szIpAddr[16];		memset(&szIpAddr, 0, sizeof(szIpAddr));
	 if (true != WSocket::bDnsParse(m_svraddr, szIpAddr)) {   
         return false;   
	 }
    
     //Connect   
	 if (true != m_sock.bConnect(szIpAddr, m_usPort)) {  
         return false;   
	 }
    
     // Recv POP3 server welcome message   
     char szInBuff[128];		memset(&szIpAddr, 0, sizeof(szIpAddr));   
     int iRes = m_sock.iRecv(szInBuff, sizeof(szInBuff) - 1, 0);   
     if (iRes <= 0 || strncmp(szInBuff, "+OK", 3) != 0) {   
         return false;   
     }   
    
#ifdef _DEBUG   
     szInBuff[iRes] = '\0';   
     printf("Recv POP3  Resp: %s", szInBuff);   
#endif   
    
     return true;   
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bLogin() {   
     char szSendBuff[128];		memset(szSendBuff, 0, sizeof(szSendBuff));   
     char szRecvBuff[128];		memset(szRecvBuff, 0, sizeof(szRecvBuff));   
    
	 //USER
	 ::wsprintf(szSendBuff, "USER %s\r\n", m_szUser);   
     m_sock.iSend(szSendBuff, strlen(szSendBuff), 0);   
     int iRes = m_sock.iRecv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
     if (iRes <= 0 || strncmp(szRecvBuff, "+OK", 3) != 0 ) {   
         return false;   
     }   
        
#ifdef _DEBUG   
     szRecvBuff[iRes] = '\0';   
     printf("Recv USER Resp: %s", szRecvBuff);   
#endif     
        
     //PASS   
     ::wsprintf(szSendBuff, "PASS %s\r\n", m_szPass);   
     m_sock.iSend(szSendBuff, strlen(szSendBuff), 0);   
     iRes = m_sock.iRecv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
     if (iRes <= 0 || strncmp(szRecvBuff, "+OK", 3) != 0) {   
         return false;   
     }   
        
#ifdef _DEBUG   
     szRecvBuff[iRes] = '\0';   
     printf("Recv PASS Resp: %s", szRecvBuff);   
#endif         
    
     return true;   
}   
//---------------------------------------------------------------------------    
bool CPop3::bList(int &iSum) {   
     /* Send LIST command */   
     char szSendBuff[128];		  	memset(szSendBuff, 0, sizeof(szSendBuff));
     char szRecvBuff[100024];	    memset(szRecvBuff, 0, sizeof(szRecvBuff));  
    
     ::wsprintf(szSendBuff, "LIST\r\n");   
     int iSended =  m_sock.iSend(szSendBuff, strlen(szSendBuff), 0); 
	 /*DEBUG*/XASSERT(strlen(szSendBuff) == iSended);

	 int iRes = iPop3Recv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
     if (iRes <= 0 || strncmp(szRecvBuff, "+OK", 3) != 0) {   
         return false;   
     }   
     szRecvBuff[iRes] = '\0';   
    
#ifdef _DEBUG   
	printf("Recv LIST Resp: %s", szRecvBuff);   
#endif   
    
     iSum = iGetMailSum(szRecvBuff);   
        
     return true;       
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bFetch(char *pcszBuff, int num) {
     char szSendBuff[128];			memset(szSendBuff, 0, sizeof(szSendBuff));   
     char szRecvBuff[10240];		memset(szRecvBuff, 0, sizeof(szRecvBuff));  
    
     /* Send RETR command */   
     ::wsprintf(szSendBuff, "RETR %d\r\n", num);   
     m_sock.iSend(szSendBuff, strlen(szSendBuff), 0);   
     int rs = iPop3Recv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
     if (rs <= 0) {   
         return false;   
     }   
     szRecvBuff[rs] = '\0';   
    
 #ifdef _DEBUG   
     printf("Recv RETR Resp: %s", szRecvBuff);   
 #endif   
        
     /* Save mail to buffer */   
     char *p = strstr(szRecvBuff, "\r\n");   
     memcpy(pcszBuff, p + 2, strlen(p + 2) - 3);   
     pcszBuff[strlen(p + 2) -3] = '\0';   
    
     return true;   
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bFetchEx(int iNum) {   
     int          iRes = - 1;   
     FILE        *fp   = NULL;   
     int          flag = 0;   
     unsigned int len  = 0;   
	 char         szFilePath[32];			memset(&szFilePath, 0, sizeof(szFilePath));  
     char         szSendBuff[128];			memset(&szSendBuff,  0, sizeof(szSendBuff));  
     char         szRecvBuff[100240];		memset(&szRecvBuff,  0, sizeof(szRecvBuff)); 
  
     //Send RETR command  
     ::wsprintf(szSendBuff, "RETR %d\r\n", iNum);   
     int iSended = m_sock.iSend(szSendBuff, strlen(szSendBuff), 0);  
	 /*DEBUG*/XASSERT(strlen(szSendBuff) == iSended);
        
     do {   
         iRes = iPop3Recv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
         if (iRes < 0) {   
             return false;   
         }   
        
         szRecvBuff[iRes] = '\0';   
    
         //Get mail subject   
         if (0 == flag) {   
             bGetSubject(szFilePath, szRecvBuff);   
             /////strcat(filename, ".eml");  
			 ::wsprintf(szFilePath, "C:/!!!!!!!/Msg_%i.eml", iNum);
             flag = 1;   
             
			 fp = fopen(szFilePath, "wb");
			 if (NULL ==  fp) {   
                 return false; 
			 }
         }   
    
 #ifdef _DEBUG   
         ////printf("Recv RETR Resp: %s", recvbuf);   
 #endif   
    
         len = strlen(szRecvBuff);   
         if (len != fwrite(szRecvBuff, 1, len, fp)) {   
             fclose(fp);   
             return false;   
         }   
         fflush(fp);   
     } 
	 while ((char *)NULL == strstr(szRecvBuff, "\r\n.\r\n"));   
    
	 if (NULL != fp) {
		 fclose(fp);	fp = NULL;
	 }

     return true;   
 }   
 //---------------------------------------------------------------------------   
 bool CPop3::bQuit() {   
     char szSendBuff[128];			memset(szSendBuff, 0, sizeof(szSendBuff));   
     char szRecvBuff[128];			memset(szRecvBuff, 0, sizeof(szRecvBuff));   
    
     //Send QUIT command   
     ::wsprintf(szSendBuff, "QUIT\r\n");   
     m_sock.iSend(szSendBuff, strlen(szSendBuff), 0);   
     int iRes = m_sock.iRecv(szRecvBuff, sizeof(szRecvBuff) - 1, 0);   
     if (iRes <= 0 || strncmp(szRecvBuff, "+OK", 3) != 0 ) {   
         return false;   
     }   
        
 #ifdef _DEBUG   
     szRecvBuff[iRes] = '\0';   
     printf("Recv QUIT Resp: %s", szRecvBuff);   
 #endif     
    
     m_sock.iClose();   

     return true;   
 }   
 //---------------------------------------------------------------------------   
 bool CPop3::bGetSubject(char *pszSubject, const char *pcszBuf) {   
     const char *p = strstr(pcszBuf, "Subject: ");   
	 if (NULL == p) {  
         return false; 
	 }
    
     p = p + 9;   
     for (int i = 0; i < 32; i++) {   
         if (p[i] == '\r' || p[i] == '\n') {   
             pszSubject[i] = '\0';   
             break;   
         }  

         pszSubject[i] = p[i];   
     }   
    
     return true;   
 }   
 //---------------------------------------------------------------------------   
 bool CPop3::bWriteFile(const char *pcszFilePath, const char *pcszBuff, unsigned int uiSize) {   
     FILE *pFile = fopen(pcszFilePath, "wb"); 
	 /*DEBUG*/XASSERT(NULL != pFile);
	 if (NULL == pFile) {   
		return false;   
	 }
        
     if (1 != fwrite(pcszBuff, uiSize, 1, pFile)) {   
		 if (NULL != pFile) {
			 fclose(pFile); pFile = NULL;
		 }  
         return false;   
     }   
        
	 if (NULL != pFile) {
		 fclose(pFile); pFile = NULL;
	 }

     return true;   
 }   
 //---------------------------------------------------------------------------   
 int CPop3::iGetMailSum(const char *pcszBuff) {   
     int         iSum = 0;   
     const char *p    = strstr(pcszBuff, "\r\n");   
	 if (NULL == p) {   
         return iSum;
	 }
    
     p = strstr(p + 2, "\r\n");   
	 if (NULL == p) {   
         return iSum;
	 }
        
     while (NULL != (p = strstr(p + 2, "\r\n"))) {   
         iSum ++;   
     }   
    
     return iSum;   
 }
 //---------------------------------------------------------------------------



 /****************************************************************************
 *	Private methods
 *
 *****************************************************************************/


 //---------------------------------------------------------------------------
 int CPop3::iPop3Recv(char *pszInBuff, int iInBuffSize, int iFlags) {   
	 /*DEBUG*/XASSERT(NULL != pszInBuff);
	 /*DEBUG*/XASSERT(0     < iInBuffSize);

	 int iRes   = - 1;   
	 int iOffset = 0;   

	 do {   
		 if (iOffset > iInBuffSize - 2) { 
			 return iOffset;   
		 }

		 iRes = m_sock.iRecv(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		 if (iRes < 0) {  
			 /*DEBUG*/XASSERT(false);
			 return - 1;   
		 }

		 iOffset += iRes;   
		 pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	 } 
	 while ((char *)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	 return iOffset;   
 }   
 //---------------------------------------------------------------------------
bool CPop3::bIsError(char *pszText) {// if (arg > 1024) arg = 1024;
	 /*DEBUG*/XASSERT(NULL != pszText);
	 /*DEBUG*/XASSERT(0 < ::lstrlen(pszText));

	 //-------------------------------------
	 //CHECK
	 if (NULL == pszText) {		
		 return true;
	 }
	 if (0 == ::lstrlen(pszText)) {
		 return true;
	 }

	 //-------------------------------------
	 //JOB
	 if (0 == memcmp(pszText, "+OK", 3)) {
		 return false;
	 } 
	 ////if (rs <= 0 || strncmp(recvbuf, "+OK", 3) != 0) {   
		//// return false;   
	 ////} 

	 return true;
}
//---------------------------------------------------------------------------