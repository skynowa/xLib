/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXPop3H 
#define CXPop3H 
//---------------------------------------------------------------------------
#include "xassert.h"
#include "wsocket.h"
//---------------------------------------------------------------------------
class CPop3 { 
	public: 
                    	   CPop3      (); 
                    	  ~CPop3      (); 
		bool               bCreate    (const char *pcszUser, const char *pcszPass, const char *pcszServer, unsigned short int usPort = 110); 
		bool               bConnect   (); 
		bool               bLogin     (); 
		bool               bList      (int &iSum);	//STAT
		bool               bFetch     (char *pszBuff, int iNum = 1); 
		bool               bFetchEx   (int iNum = 1); 
		bool               bQuit      (); 
		bool			   bGetSubject(char *pszSubject, const char *pcszBuf); 
		static bool        bWriteFile (const char *pcszFilePath, const char *pcszBuff, unsigned int uiSize); 

	protected: 
		int                iGetMailSum(const char *pcszBuf); 

		WSocket            m_sock; 
		char               m_szUser [32]; 
		char               m_szPass [32]; 
		char               m_svraddr[32]; 
		unsigned short int m_usPort; 

	private: 
		int				   iPop3Recv  (char *pszInBuff, int iInBuffSize, int iFlags = 0); 
		bool               bIsError   (char *pszText); /*-*/  
}; 
//---------------------------------------------------------------------------
#endif 
