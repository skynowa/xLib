/****************************************************************************
*    �����: CXEvent (CXEvent.h)
*
*****************************************************************************/


#ifndef CXEventH
#define CXEventH
//---------------------------------------------------------------------------
#include <iostream>
#include <windows.h>
#include <process.h>
#include <assert.h>
//---------------------------------------------------------------------------
class CXEvent {
	public:


			                  CXEvent(PSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCSTR lpszName);
			                 ~CXEvent();
        HANDLE                hGetHandle();
		BOOL                  bCreate(PSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCSTR lpszName);
		BOOL                  bOpen  (DWORD dwAccess, BOOL bInheritHandle, LPCTSTR lpszName);
		BOOL                  bPulse ();
		BOOL                  bReset ();
		BOOL                  bSet     ();
        DWORD                 dwWaitForSingleObject(DWORD dwTimeout);
        //__property int LastError = {read=FLastError, nodefault};

	private:
		HANDLE                m_hEvent;
};
//---------------------------------------------------------------------------
#endif