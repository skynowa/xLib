/****************************************************************************
*
*
*****************************************************************************/


#ifndef CXUtils_H
#define CXUtils_H

#include <windows.h>
#include <string>
#include <sstream>

using namespace std;

class CXUtils {
	public:
		static string SizeToString(DWORD dwSize);
		static string ApplicationPath();
		static string FileExtension(string sFileName);
		static string FiletimeToString(LPFILETIME Filetime);
		static string DecodeFrequency(DWORD Frequency);
};

#endif
