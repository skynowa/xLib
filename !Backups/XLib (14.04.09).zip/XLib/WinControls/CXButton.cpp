/****************************************************************************
*
*
*****************************************************************************/


#include "CXButton.h"
//---------------------------------------------------------------------------
CXButton::CXButton() {
	_m_sClassName = "BUTTON";
	_m_iLeft      = 0;
	_m_iTop       = 0;
	_m_iWidth     = 75;
	_m_iHeight    = 23;
}
//---------------------------------------------------------------------------
BOOL CXButton::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	_m_hWnd = ::CreateWindowEx(
						dwExStyles, 
						_m_sClassName.c_str(),	
						_m_sText.c_str(),					
						WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP | dwStyles,		
						_m_iLeft,							
						_m_iTop,							
						_m_iWidth,							
						_m_iHeight,							
						hParent,							
						hmnuID,							
						(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
						this); 

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------