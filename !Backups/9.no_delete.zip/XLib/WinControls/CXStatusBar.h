/****************************************************************************
*	CXStatusBar
*
*****************************************************************************/


#ifndef CXStatusBar_H
#define CXStatusBar_H
//---------------------------------------------------------------------------
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
const int ciSB_MaxParts = 256; // MSDN 256 parts max
//---------------------------------------------------------------------------
class CXStatusBar: public CXSubclassWnd {
	public:
		      CXStatusBar  ();
		BOOL  Create      (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);
		void  SetSimple   (BOOL Simple);
		int   Height      ();
		BOOL  SetMinHeight(int iHeight);	//???????????
		int   AddPart     ();
		int   AddPart     (TCHAR *PartText);	
		int   AddPart     (TCHAR *PartText, HICON hIcon);
		int   AddPart     (TCHAR *PartText, HINSTANCE hInstance, int IdIcon);
		int   AddPart     (int Size);
		int   AddPart     (TCHAR *PartText, int Size);
		int   AddPart     (TCHAR *PartText, HICON hIcon, int Size);
		int   AddPart     (TCHAR *PartText, HINSTANCE hInstance, int IdIcon, int Size);
		int   AddPart     (HICON hIcon, int Size);
		BOOL  SetIcon     (int PartIndex, HICON hIcon);
		BOOL  SetIcon     (int PartIndex, HINSTANCE hInstance, int IdIcon);
		BOOL  SetText     (int PartIndex, TCHAR *PartText);
		BOOL  SetSize     (int PartIndex, int Size);
		BOOL  SetParts    (int iParts, int iSize);
	
	private:
		int   m_iDefaultSize;
		int   m_iPartsWidths[ciSB_MaxParts];
		int   m_iNumParts;
};
//---------------------------------------------------------------------------
#endif
