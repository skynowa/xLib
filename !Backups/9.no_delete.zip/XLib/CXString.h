/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef CXStringH
#define CXStringH  
//---------------------------------------------------------------------------
#include <windows.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <string>
//---------------------------------------------------------------------------
//-------------------------------------
//������ <--> �����
long                              StrToLONG        (LPCTSTR pszValue, long           Default = 0,  int Radix = 0);	/*+*/
unsigned long                     StrToDWORD       (LPCTSTR pszValue, unsigned long  Default = 0,  int Radix = 0);	/*+*/
unsigned int                      StrToUINT        (LPCTSTR pszValue, unsigned int   Default = 0,  int Radix = 0);	/*+*/
int                               StrToINT         (LPCTSTR pszValue, int            Default = 0,  int Radix = 0);	/*+*/
short                             StrToSHORT       (LPCTSTR pszValue, short          Default = 0,  int Radix = 0);	/*+*/
unsigned short                    StrToWORD        (LPCTSTR pszValue, unsigned short Default = 0,  int Radix = 0);	/*+*/
unsigned char                     StrToBYTE        (LPCTSTR pszValue, unsigned char  Default = 0,  int Radix = 0);	/*+*/
double                            StrToDOUBLE      (LPCTSTR pszValue, double         Default = 0.0);	/*+*/
BOOL                              StrToBOOL        (LPCTSTR pszValue, BOOL           Default = FALSE);	/*+*/
bool                              StrTobool        (LPCTSTR pszValue, bool           Default = false);	/*+*/
bool                              bStrToUCHAR      (const std::string &csStr, unsigned char *ucBuff, unsigned int uiBuffLen);	/*+*/
std::string                       sUCHARToStr      (unsigned char *ucBuff, unsigned int uiBuffLen);	/*+*/
template <typename T> std::string sTypeToStr       (T val) {		
														std::ostringstream oss;
														oss << val;
														
														return oss.str();
													};	/*+*/	

template<typename T> T            iStrToType(const std::string &�sStr) {
														std::istringstream iss(�sStr);
														T val;
														iss >> val;

														return val;
													};	/*+*/

std::string                       sInt64ToStr      (__int64 liVal);

std::string                       sTrimChar        (const std::string &csStr, char cChar); /*+*/
std::string                       sTrimSpace       (const std::string &csStr);	/*+*/
std::string                       sRemoveEOL       (const std::string &csStr);	/*+*/

std::string                       sReplaceAll      (std::string sStr, const std::string &csOldStr, const std::string &csNewStr); /*+*/
std::string						  sReplaceAll      (std::string &sStr, char sOldStr, char sNewStr); /*+*/

std::vector<std::string>          vecsExplode      (char cDelimiter, const std::string &sStr); /*+*/ 
std::vector<std::string>          vecsExplode      (const std::string &csSep,  const std::string &sStr); /*+*/
std::string                       sImplode         (char cSep, std::vector<std::string> vecsVec); /*+*/

std::string                       sUrlUnescape     (const std::string &csStr); /*+*/	//sBase64Decode
std::string                       sStrToBin        (const std::string &csStr); /*+*/
std::string                       sBinToStr        (const std::string &csStr); /*+*/

bool                              bCharToWide      (const char *pszSrc, wchar_t/*wchar*/ *pwszDest, int iDestSize);

bool                              bStrToFile       (const std::string &csStr, const std::string &csFilePath);	/*-*/
std::string                       bStrFromFile     (const std::string &csStr, const std::string &csFilePath);	/*-*/

std::string						  sTranslitLatToRus(const std::string &csStr);	/*+*/
bool                              bCharToWide      (const char *pszSrc, wchar_t *pwszDest, int iDestSize);	/*-*/

std::string						  sToLowerCase     (const std::string &csSrc);	/*+*/
std::string                       sToUpperCase     (const std::string &csSrc);	/*+*/
std::string						  sToLowerCase     (const std::string &csSrc, unsigned int uiPos);	/*-*/
std::string                       sToUpperCase     (const std::string &csSrc, unsigned int uiPos);	/*-*/

std::string                       sFormatStr       (const char *pcszFormat, ...); /*+*/
std::string                       sFormatStr2      (const char *pcszFormat, ...); /*+*/
std::string                       sMinimizeStr     (const std::string &csStr, const unsigned int cuiMaxLen); /*+*/

//-------------------------------------
//char
// This is ASCII specific but is safe with chars >= 0x80
bool                              bIsSpaceChar     (unsigned char ch);
bool                              bIsPunctuation   (char ch);
bool                              bIsADigit        (char ch);
bool                              bIsLowerCase     (char ch);
bool                              bIsUpperCase     (char ch);
bool                              bIsASpaceOrTab   (unsigned int ch);
bool                              bIsADigit        (unsigned int ch);
bool                              bIsADigit        (unsigned int ch, unsigned int base);
bool                              bIsLetter        (char ch);
bool                              bIsASpace        (unsigned int ch);
bool                              IsEOLChar        (char ch);
bool                              IsLineEndChar    (char c);

char                              cMakeUpperCase   (char ch);	//non-Unicode characters only
char                              cMakeLowerCase   (char ch);	//non-Unicode characters only

int                               iGetHexChar      (unsigned char hd1, unsigned char hd2);
char                              cHexToChar       (char *pszStr);
int								  iCharCodeAt      (const std::string &csStr, int nIndex);	/*+*/

//-------------------------------------
//������
unsigned int                      UTF8Length       (const wchar_t *uptr, unsigned int tlen);
void                              UTF8FromUTF16    (const wchar_t *uptr, unsigned int tlen, char *putf, unsigned int len);
unsigned int                      UTF16Length      (const char *s, unsigned int len);
unsigned int                      UTF16FromUTF8    (const char *s, unsigned int len, wchar_t *tbuf, unsigned int tlen);

std::string                       wstring2string   (std::wstring wstr);
std::wstring                      string2wstring   (std::string str);
bool                              bIsUnicode       (unsigned char *Data, int Size);
std::wstring                      wsStrToWstr      (const std::string &csSrc);
std::string                       sWstrToStr       (const std::wstring &cwsSrc);

std::wstring					  wsASCIIToUnicode (const std::string &csSrc);
std::string						  sUnicodeToASCII  (const std::wstring &cwsSrc);
//-------------------------------------
//���������
std::string						  sStrToRtf        (std::string sStr);
std::string						  sRtfToStr        (std::string sStr);
template<typename TText, typename TCaption> void vMsgBox(TText Text, TCaption Caption, unsigned long ulType = MB_OK) {			
														std::ostringstream ossText;		ossText << Text;
														std::ostringstream ossCaption;	ossCaption << Caption;

														::MessageBox(0, ossText.str().c_str(), ossCaption.str().c_str(), ulType);
													}; /*+*/
std::string                       sCreatePlainGUID (); /*+*/ 
bool                              bIsRepeatedStr   (const std::string &csStr); /*+*/
std::string						  sUrlEscape	   (const std::string &csStr);	//���������� �����
std::string						  sUrlUnescape     (const std::string &csStr);  //���������� �����


////////// Some ATL string conversion enhancements
////////// ATL's string conversions allocate memory on the stack, which can
////////// be undesirable if converting huge strings.  These enhancements
////////// provide for a pre-allocated memory block to be used as the 
////////// destination for the string conversion.
////////#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
////////#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)
////////
////////typedef std::wstring StringW;
////////typedef std::string  StringA;
////////
////////#ifdef _UNICODE
////////typedef StringW String;
////////#define _W2T(dst,src) lstrcpyW(dst,src)
////////#define _T2W(dst,src) lstrcpyW(dst,src)
////////#define _T2A(dst,src) _W2A(dst,src)
////////#define _A2T(dst,src) _A2W(dst,src)
////////#else
////////typedef StringA String;
////////#define _W2T(dst,src) _W2A(dst,src)
////////#define _T2W(dst,src) _A2W(dst,src)
////////#define _T2A(dst,src) lstrcpyA(dst,src)
////////#define _A2T(dst,src) lstrcpyA(dst,src)
////////#endif
//---------------------------------------------------------------------------
#endif