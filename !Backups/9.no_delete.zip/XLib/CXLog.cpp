/**********************************************************************
*	�����  CXLog (CXLog.cpp)  
*	
***********************************************************************/


#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf

#include "CXLog.h"

#include <stdio.h>
#include <stdlib.h>

#include "xassert.h"
#include "CXString.h"
#include "CXFsoString.h"
//---------------------------------------------------------------------------
CXLog::CXLog(const std::string &csFileName, unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/::InitializeCriticalSection(&m_csLog);
	/*LOCK*/::InitializeCriticalSection(&m_csLogToLst);

	if (std::string::npos != csFileName.find('\\')) {
		m_sLogPath = sExtractFilePath(sExePath()) + csFileName;
	} else {
		m_sLogPath = sExtractFilePath(sExePath()) + csFileName;
	}

	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::CXLog(unsigned long int ulMaxFileSize = 20) {
	/*LOCK*/::InitializeCriticalSection(&m_csLog);
	/*LOCK*/::InitializeCriticalSection(&m_csLogToLst);

	m_sLogPath      = sExtractFilePath(sExePath()) + "\\" + sExtractFullFileName(sExePath()) + ".log";
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	
	/*UNLOCK*/::DeleteCriticalSection(&m_csLog);
	/*UNLOCK*/::DeleteCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vLog
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csStr) {     
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csStr.c_str());

	fflush(pFile);						
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, const std::string &csStr) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csStr.c_str());	

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, int iValue) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %i\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), iValue);	

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLog(const std::string &csComment, unsigned long int ulValue) {
	this->vDeleteLogIfFull();
	
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %ul\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), ulValue);	//ul?????

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrorStr(const std::string &csComment, unsigned long int ulLastError) {
	this->vDeleteLogIfFull();

	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);

	fprintf(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), this->sErrorMessageStr(ulLastError));	

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogUCharAsHex(const std::string &csComment, unsigned char *pucBuff, unsigned long int ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes = "";   
	for (unsigned int i = 0; i < ulBuffSize; i ++) {
		if (pucBuff[i] < 16) {  
			char szTemp[6];		::ZeroMemory(&szTemp, sizeof(szTemp));
			::wsprintf(szTemp, "0x0%x ", pucBuff[i]);
			sRes.append(szTemp);
		} else {
			char szTemp[6];		::ZeroMemory(&szTemp, sizeof(szTemp)); 
			::wsprintf(szTemp, "0x%2x ", pucBuff[i]);
			sRes.append(szTemp);
	    }
	}

	//-------------------------------------
	//����� ���
	/**LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
	::GetLocalTime(&stST);
	
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
void CXLog::vLogUCharAsStr(const std::string &csComment, unsigned char *pucBuff, unsigned long int ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes; 
	for (unsigned int i = 0; i < ulBuffSize; i ++) {
		//sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
		sRes.push_back((char)pucBuff[i]);      //???????????
	}

 	//-------------------------------------
 	//����� ���
 	/*LOCK*/::EnterCriticalSection(&m_csLog);
 	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
 	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	fflush(pFile);
	fclose(pFile);	pFile = NULL;

 	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vTrace
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csStr) {
	::OutputDebugString((csStr + "\r\n").c_str());	//VERIFY
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csComment, const std::string &csStr) {
	::OutputDebugString((csComment + "--->" + csStr + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csComment, int iValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(iValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void CXLog::vTrace(const std::string &csComment, unsigned long int ulValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(ulValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
void CXLog::vTraceLastError(const std::string &csComment, unsigned long int ulLastError) {
	::OutputDebugString((csComment + "--->" + this->sErrorMessageStr(ulLastError) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csStr) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, const std::string &csStr) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, int iValue) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(iValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
void CXLog::vLogToLst(HWND hLst, const std::string &csComment, unsigned long int ulValue) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(ulValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
void CXLog::vLogLastErrorToLst(HWND hLst, const std::string &csComment, unsigned long int ulLastError) {
	/*DEBUG*/XASSERT(NULL != hLst);
	
	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + this->sErrorMessageStr(ulLastError);
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vDelete() {
	//-------------------------------------
	//CHECK
    if (bFileExists(m_sLogPath) == false) {
		return;
	}	

	//-------------------------------------
	//JOB
	if (false == bSetFileNormalAttr(m_sLogPath)) {
        /*DEBUG*/XASSERT(false);
    }
    if (false == bDeleteFile(m_sLogPath)) {
        /*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
void CXLog::vOpen() {
	STARTUPINFO si;				::ZeroMemory(&si, sizeof(STARTUPINFO));
	PROCESS_INFORMATION pi;     ::ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.2\\notepad++.exe " + m_sLogPath; 
	if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	::Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
void CXLog::vClear() {
	FILE *pFile = fopen(m_sLogPath.c_str(), "w");
	/*DEBUG*/XASSERT(NULL != pFile);
	
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	
	fprintf(pFile, "");	
	
	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);

	fflush(pFile);
	fclose(pFile);	pFile = NULL;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Other
*
*****************************************************************************/

//---------------------------------------------------------------------------
//void CXLog::vErrorMessageBox() {
//	LPVOID lpMsgBuf = NULL;
//	::FormatMessage( 
//		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
//		FORMAT_MESSAGE_FROM_SYSTEM | 
//		FORMAT_MESSAGE_IGNORE_INSERTS,
//		NULL,
//		GetLastError(),
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
//		(LPSTR) &lpMsgBuf,
//		0,
//		NULL
//	);
//	MessageBox(NULL, (LPCSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
//	LocalFree(lpMsgBuf);
//}
//---------------------------------------------------------------------------
void CXLog::vMsgBoxLastError(const std::string &csComment) {
	unsigned long int ulLastError = ::GetLastError();
	std::string       sRes        = csComment + " ---> " + this->sErrorMessageStr(ulLastError);

	::MessageBox(0, sRes.c_str(), "Last error", MB_OK);
}
//---------------------------------------------------------------------------




/****************************************************************************
*	Private methodz
*
*****************************************************************************/

//---------------------------------------------------------------------------
void CXLog::vDeleteLogIfFull() {
	//-------------------------------------
	//CHECK
	if (false == bFileExists(m_sLogPath)) {
		return;
	}
	
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ulFileSize(m_sLogPath) / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------
std::string CXLog::sErrorMessageStr(unsigned long ulLastError) {
	std::string sRes     = "";
	LPVOID      lpMsgBuf = NULL;

	::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
		(LPSTR) &lpMsgBuf,
		0,
		NULL
	);
	
	sRes = std::string((LPCSTR)lpMsgBuf);

	/*DEBUG*/XASSERT(NULL != lpMsgBuf);
	::LocalFree(lpMsgBuf); lpMsgBuf = NULL;

	return sRes;
}
//---------------------------------------------------------------------------