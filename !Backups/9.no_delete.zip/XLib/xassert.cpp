/****************************************************************************
*	xassert.cpp
*
*****************************************************************************/


#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#include <windows.h>
#include <string> 
#include "D:/XLib/CXFsoString.h"
#include "D:/XLib/CXMsgBoxRtf.h"

//---------------------------------------------------------------------------
void vAssert(const char *pcszExp, unsigned long int ulLastError, const char *pcszFile, unsigned long int ulLine, const char *pcszFunc, const char *pcszComment) {
	//-------------------------------------
	//���� � exe-�����
	TCHAR szExePath[MAX_PATH];	::ZeroMemory(szExePath, sizeof(szExePath));
	if (!::GetModuleFileName(::GetModuleHandle(NULL), szExePath, MAX_PATH) || 0 == ::lstrlen(szExePath)) {
		::MessageBox(0, "GetModuleFileName() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
		return;
	}

	//-------------------------------------
	//���� � ��� exe-�����
	TCHAR szExeName[MAX_PATH];	::ZeroMemory(szExeName, sizeof(szExeName));
	_splitpath(szExePath, NULL, NULL, szExeName, NULL);
	if (NULL == szExeName || 0 == ::lstrlen(szExeName)) {
		::MessageBox(0, "_splitpath() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� GetLastError()
	LPVOID lpMsgBuf = NULL;
	::FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPSTR)&lpMsgBuf,
		0,
		NULL);
	if (NULL == lpMsgBuf || 0 == ::lstrlen((LPSTR)lpMsgBuf)) {
		::MessageBox(0, "FormatMessage() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}	
	

    //-------------------------------------
	//����������� ���������
	const unsigned int cuiMsgSize = 20024; 
	TCHAR              szMsg[cuiMsgSize];	::ZeroMemory(szMsg, sizeof(szMsg));
    ////::wsprintf(szMsg,
			 ////"%s\n\n"
			 ////"%s:  %s\n"
			 ////"%s:  %s\n"
			 ////"%s:  %i\n"
			 ////"%s:  %s\n"
			 ////"%s:  %s\n"
			 ////"%s:  %s"		/*����� ���� \n �� ����*/
			 ////"%s:  %s",			 
			 ////
			 ////"Assertion failed.",
			 ////"Program",           sMinimizeName(szExePath, 75).c_str(),
			 ////"File",              sMinimizeName(pcszFile,  75).c_str(),
			 ////"Line",              ulLine,
			 ////"Function",          pcszFunc,
			 ////"Expression",        pcszExp,
			 ////"GetLastError()",    (LPSTR)lpMsgBuf,
			 ////"Comment",           pcszComment 
    ////);


	/*static std::string _sMsg = 
		"{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}"
		"{\\colortbl ;\\red255\\green0\\blue0;}"
		"\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 Assertion failed.\\ulnone\\b0\\par"
		"\\par"
		"\\b Program:\\b0   \\lang1033\\f1         \\cf1\\lang1049\\f0 d:\\\\...\\\\_MyProjects\\\\MyVC++\\\\Projects\\\\xassert\\\\Project\\\\Debug\\\\ConsoleTest.exe\\par"
		"\\cf0\\b File:\\b0   \\lang1033\\f1                 \\cf1\\lang1049\\f0 d:\\\\my\\\\coding\\\\!!!!!!!!\\\\_myprojects\\\\myvc++\\\\projects\\\\xassert\\\\project\\\\umain.cpp\\par"
		"\\cf0\\b Line:\\b0   \\lang1033\\f1                \\cf1\\lang1049\\f0 210\\cf0\\par"
		"\\b Function:\\b0  \\lang1033\\f1        \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 main\\cf0\\par"
		"\\b Expression:\\b0   \\lang1033\\f1      \\cf1\\lang1049\\f0 NULL != pTest\\cf0\\par"
		"\\b GetLastError():\\lang1033\\f1   \\cf1\\lang1049\\b0\\f0\\'ce\\'ef\\'e5\\'f0\\'e0\\'f6\\'e8\\'ff \\'f3\\'f1\\'ef\\'e5\\'f8\\'ed\\'ee \\'e7\\'e0\\'e2\\'e5\\'f0\\'f8\\'e5\\'ed\\'e0.\\cf0  \\par"
		"\\b Comment:\\b0  \\lang1033\\f1         \\cf1 xxx\\cf0\\lang1049\\f0\\par}";*/

	::wsprintf(szMsg,
		"{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}"
		"{\\colortbl ;\\red255\\green0\\blue0;}"
		"\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par"
		"\\par"
		"\\b %s\\b0   \\lang1033\\f1         \\cf1\\lang1049\\f0 %s\\par"
		"\\cf0\\b %s\\b0   \\lang1033\\f1                 \\cf1\\lang1049\\f0 %s\\par"
		"\\cf0\\b %s\\b0   \\lang1033\\f1                \\cf1\\lang1049\\f0 %i\\cf0\\par"
		"\\b %s\\b0  \\lang1033\\f1        \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par"
		"\\b %s\\b0   \\lang1033\\f1      \\cf1\\lang1049\\f0 %s\\cf0\\par"
		"\\b %s\\lang1033\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par"
		"\\b %s\\b0  \\lang1033\\f1         \\cf1 %s\\cf0\\lang1049\\f0\\par}",			 

		"Assertion failed.",
		"Program:",           (sWinToUnixPath(sMinimizePath(szExePath, 50), false)).c_str(),
		"File:",              (sWinToUnixPath(sMinimizePath(pcszFile,  50), false)).c_str(),
		"Line:",              ulLine,
		"Function:",          pcszFunc,
		"Expression:",        pcszExp,
		"GetLastError():",    (LPSTR)lpMsgBuf,
		"Comment:",           pcszComment 
		);


	if (NULL == szMsg || 0 == ::lstrlen(szMsg)) {
		::MessageBox(0, "wsprintf() - fail", "xassert - system message", MB_ICONERROR | MB_OK);
        return;
	}

	if (NULL != lpMsgBuf) {
		::LocalFree(lpMsgBuf);    lpMsgBuf = NULL;
	}

	//-------------------------------------
	//������� MessageBox
	//int iRes = ::MessageBox(NULL, szMsg, szExeName, MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	int iRes = CXMsgBoxRtf::iShow(0, szMsg, szExeName, MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    	exit(- 1);
			break;
		}
		case IDRETRY: {
			_asm {
				int 3
			} 
			break;
		}
		case IDIGNORE: {
			break;
		}
	}
}
//---------------------------------------------------------------------------