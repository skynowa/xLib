/****************************************************************************
*    �����: CXHandleHolder (CXHandleHolder.h)
*
*****************************************************************************/



#ifndef CXHandleHolderH
#define CXHandleHolderH
//---------------------------------------------------------------------------
#include <windows.h>
#include <assert.h>
//---------------------------------------------------------------------------
class CXHandleHolder {
	public: 
				 CXHandleHolder();
				 CXHandleHolder(HANDLE hHandle);
				~CXHandleHolder();
		operator HANDLE();
		HANDLE operator = (HANDLE hHandle);
		
	private:
		HANDLE m_hHandle; 
};
//---------------------------------------------------------------------------
#endif
