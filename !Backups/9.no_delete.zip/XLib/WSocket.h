/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef WSocketH
#define WSocketH 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <windows.h>
//---------------------------------------------------------------------------
class WSocket { 
    public: 
                	WSocket      (SOCKET puiSocket = INVALID_SOCKET); 
                   ~WSocket      (); 
    	static int  Init         (); //Init winsock DLL 
    	static int  iClean       (); //Clean winsock DLL 
    	bool        bCreate      (int iAf, int iType, int iProtocol = 0); 
    	bool        bConnect     (const char *cpszIp, unsigned short int usPort); 
    	bool        bBind        (unsigned short int usPort); 
     	bool        bListen      (int iBacklog = 5);  
    	bool        bAccept      (WSocket &s, char *pszFromIp); 
    	int         iSend        (const char *cpszBuff, int iSize, int iFlags); 
    	int         iRecv        (char *pszBuf, int iSize, int iFlags); 
    	int         iClose       (); 
    	int         iGetLastError(); 
    	static bool bDnsParse    (const char *pcszDomain, char *pszIp); // Domain parse 

        WSocket& operator = (SOCKET s); 
    	operator SOCKET (); 

	protected: 
    	SOCKET m_puiSocket; 
}; 
//---------------------------------------------------------------------------
#endif