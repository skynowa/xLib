/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <stdio.h>   
#include <iostream> 
#include "xassert.h"
#include "wsocket.h"   
//---------------------------------------------------------------------------  
#ifdef WIN32   
#	pragma comment(lib, "wsock32")   
#endif   
//---------------------------------------------------------------------------  
WSocket::WSocket(SOCKET puiSocket) {   
    m_puiSocket = puiSocket;   
}   
//---------------------------------------------------------------------------   
 WSocket::~WSocket() {
 
 }   
//---------------------------------------------------------------------------  
int WSocket::Init() {  
#ifdef WIN32   
    WSADATA wsaData;   memset(&wsaData, 0, sizeof(WSADATA));   
    WORD    wVersion = MAKEWORD(2, 0);   //2.2
	//WSAStartup - [+] returns zero. [-] Otherwise, it returns one of the error codes listed below.
	int     iResult  = ::WSAStartup(wVersion, &wsaData);      
	/*DEBUG*/XASSERT(0 == iResult);  
    if (iResult) {   
        std::cerr << "Initilize winsock error !" << std::endl;   
        return - 1;   
    }   
#endif   

    return 0;   
}   
//---------------------------------------------------------------------------  
int WSocket::iClean() {   
#ifdef WIN32  
	int	iResult = SOCKET_ERROR;
	//WSACleanup - [+] 0 [-] SOCKET_ERROR
	iResult = ::WSACleanup();
	/*DEBUG*/XASSERT(0 == iResult);
	if (0 != iResult) {	
		//...
	}

	return iResult;   
#endif  
 
    return 0;   
}   
//--------------------------------------------------------------------------- 
 WSocket& WSocket::operator = (SOCKET puiSocket) {   
     /*DEBUG*/XASSERT(NULL != puiSocket);
	 m_puiSocket = puiSocket;  

     return *this;   
 }   
//--------------------------------------------------------------------------- 
 WSocket::operator SOCKET () {   
     /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);

	 return m_puiSocket;   
 }   
//--------------------------------------------------------------------------- 
 bool WSocket::bCreate(int iAf, int iType, int iProtocol) {
     /*DEBUG*/
     
	 //socket - [+] socket returns a descriptor referencing the new socket. [-] INVALID_SOCKET
	 m_puiSocket = ::socket(iAf, iType, iProtocol);   
     /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
	 if (INVALID_SOCKET == m_puiSocket) {   
         return false;   
     }   

     return true;   
 }   
//--------------------------------------------------------------------------- 
bool WSocket::bConnect(const char *cpszIp, unsigned short usPort) { 
	/*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
	/*DEBUG*/XASSERT(NULL           != cpszIp);
    /*DEBUG*/XASSERT(0              <  strlen(cpszIp));
    /*DEBUG*/XASSERT((32767 > usPort) && (0 < usPort));

	struct sockaddr_in saSockAddr;		memset(&saSockAddr, 0, sizeof(saSockAddr));   
	saSockAddr.sin_family      = AF_INET; 
	saSockAddr.sin_addr.s_addr = inet_addr(cpszIp);   
	saSockAddr.sin_port        = ::htons(usPort); //???????

	//connect - [+] 0 [-] SOCKET_ERROR
	int iRes = ::connect(m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(saSockAddr));  
	/*DEBUG*/XASSERT(0 == iRes);
	if (SOCKET_ERROR == iRes) {   
	    return false;   
	}   

	return true;   
}   
//---------------------------------------------------------------------------
 bool WSocket::bBind(unsigned short int usPort) {   
    /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
    /*DEBUG*/XASSERT((32767 > usPort) && (0 < usPort));	

    struct sockaddr_in saSockAddr;	    memset(&saSockAddr, 0, sizeof(saSockAddr));   
    saSockAddr.sin_family      = AF_INET;   
    saSockAddr.sin_addr.s_addr = INADDR_ANY;   
    saSockAddr.sin_port        = htons(usPort);   
    
    int iOpt = 1;  
    /*DEBUG*/
    if (::setsockopt(m_puiSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&iOpt, sizeof(iOpt)) < 0) {   
        return false;   
    }

    int iRes = ::bind(m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(saSockAddr)); 
    /*DEBUG*/    
    if (SOCKET_ERROR == iRes) {   
        return false;   
    }   

    return true;   
}   
//--------------------------------------------------------------------------- 
 bool WSocket::bListen(int iBacklog) { 
	/*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);

	int iRes = ::listen(m_puiSocket, iBacklog); 
    /*DEBUG*/     
    if (SOCKET_ERROR == iRes) {   
        return false;   
    }   

    return true;   
}   
//---------------------------------------------------------------------------  
bool WSocket::bAccept(WSocket &s, char *pszFromIp) { 
	/*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
	/*DEBUG*/XASSERT(NULL           != pszFromIp);
    /*DEBUG*/XASSERT(0              <  strlen(pszFromIp));

    struct sockaddr_in cliaddr;   
    int iAddrlen = sizeof(cliaddr);

	SOCKET sock = ::accept(m_puiSocket, (struct sockaddr *)&cliaddr, &iAddrlen); 
    /*DEBUG*/     
    if (SOCKET_ERROR == sock) {   
        return false;   
    }   
    
    s = sock;   
	if (NULL != pszFromIp) {  
	    ::wsprintf(pszFromIp, "%s", inet_ntoa(cliaddr.sin_addr));   
	}
    
    return true;   
}   
//---------------------------------------------------------------------------  
int WSocket::iSend(const char *pcszBuff, int iBuffSize, int iFlags) { 
    /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
    /*DEBUG*/XASSERT(NULL           != pcszBuff);
	/*DEBUG*/XASSERT(0              != strlen(pcszBuff));

    int iRes   = - 1;   
    int iCount = 0;   

    while (iCount < iBuffSize) {   
        //send - [+] total number of bytes sent, which can be less than the number requested to be sent in the len parameter. [-] SOCKET_ERROR
        iRes = ::send(m_puiSocket, pcszBuff + iCount, iBuffSize - iCount, iFlags);
        /*DEBUG*/XASSERT(SOCKET_ERROR != iRes);  
        /*DEBUG*/XASSERT(0            != iRes); 
        
        if (- 1 == iRes || 0 == iRes) {   
            return - 1;   
        }        
        iCount += iRes;   
    }    

    return iCount;   
}   
//---------------------------------------------------------------------------  
 int WSocket::iRecv(char *pszBuff, int iBuffSize, int iFlags) {  
 	 /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);
     /*DEBUG*/XASSERT(NULL           != pszBuff);

	 int iRes = SOCKET_ERROR;
	 memset(pszBuff,  0, iBuffSize);	//?????????/
	 //recv - [+] number of bytes received and the buffer pointed to by the buf parameter will contain this data received. [-] SOCKET_ERROR [-] 0 gracefully closed 
	 iRes = ::recv(m_puiSocket, pszBuff, iBuffSize, iFlags);
	 /*DEBUG*/XASSERT(SOCKET_ERROR != iRes);
	 /*DEBUG*/XASSERT(0            != iRes);

	 return iRes;   
 }   
//--------------------------------------------------------------------------- 
int WSocket::iClose() {		
    /*DEBUG*/XASSERT(INVALID_SOCKET != m_puiSocket);

#ifdef WIN32 
    int iRes = SOCKET_ERROR;

    //shutdown - [+] 0. [-] SOCKET_ERROR
    iRes = ::shutdown(m_puiSocket, SD_BOTH);	 
    /*DEBUG*/XASSERT(0 == iRes);

    //closesocket - [+] zero. [-] SOCKET_ERROR
    iRes = ::closesocket(m_puiSocket); 
    /*DEBUG*/XASSERT(0 == iRes);

    m_puiSocket = INVALID_SOCKET;

    return iRes;
    ////++return (::closesocket(m_puiSocket));   
#else   
    return (close(m_puiSocket));   
#endif   
}   
//---------------------------------------------------------------------------
int WSocket::iGetLastError() {   
#ifdef WIN32   
    return ::WSAGetLastError();   
#else   
    return errno;   
#endif   
}   
//--------------------------------------------------------------------------- 
bool WSocket::bDnsParse(const char *pcszDomain, char *pszIp) {   
    /*DEBUG*/XASSERT(NULL != pcszDomain);
    /*DEBUG*/XASSERT(NULL != pszIp);
    /*DEBUG*/XASSERT(0    < strlen(pcszDomain));

    struct hostent *pHostent = ::gethostbyname(pcszDomain); 
    /*DEBUG*/XASSERT(NULL != pHostent);
    if (NULL == pHostent) {   
        return false;   
    }

    ::wsprintf(
                pszIp,
                "%u.%u.%u.%u",   
                (unsigned char)pHostent->h_addr_list[0][0],    
                (unsigned char)pHostent->h_addr_list[0][1],    
                (unsigned char)pHostent->h_addr_list[0][2],    
                (unsigned char)pHostent->h_addr_list[0][3]
    );   

    return true;   
}   
//---------------------------------------------------------------------------