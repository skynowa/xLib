/****************************************************************************
* Class name:  CXFsoString
* Description: ������ ��� ������ � �������� ��������
* File name:   CXFsoString.cpp
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:02:43
*
*****************************************************************************/


//---------------------------------------------------------------------------
#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#include "CXFsoString.h"

#include <windows.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <ostream>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <iterator>
#include <ctime>
//#include <fentl.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
//#include <sharc.h>
//#include <io.h>

#include "xassert.h"
#include "CXString.h"
//---------------------------------------------------------------------------
#define randomize() (srand((unsigned)time(NULL))) 
#define random(x)   (rand() % x)

const char ccWinDelimeter  = '\\';
const char ccUnixDelimeter = '/';
//---------------------------------------------------------------------------


/****************************************************************************
* ����������
*
*****************************************************************************/

//--------------------------------------------------------------------------
template<class T> void vRandomShuffle(std::vector<T> &v) {
	std::random_shuffle(v.begin(), v.end());
	/*	std::vector<std::string>(v);
	v.push_back("111111");
	v.push_back("2222222");
	v.push_back("33333333");
	v.push_back("4444444444");
	v.push_back("55555555555");

	vRandomShuffle(v);

    for (unsigned int i = 0; i < v.size(); i ++) {
		MessageBox(0, v.at(i).c_str(), "", MB_OK);
    }
*/
}
//--------------------------------------------------------------------------
template<class T> void vSortVector(std::vector<T> &v) {
    std::sort(v.begin(), v.end());
}
//--------------------------------------------------------------------------


/****************************************************************************
* �������� � ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
std::string sExePath() {
	char szExePath[MAX_PATH];	::ZeroMemory(&szExePath, sizeof(szExePath));
	::GetModuleFileName(GetModuleHandle(NULL), szExePath, MAX_PATH);		

	return std::string(szExePath);	
}
//---------------------------------------------------------------------------
std::string sExtractFilePath(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sExtractFullFileName(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes = sRes.substr(i, sRes.size() - i);
			
			break;
		}
	}
	//const int ciEndOfPathIndex = casFileName.rfind("\\", casFileName.size());
	
	return sRes;
}
//--------------------------------------------------------------------------
std::string sExtractShortFileName(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	sRes = sRemoveFileExt(sExtractFullFileName(sRes));

	return sRes;
}
//--------------------------------------------------------------------------
std::string sExtractFileExt(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);
	
	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if ('.' == sRes.at(i - 1)) {
			sRes = sRes.substr(i, sRes.size() - i);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sChangeFileExt(const std::string &csFilePath, const std::string &csFileExt) {	
	std::string sRes("");
	sRes.assign(csFilePath);
	
	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if ('.' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileExt);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sChangeFullFileName(const std::string &csFilePath, const std::string &csFileName) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileName);
			
			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
std::string sRemoveFileExt(const std::string &csFilePath) {
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.' - ������� ����� � ����������
		if ('.' == sRes.at(i - 1)) {
			sRes = sRes.erase(i - 1, sRes.size() - i + 1);
			
			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
//Returns the path, without a trailing backslash '\'
std::string sExtractFileDir(const std::string &csFilePath) {
	size_t uiEndOfPathIndex = csFilePath.rfind("\\", csFilePath.size());
	if (std::string::npos == uiEndOfPathIndex) {
		return "";
	}

	return csFilePath.substr(0, uiEndOfPathIndex);
}
//--------------------------------------------------------------------------
std::string sUnixToWinPath(const std::string &csUnixPath, bool bNeedBackslashAtEnd) {
	std::string sRes("");
	sRes.assign(csUnixPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('/' == sRes.at(i)) {
			sRes.at(i) = '\\';
		}
	}

	if (bNeedBackslashAtEnd && '\\' != sRes.at(sRes.size() - 1)) {
		sRes.append("\\");
	}

	return sRes; 
}
//--------------------------------------------------------------------------
std::string sWinToUnixPath(const std::string &csWinPath, bool bNeedBackslashAtEnd) {
	std::string sRes("");
	sRes.assign(csWinPath);
	
	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('\\' == sRes.at(i)) {
			sRes.at(i) = '/';
		}
	}

	if (bNeedBackslashAtEnd && '/' != sRes.at(sRes.size() - 1)) {
		sRes.append("/");
	}

	return sRes; 
}
//--------------------------------------------------------------------------
void vForceDirectories(const std::string &csPath) {
	/*DEBUG*/XASSERT(false == csPath.empty());

	char szPath[MAX_PATH];        ::ZeroMemory(&szPath, sizeof(szPath));
	
	::lstrcpy(szPath, sWinToUnixPath(csPath, true).c_str());
	
	LPSTR pszTemp = szPath;
	
	if (pszTemp[1] == ':') {
		pszTemp += 3;
	}

	while (*pszTemp) {
		char szPathNow[MAX_PATH];    ::ZeroMemory(&szPathNow, sizeof(szPathNow));
		pszTemp = strchr (pszTemp, '/') + 1;
		::lstrcpyn(szPathNow, szPath, pszTemp - szPath);
		if (FALSE == ::CreateDirectory(szPathNow, NULL) && ERROR_ALREADY_EXISTS != ::GetLastError()) {
			throw ::GetLastError();
		}
	}
}
//---------------------------------------------------------------------------
std::string sMinimizeFileName(const std::string &csStr, const unsigned int cuiMaxLen) {	
	/*DEBUG*/XASSERT(false == csStr.empty());
	/*DEBUG*/XASSERT(0 < cuiMaxLen);

	std::string sRes("");
	std::string sTildaDotExt      = "~." + sExtractFileExt(csStr);
	size_t      uiTildaDotExtSize = sTildaDotExt.size();

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < uiTildaDotExtSize) {
			sRes = csStr.substr(0, cuiMaxLen);
		} else {
			sRes = csStr.substr(0, cuiMaxLen - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::string _sCutFirstDirectory(const std::string &csS) {
	/*DEBUG*/XASSERT(false == csS.empty());

	std::string S("");
	S.assign(csS);	

	bool   bRoot = false;
	size_t P     = - 1;

	if ("\\" == S) {
		S.clear();
	} else {
		if (S[0] == '\\') {
			bRoot = true;
			//������� � 1(0) ������� 1 ������
			//Delete(S, 1, 1);
			S.erase(0, 1);
		} else {
			bRoot = false;
		}

		if ('.' == S[0]) {
			//Delete(S, 1, 4);
			S.erase(0, 4);
		}

		//P = AnsiPos("\\", S); 
		P = S.find_first_of("\\") + 1;

		if (std::string::npos != P) {
			//Delete(S, 1, P); - c ������� 1(0) P ��������
			S.erase(0, P);
			S = "...\\" + S;        
		} else {
			S.clear();
		}

		if (bRoot) {
			S = "\\" + S;
		}
	}

	return S;
}
//---------------------------------------------------------------------------
std::string sMinimizePath(const std::string &csFilePath, const size_t cuiMaxLen) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(0 < cuiMaxLen);
	
	std::string sRes("");
	sRes.assign(csFilePath);	

	TCHAR szDrive[MAX_PATH];	::ZeroMemory(szDrive, sizeof(szDrive));
	TCHAR szDir  [MAX_PATH];	::ZeroMemory(szDir,   sizeof(szDir));
	TCHAR szName [MAX_PATH];	::ZeroMemory(szName,  sizeof(szName));
	TCHAR szExt  [MAX_PATH];	::ZeroMemory(szExt,   sizeof(szExt));
	_splitpath(csFilePath.c_str(), szDrive, szDir, szName, szExt);	

	std::string sDrive = std::string(szDrive);
	std::string sDir   = std::string(szDir);
	std::string sName  = std::string(szName) + std::string(szExt);

	//while ((Dir <> '') or (Drive <> '')) and (Canvas.TextWidth(Result) > MaxLen) do
	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/ > cuiMaxLen)) { 
		if ("\\...\\" == sDir ) {
			sDrive.clear();
			sDir = "...\\";
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			sDir = _sCutFirstDirectory(sDir);		  
		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------


/****************************************************************************
* ������ �����
*
*****************************************************************************/


//--------------------------------------------------------------------------
bool bIsDriveReady(LPCSTR pcszDrivePath) {	//���� �� ������
	BOOL bRes          = false;
	
	//������ ���������
	WORD wOldErrorMode = ::SetErrorMode(SEM_NOOPENFILEERRORBOX);  //SEM_FAILCRITICALERRORS

    //�������� ������� ����������
	if (0 == ::SetCurrentDirectory(pcszDrivePath)) {	//succeeds - nonzero, fails - zero.
        ::SetErrorMode(wOldErrorMode);
        bRes = false;
    } else {
        bRes = true;
    }
	
	//������ ���������� �� "�://"
	::SetCurrentDirectory("C:/");
    
	return bRes;
}
//--------------------------------------------------------------------------
bool bFileExists(const std::string &csFilePath) { 
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	return (INVALID_FILE_ATTRIBUTES != ::GetFileAttributes(csFilePath.c_str())); 
}
//---------------------------------------------------------------------------
unsigned long int ulFileLines(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));

	unsigned long int ulLines = 0;   //������� �����

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return 0;
	}

	char cChar = '\0';
	while (ifsStream.get(cChar)) {
		if ('\n' == cChar) {
			ulLines ++;
		}
	} 
	ulLines ++;
	ifsStream.close();

	return ulLines;
}
//--------------------------------------------------------------------------
unsigned long int ulFileSize(FILE *pFile) {
	/*DEBUG*/XASSERT(NULL != pFile);

	unsigned long int ulRes = 0;	
	
	if (0 != fseek(pFile, 0, SEEK_END)) {
		return 0;
	}

	ulRes = ftell(pFile);
	rewind(pFile);

	return ulRes;
	/*
	file.seekg (0, std::ios::end);
	size = file.tellg();
	file.seekg (0, std::ios::beg);
	*/
}
//---------------------------------------------------------------------------
unsigned long int ulFileSize(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	unsigned long int ulRes = 0;

	FILE *pFile = fopen(csFilePath.c_str(), "rb");
	/*DEBUG*/XASSERT(NULL != pFile);	
	
	if (0 != fseek(pFile, 0, SEEK_END)) {
		fclose(pFile);
		return 0;
	}

	ulRes = ftell(pFile);
	rewind(pFile);

	fclose(pFile);

	return ulRes;
}
//---------------------------------------------------------------------------
unsigned __int64 ui64GetFileSize(HANDLE hFile) {
	/*DEBUG*/XASSERT(NULL != hFile);

	DWORD dw1 = 0;
	DWORD dw2 = 0;
	dw1 = ::GetFileSize(hFile, &dw2);

	return (dw1 | (unsigned __int64) (dw2) << 32);
}
//---------------------------------------------------------------------------
bool bGetCompressedFileSize(LPCTSTR fileName, unsigned __int64 &size) {
	/*DEBUG*/XASSERT(NULL != fileName);
	
	DWORD highPart = 0;
	DWORD lowPart  = ::GetCompressedFileSize(fileName, &highPart);
	if (INVALID_FILE_SIZE == lowPart) {
		if (NO_ERROR != ::GetLastError()) {
			return false;
		}
	}

	size = ((unsigned __int64)(highPart) << 32) | lowPart;

	return true;
}
//--------------------------------------------------------------------------
bool bGetCompressedFileSizeW(LPCWSTR fileName, unsigned __int64  &size) {
	/*DEBUG*/XASSERT(NULL != fileName);

	DWORD highPart = 0;
	DWORD lowPart  = ::GetCompressedFileSizeW(fileName, &highPart);
	if (INVALID_FILE_SIZE == lowPart) {
		if (NO_ERROR != ::GetLastError()) {
			return false;
		}
	}

	size = ((unsigned __int64)(highPart) << 32) | lowPart;

	return true;
}
//--------------------------------------------------------------------------


/****************************************************************************
* ��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
bool bSetFileNormalAttr(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	DWORD  ulFileAttr = - 1;

	//������ �������� �����
	ulFileAttr = ::GetFileAttributes(csFilePath.c_str());
	if (0xFFFFFFFF == ulFileAttr)	{
		return false;
	}

	//������� ������� "������ ������"
	if (false == ::SetFileAttributes(csFilePath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
		return false;
	}

	return true;
}
//---------------------------------------------------------------------------
bool bSetFileUncompressedAttr(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	DWORD  ulFileAttr = - 1;

	//������ �������� �����
	ulFileAttr = ::GetFileAttributes(csFilePath.c_str());
	if (0xFFFFFFFF == ulFileAttr)	{
		return false;
	}

	//������� ������� "������"
	if (FALSE == ::SetFileAttributes(csFilePath.c_str(), ulFileAttr | FILE_ATTRIBUTE_COMPRESSED)) {
		return false;
	}

	return true;
}
//---------------------------------------------------------------------------
bool bSetFileCompressedAttr(const std::string &csFilePath, bool bCompress) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	HANDLE    hFile           = NULL;
	short int siCompression   = 0;
	DWORD     ulBytesReturned = 0;
	bool      bForceCompress  = true;

	if (0 != bForceCompress ||/*|*/ ((::GetFileAttributes((csFilePath).c_str()) && FILE_ATTRIBUTE_COMPRESSED))) {
		hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, 0);
		if (INVALID_HANDLE_VALUE == hFile) {
			return false;
		}
		
		if (true == bCompress) {
			siCompression = COMPRESSION_FORMAT_DEFAULT;
		} else {
			siCompression = COMPRESSION_FORMAT_NONE;
		}

		if (FALSE == ::DeviceIoControl(hFile, FSCTL_SET_COMPRESSION, &siCompression,	sizeof(short), NULL, 0, &ulBytesReturned, NULL)) {
			::CloseHandle(hFile); hFile = NULL;

			return false;
		}

		::CloseHandle(hFile); 	hFile = NULL;

		return true;
	} else {
		return true;
	}
}
//--------------------------------------------------------------------------
int iIsFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	const int ciUnknown = 0;
	const int ciFile    = 1;
	const int ciFolder  = 2;
	
	
	DWORD dwAttr = ::GetFileAttributes(csFilePath.c_str());
	if (dwAttr == INVALID_FILE_ATTRIBUTES) {
		//��� ������� �����
		return ciUnknown;
	} else if (0 == (dwAttr & FILE_ATTRIBUTE_DIRECTORY)) {
		//����
		return ciFile;
	} else {
    	//������ �����
		return ciFolder;
	}
} 
//--------------------------------------------------------------------------
bool bIsReadOnly(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_READONLY)   != 0; 
}
//--------------------------------------------------------------------------
bool bIsHidden(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_HIDDEN)     != 0; 
}
//--------------------------------------------------------------------------
bool bIsSystem(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_SYSTEM)     != 0; 
}
//--------------------------------------------------------------------------
bool bIsDirectory(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_DIRECTORY)  != 0; 
}
//--------------------------------------------------------------------------
bool bIsArchived(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_ARCHIVE)    != 0; 
}
//--------------------------------------------------------------------------
bool bIsCompressed(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_COMPRESSED) != 0; 
}
//--------------------------------------------------------------------------
bool bIsEncrypted(DWORD ulAttr) { 
	return (ulAttr & FILE_ATTRIBUTE_ENCRYPTED)  != 0; 
}
//--------------------------------------------------------------------------


/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/

//--------------------------------------------------------------------------
void vFileToArray(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	
	//ulFileLines(csFilePath);
	//...
}
//--------------------------------------------------------------------------
std::vector<std::string> vecsReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true  == bFileExists(csFilePath));
	
	std::vector<std::string> vecVector;
	std::string              sStr("");
	std::ifstream            ifsStream(csFilePath.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return std::vector<std::string>();
	}	

	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		vecVector.push_back(sStr);
	}

	return vecVector;
}
//--------------------------------------------------------------------------
std::vector<char> vecchReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in | std::ios::binary);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return std::vector<char>();
	}

	std::vector<char>       vecchBuffer;
	std::ifstream::pos_type uiSize = 0;

	if (ifsStream.seekg(0, std::ios::end)) {
		uiSize = ifsStream.tellg();
	}

	if (uiSize && ifsStream.seekg(0, std::ios::beg)) {
		vecchBuffer.resize(uiSize);
		ifsStream.read(&vecchBuffer[0], uiSize);
	}

	return vecchBuffer;
}
//--------------------------------------------------------------------------
bool bWriteText(const std::string &csFilePath, const std::string &csText) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());

	bool bRes = false;
	
	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	
	DWORD dwWrittenBytes = 0;
	bRes = ::WriteFile(hFile, csText.c_str(), (DWORD)(csText.size()), &dwWrittenBytes, NULL);
	if (csText.size() != dwWrittenBytes) {
		bRes = false;
	} else {
		bRes = true;
	}

	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}

	return bRes;
}
//--------------------------------------------------------------------------
std::string sReadText(const std::string &csFilePath) {	///char -> BYTE
	/*
	std::string xstr;
	std::ifstream xfile("inputfile.txt", std::ios::binary);

	//������ ������ �����, � �������� ������ � ������
	xfile.seekg( 0, std::ios_base::end );
	xstr.resize( xfile.tellg() );
	xfile.seekg( 0, std::ios_base::beg );

	//�������� ������
	xfile.read( (void*)xstr.data(), xstr.size() );
	*/

	/*
	std::ifstream iFile("inputfile.txt");
	std::string mystr(std::istreambuf_iterator<char>(iFile), std::istreambuf_iterator<char>());
	*/

	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);

	//-------------------------------------
    //�������� ������ �����
    DWORD dwFileSize = ::GetFileSize(hFile, NULL);
    if (0xFFFFFFFF == dwFileSize || 0 == dwFileSize) {
		::CloseHandle(hFile);

        return "";
    }

	//-------------------------------------
    //������ ����
	std::string  sRes("");
	DWORD        dwRealyRead = 0;
    char        *pBuff       = new char[dwFileSize];  	
	if (NULL == pBuff) {
		::CloseHandle(hFile);

		return "";		
	}
	if (FALSE == ::ReadFile(hFile, pBuff, dwFileSize, &dwRealyRead, NULL)) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	} 
	if (dwFileSize != dwRealyRead) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	}
	
	//-------------------------------------
    //������ � std::string
	sRes = std::string(pBuff, dwFileSize);

	//-------------------------------------
    //��������� ���� � ������� �����3
	delete [] pBuff;
	::CloseHandle(hFile);    

	return sRes;
}
//--------------------------------------------------------------------------

/****************************************************************************
* �������� � �������
*
*****************************************************************************/

//--------------------------------------------------------------------------
bool bCopyFile(const std::string &csFilePathFrom, const std::string &csFilePathTo) {
	/*DEBUG*/XASSERT(false == csFilePathFrom.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePathFrom));
	/*DEBUG*/XASSERT(false == csFilePathTo.empty());

	std::ifstream ifsStream(csFilePathFrom.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return false;
	}
	std::ofstream ofsStream(csFilePathTo.c_str()); 
	if (!ofsStream || ofsStream.fail() || !ofsStream.good() || !ofsStream.is_open() || ofsStream.eof()) {
		return false;
	}

	ofsStream << ifsStream.rdbuf();
	ofsStream.close();

	return true;
}
//---------------------------------------------------------------------------
bool bMoveFile(const std::string &csFilePathIn, const std::string &csFilePathOut) {
	/*DEBUG*/XASSERT(false == csFilePathIn.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePathIn));
	/*DEBUG*/XASSERT(false == csFilePathOut.empty());

	//-------------------------------------
	//������� ������� "������ ������"
	if (true == bFileExists(csFilePathOut)) {
		if (false == bSetFileNormalAttr(csFilePathOut)) {
			return false;
		}
	}
	if (false == bSetFileNormalAttr(csFilePathIn)) {
		return false;
	}

	//-------------------------------------
	//����������
	if (false == ::MoveFileEx(csFilePathIn.c_str(), csFilePathOut.c_str(), MOVEFILE_REPLACE_EXISTING /*|  MOVEFILE_DELAY_UNTIL_REBOOT*/)) {
		return false;
	}

	return true;
}
//---------------------------------------------------------------------------
bool bDeleteFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));

	if (false == bSetFileNormalAttr(csFilePath)) {
		return false;
	}
	
	if (false == ::DeleteFile(csFilePath.c_str())) {
		return false;
	}

	return true;
}
//--------------------------------------------------------------------------
//TODO: bSecureDeleteFile
///////*I set _stklen to 512 because there shouldn't be that much going to the
//////functions and i wanted to save memory I set _fmode to binary so i
//////could take it out of the sopen statement because im lazy*/
//////extern unsigned _stklen = 512;
//////extern int      _fmode  = 0x8000;	O_BINARY
//////bool bSecureDeleteFile(const std::string &csFilePath, unsigned int uiPasses) {
/////////////*	const int     ciO_BINARY    = 0x8000;
////////////	const int     ciO_TRUNC     = 0x0200;
////////////	const int     ciO_WRONLY    = 2;
////////////	const int     ciS_IFREG     = 0x0000;
////////////	const int     ciSH_DENYNO   = 0x0040;*/
//////
//////	const unsigned long int culBuffLen     = 32768;
//////	const unsigned long int culClusterSize = 32768;
//////
//////	int               hFile           = NULL; 
//////	unsigned long int ulFileSize      = 0;
//////	unsigned char     ucBuff[culBuffLen];
//////	
//////	//-------------------------------------
//////	//CHECK
//////	if (false == bFileExists(csFilePath)) {
//////		return false;
//////	}
//////
//////	//-------------------------------------
//////	//�������� ������� "������ ������"
//////	if (false == bSetFileNormalAttr(csFilePath)) {
//////		return false;
//////	}
//////
//////	//-------------------------------------
//////	//�������� ������� ������
//////	if (false == bSetFileCompressedAttr(csFilePath, false)) {
//////		return false;
//////	}
//////	
//////	//-------------------------------------
//////	//����� ��������� ������ � ����, ������� �� 32kb, �������-�� ���
//////	hFile = sopen(csFilePath.c_str(), O_WRONLY, SH_DENYNO, S_IFREG);
//////	if (hFile ==  - 1) {
//////		close(hFile);
//////		return false;
//////	}
//////
//////	//�������� ������ ����� � ���������� ������ ������ ��� �����
//////	ulFileSize = filelength(hFile);
//////	ulFileSize += (culClusterSize - (ulFileSize % culClusterSize));
//////
//////	for (unsigned int i = 1; i <= uiPasses; i ++) {
//////		randomize();
//////		for (register unsigned int i = 0; i < ulFileSize; i += culBuffLen) {
//////			for (register unsigned long j = 0; j < culBuffLen; j ++) {
//////				ucBuff[j] = random(255) + 1;
//////			}  
//////			write(hFile, ucBuff, culBuffLen);
//////		}
//////		flushall();
//////		
//////		//���������� �� ������ �����
//////		if (-1L == lseek(hFile, 0L, 0)) {
//////			close(hFile);
//////			return false;
//////		}
//////	}
//////
//////	close(hFile);
//////
//////	//-------------------------------------
//////	//���������� (���� ��������/�����������/���������� ��������� � ������ ��������)
//////	if (false == bSetRandomFileDate(csFilePath)) {
//////		return false;
//////	}
//////
//////	//-------------------------------------
//////	//������������� �������� ���� (����� ����������� ��������� ��� ����� ����� ��� MAX_PATH)
//////	const int    ciMaxPath          = 255; 
//////	char         chSymbols[53]      = {'q', 'w', 'e',  'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '!', '@', '#', '$', '%', '^', '&', '(', ')', '_', '+', '�', ';', '%', '.', ',', '~'};
//////	
//////	int          iFileDirPathLen    = sExtractFileDir(csFilePath).size();
//////	int          iSlashLen          = 1;
//////	std::string  sRandomFileName("");
//////	unsigned int uiRandomFileNameLen = ciMaxPath - iFileDirPathLen - iSlashLen;
//////	
//////	char *pszRandomFileName = new char[uiRandomFileNameLen + 1];		
//////	if (NULL == pszRandomFileName) {
//////		return false;
//////	}
//////
//////	//������� ��� �����
//////	randomize();
//////	for (register unsigned int i = 0; i < uiRandomFileNameLen; ) {
//////		//������� ��������� ������
//////		char chChar = random(255) + 1;
//////		//�������� �� ��� ������?
//////		for (register unsigned long x = 0; x < 53; x ++) {
//////			if (chChar == chSymbols[x]) {
//////				pszRandomFileName[i] = chChar;
//////				i ++;
//////			}			
//////		}  
//////	}
//////	pszRandomFileName[uiRandomFileNameLen] = '\0';
//////
//////	sRandomFileName = std::string(pszRandomFileName, uiRandomFileNameLen);
//////
//////	//����������� ������
//////	delete [] pszRandomFileName;
//////	pszRandomFileName = NULL;
//////
//////	//���������������
//////	std::string sFilePathOut("");
//////	sFilePathOut = sExtractFileDir(csFilePath) + "\\" + sRandomFileName;
//////	if (0 != rename(csFilePath.c_str(), sFilePathOut.c_str())) {
//////		return false;
//////	}
//////
//////	//-------------------------------------
//////	//������� ����
//////	hFile = sopen(sFilePathOut.c_str(), O_WRONLY | O_TRUNC, SH_DENYNO, S_IFREG);
//////	close(hFile);
//////
//////	//-------------------------------------
//////	//������� ����
//////	if (- 1 == remove(sFilePathOut.c_str())) {
//////		return false;
//////	}
//////
//////	return true;
//////}
//--------------------------------------------------------------------------
bool bCutFileFromEnd(const std::string &csFilePath, long int lDistanceToCut) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));
	/*DEBUG*/XASSERT(0 < lDistanceToCut);

	//-------------------------------------
	//JOB
	bool bRes = false;

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,NULL);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	if (INVALID_SET_FILE_POINTER != ::SetFilePointer(hFile, - (lDistanceToCut), NULL, FILE_END)) {
		if (TRUE == ::SetEndOfFile(hFile)) {
			bRes = true;
		}
	}
	
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}


	return bRes;
}
//---------------------------------------------------------------------------
bool bCutFileFromEnd(FILE *pFile, unsigned long int ulDistanceToCut) {
    /*DEBUG*/XASSERT(NULL != pFile);
	/*DEBUG*/XASSERT(0 < ulDistanceToCut);

	if (0 != chsize(fileno(pFile), ulFileSize(pFile) - ulDistanceToCut)) {
		return false;
	}

	return true;
}
//--------------------------------------------------------------------------
bool bCheckSignature(char *pszBuff, char *pszSignature, int iSignatureSize) {
	/*DEBUG*/XASSERT(NULL != pszBuff);
	/*DEBUG*/XASSERT(0 < ::lstrlen(pszBuff));
	/*DEBUG*/XASSERT(NULL != pszSignature);
	/*DEBUG*/XASSERT(0 < ::lstrlen(pszSignature));
	/*DEBUG*/XASSERT(0 < iSignatureSize);
	
	////const char signature[] = "\xFF\xD8\xFF\xE0\x00\x10JFIF";
	for (int i = 0; i < iSignatureSize; i++) {
		if (pszSignature[i] != pszBuff[i]) {
			return false;
		}
	}

	return true;
}
//--------------------------------------------------------------------------
bool bSetRandomFileDate(const std::string &csFilePath) {
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(true == bFileExists(csFilePath));

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    //��� ������ ����� ������� ���� FILE_FLAG_BACKUP_SEMANTICS.
	////HANDLE hFile = CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL)
    /*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	
	//-------------------------------------
	//���� ��������
	FILETIME ftCreationTime; 
	randomize();
	ftCreationTime.dwHighDateTime = rand();
	randomize();
	ftCreationTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� �������
	FILETIME ftLastAccessTime; 
	randomize();
	ftLastAccessTime.dwHighDateTime = rand();
	randomize();
	ftLastAccessTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� ���������
	FILETIME ftLastWriteTime; 
	randomize();
	ftLastWriteTime.dwHighDateTime = rand();
	randomize();
	ftLastWriteTime.dwLowDateTime  = rand();

	//-------------------------------------
	//������ ��������
	BOOL bRes = ::SetFileTime(hFile, &ftCreationTime, &ftLastAccessTime, &ftLastWriteTime);	//(LPFILETIME)NULL  
	if (FALSE == bRes) {
		/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
		if (NULL != hFile) {
			::CloseHandle(hFile); hFile = NULL;
		}
		return false;
	}

	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != hFile);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}

	return true;
}
//--------------------------------------------------------------------------


//--------------------------------------------------------------------------
/*int main() {
//Silenty executes 'dir' and writes the output to the file "temp.txt"
std::system("dir > temp.txt");

//Read "temp.txt" in a std::vector<std::string>
const std::vector<std::string> file(FileToVector("temp.txt"));

//Display the file
typedef std::vector<std::string>::const_iterator Iterator;
for (Iterator i = file.begin(); i!=file.end(); ++i)
{
std::cout << *i << std::endl;
}

//Wait for key press
std::cin.get();
}*/
//--------------------------------------------------------------------------
/*
Perform a file operation (see API doc)
Also includes MakeDir and DeleteFile

Dependencies: GetShell32Version (only for NT4 compatibility)

Web: http://beta.unclassified.de/code/cpp/
*/
/*
// wFunc: FO_COPY, FO_DELETE, FO_MOVE, FO_RENAME
bool CFileSys::FileOperation(UINT wFunc, LPCTSTR szSrc, LPCTSTR szDest)
{
    SHFILEOPSTRUCT fos;
    char cFrom[MAX_PATH + 2];
    int iRet;

    strcpy(cFrom, szSrc);
    cFrom[strlen(cFrom) + 1] = '\0';  // IMPORTANT: add second NULL

    fos.wFunc = wFunc;
    fos.pFrom = cFrom;
    fos.pTo = szDest;
    fos.fFlags = FOF_NOCONFIRMATION | FOF_NOCONFIRMMKDIR | FOF_NOERRORUI | FOF_RENAMEONCOLLISION | FOF_SILENT;

    iRet = SHFileOperation(&fos);

    // workaround on windows nt 4
    if ((GetShell32Version() == "4.00") && ((iRet == 117) || (iRet == 183)))
    {
        fos.fAnyOperationsAborted = true;
    }

    return !iRet && !fos.fAnyOperationsAborted;
}

int MakeDir(LPCTSTR szPath)
{
    if (!CreateDirectory(szPath, NULL))
    {
        return GetLastError();
    }
    else
    {
        return 0;
    }
}

bool DeleteFile(LPCTSTR szFilename)
{
    return FileOperation(FO_DELETE, szFilename, "");
}*/
//--------------------------------------------------------------------------
/*
Return system directories

Dependencies: CString

Web: http://beta.unclassified.de/code/cpp/
*/
/*
// SystemDir defines
#define SD_ROOT          0x0100
#define SD_WIN           0x0101
#define SD_SYS           0x0102

// params used for SHGetSpecialFolderPath
// only available with shell32.dll v4.71+
// copied from pladform sdk shlobj.h (SD_* was originally CSIDL_*)
// remarked values return no filesystem path
#define SD_DESKTOP                   0x0000        // <desktop>
#define SD_PROGRAMS                  0x0002        // Start Menu\Programs
#define SD_PERSONAL                  0x0005        // My Documents
#define SD_FAVORITES                 0x0006        // <user name>\Favorites
#define SD_STARTUP                   0x0007        // Start Menu\Programs\Startup
#define SD_RECENT                    0x0008        // <user name>\Recent
#define SD_SENDTO                    0x0009        // <user name>\SendTo
#define SD_STARTMENU                 0x000b        // <user name>\Start Menu
#define SD_DESKTOPDIRECTORY          0x0010        // <user name>\Desktop
#define SD_NETHOOD                   0x0013        // <user name>\nethood
#define SD_FONTS                     0x0014        // windows\fonts
#define SD_TEMPLATES                 0x0015
#define SD_COMMON_STARTMENU          0x0016        // All Users\Start Menu
#define SD_COMMON_PROGRAMS           0X0017        // All Users\Programs
#define SD_COMMON_STARTUP            0x0018        // All Users\Startup
#define SD_COMMON_DESKTOPDIRECTORY   0x0019        // All Users\Desktop
#define SD_APPDATA                   0x001a        // <user name>\Application Data
#define SD_PRINTHOOD                 0x001b        // <user name>\PrintHood
#define SD_LOCAL_APPDATA             0x001c        // <user name>\Local Settings\Application Data (non roaming)
#define SD_COMMON_FAVORITES          0x001f
#define SD_INTERNET_CACHE            0x0020
#define SD_COOKIES                   0x0021
#define SD_HISTORY                   0x0022
#define SD_COMMON_APPDATA            0x0023        // All Users\Application Data
#define SD_WINDOWS                   0x0024        // GetWindowsDirectory()
#define SD_SYSTEM                    0x0025        // GetSystemDirectory()
#define SD_PROGRAM_FILES             0x0026        // C:\Program Files
#define SD_MYPICTURES                0x0027        // C:\Program Files\My Pictures
#define SD_PROFILE                   0x0028        // USERPROFILE
#define SD_SYSTEMX86                 0x0029        // x86 system directory on RISC
#define SD_PROGRAM_FILESX86          0x002a        // x86 C:\Program Files on RISC
#define SD_PROGRAM_FILES_COMMON      0x002b        // C:\Program Files\Common
#define SD_PROGRAM_FILES_COMMONX86   0x002c        // x86 Program Files\Common on RISC
#define SD_COMMON_TEMPLATES          0x002d        // All Users\Templates
#define SD_COMMON_DOCUMENTS          0x002e        // All Users\Documents
#define SD_COMMON_ADMINTOOLS         0x002f        // All Users\Start Menu\Programs\Administrative Tools
#define SD_CONNECTIONS               0x0031        // Network and Dial-up Connections
//#define SD_INTERNET                  0x0001        // Internet Explorer (icon on desktop)
//#define SD_CONTROLS                  0x0003        // My Computer\Control Panel
//#define SD_PRINTERS                  0x0004        // My Computer\Printers
//#define SD_BITBUCKET                 0x000a        // <desktop>\Recycle Bin
//#define SD_DRIVES                    0x0011        // My Computer
//#define SD_NETWORK                   0x0012        // Network Neighborhood
//#define SD_ALTSTARTUP                0x001d        // non localized startup
//#define SD_COMMON_ALTSTARTUP         0x001e        // non localized common startup
//#define SD_ADMINTOOLS                0x0030        // <user name>\Start Menu\Programs\Administrative Tools

#define SD_FLAG_CREATE               0x8000        // combine with SD_ value to force folder creation in SHGetFolderPath()
#define SD_FLAG_DONT_VERIFY          0x4000        // combine with SD_ value to return an unverified folder path
#define SD_FLAG_MASK                 0xFF00        // mask for all possible flag values

// runtime function
typedef BOOL (WINAPI *SHGETSPECIALFOLDERPATH)(HWND hwndOwner, LPTSTR lpszPath, int nFolder, BOOL fCreate);
SHGETSPECIALFOLDERPATH pSHGetSpecialFolderPath = 0;


// initialisation needed!
HMODULE hShellDLL = LoadLibrary("shell32.dll");
if (hShellDLL)
{
    pSHGetSpecialFolderPath = (SHGETSPECIALFOLDERPATH) GetProcAddress(hShellDLL, "SHGetSpecialFolderPathA");
}

// free module when finished!
FreeLibrary(hShellDLL);


CString GetSystemDir(int iType)
{
    CString str;
    int i = MAX_PATH + 1;
    switch (iType)
    {
        case SD_ROOT:
            str = GetSystemDir(SD_WIN);
            str = str.Left(3);
            break;
        case SD_WIN:
            GetWindowsDirectory(str.GetBuffer(i), i);
            str.ReleaseBuffer();
            break;
        case SD_SYS:
            GetSystemDirectory(str.GetBuffer(i), i);
            str.ReleaseBuffer();
            break;
        default:
            if (pSHGetSpecialFolderPath)
            {
                pSHGetSpecialFolderPath(NULL, str.GetBuffer(MAX_PATH + 1), iType, FALSE);
                str.ReleaseBuffer();
            }
            else
            {
                str = "";
            }
            break;
    }
    return str;
}*/
//--------------------------------------------------------------------------
/*
Check files for existance, attributes, size
Scan directories

Dependencies: CString, CStringList (MFC)
Status: partially unchecked

Web: http://beta.unclassified.de/code/cpp/
*/
/*
int file_exists(CString filename)
{
    return _access(filename, 0) ? false : true;
}

int is_directory(CString strPath)
{
    WIN32_FIND_DATA lpffd;
    HANDLE      hFind;

    hFind = FindFirstFile(strPath, &lpffd);
    if (hFind != INVALID_HANDLE_VALUE)
    {
        if (lpffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            FindClose(hFind);
            return true;
        }
    }
    FindClose(hFind);
    return false;
}

int dir_list_entries(CString strPath, CStringList *slEntries)
{
    WIN32_FIND_DATA lpffd;
    CString   strTmp;
    HANDLE      hFind;
    int    rc, bRet = true;

    strPath = strPath + "\\*.*";

    rc = false;
    hFind = FindFirstFile(strPath, &lpffd);
    while (hFind != INVALID_HANDLE_VALUE && bRet)
    {
        // at least 1 file was found in the directory
        if (*lpffd.cFileName != '.')
        {
            rc = true;
            if (lpffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            {
                // this is a directory
                strTmp.Format("%s", lpffd.cFileName);
                slEntries->AddHead(strTmp);
            }
        }
        bRet = FindNextFile(hFind, &lpffd);
    }
    FindClose(hFind);

    return rc;
}*/
//--------------------------------------------------------------------------
/*
��� 74 - ������� GetCurrentDirectory() � SetCurrentDirectory()
 

������ ������� �������� ������� �������: 

DWORD GetCurrentDirectory
(
	DWORD nBufferLength,	// ������ ������
	LPTSTR lpBuffer		// ��������� �� �����
);

���� ������� ������� �����������, �������� �������� ���������� ����� ��������, ���������� � �����, �� ������� ������ ����������, ����� �������� �������� �������. ���� �����, ��������� �� lpBuffer �� ���������� �������, �������� �������� ���������� ��������� ������ ������, ������� ����� ������, ����������� ��� ������� ����������. 

������ ������� ������������� ������� �������: 

BOOL SetCurrentDirectory
(
	LPCTSTR lpPathName		// ��� ��������
);

���� ��� ���������, �� ������� ������ ��������� ��������, � ��������� ������ ����. �� � ������ ��� ��. 

// TestDir.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include "iostream.h"

void main()
{
	TCHAR buffer[MAX_PATH];
	GetCurrentDirectory(sizeof(buffer),buffer);
	cout << buffer << endl;
	SetCurrentDirectory("C:\\");
	GetCurrentDirectory(sizeof(buffer),buffer);
	cout << buffer << endl;
}

� ��� ��������� � ����: 

C:\VC\TestDir
C:\
Press any key to continue


*/
//--------------------------------------------------------------------------
//////unsigned long int CLog::ulGetFileSize(const std::string &csFilePath) {
//////	HANDLE h = CreateFile(csFilePath.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL); 
//////	if (h == NULL) {
//////	    vLogLastErrStrServ();
//////		CloseHandle(h);
//////		h = NULL;
//////
//////		return 0;
//////	}
//////	
//////	unsigned long int ulFileSize = GetFileSize(h, NULL) / 1000000;  //������ ����� � ������ / 1000000
//////	if (ulFileSize == -1) {
//////		vLogLastErrStrServ();
//////		CloseHandle(h);
//////		h = NULL;
//////		return 0;
//////	}
//////	CloseHandle(h);
//////	h = NULL;
//////	
//////	return ulFileSize;
//////////}

//--------------------------------------------------------------------------
/*Increase



A functor that assigns values increasingly higher.

* View the code of 'Increase' in plain text.





#include <cassert>

#include <functional>

#include <vector>

#include <algorithm>



//From http://www.richelbilderbeek.nl

struct Increase : public std::unary_function<void,int>

{

	explicit Increase(const int& initValue = 0) : mValue(initValue) {}

	void operator()(int& anything)

	{

		anything = mValue;

		++mValue;

	}



private:

	int mValue;

};







int main()

{

	std::vector<int> v(10);

	std::for_each(v.begin(), v.end(), Increase() );

	assert(v[0] == 0);

	assert(v[1] == 1);

	assert(v[2] == 2);

	assert(v[3] == 3);

	assert(v[4] == 4);

}*/
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------