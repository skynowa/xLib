 /****************************************************************************
* Class name:  CXFsoString
* Description: ������ ��� ������ � �������� ��������
* File name:   CXFsoString.h
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:02:43
*
*****************************************************************************/
//http://www.richelbilderbeek.nl/CppFileExists.htm

#ifndef CXFsoStringH
#define CXFsoStringH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <vector>
#include <stdio.h>
//---------------------------------------------------------------------------
//����������
template <class T> void  vRandomShuffle          (std::vector<T> &v); /*-*/
template <class T> void  vSortVector             (std::vector<T> &v); /*-*/

//�������� � ������
std::string				 sExePath                (); /*+*/
std::string              sExeDirPath             (); /*+*/
std::string				 sExtractFilePath        (const std::string &csFilePath); /*+*/
std::string              sExtractFullFileName    (const std::string &csFilePath); /*+*/
std::string              sExtractShortFileName   (const std::string &csFilePath); /*+*/
std::string              sExtractFileExt         (const std::string &csFilePath); /*+*/
std::string              sChangeFileExt          (const std::string &csFilePath, const std::string &csFileExt); /*+*/
std::string              sChangeFullFileName     (const std::string &csFilePath, const std::string &csFileName); /*+*/
std::string              sRemoveFileExt          (const std::string &csFilePath); /*+*/
std::string              sExtractFileDir         (const std::string &csFilePath); /*+*/
std::string              sExtractFileDrive       (const std::string &csFilePath); /*...*/
std::string              sExtractRelativePath    (const std::string &csFilePath); /*...*/

std::string              sUnixToWinPath          (const std::string &csUnixPath, bool bNeedBackslashAtEnd); /*+*/
std::string              sWinToUnixPath          (const std::string &csWinPath,  bool bNeedBackslashAtEnd); /*+*/

std::string              sMinimizeFileName       (const std::string &csStr, const UINT cuiMaxLen);
std::string              sMinimizePath           (const std::string &csPath, const size_t cuiMaxLen);

//������ �����
bool                     bIsDriveReady           (LPCSTR pcszDrivePath); /*+*/
unsigned long int        ulFileLines             (const std::string &csFilePath); /*+*/
bool                     bFileExists             (const std::string &csFilePath); /*+*/
unsigned long int		 ulFileSize              (FILE *pFile); /*+*/
unsigned long int		 ulFileSize			     (const std::string &csFilePath); /*+*/
unsigned __int64         ui64GetFileSize         (HANDLE hFile);	/*-*/
bool					 bGetCompressedFileSize  (LPCTSTR fileName, unsigned __int64 &size);
bool                     bGetCompressedFileSizeW (LPCWSTR fileName, unsigned __int64 &size);

//��������
bool                     bSetFileNormalAttr      (const std::string &csFilePath); /*+*/
int						 iIsFile                 (const std::string &csFilePath); /*+*/	//0, 1, 2
bool					 bIsReadOnly             (ULONG ulAttr);
bool 					 bIsHidden               (ULONG ulAttr);
bool 					 bIsSystem               (ULONG ulAttr);
bool 					 bIsDirectory            (ULONG ulAttr);
bool 					 bIsArchived             (ULONG ulAttr);
bool 					 bIsCompressed           (ULONG ulAttr);
bool 					 bIsEncrypted            (ULONG ulAttr);

//������ / ������ �����
void                     vFileToArray            (const std::string &csFilePath); /*-*/
std::vector<std::string> vecsReadFile            (const std::string &csFilePath); /*-*/
std::vector<char>        vecchReadFile		     (const std::string &csFilePath); /*-*/
std::string				 sReadText   		     (const std::string &csFilePath); /*+*/
bool					 bWriteText  		     (const std::string &csFilePath, const std::string &csText); /*+*/

//�������� � �������
bool                     bCopyFile               (const std::string &csFilePathFrom, const std::string &csFilePathTo); /*+*/
bool                     bMoveFile               (const std::string &csFilePathIn, const std::string &csFilePathOut);	//����, ������� /*+*/
bool                     bRenameFile             (const std::string &csFilePath); /*...*/
bool                     bDeleteFile             (const std::string &csFilePath); /*+*/
bool                     bSecureDeleteFile       (const std::string &csFilePath, UINT uiPasses); /*-*/
bool                     bCutFileFromEnd         (const std::string &csFilePath, LONG lDistanceToCut);	/*+*/
bool                     bCutFileFromEnd         (FILE *pFile, ULONG ulDistanceToCut);	/*+*/
bool                     bCheckSignature         (CHAR *pszBuff, CHAR *pszSignature, INT iSignatureSize);	/*-*/

bool                     bSetRandomFileDate      (const std::string &csFilePath); /*-*/
bool				     bSetFileUncompressedAttr(const std::string &csFilePath); /*-*/
bool			         bSetFileCompressedAttr  (const std::string &csFilePath, bool bCompress); /*-*/

//�������� � �������
std::string              sGetCurrentDir          ();
bool                     bSetCurrentDir          (const std::string &csDirPath);
void                     vForceDirectories       (const std::string &csPath); /*+*/


//������
ULONG                    ulCountDigits           (ULONG ulDigit); 
std::string              sSizeToStr              (ULONG dwSize);
std::string              sFiletimeToStr          (LPFILETIME Filetime);
//---------------------------------------------------------------------------
#endif


/* TODO:

///////////////////////////////////////
bool CUtil::IsPathValid(
//Is a path valid.
//
//Params:
const char *pszPath)		//(in)	Path should not end in separator.
//
//Returns:
//True if it is, false if it isn't.
const
{
return (chdir(pszPath) == 0);
}
//////////////////////////////////////////////////////
::PathIsUNC( strRoot )
//////////////////////////////////////////////////////
::GetFileTitle
//////////////////////////////////////////////////////
void GetModuleShortFileName(HINSTANCE hInst, CString& strShortName)
{
	TCHAR szLongPathName[_MAX_PATH];
	::GetModuleFileName(hInst, szLongPathName, _MAX_PATH);
	if (::GetShortPathName(szLongPathName,	strShortName.GetBuffer(_MAX_PATH), _MAX_PATH) == 0)
	{
		// rare failure case (especially on not-so-modern file systems)
		strShortName = szLongPathName;
	}
	strShortName.ReleaseBuffer();
}
//////////////////////////////////////////////////////
BOOL IsDirSep(TCHAR ch)
{
	return (ch == '\\' || ch == '/');
}
//////////////////////////////////////////////////////

*/