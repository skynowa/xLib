/**********************************************************************
*	�����  CXLog (CXLog.hpp)
*
***********************************************************************/


#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
//---------------------------------------------------------------------------
class CXLog {
	public:
					             CXLog             (const std::string &csFileName, unsigned long int ulMaxFileSize);
						         CXLog			   (unsigned long int ulMaxFileSize);
					            ~CXLog             ();

		void                     vLog              (const std::string &csStr);
		void                     vLog              (const std::string &csComment, const std::string &csStr);
		void                     vLog              (const std::string &csComment, int iValue);
		void                     vLog              (const std::string &csComment, unsigned long int ulLastError);
					
		void                     vLogUCharAsHex    (const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
        void                     vLogUCharAsStr    (const std::string &csFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
		void                     vLogLastErrorStr  (const std::string &csComment, unsigned long int ulLastError);	
        
		void                     vLogToLst         (HWND hLst, const std::string &csStr); 
		void                     vLogToLst         (HWND hLst, const std::string &csComment, const std::string &csStr); 
		void                     vLogToLst         (HWND hLst, const std::string &csComment, int iValue);
		void                     vLogToLst         (HWND hLst, const std::string &csComment, unsigned long int ulValue);
		void                     vLogLastErrorToLst(HWND hLst, const std::string &csComment, unsigned long int ulLastError);  

		void                     vTrace            (const std::string &csStr); 
		void                     vTrace            (const std::string &csComment, const std::string &csStr); 
		void                     vTrace            (const std::string &csComment, int iValue);
		void                     vTrace            (const std::string &csComment, unsigned long int ulValue);
		void                     vTraceLastError   (const std::string &csComment, unsigned long int ulLastError);

		void                     vOpen             ();
		void                     vClear            ();
		void                     vDelete           ();

		void					 vMsgBoxLastError  (const std::string &csComment);
	
	private:
		std::string              m_sLogPath;
		unsigned long int        m_ulMaxFileSize;
		CRITICAL_SECTION         m_csLog;
		CRITICAL_SECTION         m_csLogToLst;

		void                     vDeleteLogIfFull  ();
		std::string              sErrorMessageStr  (unsigned long ulLastError);
};
//---------------------------------------------------------------------------
#endif