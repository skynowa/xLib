#ifndef _COMMON_H_
#define _COMMON_H_

#define SAFE_DELETE(p)       {if (p) {delete p; p = NULL;}}  
#define SAFE_DELETE_ARRAY(a) {if (a) {delete [] a; a = NULL;}}
#define ZERO_BUFF(x)         ::ZeroMemory(&x, sizeof(x));

#endif 