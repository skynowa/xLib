/**********************************************************************
 *	����� MsgBox (MsgBox.hpp)       http://www.richelbilderbeek.nl/CppFileExists.htm
 *
 ***********************************************************************/

 
#pragma once

#ifndef MsgBoxH
#define MsgBoxH   


#include <windows.h>
#include <string>
////#include <vector>
////#include <iostream>
////#include <ostream>

//---------------------------------------------------------------------------
////void MsgBox(unsigned long int    ulText, const char *cpszCaption, unsigned long int ulType);
////void MsgBox(const char        *cpszText, const char *cpszCaption, unsigned long int ulType);
////void MsgBox(signed long int       lText, const char *cpszCaption, unsigned long int ulType);


template <typename T> void MsgBox(T val) {		/*+*/	
	std::ostringstream oss;
	oss << val;

	MessageBox(0, oss.str().c_str(), oss.str().c_str(), MB_OK);
}
//---------------------------------------------------------------------------
#endif