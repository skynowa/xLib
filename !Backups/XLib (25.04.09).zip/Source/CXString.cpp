/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.cpp
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/CXString.h>

#include <windows.h>
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include <tchar.h>
#include <stdlib.h>
#include <cctype>
#include <algorithm>
#include <ctime>

#include <XLib/xassert.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
LONG StrToLONG(LPCTSTR pwszValue, LONG Default /*= 0*/, INT Radix /*= 0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        LONG nResult = _tcstol(pwszValue, &pszStop, Radix);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return (Default);  
}
//---------------------------------------------------------------------------
ULONG StrToDWORD(LPCTSTR pwszValue, DWORD Default /*= 0*/, INT Radix /*= 0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        LONG nResult = _tcstoul(pwszValue, &pszStop, Radix);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return Default;  
}
//---------------------------------------------------------------------------
BOOL StrToBOOL(LPCTSTR pwszValue, BOOL fDefault /* = FALSE */) {
    return *pwszValue != 0 ? _tcschr(_T("1tTyY"), pwszValue[0]) != NULL : fDefault;
}
//---------------------------------------------------------------------------
DOUBLE StrToDOUBLE(LPCTSTR pwszValue, DOUBLE Default /*= 0.0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        DOUBLE nResult = _tcstod(pwszValue, &pszStop);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return Default;    
}
//---------------------------------------------------------------------------
SHORT StrToSHORT(LPCTSTR pwszValue, SHORT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<SHORT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
USHORT StrToWORD(LPCTSTR pwszValue,WORD Default /*= 0*/, INT Radix /*= 0*/) {
	return LOWORD(/*= 0*/StrToDWORD(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
UCHAR StrToBYTE(LPCTSTR pwszValue, UCHAR Default /*= 0*/, INT Radix /*= 0*/) {
	return LOBYTE(LOWORD(/*= 0*/StrToDWORD(pwszValue, Default, Radix)));  
}
//---------------------------------------------------------------------------
bool StrTobool(LPCTSTR pwszValue, bool Default /* = false */) {
    return /*= 0*/StrToBOOL(pwszValue, Default) != 0;
}
//---------------------------------------------------------------------------
INT StrToINT(LPCTSTR pwszValue, INT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<INT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
UINT StrToUINT(LPCTSTR pwszValue, UINT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<UINT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
bool bStrToUCHAR(const std::string &csStr, UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT(false == csStr.empty());
    /*DEBUG*/XASSERT(NULL != pucBuff);    
    /*DEBUG*/XASSERT(0 < uiBuffSize); 
    /*DEBUG*/XASSERT(csStr.size() <= uiBuffSize);     

	for (UINT i = 0; i < csStr.size(); i ++)  { 
		pucBuff[i]  = static_cast<unsigned char>(csStr.at(i)); 
	}    
   
	////std::vector<unsigned char> data;
	////std::copy(csStr.begin(), csStr.end(), std::back_inserter(data));
	////pucBuff = data;

	return true;
}
//---------------------------------------------------------------------------
std::string sUCHARToStr(UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT(NULL != pucBuff);    
    /*DEBUG*/XASSERT(0 < uiBuffSize); 
	
	return std::string((CHAR *)pucBuff, uiBuffSize);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
std::string sTrimSpace(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
    std::string sRes("");
    sRes.assign(csStr);

    while ((!sRes.empty()) && (* sRes.begin() == ' ')) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (* sRes.rbegin() == ' ')) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;
}
//---------------------------------------------------------------------------
std::string sTrimChar(const std::string &csStr, CHAR cChar) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
    std::string sRes("");
    sRes.assign(csStr);

    while ((!sRes.empty()) && (* sRes.begin() == cChar)) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (* sRes.rbegin() == cChar)) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;	
}
//---------------------------------------------------------------------------
std::string sRemoveEOL(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 

	std::string sRes("");
    sRes.assign(csStr);

	//������� \r\n
	sRes = sTrimChar(sRes, '\n');
	sRes = sTrimChar(sRes, '\r');
    
    return sRes;	
}
//---------------------------------------------------------------------------
std::string sReplaceAll(std::string sStr, const std::string &csOldStr, const std::string &csNewStr) {
    /*DEBUG*/XASSERT(false == sStr.empty()); 
    /*DEBUG*/XASSERT(false == csOldStr.empty()); 

	std::string::size_type stPos = std::string::npos;

	while (std::string::npos != (stPos = sStr.find(csOldStr))) {
		sStr = sStr.replace(stPos, 1, csNewStr);
	}

	return sStr;
}
//---------------------------------------------------------------------------
std::string sReplaceAll(const std::string &csStr, CHAR sOldStr, CHAR sNewStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::string sRes("");
    sRes.assign(csStr);
	
	for (UINT i = 0; i < sRes.size(); i ++) {
		if (sRes.at(i) == sOldStr) {
			sRes.at(i) = sNewStr;	
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::vector<std::string> vecsExplode(CHAR cDelimiter, const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::vector<std::string> vecRes;
	std::size_t              uiPos    = std::string::npos;	
	std::size_t              uiOldPos = std::string::npos;
   
   while (std::string::npos != (uiPos = csStr.find_first_of(cDelimiter, uiOldPos))) {
		vecRes.push_back(csStr.substr(uiOldPos, uiPos - uiOldPos));
		uiOldPos = uiPos + 1;
   }
   vecRes.push_back(csStr.substr(uiOldPos, - 1));
   
   return vecRes;
}
//---------------------------------------------------------------------------
std::vector<std::string> vecsExplodeEx(CHAR *pszStr, CHAR *pszDelimiter) {
    /*DEBUG*/XASSERT(NULL != pszStr);        
	/*DEBUG*/XASSERT('\0' != *pszStr); 
    /*DEBUG*/XASSERT(NULL != pszDelimiter);        
	/*DEBUG*/XASSERT('\0' != *pszDelimiter); 

	std::vector<std::string> vecRes;
	std::size_t              uiPos     = std::string::npos; 
	std::size_t              uiPrevPos = std::string::npos;
	std::string              sCopy     = std::string(pszStr);

	while (std::string::npos != (uiPos = sCopy.find(pszDelimiter, uiPos))) {
		vecRes.push_back(std::string(sCopy, uiPrevPos, uiPos - uiPrevPos));
		uiPrevPos = ++ uiPos;
	}
	vecRes.push_back(std::string(sCopy, uiPrevPos, sCopy.size() - uiPrevPos));

	return vecRes;
}
//---------------------------------------------------------------------------
//��������� ������ �� ��������� �� �������-�����������, ��������� ������ ����� (vector)
std::vector<std::string> vecsExplode(const std::string &csSep, const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csSep.empty());	//return std::vector<std::string>()
    /*DEBUG*/XASSERT(false == csStr.empty());
	/*DEBUG*/XASSERT(csStr.substr(0, csSep.size()) != csSep);
	/*DEBUG*/XASSERT(csStr.substr(csStr.size()- csSep.size(), csSep.size()) != csSep);
	
	std::size_t              uiOldPos = std::string::npos; 	//start of string
	std::size_t              uiPos    = std::string::npos;
	std::vector<std::string> vecsExpd;
    while (std::string::npos != (uiPos = csStr.find_first_of(csSep, uiOldPos))) {
		vecsExpd.push_back(csStr.substr(uiOldPos, uiPos - uiOldPos));
		uiOldPos = uiPos + csSep.size()/*1*/;
	}
	vecsExpd.push_back(csStr.substr(uiOldPos, - 1));

	return vecsExpd;
}
//---------------------------------------------------------------------------
//"���������" ������ ������� ��������-������������
std::string sImplode(CHAR cSep, std::vector<std::string> vecsVec) {
	std::string sRes;

	for (size_t i = 0; i < vecsVec.size(); i ++) {
		sRes += vecsVec[i];
		sRes += cSep;
	}

	return sRes;
}
//---------------------------------------------------------------------------
bool bCharToWide(const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize) {
    /*DEBUG*/XASSERT(NULL != pszSrc);        
	/*DEBUG*/XASSERT('\0' != *pszSrc); 
    /*DEBUG*/XASSERT(NULL != pwszDest);        
	/*DEBUG*/XASSERT('\0' != *pwszDest); 
    
	bool bRes = false;
	if (::MultiByteToWideChar(CP_ACP, 0, pszSrc, - 1, pwszDest, iDestSize) == 0) {
		bRes = false;
	}

	return bRes;		
}
//---------------------------------------------------------------------------
CHAR cHexToChar(CHAR *pszStr) {
    /*DEBUG*/XASSERT(NULL != pszStr);        
	/*DEBUG*/XASSERT('\0' != *pszStr); 

	CHAR ch;

	if (pszStr[0] >= 'A') {
		ch = ((pszStr[0] & 0xdf) - 'A') + 10;
	} else {
		ch = pszStr[0] - '0';
	}

	ch <<= 4;

	if (pszStr[1] >= 'A') {
		ch += ((pszStr[1] & 0xdf) - 'A') + 10;
	} else {
		ch += pszStr[1] - '0';
	}

	return ch;
}
//---------------------------------------------------------------------------
//%FF%E4%F0%E5%ED%E0%20%62%75%67%73 -> "������ bugs"
std::string sUrlUnescape(const std::string &csStr) {  /*sBase64Decode*/
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::string sRes("");
    sRes.assign(csStr);

	UINT uiSrc  = 0;
	UINT uiDest = 0;
	CHAR ch     = 0;
	for (uiSrc = 0, uiDest = 0; sRes[uiSrc]; uiSrc ++, uiDest ++)   {
		ch = sRes[uiSrc];
		ch = (ch == '+') ? ' ' : ch;
		sRes[uiDest] = ch;

		if (ch == '%')	{
			sRes[uiDest] = cHexToChar(&sRes[uiSrc + 1]);
			uiSrc += 2;
		}
	}
	sRes[uiDest] = '\0';		//�������� ��� ��� ���� ����� '\0'

	return std::string(sRes.c_str());	//���������� ��-���� ������, ��� �� ����
}
//---------------------------------------------------------------------------
//string -> %20%20%...
std::string sStrToBin(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::string sRes("");
	for (UINT i = 0; i < csStr.size(); i ++) {
		sRes.append("%" + sTypeToStr((INT)((UCHAR)csStr.at(i))));
	}

	return sRes;
}
//---------------------------------------------------------------------------
//%20%20%... -> string  ???????
std::string sBinToStr(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::string              sRes     = "";
	std::vector<std::string> vecsList = vecsExplode('%', csStr);

	for (UINT i = 1; i < vecsList.size(); i ++) {	//i = 1 - ������ ������ ������
		//str(59) -> char() -> string
		INT  iIntValue  = iStrToType<int>(vecsList.at(i));
		CHAR cCharValue = (CHAR)(iIntValue);
		std::string sStrValue(1, cCharValue);

		sRes.append(sStrValue);
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::string sTranslitLatToRus(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 

	std::string sRes("");
    sRes.assign(csStr);

	//-------------------------------------
	//�������
	CONST INT ciDictSize = 66;
	std::string sDict[ciDictSize][2] =	{
			{"�", "Y"},
			{"�", "C"},
			{"�", "U"},
			{"�", "K"},
			{"�", "E"},
			{"�", "E"},
			{"�", "N"},
			{"�", "G"},
			{"�", "SH"},
			{"�", "SH'"},
			{"�", "Z"},
			{"�", "H"},
			{"�", "`"},
			{"�", "F"},
			{"�", "I"},
			{"�", "V"},
			{"�", "A"},
			{"�", "P"},
			{"�", "R"},
			{"�", "O"},
			{"�", "L"},
			{"�", "D"},
			{"�", "ZH"},
			{"�", "E"},
			{"�", "YA"},
			{"�", "4"},
			{"�", "S"},
			{"�", "M"},
			{"�", "I"},
			{"�", "T"},
			{"�", "'"},
			{"�", "B"},
			{"�", "YU"},

			{"�", "y"},
			{"�", "c"},
			{"�", "u"},
			{"�", "k"},
			{"�", "e"},
			{"�", "e"},
			{"�", "n"},
			{"�", "g"},
			{"�", "sh"},
			{"�", "sh'"},
			{"�", "z"},
			{"�", "h"},
			{"�", "`"},
			{"�", "f"},
			{"�", "i"},
			{"�", "v"},
			{"�", "a"},
			{"�", "p"},
			{"�", "r"},
			{"�", "o"},
			{"�", "l"},
			{"�", "d"},
			{"�", "zh"},
			{"�", "e"},
			{"�", "ya"},
			{"�", "4"},
			{"�", "s"},
			{"�", "m"},
			{"�", "i"},
			{"�", "t"},
			{"�", "'"},
			{"�", "b"},
			{"�", "yu"}
	};

	//-------------------------------------
	//������ ��������
	for (INT i = 0; i < ciDictSize; i ++) {
		////sText = sReplaceAll(sText, sDict[i][0], sDict[i][1]);
		std::string            sOldStr = sDict[i][0];
		std::string            sNewStr = sDict[i][1];
		std::string::size_type stPos   = std::string::npos;

		while (std::string::npos != (stPos = sRes.find(sOldStr))) {
			sRes.replace(stPos, 1, sNewStr);
		}
	}

	return sRes;
}
//-------------------------------------------------------------------------
std::string sToLowerCase(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += std::tolower(csStr.at(i));
	}
		
	return sRes;

	/* 
	//explicit cast needed to resolve ambiguity
	std::transform(myString.begin(), myString.end(), myString.begin(), (int(*)(int)) std::tolower);
	*/
}
//---------------------------------------------------------------------------
std::string sToUpperCase(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 

	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += std::toupper(csStr.at(i));
	}
		
	return sRes;

	/*
	//explicit cast needed to resolve ambiguity
	std::transform(s.begin(), s.end(), s.begin(), (int(*)(int)) std::toupper);
	return s;
	*/
}
//---------------------------------------------------------------------------
INT	iCharCodeAt(const std::string &csStr, INT iIndex) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    /*DEBUG*/XASSERT(0 < iIndex); 
        
	return static_cast<INT>(csStr.at(iIndex));
}
//---------------------------------------------------------------------------




/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//This is ASCII specific but is safe with chars >= 0x80
bool bIsSpaceChar(UCHAR ch) {
	return (ch == ' ') || ((ch >= 0x09) && (ch <= 0x0d));
}
//---------------------------------------------------------------------------
bool bIsPunctuation(CHAR ch) {
	return isascii(ch) && ispunct(ch);
}
//---------------------------------------------------------------------------
bool bIsADigit(CHAR ch) {
	return isascii(ch) && isdigit(ch);
}
//---------------------------------------------------------------------------
bool bIsLowerCase(CHAR ch) {
	return isascii(ch) && islower(ch);
}
//---------------------------------------------------------------------------
bool bIsUpperCase(CHAR ch) {
	return isascii(ch) && isupper(ch);
}
//---------------------------------------------------------------------------
bool bIsASpaceOrTab(UINT ch) {
	return (ch == ' ') || (ch == '\t');
}
//---------------------------------------------------------------------------
bool bIsADigit(UINT ch) {
	return (ch >= '0') && (ch <= '9');
}
//---------------------------------------------------------------------------
bool bIsADigit(UINT ch, UINT base) {
	if (base <= 10) {
		return (ch >= '0') && (ch < '0' + base);
	} else {
		return ((ch >= '0') && (ch <= '9'))            ||
		       ((ch >= 'A') && (ch < 'A' + base - 10)) ||
		       ((ch >= 'a') && (ch < 'a' + base - 10));
	}
}
//---------------------------------------------------------------------------
INT iGetHexChar(UCHAR hd1, UCHAR hd2) {
	int iHexValue = 0;
	
	if (hd1 >= '0' && hd1 <= '9') {
		iHexValue += 16 * (hd1 - '0');
	} else if (hd1 >= 'A' && hd1 <= 'F') {
		iHexValue += 16 * (hd1 - 'A' + 10);
	} else if (hd1 >= 'a' && hd1 <= 'f') {
		iHexValue += 16 * (hd1 - 'a' + 10);
	} else {
		return - 1;
	}

	if (hd2 >= '0' && hd2 <= '9') {
		iHexValue += hd2 - '0';
	} else if (hd2 >= 'A' && hd2 <= 'F') {
		iHexValue += hd2 - 'A' + 10;
	} else if (hd2 >= 'a' && hd2 <= 'f') {
		iHexValue += hd2 - 'a' + 10;
	} else {
		return - 1;
	}
		
	return iHexValue;
}
//---------------------------------------------------------------------------
bool bIsLetter(CHAR ch) {
	return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'));
}
//---------------------------------------------------------------------------
bool bIsASpace(UINT ch) {
    return (ch == ' ') || ((ch >= 0x09) && (ch <= 0x0d));
}
//---------------------------------------------------------------------------
//non-Unicode characters only
CHAR cMakeUpperCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
		return static_cast<char>(ch - 'a' + 'A');
	}
}
//---------------------------------------------------------------------------
//non-Unicode characters only
CHAR cMakeLowerCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
        return static_cast<char>(ch - 'A' + 'a');
	}
}
//---------------------------------------------------------------------------
bool IsEOLChar(CHAR ch) {
	return (ch == '\r') || (ch == '\n');
}
//---------------------------------------------------------------------------
bool IsLineEndChar(CHAR c) {
	return (c == '\n' || c == '\r');
}
//---------------------------------------------------------------------------
//���������� ���� ��������� n (���������)
ULONG ulCountDigits(ULONG ulDigit) {
    ULONG i = 1;
    
	for (; (ulDigit /= 10); i ++);
    
	return i;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	������
*
*****************************************************************************/


//---------------------------------------------------------------------------
//Functions to handle UFT-8 and UCS-2 strings
enum         {SURROGATE_LEAD_FIRST  = 0xD800};
enum         {SURROGATE_TRAIL_FIRST = 0xDC00};
enum         {SURROGATE_TRAIL_LAST  = 0xDFFF};

UINT UTF8Length(const WCHAR *uptr, UINT tlen) {
    /*DEBUG*/XASSERT(NULL != uptr);        
	/*DEBUG*/XASSERT('\0' != *uptr);
    /*DEBUG*/XASSERT(0 < tlen);    

	UINT len = 0;
	for (UINT i = 0; i < tlen && uptr[i];) {
		UINT uch = uptr[i];
		if (uch < 0x80) {
			len++;
		} else if (uch < 0x800) {
			len += 2;
		} else if ((uch >= SURROGATE_LEAD_FIRST) &&
			(uch <= SURROGATE_TRAIL_LAST)) {
			len += 4;
			i++;
		} else {
			len += 3;
		}
		i++;
	}
    
	return len;
}
//---------------------------------------------------------------------------
VOID UTF8FromUTF16(const WCHAR *uptr, UINT tlen, CHAR *putf, UINT len) {
    /*DEBUG*/XASSERT(NULL != uptr);        
	/*DEBUG*/XASSERT('\0' != *uptr); 
    /*DEBUG*/XASSERT(0 < tlen);
    
    /*DEBUG*/XASSERT(NULL != putf);        
	/*DEBUG*/XASSERT('\0' != *putf); 
    /*DEBUG*/XASSERT(0 < len);

	int k = 0;
	for (UINT i = 0; i < tlen && uptr[i];) {
		UINT uch = uptr[i];
		if (uch < 0x80) {
			putf[k++] = static_cast<char>(uch);
		} else if (uch < 0x800) {
			putf[k++] = static_cast<char>(0xC0 | (uch >> 6));
			putf[k++] = static_cast<char>(0x80 | (uch & 0x3f));
		} else if ((uch >= SURROGATE_LEAD_FIRST) &&
			(uch <= SURROGATE_TRAIL_LAST)) {
			// Half a surrogate pair
			i++;
			UINT xch = 0x10000 + ((uch & 0x3ff) << 10) + (uptr[i] & 0x3ff);
			putf[k++] = static_cast<char>(0xF0 | (xch >> 18));
			putf[k++] = static_cast<char>(0x80 | (xch >> 12) & 0x3f);
			putf[k++] = static_cast<char>(0x80 | ((xch >> 6) & 0x3f));
			putf[k++] = static_cast<char>(0x80 | (xch & 0x3f));
		} else {
			putf[k++] = static_cast<char>(0xE0 | (uch >> 12));
			putf[k++] = static_cast<char>(0x80 | ((uch >> 6) & 0x3f));
			putf[k++] = static_cast<char>(0x80 | (uch & 0x3f));
		}
		i++;
	}
	putf[len] = '\0';
}
//---------------------------------------------------------------------------
UINT UTF16Length(const CHAR *s, UINT len) {
    /*DEBUG*/XASSERT(NULL != s);        
	/*DEBUG*/XASSERT('\0' != *s); 
    /*DEBUG*/XASSERT(0 < len);
    
	UINT ulen = 0;
	UINT charLen;
    
	for (UINT i = 0; i < len; ) {
		unsigned char ch = static_cast<unsigned char>(s[i]);
		if (ch < 0x80) {
			charLen = 1;
		} else if (ch < 0x80 + 0x40 + 0x20) {
			charLen = 2;
		} else if (ch < 0x80 + 0x40 + 0x20 + 0x10) {
			charLen = 3;
		} else {
			charLen = 4;
			ulen++;
		}
		i += charLen;
		ulen++;
	}
    
	return ulen;
}
//---------------------------------------------------------------------------
UINT UTF16FromUTF8(const CHAR *s, UINT len, WCHAR *tbuf, UINT tlen) {
    /*DEBUG*/XASSERT(NULL != s);        
	/*DEBUG*/XASSERT('\0' != *s); 
    /*DEBUG*/XASSERT(0 < len);
    
    /*DEBUG*/XASSERT(NULL != tbuf);        
	/*DEBUG*/XASSERT('\0' != *tbuf); 
    /*DEBUG*/XASSERT(0 < tlen);
    
	UINT ui=0;
	const UCHAR *us = reinterpret_cast<const UCHAR *>(s);
	UINT i=0;
	while ((i<len) && (ui<tlen)) {
		UCHAR ch = us[i++];
		if (ch < 0x80) {
			tbuf[ui] = ch;
		} else if (ch < 0x80 + 0x40 + 0x20) {
			tbuf[ui] = static_cast<WCHAR>((ch & 0x1F) << 6);
			ch = us[i++];
			tbuf[ui] = static_cast<WCHAR>(tbuf[ui] + (ch & 0x7F));
		} else if (ch < 0x80 + 0x40 + 0x20 + 0x10) {
			tbuf[ui] = static_cast<WCHAR>((ch & 0xF) << 12);
			ch = us[i++];
			tbuf[ui] = static_cast<WCHAR>(tbuf[ui] + ((ch & 0x7F) << 6));
			ch = us[i++];
			tbuf[ui] = static_cast<WCHAR>(tbuf[ui] + (ch & 0x7F));
		} else {
			// Outside the BMP so need two surrogates
			int val = (ch & 0x7) << 18;
			ch = us[i++];
			val += (ch & 0x3F) << 12;
			ch = us[i++];
			val += (ch & 0x3F) << 6;
			ch = us[i++];
			val += (ch & 0x3F);
			tbuf[ui] = static_cast<WCHAR>(((val - 0x10000) >> 10) + SURROGATE_LEAD_FIRST);
			ui++;
			tbuf[ui] = static_cast<WCHAR>((val & 0x3ff) + SURROGATE_TRAIL_FIRST);
		}
		ui++;
	}
	return ui;
}
//---------------------------------------------------------------------------
std::string wstring2string(std::wstring wstr) {
    /*DEBUG*/XASSERT(false == wstr.empty()); 

	std::string str("", wstr.size());
	////std::copy(wstr.begin(), wstr.end(), str.begin()); //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	
	return str;
}
//---------------------------------------------------------------------------
std::wstring string2wstring(std::string str) {
    /*DEBUG*/XASSERT(false == str.empty()); 
    
	std::wstring wstr(L"", str.size());
	std::copy(str.begin(), str.end(), wstr.begin());
	/*return s.c_str();*/
    
	return wstr;
}
//---------------------------------------------------------------------------
bool bIsUnicode(UCHAR *pucData, INT iSize) {
    /*DEBUG*/XASSERT(NULL != pucData);
    /*DEBUG*/XASSERT(0 < iSize);      
    
	if (iSize < 4 || pucData[0] != 0xff || pucData[1] != 0xfe) {
		return false;
	}
	for (INT i = 2; i < iSize; i ++) {
		if (pucData[i] < 32 && pucData[i] != '\r' && pucData[i] != '\n') {
			return true;
		}
	}

	return false;
}
//---------------------------------------------------------------------------
//convert from string to wstring
std::wstring wsStrToWstr(const std::string &csSrc) {
    /*DEBUG*/XASSERT(false == csSrc.empty()); 
    
	std::wstring wsRes;
	for (size_t i = 0; i < csSrc.size(); ++ i) {
		wsRes += static_cast<wchar_t>(csSrc[i]);
	}
		
	return wsRes;
}
//---------------------------------------------------------------------------
//convert from wstring to string
std::string sWstrToStr(const std::wstring &cwsSrc) {
    /*DEBUG*/XASSERT(false == cwsSrc.empty()); 
    
	std::string sRes = "";
	for (size_t i = 0; i < cwsSrc.size(); ++ i) {
		sRes += static_cast<char>(cwsSrc[i]);
	}
		
	return sRes;
}
//---------------------------------------------------------------------------
std::wstring wsASCIIToUnicode(const std::string &csSrc) {
    /*DEBUG*/XASSERT(false == csSrc.empty()); 
    
	std::wstring wsRes;
	for (size_t i = 0; i < csSrc.size(); ++ i) {
		wsRes += static_cast<wchar_t>(csSrc[i]);
	}
		
	return wsRes;
}
//---------------------------------------------------------------------------
std::string sUnicodeToASCII(const std::wstring &cwsSrc) {
    /*DEBUG*/XASSERT(false == cwsSrc.empty()); 
    
	std::string sRes;
	for (size_t i = 0; i < cwsSrc.size(); ++ i) {
		sRes += static_cast<char>(cwsSrc[i]);
    }
		
	return sRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/


//---------------------------------------------------------------------------
std::string sStrToRtf(std::string sStr) {
    /*DEBUG*/XASSERT(false == sStr.empty()); 
    
    std::ostringstream    ss;
    std::string::iterator i = sStr.begin();

    while (i < sStr.end()) {
        //if ( ( ( INT ) ( unsigned char ) *i ) > 127 )
        INT c = static_cast<INT>(static_cast<UCHAR>(*i));
		if (c > 127) {
            //ss << hex << "\\\'" << ( INT ) ( unsigned char ) *i;
            ss << std::hex << "\\\'" << c;
		} else {
            //ss << ( UCHAR ) *i;
            ss << static_cast<UCHAR>( *i );
		}
        i ++;
    }

    return ss.str();
}
//---------------------------------------------------------------------------
std::string sRtfToStr(std::string sStr) {
    /*DEBUG*/XASSERT(false == sStr.empty()); 
    
    std::string::size_type	resultPos = std::string::npos;
    std::string::size_type	startFind = std::string::npos;
    std::ostringstream		ss;
    char					buf[]     = "ff";
    char				   *resPos    = &buf[0];
    char				   *pstr      = NULL;

    //Search \'xx
    while (std::string::npos != (resultPos = sStr.find("\\\'", startFind))) {
        //copy start part of string
		if (resultPos > startFind) {
            ss << sStr.substr(startFind, resultPos - startFind);
		}

        //if (end) exit
		if (resultPos + 4 > sStr.size()) {
            break;
		}

        //Copy char
        sStr.copy(buf, 2, resultPos + 2);
        LONG CharCode = strtoul(resPos, &pstr, 16);
        if (CharCode > 127) {
            ss << static_cast<UCHAR>(strtoul(resPos, &pstr, 16)); // 16 == hex base
            startFind = resultPos + 4;
        } else {
            ss << "\\\'";
            startFind = resultPos + 2;
        }
    }

    //copy end part of string
	if (startFind < sStr.size()) {
        ss << sStr.substr(startFind, sStr.size() - startFind );
	}

    return ss.str();
}
//---------------------------------------------------------------------------
std::string sFormatStr(const CHAR *pcszFormat, ...) {
////	//-------------------------------------
////	//CHECK
////	if (NULL == pcszFormat || '\0' == pcszFormat[0]) {
////		return "";
////	}
////
////	//-------------------------------------
////	//JOB
////	std::vector<char> vecchBuff(128, 0);
////	size_t uiLen = 0;
////
////	::va_list pszArgList = NULL;
////	va_start(pszArgList, pcszFormat);
////
////	for(;;) {
////		//���� win32 �� ���������� _vsnprintf
////		uiLen = ::_vsnprintf(&vecchBuff[0], vecchBuff.size(), pcszFormat, pszArgList);
////		if (uiLen >= 0 && uiLen < vecchBuff.size()) {
////			break; //succeeded
////		}
////		vecchBuff.resize(vecchBuff.size() * 2);
////	}
////
////	va_end(pcszFormat);
////
////	return std::string(vecchBuff.begin(), vecchBuff.begin() + uiLen/* - 1*/);
    return "";
}
//---------------------------------------------------------------------------
std::string sFormatStr2(const CHAR *pcszFormat, ...) {
	CHAR szFormatBuf[1024]; ::ZeroMemory(&szFormatBuf, sizeof(szFormatBuf));

	va_list pszArgList = NULL;
	va_start(pszArgList, pcszFormat);
	::wvsprintf(szFormatBuf, pcszFormat, pszArgList);
	va_end(pszArgList);

	return std::string(szFormatBuf);
}
//---------------------------------------------------------------------------
std::string sMinimizeStr(const std::string &csStr, const UINT cuiMaxLen) {	
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    /*DEBUG*/XASSERT(0 < cuiMaxLen); 
	
	std::string sRes("");

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < 3) {
			sRes = csStr.substr(0, cuiMaxLen);
    	} else {
			sRes = csStr.substr(0, cuiMaxLen - 3) + "...";
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//--------------------------------------------------------------------------
std::string sCreatePlainGUID() { 
	GUID  gidGuid;	    ::ZeroMemory(&gidGuid, sizeof(gidGuid));
	TCHAR szBuff[250];	::ZeroMemory(&szBuff,  sizeof(szBuff));

	CoCreateGuid(&gidGuid);	 
	const std::string sFormat = "%04X-%02X-%02X-%02X%02X-%02X%02X%02X%02X%02X%02X";

	::wsprintf(
		szBuff, 
		sFormat.c_str(),
		gidGuid.Data1, 
		gidGuid.Data2, 
		gidGuid.Data3,
		gidGuid.Data4[0], gidGuid.Data4[1],
		gidGuid.Data4[2], gidGuid.Data4[3], gidGuid.Data4[4], gidGuid.Data4[5], gidGuid.Data4[6], gidGuid.Data4[7]
	);
    
	return std::string(szBuff);
}   
//---------------------------------------------------------------------------
bool bIsRepeatedStr(const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csStr.empty()); 
    
	size_t uiStrLen = csStr.size();
	for (size_t i = 1; i < uiStrLen; i ++) {
		if (csStr.at(0) != csStr.at(i)) {
			return false;
		}
	}

	return true;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Random
*
*****************************************************************************/


//--------------------------------------------------------------------------
//////void RandomizeTimer() {
//////	  std::srand(std::time(0));
//////}
//--------------------------------------------------------------------------



/****************************************************************************
*	��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
/*void RemoveChar(string & str, const char ch) {
    for (int i = str.find(ch); i != string::npos; i = str.find(ch)) {
        str.erase(i, 1);
    }
}*/
//---------------------------------------------------------------------------


/**********************************************************************
*
*   <<< ������ �������������: >>>
*   std::string str;
*   int         iVal;
*   float       fVal;
*
*   str = sTypeToStr(iVal);
*   str = sTypeToStr(fVal);
*
*   iVal = iStrToType<int>(str);
*   fVal = iStrToType<float>(str);
*
***********************************************************************/
/**********************************************************************
LARGE_INTEGER li = {1234567890};
std::stringstream ss;
ss << li;
std::string s = ss.str();
***********************************************************************/

