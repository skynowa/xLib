/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

   

//---------------------------------------------------------------------------
#include <XLib/CXPop3.h> 

#include <stdio.h>   
#include <string>   
#include <iostream>
#include <XLib/xassert.h>   
#include <XLib/CXString.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------  


/****************************************************************************
*	Private methods
*
*****************************************************************************/



//---------------------------------------------------------------------------
CPop3::CPop3() {   
	WSocket::Init();   
}   
//--------------------------------------------------------------------------- 
CPop3::~CPop3() {   
	WSocket::iClean();   
}   
//--------------------------------------------------------------------------- 
 bool CPop3::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, unsigned short int usPort) {   
	 m_sUser   = csUser;   
	 m_sPass   = csPass;   
	 m_sServer = csServer;   
	 m_usPort  = usPort;   

	 return true;  
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bConnect() {   
     //Create sock   
     m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);   
    
     //Parse domain   
     char szIpAddr[16];		memset(szIpAddr, 0, sizeof(szIpAddr));
	 if (true != WSocket::bDnsParse(m_sServer.c_str(), szIpAddr)) {   
         return false;   
	 }
    
     //Connect   
	 if (true != m_scktSocket.bConnect(szIpAddr, m_usPort)) {  
         return false;   
	 }
    
	 //-------------------------------------
	 //[welcome message] 
     char szRecv[128];		memset(szIpAddr, 0, sizeof(szIpAddr)); 

     int iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	 /*DEBUG*/XASSERT(0 < iRes);
	 /*DEBUG*/XASSERT(false == bIsError(szRecv));
    
#ifdef _DEBUG   
     szRecv[iRes] = '\0';   
     printf("Recv POP3 Resp: %s", szRecv);   
#endif   
    
     return true;   
 }   
//---------------------------------------------------------------------------    
bool CPop3::bLogin() {  
	int  iRes = - 1;
	char szRecv[ms_cuiRecvSize];		memset(szRecv, 0, sizeof(szRecv));   

	//-------------------------------------
	//[USER\r\n]
	std::string sUserCmd = "USER " + m_sUser + "\r\n";

	iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
	/*DEBUG*/XASSERT(sUserCmd.size() == iRes);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv USER Resp: %s", szRecv);   
#endif     

	//-------------------------------------
	//[PASS\r\n]   
	std::string sPassCmd = "PASS " + m_sPass + "\r\n";

	iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
	/*DEBUG*/XASSERT(sPassCmd.size() == iRes);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv PASS Resp: %s", szRecv);   
#endif         

	return true; 
}   
//---------------------------------------------------------------------------
bool CPop3::bList(std::vector<ULONG> &veculList) {
	/*
	+OK scan listing follows
	1 570829
	2 571012
	.
	*/
////	int  iRes = - 1; 
////	char szRecv[100024];	    memset(szRecv, 0, sizeof(szRecv));  
////
////	//-------------------------------------
////	//[LIST\r\n]   
////	std::string sListCmd = "LIST\r\n";
////
////	iRes =  m_scktSocket.iSend(sListCmd.c_str(), sListCmd.size(), 0); 
////	/*DEBUG*/XASSERT(sListCmd.size() == iRes);
////
////	iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
////	/*DEBUG*/XASSERT(0 < iRes);
////	/*DEBUG*/XASSERT(false == bIsError(szRecv));  
////	szRecv[iRes] = '\0';   
////
////#ifdef _DEBUG   
////	printf("Recv LIST Resp: %s", szRecv);   
////#endif   
////	
////	///????std::vector veculRes = vecsExplode('\r\n', std::string(szRecv));


	return false;  
}	
//---------------------------------------------------------------------------
bool CPop3::bListAt(ULONG &ulIndex) {
	//...

	return false;
}	               
//---------------------------------------------------------------------------    
bool CPop3::bStat(unsigned long int &ulSum, unsigned long int &ulSize) {   
	int  iRes = - 1; 
	char szRecv[1024];	    memset(szRecv, 0, sizeof(szRecv));  

	//-------------------------------------
	//[LIST\r\n]   
	std::string sStatCmd = "STAT\r\n";

	iRes =  m_scktSocket.iSend(sStatCmd.c_str(), sStatCmd.size(), 0); 
	/*DEBUG*/XASSERT(sStatCmd.size() == iRes);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));  
	szRecv[iRes] = '\0';   

	ulSum  = ulMailsSum (std::string(szRecv));
	ulSize = ulMailsSize(std::string(szRecv));

#ifdef _DEBUG   
	printf("Recv STAT Resp: %s", szRecv); 
	//+OK 2 1141841
	printf("Recv STAT Resp: MailsSum  = %u\n", ulSum); 
	printf("Recv STAT Resp: MailsSize = %u\n", ulSize);
#endif  

	return true;       
}
//---------------------------------------------------------------------------    
bool CPop3::bRetriveRaw(int iNum, const std::string &csDirPath) {  //csDirPath ��� ����� 
	int    iRes       = - 1;   
	FILE  *pFile      = NULL;   
	int    iFlag      = 0;   
	   
	char   szRecv[100240];		memset(&szRecv, 0, sizeof(szRecv)); 

	//-------------------------------------
	//[RETR 3\r\n]
	char szNum[32];			memset(szNum, 0, sizeof(szNum));
	sprintf(szNum, "%d", iNum);
	std::string sRetrCmd = "RETR " + std::string(szNum) + "\r\n";
    
    iRes = m_scktSocket.iSend(sRetrCmd.c_str(), sRetrCmd.size(), 0); 
    /*DEBUG*/XASSERT(sRetrCmd.size() == iRes);



	//-------------------------------------
	//(1) ������ �� ������ � ����� ����� � ����
////////	size_t uiRecvSize = 0;
////////    do {   
////////        iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
////////    	/*DEBUG*/XASSERT(0 < iRes);
////////        szRecv[iRes] = '\0';   
////////
////////        //Get mail subject   
////////        if (0 == iFlag) {   
////////            iFlag = 1;   
////////            pFile = fopen((csDirPath + "/Msg_" + std::string(szNum) + ".eml").c_str(), "wb");
////////            /*DEBUG*/XASSERT(NULL != pFile);
////////        }   
////////
////////#ifdef _DEBUG   
////////        ////printf("Recv RETR Resp: %s", recvbuf);   
////////#endif   
////////
////////        uiRecvSize = strlen(szRecv);   
////////        if (uiRecvSize != fwrite(szRecv, 1, uiRecvSize, pFile)) {   
////////            fclose(pFile);   
////////            return false;   
////////        }   
////////        fflush(pFile);   
////////	} 
////////	while ((char *)NULL == strstr(szRecv, "\r\n.\r\n"));   

	//-------------------------------------
	//(2) ������ �� ������ � ����� ����� � ����
	////size_t uiRecvSize = sizeof(szRecv); //1024;	  /////////---uiRecvSize = strlen(szRecv); 
	////for (;;) {   
	////	iRes = iPop3Recv(szRecv, uiRecvSize - 1, 0);   
	////	/*DEBUG*/
 ////       if (iRes < 0) {   
 ////           break;  
 ////       } 
	////	szRecv[iRes] = '\0';   

	////	//������� ����
	////	if (0 == iFlag) {   
	////		iFlag = 1;   
	////		pFile = fopen((csDirPath + "/Msg_" + std::string(szNum) + ".eml").c_str(), "wb");
	////		/*DEBUG*/XASSERT(NULL != pFile);
 ////   	}   

	////	size_t uiWriteSize = fwrite(szRecv, 1, uiRecvSize, pFile); 
 ////       /*DEBUG*/XASSERT(0          == ferror(pFile));
	////	/*DEBUG*/XASSERT(uiRecvSize == uiWriteSize);   
 ////       if (uiWriteSize <= 0) {
 ////           break;
 ////       }   
	////	fflush(pFile); 

	////	if ((char *)NULL != strstr(szRecv, "\r\n.\r\n")) {
	////		break; 
	////	}
	////} 
	

	//-------------------------------------
	//(3)
	size_t uiRecvSize = 0;
	for (;;) {   
		iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
		/*DEBUG*/XASSERT(0 < iRes);
		szRecv[iRes] = '\0';   

		//Get mail subject   
		if (0 == iFlag) {   
			iFlag = 1;   
			pFile = fopen((csDirPath + "/Msg_" + std::string(szNum) + ".eml").c_str(), "wb");
			/*DEBUG*/XASSERT(NULL != pFile);
		}   

		uiRecvSize = strlen(szRecv); 
		size_t uiWriteSize = fwrite(szRecv, 1, uiRecvSize, pFile); 
		/*DEBUG*/XASSERT(0          == ferror(pFile));
		/*DEBUG*/XASSERT(uiRecvSize == uiWriteSize); 
		fflush(pFile);  

		if ((char *)NULL != strstr(szRecv, "\r\n.\r\n")) {
			break; 
		}
	}   




    /*DEBUG*/XASSERT(NULL != pFile);
    if (NULL != pFile) {
        fflush(pFile);	
		fclose(pFile);	pFile = NULL;
    }

    return true;  
}   
//---------------------------------------------------------------------------   
bool CPop3::bDisconnect() {   
	int iRes = - 1;
  
	char        szRecv[ms_cuiRecvSize];			memset(szRecv, 0, sizeof(szRecv));   
	std::string sQuitCmd = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT(sQuitCmd.size() == iRes);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT(0 < iRes);
	/*DEBUG*/XASSERT(false == bIsError(szRecv));

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", szRecv);   
#endif     

	m_scktSocket.iClose();   

	return true; 
}   
//---------------------------------------------------------------------------   
bool CPop3::bGetSubject(char *pszSubject, const char *pcszBuf) {   
    const char *p = strstr(pcszBuf, "Subject: ");   
	if (NULL == p) {  
        return false; 
	}
    
    p = p + 9;   
    for (int i = 0; i < 32; i++) {   
        if (p[i] == '\r' || p[i] == '\n') {   
            pszSubject[i] = '\0';   
            break;   
        }  

        pszSubject[i] = p[i];   
    }   
    
    return true;   
}   
//---------------------------------------------------------------------------   
////int CPop3::iGetMailSum(const char *pcszBuff) {   
////	int         iSum = 0;   
////	const char *p    = strstr(pcszBuff, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	p = strstr(p + 2, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	while (NULL != (p = strstr(p + 2, "\r\n"))) {   
////		iSum ++;   
////	}   
////
////	return iSum;   
////}
//---------------------------------------------------------------------------
unsigned long int CPop3::ulMailsSum(const std::string &csServerAnswer) {
	//+OK 2 1141841
	unsigned long int ulSum = 0;   
	std::string       sSum  = ""; 
	
	sSum  = vecsExplode(' ', csServerAnswer)[1]; 
	ulSum = atol(sSum.c_str());		//!!! ul -> l
	
	return ulSum;
}
//---------------------------------------------------------------------------
unsigned long int CPop3::ulMailsSize(const std::string &csServerAnswer) {
	//+OK 2 1141841
	unsigned long int ulSize = 0;   
	std::string       sSize  = ""; 

	sSize  = vecsExplode(' ', csServerAnswer)[2]; 
	ulSize = atol(sSize.c_str());	//!!! ul+\r\n -> l

	return ulSize;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
int CPop3::iPop3Recv(char *pszInBuff, int iInBuffSize, int iFlags) {   
	/*DEBUG*/XASSERT(NULL != pszInBuff);
	/*DEBUG*/XASSERT(0     < iInBuffSize);

	int iRes   = - 1;   
	int iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iRecv(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		if (iRes < 0) {  
			/*DEBUG*/XASSERT(false);
			return - 1;   
		}

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((char *)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
bool CPop3::bIsError(const std::string &sText) {
	/*DEBUG*/XASSERT(true == !sText.empty());

	//-------------------------------------
	//CHECK
	if (true == sText.empty()) {
		return true;
	}    

	//-------------------------------------
	//JOB
	if (0 == memcmp(sText.c_str(), "+OK", 3)) {
		return false;
	} 
	if (0 == memcmp(sText.c_str(), "-ERR", 4)) {
		return true;
	} 
	
	/*DEBUG*/XASSERT_EX(false, sText.c_str());
	
	return true;
}
//---------------------------------------------------------------------------