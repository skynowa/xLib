/**********************************************************************
 *	����� MsgBox (MsgBox.cpp)
 *
 ***********************************************************************/
 

#include <windows.h>
#include <string>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
const unsigned long int culTextBuffLen = 1024;
//---------------------------------------------------------------------------
void MsgBox(unsigned long int ulText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%u", ulText);
	::MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(const char *cpszText, const char *cpszCaption = "Debug", unsigned long int ulType = MB_OK) {
	::MessageBox(0, cpszText, cpszCaption, ulType);
}
//---------------------------------------------------------------------------
void MsgBox(signed long int  lText, const char *cpszCaption, unsigned long int ulType) {
	char szBuff[culTextBuffLen];	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "%i", lText);
	::MessageBox(0, szBuff, cpszCaption, ulType);
}
//---------------------------------------------------------------------------


