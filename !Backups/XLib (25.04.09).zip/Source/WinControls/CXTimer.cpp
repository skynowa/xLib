/**********************************************************************
*	����� CXTimer (CXTimer.cpp)
*
***********************************************************************/


#include <XLib/WinControls/CXTimer.h>
//---------------------------------------------------------------------------
CXTimer::CXTimer() {	
	_m_sClassName = WC_TABCONTROL;
	_m_iLeft      = 0;
	_m_iTop       = 0;
	_m_iWidth     = 650;
	_m_iHeight    = 350;	
}
//---------------------------------------------------------------------------
BOOL CXTimer::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	vStartCommonControls(ICC_TAB_CLASSES);

	_m_hWnd = ::CreateWindowEx(
						dwExStyles, 
						_m_sClassName.c_str(), 
						NULL, 
						WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS | dwStyles,  
						_m_iLeft,	
						_m_iTop,	 
						_m_iWidth, 
						_m_iHeight, 
						hParent,	 
						(HMENU)hmnuID,			
						(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
						this); 

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------