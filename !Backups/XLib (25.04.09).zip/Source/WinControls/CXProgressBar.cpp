/****************************************************************************
*	CXProgressBar
*
*****************************************************************************/


#include <XLib/WinControls/CXProgressBar.h>
//---------------------------------------------------------------------------
CXProgressBar::CXProgressBar() {
	_m_sClassName = PROGRESS_CLASS;	////"msctls_progress32";
	_m_iLeft      = _m_iTop    = 0;
	_m_iWidth     = _m_iHeight = 50;
}
//---------------------------------------------------------------------------
BOOL CXProgressBar::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	vStartCommonControls(ICC_PROGRESS_CLASS);

	_m_hWnd = ::CreateWindowEx(
				dwExStyles, 
				_m_sClassName.c_str(),
				_m_sText.c_str(), 
				WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP | dwStyles, 
				_m_iLeft, 
				_m_iTop, 
				_m_iWidth, 
				_m_iHeight, 
				hParent, 
				(HMENU)hmnuID,	 
				(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
				this);

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------
int CXProgressBar::SetRange(int nMin, int nMax) {	 //�������� ��������� �������� � ��������� �������� (� �������� �� 0 �� 65535).
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETRANGE, (WPARAM)0, (LPARAM)MAKELPARAM(nMin, nMax));
}
//---------------------------------------------------------------------------
int CXProgressBar::SetRange32(int nMin, int nMax) {	 
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETRANGE32, (WPARAM)nMin, (LPARAM)nMax);
}
//---------------------------------------------------------------------------
void CXProgressBar::GetRange(PPBRANGE pPBRange) {
	assert(bIsWindow());

	::SendMessage(_m_hWnd, PBM_GETRANGE, (WPARAM)TRUE, (LPARAM)pPBRange);
}
//---------------------------------------------------------------------------
int CXProgressBar::GetRangeLimit(BOOL bLimit) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_GETRANGE, (WPARAM)bLimit, (LPARAM)NULL);
}
//---------------------------------------------------------------------------
int CXProgressBar::GetMaxValue() {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_GETRANGE, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
int CXProgressBar::GetMinValue() {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_GETRANGE, (WPARAM)1, (LPARAM)0);
}
//---------------------------------------------------------------------------
int CXProgressBar::SetPos(int nPos) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETPOS, nPos, 0);
}
//---------------------------------------------------------------------------
int CXProgressBar::GetPos() {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_GETPOS, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
int CXProgressBar::DeltaPos(int nDelta) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_DELTAPOS, nDelta, 0);
}
//---------------------------------------------------------------------------
int CXProgressBar::SetStep(int nStep) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETSTEP, (WPARAM)nStep, (LPARAM)0);
}
//---------------------------------------------------------------------------
int CXProgressBar::StepIt() {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_STEPIT, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBarColour(COLORREF clrBar) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETBARCOLOR , (WPARAM)0, (LPARAM)(COLORREF)clrBar);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBkColour(COLORREF clrBk) {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, PBM_SETBKCOLOR, (WPARAM)0, (LPARAM)(COLORREF)clrBk);
}
//---------------------------------------------------------------------------