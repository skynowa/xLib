/****************************************************************************
*    �����: CXMutex (CXMutex.h)
*
*****************************************************************************/


#include <XLib/CXSync/CXMutex.h>
//---------------------------------------------------------------------------
CXMutex::CXMutex() {
	m_hMutex = NULL;
}
//---------------------------------------------------------------------------
CXMutex::CXMutex(LPSECURITY_ATTRIBUTES lpsaAttributes = NULL, BOOL bInitialState = FALSE, LPCSTR lpszName = NULL) {
	m_hMutex = NULL;
	
	BOOL bSuccess = FALSE;
	bSuccess = bCreate(lpsaAttributes, bInitialState, lpszName);
	if (FALSE == bSuccess) {
		return;
	}
}
//---------------------------------------------------------------------------
CXMutex::~CXMutex() {
	if (NULL != m_hMutex) {
		::CloseHandle(m_hMutex);	m_hMutex = NULL;
	}
}
//---------------------------------------------------------------------------
HANDLE CXMutex::hGetHandle() {
	assert(NULL != m_hMutex);

	return m_hMutex;
}
//---------------------------------------------------------------------------
BOOL CXMutex::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialOwner, LPCSTR lpszName) {
	m_hMutex = ::CreateMutex(lpsaAttributes, bInitialOwner, lpszName);
	
	return (NULL != m_hMutex);
}
//---------------------------------------------------------------------------
BOOL CXMutex::bOpen(DWORD dwAccess, BOOL bInheritHandle, LPCSTR lpszName) {
	assert(NULL != m_hMutex);

	m_hMutex = ::OpenMutex(dwAccess, bInheritHandle, lpszName);

	return (NULL != m_hMutex);
}
//---------------------------------------------------------------------------
BOOL CXMutex::bRelease() {
	assert(NULL != m_hMutex);

	return (::ReleaseMutex(m_hMutex));
}
//---------------------------------------------------------------------------
DWORD CXMutex::dwWaitForSingleObject(DWORD dwTimeout = INFINITE) {
	assert(NULL != m_hMutex);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
	return (::WaitForSingleObject(m_hMutex, dwTimeout));
	//SignalMeAndWaitOther()	::SignalObjectAndWait() 
}
//---------------------------------------------------------------------------