/****************************************************************************
* Lib name:  XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/



#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

#include <XLib/CXFsoString.h>


using namespace std;
//---------------------------------------------------------------------------
int main(int /*argc*/) {
	cout << "sExeDirPath(): " << sExeDirPath() << endl;
	cout << "sExePath:      " << sExePath()    << endl;
    cout << "sSizeToStr:    " << sSizeToStr(100)    << endl;
	






	system("pause");
	return 0;
}
//---------------------------------------------------------------------------