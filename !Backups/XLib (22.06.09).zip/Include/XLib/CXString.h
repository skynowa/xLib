/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef CXStringH
#define CXStringH  
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
//---------------------------------------------------------------------------

/****************************************************************************
*    ������ <--> �����
*
*****************************************************************************/

LONG                              StrToLONG        (LPCTSTR pszValue, LONG   Default = 0,  INT Radix = 0);	/*+*/
ULONG							  StrToULONG       (LPCTSTR pszValue, ULONG  Default = 0,  INT Radix = 0);	/*+*/
UINT							  StrToUINT        (LPCTSTR pszValue, UINT   Default = 0,  INT Radix = 0);	/*+*/
INT                               StrToINT         (LPCTSTR pszValue, INT    Default = 0,  INT Radix = 0);	/*+*/
SHORT                             StrToSHORT       (LPCTSTR pszValue, SHORT  Default = 0,  INT Radix = 0);	/*+*/
USHORT							  StrToWORD        (LPCTSTR pszValue, USHORT Default = 0,  INT Radix = 0);	/*+*/
UCHAR							  StrToBYTE        (LPCTSTR pszValue, UCHAR  Default = 0,  INT Radix = 0);	/*+*/
double                            StrToDOUBLE      (LPCTSTR pszValue, double Default = 0.0);	/*+*/
BOOL                              StrToBOOL        (LPCTSTR pszValue, BOOL   Default = FALSE);	/*+*/
bool                              StrToBool        (LPCTSTR pszValue, bool   Default = false);	/*+*/
bool                              bStrToUCHAR      (const std::string &csStr, UCHAR *pucBuff, UINT uiBuffLen);	/*+*/
std::string                       sUCHARToStr      (UCHAR *pucBuff, UINT uiBuffLen);	/*+*/
template <typename T> std::string sTypeToStr       (T val) {		
														std::ostringstream oss;	oss << val;
                                                        oss.flush();
														return oss.str();
													};	/*+*/	
                                                    
/*template<typename T>
string to_string(T const & value)
{
  ostringstream ost;
  ost << value;
  ost.flush();
  return ost.str();
}*/


template<typename T> T            iStrToType       (const std::string &csStr) {
														std::istringstream iss(csStr);
														T val;	iss >> val;
														return val;
													};	/*+*/

std::string                       sTrimChar        (const std::string &csStr, CHAR cChar); /*+*/
std::string                       sTrimSpace       (const std::string &csStr);	/*+*/
std::string                       sRemoveEOL       (const std::string &csStr);	/*+*/

std::string                       sReplaceAll      (const std::string &csStr, const std::string &csOldStr, const std::string &csNewStr); /*+*/
std::string                       sReplaceAll      (const std::string &csStr, CHAR cOldStr, CHAR cNewStr); /*+*/
std::string                       sRemoveAll       (const std::string &csStr, const std::string &csRemoveStr); /*+*/

std::vector<std::string>          vecsSplit        (const std::string &csSep,  const std::string &sStr); /*+*/
std::string                       sJoin            (CHAR chSep, std::vector<std::string> vecsVec); /*+*/
std::string                       sCut             (const std::string &csStr, CHAR cStartDelimiter, CHAR cStopDelimiter); /*-*/

std::string                       sUrlUnescape     (const std::string &csStr); /*+*/	//sBase64Decode
std::string                       sStrToBin        (const std::string &csStr); /*+*/
std::string                       sBinToStr        (const std::string &csStr); /*+*/

bool                              bCharToWide      (const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize);

bool                              bStrToFile       (const std::string &csStr, const std::string &csFilePath);	/*-*/
std::string                       bStrFromFile     (const std::string &csStr, const std::string &csFilePath);	/*-*/

std::string						  sTranslitLatToRus(const std::string &csStr);	/*+*/
bool                              bCharToWide      (const CHAR *pszSrc, wchar_t *pwszDest, INT iDestSize);	/*-*/

std::string						  sToLowerCase     (const std::string &csSrc);	/*+*/
std::string                       sToUpperCase     (const std::string &csSrc);	/*+*/
std::string						  sToLowerCase     (const std::string &csSrc, UINT uiPos);	/*-*/
std::string                       sToUpperCase     (const std::string &csSrc, UINT uiPos);	/*-*/

std::string                       sFormatStr       (LPCSTR pcszFormat, ...); /*+*/
std::string                       sFormatStr2      (LPCSTR pcszFormat, ...); /*+*/
std::string                       sFormatStrV      (LPCSTR pcszFormat, va_list palArgs);
std::string                       sMinimizeStr     (const std::string &csStr, const UINT cuiMaxLen); /*+*/

/****************************************************************************
*    CHAR
*
*****************************************************************************/

//This is ASCII specific but is safe with chars >= 0x80
bool                              bIsPunctuation   (CHAR ch); /*+*/
bool                              bIsADigit        (CHAR ch); /*+*/
bool                              bIsLowerCase     (CHAR ch); /*+*/
bool                              bIsUpperCase     (CHAR ch); /*+*/
bool                              bIsSpaceOrTab   (UINT ch); /*+*/
bool                              bIsDigit        (UINT ch); /*+*/
bool                              bIsDigit        (UINT ch, UINT base); /*+*/
bool                              bIsLetter        (CHAR ch); /*+*/
bool                              bIsSpace         (UINT ch); /*+*/
bool                              IsEOLChar        (CHAR ch); /*+*/
bool							  bIsSlash         (CHAR ch);  /*+*/

CHAR                              cMakeUpperCase   (CHAR ch); /*+*/ //non-Unicode characters only
CHAR                              cMakeLowerCase   (CHAR ch); /*+*/ //non-Unicode characters only

INT                               iGetHexChar      (UCHAR hd1, UCHAR hd2);
CHAR                              cHexToChar       (CHAR *pszStr);
INT								  iCharCodeAt      (const std::string &csStr, INT nIndex);	/*+*/
BOOL                              bCompareNoCase   (const std::string &csStr1, const std::string &csStr2); /*+*/
BOOL                              bCompareCase     (const std::string &csStr1, const std::string &csStr2); /*+*/
BOOL                              bCompareNoCase2  (const std::string &csStr1, const std::string &csStr2); /*+*/

/****************************************************************************
*    ����������
*
*****************************************************************************/
template <class T> void           vRandomShuffle   (std::vector<T> &v); /*-*/
template <class T> void           vSortVector      (std::vector<T> &v); /*-*/

/****************************************************************************
*    ������
*
*****************************************************************************/

std::string						  sStrToRtf        (std::string sStr);
std::string						  sRtfToStr        (std::string sStr);

std::string                       sCreatePlainGUID (); /*+*/ 
bool                              bIsRepeatedStr   (const std::string &csStr); /*+*/

std::string						  sUrlEscape	   (const std::string &csStr);	//���������� �����
std::string						  sUrlUnescape     (const std::string &csStr);  //���������� �����

std::string                       sLastErrorStr    (ULONG ulLastError);	/*+*/
ULONG                             ulCountDigits    (ULONG ulDigit);	/*+*/

std::string                       sSizeToStr       (ULONG dwSize); /*-*/


//---------------------------------------------------------------------------
//������ � ������� std::vector 
template<class T>
VOID vPrintStdVectorT(const std::vector<T> &t) {
	std::cout << std::endl << "Printing std::vector contents..." << std::endl << std::endl;

	std::vector<T>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it){
		std::cout << "Value: [" << (*it) << "]" << std::endl;
	}
	
	std::cout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
//������ � ������� std::multimap 
template<class T1, class T2>
VOID vPrintStdMultiMapT(const std::multimap<T1, T2> &t) { 
	std::cout << std::endl << "Printing std::multimap contents..." << std::endl << std::endl;
	
	std::multimap<T1, T2>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it) {
		std::cout << "Key: [" << (*it).first << "]" << "\t\t" 
			      << "Value: [" << (*it).second << "]" << std::endl;
	}

	std::cout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
#endif