/****************************************************************************
* Class name:  CXSmtp
* Description: Pop3 ������ (RFC 2821)
* File name:   CXSmtp.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXSmtpH 
#define CXSmtpH 
//---------------------------------------------------------------------------
#include <Xlib/CXNet/CXTcpClientSocket.h>
#include <XLib/CXCommon.h>
#include <map>
//---------------------------------------------------------------------------
class CXSmtp { 
		_NO_COPY(CXSmtp);
		
	public: 
                    	    CXSmtp     (); 
                    	   ~CXSmtp     (); 
		BOOL                bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); 
		BOOL                bConnect   ();
	   //BOOL               bIsConnected ();
		BOOL                bLogin     (); 
		BOOL                bSendRaw   (const std::string &csFilePath, const std::string &csFrom, const std::string &csTo); 
		BOOL                bSend      (const std::string &csText, const std::string &sFrom, const std::string &sTo);
		BOOL                bDisconnect(); 

	private: 
		CXTcpClientSocket   m_scktSocket; 
		std::string         m_sUser; 
		std::string         m_sPass; 
		std::string         m_sServer; 
		USHORT              m_usPort; 

		static const size_t ms_cuiRecvSize = 32768;
		CHAR                m_szRecv[ms_cuiRecvSize + 1];

		INT				    iSmtpSend  (LPSTR pszInBuff, INT iInBuffSize, INT iFlags); 
		BOOL                bIsError   (const std::string &csText); 
}; 
//---------------------------------------------------------------------------
#endif 
