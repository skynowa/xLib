/****************************************************************************
* Class name:  CXWaitableTimer
* Description: ������ � �������� ��������
* File name:   CXWaitableTimer.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.05.2009 17:07:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSync/CXWaitableTimer.h>

#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXWaitableTimer::CXWaitableTimer() 
	: m_hWaitableTimer(NULL)
{

}  
//---------------------------------------------------------------------------
CXWaitableTimer::~CXWaitableTimer() {
	/*DEBUG*/XASSERT(NULL != m_hWaitableTimer);

	if (NULL != m_hWaitableTimer) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(m_hWaitableTimer);	m_hWaitableTimer = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXWaitableTimer::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, NULL);

	return m_hWaitableTimer;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bCreate(BOOL bManualReset, LPCSTR pcszName, LPSECURITY_ATTRIBUTES lpTimerAttributes) {
	/*DEBUG*/XASSERT_RET(NULL == m_hWaitableTimer, FALSE);

	m_hWaitableTimer = ::CreateWaitableTimer(lpTimerAttributes, bManualReset, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bOpen(LPCSTR pcszName, ULONG ulDesiredAccess, BOOL bInheritHandle) {
	/*DEBUG*/XASSERT_RET(NULL == m_hWaitableTimer, FALSE);

	m_hWaitableTimer = ::OpenWaitableTimer(ulDesiredAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bCancel() {
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, FALSE);

	BOOL bRes = FALSE;

	bRes = ::CancelWaitableTimer(m_hWaitableTimer);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWaitableTimer::bSet(LONGLONG i64DueTime, LONG liPeriod, PTIMERAPCROUTINE pfnCompletionRoutine, LPVOID pvArgToCompletionRoutine, BOOL bResume) {
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, FALSE);

	/*
	#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	//����� �������� ��� ������� = 2 �������
	qwTimeInterval = -2 * _SECOND;
	*/
	BOOL bRes = FALSE;  //#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	LARGE_INTEGER liDueTime = {0};
	liDueTime.QuadPart = i64DueTime;
	
	bRes = ::SetWaitableTimer(m_hWaitableTimer, &liDueTime, liPeriod, pfnCompletionRoutine, pvArgToCompletionRoutine, bResume);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXWaitableTimer::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != m_hWaitableTimer, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
	return ::WaitForSingleObject(m_hWaitableTimer, ulTimeout);
}
//---------------------------------------------------------------------------