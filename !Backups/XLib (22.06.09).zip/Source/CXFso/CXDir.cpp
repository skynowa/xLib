/****************************************************************************
* Class name:  CXDir
* Description: �������� � �������
* File name:   CXDir.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXFso/CXDir.h>

#include <XLib/CXString.h>
#include <XLib/CXFso/CXFile.h>
#include <XLib/CXFso/CXPath.h>
#include <XLib/xassert.h>

const std::string csWinSlash  = "\\";
const std::string csUnixSlash = "/";
//---------------------------------------------------------------------------
CXDir::CXDir() {
	//code
}
//---------------------------------------------------------------------------
CXDir::~CXDir() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//����������, ���������� �� ��������� �������.
/*static*/BOOL CXDir::bIsExists(const std::string &csDirPath) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);

	if (CXFile::faDirectory == CXFile::ulGetAttr(csDirPath.c_str())) {
		return TRUE;
	}

	return FALSE;
}
//---------------------------------------------------------------------------
//���������� ���� ������� ��� ���
/*static*/BOOL CXDir::bIsEmpty(const std::string &csDirPath, const std::string &csMask) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csMask.empty(),    FALSE);

	BOOL            bRes;
	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            _bRet;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, TRUE); 

	do {
		std::string sFileName = std::string(fd.cFileName);

		if ("." != sFileName && ".." != sFileName) {
			bRes = FALSE;	//�� ������
		} else {
			bRes = TRUE;	//������
		}

		_bRet = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == _bRet); 

	_bRet = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != _bRet, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//���������� ������ ��� �������� ��������
/*static*/std::string CXDir::sGetCurrent() {
	TCHAR szBuff[MAX_PATH + 1] = {0};
	ULONG ulRes = ::GetCurrentDirectory(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(0 != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//������������� ������� �������
/*static*/BOOL CXDir::bSetCurrent(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 	

	return ::SetCurrentDirectory(csDirPath.c_str());
}
//--------------------------------------------------------------------------
//���������� ���� � �������� %Temp%
/*static*/std::string CXDir::sGetTempPath() {
	TCHAR szBuff[MAX_PATH + 1] = {'\0'};		
	ULONG ulRes = ::GetTempPath(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(FALSE != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//������� �������
/*static*/BOOL CXDir::bCreate(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = ::CreateDirectory(csDirPath.c_str(), NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//--------------------------------------------------------------------------
//������� ��� ����������� �������� �� ��������� ����
/*static*/VOID CXDir::vForceCreate(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), VOID(NULL));

	CHAR szPath[MAX_PATH + 1] = {0};

	::lstrcpy(szPath, CXPath::sUnixToWinPath(csDirPath, true).c_str());  

	LPSTR pszTemp = szPath;

	if (':' == pszTemp[1]) {
		pszTemp += 3;
	}

	while (*pszTemp) {
		CHAR szPathNow[MAX_PATH + 1] = {0};

		pszTemp = strchr(pszTemp, '\\') + 1;
		::lstrcpyn(szPathNow, szPath, pszTemp - szPath);
		if (FALSE == ::CreateDirectory(szPathNow, NULL) && ERROR_ALREADY_EXISTS != ::GetLastError()) {
			throw ::GetLastError();
		}
	}
}
//---------------------------------------------------------------------------
//������� �������� �������
/*static*/BOOL CXDir::bDelete(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = ::RemoveDirectory(csDirPath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//������� �� ���������� ����������
/*static*/BOOL CXDir::bForceClear(const std::string &csDirPath) { //��� �����
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    FALSE); 
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csDirPath), FALSE);

	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            bRes   = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, FALSE); 

	do {
		std::string sFileName = std::string(fd.cFileName);

		if ("." != sFileName && ".." != sFileName) {
			if (CXFile::faDirectory == CXFile::ulGetAttr(sPath + sFileName/*fd.dwFileAttributes*/)) {
				bRes = bForceDelete(sPath + sFileName);
			} else {
				bRes = CXFile::bDelete(sPath + sFileName);
			}
			//if not Result then Exit;
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//������� ���������� � ��� � ����������
/*static*/BOOL CXDir::bForceDelete(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;

	bForceClear(csDirPath);
	bRes = bDelete(csDirPath);

	return bRes;
}
//---------------------------------------------------------------------------
//���������� ������ ������ � ����������
std::vector<std::string> CXDir::vecsListFiles(const std::string &csDirPath, const std::string &csMask) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csDirPath), std::vector<std::string>());

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;


	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, std::vector<std::string>()); 

	do {
		//���������� �����
		if (!(CXFile::faDirectory == (fd.dwFileAttributes & CXFile::faDirectory))) {
			vecsRes.push_back(std::string(fd.cFileName));	
		} 

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
//���������� ������ ���������� � ����������
/*static*/std::vector<std::string> CXDir::vecsListDirs(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csDirPath), std::vector<std::string>());

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, std::vector<std::string>()); 

	do {
		//���������� ����� � "." ".."
		if ((CXFile::faDirectory == (fd.dwFileAttributes & CXFile::faDirectory)) && ("." != std::string(fd.cFileName)) && (".." != std::string(fd.cFileName))) {
			vecsRes.push_back(fd.cFileName);
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------