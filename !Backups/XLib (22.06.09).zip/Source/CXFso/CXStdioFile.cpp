/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXFso/CXStdioFile.h>

#include <string.h>
#include <cstdarg>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
/////////////////////////
#include <vector>
#include <hash_map>
#include <map>
#include <stdio.h>
#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <ostream>
#include <fstream>
#include <io.h>   
#include <algorithm>
#include <iterator>
#include <ctime>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
//#include <sharc.h>
////////////////////////
#include <XLib/CXString.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXStdioFile::CXStdioFile() 
	: _m_pFile(NULL)
{

}
//---------------------------------------------------------------------------
CXStdioFile::~CXStdioFile() { 
	if (NULL != _m_pFile) {
		BOOL bRes = FALSE;

		bRes = bClose();
		/*DEBUG*/XASSERT(FALSE != bRes);	
	}
}
//---------------------------------------------------------------------------
CXStdioFile::operator FILE*() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, NULL);     
	
	return _m_pFile;
}
//---------------------------------------------------------------------------
//�������� ��������� �� ����
FILE *CXStdioFile::pGetFile() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, NULL);      

	return _m_pFile;
}
//---------------------------------------------------------------------------
//Open file 
BOOL CXStdioFile::bOpen(const std::string &csFilePath, const std::string &csMode) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/XASSERT_RET(false == csMode.empty(),     FALSE); 
	
	_m_pFile = fopen(csFilePath.c_str(), csMode.c_str());
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);       

	return TRUE;
}
//---------------------------------------------------------------------------
//Reopen stream with different file or mode
BOOL CXStdioFile::bReopen(const std::string &csFilePath, const std::string &csMode) {
	/*DEBUG*/XASSERT_RET(NULL  != _m_pFile,            FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/XASSERT_RET(false == csMode.empty(),     FALSE); 

	_m_pFile = freopen(csFilePath.c_str(), csMode.c_str(), _m_pFile);
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);       

	return TRUE;
}
//---------------------------------------------------------------------------
//Read block of data from stream
size_t CXStdioFile::uiRead(LPVOID pvBuff, size_t uiCount) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, 0); 
	/*DEBUG*/XASSERT_RET(NULL != pvBuff,  0); 
	
	size_t uiRes = 0;

	uiRes = fread(pvBuff, sizeof(CHAR), uiCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(uiCount >= uiRes, 0); 
	
	return uiRes;
}
//---------------------------------------------------------------------------
//Reads data from the file to pszStr till '\n' is encountered
BOOL CXStdioFile::bReadLine(LPSTR pszStr, size_t uiMaxCount) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pszStr,   FALSE); 

	LPSTR pszRes = NULL;
	pszRes = fgets(pszStr, uiMaxCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//Write block of data to stream
size_t CXStdioFile::uiWrite(const LPVOID pcvBuf, size_t uiCount) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, 0);
	/*DEBUG*/XASSERT_RET(NULL != pcvBuf,  0); 
	
	size_t uiRes = 0;
	
	uiRes = fwrite(pcvBuf, sizeof(CHAR), uiCount, _m_pFile);
	/*DEBUG*/XASSERT_RET(uiCount == uiRes, 0); 

	return uiRes;
}
//---------------------------------------------------------------------------
//Locks or unlocks bytes of a file.
BOOL CXStdioFile::bLocking(ELockingMode lmMode, LONG liBytes) {
	INT iRes = etError;

	iRes = _locking(_iGetHandle(), lmMode, liBytes);
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//Writes csStr and then writes '\n' to the file.
BOOL CXStdioFile::bWriteLine(const std::string &csStr, size_t uiSize) {
	if (etError == uiSize) {
		uiSize = csStr.size();
	}

	size_t uiRet = uiWrite((LPVOID)csStr.c_str(), uiSize);
	if (uiRet < uiSize) {
		return FALSE;
	}

	uiRet = strlen("\n");

	return (uiRet == uiWrite("\n", uiRet));
}
//---------------------------------------------------------------------------
//Write character to stream
BOOL CXStdioFile::bWriteChar(CHAR cChar) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
	INT iRes = etError;
	
	iRes = fputc((INT)cChar , _m_pFile);
	/*DEBUG*/XASSERT_RET((INT)cChar != etError, FALSE);
	/*DEBUG*/XASSERT_RET((INT)cChar == iRes,    FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//Write string to stream
BOOL CXStdioFile::bWriteString(const std::string &csStr) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = fputs(csStr.c_str() , _m_pFile); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);
	/*DEBUG*/XASSERT_RET(EOF < iRes,      FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//Get character from stream
CHAR CXStdioFile::cGetChar() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = getc(_m_pFile);
	/*DEBUG*/XASSERT_RET(iRes != etError, (CHAR)etError);
	/*DEBUG*/XASSERT_RET(EOF < iRes,      (CHAR)etError);

	return (CHAR)iRes; 
} 
//---------------------------------------------------------------------------
//Unget character from stream
BOOL CXStdioFile::bUngetChar(CHAR cChar) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = ungetc(cChar, _m_pFile);
	/*DEBUG*/XASSERT_RET(iRes != etError,     FALSE);
	/*DEBUG*/XASSERT_RET(cChar == (CHAR)iRes, FALSE);	

	return TRUE; 
} 
//---------------------------------------------------------------------------





//---------------------------------------------------------------------------
//Change stream buffering
BOOL CXStdioFile::bSetVBuff(LPSTR pszBuff, EBufferingMode bmMode, size_t uiSize) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile,                FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pszBuff,                FALSE);
    /*DEBUG*/XASSERT_RET(2 < uiSize && uiSize < INT_MAX, FALSE);
    
    INT iRes = etError;
    
	iRes = setvbuf(_m_pFile, pszBuff, bmMode, uiSize);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//Sets the file translation mode.
BOOL CXStdioFile::bSetMode(ETranslationMode tmMode) {    
	INT iRes = etError;

	iRes = _setmode(_iGetHandle(), tmMode);
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//REFilePosition stream position indicator 
BOOL CXStdioFile::bSetPosition(LONG lOffset, EPointerPosition fpPos/* = fpBegin*/) {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
	INT iRet = ppError;

	iRet = fseek(_m_pFile, lOffset, fpPos);
	/*DEBUG*/XASSERT_RET(0 == iRet, FALSE); 
	
	return TRUE;
}
//---------------------------------------------------------------------------
//Get current position in stream
LONG CXStdioFile::liGetPosition() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
	LONG liRes = ppError;

	liRes = ftell(_m_pFile);
	/*DEBUG*/XASSERT_RET(ppError != liRes, ppError); 
		
	return liRes;
}
//---------------------------------------------------------------------------
//Close file
BOOL CXStdioFile::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	
	
	iRes = fclose(_m_pFile);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	_m_pFile = NULL;

	return TRUE;
}
//---------------------------------------------------------------------------
//Flush stream
BOOL CXStdioFile::bFlush() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	

	iRes = fflush(_m_pFile);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//������ �����
LONG CXStdioFile::liGetSize() {
	LONG liStreamSize    = ppError;
	LONG liCurrStreamPos = ppError;
	
	//Get current position
	liCurrStreamPos = liGetPosition();
	
	//seek to the end of file
	if (FALSE == bSetPosition(0, ppEnd)) {
		return ppError; 
	}
	liStreamSize = liGetPosition();
	
	//Get back to the stored position
	if (FALSE == bSetPosition(liCurrStreamPos, ppBegin)) {
		return ppError;
	}

	return liStreamSize;
}
//---------------------------------------------------------------------------
//Changes the file size.
BOOL CXStdioFile::bChsize(LONG liSize) {
	/*DEBUG*///not need 

	INT iRes = etError;

	iRes = _chsize(_iGetHandle(), liSize); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//������ �����
/*static*/BOOL CXStdioFile::bIsExists(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	
	return bAccess(csFilePath, amExistence);
}
//---------------------------------------------------------------------------
//Determine file-access permission.
/*static*/BOOL CXStdioFile::bAccess(const std::string &csFilePath, EAccessMode amMode) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _access(csFilePath.c_str(), amMode); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//Change the file-permission settings.
/*static*/BOOL CXStdioFile::bChmod(const std::string &csFilePath, EPermissionMode pmMode) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _chmod(csFilePath.c_str(), pmMode); 
	/*DEBUG*/XASSERT_RET(iRes != etError, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------		
//Remove file
/*static*/BOOL CXStdioFile::bRemove(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);  
	
	INT iRes = etError;

	iRes = bChmod(csFilePath.c_str(), pmWrite);
	/*DEBUG*/XASSERT_RET(FALSE != iRes, FALSE);  

	iRes = remove(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//Delete a file.
/*static*/BOOL CXStdioFile::bUnlink(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	
	INT iRes = etError;

	iRes = _unlink(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//Rename file 
/*static*/BOOL CXStdioFile::bRename(const std::string &csOldFilePath, const std::string &csNewFilePath) {
	/*DEBUG*/XASSERT_RET(false == csOldFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csNewFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = rename(csOldFilePath.c_str(), csNewFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//��������� ����
/*static*/BOOL CXStdioFile::bExec(const std::string &csFilePath, const std::string &csArgList) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = spawnlp(/*_P_WAIT*/P_NOWAIT/*P_DETACH*/, csFilePath.c_str(), csFilePath.c_str(), csArgList.c_str(), NULL);
	/*DEBUG*/XASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//Generate temporary filename (������ ����� ����� [\s150.])
/*static*/std::string CXStdioFile::sCreateTempFileName() {
	CHAR  szBuff[L_tmpnam] = {0};
	CHAR *pszRes           = NULL;

	pszRes = tmpnam(szBuff);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, ""); 

	return std::string(szBuff);  
}
//---------------------------------------------------------------------------
//Flushes all streams opened for output
/*static*/BOOL CXStdioFile::bFlushAllOutput() {
	INT iRes = etError;	

	iRes = fflush(NULL);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//returns the number of open streams (input and output). 
/*static*/INT CXStdioFile::iFlushAll() {
	INT iRes = etError;	

	iRes = _flushall();
	/*DEBUG*///not need

	return iRes;
}
//--------------------------------------------------------------------------
/*static*/ULONG CXStdioFile::ulLines(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), 0);
	/*DEBUG*/XASSERT_RET(TRUE == bIsExists(csFilePath), 0);

	ULONG ulLines = 0;   //������� �����

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return 0;
	}

	CHAR cChar = '\0';
	while (ifsStream.get(cChar)) {
		if ('\n' == cChar) {
			ulLines ++;
		}
	} 
	ulLines ++;
	ifsStream.close();

	return ulLines;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//Get character from stdin
CHAR CXStdioFile::cGetCharFromStdin() {
	INT iRes = etError;
	
	iRes = getchar();
	/*DEBUG*/XASSERT_RET(etError != iRes, (CHAR)etError);
	
	return (CHAR)iRes;
}
//---------------------------------------------------------------------------
//Get string from stdin
std::string CXStdioFile::sGetStringFromStdin(LPSTR pszBuff) {
	LPSTR pszRes = NULL;

	pszRes = gets(pszBuff);
	/*DEBUG*/XASSERT_RET(NULL != pszRes, "");

	return std::string(pszRes);
}
//---------------------------------------------------------------------------
//Write character to stdout
BOOL CXStdioFile::bWriteCharToStdout(CHAR cChar) {
	INT iRes = etError;

	iRes = putchar((INT)cChar);
	/*DEBUG*/XASSERT_RET(etError    != iRes, (CHAR)etError);
	/*DEBUG*/XASSERT_RET((INT)cChar == iRes, (CHAR)etError);

	return (CHAR)iRes;
}
//---------------------------------------------------------------------------
//Write string to stdout
BOOL CXStdioFile::bWriteStringToStdout(const std::string &csStr) {
	INT iRes = etError;
	
	iRes = puts(csStr.c_str());
	/*DEBUG*/XASSERT_RET(etError < iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------

//TODO: Formatted input/output:

//---------------------------------------------------------------------------
//Write formatted output to stream
INT CXStdioFile::iFprintf(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,    etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);
	
    iRes = vfprintf(_m_pFile, pcszFormat, args);
    /*DEBUG*/XASSERT_RET(etError < iRes, etError);
    
    va_end(args);
    
    return iRes;
}
//---------------------------------------------------------------------------
//Read formatted data from stream
INT CXStdioFile::iFscanf(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,    etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = vfscanf(_m_pFile, pcszFormat, args);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//Print formatted data to stdout
INT CXStdioFile::iPrintf(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = vprintf(pcszFormat, args);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//Read formatted data from stdin
INT CXStdioFile::iScanf(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;

	va_list args = NULL;
	va_start(args, pcszFormat);
	
	iRes = vscanf(pcszFormat, args);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//Write formatted data to string
INT CXStdioFile::iSprintf(LPSTR pszStr, LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = vsprintf(pszStr, pcszFormat, args);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: (iSscanf) Read formatted data from string 
/*static*/INT CXStdioFile::iSscanf(LPCSTR pcszStr, LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszStr,    etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;

	////va_list args = NULL;
	////va_start(args, pcszFormat);

	////iRes = vsscanf(pcszStr, pcszFormat, args);
	/////*DEBUG*/XASSERT_RET(etError < iRes, etError);

	////va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//Write formatted variable argument list to stream
INT CXStdioFile::iVfprintf(LPCSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile,    etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = vfprintf(_m_pFile, pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);
	
	return iRes;
}
//---------------------------------------------------------------------------
//Print formatted variable argument list to stdout
INT CXStdioFile::iVprintf(LPCSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = vprintf(pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------
//Print formatted variable argument list to string
INT CXStdioFile::iVsprintf(LPSTR pszStr, LPCSTR pcszFormat, va_list arg) {
	/*DEBUG*/XASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/XASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = vsprintf(pszStr, pcszFormat, arg);
	/*DEBUG*/XASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------



//Error-handling:


//---------------------------------------------------------------------------
//Clear error indicators
BOOL CXStdioFile::bClearErr() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
    clearerr(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------
//Check End-of-File indicator
BOOL CXStdioFile::bIsEof() {
	/*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
    BOOL bRes = FALSE;
    
    bRes = (BOOL)feof(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------
//Check error indicator
BOOL CXStdioFile::bIsError() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, FALSE);
    
    BOOL bRes = FALSE;
    
    bRes = (BOOL)ferror(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}		
//---------------------------------------------------------------------------
//Print error message
BOOL CXStdioFile::bPrintError(const std::string &csStr) {
    perror(csStr.c_str());
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/

//--------------------------------------------------------------------------
/*static*/VOID CXStdioFile::vFileToArray(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), VOID(NULL));

	//ulFileLines(csFilePath);
	//...
}
//--------------------------------------------------------------------------
/*static*/std::vector<std::string> CXStdioFile::vecsReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(TRUE  == bAccess(csFilePath, amExistence), std::vector<std::string>());

	std::vector<std::string> vecRes;
	std::string              sStr("");
	std::ifstream            ifsStream(csFilePath.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, std::vector<std::string>());
	}	

	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		vecRes.push_back(sStr);
	}

	return vecRes;
}
//--------------------------------------------------------------------------
/*static*/std::vector<char> CXStdioFile::vecchReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), std::vector<char>());
	/*DEBUG*/XASSERT_RET(TRUE == bAccess(csFilePath, amExistence), std::vector<char>());

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in | std::ios::binary);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, std::vector<char>());
	}

	std::vector<CHAR>       vecchBuffer;
	std::ifstream::pos_type uiSize = 0;

	if (ifsStream.seekg(0, std::ios::end)) {
		uiSize = ifsStream.tellg();
	}

	if (uiSize && ifsStream.seekg(0, std::ios::beg)) {
		vecchBuffer.resize(uiSize);
		ifsStream.read(&vecchBuffer[0], uiSize);
	}

	return vecchBuffer;
}
//--------------------------------------------------------------------------
//���������� ����� Name1=Value1\r\r\nName2=Value2\r\n...
/*static*/std::map<std::string, std::string> CXStdioFile::mapReadFile(const std::string &csFilePath, const std::string &csDelimiter) {
	//return std::map<std::string, std::string>(); 
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),      (std::map<std::string, std::string>()));
	/*DEBUG*/XASSERT_RET(TRUE  == bAccess(csFilePath, amExistence), (std::map<std::string, std::string>()));

	std::map<std::string, std::string> mapLines;
	std::string                        sStr("");
	std::ifstream                      ifsStream(csFilePath.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, (std::map<std::string, std::string>()));
	}	

	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);

		std::vector<std::string> vecsLine = vecsSplit(csDelimiter, sStr);

		mapLines[vecsLine.at(0)] = vecsLine.at(1);
	}

	return mapLines;
}
//--------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//Gets the file descriptor associated with a stream.
INT CXStdioFile::_iGetHandle() {
    /*DEBUG*/XASSERT_RET(NULL != _m_pFile, etError);
    
    INT iRes = etError;
    
	iRes = _fileno(_m_pFile);
	/*DEBUG*/XASSERT_RET(etError != iRes, etError);
	
	return iRes; 
}
//---------------------------------------------------------------------------