/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/xassert.h> 

#include <XLib/CXString.h>
#include <XLib/CXFsoString.h> 
//---------------------------------------------------------------------------
void vAssert(const std::string &csExp, ULONG ulLastError, const std::string &csFile, ULONG ulLine, const std::string &csFunc, const std::string &csComment) {
	//-------------------------------------
	//�������� ���������
	std::string sProgram      = sMinimizePath(sExePath(), 40);
	std::string sFile         = sMinimizePath(csFile,     40);
	std::string sGetLastError = sLastErrorStr(ulLastError);
	std::string sExeName      = sExtractShortFileName(sExePath());

	std::string sFStr = sFormatStr(
				"%s\n\n"
				"%s:  %s\n"
				"%s:  %s\n"
				"%s:  %i\n"
				"%s:  %s\n"
				"%s:  %s\n"
				"%s:  %s"		/*����� ���� \n �� ����*/
				"%s:  %s",			 

				"Assertion failed.",
				"Program",           sProgram.c_str(),
				"File",              sFile.c_str(),
				"Line",              ulLine,
				"Function",          csFunc.c_str(),
				"Expression",        csExp.c_str(),
				"GetLastError()",    sGetLastError.c_str(),
				"Comment",           csComment.c_str() 
	);

	//-------------------------------------
	//������� MessageBox
	INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    	exit(- 1);
			break;
		}
		case IDRETRY: {
			////_asm {int 3} 
			_CrtDbgBreak();
			break;
		}
		case IDIGNORE: {
			break;
		}
	}
}
//---------------------------------------------------------------------------