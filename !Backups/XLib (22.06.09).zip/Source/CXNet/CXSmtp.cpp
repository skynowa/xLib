/****************************************************************************
* Class name:  CXSmtp
* Description: SMTP ������ (RFC 2821)
* File name:   CXSmtp.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

    
//---------------------------------------------------------------------------
#include <XLib/CXNet/CXSmtp.h> 

#include <stdio.h>   
#include <string>   
#include <iostream> 
#include <XLib/CXFso/CXPath.h>
#include <XLib/CXLog/CXTraceLog.h> 
#include <XLib/CXFso/CXStdioFile.h>
#include <XLib/xassert.h> 

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------  


/****************************************************************************
*	Public methods
*
*****************************************************************************/

//---------------------------------------------------------------------------
CXSmtp::CXSmtp() {   
	::ZeroMemory(&m_szRecv, sizeof(m_szRecv)); 
	CXTcpClientSocket::bInit();  
}   
//--------------------------------------------------------------------------- 
CXSmtp::~CXSmtp() {   
	////bDisconnect();
	CXTcpClientSocket::bClean();   
}   
//--------------------------------------------------------------------------- 
BOOL CXSmtp::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort) {
	/*DEBUG*/XASSERT_RET(FALSE == csUser.empty(),          FALSE);
	/*DEBUG*/XASSERT_RET(FALSE == csPass.empty(),          FALSE);
	/*DEBUG*/XASSERT_RET(FALSE == csServer.empty(),        FALSE);
    /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	m_sUser   = csUser;   
	m_sPass   = csPass;   
	m_sServer = csServer;   
	m_usPort  = usPort;   

	return TRUE;   
}   
//---------------------------------------------------------------------------    
BOOL CXSmtp::bConnect() {   
    BOOL bRes = FALSE;

	//-------------------------------------
	//Create sock   
    bRes = m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);   
	CHECK_RET(FALSE == bRes, FALSE);
	
	//-------------------------------------
	//Parse domain   
    CHAR szIpAddr[16] = {0};
	
	bRes = CXTcpClientSocket::bDnsParse(m_sServer.c_str(), szIpAddr);
	CHECK_RET(FALSE == bRes, FALSE);
    
	//-------------------------------------
	//Connect   
	bRes = m_scktSocket.bConnect(szIpAddr, m_usPort);
	CHECK_RET(FALSE == bRes, FALSE);
    
    //-------------------------------------
	//[welcome message]   
    /////////////--CHAR szRecv[ms_cuiRecvSize] = {0}; 

    INT iRecv = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRecv,                            FALSE);
    /*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);
    
#ifdef _DEBUG   
    m_szRecv[iRecv] = '\0';   
    printf("Recv SMTP  Resp: %s", m_szRecv);   
#endif   
   
    return TRUE;   
}   
//---------------------------------------------------------------------------    
BOOL CXSmtp::bLogin() {   
    INT  iRes = SOCKET_ERROR;

    //-------------------------------------
    //[USER\r\n]
    const std::string sUserCmd = "USER " + m_sUser + "\r\n";

    iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sUserCmd.size() == iRes, FALSE);

    iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
    /*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
    /*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);
  
#ifdef _DEBUG   
    m_szRecv[iRes] = '\0';   
    printf("Recv USER Resp: %s", m_szRecv);   
#endif     
        
    //-------------------------------------
    //[PASS\r\n]   
    const std::string sPassCmd = "PASS " + m_sPass + "\r\n";

    iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sPassCmd.size() == iRes, FALSE);
    
    iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
    /*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
    /*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);
        
#ifdef _DEBUG   
    m_szRecv[iRes] = '\0';   
    printf("Recv PASS Resp: %s", m_szRecv);   
#endif         
    
    return TRUE;   
}   
//---------------------------------------------------------------------------    
BOOL CXSmtp::bSendRaw(const std::string &csFilePath, const std::string &sFrom, const std::string &sTo) {   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_scktSocket, FALSE);
	/*DEBUG*/XASSERT_RET(FALSE == sFrom.empty(),         FALSE); 
	/*DEBUG*/XASSERT_RET(FALSE == sTo.empty(),		     FALSE); 
	
	BOOL        bRes      = FALSE;
	INT         iRes      = SOCKET_ERROR;     

	const std::string sHelloCmd = "HELO\r\n";
	const std::string sFromCmd  = "MAIL FROM:<" + sFrom + ">\r\n";
	const std::string sToCmd    = "RCPT TO:<"   + sTo   + ">\r\n";
	const std::string sDataCmd  = "DATA\r\n";
	const std::string sEndCmd   = "\r\n.\r\n";

	//-------------------------------------
	//[HELO\r\n]
	iRes = m_scktSocket.iSend(sHelloCmd.c_str(), sHelloCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sHelloCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------
	//[MAIL FROM:<my_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sFromCmd.c_str(), sFromCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sFromCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);
	
	//-------------------------------------	
	//[RCPT TO:<your_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sToCmd.c_str(), sToCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sToCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);
	
	//-------------------------------------
	//[DATA\r\n]
	iRes = m_scktSocket.iSend(sDataCmd.c_str(), sDataCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sDataCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------
	//������ �� ����� � ����� ����� � �����
	const size_t cuiSendSize             = 1024;
	CHAR         szSend[cuiSendSize + 1] = {0};
	
	CXStdioFile stdFile;
	bRes = stdFile.bOpen(csFilePath.c_str(), "r");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	for (;;) {
		size_t uiReadSize = stdFile.uiRead(szSend, cuiSendSize); 
        if (uiReadSize <= 0) {
			break;
		}

		iRes = m_scktSocket.iSend(szSend, uiReadSize, 0);   
		/*DEBUG*/XASSERT_RET(uiReadSize == iRes, FALSE);
		if (iRes < 0) {   
			break;  
		} 
	}
	
	//-------------------------------------
	//[\r\n.\r\n]
	iRes = m_scktSocket.iSend(sEndCmd.c_str(), sEndCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sEndCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	return TRUE;   
}   
//---------------------------------------------------------------------------  
BOOL CXSmtp::bSend(const std::string &csText, const std::string &sFrom, const std::string &sTo) {   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_scktSocket, FALSE);
	/*DEBUG*/XASSERT_RET(FALSE == sFrom.empty(),         FALSE); 
	/*DEBUG*/XASSERT_RET(FALSE == sTo.empty(),		     FALSE); 

	INT         iRes      = SOCKET_ERROR;   

	const std::string sHelloCmd = "HELO DrWEB\r\n";
	const std::string sFromCmd  = "MAIL FROM:<" + sFrom + ">\r\n";
	const std::string sToCmd    = "RCPT TO:<"   + sTo   + ">\r\n";
	const std::string sDataCmd  = "DATA\r\n";
	const std::string sEndCmd   = "\r\n.\r\n";

	//-------------------------------------
	//[HELO DrWEB\r\n]
	iRes = m_scktSocket.iSend(sHelloCmd.c_str(), sHelloCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sHelloCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------
	//[MAIL FROM:<my_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sFromCmd.c_str(), sFromCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sFromCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------	
	//[RCPT TO:<your_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sToCmd.c_str(), sToCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sToCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------
	//[DATA\r\n]
	iRes = m_scktSocket.iSend(sDataCmd.c_str(), sDataCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sDataCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	//-------------------------------------
	//�������� �����
	iRes = m_scktSocket.iSend(csText.c_str(), csText.size(), 0);   
	/*DEBUG*/XASSERT_RET(csText.size() == iRes, FALSE);

	//-------------------------------------
	//[\r\n.\r\n]
	iRes = m_scktSocket.iSend(sEndCmd.c_str(), sEndCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sEndCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

	return TRUE;   
}   
//---------------------------------------------------------------------------   
BOOL CXSmtp::bDisconnect() {   
	INT         iRes     = SOCKET_ERROR;
  
	const std::string sQuitCmd = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sQuitCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

#ifdef _DEBUG   
	m_szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", m_szRecv);   
#endif     

	if (FALSE == m_scktSocket.bClose()) {
		return FALSE;
	}   

	return TRUE;   
}   
//---------------------------------------------------------------------------   



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
INT CXSmtp::iSmtpSend(LPSTR pszInBuff, INT iInBuffSize, INT iFlags) {   
	/*DEBUG*/XASSERT_RET(NULL != pszInBuff,   - 1);
	/*DEBUG*/XASSERT_RET(0     < iInBuffSize, - 1);

	INT iRes    = - 1;   
	INT iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iSend(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		if (iRes < 0) {  
			/*DEBUG*/XASSERT_RET(FALSE, - 1);
			return - 1;   
		}

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((LPSTR)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
BOOL CXSmtp::bIsError(const std::string &csText) {
    /*DEBUG*/XASSERT_RET(FALSE == csText.empty(), TRUE);
     
    /*int iResponseCode[] =
    {
        {500, "Syntax error, command unrecognized"                            },
        {501, "Syntax error in parameters or arguments"                       },
        {502, "Command not implemented"                                       },
        {503, "Bad sequence of commands"                                      },
        {504, "Command parameter not implemented"                             },
        {211, "System status, or system help reply"                           },
        {214, "Help message"                                                  },
        {220, "<domain> Service ready"                                        },
        {221, "<domain> Service closing transmission channel"                 },
        {421, "<domain> Service not available, closing transmission channel"  },
        {250, "Requested mail action okay, completed"                         },
        {251, "User not local; will forward to <forward-path>"                },
        {252, "Cannot VRFY user, but will accept message and attempt delivery"},
        {450, "Requested mail action not taken: mailbox unavailable"          },
        {550, "Requested action not taken: mailbox unavailable"               },
        {451, "Requested action aborted: error in processing"                 },
        {551, "User not local; please try <forward-path>"                     },
        {452, "Requested action not taken: insufficient system storage"       },
        {552, "Requested mail action aborted: exceeded storage allocation"    },
        {553, "Requested action not taken: mailbox name not allowed"          },
        {554, "Transaction failed"                                            },
        {354, "Start mail input; end with <CRLF>.<CRLF>"                      }
    };*/

	BOOL bRes = !(
			!memcmp(csText.c_str(), "220", 3) || 
			!memcmp(csText.c_str(), "250", 3) || 
			!memcmp(csText.c_str(), "354", 3) || 
			!memcmp(csText.c_str(), "221", 3)
	);
	 
	return bRes;
}
//---------------------------------------------------------------------------