/****************************************************************************
*	CXCheckBox
*
*****************************************************************************/


#ifndef CXCheckBox_H
#define CXCheckBox_H
//---------------------------------------------------------------------------
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
class CXCheckBox: public CXSubclassWnd {
	public:
		     CXCheckBox  ();
		BOOL Create      (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);
		BOOL IsChecked   ();
		void Check       (BOOL bChecked);
};
//---------------------------------------------------------------------------
#endif