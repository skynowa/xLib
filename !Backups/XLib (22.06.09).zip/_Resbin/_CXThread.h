/****************************************************************************
* Class name:  CXThread
* Description: ������ � ��������
* File name:   CXThread.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2009 17:20:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXThreadH
#define CXThreadH
//---------------------------------------------------------------------------
#include <windows.h>
#include <process.h>
#include <string>
#include <XLib/xassert.h>
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
namespace XLib {
	template<class T, class P>
	class CXThread {
		public:
			//typedef enum {
			//	cfCreateSuspended = CREATE_SUSPENDED,
			//	cfCreateRunning   = 0
			//} ECreationFlag;

			typedef VOID (T::*ThreadFunc)(P);
			
			         CXThread();
			virtual ~CXThread();

			//Run - Start the CXThread and run the method
			//pClass->(*pfFunc), passing p as an argument.
			//Returns true if the thread was created 
			//successfully, false otherwise
			BOOL bRun(T *pClass, ThreadFunc pfFunc, P p);

			//Suspend - Suspends the thread (if one is active)
			BOOL bSuspend();

			//Resume - Resumes a previously suspended thread
			BOOL bResume();

			//bKill - Terminates the thread (if one is active).
			//Prefer another means of exiting the thread, as
			//calling Terminate() does not allow the thread to free
			//any resources it may hold
			BOOL bKill();

			//IsThreadActive - Called in the context of another
			//(external) thread to test whether the thread is
			//currently running
			BOOL bIsActive() const;
			
			//ExitThread methods - Called within the context of an
			//external thread to instruct the embedded (running)
			//thread to exit.  
			//
			//bExit() - Signals the event and immediately 
			//returns.  
			//
			//bExitAndWait() - Signals the event and waits 
			//until the thread actually exits or the timeout
			//expires.  Returns true if the thread exited, or
			//false if the timeout expired
			BOOL bExit       ();
			BOOL bExitAndWait(ULONG ulTimeoutMS = 5000);

			//IsExitEventSet - Called by the embedded (running)
			//thread to test if the exit event is set.  Returns
			//true if the event has been set, and the thread
			//should exit, and false otherwise
			BOOL bIsExitEventSet();
			
			
			BOOL bWaitFor(ULONG ulWaitTime = INFINITE);

		protected:
			//Static CXThread Proc - The ThreadProc called by the
			//Windows _beginthreadex() function.  The parameter is
			//a pointer to the thread instance that is being started.  
			static UINT/*ULONG*/ WINAPI ulThreadProc(VOID *pvParam);

			//Handle to the created CXThread
			HANDLE      m_hThread;
			//Handle to the Exit Event
			HANDLE      m_hExitEvent;
			//ID of the created thread
			ULONG       m_ulThreadID;

			//ThreadFunc invoketion members
			T          *m_pInstance;
			ThreadFunc	m_pfFunc;
			P			m_iParam;
	};

	//---------------------------------------------------------------------------
	template<class T, class P>
	CXThread<T, P>::CXThread()
		: m_hThread   (NULL)
		, m_hExitEvent(NULL)
		, m_ulThreadID((ULONG) - 1)
		, m_pInstance (NULL)
		, m_pfFunc    (NULL)
	{
		//Create the Exit Event - Should the args to CreateEvent be
		//customizable?  What should be done if CreateEvent() fails?
		//NOTE: Since we will have only one consumer of the exit event,
		//it is safe to make the event an auto-reset event
		m_hExitEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
		/*DEBUG*/XASSERT(NULL != m_hExitEvent);
	}

	//---------------------------------------------------------------------------
	template<class T, class P>
	CXThread<T, P>::~CXThread()	{
		/*DEBUG*/XASSERT(NULL != m_hThread);
		/*DEBUG*/XASSERT(NULL != m_hExitEvent);

		if (bIsActive()) {
			bKill();
		}
			
		/*DEBUG*/XASSERT(NULL != m_hExitEvent);
		BOOL bRes = ::CloseHandle(m_hExitEvent);
		/*DEBUG*/XASSERT(FALSE != bRes);
		
		m_hExitEvent = NULL;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bRun(T *pClass, ThreadFunc pfFunc, P param)	{
		/*DEBUG*/XASSERT_RET(NULL == m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
		/*DEBUG*/XASSERT_RET(NULL != pClass,       FALSE);
		/*DEBUG*/XASSERT_RET(NULL != pfFunc,       FALSE);
		/*DEBUG*///////////XASSERT_RET(0    <  param,        FALSE);
		
		
		//Store the values in this class instance so
		//the static ulThreadProc() function can call
		//the appropriate method on the object
		m_pInstance = pClass;
		m_pfFunc    = pfFunc;
		m_iParam    = param; 
 
		////m_hThread = ::CreateThread(NULL, 0, ulThreadProc, this, 0, &m_ulThreadID);
		m_hThread = (HANDLE)_beginthreadex(NULL, 0, ulThreadProc, /*lpPara*/this, /*dwCreationFlags*//*0*/m_iParam, (UINT *)&m_ulThreadID);
		/*DEBUG*/XASSERT_RET(NULL != m_hThread, FALSE);
		
		return TRUE/*(NULL != m_hThread)*/;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bSuspend() {
		/*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE); 
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
			
		ULONG ulRes = (DWORD) -1;
		
		ulRes = ::SuspendThread(m_hThread);
		/*DEBUG*/XASSERT_RET((DWORD) -1 != ulRes, FALSE);
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bResume()	{
		/*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
			
	    ULONG ulResumeCount = (DWORD) -1;
	    
		ulResumeCount = ::ResumeThread(m_hThread);
		/*DEBUG*/XASSERT_RET((DWORD) -1 != ulResumeCount, FALSE);
		while (ulResumeCount > 1) {
			ulResumeCount = ::ResumeThread(m_hThread);
			/*DEBUG*/XASSERT_RET((DWORD) -1 != ulResumeCount, FALSE);
		}
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bKill() {
		/*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE); 
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
		
		BOOL bRes = FALSE;  
	    bRes = ::TerminateThread(m_hThread, 0);
	    /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	    
	    bRes = ::CloseHandle(m_hThread);
	    /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	    
        m_hThread = NULL;
        
        return TRUE;
    }
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bIsActive() const {
	    /*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
	       
		return ((NULL != m_hThread) && (WAIT_OBJECT_0 != ::WaitForSingleObject(m_hThread, 0)));
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	UINT/*ULONG*/ WINAPI CXThread<T, P>::ulThreadProc(VOID *pvParam) {
		CXThread *pInstance = reinterpret_cast<CXThread *>(pvParam);
		/*DEBUG*/XASSERT_RET(NULL != pInstance, (ULONG) - 1);

		//Get the invoketion variables so we don't have to
		//use even more funky syntax
		T         *pClassInstance = pInstance->m_pInstance;
		ThreadFunc pfFunc         = pInstance->m_pfFunc;
		P          param          = pInstance->m_iParam;
		/*DEBUG*/XASSERT_RET(NULL != pClassInstance, (ULONG) - 1);
		/*DEBUG*/XASSERT_RET(NULL != pfFunc,         (ULONG) - 1);
		/*DEBUG*//////////////XASSERT_RET(0    <  param,          (ULONG) - 1);


		//We have a valid instance of the CXThread class, use
		//the thread's stored parameters to call the client
		//(worker) function.  This will continue to run in
		//the context of this (seperate) thread until finished
		((*pClassInstance).*pfFunc)(param);

		return 0;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bExit()	{
	    /*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
	    
		BOOL bRes = FALSE;
		
		bRes = ::SetEvent(m_hExitEvent);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bExitAndWait(ULONG ulTimeoutMS) {
	    /*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
	    
		BOOL bRes = FALSE;
		
		//Set the event telling the thread to exit
		bRes = ::SetEvent(m_hExitEvent);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

		//Wait for the thread to actually exit
		ULONG ulRes = ::WaitForSingleObject(m_hThread, ulTimeoutMS);            //debug

		//Cleanup handle
		/*DEBUG*/XASSERT(NULL != m_hThread);
		bRes = ::CloseHandle(m_hThread);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
		m_hExitEvent = NULL;

		return (WAIT_OBJECT_0 == ulRes);
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bIsExitEventSet()	{
	    /*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
	        
		ULONG ulRes = ::WaitForSingleObject(m_hExitEvent, 0);
		
		return (WAIT_OBJECT_0 == ulRes);
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThread<T, P>::bWaitFor(ULONG ulWaitTime) {
	    /*DEBUG*/XASSERT_RET(NULL != m_hThread,    FALSE);
		/*DEBUG*/XASSERT_RET(NULL != m_hExitEvent, FALSE);
	        
		ULONG ulRes = ::WaitForSingleObject(m_hThread, ulWaitTime);

		return (WAIT_OBJECT_0 == ulRes);
	}
}
//---------------------------------------------------------------------------
#endif