/****************************************************************************
* Class name:  CXLog
* Description: �����������
* File name:   CXLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 10:24:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXLog.h>

#include <stdio.h>
#include <stdlib.h>
#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>
#include <XLib/CXSync/CXLockScope.h>
#include <XLib/CXStdioFile.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf

CXCriticalSection CXLog::ms_csFile;
CXCriticalSection CXLog::ms_csListBox;
CXCriticalSection CXLog::ms_csConsole;
//---------------------------------------------------------------------------
CXLog::CXLog() 
	: m_sLogPath(""), 
	  m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);

	//�� ������ ���� (��� �����)
	m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + sExtractFullFileName(sExePath()) + ".log";
	m_ulMaxFileSize = DEFAULT_MAX_LOG_SIZE;
}
//---------------------------------------------------------------------------
CXLog::CXLog(const std::string &csFilePath, ULONG ulMaxFileSize) 
	: m_sLogPath(""), 
	  m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > ulMaxFileSize);
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);
	
	//��� ����� - �� �������� "\"
	if (std::string::npos == csFilePath.find("\\")) {
		//�� ������ ���� (��� �����)
		m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + csFilePath/* + ".log"*/;
		m_ulMaxFileSize = ulMaxFileSize;
	} else {
		//������ ����
		m_sLogPath      = csFilePath;
		m_ulMaxFileSize = ulMaxFileSize;
	}
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	

}
//---------------------------------------------------------------------------
BOOL CXLog::bWriteToFile(LPCSTR pcszFormat, ...) {   
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	bRes = bDeleteFileIfFull();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXLockScope SL(ms_csFile);

	CXStdioFile sfFile;

	bRes = sfFile.bOpen(m_sLogPath, "a");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	sfFile.iFprintf("%s %s\r\n", sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXLog::bTrace(LPCSTR pcszFormat, ...) {     
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	::OutputDebugString((sTime + " " + sParam + "\r\n").c_str());
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXLog::bWriteToListBox(HWND hLst, LPCSTR pcszFormat, ...) { 
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXLockScope SL(ms_csListBox);

	//sRemoveEOL
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)(sTime + " " + sParam).c_str());
	::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXLog::bWriteToConsole (LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXLockScope SL(ms_csConsole);

	CXStdioFile::iPrintf("%s %s\r\n", sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXLog::bDeleteFile() {
    BOOL bRes = FALSE;
	
	/*LOCK*/CXLockScope SL(ms_csFile);

	bRes = CXStdioFile::bRemove(m_sLogPath);
    /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXLog::bOpenFile() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec("notepad.exe", m_sLogPath);
	////bRes = CXStdioFile::bExec(m_sLogPath, "-a");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXLog::bClearFile() {
	BOOL bRes = FALSE;
	
	/*LOCK*/CXLockScope SL(ms_csFile);
	
	CXStdioFile sfFile;
	bRes = sfFile.bOpen(m_sLogPath, "w");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	sfFile.iFprintf("");
	
	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Private methodz
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXLog::bDeleteFileIfFull() {
	BOOL bRes = FALSE;

	/*LOCK*/CXLockScope SL(ms_csFile);

	bRes = CXStdioFile::bIsExists(m_sLogPath);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, TRUE);
	
	CXStdioFile sfFile;
	LONG        liSize = CXStdioFile::fpError;

	bRes = sfFile.bOpen(m_sLogPath, "w");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	
	liSize = sfFile.liGetSize();
	/*DEBUG*/XASSERT_RET(CXStdioFile::fpError != liSize, FALSE);

	bRes = sfFile.bClose();
	/*DEBUG*/XASSERT_RET(CXStdioFile::fpError != liSize, FALSE);

	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ULONG)(liSize / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		bRes = bDeleteFile();
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------