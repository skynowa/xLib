/****************************************************************************
* Class name:  CXLockScope
* Description: �����
* File name:   CXLockScope.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.04.2009 15:33:00
*
*****************************************************************************/


#ifndef CXLockScopeH
#define CXLockScopeH
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
/*class CXLock {
    public:
		CXLock() {
			::InitializeCriticalSection(&m_CS);
		}
		~ CXLock() {
			::DeleteCriticalSection(&m_CS);
		}
		void lock() {
			::EnterCriticalSection(&m_CS);
		}
		void unlock() {
			::LeaveCriticalSection(&m_CS);
		}
        
	private:
		::CRITICAL_SECTION m_CS;
};*/
//---------------------------------------------------------------------------
class CXLockScope {
    public:
        CXLockScope(CXLock &l): m_lock(l) {
            m_lock.lock();
        }
        ~ CXLockScope() {
            m_lock.unlock();
        }
        
    private
        CXLock &m_lock;
};
//---------------------------------------------------------------------------
#endif