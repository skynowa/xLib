/**********************************************************************
*	����� CPop3 (CPop3.h)
*
***********************************************************************/


#ifndef CPop3H
#define CPop3H       
//---------------------------------------------------------------------------
#include "Winsock2.h"
#include <string>
#include <stdio.h>
#include <stdlib.h>

using std::string;
//---------------------------------------------------------------------------
class CPop3 {
	public:
			CPop3();
			~CPop3();
		bool bCreate(string sHost, int nPort);		//1. ������� �����
		//lookfor
		bool bConnect(string sUser, string sPass);	//2. �������������
		//bLogin
		bool bDisconnect();							//4. ��������������
		bool bClose();								//5. ������� �����
		bool bGetTimeOut(DWORD *dwTimeOut);
		bool bSetTimeOut(DWORD dwTimeOut);

		//Response
		//���-�� �������
		//mailman.put_ConnectTimeout(5);
		//3. ������������
		//mailman.put_ReadTimeout(10);
		
		bool IsConnected();
		//sendString

    private:
		SOCKET  m_sPop3Socket;
		WSADATA m_wsdRec;
		int     m_iMaxAttemps;
};
//---------------------------------------------------------------------------
#endif


/**********************************************************************
*	����� CPop3 (CPop3.cpp)
*
***********************************************************************/


//---------------------------------------------------------------------------
CPop3::CPop3() {	

}
//---------------------------------------------------------------------------
CPop3::~CPop3() {	
/*inline   Pop3::Pop3() {
	////{
	////	std::stringstream ss;
	////	ss << "QUIT\r\n";
	////	Write(ss.str());
	////}

	////std::string response = Response();
	////if (response.find("+OK") == response.npos) {
	////	throw  SocketException(response);
	////}*/
}
//--------------------------------------------------------------------------
//1. ������� �����
bool CPop3::bCreate(string sHost, int nPort) {
	return false;
}
//--------------------------------------------------------------------------
//2. �������������
bool CPop3::bConnect(string sUser, string sPass) {
	return false;
}
//--------------------------------------------------------------------------
//4. ��������������
bool CPop3::bDisconnect() {
	return false;
}
//--------------------------------------------------------------------------
//5. ������� �����
bool CPop3::bClose() {
	return false;
}
//--------------------------------------------------------------------------


/*
unsigned long SizeOfFile(FILE* fil) 
{ 
   unsigned long ler; 
   fseek(fil,0,SEEK_END); 
   ler=ftell(fil); 
   fseek(fil,0,SEEK_SET); 
   return ler; 
} 

Verify the POP3 TCP/IP connection.
//////////////////////////////////////////
    // Set the POP3 connect timeout to 5 seconds
    mailman.put_ConnectTimeout(5);
    // Set the POP3 read timeout to 10 seconds.
    mailman.put_ReadTimeout(10);
/////////////////////////////////////////////////
    CkMailMan mailman;

    mailman.put_MailHost("mail.chilkatsoft.com");
    mailman.put_PopUsername("matt");
    mailman.put_PopPassword(myPassword);

    // Set the POP3 port to the standard MS Exchange Server SSL POP3 port 995
    mailman.put_MailPort(995);
    // Tell the mailman to connect to POP3 using SSL
    mailman.put_PopSsl(true);
///////////////////////////////////////////////////////
#include <CkMailMan.h>
#include <CkCert.h>

void ChilkatSample(void)
    {
    //  The mailman object is used for receiving (POP3)
    //  and sending (SMTP) email.
    CkMailMan mailman;

    //  Any string argument automatically begins the 30-day trial.
    bool success;
    success = mailman.UnlockComponent("30-day trial");
    if (success != true) {
        printf("Component unlock failed\n");
        return;
    }

    //  Set the GMail account POP3 properties.
    mailman.put_MailHost("pop.gmail.com");
    mailman.put_PopUsername("chilkat.support");
    mailman.put_PopPassword("****");
    mailman.put_PopSsl(true);
    mailman.put_MailPort(995);

    //  Use our certificate, which is already installed
    //  in our current-user certificate store on the computer.
    CkCert clientCert;
    success = clientCert.LoadByCommonName("Chilkat Software, Inc.");
    if (success != true) {
        printf("%s\n",clientCert.lastErrorText());
        return;
    }

    //  Note: The GMail POP3 server does not require that you
    //  have a client cert.  This example only demonstrates
    //  how you may use a client certificate.  Typically,
    //  higher-security systems may require a client-side SSL cert.
    mailman.SetSslClientCert(clientCert);

    //  Establish a POP3 connection:
    success = mailman.Pop3BeginSession();
    if (success != true) {
        printf("%s\n",mailman.lastErrorText());
        return;
    }

    //  Let's look at the LastErrorText to see the details
    //  of the successful connection.  We should see our cert:
    printf("%s\n",mailman.lastErrorText());
//////////////////////////////////////////////////////////////////////////////
Retrieve UIDL's from POP3 Server
/////////////////////////////////////////////////////////////////////////////////
Accept Connection on Socket

Demonstrates how to create a TCP/IP socket, listen on a port, accept an incoming connection, and send a "Hello World" message to the client.

 Download Chilkat C/C++ Libraries for VC++ 9.0 / Win32

 Download Chilkat C/C++ Libraries for VC++ 8.0 / Win32

 Download Chilkat C/C++ 64-bit Libraries for VC++ 8.0 / x64

 Download Chilkat Visual Studio 2005 C/C++ Libs for Windows Mobile, Pocket PC, SmartPhone, WinCE

 Download Chilkat C/C++ Libraries for VC++ 7.0 / Win32

 Download Chilkat C/C++ Libraries for VC++ 6.0 / Win32

 Download Chilkat C/C++ Libraries for VC++ 6.0, Win 95/98/NT4 Compatible
#include <CkSocket.h>

void ChilkatSample(void)
    {
    CkSocket listenSocket;

    bool success;
    success = listenSocket.UnlockComponent("Anything for 30-day trial");
    if (success != true) {
        printf("Failed to unlock component\n");
        return;
    }

    //  Bind to a port and listen for incoming connections:
    //  This example will listen at port 5555 and allows for a backlog
    //  of 25 pending connection requests.
    success = listenSocket.BindAndListen(5555,25);
    if (success != true) {
        printf("%s\n",listenSocket.lastErrorText());
        return;
    }

    //  Get the next incoming connection
    //  Wait a maximum of 20 seconds (20000 millisec)
    CkSocket *connectedSocket = 0;
    connectedSocket = listenSocket.AcceptNextConnection(20000);
    if (connectedSocket == 0 ) {
        printf("%s\n",listenSocket.lastErrorText());
        return;
    }

    //  Set maximum timeouts for reading an writing (in millisec)
    connectedSocket->put_MaxReadIdleMs(10000);
    connectedSocket->put_MaxSendIdleMs(10000);

    //  Send a "Hello World!" message to the client:
    success = connectedSocket->SendString("Hello World!");
    if (success != true) {
        printf("%s\n",connectedSocket->lastErrorText());
        delete connectedSocket;
        return;
    }

    //  Close the connection with the client.
    //  Wait a max of 20 seconds (20000 millsec)
    connectedSocket->Close(20000);

    printf("success!\n");
    }
///////////////////////////////////////////////////

*/