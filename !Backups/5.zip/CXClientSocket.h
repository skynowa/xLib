/**********************************************************************
*	����� CXClientSocket (CXClientSocket.h)
*
***********************************************************************/

#ifndef CXClientSocketH
#define CXClientSocketH   

#pragma comment(lib, "Ws2_32.lib")	
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
//---------------------------------------------------------------------------
class CXClientSocket {
	public:
			               CXClientSocket  (const char *pcszHostName, unsigned short usPort);
			               ~CXClientSocket ();
		
		bool               bConnect        ();
		bool               bSend		   (char *pszText);
		bool               bReceive        (char *pszText, const int ciRecvTextLen);
		bool               bDisconnect     ();
		
    private:
		WSADATA            m_wsaData;
		SOCKET             m_puiSocket;
		struct sockaddr_in m_saSockAddr;					
		PHOSTENT           m_phstHost;		
		///char               m_szBuff[2048];

		//////////--char               m_szBuffIn [2048];
		char               m_szBuffOut[2048];

		bool               bIsError        (char *pszText); 	
};
//---------------------------------------------------------------------------
#endif