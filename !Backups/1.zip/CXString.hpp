/**********************************************************************
*	CXString.hpp
*
***********************************************************************/


#ifndef CXSTRING_HPP
#define CXSTRING_HPP
//---------------------------------------------------------------------------
#define LONG   long
#define DWORD  unsigned long
#define UINT   unsigned int
#define INT    int
#define SHORT  short                        
#define WORD   unsigned short                         
#define BYTE   unsigned char                          
#define DOUBLE double                      
#define BOOL   int  
//---------------------------------------------------------------------------
#include <string>
#include <sstream>
#include <tchar.h>
//---------------------------------------------------------------------------
//���������
LONG                              StrToLONG   (LPCTSTR pszValue, LONG   Default = 0,  int Radix = 0);
DWORD                             StrToDWORD  (LPCTSTR pszValue, DWORD  Default = 0,  int Radix = 0);
UINT                              StrToUINT   (LPCTSTR pszValue, UINT   Default = 0,  int Radix = 0);
INT                               StrToINT    (LPCTSTR pszValue, INT    Default = 0,  int Radix = 0);
SHORT                             StrToSHORT  (LPCTSTR pszValue, SHORT  Default = 0,  int Radix = 0);
WORD                              StrToWORD   (LPCTSTR pszValue, WORD   Default = 0,  int Radix = 0);
BYTE                              StrToBYTE   (LPCTSTR pszValue, BYTE   Default = 0,  int Radix = 0);
DOUBLE                            StrToDOUBLE (LPCTSTR pszValue, DOUBLE Default = 0.0);
BOOL                              StrToBOOL   (LPCTSTR pszValue, BOOL   Default = FALSE);
bool                              StrTobool   (LPCTSTR pszValue, bool   Default = false);

template <typename T> std::string sTypeToStr  (const T &t);	          		
template <typename T> T           iTypeFromStr(const std::string &sStr);
std::string                       sTrimSpace  (const std::string &sStr);
//---------------------------------------------------------------------------
LONG StrToLONG(LPCTSTR pszValue, LONG Default /*= 0*/, int Radix /*= 0*/) {
    LPTSTR pszStop;
    if ( *pszValue != 0 ) {
        LONG nResult = _tcstol(pszValue, &pszStop, Radix);
        if (*pszStop == 0) {
            return (nResult);
        }
    }
    return (Default);  
}
//---------------------------------------------------------------------------
DWORD StrToDWORD(LPCTSTR pszValue, DWORD Default /*= 0*/, int Radix /*= 0*/) {
    LPTSTR pszStop;
    if (*pszValue != 0) {
        LONG nResult = _tcstoul(pszValue, &pszStop, Radix);
        if (*pszStop == 0) {
            return (nResult);
        }
    }
    return (Default);  
}
//---------------------------------------------------------------------------
BOOL StrToBOOL(LPCTSTR pszValue, BOOL fDefault /* = FALSE */) {
    return (*pszValue != 0 ? _tcschr(_T("1tTyY"), pszValue[0]) != NULL : fDefault);
}
//---------------------------------------------------------------------------
DOUBLE StrToDOUBLE(LPCTSTR pszValue, DOUBLE Default /*= 0.0*/) {
    LPTSTR pszStop;
    if (*pszValue != 0) {
        DOUBLE nResult = _tcstod(pszValue, &pszStop);
        if (*pszStop == 0) {
            return (nResult);
        }
    }
    return (Default);    
}
//---------------------------------------------------------------------------
SHORT StrToSHORT(LPCTSTR pszValue, SHORT Default /*= 0*/, int Radix /*= 0*/) {
	return (static_cast<SHORT>(/*= 0*/StrToLONG(pszValue,Default,Radix)));
}
//---------------------------------------------------------------------------
WORD StrToWORD(LPCTSTR pszValue,WORD Default /*= 0*/, int Radix /*= 0*/) {
	return ( LOWORD(/*= 0*/StrToDWORD(pszValue,Default,Radix)) );
}
//---------------------------------------------------------------------------
BYTE  StrToBYTE(LPCTSTR pszValue,BYTE Default /*= 0*/, int Radix /*= 0*/) {
	return (LOBYTE(LOWORD(/*= 0*/StrToDWORD(pszValue,Default,Radix))));  
}
//---------------------------------------------------------------------------
bool StrTobool(LPCTSTR pszValue, bool Default /* = false */) {
    return (/*= 0*/StrToBOOL(pszValue, Default) != 0);
}
//---------------------------------------------------------------------------
INT  StrToINT(LPCTSTR pszValue, INT Default /*= 0*/, int Radix /*= 0*/) {
	return (static_cast<INT>(/*= 0*/StrToLONG(pszValue,Default,Radix)) );
}
//---------------------------------------------------------------------------
UINT StrToUINT(LPCTSTR pszValue, UINT Default /*= 0*/, int Radix /*= 0*/) {
	return (static_cast<UINT>(/*= 0*/StrToLONG(pszValue,Default,Radix)));
}
//---------------------------------------------------------------------------

/**********************************************************************
*   sStringConversation.h
*   ������� ������� ��� �������������� � ������ � �������
*
*   <<< ������ �������������: >>>
*   std::string str;
*   int         iVal;
*   float       fVal;
*
*   str = sToString(iVal);
*   str = sToString(fVal);
*
*   iVal = iFromString<int>(str);
*   fVal = iFromString<float>(str);
*
***********************************************************************/

//---------------------------------------------------------------------------
template <typename T> std::string sTypeToStr(const T &t) {
    std::ostringstream oss;
    oss << t;

    return oss.str();
}
//---------------------------------------------------------------------------
template <typename T> T iTypeFromStr(const std::string &sStr) {
    std::istringstream iss(sStr);
    T t;
    iss >> t;

    return t;
}
//---------------------------------------------------------------------------
std::string sTrimSpace(const std::string &sStr) {
    std::string sRes = "";
    sRes.assign(sStr);

    while ((!sRes.empty()) && (*sRes.begin() == ' ')) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (*sRes.rbegin() == ' ')) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;
}
//---------------------------------------------------------------------------
/*
string &replace_all(string &str,const string& old_value,const string& new_value)   
{   
       while(true)    
       {   
               string::size_type   pos(0);   
               if(   (pos=str.find(old_value))!=string::npos)   
                       str.replace(pos,old_value.length(),
new_value);   
               else   break;   
       }   
       return   str;   
} 


void CParser::RemoveChar(string & str, const char ch) {
    for (int i = str.find(ch); i != string::npos; i = str.find(ch))
        str.erase(i, 1);
}

void CParser::RemoveTrims(string & str) {
    const char * delim = " \t";
    
    int i = str.find_first_not_of(delim);
    if (i) str.erase(0, i);
    
    i = str.find_last_not_of(delim) + 1;
    if (i < str.length()) str.erase(i, str.length());
}
*/

/*
#include <string>
#include <iostream>


//---------------------------------------------------------------------------
std::string sTranslitLatToRus(std::string sText) {
	//-------------------------------------
	//CHECK
	if (sText.size() == 0) {        
		return "";
	}

	//-------------------------------------
	//�������
	std::string sRes       = "";
	const int   ciDictSize = 66;
	std::string sDict[ciDictSize][2] =	{
			{"�", "Y"},
			{"�", "C"},
			{"�", "U"},
			{"�", "K"},
			{"�", "E"},
			{"�", "E"},
			{"�", "N"},
			{"�", "G"},
			{"�", "SH"},
			{"�", "SH'"},
			{"�", "Z"},
			{"�", "H"},
			{"�", "`"},
			{"�", "F"},
			{"�", "I"},
			{"�", "V"},
			{"�", "A"},
			{"�", "P"},
			{"�", "R"},
			{"�", "O"},
			{"�", "L"},
			{"�", "D"},
			{"�", "ZH"},
			{"�", "E"},
			{"�", "YA"},
			{"�", "4"},
			{"�", "S"},
			{"�", "M"},
			{"�", "I"},
			{"�", "T"},
			{"�", "'"},
			{"�", "B"},
			{"�", "YU"},

			{"�", "y"},
			{"�", "c"},
			{"�", "u"},
			{"�", "k"},
			{"�", "e"},
			{"�", "e"},
			{"�", "n"},
			{"�", "g"},
			{"�", "sh"},
			{"�", "sh'"},
			{"�", "z"},
			{"�", "h"},
			{"�", "`"},
			{"�", "f"},
			{"�", "i"},
			{"�", "v"},
			{"�", "a"},
			{"�", "p"},
			{"�", "r"},
			{"�", "o"},
			{"�", "l"},
			{"�", "d"},
			{"�", "zh"},
			{"�", "e"},
			{"�", "ya"},
			{"�", "4"},
			{"�", "s"},
			{"�", "m"},
			{"�", "i"},
			{"�", "t"},
			{"�", "'"},
			{"�", "b"},
			{"�", "yu"}
	};

	//-------------------------------------
	//������ ��������
	for (int i = 0; i < ciDictSize; i ++) {
		////sText = sReplaceAll(sText, sDict[i][0], sDict[i][1]);
		std::string sOldStr = sDict[i][0];
		std::string sNewStr = sDict[i][1];
		std::string::size_type stPos;

		while ((stPos = sText.find(sOldStr)) != std::string::npos) {
			sText.replace(stPos, 1, sNewStr);
		}
	}

	return sText;
}
//---------------------------------------------------------------------------
*/

/*
void DecodeStr(char *szString);
char DecodeHex(char *str);

void DecodeStr(char *szString) {

  int src;

  int dst;

  char ch;

  for(src=0, dst=0; szString[src]; src++, dst++)   {

    ch = szString[src];

    ch = (ch == '+') ? ' ' : ch;

    szString[dst] = ch;

    if(ch == '%')

    {

      szString[dst] = DecodeHex(&szString[src + 1]);

      src += 2;

    }

  }

  szString[dst] = '\0';

}


char DecodeHex(char *str) {

  char ch;

  if(str[0] >= 'A')

    ch = ((str[0] & 0xdf) - 'A') + 10;

  else

    ch = str[0] - '0';

  ch <<= 4;

  if(str[1] >= 'A')

    ch += ((str[1] & 0xdf) - 'A') + 10;

  else

    ch += str[1] - '0';

  return ch;
}
*/
#endif