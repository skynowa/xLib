/**********************************************************************
*	CIni.h
*
***********************************************************************/


#ifndef CIniH
#define CIniH
//---------------------------------------------------------------------------
#include <string>
#include <iostream>
#include <stdio.h>

#define LINE_LEN 256
//---------------------------------------------------------------------------
class CIni {
	public:
					CIni             (char *pszFileName);
					~CIni            ();

		bool        bCreateDefaultINI(char *pszFileName); 
		int         iReadInteger     (char *pszSection, char *pszKey, int         iDefaultValue);
		double      dReadFloat       (char *pszSection, char *pszKey, double      dDefaultValue);
		bool        bReadBoolean     (char *pszSection, char *pszKey, bool        bDefaultValue);
		std::string sReadString      (char *pszSection, char *pszKey, const char *pcszDefaultValue);

		void        vWriteInteger    (char *pszSection, char *pszKey, int         iValue);
		void        vWriteFloat      (char *pszSection, char *pszKey, float       fValue);
		void        vWriteBoolean    (char *pszSection, char *pszKey, bool        bValue);
		void        vWriteString     (char *pszSection, char *pszKey, char       *pszValue);
		
	private:
		char  m_szFileName[255];
		char *m_pszResReadString;
};
//---------------------------------------------------------------------------
#endif 
 