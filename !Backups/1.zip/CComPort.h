/**********************************************************************
*	����� CComPort (CComPort.h)
*
***********************************************************************/


#ifndef CComPortH
#define CComPortH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>


//---------------------------------------------------------------------------
class CComPort {
	public:
	                CComPort        (const std::string &sPortNum);
		            ~CComPort       ();
		
		bool        bOpen           ();
		bool        bConfig         ();
		bool        bClearData      ();
		std::string bReadData       (char *pszBuff, DWORD dwNumOfBytesToRead);
		int         iReadDataWaiting();
		bool        bWriteData      (const char *pszBuff, DWORD dwNumOfBytesToWrite);
		bool        bClose          ();

		DWORD       dwInputBuffTest ();
		bool        bClearCLRDTR    (); //���������� ������ DTR
		bool        bClearCLRRTS    (); //���������� ������ RTS
    	bool        bSetSETDTR      ();   //������������ ������ DTR
		bool        bSetSETRTS      ();   //������������� ������ RTS
		
    private:
		HANDLE      m_hComPort;
		std::string m_sPortNum;

		HANDLE       handle;
		COMMTIMEOUTS CommTimeOuts;
		DCB          dcb;
		COMSTAT      ComState;              
		OVERLAPPED   Overlap;
};
//---------------------------------------------------------------------------
#endif