/**********************************************************************
*	CIni.cpp
*
***********************************************************************/


#include "CIni.h"

//-------------------------------------------------------------------------
CIni::CIni(char *pszFileName = "Config.ini") {
	//���� INI-����� ��� - �������	
	if (PathFileExists(pszFileName) == false) {
		if (bCreateDefaultINI(pszFileName) == false) {
			return;
		}
	};

	char szPath[MAX_PATH] = {0};
	GetCurrentDirectory(sizeof(szPath), szPath);
	strcpy_s(m_szFileName, szPath);
    strcat_s(m_szFileName, "\\\\");
	strcat_s(m_szFileName, pszFileName);
	
	m_pszResReadString = new char[LINE_LEN];
}
//-------------------------------------------------------------------------
CIni::~CIni() {
	delete [] m_pszResReadString;
}
//-------------------------------------------------------------------------
bool CIni::bCreateDefaultINI(char *pszFileName) {
	bool bRes = false;

	FILE *pFile = NULL;
	if (fopen_s(&pFile, pszFileName, "w") != 0 && pFile == NULL) {
		bRes = false;
    } else {
		fprintf_s(pFile, "[Settings]\n");
        fprintf_s(pFile, "MailAddress=kmda_ua@mail.ru\n");
		fprintf_s(pFile, "Sender=kmda_ua\n");
		fprintf_s(pFile, "Recipient=380975582000@2sms.kyivstar.net\n");
		fprintf_s(pFile, "Subject=Alert!\n");
		fprintf_s(pFile, "Text=Some text...\n");
		fprintf_s(pFile, "DNSServer=2sms.kyivstar.net\n");
		fprintf_s(pFile, "CheckTimeout=4000\n");
		fprintf_s(pFile, "COMPort=COM1");

		bRes = true;
    }
	fclose(pFile);

	return bRes;
}
//-------------------------------------------------------------------------

//������
//-------------------------------------------------------------------------
int CIni::iReadInteger(char *pszSection, char *pszKey, int iDefaultValue) {
	int iResult = GetPrivateProfileInt(pszSection, pszKey, iDefaultValue, m_szFileName);
	return iResult;
}
//-------------------------------------------------------------------------
double CIni::dReadFloat(char *pszSection, char *pszKey, double dDefaultValue) {
	char   szResult[LINE_LEN];
	char   szDefault[LINE_LEN];
	double dResult;

	sprintf_s(szDefault, "%d", dDefaultValue);
	GetPrivateProfileString(pszSection, pszKey, szDefault, szResult, LINE_LEN, m_szFileName);
	dResult = atof(szResult);
	return dResult;
}
//-------------------------------------------------------------------------
bool CIni::bReadBoolean(char *pszSection, char *pszKey, bool bDefaultValue) {
	char szResult[LINE_LEN];
	char szDefault[LINE_LEN];
	bool bResult;

	sprintf_s(szDefault, "%s", bDefaultValue ? "True" : "False");
	GetPrivateProfileString(pszSection, pszKey, szDefault, szResult, LINE_LEN, m_szFileName);
	bResult = (strcmp(szResult, "True") == 0 || strcmp(szResult, "true") == 0) ? true : false;
	return bResult;
}
//-------------------------------------------------------------------------
std::string CIni::sReadString(char *pszSection, char *pszKey, const char *pcszDefaultValue) {
	memset(m_pszResReadString, 0x00, LINE_LEN);
	GetPrivateProfileString(pszSection, pszKey, pcszDefaultValue, m_pszResReadString, LINE_LEN, m_szFileName);
	return std::string(m_pszResReadString);
}
//-------------------------------------------------------------------------


//�����
//-------------------------------------------------------------------------
void CIni::vWriteInteger(char *pszSection, char *pszKey, int iValue) {
	char szValue[LINE_LEN];
	sprintf_s(szValue, "%d", iValue);
	WritePrivateProfileString(pszSection, pszKey, szValue, m_szFileName);
}
//-------------------------------------------------------------------------
void CIni::vWriteFloat(char *pszSection, char *pszKey, float fValue) {
	char szValue[LINE_LEN];
	sprintf_s(szValue, "%f", fValue);
	WritePrivateProfileString(pszSection, pszKey, szValue, m_szFileName);
}
//-------------------------------------------------------------------------
void CIni::vWriteBoolean(char *pszSection, char *pszKey, bool bolValue) {
	char szValue[LINE_LEN];
	sprintf_s(szValue, "%s", bolValue ? "True" : "False");
	WritePrivateProfileString(pszSection, pszKey, szValue, m_szFileName);
}
//-------------------------------------------------------------------------
void CIni::vWriteString(char *pszSection, char *pszKey, char *szValue) {
	WritePrivateProfileString(pszSection, pszKey, szValue, m_szFileName);
}
//-------------------------------------------------------------------------