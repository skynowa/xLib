/**********************************************************************
*	�����  CLog (CLog.h)
*
***********************************************************************/


#ifndef CLogH
#define CLogH       
//---------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
//---------------------------------------------------------------------------
class CLog {
	public:
					CLog                  (const std::string &csFileName, unsigned long int ulMaxFileSize);
					~CLog                 ();
		void        vSetMaxFileSize       (unsigned long int ulMaxFileSize);	//Mb 
		void        vLog                  (const std::string &csFileText);
		void        vLogCharAsHex         (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
        void        vLogCharAsStr         (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
		void        vOpen                 ();
		void        vDelete               ();
		void        vSetName              (const std::string &csFileName);
		void        vSetPath              (const std::string &csFilePath);
		////std::string sErrorMessageStr      ();
	
	private:
		std::string       m_sLogPath;
		std::string       m_sLogName;
		unsigned long int m_ulMaxFileSize;
		
		////void              vErrorMessageBox();
        std::string       sGetCurrentDir  ();
		unsigned long int ulGetFileSize   (const std::string &csFilePath);
};
//---------------------------------------------------------------------------
#endif