/**********************************************************************
*	�����  CLog (CLog.cpp)  
*	
***********************************************************************/


#include "CLog.h"

#include <shlwapi.h>
#pragma comment (lib, "shlwapi.lib")

#include <shellapi.h>					//ShellExecute
#pragma comment (lib, "shell32.lib")	//ShellExecute
//---------------------------------------------------------------------------
CLog::CLog(const std::string &csFileName, unsigned long int ulMaxFileSize = 20) {
	m_sLogName      = csFileName;
	m_sLogPath      = sGetCurrentDir() + "\\" + m_sLogName;
	m_ulMaxFileSize = ulMaxFileSize;

	FILE *pFile = NULL; 
	if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {	
		//vErrorMessageBox();
    }
	fclose(pFile);
}
//---------------------------------------------------------------------------
std::string CLog::sGetCurrentDir() {
    TCHAR szPath[MAX_PATH] = {0};
	GetCurrentDirectory(sizeof(szPath), szPath);

    return std::string(szPath);  //����� ���� (��� ����� �� �����) + sizeof(szPath)
} 
//---------------------------------------------------------------------------
CLog::~CLog() {	
	
}
//---------------------------------------------------------------------------
void CLog::vDelete() {
    if (!SetFileAttributes(m_sLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
        //vErrorMessageBox();
    }
    if (remove(m_sLogPath.c_str()) != 0) {
        //vErrorMessageBox();
    }
}
//---------------------------------------------------------------------------
void CLog::vSetPath(const std::string &csFilePath) {
	m_sLogPath = m_sLogPath;
}
//---------------------------------------------------------------------------
void CLog::vSetName(const std::string &csFileName) {
	m_sLogName = csFileName;
	m_sLogPath = sGetCurrentDir() + "\\" + csFileName;
}
//---------------------------------------------------------------------------
void CLog::vOpen() {
	ShellExecute(NULL, NULL, m_sLogPath.c_str(), NULL, NULL, SW_SHOW);
}
//---------------------------------------------------------------------------
void CLog::vLog(const std::string &csFileText) {
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if (ulGetFileSize(m_sLogPath) >= m_ulMaxFileSize) {
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
		
	//-------------------------------------
	//����� ���
	FILE *pFile = NULL;
    if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {
        //vErrorMessageBox();
    } else {
        SYSTEMTIME stST;          
        GetLocalTime(&stST);
        fprintf_s(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileText.c_str());	
    }
	fclose(pFile);
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsHex(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
	    if (pcFileText[i] < 16) {
            //sRes += AnsiString(0).sprintf("0x0%x ", pcFileText[i]);
		} else {
            //sRes += AnsiString(0).sprintf("0x%2x ", pcFileText[i]);
        }
	}
	
	FILE *pFile = NULL;
    if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {
        //vErrorMessageBox();
    } else {
        SYSTEMTIME stST;
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
    }
	fclose(pFile);
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsStr(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
        //sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
        sRes.push_back(pcFileText[i]);      //???????????
	}

	FILE *pFile = NULL;
    if (fopen_s(&pFile, m_sLogPath.c_str(), "a") != 0 && pFile == NULL) {
        //vErrorMessageBox();
    } else {
        SYSTEMTIME stST;
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
    }
	fclose(pFile);
}
//---------------------------------------------------------------------------
////void CLog::vErrorMessageBox() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
////	LocalFree(lpMsgBuf);
////}
//---------------------------------------------------------------------------
////std::string CLog::sErrorMessageStr() {
////	LPVOID lpMsgBuf;
////	FormatMessage( 
////		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
////		FORMAT_MESSAGE_FROM_SYSTEM | 
////		FORMAT_MESSAGE_IGNORE_INSERTS,
////		NULL,
////		GetLastError(),
////		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
////		(LPTSTR) &lpMsgBuf,
////		0,
////		NULL
////	);
////	////LocalFree(lpMsgBuf);
////
////	return std::string((LPCTSTR)lpMsgBuf);
////}
//---------------------------------------------------------------------------
void CLog::vSetMaxFileSize(unsigned long int ulMaxFileSize) {
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
unsigned long int CLog::ulGetFileSize(const std::string &csFilePath) {
	HANDLE h = CreateFile(csFilePath.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL); 
	if (h == NULL) {
	    //vErrorMessageBox();
		CloseHandle(h);
		return 0;
	}
	
	unsigned long int ulFileSize = GetFileSize(h, NULL) / 1000000;  //������ ����� � ������ / 1000000
	if (ulFileSize == -1) {
		//vErrorMessageBox();
		CloseHandle(h);
		return 0;
	}
	CloseHandle(h);
	
	return ulFileSize;
}
//---------------------------------------------------------------------------