/**********************************************************************
*	����� CThread (CThread.h)
*
***********************************************************************/


#ifndef CThreadH
#define CThreadH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>


//---------------------------------------------------------------------------
class CThread {
	public:
		//typedef void (*ThreadFunc)( P );



	    CThread();
		~CThread();
		
		bool Run(/*ThreadFunc pfFunc*/);

		// Suspend - Suspends the thread (if one is active)
		void Suspend();

		// Resume - Resumes a previously suspended thread
		void Resume();

		// Terminate - Terminates the thread (if one is active).
		// Prefer another means of exiting the thread, as
		// calling Terminate() does not allow the thread to free
		// any resources it may hold
		void Terminate();
		void Kill();

		// IsThreadActive - Called in the context of another
		// (external) thread to test whether the thread is
		// currently running
		bool IsThreadActive() const;

		void ExitThread();
		bool ExitThreadAndWait(DWORD timeoutMS);
		bool IsExitEventSet();
		
		/*-----------------------------------------------------------*/
		//SetPriority and GetPriority
		//IsRunning	Returns true if the thread is running.
		//IsTerminated	Returns true if the thread is terminated.
		//IsSuspend
		
    private:
		//static DWORD WINAPI StartThread(void* pParam);

		// Handle to the created Thread
		HANDLE m_hThread;

		// ID of the created thread
		DWORD m_threadID;

		// ThreadFunc invoketion members
		//T*			m_pInstance;
		//ThreadFunc	m_pfFunc;
		//P			m_param;
		HANDLE m_hExitThreadEvent;
 
};
//---------------------------------------------------------------------------
#endif




/**********************************************************************
*	����� CThread (CThread.cpp)
*
***********************************************************************/


//---------------------------------------------------------------------------
static unsigned long int __stdcall DoExitableWork(void *pParam/* int */) {
	for (char c = 'a'; c <= 'z'; ++c) {
		for (int j = 0; j < 1000; ++j)  {
			std::cout << j << std::endl;
			//Sleep(200);

			/*if (CThread.IsExitEventSet())
				return;*/
		}
	}
	
	return 0;
}
//---------------------------------------------------------------------------
CThread::CThread() {
	m_hExitThreadEvent = NULL;
	m_hExitThreadEvent = ::CreateEvent( NULL, false, false, NULL );
}
//---------------------------------------------------------------------------
CThread::~CThread() {
	if (m_hExitThreadEvent)	{
		::CloseHandle( m_hExitThreadEvent );
		m_hExitThreadEvent = NULL;
	}

	if (IsThreadActive()) {
		Terminate();
	}
}
//--------------------------------------------------------------------------
bool CThread::Run(/*ThreadFunc pfFunc*/) {
	////m_pfFunc = pfFunc;
	////m_param = param;

	m_hThread = ::CreateThread(NULL, 0, DoExitableWork, 0, 0, &m_threadID);
	return (m_hThread != NULL);
}
//--------------------------------------------------------------------------
//Suspend - Suspends the thread (if one is active)
void CThread::Suspend() {
	::SuspendThread(m_hThread);
}
//--------------------------------------------------------------------------
//Resume - Resumes a previously suspended thread
void CThread::Resume() {
	int resumeCount = ::ResumeThread(m_hThread);
	while (resumeCount > 1) {
		resumeCount = ::ResumeThread(m_hThread);
	}
}
//--------------------------------------------------------------------------
//Terminate - Terminates the thread (if one is active).
//Prefer another means of exiting the thread, as
//calling Terminate() does not allow the thread to free
//any resources it may hold
void CThread::Terminate() {
    if (m_hThread) {
	    ::TerminateThread(m_hThread, 0);
	    ::CloseHandle(m_hThread);
        m_hThread = NULL;
    }
}
//--------------------------------------------------------------------------
bool CThread::IsThreadActive() const {
	return ((m_hThread != NULL) && (::WaitForSingleObject(m_hThread, 0) != WAIT_OBJECT_0));
}
//--------------------------------------------------------------------------	
void CThread::ExitThread() {
	::SetEvent( m_hExitThreadEvent );
}
//--------------------------------------------------------------------------
bool CThread::ExitThreadAndWait(DWORD timeoutMS) {
	// Set the event telling the thread to exit
	::SetEvent( m_hExitThreadEvent );

	// Wait for the thread to actually exit
	DWORD result = ::WaitForSingleObject( m_hThread, timeoutMS );

	// Cleanup handle
	::CloseHandle(m_hThread);
	m_hThread = NULL;

	return ( result == WAIT_OBJECT_0 );
}
//--------------------------------------------------------------------------
bool CThread::IsExitEventSet() {
	DWORD res = ::WaitForSingleObject( m_hExitThreadEvent, 0 );
	return ( res == WAIT_OBJECT_0 );
}
//--------------------------------------------------------------------------
		
		
		
		
		
		
		
		
		
		
		

/*
	static enum {DW_OK					= 0x00000000,
				 DW_ERROR				= 0xFFFFFFFF,
				 DW_UNDEFINED			= 0xFFFFFFFE,
				 DW_TIMEOUT_ELAPSED		= 0xFFFFFFFD,
				 DW_INFINITE			= INFINITE,
				 THREAD_CREATED			= 0,
				 THREAD_STOPPED			= 1,
				 THREAD_RUNNING			= 2,
				 THREAD_PAUSED			= 3,
				 THREAD_CONTINUING		= 4,
				 THREAD_PENDING			= 5,
				 THREAD_USER_ACTIVITY	= 6};
*/