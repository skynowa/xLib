/**********************************************************************
*	����� CComPort (CComPort.cpp)
*
***********************************************************************/


#include "CComPort.h"
//---------------------------------------------------------------------------
CComPort::CComPort(const std::string &sPortNum = "COM1") {	
	m_hComPort = INVALID_HANDLE_VALUE;
	m_sPortNum = sPortNum; 
}
//---------------------------------------------------------------------------
CComPort::~CComPort() {	
	bClose();
}
//--------------------------------------------------------------------------
//������� ����
bool CComPort::bOpen() {
	m_hComPort = CreateFile(m_sPortNum.c_str(), GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);
    if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	} else {	
		return true;	
	}
}
//--------------------------------------------------------------------------
//���������� ����
bool CComPort::bConfig() {
	DCB dcb;
	dcb.fOutxCtsFlow = false;                  //Disable CTS monitoring
	dcb.fOutxDsrFlow = false;				   //Disable DSR monitoring
	dcb.fDtrControl  = DTR_CONTROL_DISABLE;    //Disable DTR monitoring
	dcb.fOutX        = false;                  //Disable XON/XOFF for transmission
	dcb.fInX         = false;                  //Disable XON/XOFF for receiving
	dcb.fRtsControl  = RTS_CONTROL_DISABLE;    //Disable RTS (Ready To Send)

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout         = 20; 
	timeouts.ReadTotalTimeoutMultiplier  = 10;
	timeouts.ReadTotalTimeoutConstant    = 100;
	timeouts.WriteTotalTimeoutMultiplier = 10;
	timeouts.WriteTotalTimeoutConstant   = 100;

	if (SetCommTimeouts(m_hComPort, &timeouts) == false)	{
		//
	}

	bClearData();

	SetCommMask(m_hComPort, EV_DSR);
	
	ULONG lpEvtMask = 0;	
	WaitCommEvent(m_hComPort, &lpEvtMask, NULL);
	//CTest->OnRead();

	return false;
}
//--------------------------------------------------------------------------
//�������� ������ � �����
bool CComPort::bClearData() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}
  
	PurgeComm(m_hComPort, PURGE_RXCLEAR | PURGE_TXCLEAR); ///PurgeComm(m_hComPort, PURGE_TXCLEAR | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_RXABORT);
	
	DWORD dwErrors;
	ClearCommError(m_hComPort, &dwErrors, 0);

	return true;
}
//--------------------------------------------------------------------------
//��������� ������ � �����
std::string CComPort::bReadData(char *pszBuff, DWORD dwNumOfBytesToRead) {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}		

	Sleep(5L);

	DWORD dwNumOfBytesRead = 0;
	BOOL  bRes             = ReadFile(m_hComPort, pszBuff, dwNumOfBytesToRead/*cuiSendStrLen*/, &dwNumOfBytesRead, NULL); 
	if (bRes == false) {
		return "";
	}
	if (dwNumOfBytesRead != dwNumOfBytesToRead) {
		return "";
	}

	return std::string(pszBuff, dwNumOfBytesRead);
}
//--------------------------------------------------------------------------
//
int CComPort::iReadDataWaiting() {
	return 0;
}
//--------------------------------------------------------------------------
//�������� ������ � ����
bool CComPort::bWriteData(const char *pszBuff, DWORD dwNumOfBytesToWrite) {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

	DWORD dwNumOfBytesWritten = 0;
	if (WriteFile(m_hComPort, pszBuff, dwNumOfBytesToWrite, &dwNumOfBytesWritten, NULL) == false) {
		return false;
	}

	if (dwNumOfBytesWritten != dwNumOfBytesToWrite) {
		return false;
	}

	if (FlushFileBuffers(m_hComPort) == false) {
		return false;
	}
	
	return true;


	////OVERLAPPED osWrite   = {0};
	////DWORD      dwWritten = 0;
	////bool       bRes      = false;

	//////Issue write
	////if (!WriteFile(m_hComPort, lpBuf, dwToWrite, &dwWritten, NULL)) {
	////	if (GetLastError() != ERROR_IO_PENDING) {  //WriteFile failed, but it isn't delayed. Report error and abort.
	////		bRes = false;
	////	} else {
	////		//Write is pending
	////		if (GetOverlappedResult(m_hComPort, &osWrite, &dwWritten, TRUE) == false) {     
	////			bRes = false;
	////		} else {
	////			//Write operation completed successfully.
	////			bRes = true;
	////		}
	////	}
	////} else {
	////	//WriteFile completed immediately.
	////	bRes = true;
	////}
 //// 
	////return bRes;
}
//--------------------------------------------------------------------------
//������� ����
bool CComPort::bClose() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

    bool bRes = false; 
	if (CloseHandle(m_hComPort) == 0) {
		bRes = false; 
	} else {
		bRes = true; 
	}

	m_hComPort = INVALID_HANDLE_VALUE;

	return bRes;
}
//--------------------------------------------------------------------------
DWORD CComPort::dwInputBuffTest() {
	DWORD    dwErrors;
	_COMSTAT csStat;
	
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return 0;
	}
	
	if (ClearCommError(m_hComPort, &dwErrors, &csStat) == false) {
		return 0;
	}
	
	return csStat.cbInQue;
}
//-------------------------------------------------------------------------
//���������� ������ DTR
bool CComPort::bClearCLRDTR() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

	return EscapeCommFunction(m_hComPort, CLRDTR);
}
//-------------------------------------------------------------------------
//���������� ������ RTS
bool CComPort::bClearCLRRTS() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

	return EscapeCommFunction(m_hComPort, CLRRTS);
}
//-------------------------------------------------------------------------
//������������ ������ DTR
bool CComPort::bSetSETDTR() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

	return EscapeCommFunction(m_hComPort, SETDTR);
}
//-------------------------------------------------------------------------
//������������� ������ RTS
bool CComPort::bSetSETRTS() {
	if (m_hComPort == INVALID_HANDLE_VALUE) {
		return false;
	}

	return EscapeCommFunction(m_hComPort, SETRTS);
}
//-------------------------------------------------------------------------