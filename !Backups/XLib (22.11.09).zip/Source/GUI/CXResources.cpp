/****************************************************************************
* Class name:  CXResources
* Description: 
* File name:   CXResources.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.09.2009 9:44:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXResources.h>

#define RES_FILE_PATH <XLib/GUI/Resource.xrc.cpp> 
//---------------------------------------------------------------------------
//TODO: + �������������� ������ �����
CXResources::TSettingsMap CXResources::_m_mapResContent;
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bInit ()
/*static*/BOOL CXResources::bInit() {
	BOOL bRes = FALSE;

	#ifndef RES_FILE_PATH
		#error "XLib: [Please, define RES_FILE_PATH]" 
		
		return FALSE;
	#endif

	//�������� ���� � ����� ������� ���������
	#include RES_FILE_PATH

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sGetText (�� ID �������� ���� ��������)
/*static*/tstring CXResources::sGetText(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].sGetText();
}
//---------------------------------------------------------------------------
//TODO: + iGetLeft (�� ID �������� ���� ��������)
/*static*/INT CXResources::iGetLeft(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].iGetLeft();
}
//---------------------------------------------------------------------------
//TODO: + iGetTop (�� ID �������� ���� ��������)
/*static*/INT CXResources::iGetTop(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].iGetTop();
}
//---------------------------------------------------------------------------
//TODO: + iGetWidth (�� ID �������� ���� ��������)
/*static*/INT CXResources::iGetWidth(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].iGetWidth();
}
//---------------------------------------------------------------------------
//TODO: + iGetHeight (�� ID �������� ���� ��������)
/*static*/INT CXResources::iGetHeight(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].iGetHeight();
}
//---------------------------------------------------------------------------
//TODO: + ulGetStyle (�� ID �������� ���� ��������)
/*static*/ULONG CXResources::ulGetStyle(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].ulGetStyle();
} 
//---------------------------------------------------------------------------
//TODO: + ulGetStyleEx (�� ID �������� ���� ��������)
/*static*/ULONG CXResources::ulGetStyleEx(INT iID) {
	CHECK_RET(true == _m_mapResContent.empty(), 0);

	return _m_mapResContent[iID].ulGetStyleEx();
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXResources
CXResources::CXResources() {        
	/*DEBUG*/XASSERT(FALSE);
}
//---------------------------------------------------------------------------
//TODO: + ~CXResources
CXResources::~CXResources() {		 
	/*DEBUG*/XASSERT(FALSE);
}
//---------------------------------------------------------------------------
//TODO: + _bInitControl
/*static*/BOOL CXResources::_bInitControl(INT iID, const tstring &csText, INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulStyleEx) {
	XASSERT_RET(0 <  iID,     FALSE);
	XASSERT_RET(0 <= iLeft,   FALSE);
	XASSERT_RET(0 <= iTop,    FALSE);
	XASSERT_RET(0 <= iWidth,  FALSE);
	XASSERT_RET(0 <= iHeight, FALSE);

	_m_mapResContent[iID] = CXSettings(csText, iLeft, iTop, iWidth, iHeight, ulStyle, ulStyleEx);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRemoveControl
/*static*/BOOL CXResources::_bRemoveControl(INT iID) {
	XASSERT_RET(0 < iID, FALSE);

	TSettingsMap::const_iterator it;

	it = _m_mapResContent.find(iID);
	XASSERT_RET(_m_mapResContent.end() != it, FALSE);

	_m_mapResContent.erase(it);

	return TRUE;
}
//---------------------------------------------------------------------------