/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <process.h>

#include <XLib/Sync/CThread.h>
//---------------------------------------------------------------------------
CThread::CThread(BOOL bAutoDelete/* = FALSE*/) :
	_m_bAutoDelete (bAutoDelete),
	_m_hThread     (NULL),
	_m_ulID        (0),
	_m_iRes        (0),
	_m_pvParam     (0),
	_m_ptfStartAddress(0)
{
	if (FALSE == _m_ExitEvent.bCreate(NULL, FALSE, FALSE, NULL)) {
		return;
	}
}
//---------------------------------------------------------------------------
CThread::~CThread() {
	////if (TRUE == bIsActive()) {
	////	bKill();
	////}

	if (_m_hThread != NULL) {
		::CloseHandle(_m_hThread);
	}
}
//---------------------------------------------------------------------------
BOOL CThread::bCreate(pThreadFunc ptfStartAddr /*= 0*/, VOID *pvParam /*= 0*/, BOOL bSuspended /*= TRUE*/) {
	_m_ptfStartAddress = ptfStartAddr;
	_m_pvParam         = pvParam;
	_m_hThread         = (HANDLE)_beginthreadex(NULL, 0, _s_uiStartFunc, this, bSuspended == TRUE ? CREATE_SUSPENDED : 0, (UINT *)&_m_ulID);
	/*DEBUG*/XASSERT_RET(NULL != _m_hThread, FALSE);		

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetPriority
BOOL CThread::bSetPriority(INT iPriority) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriority(_m_hThread, iPriority);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iGetPriority
INT CThread::iGetPriority() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), THREAD_PRIORITY_ERROR_RETURN); 

	INT iRes = THREAD_PRIORITY_ERROR_RETURN;

	iRes = ::GetThreadPriority(_m_hThread);
	/*DEBUG*/XASSERT_RET(THREAD_PRIORITY_ERROR_RETURN != iRes, THREAD_PRIORITY_ERROR_RETURN);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetId
ULONG CThread::ulGetId() {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), 0); 

	ULONG ulRes = 0;

	ulRes = ::GetCurrentThreadId();
	/*DEBUG*/XASSERT_RET(0 != ulRes, 0);
	/*DEBUG*///TODO: - XASSERT_RET(static_cast<ULONG>(_m_uiID) == ulRes, 0);

	return ulRes;
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
UINT __stdcall CThread::_s_uiStartFunc(VOID *pvThis) {
	UINT uiRes = 0;

	if (0 == reinterpret_cast<CThread *>(pvThis)->_m_ptfStartAddress) {
		uiRes = reinterpret_cast<CThread *>(pvThis)->_m_iRes = reinterpret_cast<CThread *>(pvThis)->iExecute();
	} else {
		uiRes = reinterpret_cast<CThread *>(pvThis)->_m_ptfStartAddress(reinterpret_cast<CThread *>(pvThis)->_m_pvParam);
	}

	if (TRUE == reinterpret_cast<CThread *>(pvThis)->_m_bAutoDelete) {
		delete reinterpret_cast<CThread *>(pvThis);
	}

	return uiRes;
}
//---------------------------------------------------------------------------
/*virtual*/ INT CThread::iExecute() {
	return 0;
}
//---------------------------------------------------------------------------
//TODO: + bWait
BOOL CThread::bWait(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	ULONG ulRes = ::WaitForSingleObject(_m_hThread, ulTimeout);    //debug

	return (WAIT_OBJECT_0 == ulRes);
}
//---------------------------------------------------------------------------
//TODO: + bResume
BOOL CThread::bResume() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	ULONG ulResumeCount = (ULONG) -1;

	ulResumeCount = ::ResumeThread(_m_hThread);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulResumeCount, FALSE);

	while (ulResumeCount > 1) {
		ulResumeCount = ::ResumeThread(_m_hThread);
		/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulResumeCount, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSuspend
BOOL CThread::bSuspend() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	ULONG ulRes = (ULONG) -1;

	ulRes = ::SuspendThread(_m_hThread);
	/*DEBUG*/XASSERT_RET((ULONG) -1 != ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CThread::bExit() {
	return _m_ExitEvent.bSet();
}
//---------------------------------------------------------------------------
//TODO: + bKill
BOOL CThread::bKill() {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	BOOL bRes = FALSE;  

	bRes = ::TerminateThread(_m_hThread, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	bRes = ::CloseHandle(_m_hThread);	_m_hThread = NULL;
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsExited
BOOL CThread::bIsExited()	{
	ULONG ulRes = _m_ExitEvent.ulWaitForSingleObject(0);

	return WAIT_OBJECT_0 == ulRes;
}
//---------------------------------------------------------------------------






//---------------------------------------------------------------------------
//TODO: + bPostMessage
BOOL CThread::bPostMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread),  FALSE);
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(hHwnd),       FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSendMessage
BOOL CThread::bSendMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(hHwnd),      FALSE);

	::SendMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*///- not need 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPostThreadMessage
BOOL CThread::bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostThreadMessage(_m_ulID, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue
BOOL CThread::bMessageWaitQueue(INT iMsg, INT *piParam1, INT *piParam2) {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);
	/*DEBUG*/XASSERT_RET(0    <  iMsg,             FALSE);

	BOOL bRes   = - 1;
	MSG  msgMsg = {0};

	while (bRes = ::GetMessage(&msgMsg, NULL, 0, 0 )) {
		if (- 1 == bRes) {
			/*DEBUG*/XASSERT_RET(false, false);
			break;
		}

		if (iMsg == msgMsg.message) {
			if (NULL != piParam1) {
				*piParam1 = static_cast<INT>(msgMsg.lParam);
			}

			if (NULL != piParam2) {
				*piParam2 = static_cast<INT>(msgMsg.wParam);
			}

			break;
		}

		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return TRUE;
}
//---------------------------------------------------------------------------