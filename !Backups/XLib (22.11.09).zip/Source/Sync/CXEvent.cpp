/****************************************************************************
* Class name:  CXEvent
* Description: ������ � ��������
* File name:   CXEvent.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXEvent.h>

#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXEvent::CXEvent() 
	: _m_hEvent(NULL)
{
	
}
//---------------------------------------------------------------------------
CXEvent::~CXEvent() {
	/*DEBUG*/XASSERT(NULL != _m_hEvent);
	
	if (NULL != _m_hEvent) {
		BOOL bRes = FALSE;
		
		bRes = ::CloseHandle(_m_hEvent);	_m_hEvent = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXEvent::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, NULL);
    
    return _m_hEvent;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCTSTR pcszName) {
	_m_hEvent = ::CreateEvent(lpsaAttributes, bManualReset, bInitialState, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT(NULL != _m_hEvent);		//////////////////
	
	/*EVENT_MODIFY_STATE, EVENT_ALL_ACCESS, EVENT_MODIFY_STATE*/
	_m_hEvent = ::OpenEvent(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bPulse() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, FALSE);
	
	BOOL bRes = FALSE;

	bRes = ::PulseEvent(_m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bReset() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, FALSE);

	BOOL bRes = FALSE;

	bRes = ::ResetEvent(_m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bSet() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetEvent(_m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXEvent::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hEvent, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return ::WaitForSingleObject(_m_hEvent, ulTimeout);
}
//---------------------------------------------------------------------------