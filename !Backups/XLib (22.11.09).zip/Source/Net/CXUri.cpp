/****************************************************************************
* Class name:  CXUri
* Description: ��������������� ������������� �������
* File name:   CXUri.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.11.2009 12:41:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CXUri.h>

const std::string CXUri::RESERVED_PATH     = "?#";
const std::string CXUri::RESERVED_QUERY    = "#";
const std::string CXUri::RESERVED_FRAGMENT = "";
const std::string CXUri::ILLEGAL           = "%<>{}|\\\"^`";

/****************************************************************************
* public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXUri
CXUri::CXUri() :
	_m_sScheme   (""),	
	_m_sAuthority(""), 
	_m_sUserInfo (""),	
	_m_sHost     (""),
	_m_usPort    (0), 
	_m_sPath     (""),        
	_m_sQuery    (""),   
	_m_sFragment ("")
{
	
}
//---------------------------------------------------------------------------
//TODO: + CXUri
CXUri::CXUri(const std::string &csUri) :
	_m_sScheme   (""),	
	_m_sAuthority(""), 
	_m_sUserInfo (""),	
	_m_sHost     (""),
	_m_usPort    (0), 
	_m_sPath     (""),        
	_m_sQuery    (""),   
	_m_sFragment ("")
{
	BOOL bRes = FALSE;
	
	bRes = _bParse(csUri);
	/*DEBUG*/XASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXUri 
CXUri::~CXUri() {
	
}
//---------------------------------------------------------------------------
//TODO: - sGetScheme
std::string CXUri::sGetScheme() {
	return _m_sScheme;	
}
//---------------------------------------------------------------------------
//TODO: + sGetAuthority
std::string CXUri::sGetAuthority() {
	return _m_sAuthority; 
}
//---------------------------------------------------------------------------
//TODO: + sGetUserInfo
std::string CXUri::sGetUserInfo() {
	return _m_sUserInfo;	
}
//---------------------------------------------------------------------------
//TODO: + sGetHost
std::string CXUri::sGetHost() {
	return _m_sHost;
}
//---------------------------------------------------------------------------
//TODO: + usGetPort
USHORT CXUri::usGetPort() {
	return _m_usPort;
}
//---------------------------------------------------------------------------
//TODO: + sGetPath
std::string CXUri::sGetPath() {
	return _m_sPath;        
}
//---------------------------------------------------------------------------
//TODO: + sGetQuery
std::string CXUri::sGetQuery() {
	return _m_sQuery;   
}
//---------------------------------------------------------------------------
//TODO: + sGetFragment
std::string CXUri::sGetFragment() {
	return _m_sFragment;
}
//---------------------------------------------------------------------------
//TODO: + bClear ()
BOOL CXUri::bClear() {
	BOOL bRes = FALSE;

	_m_sScheme.clear();	
	_m_sAuthority.clear(); 
	_m_sUserInfo.clear();	
	_m_sHost.clear();
	_m_usPort = 0;
	_m_sPath.clear();        
	_m_sQuery.clear();   
	_m_sFragment.clear();

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: 
//void URI::encode(const std::string& str, const std::string& reserved, std::string& encodedStr)
/*static*/ std::string CXUri::sEncode(const std::string &csUri) {
	std::string sRes;
	
	for (std::string::const_iterator it = csUri.begin(); it != csUri.end(); ++ it) {
		char c = *it;

		if (
			(c >= 'a' && c <= 'z') || 
			(c >= 'A' && c <= 'Z') || 
			(c >= '0' && c <= '9') || 
			c == '-' || 
			c == '_' || 
			c == '.' || 
			c == '~')        
		{
			sRes += c;
		}
		/*
		RESERVED_PATH     = "?#";
		RESERVED_QUERY    = "#";
		RESERVED_FRAGMENT = "";
		ILLEGAL           = "%<>{}|\\\"^`";
		*/
		else if (c <= 0x20 || c >= 0x7F || ILLEGAL.find(c) != std::string::npos /*|| reserved.find(c) != std::string::npos*/) {
			//� -> %FF
			sRes += sFormatStrA("%%%02X", (UINT)(UCHAR)c);
		} 
		else {
			sRes += c;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO:
//void URI::decode(const std::string& str, std::string& decodedStr)
/*static*/ std::string CXUri::sDecode(const std::string &csUri) {
	std::string sRes;

	std::string::const_iterator it  = csUri.begin();
	std::string::const_iterator end = csUri.end();

	while (it != end) {
		char c = *it ++;
		
		if (c == '%') {
			if (it == end) {
				//throw SyntaxException("URI encoding: no hex digit following percent sign", csUri);
				/*DEBUG*/XASSERT_RET(FALSE, "");
			}
			
			char hi = *it ++;
			
			if (it == end) {
				//throw SyntaxException("URI encoding: two hex digits must follow percent sign", csUri);
				/*DEBUG*/XASSERT_RET(FALSE, "");
			}
			
			char lo = *it ++;
			
			if (       hi >= '0' && hi <= '9') {
				c = hi - '0';
			} else if (hi >= 'A' && hi <= 'F') {
				c = hi - 'A' + 10;
			} else if (hi >= 'a' && hi <= 'f') {
				c = hi - 'a' + 10;
			} else { 
				//throw SyntaxException("URI encoding: not a hex digit");
				/*DEBUG*/XASSERT_RET(FALSE, "");
			}
			
			c *= 16;
			
			if (       lo >= '0' && lo <= '9') {
				c += lo - '0';
			} else if (lo >= 'A' && lo <= 'F') {
				c += lo - 'A' + 10;
			} else if (lo >= 'a' && lo <= 'f') {
				c += lo - 'a' + 10;
			} else {
				//throw SyntaxException("URI encoding: not a hex digit");
				/*DEBUG*/XASSERT_RET(FALSE, "");
			}
		}

		sRes += c;
	}

	return sRes;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - bParse (������ URI)
/*
URI = scheme ":" hier-part [ "?" query ] [ "#" fragment ]

foo://userinfo@example.com:8042/over/there?name=ferret#nose
\_/   \_______________________/\_________/ \_________/ \__/
|                |                |            |       |
scheme        authority           path        query   fragment
*/

/*
http   : //ru.wikipedia.org/wiki/URI
ftp    : //ftp.is.co.za/rfc/rfc1808.txt
file   : //C:\UserName.HostName\Projects\Wikipedia_Articles\URI.xml
ldap   : //[2001:db8::7]/c=GB                                       ? objectClass?one

mailto : John.Doe@example.com
sip    : 911@pbx.mycompany.com
news   : comp.infosystems.www.servers.unix
data   : text/plain;charset=iso-8859-7,%be%fg%be
tel    : +1-816-555-1212
telnet : //192.0.2.16:80/
*/
BOOL CXUri::_bParse(const std::string &csUri) {
	BOOL bRes = FALSE;

	//Normilize();

	bRes = bClear();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//[scheme] - [foo]
	//[INPUT]     - foo://userinfo@example.com:8042/over/there?name=ferret#nose
	size_t uiSchemeStart = 0;
	size_t uiSchemeEnd   = csUri.find_first_of(xCOLON);
	/*DEBUG*/XASSERT_RET(std::string::npos       != uiSchemeEnd, FALSE);
	/*DEBUG*/XASSERT_RET(7/*SCHEME_MAX_SIZE + 1*/ > uiSchemeEnd, FALSE);

	_m_sScheme = sCut(csUri, uiSchemeStart, uiSchemeEnd);

	//-------------------------------------
	//[authority] - [example.com:8042]
	//[INPUT]     - foo://userinfo@example.com:8042/over/there?name=ferret#nose
	size_t uiAuthorityStart = uiSchemeEnd + 1/*":"*/; 										   

	//���� ����� [:] ���� [//] - ����������
	size_t uiSlashCount = 0;
	while ('/' == csUri.at(uiAuthorityStart + uiSlashCount)) {
		uiSlashCount ++;
	}

	size_t uiAuthorityEnd = csUri.find_first_of("/?#", uiAuthorityStart + uiSlashCount); //or by the end

	if (std::string::npos == uiAuthorityEnd) {
		uiAuthorityEnd = csUri.size();
	}	

	_m_sAuthority = sCut(csUri, uiAuthorityStart /*+ uiSlashCount*/, uiAuthorityEnd);

	//-------------------------------------
	//[_m_sUserInfo] - [userinfo]
	//[INPUT]        - userinfo@example.com:8042
	size_t uiUserInfoStart = 0 + uiSlashCount;
	size_t uiUserInfoEnd   = _m_sAuthority.find_first_of("@", uiUserInfoStart);
	
	if (std::string::npos != uiUserInfoEnd) {
	    _m_sUserInfo = sCut(_m_sAuthority, uiUserInfoStart, uiUserInfoEnd);
	}	

	//-------------------------------------
	//[_m_sHost] - [example.com]
	//[INPUT]    -  userinfo@example.com:8042
	size_t uiHostStart = _m_sAuthority.find_first_of("@");
	size_t uiHostEnd   = _m_sAuthority.find_first_of(":");

	if (std::string::npos != uiHostStart) {
		//���� ��� �����
		if (std::string::npos == uiHostEnd) {
			uiHostEnd == _m_sAuthority.size();
		}		
		
		_m_sHost = sCut(_m_sAuthority, uiHostStart + 1/*"@"*/, uiHostEnd);
	}

	//-------------------------------------
	//[_sPort] - [8042]
	//[INPUT]  -  userinfo@example.com:8042
	size_t uiPortStart = _m_sAuthority.find_first_of(":");
	size_t uiPortEnd   = _m_sAuthority.size();

	if (std::string::npos != uiPortStart) {
		std::string sPort = sCut(_m_sAuthority, uiPortStart + 1/*":"*/, uiPortEnd);
		_m_usPort = lexical_cast<USHORT>(sPort);
	}	
	if (0 == _m_usPort) {
		_m_usPort = _usGetAssignPort();
	}

	//-------------------------------------
	//[_m_sHost] - [example.com] - ������ ������
	//[INPUT]    -  userinfo@example.com:8042
	size_t uiAuthorityChars = _m_sAuthority.find_first_of("@:");

	//���� � Authority ��� "@:" - _m_sHost ��� Authority ��� "//"
	if (std::string::npos == uiAuthorityChars) {
		_m_sHost = sTrimChar(_m_sAuthority, '/');
	}

	//-------------------------------------
	//[_m_sPath] - [/over/there?]
	//[INPUT]     - foo://userinfo@example.com:8042/over/there?name=ferret#nose
	size_t uiPathStart = uiAuthorityEnd; 										   
	size_t uiPathEnd   = csUri.find_first_of("?#", uiPathStart);  //or by the end
	
	if (std::string::npos == uiPathEnd) {
		uiPathEnd = csUri.size();
	}

	_m_sPath = sCut(csUri, uiPathStart, uiPathEnd);

	//-------------------------------------
	//[_m_sQuery] - [name=ferret]
	//[INPUT]     - foo://userinfo@example.com:8042/over/there?name=ferret#nose
	size_t uiQueryStart = uiPathEnd; 										   
	size_t uiQueryEnd   = csUri.find_first_of("#", uiQueryStart);

	if (std::string::npos == uiQueryEnd) {
		uiQueryEnd = csUri.size();
	}

	_m_sQuery = sCut(csUri, uiQueryStart + 1/*"?"*/, uiQueryEnd);

	//-------------------------------------
	//[_m_sFragment] - [nose]
	//[INPUT]     - foo://userinfo@example.com:8042/over/there?name=ferret#nose
	size_t uiFragmentStart = uiQueryEnd + std::string("#").size(); 	  									   
	size_t uiFragmentEnd   = csUri.size();						//by the end

	_m_sFragment = sCut(csUri, uiFragmentStart, uiFragmentEnd);


	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - _bNormilize ()
BOOL CXUri::_bNormilize(const std::string &csUri) {
	BOOL bRes = FALSE;

	 //trim, lowcase(_m_sScheme)

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - _usGetAssocPort ()
USHORT CXUri::_usGetAssignPort() const {
	if (       "ftp"    == _m_sScheme) {
		return 21;
	} else if ("ssh"    == _m_sScheme) {
		return 22;
	} else if ("telnet" == _m_sScheme) {
		return 23;
	} else if ("gopher" == _m_sScheme) {
		return 70;
	} else if ("http"   == _m_sScheme) {
		return 80;
	} else if ("nntp"   == _m_sScheme) {
		return 119;
	} else if ("ldap"   == _m_sScheme) {
		return 389;
	} else if ("https"  == _m_sScheme) {
		return 443;
	} else {
		return 0;
	}
}
//---------------------------------------------------------------------------