/****************************************************************************
* Class name:  CXIni
* Description: ������ � ini-�������
* File name:   CXIni.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.04.2009 12:10:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXIni.h>

#include <iostream>
#include <stdio.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXStdioFile.h>
//-------------------------------------------------------------------------
//TODO: + CXIni ()
CXIni::CXIni(const tstring &csFileName, const tstring &csDefaultContent) :
	_m_sFilePath(_T(""))
{
	/*DEBUG*/XASSERT(false == csFileName.empty());        
	
	_m_sFilePath = CXPath::sChangeFullFileName(CXPath::sExePath(), csFileName);
	
	//���� INI-����� ��� - �������	
	if (FALSE == CXStdioFile::bIsExists(_m_sFilePath)) {	//????????????
		if (FALSE == bCreateDefaultIni(_m_sFilePath.c_str(), csDefaultContent)) {
			return;
		}
	}
}
//-------------------------------------------------------------------------
//TODO: + ~CXIni ()
CXIni::~CXIni() {

}
//-------------------------------------------------------------------------
//TODO: + bCreateDefaultIni (������� ���� ��-���������)
BOOL CXIni::bCreateDefaultIni(const tstring &csFilePath, const tstring &csContent) {
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	
	BOOL bRes = FALSE;
	INT  iRes = CXStdioFile::etError;

	CXStdioFile sfFile;

	bRes = sfFile.bOpen(csFilePath, _T("w"));
	CHECK_RET(FALSE == bRes, FALSE);

	iRes = sfFile.iFprintf(csContent.c_str());
	CHECK_RET(FALSE == CXStdioFile::etError, FALSE);

	return TRUE;
}
//-------------------------------------------------------------------------
//TODO: + sReadString (������ �������� �����)
tstring CXIni::sReadString(const tstring &csSection, const tstring &csKey, const tstring &csDefaultValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(),                 tstring());
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), tstring());
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	tstring sRes  = _T("");
	ULONG   ulRes = 0;

	sRes.resize(_ms_ciLineSize);
	
	ulRes = ::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), csDefaultValue.c_str(), &sRes[0], sRes.size(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, _T(""));

	sRes.resize(ulRes);
	
	return sRes;
}
//-------------------------------------------------------------------------
//TODO: + bWriteString (����� �������� �����)
BOOL CXIni::bWriteString(const tstring &csSection, const tstring &csKey, const tstring &csValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(),                 FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), FALSE);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	BOOL bRes = FALSE;

	bRes = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), csValue.c_str(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//-------------------------------------------------------------------------
//TODO: iReadInteger ()
INT CXIni::iReadInteger(const tstring &csSection, const tstring &csKey, INT iDefaultValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), 0);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), 0);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	INT iRes = 0;
	
	iRes = ::GetPrivateProfileInt(csSection.c_str(), csKey.c_str(), iDefaultValue, _m_sFilePath.c_str());
	/*DEBUG*///not need

	return iRes;
}
//-------------------------------------------------------------------------
//TODO: bWriteInteger ()
BOOL CXIni::bWriteInteger(const tstring &csSection, const tstring &csKey, INT iValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), FALSE);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	ULONG ulRes = 0;

	ulRes = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), lexical_cast(iValue).c_str(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, FALSE);

	return TRUE; 
}
//-------------------------------------------------------------------------
//TODO: dReadFloat ()
DOUBLE CXIni::dReadFloat(const tstring &csSection, const tstring &csKey, DOUBLE dDefaultValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), 0.0);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), 0.0);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	DOUBLE  dRes      = 0.0;
	tstring sRes      = _T("");
	ULONG   ulRes     = 0;

	sRes.resize(_ms_ciLineSize);

	ulRes = ::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), lexical_cast(dDefaultValue).c_str(), &sRes[0], sRes.size(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, 0.0);

	//dRes = atof(szResult);
	dRes = lexical_cast<DOUBLE>(sRes);

	return dRes;
}
//-------------------------------------------------------------------------
//TODO: bWriteFloat ()
BOOL CXIni::bWriteFloat(const tstring &csSection, const tstring &csKey, FLOAT fValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), FALSE);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	ULONG ulRes = 0;

	ulRes = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), lexical_cast(fValue).c_str(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, FALSE);

	return TRUE;	
}
//-------------------------------------------------------------------------
//TODO: bReadBoolean ()
BOOL CXIni::bReadBoolean(const tstring &csSection, const tstring &csKey, BOOL bDefaultValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), FALSE);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	BOOL    bRes          = FALSE;
	tstring sRes          = _T("");
	tstring sDefaultValue = _T("");
	ULONG   ulRes         = 0;

	////TCHAR  szDefault[_ms_ciLineSize + 1] = {0};
	////::wsprintf(szDefault, _T("%s"), bDefaultValue ? _T("True") : _T("False"));

	sDefaultValue = bDefaultValue ? _T("True") : _T("False");
	sRes.resize(_ms_ciLineSize);

	ulRes = ::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), sDefaultValue.c_str(), &sRes[0], sRes.size(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, FALSE);

	//TODO: ���� ������ ������
	////////////////////bRes = (0 == ::lstrcmp(szResult, _T("True")) || 0 == ::lstrcmp(szResult, _T("true"))) ? true : false;	//lowcase uppercase
	bRes = bCompareNoCase(sRes, _T("True"));
	////bRes = bCompareNoCase(sRes, "False");

	return bRes;
}
//-------------------------------------------------------------------------
//TODO: bWriteBoolean ()
BOOL CXIni::bWriteBoolean(const tstring &csSection, const tstring &csKey, BOOL bBoolValue) {
	/*DEBUG*/XASSERT_RET(false == _m_sFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == CXStdioFile::bIsExists(_m_sFilePath), FALSE);
	/*DEBUG*///csSection - not need
	/*DEBUG*///csKey     - not need

	//TCHAR szBuff[_ms_ciLineSize + 1] = {0};
	////::wsprintf(szBuff, _T("%s"), bBoolValue ? _T("True") : _T("False"));

	ULONG   ulRes         = 0;
	tstring sDefaultValue = _T("");

	sDefaultValue = bBoolValue ? _T("True") : _T("False");

	ulRes = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), sDefaultValue.c_str(), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(0 != ulRes, FALSE);

	return TRUE;	
}
//-------------------------------------------------------------------------





















//-------------------------------------------------------------------------
//TODO: + bClearSection (������� ������)
BOOL CXIni::bClearSection(const tstring &csSection) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	BOOL bRes = FALSE;
	
	bRes = ::WritePrivateProfileSection(csSection.c_str(), _T(""), _m_sFilePath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//-------------------------------------------------------------------------
//TODO: - bReadSectionsNames () 
BOOL CXIni::bReadSectionsNames() {	
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));

	TCHAR szBuff[1024 + 1] = {0};
	
	::GetPrivateProfileSectionNames(szBuff, 1024, _m_sFilePath.c_str());
	//"SectionName1"0"SectionName2"0"SectionName3"
	::MessageBox(0, szBuff, _T(""), MB_OK);

	return TRUE;
}
//-------------------------------------------------------------------------
//TODO: - bReadSectionKeysAndValues ()
BOOL CXIni::bReadSectionKeysAndValues(const tstring &csSection) { 
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	TCHAR szBuff[1024 + 1] = {0};
	
	::GetPrivateProfileSection(csSection.c_str(), szBuff, 1024, _m_sFilePath.c_str());
	/*DEBUG*/

	//"Key1=xxx1"0"Key2=xxx2"0"Key2=xxx2"	
	::MessageBox(0, szBuff, _T(""), MB_OK);

	return TRUE;
}
//-------------------------------------------------------------------------
//TODO: + ulSectionSize (������ ������)
ULONG CXIni::ulSectionSize(const tstring &csSection) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	ULONG      ulRes                 = 0; 
	CONST UINT uiBuffLen             = _ms_ciLinesPerSection * _ms_ciLineSize;
	TCHAR      szBuff[uiBuffLen + 1] = {0};
	
	::GetPrivateProfileSection(csSection.c_str(), szBuff, uiBuffLen, _m_sFilePath.c_str());
	/*DEBUG*/
	//"Key1=xxx1"0"Key2=xxx2"0"Key2=xxx2"
	
	//���� ������ ������
	if (_T('\0') == szBuff[0]) {
		return 0;
	} 
	
	//������ �� ������
	for (INT i = 0; i < uiBuffLen; i ++) {
		if (_T('\0') == szBuff[i]) {
			ulRes ++;
			
			//����� ������ '\0\0'
			if (_T('\0') == szBuff[i + 1]) {
				break;
			}				
		}
	}	
	
	return ulRes;
}
//-------------------------------------------------------------------------

/*
Free - ������� ������ TIniFile 
FileName - ���������� ��� �����, � ������� ������ ������ TIniFile 
DeleteKey - ������� ���� � ������� 
EraseSection - ������� ������ 
ReadInteger - ��������� �� ����� ������������� ������ 
ReadString - ��������� �� ����� ��������� ������ 
ReadBool - ��������� �� ����� ���������� (true, false) ������ 
WriteBool - ���������� � ���� ���������� ������ 
WriteString - ���������� � ���� ��������� ������ 
WriteInteger - ���������� � ���� ������������� ������ 
ReadSection - ��������� ����� ��������������� � ��������� ������� INI - ����� 
ReadSections - ��������� ��� ����� �������� 
ReadSectionValues - ��������� �� ��������� ������� ��� ����� 
ReadBinaryStream - ��������� ����� �� ����� 
WriteBinaryStream - �����
*/

/*
GetPrivateProfileInt
GetPrivateProfileSection
GetPrivateProfileSectionNames
GetPrivateProfileString
GetPrivateProfileStruct
GetProfileInt
GetProfileSection
GetProfileString
WritePrivateProfileSection
WritePrivateProfileString
WritePrivateProfileStruct
WriteProfileSection
WriteProfileString
*/