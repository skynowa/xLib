/****************************************************************************
* Class name:  CXStatusBar
* Description: ������ ���������
* File name:   CXStatusBar.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     26.07.2009 23:49:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXStatusBar.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXStatusBar::CXStatusBar() :
    _m_iDefaultSize                  (0),
	m_iNumParts                      (0)

{
	::ZeroMemory(&m_iPartsWidths[0], sizeof(m_iPartsWidths));
	
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXSTATUSBAR_CONTROL_CLASS;
	_m_ulStyle        = CXSTATUSBAR_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXSTATUSBAR_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXSTATUSBAR_DEFAULT_WIDTH;
	_m_iHeight        = CXSTATUSBAR_DEFAULT_HEIGHT;
	
	_m_iDefaultSize   = - 1;
	
	//TODO: bInitCommonControls
	bInitCommonControls(ICC_BAR_CLASSES);
}
//---------------------------------------------------------------------------
CXStatusBar::~CXStatusBar() {
	LOG();
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetSimple(BOOL Simple) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	lSendMessage(SB_SIMPLE, (WPARAM)Simple, 0);
	
	return TRUE;
}
//---------------------------------------------------------------------------
INT CXStatusBar::Height() {
	RECT rect = GetRect();
	
	return rect.bottom - rect.top;
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetMinHeight(INT iHeight) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)lSendMessage(SB_SETMINHEIGHT, (WPARAM)iHeight, (LPARAM)0);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(INT nPart, HICON hIcon) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)lSendMessage(SB_SETICON, (WPARAM)nPart, (LPARAM)hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(INT PartIndex, INT IdIcon) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return SetIcon(PartIndex, hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetText(INT PartIndex, const std::string &csPartText) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)lSendMessage(SB_SETTEXT, PartIndex, (LPARAM)csPartText.c_str());
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetSize(INT PartIndex, INT Size) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	if (PartIndex >= m_iNumParts) {
		return FALSE;
	}
	m_iPartsWidths[PartIndex] = Size;

	return (BOOL)lSendMessage(SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart() {
	return AddPart(_m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const std::string &csPartText) {
	return AddPart(csPartText, _m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const std::string &csPartText, HICON hIcon) {
	return AddPart(csPartText, hIcon, _m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const std::string &csPartText, INT IdIcon) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);
	
	return AddPart(csPartText, hIcon);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(INT Size) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	m_iPartsWidths[m_iNumParts] = 0;
	for (INT Cnt = 0; Cnt < m_iNumParts; Cnt ++) {
		m_iPartsWidths[m_iNumParts] += m_iPartsWidths[Cnt];
	}
	m_iPartsWidths[m_iNumParts] += Size;
	m_iNumParts ++;
	if (!lSendMessage(SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths)) {
		return  - 1;
	}
	
	return m_iNumParts - 1;
}
//---------------------------------------------------------------------------
////////INT CXStatusBar::AddPart(const std::string &csPartText, INT Size) {
////////	INT Index = - 1;
////////	Index = AddPart(Size);
////////	if (Index < 0) {
////////		return Index;
////////	}
////////	SetText(m_iNumParts - 1, csPartText);
////////	
////////	return Index;
////////}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const std::string &csPartText, HICON hIcon, INT Size) {
	INT Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);
	SetText(m_iNumParts - 1, csPartText);
	
	return Index;
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const std::string &csPartText, INT IdIcon, INT Size) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return AddPart(csPartText, hIcon, Size);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(HICON hIcon, INT Size) {
	INT Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);

	return Index;
}
//---------------------------------------------------------------------------