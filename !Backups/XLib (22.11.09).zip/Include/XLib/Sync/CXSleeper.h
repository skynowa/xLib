/****************************************************************************
* Class name:  CXSleeper
* Description: ������ ::Sleep()
* File name:   CXSleeper.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.07.2009 12:54:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXSleeperH
#define CXSleeperH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXEvent.h>
//---------------------------------------------------------------------------
class CXSleeper : public CXNonCopyable {
	public:
         	   CXSleeper();
			  ~CXSleeper();
		BOOL   bSleep   (ULONG ulwMilliseconds = 1000);

	private:
		CXEvent _m_objEvent; 
};
//---------------------------------------------------------------------------
#endif