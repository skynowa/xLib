/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CThreadH
#define XLib_Sync_CThreadH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXEvent.h>
//---------------------------------------------------------------------------
class CThread : public CXNonCopyable {
	public:
		//��������� ������
		class CPriority {
			static const INT tpTimeCritical = THREAD_PRIORITY_TIME_CRITICAL;
			static const INT tpHighest      = THREAD_PRIORITY_HIGHEST;
			static const INT tpAboveNormal  = THREAD_PRIORITY_ABOVE_NORMAL;
			static const INT tpNormal       = THREAD_PRIORITY_NORMAL;
			static const INT tpBelowNormal  = THREAD_PRIORITY_BELOW_NORMAL;
			static const INT tpLowest       = THREAD_PRIORITY_LOWEST;
			static const INT tpIdle         = THREAD_PRIORITY_IDLE;
		};

		typedef INT      (* pThreadFunc)(VOID *);

			     CThread (BOOL bAutoDelete = FALSE);
		virtual ~CThread ();

		BOOL bCreate     (pThreadFunc ptfStartAddr = 0, VOID *pvParam = 0, BOOL bSuspended = FALSE);

		//���������
		BOOL  bSetPriority      (INT iPriority) const;
		INT   iGetPriority      () const; 
		
		ULONG ulGetId           ();

		BOOL bWait       (ULONG ulTiomeout = 0);
		BOOL bResume     () const;
		BOOL bSuspend    () const;
		BOOL bExit       ();
		BOOL bKill       ();
		BOOL bIsExited   ();



		BOOL  bPostMessage      (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL  bSendMessage      (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL  bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const;

		//�������� ��������� c ����������� �� ������� ������
		BOOL  bMessageWaitQueue (INT iMsg, INT *piParam1, INT *piParam2);

	protected:
		virtual INT iExecute();
		
	private:
		pThreadFunc   _m_ptfStartAddress;
		BOOL          _m_bAutoDelete;
		INT           _m_iRes;
		VOID         *_m_pvParam;
		HANDLE        _m_hThread;
		ULONG         _m_ulID;
		
		static UINT __stdcall _s_uiStartFunc(VOID *);

		CXEvent       _m_ExitEvent;

};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CThreadH