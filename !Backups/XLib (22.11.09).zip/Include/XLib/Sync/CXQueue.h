/****************************************************************************
* Class name:  CXEvent
* Description: �������
* File name:   CXQueue.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXQueueH
#define XLib_Sync_CXQueueH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include "CmnHdr.h"     /* See Appendix A. */
//---------------------------------------------------------------------------
class CXQueue : public CXNonCopyable {
	public:
		struct ELEMENT {
			INT m_iThreadNum;
			INT m_iRequestNum;
			// Other element data should go here
		};
		typedef ELEMENT *PELEMENT;

	             CXQueue(INT nMaxElements);
	            ~CXQueue();

		BOOL     bAppend(PELEMENT pElement, ULONG dwMilliseconds);
		BOOL     bRemove(PELEMENT pElement, ULONG dwMilliseconds);

	private:
		PELEMENT _m_pElements;			//Array of elements to be processed
		INT      _m_nMaxElements;		//Maximum # of elements in the array
		HANDLE   _m_hSyncArrary[2];		//Mutex & semaphore handles
		HANDLE   &_m_hMutex;			//Reference to _m_hSyncArrary[0]
		HANDLE   &_m_hSemaphore;		//Reference to _m_hSyncArrary[1]
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXQueueH