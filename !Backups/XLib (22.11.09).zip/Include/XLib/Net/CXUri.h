/****************************************************************************
* Class name:  CXUri
* Description: ��������������� ������������� ������� (RFC 3986)
* File name:   CXUri.h
* Compilers:   Visual C++ 2008
* String type: Ansi (!!!!!)
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.11.2009 12:41:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Net_CXUriH
#define XLib_Net_CXUriH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXString.h>
//---------------------------------------------------------------------------
class CXUri {
	public:
				          CXUri          ();
	   explicit           CXUri          (const std::string &csUri);
				         ~CXUri          ();

	   std::string        sGetScheme     ();	
	   std::string        sGetAuthority  (); 
	   std::string        sGetUserInfo   ();	
	   std::string        sGetHost       ();
	   USHORT             usGetPort      ();
	   std::string        sGetPath       ();        
	   std::string        sGetQuery      ();   
	   std::string        sGetFragment   ();

	   static std::string sEncode        (const std::string &csUri);
	   static std::string sDecode        (const std::string &csUri);

	   BOOL               bClear         ();


	
	private:
	   std::string _m_sScheme;	
	   std::string _m_sAuthority; 
	   std::string _m_sUserInfo;	
	   std::string _m_sHost;
	   USHORT      _m_usPort;
	   std::string _m_sPath;        
	   std::string _m_sQuery;   
	   std::string _m_sFragment;

	   static const std::string RESERVED_PATH;
	   static const std::string RESERVED_QUERY;
	   static const std::string RESERVED_FRAGMENT;
	   static const std::string ILLEGAL;

	   BOOL        _bParse               (const std::string &csUri);
	   BOOL        _bNormilize           (const std::string &csUri); 


	   USHORT      _usGetAssignPort       () const;



};
//---------------------------------------------------------------------------
#endif	//XLib_Net_CXUriH