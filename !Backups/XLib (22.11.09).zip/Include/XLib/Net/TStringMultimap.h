#ifndef TStringMultiMapH 
#define TStringMultiMapH 
//---------------------------------------------------------------------------
struct CompareNoCase
{
	bool operator () (const tstring &csStr1, const tstring &csStr2) const 
	{
		bool bRes = ::lstrcmpi(csStr1.c_str(), csStr2.c_str()) < 0;

		return bRes;
	}
};

typedef std::multimap<tstring, tstring, CompareNoCase> TStringMultiMap;
//---------------------------------------------------------------------------
#endif