/****************************************************************************
* Class name:  CXDll
* Description: DLL
* File name:   CXDll.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXDllH
#define XLib_Fso_CXDllH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXDll : public CXNonCopyable {
	public:
		        CXDll           ();
		       ~CXDll           ();

		BOOL    bIsLoaded       ();
		BOOL    bLoad           (LPCTSTR pszDllPath);
		FARPROC fpGetProcAddress(LPCSTR  pszProcName/*ANSI*/);
		BOOL    bFree           ();

	private:
		HMODULE _m_hDLL;
};
//---------------------------------------------------------------------------
#endif //XLib_Fso_CXDllH