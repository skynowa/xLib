/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (tstring, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef XLib_CXStringH
#define XLib_CXStringH  
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator> 
//---------------------------------------------------------------------------


/****************************************************************************
*    ������ <--> �����
*
*****************************************************************************/

template <typename T> 
tstring                       lexical_cast     (T const &cValueT) {		
													    tostringstream ossStream;	
														ossStream.exceptions(/*tostringstream::eofbit |*/ tostringstream::failbit | tostringstream::badbit);

														try {
															ossStream << cValueT;
														} catch (tostringstream::failure e) {
															/*DEBUG*/XASSERT_RET(FALSE, tstring());
														}
												
														return ossStream.str();
												   };		
template<typename T> 
T                             lexical_cast      (const tstring &csStr) {
														tistringstream issStream(csStr);
														issStream.exceptions(/*tostringstream::eofbit |*/ tostringstream::failbit | tostringstream::badbit);

														T ValueT;
														try {
															issStream >> ValueT;
														} catch (tostringstream::failure e) {
															/*DEBUG*/XASSERT_RET(FALSE, T());
														}

														return ValueT;
												   };	
BOOL                          bStrToUCHAR      (const tstring &csStr, UCHAR *pucBuff, UINT uiBuffLen);	
tstring                       sUCHARToStr      (UCHAR *pucBuff, UINT uiBuffLen);

tstring                       sTrimChar        (const tstring &csStr, TCHAR chChar); 
tstring                       sTrimSpace       (const tstring &csStr);	
tstring                       sTrimLeftChar    (const tstring &csStr, TCHAR chChar); 
tstring                       sTrimRightChar   (const tstring &csStr, TCHAR chChar); 
tstring                       sRemoveEOL       (const tstring &csStr);	

tstring                       sReplaceAll      (const tstring &csStr, const tstring &csOldStr, const tstring &csNewStr); 
tstring                       sReplaceAll      (const tstring &csStr, TCHAR cOldStr, TCHAR cNewStr); 
tstring                       sRemoveAll       (const tstring &csStr, const tstring &csRemoveStr); 

std::vector<tstring>          vecsSplit        (const tstring &csStr, const tstring &csDelimiter); 
BOOL                          bSplit           (const tstring &csStr, const tstring &csDelimiter, std::vector<tstring> *vecsOut); 

std::vector<tstring>          vecsSplitKeyValue(const tstring &csStr, const tstring &csDelimiter); 
tstring                       sJoin            (const std::vector<tstring> &cvecsVec, const tstring &csDelimiter); 
tstring                       sCut             (const tstring &csStr, const tstring &csFirstLeftDelimiter, const tstring &csFirstRightDelimiter); /*-*/
tstring                       sCut             (const tstring &csStr, size_t uiStartPos = 0, size_t uiEndPos = std::string::npos); 

BOOL                          bStrToFile       (const tstring &csStr, const tstring &csFilePath);	/*-*/
tstring                       bStrFromFile     (const tstring &csStr, const tstring &csFilePath);	/*-*/

tstring						  sToLowerCase     (const tstring &csStr);	
tstring                       sToUpperCase     (const tstring &csStr);	
tstring						  sToLowerCase     (const tstring &csStr, ULONG ulSize);	
tstring                       sToUpperCase     (const tstring &csStr, ULONG ulSize);	

tstring                       sFormatStr       (LPCTSTR pcszFormat, ...); 
std::string                   sFormatStrA      (LPCSTR  pcszFormat, ...); 
tstring                       sFormatStr2      (LPCTSTR pcszFormat, ...); 
tstring                       sFormatStrV      (LPCTSTR pcszFormat, va_list palArgs);
tstring                       sMinimizeStr     (const tstring &csStr, const UINT cuiMaxLen); 

/****************************************************************************
*    TCHAR
*
*****************************************************************************/

//This is ASCII specific but is safe with chars >= 0x80
BOOL                              bIsPunctuation   (TCHAR ch); 
BOOL                              bIsADigit        (TCHAR ch); 
BOOL                              bIsLowerCase     (TCHAR ch); 
BOOL                              bIsUpperCase     (TCHAR ch); 
BOOL                              bIsSpaceOrTab    (UINT ch); 
BOOL                              bIsDigit         (UINT ch); 
BOOL                              bIsDigit         (UINT ch, UINT base); 
BOOL                              bIsLetter        (TCHAR ch); 
BOOL                              bIsSpace         (UINT ch); 
BOOL                              IsEOLChar        (TCHAR ch); 
BOOL							  bIsSlash         (TCHAR ch);  

INT                               iGetHexChar      (UCHAR hd1, UCHAR hd2);
TCHAR                             cHexToChar       (TCHAR *pszStr);
INT								  iCharCodeAt      (const tstring &csStr, INT nIndex);	
BOOL                              bCompareNoCase   (const tstring &csStr1, const tstring &csStr2); 
BOOL                              bCompareNoCase2  (const tstring &csStr1, const tstring &csStr2); 


/****************************************************************************
* ����������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + vRandomShuffleT (������������ ������)
template<class T> 
VOID vRandomShuffleT(std::vector<T> &v) {
	std::random_shuffle(v.begin(), v.end());
}
//--------------------------------------------------------------------------
//TODO: + vSortVectorT (��������� ������)
template<class T> 
VOID vSortVectorT(std::vector<T> &v) {
	std::sort(v.begin(), v.end());
}
//--------------------------------------------------------------------------


/****************************************************************************
*	�������������
*
*****************************************************************************/

tstring                       sDecodeWinKoi    (const tstring &csStr, UINT uiFrom, UINT uiTo);
tstring						  sTranslitLatToRus(const tstring &csStr);	
BOOL                          bCharToWide      (const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize);	/*-*/
tstring						  sStrToRtf        (tstring sStr);
tstring						  sRtfToStr        (tstring sStr);
tstring                       sFormatBytes     (DOUBLE dBytes);



/****************************************************************************
*    ������
*
*****************************************************************************/

tstring                       sCreatePlainGUID ();  
BOOL                          bIsRepeatedStr   (const tstring &csStr); 
tstring                       sLastErrorStr    (ULONG ulLastError);	
ULONG                         ulCountDigits    (ULONG ulDigit);	

//---------------------------------------------------------------------------
//TODO: + vPrintStdVectorT (������ � ������� std::vector) 
template<class T>
VOID vPrintStdVectorT(const std::vector<T> &t) {
	std::cout << std::endl << _T("Printing std::vector contents...") << std::endl << std::endl;

	std::vector<T>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it){
		tcout << _T("Value: [") << (*it) << _T("]") << std::endl;
	}
	
	tcout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
//TODO: + vPrintStdMultiMapT (������ � ������� std::multimap) 
template<class T1, class T2>
VOID vPrintStdMultiMapT(const std::multimap<T1, T2> &t) { 
	tcout << std::endl << _T("Printing std::multimap contents...") << std::endl << std::endl;
	
	std::multimap<T1, T2>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it) {
		tcout << _T("Key: [") << (*it).first << _T("]") << _T("\t\t") 
			  << _T("Value: [") << (*it).second << _T("]") << std::endl;
	}

	tcout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
#endif	//XLib_CXStringH