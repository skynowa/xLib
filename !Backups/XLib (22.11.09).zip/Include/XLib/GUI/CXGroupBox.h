/****************************************************************************
* Class name:  CXGroupBox
* Description: 
* File name:   CXGroupBox.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:10:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXGroupBoxH
#define XLib_Gui_CXGroupBoxH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXGroupBox: public CXWindow {
	public:
		 CXGroupBox();
		~CXGroupBox();

		BOOL bCreateRes(INT iID, HWND hParent);

};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXGroupBoxH