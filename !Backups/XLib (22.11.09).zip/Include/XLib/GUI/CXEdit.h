/****************************************************************************
* Class name:  CXEdit
* Description: ������ � ��������� �����
* File name:   CXEdit.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXEditH
#define XLib_Gui_CXEditH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXEdit: public CXWindow {
	public:
		        CXEdit    ();
		       ~CXEdit    ();
                       
		BOOL    bCreateRes(INT iID, HWND hParent);
		LRESULT bLimitText(UINT uiSize);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXEditH