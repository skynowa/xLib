#ifndef XLib_CommonH
#define XLib_CommonH

#ifndef WIN32
////#    error This file is intended only for use with the Microsoft Windows API.
#endif
#ifndef __cplusplus
   #error XLib requires C++ compilation (use a .cpp suffix)
#endif






////#if defined(UNICODE)
////typedef std::wstring tstring;
////#else
////typedef std::string tstring;
////#endif 


////////#ifndef STRICT
////////#    define STRICT 1
////////#endif

#define XARRAYSIZE(a) (sizeof(a)/sizeof(a[0]))

//////#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

//---------------------------------------------------------------------------
//#undef  FALSE
//#define FALSE       0
//
//#undef  TRUE
//#define TRUE        1
//
//#undef  NULL
//#define NULL        0
//
//#undef  CHAR        
//#define CHAR        char
//
//#undef  WCHAR       
//#define WCHAR       wchar_t
//
//#undef  UCHAR       
//#define UCHAR       unsigned char
//
//#undef  INT        
//#define INT         int
//
//#undef  UINT     
//#define UINT        unsigned int
//
//#undef  SHORT      
//#define SHORT       short
//
//#undef  USHORT      
//#define USHORT      unsigned short
//
//#undef  LONG         
//#define LONG        long
//
//#undef ULONG       
//#define ULONG       unsigned long

//#undef long long int
//#define long long int

//#undef  LONGLONG    
//#define LONGLONG    __int64
//
//#undef  ULONGLONG   
//#define ULONGLONG   unsigned __int64 

//#undef  VOID        (void)
//#define VOID        void
//
//#undef  CONST       const
//#define CONST       const

//#undef  LPSTR       
//#define LPSTR       char *
//
//#undef  LPCSTR      
//#define LPCSTR      const char *
//
//#undef  LPWSTR      
//#define LPWSTR      wchar_t *  
//
//#undef  LPWCSTR     
//#define LPWCSTR     const wchar_t
//
//#undef  LPTSTR     
//#define LPTSTR      wchar_t *
//
//#undef  LPTCSTR     
//#define LPTCSTR     const wchar_t *

/*
CHAR        char
WCHAR       wchar_t
UCHAR       unsigned char
INT         int
UINT        unsigned int
SHORT       short
USHORT      unsigned short
LONG        long
ULONG       unsigned long
            long long int
LONGLONG    __int64
ULONGLONG   unsigned __int64 
VOID        void
CONST       const
LPSTR       char *
LPCSTR      const char *
LPWSTR      wchar_t *  
LPWCSTR     const wchar_t
LPTSTR      wchar_t *
LPTCSTR     const wchar_t *
*/
//---------------------------------------------------------------------------
/*
#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)
*/
#define DELETE_POINTER(p)   if (NULL != (p)) {delete p;    p = NULL;} 
#define DELETE_ARRAY(a)		if (NULL != (a)) {delete [] a; a = NULL;}
#define ZERO_BUFF(x)        ::ZeroMemory(&x, sizeof(x));
#define SIZEOF_ARRAY(array) (sizeof(array) / sizeof(array[0]))

#define CHECK_HANDLE(h)		((INVALID_HANDLE_VALUE != h) && (NULL != h) /*&& (FALSE != ::GetHandleInformation(h, HANDLE_FLAG_INHERIT))*/)
#define CLOSE_HANDLE(h)		if (INVALID_HANDLE_VALUE != h) {::CloseHandle(h);	h = INVALID_HANDLE_VALUE;}
//#define IsValidFileHandle(x)	((x) && ((x) != INVALID_HANDLE_VALUE))
//-------------------------------------
//Define min and max for Borland C++, Dev-C++ compatibility
#ifndef max
#    define max(a, b)  (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#    define min(a, b)  (((a) < (b)) ? (a) : (b))
#endif
//---------------------------------------------------------------------------
//ASSERT (_CrtCheckMemory()).
////XASSERT(INVALID_HANDLE_VALUE != NULL);
////XASSERT(NULL != INVALID_HANDLE_VALUE);
////XASSERT(INVALID_HANDLE_VALUE != FALSE);
////XASSERT(FALSE != INVALID_HANDLE_VALUE);
////XASSERT(INVALID_HANDLE_VALUE == ((HANDLE)(ULONG) -1));
///XASSERT(DWORD == ULONG);

////#define _SECURE_SCL 0

//Remove pointless warning messages
#ifdef _MSC_VER
  #pragma warning (disable : 4511) // copy operator could not be generated
  #pragma warning (disable : 4512) // assignment operator could not be generated
  #pragma warning (disable : 4702) // unreachable code (bugs in Microsoft's STL)
  #pragma warning (disable : 4786) // identifier was truncated
  #pragma warning (disable : 4996) // function or variable may be unsafe (deprecated)
  #ifndef _CRT_SECURE_NO_WARNINGS
    #define _CRT_SECURE_NO_WARNINGS // eliminate deprecation warnings for VS2005
  #endif
#endif // _MSC_VER
#ifdef __BORLANDC__
  #pragma option -w-8027		   // function not expanded inline
#endif

//Required for VS 2008 (fails on XP and Win2000 without this fix)
#ifndef _WIN32_WINNT
  #define _WIN32_WINNT 0x0500
#endif

#ifndef STRICT
  #define STRICT 1
#endif

//Prevent winsock.h #include's.
#define _WINSOCKAPI_            

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf

#include <windows.h>
#include <windowsx.h>
#include <string>
#include <stdio.h>
#include <iostream>
#include <tchar.h>

#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator> 

////#include <shlwapi.h>
//---------------------------------------------------------------------------
////typedef std::basic_string<TCHAR> tString;

#if defined(UNICODE) || defined(_UNICODE)
	typedef std::wstring        tstring;         
	typedef std::wostringstream tostringstream; 
	typedef std::wistringstream tistringstream;
	typedef std::wifstream      tifstream;      
	typedef std::wofstream      tofstream;  

    #define tcout               std::wcout        
#else   
	typedef std::string         tstring;       
	typedef std::ostringstream  tostringstream; 
	typedef std::istringstream  tistringstream;  
	typedef std::ifstream       tifstream;      
	typedef std::ofstream       tofstream;     

	#define tcout               std::cout      
#endif  /*_UNICODE*/
//---------------------------------------------------------------------------
#include <XLib/CXMsgBoxT.h>
#include <XLib/CXNonCopyable.hpp>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
#define ATTR_DELIMITER_A ":"; 

////const std::string g_csAttrDelimiterA = ATTR_DELIMITER_A;
////const std::string g_csEndOfHeaderA   = END_OF_HEADER_A;
////const std::string g_csEndOfLineA     = END_OF_LINE_A;

const std::string xCR        = "\r";
const std::string xLF        = "\n";
const std::string xCRLF      = xCR + xLF;
const std::string xCOLON     = ":";

const std::string xWIN_SLASH = "\\";
const std::string xNIX_SLASH = "/";

//CR             = <US-ASCII CR, carriage return (13)>
//LF             = <US-ASCII LF, linefeed (10)>
//SP             = <US-ASCII SP, space (32)>
//HT             = <US-ASCII HT, horizontal-tab (9)>

/*
vbCr			Chr(13)	//������� �������.
VbCrLf			Chr(13) & Chr(10)	//������� ������� � ������� ������.
vbFormFeed		Chr(12)	//������� ��������.
vbLf			Chr(10)	//������� ������.
vbNewLine		Chr(13) & Chr(10) or Chr(10)	//������������ ���������� (����������) ������ ����� ������.
vbNullChar		Chr(0)	//������ � ������� �����.
vbNullString	//������� �������� ���� �����, ��� ������ ������� ����� ("").
vbTab			Chr(9)	//������ ���������.
vbVerticalTab	Chr(11)	//������ ������������ ���������.
*/

/*
{$IFDEF MSWINDOWS}
PathDelim = '\';
DriveDelim = ':';
PathSep = ';';
AllFilesMask = '*.*';
{$ENDIF MSWINDOWS}
{$IFDEF UNIX}
PathDelim = '/';
AllFilesMask = '*';
{$ENDIF UNIX}
// Note: the else is on purpose, VCL is not defined for a console application
NullHandle = 0;
USDecimalSeparator = '.';
*/
//---------------------------------------------------------------------------
//////////////////////////////#ifdef INT
//////////////////////////////#    define INT int
//////////////////////////////#endif
//////////////////////////////#ifndef INT
//////////////////////////////#    define INT int
//////////////////////////////#endif
//-------------------------------------
//For compilers lacking Win64 support
////#ifndef  GetWindowLongPtr
////  #define GetWindowLongPtr   GetWindowLong
////  #define SetWindowLongPtr   SetWindowLong
////  #define GWLP_WNDPROC       GWL_WNDPROC
////  #define GWLP_HINSTANCE     GWL_HINSTANCE
////  #define GWLP_ID            GWL_ID
////  #define GWLP_USERDATA      GWL_USERDATA
////  #define DWLP_DLGPROC       DWL_DLGPROC
////  #define DWLP_MSGRESULT     DWL_MSGRESULT
////  #define DWLP_USER          DWL_USER
////  #define DWORD_PTR          DWORD
////  #define LONG_PTR           LONG
////  #define ULONG_PTR          LONG
////#endif
////#ifndef GetClassLongPtr
////  #define GetClassLongPtr    GetClassLong
////  #define SetClassLongPtr    SetClassLong
////  #define GCLP_HBRBACKGROUND GCL_HBRBACKGROUND
////  #define GCLP_HCURSOR       GCL_HCURSOR
////  #define GCLP_HICON         GCL_HICON
////  #define GCLP_HICONSM       GCL_HICONSM
////  #define GCLP_HMODULE       GCL_HMODULE
////  #define GCLP_MENUNAME      GCL_MENUNAME
////  #define GCLP_WNDPROC       GCL_WNDPROC
////#endif


#ifndef TRUE
    #define TRUE 1
#endif            

#ifndef FALSE
    #define FALSE 0
#endif
//-------------------------------------
//For Visual Studio 6 (without an updated platform SDK) and Dev-C++
#ifndef OPENFILENAME_SIZE_VERSION_400
  #define OPENFILENAME_SIZE_VERSION_400 sizeof(OPENFILENAME)
#endif

//-------------------------------------
//Automatically include the XLib namespace define NO_USING_NAMESPACE to skip this step
namespace XLib {}
#ifndef NO_USING_NAMESPACE
  using namespace XLib;
#endif
//---------------------------------------------------------------------------
#endif  //XLib_CommonH