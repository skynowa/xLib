/****************************************************************************
* Class name:  CXDbLog
* Description: ����������� ����� ��
* File name:   CXDbLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:55:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXDbLogH
#define CXDbLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXDbLog : public CXNonCopyable {
	public:
		CXDbLog();
	   ~CXDbLog();
};
//---------------------------------------------------------------------------
#endif
