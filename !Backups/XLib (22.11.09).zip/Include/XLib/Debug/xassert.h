/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Debug_XassertH
#define XLib_Debug_XassertH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <stddef.h>
//---------------------------------------------------------------------------
#if defined(__GNUC__) || (defined(__MWERKS__) && (__MWERKS__ >= 0x3000)) || (defined(__ICC) && (__ICC >= 600))
#    define __OUT_FUNC__ __PRETTY_FUNCTION__
#elif defined(__DMC__) && (__DMC__ >= 0x810)
#    define __OUT_FUNC__ __PRETTY_FUNCTION__
#elif defined(__FUNCSIG__)
#    define __OUT_FUNC__ __FUNCTION__ /*__FUNCSIG__*/
#elif (defined(__INTEL_COMPILER) && (__INTEL_COMPILER >= 600)) || (defined(__IBMCPP__) && (__IBMCPP__ >= 500))
#    define __OUT_FUNC__ __FUNCTION__
#elif defined(__BORLANDC__) && (__BORLANDC__ >= 0x550)
#    define __OUT_FUNC__ __FUNC__
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199901)
#    define __OUT_FUNC__ __func__
#else
#    define __OUT_FUNC__ _T("<unknown>")
#endif
//---------------------------------------------------------------------------
//#define NDEBUG 1
//#define XLib_Debug_MsgBoxLite 1
//C_ASSERT
//---------------------------------------------------------------------------
#ifdef NDEBUG
    VOID vLogAssert(LPCTSTR pszExp, ULONG ulLastError, LPCTSTR pszFile, ULONG ulLine, LPCTSTR pszFunc, LPCTSTR pszComment = _T(""));

	#define XASSERT(exp)                             do { if (!(exp)) {vLogAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__));}                               } while(0)
	#define XASSERT_RET(exp, return_exp)             do { if (!(exp)) {vLogAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__)); return (return_exp);}          } while(0)

	#define XASSERT_EX(exp, comment)                 do { if (!(exp)) {vLogAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__), comment);}                      } while(0)
    #define XASSERT_EX_RET(exp, comment, return_exp) do { if (!(exp)) {vLogAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__), comment); return (return_exp);} } while(0)
	
	#define XASSERT_DO(exp, do_instructions)         do { if (!(exp)) {vLogAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__)); do_instructions;}              } while(0)
#else 
    VOID vMsgAssert(LPCTSTR pszExp, ULONG ulLastError, LPCTSTR pszFile, ULONG ulLine, LPCTSTR pszFunc, LPCTSTR pszComment = _T(""));

	#define XASSERT(exp)                             do { if (!(exp)) {vMsgAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__));}                               } while(0)
	#define XASSERT_RET(exp, return_exp)             do { if (!(exp)) {vMsgAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__)); return (return_exp);}          } while(0)

	#define XASSERT_EX(exp, comment)                 do { if (!(exp)) {vMsgAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__), comment);}                      } while(0)
	#define XASSERT_EX_RET(exp, comment, return_exp) do { if (!(exp)) {vMsgAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__), comment); return (return_exp);} } while(0)
	
	#define XASSERT_DO(exp, do_instructions)         do { if (!(exp)) {vMsgAssert(_T(#exp), ::GetLastError(), _T(__FILE__), __LINE__, _T(__OUT_FUNC__)); do_instructions;}              } while(0)
#endif /*NDEBUG*/

	#define CHECK_RET(exp, return_exp)               do { if ((exp))  {return (return_exp);} } while(0)                                                                               
	#define CHECK_DO(exp, do_instructions)           do { if ((exp))  {do_instructions;}     } while(0)
//---------------------------------------------------------------------------
#endif /*XLib_Debug_XassertH*/
