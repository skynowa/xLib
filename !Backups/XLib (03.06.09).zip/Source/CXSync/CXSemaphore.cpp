/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSync/CXSemaphore.h>

#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXSemaphore::CXSemaphore() 
	: m_hSemaphore(NULL)
{
	
}
//---------------------------------------------------------------------------
CXSemaphore::~CXSemaphore() {
	/*DEBUG*/XASSERT(NULL != m_hSemaphore);

	if (NULL != m_hSemaphore) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(m_hSemaphore);	m_hSemaphore = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXSemaphore::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, NULL);

	return m_hSemaphore;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG nInitialCount, LONG nMaxCount, LPCSTR pcszName) {
	m_hSemaphore = ::CreateSemaphore(lpsaAttributes, nInitialCount, nMaxCount, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, FALSE);
	
	m_hSemaphore = ::OpenSemaphore(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bRelease(LONG liReleaseCount, LONG *pliOldCount) {
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, FALSE);

	BOOL bRes = FALSE;
	
	bRes = ::ReleaseSemaphore(m_hSemaphore, liReleaseCount, pliOldCount);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXSemaphore::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != m_hSemaphore, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return ::WaitForSingleObject(m_hSemaphore, ulTimeout);
}
//---------------------------------------------------------------------------