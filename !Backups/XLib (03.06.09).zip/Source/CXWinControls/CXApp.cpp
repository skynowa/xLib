/****************************************************************************
*	CXApp
*
*****************************************************************************/


#include <Xlib/CXWinControls/CXApp.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXApp::CXApp() {
	_m_hInstance  = NULL;
	_m_sClassName = "CXApp";
	_m_hIcon      = NULL;
	_m_hAccel     = NULL;
	_m_iWidth     = 544;
	_m_iHeight    = 375;
	_m_iTop       = CW_USEDEFAULT;
	_m_iLeft      = CW_USEDEFAULT;
}
//---------------------------------------------------------------------------
//Create the window
BOOL CXApp::bCreate(HINSTANCE hInstance, INT iCmdShow) {
	//-------------------------------------
	//The Window structure
	WNDCLASSEX wincl = {0};	

	wincl.hInstance     = hInstance;		
	wincl.lpszClassName = _m_sClassName.c_str();
	wincl.lpfnWndProc   = (WNDPROC)StatiCXWndProc;	//This function is called by windows
	wincl.style         = CS_DBLCLKS;				//Catch double-clicks
	wincl.cbSize        = sizeof(WNDCLASSEX);
	wincl.hIcon         = _m_hIcon;	//LoadIcon (hInstance, 0);
	wincl.hIconSm       = NULL;		//LoadIcon (hInstance, 0);
	wincl.hCursor       = NULL;		//LoadCursor (NULL, IDC_ARROW);
	wincl.lpszMenuName  = NULL;
	wincl.cbClsExtra    = 0;		//No extra bytes after the window class
	wincl.cbWndExtra    = 0;		//structure or the window instance
	wincl.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);

	//-------------------------------------
	//Register the window class, and if it fails quit the program
	if (FALSE == ::RegisterClassEx(&wincl)) {
		return FALSE;
	} 

	//-------------------------------------
	//The class is registered, let's create the program
	_m_hWnd = ::CreateWindowEx(
				0,								//Extended possibilites for variation
				_m_sClassName.c_str(),			//Classname
				_m_sText.c_str(),				//Title Text
				/*WS_OVERLAPPEDWINDOW |*/ DS_CENTER | WS_MINIMIZEBOX | WS_POPUP | WS_CAPTION | WS_SYSMENU,			//default window
				_m_iLeft, _m_iTop, _m_iWidth,	//The programs width
				_m_iHeight,						//and height in pixels
				HWND_DESKTOP,					//The window is a child-window to desktop
				_m_hMenu,						//Menu
				hInstance,						//Program Instance handler
				this);							//Pointer to the current class
	
	if (NULL ==_m_hWnd) {
		return FALSE;
	} 

	HFONT hFont = ::CreateFont(13, 0, 0, 0, 0, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Tahoma");
	SetFont(hFont);	////::SendMessage(_m_hWnd, WM_SETFONT, (WPARAM)hFont, (LPARAM)1);

	//-------------------------------------
	//Make the window visible on the screen
	Show(iCmdShow);	
	::UpdateWindow(_m_hWnd);

	return TRUE;
}
//---------------------------------------------------------------------------
//Runs the window (waits for messages and processes them)
VOID CXApp::vRun() {
	MSG msg = {0}; //Here messages to the application are saved

	while (::GetMessage(&msg, NULL, 0, 0)) {
		if (NULL != _m_hAccel && ::TranslateAccelerator(_m_hWnd, _m_hAccel, &msg)) {
			continue;
		} 
		//Translate virtual-key messages into character messages
		::TranslateMessage(&msg);
		//Send message to WindowProcedure
		::DispatchMessage(&msg);
	}
}
//---------------------------------------------------------------------------
HICON CXApp::hIcon() {
	return _m_hIcon;
}
//---------------------------------------------------------------------------
VOID CXApp::vIcon(HICON hIcon) {
	_m_hIcon = hIcon;
}
//---------------------------------------------------------------------------
HACCEL CXApp::hAccelerators() {
	return _m_hAccel;
}
//---------------------------------------------------------------------------
VOID CXApp::vAccelerators(HACCEL hAccel) {
	_m_hAccel = hAccel;
}
//---------------------------------------------------------------------------
BOOL CXApp::bIsMaximized() {
	return ::IsZoomed(_m_hWnd);
}
//---------------------------------------------------------------------------
VOID CXApp::vProcessMessages() {
	MSG msg = {0};

	while(::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
		::TranslateMessage(&msg); 
		::DispatchMessage(&msg); 
	}
}
//---------------------------------------------------------------------------
BOOL CXApp::bSetPosScreenCenter() {
	BOOL bRes = FALSE;
	
	INT  iWidth  = 0; 
	INT  iHeight = 0; 
	INT  iLeft   = 0; 
	INT  iTop    = 0;
	RECT rcWin   = {0};

	//-------------------------------------
	//������ ������
	HDC hDC = ::GetDC(0);
	iWidth  = ::GetDeviceCaps(hDC, HORZRES);
	iHeight = ::GetDeviceCaps(hDC, VERTRES);
	::ReleaseDC(0, hDC);

	::GetWindowRect(_m_hWnd, &rcWin);

	iLeft = (iWidth -  (rcWin.right  - rcWin.left + 1)) / 2;
	iTop  = (iHeight - (rcWin.bottom - rcWin.top  + 1)) / 2;

	bRes = Move(iLeft, iTop, rcWin.right - rcWin.left + 1, rcWin.bottom - rcWin.top + 1, TRUE);

	return bRes;
}
//---------------------------------------------------------------------------