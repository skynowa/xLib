/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#include <Xlib/CXWinControls/CXWnd.h>
#include <XLib/xassert.h>

#pragma comment(lib, "comctl32.lib")
//---------------------------------------------------------------------------
CXWnd::CXWnd() {
	_m_hWnd        = NULL;
	_m_hMenu       = NULL;
	_m_sClassName  = "CXWnd";
	_m_DefaultFont = hfCreateDefaultFont();
	_m_sText       = "";

	OnCreate       = NULL;
	OnDoubleClick  = NULL;
	OnResize       = NULL;
	OnCommand      = NULL;
	OnMouseMove    = NULL;
	OnMouseLeftUp  = NULL;
	OnClose        = NULL;
	OnDestroy      = NULL;
}
//---------------------------------------------------------------------------
//Window Procedure called by windows (static)
LRESULT CALLBACK CXWnd::StatiCXWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	//A pointer to the current class (this) is saved into the window with
	//SetWindowLongPtr. Why ? Because WndProc is called as a static method (it's not supposed to be a class method at first)
	//The message handling is then deferred to OnMessage which can use the this pointer.
	CXWnd *pwndThis = NULL;

	if (WM_CREATE == message) {
		CREATESTRUCT *pCS = (CREATESTRUCT*)lParam;

		pwndThis = (CXWnd *)pCS->lpCreateParams;
		::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)pwndThis);
	} else {
		pwndThis = (CXWnd *)::GetWindowLongPtr(hWnd, GWLP_USERDATA);
	}

	if (NULL == pwndThis) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return pwndThis->WndProc(hWnd, message, wParam, lParam);
	} 
}
//---------------------------------------------------------------------------
//Window Procedure
LRESULT CXWnd::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	if (FALSE == bHandleMessage(hWnd, message, wParam, lParam)) {
		return ::DefWindowProc(hWnd, message, wParam, lParam);
	} else {
		return FALSE;
	} 
}
//---------------------------------------------------------------------------
BOOL CXWnd::bHandleMessage(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) { 
		case WM_CREATE:
			{
				if (NULL != OnCreate) {
					OnCreate(wParam, lParam);
				} 
			}
			break;

		case WM_COMMAND:
			{
				if (NULL != OnCommand) {
					OnCommand(wParam, lParam);
				} 
			}
			break;

		case WM_MOUSEMOVE:
			{
				if (NULL != OnMouseMove) {
					OnMouseMove(wParam, (INT)LOWORD(lParam), (INT)HIWORD(lParam));
				} 
			}
			break;

		case WM_NOTIFY:
			{
				if (NULL != OnNotify) {
					OnNotify(wParam, lParam);
				} 
			}
			break;

		case WM_LBUTTONUP:
			{
				if (NULL != OnMouseLeftUp) {
					OnMouseLeftUp(wParam, (INT)LOWORD(lParam), (INT)HIWORD(lParam));
				} 
			}
 
			break;
		case WM_LBUTTONDBLCLK:
			{
				if (NULL != OnDoubleClick) {
					OnDoubleClick();
				}
			} 
			break;

		case WM_MOVE:
			{
				_m_iLeft = LOWORD(lParam);
				_m_iTop  = HIWORD(lParam);
			}
			break;

		case WM_CHAR:
			{
				if (NULL != OnChar) {
					OnChar(wParam, lParam);
				} 
			}
			break;

		case WM_KEYDOWN:
			{
				if (NULL != OnKeyDown) {
					OnKeyDown(wParam, lParam);
				} 
			}
			break;

		case WM_KEYUP:
			{
				if (NULL != OnKeyUp) {
					OnKeyUp(wParam, lParam);
				} 
			}
			break;

		case WM_DEADCHAR:
			{
				if (NULL != OnDeadChar) {
					OnDeadChar(wParam, lParam);
				} 
			}
			break;

		case WM_CONTEXTMENU:
			{
				if (NULL != OnContextMenu) {
					OnContextMenu((HWND)wParam, LOWORD(lParam), HIWORD(lParam));
				} 
			}
			break;

		case WM_SIZE:
			{
				_m_iWidth  = LOWORD(lParam); //_rect.right-_rect.left;
				_m_iHeight = HIWORD(lParam); //_rect.bottom-_rect.top;
				if (NULL != OnResize) {
					OnResize(_m_iWidth, _m_iHeight, wParam);
				} 
			}
			break;

		case WM_SIZING:
			{
				if (NULL != OnResizing) {
					OnResizing(wParam, (LPRECT)lParam);
				} 
			}
			break;

		case WM_TIMER:
			{
				if (NULL != OnTimer) {
					OnTimer(wParam, lParam);
				} 
			}
			break;

		case WM_CLOSE:
			{
				if (NULL != OnClose) {
					OnClose();
				} 
			}
		break;


		case WM_DESTROY:
			{
				if (NULL != OnDestroy) {
					OnDestroy();
				} 
				::PostQuitMessage(0); 
			}
			break;

		default:
			return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWnd::bInitCommonControls(DWORD dwFlags) {
	BOOL bRes = FALSE;

	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = dwFlags;
	
	bRes = ::InitCommonControlsEx(&iccx);
	/*DEBUG*/XASSERT_RET(NULL == _m_hWnd, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
UINT_PTR CXWnd::puiSetTimer(UINT_PTR nIDEvent, UINT uElapse) {
	/*DEBUG*/
	/*DEBUG*///not need
	
	return ::SetTimer(_m_hWnd, nIDEvent, uElapse, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::bKillTimer(UINT_PTR uIDEvent) {
	/*DEBUG*/
	/*DEBUG*///not need
	
	return ::KillTimer(_m_hWnd, uIDEvent);
}
//---------------------------------------------------------------------------
BOOL CXWnd::bSetText(const std::string &csText) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	BOOL bRes = FALSE;

	_m_sText = csText;
	bRes = ::SetWindowText(_m_hWnd, csText.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXWnd::sGetText() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), "");
	
	std::string sRes   = "";
	const INT   ciSize = ::GetWindowTextLength(_m_hWnd);
	if (ciSize > 0) {
		sRes.resize(ciSize + 1);
		::GetWindowText(_m_hWnd, &sRes[0], ciSize + 1);
		sRes.resize(ciSize);
	}

	return sRes;
}
//---------------------------------------------------------------------------
HWND CXWnd::GetHandle() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), NULL);
	
	return _m_hWnd;
}
//---------------------------------------------------------------------------
HFONT CXWnd::GetFont() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), NULL);
	
	return (HFONT)SendMessage(WM_GETFONT, 0, 0);
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetFont(HFONT hFont) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	return (BOOL)SendMessage(WM_SETFONT, (WPARAM)hFont, FALSE);
}
//---------------------------------------------------------------------------
HFONT CXWnd::hfCreateDefaultFont() {
	/*DEBUG*///??XASSERT_RET(bIsWindow(), NULL);
	
	HFONT hfRes = NULL;

	hfRes = ::CreateFont(- 11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	/*DEBUG*/XASSERT_RET(NULL != hfRes, NULL);

	return hfRes;
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetDefaultFont() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	return SetFont(_m_DefaultFont);
}
//---------------------------------------------------------------------------
LOGFONT CXWnd::GetLogicalFont() {
	/*DEBUG*///////////XASSERT_RET(bIsWindow(), (LPVOID)NULL);  ??????????????????????
	
	LOGFONT lf = {0};
	::GetObject(GetFont(), sizeof(LOGFONT), &lf);
	
	return lf;
}
//---------------------------------------------------------------------------
INT CXWnd::GetWidth() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), - 1);
	
	return _m_iWidth;
}
//---------------------------------------------------------------------------
INT CXWnd::GetHeight() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), - 1);
	
	return _m_iHeight;
}
//---------------------------------------------------------------------------
INT CXWnd::GetLeft() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), - 1);
	
	return _m_iLeft;
}
//---------------------------------------------------------------------------
INT CXWnd::GetTop() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), - 1);
	
	return _m_iTop;
}
//---------------------------------------------------------------------------
BOOL CXWnd::bSetWindowPos(HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);

	BOOL bRes = FALSE;

	_m_iLeft   = X;
	_m_iTop    = Y;
	_m_iWidth  = cx;
	_m_iHeight = cy;

	bRes = ::SetWindowPos(_m_hWnd, hWndInsertAfter, X, Y, cx, cy, uFlags);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetSize(INT Width, INT Height) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	BOOL bRes = FALSE;

	_m_iWidth  = Width;
	_m_iHeight = Height;
	
	bRes = bSetWindowPos(NULL, 0, 0, Width, Height, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);

	return TRUE;	
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetPosition(INT Left, INT Top) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);

	BOOL bRes = FALSE;
	
	_m_iLeft = Left;
	_m_iTop  = Top;

	bRes = bSetWindowPos(NULL, Left, Top, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWnd::Align(HWND hParent, HWND hChild) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	BOOL bRes = FALSE;

	RECT rect = {0};		
	bRes = ::GetClientRect(hParent, &rect);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	bRes = ::MoveWindow(hChild, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetRect(RECT Rect) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);

	BOOL bRes = FALSE;
	
	_m_iWidth  = Rect.right  - Rect.left;
	_m_iHeight = Rect.bottom - Rect.top;
	_m_iLeft   = Rect.left;
	_m_iTop    = Rect.top;

	bRes = bSetWindowPos(NULL, _m_iLeft, _m_iTop, _m_iWidth, _m_iHeight, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);

	return TRUE;
}
//---------------------------------------------------------------------------
RECT CXWnd::GetRect() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), RECT()); 
	
	RECT rectRes = {0};

	BOOL bRes = FALSE;
	bRes = ::GetWindowRect(_m_hWnd, &rectRes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, RECT());    

	return rectRes;
}
//---------------------------------------------------------------------------
BOOL CXWnd::Destroy() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::DestroyWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWnd::Close() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);

	return (BOOL)SendMessage(WM_CLOSE, NULL, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Enable(BOOL Enabled) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	return ::EnableWindow(_m_hWnd, Enabled);
}
//---------------------------------------------------------------------------
HMENU CXWnd::GetMenu() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), HMENU());  
	
	return _m_hMenu;
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetMenu(HMENU Value) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	_m_hMenu = Value;

	return TRUE;
}
//---------------------------------------------------------------------------
HWND CXWnd::SetFocus() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	return ::SetFocus(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::SetRedraw(BOOL Redraw) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	
	return (BOOL)SendMessage(WM_SETREDRAW, Redraw, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(BOOL bErase) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	return ::InvalidateRect(_m_hWnd, NULL, bErase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Invalidate(LPRECT Rect, BOOL bErase) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	return ::InvalidateRect(_m_hWnd, Rect, bErase);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	return ::ValidateRect(_m_hWnd, NULL);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Validate(LPRECT Rect) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	return ::ValidateRect(_m_hWnd, Rect);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Show(INT iCmdShow) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	/*iCmdShow
		SW_FORCEMINIMIZE
		SW_HIDE
		SW_MAXIMIZE
		SW_MINIMIZE
		SW_RESTORE
		SW_SHOW
		SW_SHOWDEFAULT
		SW_SHOWMAXIMIZED
		SW_SHOWMINIMIZED
		SW_SHOWMINNOACTIVE
		SW_SHOWNA
		SW_SHOWNOACTIVATE
		SW_SHOWNORMAL*/

	return ::ShowWindow(_m_hWnd, iCmdShow);
}
//---------------------------------------------------------------------------
BOOL CXWnd::Move(int X, int Y, int nWidth, int nHeight, BOOL bRepaint) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	return ::MoveWindow(_m_hWnd, X, Y, nWidth, nHeight, bRepaint);
}
//---------------------------------------------------------------------------
BOOL CXWnd::IsVisible() {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need
	
	return ::IsWindowVisible(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXWnd::bIsWindow() {
	/*DEBUG*///--XASSERT(bIsWindow(_m_hWnd));
	/*DEBUG*///not need

	return ::IsWindow(_m_hWnd);
}
//---------------------------------------------------------------------------
LRESULT CXWnd::SendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need ???????

	//int __fastcall Perform(unsigned Msg, int WParam, int LParam);
	return ::SendMessage(_m_hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------
LRESULT CXWnd::PostMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need ???????

	//int __fastcall Perform(unsigned Msg, int WParam, int LParam);
	return ::PostMessage(_m_hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------