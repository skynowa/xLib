/****************************************************************************
* Class name:  CXFileLog
* Description: ����������� � ����
* File name:   CXFileLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:40:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXLog/CXFileLog.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>
#include <XLib/CXSync/CXLockScope.h>
#include <XLib/CXStdioFile.h>

//---------------------------------------------------------------------------
CXFileLog::CXFileLog() : 
	m_sLogPath(""), 
	m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);

	//�� ������ ���� (��� �����)
	m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + sExtractFullFileName(sExePath()) + ".log";
	m_ulMaxFileSize = DEFAULT_MAX_LOG_SIZE;
}
//---------------------------------------------------------------------------
CXFileLog::CXFileLog(const std::string &csFilePath, ULONG ulMaxFileSize): 
	m_sLogPath(""), 
	m_ulMaxFileSize(0)
{
	/*DEBUG*/XASSERT(false == csFilePath.empty());
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > ulMaxFileSize);
	/*DEBUG*/XASSERT(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE);

	//��� ����� - �� �������� "\"
	if (std::string::npos == csFilePath.find("\\")) {
		//�� ������ ���� (��� �����)
		m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + csFilePath/* + ".log"*/;
		m_ulMaxFileSize = ulMaxFileSize;
	} else {
		//������ ����
		m_sLogPath      = csFilePath;
		m_ulMaxFileSize = ulMaxFileSize;
	}
}
//---------------------------------------------------------------------------
CXFileLog::~CXFileLog() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXFileLog::bWrite(LPCSTR pcszFormat, ...) {   
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	bRes = bDeleteIfFull();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/////CXLockScope SL(m_csFile);

	CXStdioFile sfFile;

	bRes = sfFile.bOpen(m_sLogPath, "a");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	sfFile.iFprintf("%s %s\r\n", sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bOpen() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec("notepad.exe", m_sLogPath);
	////bRes = CXStdioFile::bExec(m_sLogPath, "-a");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bClear() {
	BOOL bRes = FALSE;

	/*LOCK*/////CXLockScope SL(m_csFile);

	CXStdioFile sfFile;
	
	bRes = sfFile.bOpen(m_sLogPath, "w");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	
	sfFile.iFprintf("");

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFileLog::bDelete() {
	BOOL bRes = FALSE;

	/*LOCK*/////CXLockScope SL(m_csFile);

	bRes = CXStdioFile::bRemove(m_sLogPath);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/


//---------------------------------------------------------------------------
BOOL CXFileLog::bDeleteIfFull() {
	BOOL bRes = FALSE;

	/*LOCK*/////CXLockScope SL(m_csFile);

	bRes = CXStdioFile::bAccess(m_sLogPath, CXStdioFile::amExistence);
	MsgBox(bRes, "");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, TRUE);

	CXStdioFile sfFile;
	LONG        liSize = CXStdioFile::fpError;

	bRes = sfFile.bOpen(m_sLogPath, "r");
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	liSize = sfFile.liGetSize();
	/*DEBUG*/XASSERT_RET(CXStdioFile::fpError != liSize, FALSE);

	bRes = sfFile.bClose();
	/*DEBUG*/XASSERT_RET(CXStdioFile::fpError != liSize, FALSE);

	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ULONG)(liSize / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		bRes = CXStdioFile::bRemove(m_sLogPath);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------