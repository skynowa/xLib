/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.cpp
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#include <XLib/CXPerform.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>

#pragma warning(disable : 4996)
//---------------------------------------------------------------------------
CXPerform::CXPerform(const std::string &csFileName) {
	/*DEBUG*/XASSERT(false == csFileName.empty());
	
	this->vResetData();
	this->m_sLogPath = sExtractFileDir(sExePath()) + "\\" + csFileName;
	
	this->vLog("------------------------------");
}
//---------------------------------------------------------------------------
CXPerform::~CXPerform() {	
	this->vLog("------------------------------");
}
//--------------------------------------------------------------------------
VOID CXPerform::vStart(INT iPerformMode) {
    if (iPerformMode > 2 || iPerformMode < 0) {
        this->m_bWasStarted = false;
        ::MessageBox(0, "���������� �����", "Log", MB_OK);
        return;
    }
    this->m_iPerfomModeNow = iPerformMode;

    switch (this->m_iPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				////////dtBeginTime = Time();
				////SYSTEMTIME stST = {0};
				////::GetLocalTime(&stST);

				////fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	
			}
			break;

        //pmGetTickCount
		case pmGetTickCount:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				this->m_dwBeginTime = ::GetTickCount();
			}
            break;
		
		//QueryPerformanceCounter
        case pmQueryPerformanceCounter:
			{
				if (!::QueryPerformanceFrequency(&this->m_liStart)) {
					::MessageBox(0, "��������� ����������", "Log", MB_OK);
					return;
				}
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::QueryPerformanceFrequency(&this->m_liBeginCount);
			}
            break;

		//pmGetThreadTimes
		case pmGetThreadTimes:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::GetThreadTimes(::GetCurrentThread(), &this->m_lpCreationTime, &this->m_lpExitTime, &this->m_lpKernelTime0, &this->m_lpUserTime0);
			}
			break;
		
        default:	
			{
				/*DEBUG*/XASSERT_EX(false, "���������� �����");
				::MessageBox(0, "���������� �����", "Log", MB_OK);
			}
            break;
    }

    m_bWasStarted = true;
}
//--------------------------------------------------------------------------
VOID CXPerform::vStop(const std::string &csComment) {
	if (false == this->m_bWasStarted) {
	   return;
	}

	switch (this->m_iPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				////dtEndTime = Time();
				////this->vLog(casComment, (dtEndTime - dtBeginTime).FormatString("hh:nn:ss:zz"));
			}
			break;

        //pmGetTickCount (��������)
        case pmGetTickCount:
            {
				this->m_dwEndTime = ::GetTickCount();
                this->vLog(csComment, sMilliSecToTimeString(this->m_dwEndTime - this->m_dwBeginTime));
            }
            break;

	    //QueryPerformanceCounter (�����)
	    case pmQueryPerformanceCounter:
            {
                ::QueryPerformanceCounter(&this->m_liEndCount);
                m_liCount.QuadPart = this->m_liEndCount.QuadPart - this->m_liBeginCount.QuadPart;
                this->vLog(csComment, sTypeToStr(this->m_liCount.QuadPart * 1000 / this->m_liStart.QuadPart));
            }
            break;

        //pmGetThreadTimes (��������)
        case pmGetThreadTimes:
            {
                ::GetThreadTimes(GetCurrentThread(), &this->m_lpCreationTime, &this->m_lpExitTime, &this->m_lpKernelTime1, &this->m_lpUserTime1);
                /*???? float*/this->vLog(csComment, sMilliSecToTimeString((iFiletimeToint64(this->m_lpUserTime1) - iFiletimeToint64(this->m_lpUserTime0)) / 10000));	//10000 - ������������; 10 - ������������
            }
            break;  	

	}

	this->vResetData();
}
//--------------------------------------------------------------------------
VOID CXPerform::vPulse(const std::string &csComment, INT iPerformMode) {
    this->vStop(csComment);
    this->vStart(iPerformMode);
}
//---------------------------------------------------------------------------
VOID CXPerform::vPulse(ULONG  ulComment, INT iPerformMode) {
    this->vStop(sTypeToStr(ulComment));
    this->vStart(iPerformMode);
}
//---------------------------------------------------------------------------
VOID CXPerform::vDeleteLog() {
    if (false == bFileExists(this->m_sLogPath)) {
		return;
    }
	if (!::SetFileAttributes(this->m_sLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
		/*DEBUG*/XASSERT(false);
	}
	if (0 != remove(this->m_sLogPath.c_str())) {
		/*DEBUG*/XASSERT(false);
	}
}
//---------------------------------------------------------------------------
VOID CXPerform::vOpenLog() {
	STARTUPINFO si         = {0};
	PROCESS_INFORMATION pi = {0}; 
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "Notepad.exe " + this->m_sLogPath; 
	if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	::Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------







/****************************************************************************
*	Private methods	
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXPerform::vResetData() {
    m_iPerfomModeNow                = - 1;
    m_bWasStarted                   = false;

	//pmGetTickCount
	m_dwBeginTime                   = 0;
	m_dwEndTime                     = 0;

    //QueryPerformanceCounter
    m_liStart.QuadPart              = 0;
	m_liBeginCount.QuadPart         = 0;
	m_liEndCount.QuadPart           = 0;

	//GetThreadTimes
	m_lpCreationTime.dwLowDateTime  = 0;
    m_lpCreationTime.dwHighDateTime = 0;
	m_lpExitTime.dwLowDateTime      = 0;
    m_lpExitTime.dwHighDateTime     = 0;
	m_lpKernelTime0.dwLowDateTime   = 0;
    m_lpKernelTime0.dwHighDateTime  = 0;
	m_lpUserTime0.dwLowDateTime     = 0;
    m_lpUserTime0.dwHighDateTime    = 0;
	m_lpKernelTime1.dwLowDateTime   = 0;
    m_lpKernelTime1.dwHighDateTime  = 0;
	m_lpUserTime1.dwLowDateTime     = 0;
    m_lpUserTime1.dwHighDateTime    = 0;
    
    ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);
}
//--------------------------------------------------------------------------
__int64 CXPerform::iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//--------------------------------------------------------------------------
VOID CXPerform::vLog(const std::string &csText) {
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	
	fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;
}
//---------------------------------------------------------------------------
VOID CXPerform::vLog(const std::string &csComment, const std::string &csText) {
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
    XASSERT(NULL != pFile);

    SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	
	fprintf(pFile, "[%d:%d:%d]  %s: %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csText.c_str());	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;
}
//---------------------------------------------------------------------------
std::string CXPerform::sMilliSecToTimeString(__int64 i64MilliSec) {
	CHAR    szBuff[64 + 1] = {0};
    __int64 i64H  = 0;
    __int64 i64M  = 0;
    __int64 i64S  = 0;
    __int64 i64Ms = 0;

    i64H  = i64MilliSec / 3600000;
    i64M  = i64MilliSec % 3600000 / 60000;
    i64S  = i64MilliSec % 60000   / 1000;
    i64Ms = i64MilliSec % 1000;
	
    ::wsprintf(szBuff, "%I64d:%.2I64d:%.2I64d:%.3I64d", i64H, i64M, i64S, i64Ms);	
	
	return std::string(szBuff);
}
//---------------------------------------------------------------------------







/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

VOID F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
INT main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/