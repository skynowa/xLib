/****************************************************************************
*    �����: CXHandleHolder (CXHandleHolder.h)
*
*****************************************************************************/



#ifndef CXHandleHolderH
#define CXHandleHolderH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXHandleHolder {
		_NO_COPY(CXHandleHolder);
		
	public: 
				 CXHandleHolder();
				 CXHandleHolder(HANDLE hHandle);
			    ~CXHandleHolder();
                
		operator HANDLE();
		HANDLE operator = (HANDLE hHandle);
		
	private:
		HANDLE   m_hHandle; 
};
//---------------------------------------------------------------------------
#endif
