/****************************************************************************
*	CXWnd
*
*****************************************************************************/


#ifndef CXWnd_H
#define CXWnd_H
//---------------------------------------------------------------------------
#include <windows.h>
#include <commctrl.h>
#include <string>

using namespace std;
//---------------------------------------------------------------------------
class CXWnd {
	public:
		                        CXWnd               ();
		BOOL                    bSetText            (const std::string &csText);
		std::string             sGetText            ();
		INT                     GetWidth            ();
		INT                     GetHeight           ();
		INT                     GetLeft             ();
		INT                     GetTop              ();
		BOOL                    SetSize             (INT Width, INT Height);
		BOOL                    SetPosition         (INT Left,  INT Top);
		BOOL                    Align               (HWND hParent, HWND hChild);
		BOOL                    SetRedraw           (BOOL Redraw);
		RECT                    GetRect             ();
		BOOL                    SetRect             (RECT Rect);
		HWND                    GetHandle           ();
		HFONT                   GetFont             ();
		BOOL                    SetFont             (HFONT hFont);

		BOOL                    SetDefaultFont      ();
		LOGFONT                 GetLogicalFont      ();
		HWND                    SetFocus            ();
		HMENU                   GetMenu             ();
		BOOL                    SetMenu             (HMENU Value);

		BOOL                    Destroy             ();
		BOOL                    Close               ();
		BOOL                    Enable              (BOOL Enabled);
		BOOL                    Invalidate          (BOOL Erase);
		BOOL                    Invalidate          (LPRECT Rect, BOOL Erase);
		BOOL                    Validate            ();
		BOOL                    Validate            (LPRECT Rect);
		VOID                    SetCursor           (HCURSOR Cursor);
		BOOL                    Show                (INT iCmdShow);
		BOOL                    Move                (int X, int Y, int nWidth, int nHeight, BOOL bRepaint);
		BOOL                    bSetWindowPos       (HWND hWndInsertAfter, int X, int Y, int cx, int cy, UINT uFlags);
		BOOL                    IsVisible           ();
		BOOL                    bIsWindow           ();
		UINT_PTR                puiSetTimer         (UINT_PTR nIDEvent, UINT uElapse);
		BOOL                    bKillTimer          (UINT_PTR uIDEvent);
		LRESULT                 SendMessage         (UINT uiMsg, WPARAM wParam, LPARAM lParam);
		LRESULT                 PostMessage         (UINT uiMsg, WPARAM wParam, LPARAM lParam);

		VOID                    (*OnDoubleClick)    ();
		VOID                    (*OnClose)          ();
		VOID                    (*OnDestroy)        ();
		VOID                    (*OnTimer)          (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnResize)         (INT NewWidth, INT NewHeight, WPARAM SizeType);
		VOID                    (*OnResizing)       (WPARAM Edge, LPRECT DragRect);
		VOID                    (*OnContextMenu)    (HWND hWnd, INT X, INT Y);
		VOID                    (*OnNotify)         (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnCreate)         (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnCommand)        (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnChar)           (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnKeyDown)        (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnKeyUp)          (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnDeadChar)       (WPARAM wParam, LPARAM lParam);
		VOID                    (*OnMouseMove)      (WPARAM VKeys, INT x, INT y);
		VOID                    (*OnMouseLeftUp)    (WPARAM VKeys, INT x, INT y);

	protected:
		HWND                    _m_hWnd;
		HMENU                   _m_hMenu;
		string                  _m_sText;
		string                  _m_sClassName;
		INT                     _m_iWidth, _m_iHeight, _m_iLeft, _m_iTop;
		HFONT                   _m_DefaultFont;

		static LRESULT CALLBACK StatiCXWndProc      (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This static method is called by Windows
		LRESULT                 WndProc             (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by StatiCXWndProc
		BOOL                    bHandleMessage      (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);	//This method is called by WndProc
		BOOL                    bInitCommonControls (DWORD dwFlags);

	private:
		HFONT                   hfCreateDefaultFont ();
};
//---------------------------------------------------------------------------
#endif