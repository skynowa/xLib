#ifndef CXFILE
#define CXFILE



#include <XLib/xassert.h>
//---------------------------------------------------------------------------
template< bool t_bManaged >
class CFileT {
	//		_NO_COPY(CFileT);
	
    public:
		/*+*/HANDLE m_hFile;

		//---------------------------------------------------------------------------
		CFileT(HANDLE hFile = INVALID_HANDLE_VALUE) 
				: m_hFile(hFile)
		{
		}
		//---------------------------------------------------------------------------
		CFileT(const CFileT<t_bManaged>& file) : 
			m_hFile(INVALID_HANDLE_VALUE) 
		{
			DuplicateHandle(file.m_hFile);
		}
		//---------------------------------------------------------------------------
		~CFileT() { 
			if (t_bManaged) {
				Close(); 
			}
		}
		//---------------------------------------------------------------------------
		operator HFILE() const { 
			return (HFILE) m_hFile; 
		}
		//---------------------------------------------------------------------------
		/*+*/operator HANDLE() const {
			return m_hFile; 
		}
		//---------------------------------------------------------------------------
		const CFileT<t_bManaged>& operator=(const CFileT<t_bManaged>& file) {
			DuplicateHandle(file.m_hFile);
	        
			return *this;
		}
		//---------------------------------------------------------------------------
		/*+*/BOOL Open(LPCTSTR pstrFileName, 
				  DWORD   dwAccess     = GENERIC_READ, 
				  DWORD   dwShareMode  = FILE_SHARE_READ, 
				  DWORD   dwFlags      = OPEN_EXISTING,
				  DWORD   dwAttributes = FILE_ATTRIBUTE_NORMAL)
		{
			/*DEBUG*/XASSERT_RET(!::IsBadStringPtr(pstrFileName, -1), FALSE);
	        
			Close();

			HANDLE hFile = ::CreateFile(pstrFileName, dwAccess, dwShareMode, NULL, dwFlags, dwAttributes, NULL);
			if (hFile == INVALID_HANDLE_VALUE) {
				return FALSE;
			}
			m_hFile = hFile;
	        
			return TRUE;
		}
		//---------------------------------------------------------------------------
		BOOL Create(LPCTSTR pstrFileName,
					DWORD   dwAccess     = GENERIC_WRITE, 
					DWORD   dwShareMode  = 0 /*DENY ALL*/, 
					DWORD   dwFlags      = CREATE_ALWAYS,
					DWORD   dwAttributes = FILE_ATTRIBUTE_NORMAL) 
		{
			return Open(pstrFileName, dwAccess, dwShareMode, dwFlags, dwAttributes);
		}
		//---------------------------------------------------------------------------
		void Close() {
			if (m_hFile == INVALID_HANDLE_VALUE) {
				return;
			}
	        
			::CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}
		//---------------------------------------------------------------------------
		BOOL IsOpen() const {
			return m_hFile != INVALID_HANDLE_VALUE;
		}
		//---------------------------------------------------------------------------
		void Attach(HANDLE hHandle) {
			Close();
			m_hFile = hHandle;
		}   
		//---------------------------------------------------------------------------
		HANDLE Detach() {
			HANDLE h = m_hFile;
			m_hFile = INVALID_HANDLE_VALUE;
	        
			return h;
		}
		//---------------------------------------------------------------------------
		BOOL Read(LPVOID lpBuf, DWORD nCount) {
			/*DEBUG*/XASSERT_RET(m_hFile != INVALID_HANDLE_VALUE, FALSE);
			/*DEBUG*/XASSERT_RET(lpBuf   != NULL,                 FALSE);
			/*DEBUG*/XASSERT_RET(!::IsBadWritePtr(lpBuf, nCount), FALSE);
	        
			if (nCount == 0) {
				return TRUE;   // avoid Win32 "null-read"
			}
	        
			DWORD dwBytesRead = 0;
			if (!::ReadFile(m_hFile, lpBuf, nCount, &dwBytesRead, NULL)) {
				return FALSE;
			}
	        
			return TRUE;
		}
		//---------------------------------------------------------------------------
		BOOL Read(LPVOID lpBuf, DWORD nCount, LPDWORD pdwRead) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
			/*DEBUG*/XASSERT_RET(lpBuf, FALSE);
			/*DEBUG*/XASSERT_RET(!::IsBadWritePtr(lpBuf, nCount), FALSE);
			/*DEBUG*/XASSERT_RET(pdwRead, FALSE);
	        
			*pdwRead = 0;
	        
			if (nCount == 0) {
				return TRUE;   // avoid Win32 "null-read"
			}
	        
			if (!::ReadFile(m_hFile, lpBuf, nCount, pdwRead, NULL)) {
				return FALSE;
			}
	        
			return TRUE;
		}
		//---------------------------------------------------------------------------
		BOOL Write(LPCVOID lpBuf, DWORD nCount) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
			/*DEBUG*/XASSERT_RET(lpBuf!=NULL, FALSE);
			/*DEBUG*/XASSERT_RET(!::IsBadReadPtr(lpBuf, nCount), FALSE);   
	        
			if (nCount == 0) {
				return TRUE; // avoid Win32 "null-write" option
			}
	        
			DWORD dwBytesWritten = 0;
			if (!::WriteFile(m_hFile, lpBuf, nCount, &dwBytesWritten, NULL)) {
				return FALSE;
			}
	        
			return TRUE;
		}
		//---------------------------------------------------------------------------
		BOOL Write(LPCVOID lpBuf, DWORD nCount, LPDWORD pdwWritten) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
			/*DEBUG*/XASSERT_RET(lpBuf, FALSE);
			/*DEBUG*/XASSERT_RET(!::IsBadReadPtr(lpBuf, nCount), FALSE);
			/*DEBUG*/XASSERT_RET(pdwWritten, FALSE); 
	        
			*pdwWritten = 0;
			if (nCount == 0) {
				return TRUE; // avoid Win32 "null-write" option
			}
			if (!::WriteFile(m_hFile, lpBuf, nCount, pdwWritten, NULL)) {
				return FALSE;
			}
	        
			return TRUE;
		}
		//---------------------------------------------------------------------------
		DWORD Seek(LONG lOff, UINT nFrom) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::SetFilePointer(m_hFile, lOff, NULL, (DWORD) nFrom);
		}
		//---------------------------------------------------------------------------
		DWORD GetPosition() const {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::SetFilePointer(m_hFile, 0, NULL, FILE_CURRENT);
		}
		//---------------------------------------------------------------------------
		BOOL Lock(DWORD dwOffset, DWORD dwSize) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::LockFile(m_hFile, dwOffset, 0, dwSize, 0);
		}
		//---------------------------------------------------------------------------
		BOOL Unlock(DWORD dwOffset, DWORD dwSize) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::UnlockFile(m_hFile, dwOffset, 0, dwSize, 0);
		}
		//---------------------------------------------------------------------------
		BOOL SetEOF() {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::SetEndOfFile(m_hFile);
		}
		//---------------------------------------------------------------------------
		BOOL Flush() {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::FlushFileBuffers(m_hFile);
		}
		//---------------------------------------------------------------------------
		DWORD GetSize() const {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::GetFileSize(m_hFile, NULL);
		}
		//---------------------------------------------------------------------------
		DWORD GetType() const {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::GetFileType(m_hFile);
		}
		//---------------------------------------------------------------------------
		BOOL GetFileTime(FILETIME* ftCreate, FILETIME* ftAccess, FILETIME* ftModified) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::GetFileTime(m_hFile, ftCreate, ftAccess, ftModified);
		}
		//---------------------------------------------------------------------------
		BOOL SetFileTime(FILETIME* ftCreate, FILETIME* ftAccess, FILETIME* ftModified) {
			/*DEBUG*/XASSERT_RET(m_hFile!=INVALID_HANDLE_VALUE, FALSE);
	        
			return ::SetFileTime(m_hFile, ftCreate, ftAccess, ftModified);
		}
		//---------------------------------------------------------------------------
		BOOL DuplicateHandle(HANDLE hOther) {
			ATLASSERT(m_hFile==INVALID_HANDLE_VALUE, FALSE);
			ATLASSERT(hOther!=INVALID_HANDLE_VALUE, FALSE);
	        
			HANDLE process = ::GetCurrentProcess();
			BOOL res = ::DuplicateHandle(process, hOther, process, &m_hFile, NULL, FALSE, DUPLICATE_SAME_ACCESS);
			/*DEBUG*/XASSERT_RET(res, FALSE);
	        
			return res;
		}
		//---------------------------------------------------------------------------
		// Static members

		//---------------------------------------------------------------------------
		static BOOL FileExists(LPCTSTR pstrFileName) {
			/*DEBUG*/XASSERT_RET(!::IsBadStringPtr(pstrFileName, MAX_PATH), FALSE);
	        
			DWORD dwErrMode = ::SetErrorMode(SEM_FAILCRITICALERRORS);
			DWORD dwAttribs = ::GetFileAttributes(pstrFileName);
			::SetErrorMode(dwErrMode);
	        
			return (dwAttribs != (DWORD) -1) && (dwAttribs & FILE_ATTRIBUTE_DIRECTORY) == 0;
		}
		//---------------------------------------------------------------------------
		static BOOL Delete(LPCTSTR pstrFileName) {
			/*DEBUG*/XASSERT_RET(!::IsBadStringPtr(pstrFileName, MAX_PATH), FALSE);
	        
			return ::DeleteFile(pstrFileName);
		}
		//---------------------------------------------------------------------------
		static BOOL Rename(LPCTSTR pstrSourceFileName, LPCTSTR pstrTargetFileName) {
			/*DEBUG*/XASSERT_RET(!::IsBadStringPtr(pstrSourceFileName, MAX_PATH), FALSE);
			/*DEBUG*/XASSERT_RET(!::IsBadStringPtr(pstrTargetFileName, MAX_PATH), FALSE);
	        
			return ::MoveFile(pstrSourceFileName, pstrTargetFileName);
		}
		//---------------------------------------------------------------------------
};
//---------------------------------------------------------------------------
typedef CFileT<true>  CFile;
typedef CFileT<false> CFileHandle;
//---------------------------------------------------------------------------
#endif