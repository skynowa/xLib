/****************************************************************************
*	�����  CXLog (CXLog.hpp) (C++Builder 6.0)
*
*****************************************************************************/


//---------------------------------------------------------------------------
class CXCriticalSection {
        CRITICAL_SECTION m_CriticalSection;
		
    public:
        CXCriticalSection();
        ~CXCriticalSection();
        void Enter();
        bool TryEnter();
        void Leave();
		
    private:
        const CXCriticalSection& operator = (const CXCriticalSection&);
        CXCriticalSection(const CXCriticalSection&);
};
//---------------------------------------------------------------------------
CXCriticalSection::CXCriticalSection() {
    ::InitializeCriticalSection(&m_CriticalSection);
}
//---------------------------------------------------------------------------
CXCriticalSection::~CXCriticalSection() {
    ::DeleteCriticalSection(&m_CriticalSection);
}
//---------------------------------------------------------------------------
void CXCriticalSection::Enter() {
    ::EnterCriticalSection(&m_CriticalSection);
}
//---------------------------------------------------------------------------
bool CXCriticalSection::TryEnter() {
    return TryEnterCriticalSection(&m_CriticalSection) != FALSE;
}
//---------------------------------------------------------------------------
void CXCriticalSection::Leave() {
    ::LeaveCriticalSection(&m_CriticalSection);
}
//---------------------------------------------------------------------------




/****************************************************************************
*	����� CXScopeLocker
*
*****************************************************************************/


//---------------------------------------------------------------------------
class CXScopeLocker {  
        CXCriticalSection &m_CritSection;
		
    public:
        CXScopeLocker(CXCriticalSection &a_critSect);
        ~CXScopeLocker();
		
    private:
        CXScopeLocker();
        const CXScopeLocker& operator = (const CXScopeLocker&);
        CXScopeLocker(const CXScopeLocker&);
};
//---------------------------------------------------------------------------
CXScopeLocker::CXScopeLocker(CXCriticalSection &a_critSect) : m_CritSection(a_critSect) {
    m_CritSection.Enter();
}
//---------------------------------------------------------------------------
CXScopeLocker::~CXScopeLocker() {
    m_CritSection.Leave();
}
//---------------------------------------------------------------------------



/****************************************************************************
*	�������������
*
*****************************************************************************/
/*
�� � � ������ �������:
void InitDefaultConfig(t_P4LT_Config* pP4LTConfig) {
	static CXCriticalSection g_CS;
	CXScopeLocker SL(g_CS);
	//.....
}
*/