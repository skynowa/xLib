/****************************************************************************
* Class name:  CXSmtp
* Description: Pop3 ������ (RFC 2821)
* File name:   CXSmtp.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXSmtpH 
#define CXSmtpH 
//---------------------------------------------------------------------------
#include "WSocket.h"
#include <windows.h>
#include <string>
//---------------------------------------------------------------------------
class CXSmtp { 
		_NO_COPY(CXSmtp);
		
	public: 
                    	    CXSmtp     (); 
                    	   ~CXSmtp     (); 
		bool                bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); 
		bool                bConnect   ();
	   //bool               bIsConnected ();
		bool                bLogin     (); 
		bool                bSendRaw   (const std::string &csFilePath, const std::string &csFrom, const std::string &csTo); 
		bool                bSend      (const std::string &csText, const std::string &sFrom, const std::string &sTo);
		bool                bDisconnect(); 

	private: 
		WSocket             m_scktSocket; 
		std::string         m_sUser; 
		std::string         m_sPass; 
		std::string         m_sServer; 
		USHORT              m_usPort; 

		static const size_t ms_cuiRecvSize = 32768;
		CHAR                m_szRecv[ms_cuiRecvSize + 1];

		INT				    iSmtpSend  (LPSTR pszInBuff, INT iInBuffSize, INT iFlags); 
		bool                bIsError   (const std::string &csText); 
}; 
//---------------------------------------------------------------------------
#endif 
