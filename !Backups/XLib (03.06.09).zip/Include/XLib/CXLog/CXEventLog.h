/****************************************************************************
* Class name:  CXEventLog
* Description: ����������� ����� "Event Log"
* File name:   CXEventLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:52:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXEventLogH
#define CXEventLogH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXEventLog {
		_NO_COPY(CXEventLog);

	public:
		CXEventLog();
	   ~CXEventLog();
};
//---------------------------------------------------------------------------
#endif
