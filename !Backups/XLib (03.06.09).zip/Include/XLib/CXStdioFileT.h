/****************************************************************************
* Class name:  CXStdioFileT
* Description: ������ � �������
* File name:   CXStdioFileT.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef	CXStdioFileH
#define	CXStdioFileH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <stdio.h>
//---------------------------------------------------------------------------
template<bool T>
class CXStdioFileT {
	public:
		//file position data for the given stream
		typedef enum {
			fpBegin = SEEK_SET,	
			fpCurr  = SEEK_CUR,	
			fpEnd   = SEEK_END,
			fpError = -1L	
		} EFilePosition;	
		
		//mode for file buffering
		typedef enum {
			bmFull = _IOFBF, 
			bmLine = _IOLBF, 
			bmNo   = _IONBF	 
		} EBufferingMode;
	
		 	               CXStdioFileT        ();	/*+*/
		 	              ~CXStdioFileT        ();	/*+*/
		operator           FILE*              ();	/*+*/
		
		FILE              *pGetFile           ();
		BOOL               bOpen              (const std::string &csFilePath, const std::string &csMode);	/*+*/
		BOOL               bReopen            (const std::string &csFilePath, const std::string &csMode);	/*+*/
		size_t             uiRead             (LPVOID pvBuf, size_t uiCount); /*+*/
		size_t             uiWrite            (const LPVOID pcvBuff, size_t uiCount); /*+*/
		BOOL               bSetPosition       (LONG lOffset, EFilePosition fpPos/* = fpBegin*/); /*+*/
		LONG               liGetPosition      (); /*+*/
		BOOL               bClose             (); /*+*/
		BOOL               bFlush             (); /*+*/
		LONG               liGetSize          (); /*+*/
		BOOL               bSetVBuff          (LPSTR pszBuff, EBufferingMode bmMode, size_t uiSize); /*+*/
		
		BOOL               bReadLine          (LPSTR pszStr, size_t uiMaxSize); /*+*/
		BOOL               bWriteLine         (const std::string &csStr, size_t uiSize = EOF); /*+*/		

		BOOL               bWriteChar         (CHAR cChar); /*+*/
		BOOL               bWriteString       (const std::string &csStr); /*+*/
		CHAR               cGetChar           (); /*+*/ 
		BOOL               bUngetChar         (CHAR cChar); /*+*/		
		
		//Character input/output:
		static CHAR        cGetCharFromStdin   ();
		static std::string sGetStringFromStdin (LPSTR pszBuff);
		static BOOL        bWriteCharToStdout  (CHAR cChar); 
		static BOOL        bWriteStringToStdout(const std::string &csStr);

		//Operations on files:
		static BOOL        bIsFile            (const std::string &csFilePath); /*+*/
		static BOOL        bRemove            (const std::string &csFilePath); /*+*/
		static BOOL        bRename            (const std::string &csOldFilePath, const std::string &csNewFilePath); /*+*/
        static std::string sCreateTempFileName(); /*+*/
		static BOOL        bFlushAllOutput    (); /*+*/

		//Formatted input/output:
		INT                iFprintf           (LPCSTR pcszFormat, ...); /*+*/
		INT                iFscanf            (LPCSTR pcszFormat, ...); /*+*/
		static INT         iPrintf            (LPCSTR pcszFormat, ...); /*+*/
		static INT         iScanf             (LPCSTR pcszFormat, ...); /*+*/
		static INT         iSprintf           (LPSTR  pszStr,  LPCSTR pcszFormat, ...); /*+*/
		/**/static INT         iSscanf            (LPCSTR pcszStr, LPCSTR pcszFormat, ...); /*-*/
		INT                iVfprintf          (LPCSTR pcszFormat, va_list arg); /*+*/
		static INT         iVprintf           (LPCSTR pcszFormat, va_list arg); /*+*/
		static INT         iVsprintf          (LPSTR  pszStr, LPCSTR pcszFormat, va_list arg); /*+*/

		//Error-handling:
		BOOL               bClearErr          (); /*+*/
		BOOL               bIsEof             (); /*+*/
		BOOL               bIsError           (); /*+*/	
		static BOOL        bPrintError        (const std::string &csStr); /*+*/		

		//Macros
		//EOF			End-of-File (constant)
		//FILENAME_MAX	Maximum length of file names (constant)
		//TMP_MAX		Number of temporary files (constant)

	private:
		FILE              *m_pFile;
		
		INT vfscanf(FILE *pFile, LPCSTR format, va_list argList) {
			return fscanf(pFile, format, * (void **) argList);
		}
		static INT vscanf(LPCSTR format, va_list argList) {
			return scanf(format, * (void **) argList);
		}
		static INT vsscanf(LPCSTR pcszStr, LPCSTR format, va_list argList) {
			return sscanf(pcszStr, format, * (void **) argList);
		}
};
//---------------------------------------------------------------------------
#endif	

#include <XLib\\CXStdioFileT.inl>
