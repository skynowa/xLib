/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

   

//---------------------------------------------------------------------------
#include <XLib/CXPop3.h> 

#include <stdio.h>   
#include <string>   
#include <iostream>
#include <XLib/xassert.h>   
#include <XLib/CXString.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------  


/****************************************************************************
*	Private methods
*
*****************************************************************************/



//---------------------------------------------------------------------------
CPop3::CPop3() {   
	WSocket::Init();   
}   
//--------------------------------------------------------------------------- 
CPop3::~CPop3() {   
	WSocket::iClean();   
}   
//--------------------------------------------------------------------------- 
 bool CPop3::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort) {   
	 m_sUser   = csUser;   
	 m_sPass   = csPass;   
	 m_sServer = csServer;   
	 m_usPort  = usPort;   

	 return true;  
 }   
//---------------------------------------------------------------------------    
 bool CPop3::bConnect() {   
     bool bRes = false;

	 //-------------------------------------
	 //Create sock   
     bRes = m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);  
	 if (false == bRes) {
		return false;
	 }
    
	 //-------------------------------------
	 //Parse domain   
     CHAR szIpAddr[16] = {0};

	 bRes = WSocket::bDnsParse(m_sServer.c_str(), szIpAddr);
	 if (false == bRes) {
		 return false;
	 }
    
	 //-------------------------------------
	 //Connect   
	 bRes = m_scktSocket.bConnect(szIpAddr, m_usPort);
	 if (false == bRes) {
		 return false;
	 }
    
	 //-------------------------------------
	 //[welcome message] 
     const INT ciRecvSize = 128;
	 CHAR szRecv[128] = {0};

     INT iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	 /*DEBUG*/XASSERT_RET(0 < iRes, false);
	 /*DEBUG*/XASSERT_RET(false == bIsError(szRecv), false); //��� "+OK"
    
#ifdef _DEBUG   
     szRecv[iRes] = '\0';   
     printf("Recv POP3 Resp: %s", szRecv);   
#endif   
    
     return true;   
 }   
//---------------------------------------------------------------------------    
bool CPop3::bLogin() {  
	INT  iRes = - 1;
	CHAR szRecv[ms_cuiRecvSize] = {0};  

	//-------------------------------------
	//[USER\r\n]
	std::string sUserCmd = "USER " + m_sUser + "\r\n";

	iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sUserCmd.size() == iRes, false);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_RET(false == bIsError(szRecv), false);

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv USER Resp: %s", szRecv);   
#endif     

	//-------------------------------------
	//[PASS\r\n]   
	std::string sPassCmd = "PASS " + m_sPass + "\r\n";

	iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sPassCmd.size() == iRes, false);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_RET(false == bIsError(szRecv), false);

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv PASS Resp: %s", szRecv);   
#endif         

	return true; 
}   
//---------------------------------------------------------------------------
bool CPop3::bList(std::vector<ULONG> &veculList) {
	/*
	+OK scan listing follows
	1 570829
	2 571012
	.
	*/
////	int  iRes = - 1; 
////	CHAR szRecv[100024];	    memset(szRecv, 0, sizeof(szRecv));  
////
////	//-------------------------------------
////	//[LIST\r\n]   
////	std::string sListCmd = "LIST\r\n";
////
////	iRes =  m_scktSocket.iSend(sListCmd.c_str(), sListCmd.size(), 0); 
////	/*DEBUG*/XASSERT_RET(sListCmd.size() == iRes);
////
////	iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
////	/*DEBUG*/XASSERT_RET(0 < iRes);
////	/*DEBUG*/XASSERT_RET(false == bIsError(szRecv));  
////	szRecv[iRes] = '\0';   
////
////#ifdef _DEBUG   
////	printf("Recv LIST Resp: %s", szRecv);   
////#endif   
////	
////	///????std::vector veculRes = vecsExplode('\r\n', std::string(szRecv));


	return false;  
}	
//---------------------------------------------------------------------------
bool CPop3::bListAt(ULONG &ulIndex) {
	//...

	return false;
}	               
//---------------------------------------------------------------------------    
bool CPop3::bStat(ULONG &ulSum, ULONG &ulSize) {   
	INT  iRes = - 1; 
	CHAR szRecv[1024] = {0};  

	//-------------------------------------
	//[LIST\r\n]   
	std::string sStatCmd = "STAT\r\n";

	iRes =  m_scktSocket.iSend(sStatCmd.c_str(), sStatCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sStatCmd.size() == iRes, false);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_RET(false == bIsError(szRecv), false);  
	szRecv[iRes] = '\0';   

	ulSum  = ulMailsSum (std::string(szRecv));
	ulSize = ulMailsSize(std::string(szRecv));

#ifdef _DEBUG   
	printf("Recv STAT Resp: %s", szRecv); 
	//+OK 2 1141841
	printf("Recv STAT Resp: MailsSum  = %u\n", ulSum); 
	printf("Recv STAT Resp: MailsSize = %u\n", ulSize);
#endif  

	return true;       
}
//---------------------------------------------------------------------------    
bool CPop3::bRetriveRaw(INT iNum, const std::string &csDirPath) {  //csDirPath ��� ����� 
	INT    iRes       = - 1;   
	FILE  *pFile      = NULL;   
	INT    iFlag      = 0;   
	   
	CHAR   szRecv[100240] = {0};

	//-------------------------------------
	//[RETR 3\r\n]
	CHAR szNum[32] = {0}; 
	sprintf(szNum, "%d", iNum);
	std::string sRetrCmd = "RETR " + std::string(szNum) + "\r\n";
    
    iRes = m_scktSocket.iSend(sRetrCmd.c_str(), sRetrCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sRetrCmd.size() == iRes, false);



	//-------------------------------------
	//(1) ������ �� ������ � ����� ����� � ����
////////	size_t uiRecvSize = 0;
////////    do {   
////////        iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
////////    	/*DEBUG*/XASSERT_RET(0 < iRes);
////////        szRecv[iRes] = '\0';   
////////
////////        //Get mail subject   
////////        if (0 == iFlag) {   
////////            iFlag = 1;   
////////            pFile = fopen((csDirPath + "/Msg_" + std::string(szNum) + ".eml").c_str(), "wb");
////////            /*DEBUG*/XASSERT_RET(NULL != pFile);
////////        }   
////////
////////#ifdef _DEBUG   
////////        ////printf("Recv RETR Resp: %s", recvbuf);   
////////#endif   
////////
////////        uiRecvSize = strlen(szRecv);   
////////        if (uiRecvSize != fwrite(szRecv, 1, uiRecvSize, pFile)) {   
////////            fclose(pFile);   
////////            return false;   
////////        }   
////////        fflush(pFile);   
////////	} 
////////	while ((char *)NULL == strstr(szRecv, "\r\n.\r\n"));   

	//-------------------------------------
	//(2) ������ �� ������ � ����� ����� � ����
	////size_t uiRecvSize = sizeof(szRecv); //1024;	  /////////---uiRecvSize = strlen(szRecv); 
	////for (;;) {   
	////	iRes = iPop3Recv(szRecv, uiRecvSize - 1, 0);   
	////	/*DEBUG*/
 ////       if (iRes < 0) {   
 ////           break;  
 ////       } 
	////	szRecv[iRes] = '\0';   

	////	//������� ����
	////	if (0 == iFlag) {   
	////		iFlag = 1;   
	////		pFile = fopen((csDirPath + "/Msg_" + std::string(szNum) + ".eml").c_str(), "wb");
	////		/*DEBUG*/XASSERT_RET(NULL != pFile);
 ////   	}   

	////	size_t uiWriteSize = fwrite(szRecv, 1, uiRecvSize, pFile); 
 ////       /*DEBUG*/XASSERT_RET(0          == ferror(pFile));
	////	/*DEBUG*/XASSERT_RET(uiRecvSize == uiWriteSize);   
 ////       if (uiWriteSize <= 0) {
 ////           break;
 ////       }   
	////	fflush(pFile); 

	////	if ((CHAR *)NULL != strstr(szRecv, "\r\n.\r\n")) {
	////		break; 
	////	}
	////} 
	

	//-------------------------------------
	//(3)
	size_t uiRecvSize = 0;
	for (;;) {   
		iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
		/*DEBUG*/XASSERT_RET(0 < iRes, false);
		szRecv[iRes] = '\0';   

		//Get mail subject   
		if (0 == iFlag) {   
			iFlag = 1;   
			std::string _sFilePath = "/Msg_" + std::string(szNum) + ".eml";

			pFile = fopen((csDirPath + "/" + _sFilePath).c_str(), "wb");
			/*DEBUG*/XASSERT_RET(NULL != pFile, false);
		}   

		uiRecvSize = strlen(szRecv); 
		size_t uiWriteSize = fwrite(szRecv, 1, uiRecvSize, pFile); 
		/*DEBUG*/XASSERT_RET(0          == ferror(pFile), false);
		/*DEBUG*/XASSERT_RET(uiRecvSize == uiWriteSize, false); 
		fflush(pFile);  

		if ((LPSTR)NULL != strstr(szRecv, "\r\n.\r\n")) {
			break; 
		}
	}   




    /*DEBUG*/XASSERT_RET(NULL != pFile, false);
    if (NULL != pFile) {
        fflush(pFile);	
		fclose(pFile);	pFile = NULL;
    }

    return true;  
}   
//---------------------------------------------------------------------------   
bool CPop3::bDisconnect() {   
	INT iRes = - 1;
  
	CHAR        szRecv[ms_cuiRecvSize] = {0};  
	std::string sQuitCmd = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sQuitCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                  false);
	/*DEBUG*/XASSERT_RET(false == bIsError(szRecv), false);

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", szRecv);   
#endif     

	m_scktSocket.iClose();   

	return true; 
}   
//---------------------------------------------------------------------------   
bool CPop3::bGetSubject(LPSTR pszSubject, LPCSTR pcszBuf) {   
    LPCSTR p = strstr(pcszBuf, "Subject: ");   
	if (NULL == p) {  
        return false; 
	}
    
    p = p + 9;   
    for (int i = 0; i < 32; i ++) {   
        if (p[i] == '\r' || p[i] == '\n') {   
            pszSubject[i] = '\0';   
            break;   
        }  

        pszSubject[i] = p[i];   
    }   
    
    return true;   
}   
//---------------------------------------------------------------------------   
////int CPop3::iGetMailSum(const char *pcszBuff) {   
////	INT         iSum = 0;   
////	LPCSTR      p    = strstr(pcszBuff, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	p = strstr(p + 2, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	while (NULL != (p = strstr(p + 2, "\r\n"))) {   
////		iSum ++;   
////	}   
////
////	return iSum;   
////}
//---------------------------------------------------------------------------
ULONG CPop3::ulMailsSum(const std::string &csServerAnswer) {
	//+OK 2 1141841
	ULONG       ulSum = 0;   
	std::string sSum  = ""; 
	
	sSum  = vecsSplit(' ', csServerAnswer).at(1); 
	ulSum = atol(sSum.c_str());		//!!! ul -> l
	
	return ulSum;
}
//---------------------------------------------------------------------------
ULONG CPop3::ulMailsSize(const std::string &csServerAnswer) {
	//+OK 2 1141841
	ULONG       ulSize = 0;   
	std::string sSize  = ""; 

	sSize  = vecsSplit(' ', csServerAnswer)[2]; 
	ulSize = atol(sSize.c_str());	//!!! ul+\r\n -> l

	return ulSize;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
INT CPop3::iPop3Recv(LPSTR pszInBuff, INT iInBuffSize, INT iFlags) {   
	/*DEBUG*/XASSERT_RET(NULL != pszInBuff, - 1);
	/*DEBUG*/XASSERT_RET(0     < iInBuffSize, - 1);

	INT iRes   = - 1;   
	INT iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iRecv(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		if (iRes < 0) {  
			/*DEBUG*/XASSERT_RET(false, - 1);
			return - 1;   
		}

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((LPSTR)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
bool CPop3::bIsError(const std::string &sText) {
	/*DEBUG*/XASSERT_RET(true == !sText.empty(), false);

	//-------------------------------------
	//CHECK
	if (true == sText.empty()) {
		return true;
	}    

	//-------------------------------------
	//JOB
	if (0 == memcmp(sText.c_str(), "+OK", 3)) {
		return false;
	} 
	if (0 == memcmp(sText.c_str(), "-ERR", 4)) {
		return true;
	} 
	
	/*DEBUG*/XASSERT_RET(false, true);
	
	return true;
}
//---------------------------------------------------------------------------