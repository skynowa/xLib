#include <windows.h>
#include <richedit.h>
#include <string>


/*namespace*/class NMsgBoxRtf {
	#define ID_staImg    200
	#define ID_redtText  201
	#define ID_btnAbort  202
	#define ID_btnRetry  203
	#define ID_btnIgnore 204
	
	
	      INT iRes          = 0;
	
	enum ERes {None, Abort, Retry, Ignore};

	const INT iLeft         = 200;
	const INT iTop          = 150;
	const INT iWidth        = 240;
	const INT iHeight       = 150;

	const INT iBtnWidth     = 75;
	const INT iBtnHeight    = 25;
	const INT iBtnShift     = 100;
	const INT iRichEdtShift = 68;

	HWND        g_hMainWnd   = NULL;
	HINSTANCE   g_hInst      = NULL;
	HFONT       g_hFont      = NULL;
	HWND        g_hStaImg    = NULL;	
	HWND        g_hRedtText  = NULL;	
	HWND	    g_hBtnAbort  = NULL;	
	HWND	    g_hBtnRetry  = NULL;	
	HWND	    g_hBtnIgnore = NULL;	

	std::string g_sTitle     = ""; 
	std::string g_sMessage   = ""; 
	//---------------------------------------------------------------------------
	void vCreateDlgContent(HWND hParent) {
		g_hFont = (HFONT)::SendMessage(g_hMainWnd, WM_GETFONT, 0, 0);

		//-------------------------------------
		//������
		g_hStaImg = ::CreateWindowEx(
							0x00000000, 
							"Static", 
							"ID_staImg", 
							WS_CHILD | WS_VISIBLE | SS_ICON | SS_CENTER | SS_RIGHT | SS_CENTERIMAGE | SS_NOTIFY, 
							16, 16, 56, 40, 
							hParent, 
							(HMENU)ID_staImg, 
							g_hInst, 
							NULL
					);
		::SendMessage(g_hStaImg, WM_SETFONT, (WPARAM)g_hFont, TRUE);
		::SendMessage(g_hStaImg, STM_SETICON, (WPARAM)::LoadIcon(NULL, IDI_ERROR), 0);

		//-------------------------------------
		//��������� ���� (RICHEDIT)
		g_hRedtText = ::CreateWindowEx(
							0x00000000, 
							"RICHEDIT", 
							"", 
							WS_CHILD | WS_VISIBLE | ES_LEFT | ES_MULTILINE | ES_WANTRETURN | ES_READONLY, 
							88, 8, 368, 200, 
							hParent, 
							(HMENU) ID_redtText, 
							g_hInst, 
							NULL
						);
		::SendMessage(g_hRedtText, EM_SETBKGNDCOLOR, 0, ::GetSysColor(COLOR_3DFACE));
		::SendMessage(g_hRedtText, WM_SETFONT, (WPARAM)g_hFont, TRUE);

		CHARRANGE cr = {0};
		cr.cpMin = ::GetWindowTextLength(g_hRedtText);
		cr.cpMax = ::GetWindowTextLength(g_hRedtText);

		::SendMessage(g_hRedtText, EM_EXSETSEL, 0, (LPARAM) &cr);
		::SendMessage(g_hRedtText, EM_REPLACESEL, (WPARAM)/*bCanUndo*/FALSE, (LPARAM)g_sMessage.c_str());

		//-------------------------------------
		//������ "Abort"
		g_hBtnAbort = ::CreateWindowEx(
							0x00000000, 
							"Button", 
							"Abort", 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							96, 216, iBtnWidth, iBtnHeight, 
							hParent, 
							(HMENU) ID_btnAbort, 
							g_hInst, 
							NULL
						);
		::SendMessage(g_hBtnAbort, WM_SETFONT, (WPARAM)g_hFont, TRUE);

		//-------------------------------------
		//������ "Retry"
		g_hBtnRetry = ::CreateWindowEx(
							0x00000000, 
							"Button", 
							"Retry", 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							200, 216, iBtnWidth, iBtnHeight, 
							hParent, 
							(HMENU) ID_btnRetry, 
							g_hInst, 
							NULL
						);
		::SendMessage(g_hBtnRetry, WM_SETFONT, (WPARAM)g_hFont, TRUE);

		//-------------------------------------
		//������ "Ignore"
		g_hBtnIgnore = ::CreateWindowEx(
							0x00000000, 
							"Button", 
							"Ignore", 
							WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP, 
							304, 216, iBtnWidth, iBtnHeight,
							hParent, 
							(HMENU) ID_btnIgnore, 
							g_hInst, 
							NULL
						);			
		::SendMessage(g_hBtnIgnore, WM_SETFONT, (WPARAM)g_hFont, TRUE);
	}
	//---------------------------------------------------------------------------
	BOOL CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) {
		switch(message)	{
			case WM_INITDIALOG:
				{
					vCreateDlgContent(hDlg);
				}
				return TRUE;

			case WM_CLOSE:
				{
				    ::EndDialog(hDlg,0);
				}
				return TRUE;

			case WM_COMMAND:
				switch (LOWORD(wParam))	{
					case ID_btnAbort:
						{
							//::SendMessage(hDlg, WM_CLOSE, 0, 0);
							iRes = Abort;
							::SendMessage(hDlg, WM_CLOSE, 0, 0);
						}
						return TRUE;
					case ID_btnRetry:
						{
							iRes = Retry;
							::SendMessage(hDlg, WM_CLOSE, 0, 0);
						}
						return TRUE;
					case ID_btnIgnore:
						{
							iRes = Ignore;
							::SendMessage(hDlg, WM_CLOSE, 0, 0);
						}
						return TRUE;
						
					default:
						{
							iRes = None;
							::SendMessage(hDlg, WM_CLOSE, 0, 0);
						}						
						return TRUE;
				}
				
				return FALSE;
			}

		return FALSE;
	}
	//---------------------------------------------------------------------------
	LRESULT MsgBoxRtf(HINSTANCE hinst, HWND hwndOwner, const std::string &csMessage, const std::string &csTiltle) {
		HMODULE hmRichEdtDll = ::LoadLibrary("RICHED32.DLL");

		HGLOBAL           hgbl  = INVALID_HANDLE_VALUE;
		LPDLGTEMPLATE     lpdt  = {0};
		LPDLGITEMTEMPLATE lpdit = {0};;
		LPWORD            lpw   = NULL;
		LPWSTR            lpwsz = NULL;
		LRESULT           ret   = NULL;
		int               nchar = - 1;

		hgbl = ::GlobalAlloc(GMEM_ZEROINIT, 1024);
		if (NULL == hgbl) {
			return - 1;
		}

		lpdt = (LPDLGTEMPLATE)::GlobalLock(hgbl);

		//-------------------------------------
		//Define a dialog box
		lpdt->style = WS_POPUP | WS_BORDER | WS_SYSMENU | DS_MODALFRAME | WS_CAPTION;
		lpdt->cdit = 0;         // Number of controls
		lpdt->x  = iLeft;  
		lpdt->y  = iTop;
		lpdt->cx = iWidth; 
		lpdt->cy = iHeight;

		lpw = (LPWORD)(lpdt + 1);
		*lpw++ = 0;             // No menu
		*lpw++ = 0;             // Predefined dialog box class (by default)

		lpwsz = (LPWSTR)lpw;
		nchar = 1 + ::MultiByteToWideChar(CP_ACP, 0, csTiltle.c_str(), -1, lpwsz, 50);
		lpw += nchar;

		g_sTitle     = csTiltle; 
		g_sMessage   = csMessage; 

		::GlobalUnlock(hgbl); 
		ret = ::DialogBoxIndirect(hinst, (LPDLGTEMPLATE)hgbl, hwndOwner, (DLGPROC)DialogProc); 
		::GlobalFree(hgbl); 

		::FreeLibrary(hmRichEdtDll);

		return /*ret*/iRes; 
	}
	//---------------------------------------------------------------------------


	//MsgBoxRtf(g_hInst, NULL, sRTF, "���������");
}
