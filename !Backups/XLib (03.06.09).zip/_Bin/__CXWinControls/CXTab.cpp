/**********************************************************************
*	����� CXTab (CXTab.cpp)
*
***********************************************************************/


#include <XLib/CXWinControls/CXTab.h>
//---------------------------------------------------------------------------
CXTab::CXTab() {	
	_m_sClassName = WC_TABCONTROL;
	_m_iLeft      = 0;
	_m_iTop       = 0;
	_m_iWidth     = 650;
	_m_iHeight    = 350;	
}
//---------------------------------------------------------------------------
BOOL CXTab::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	vStartCommonControls(ICC_TAB_CLASSES);

	_m_hWnd = ::CreateWindowEx(
						dwExStyles, 
						_m_sClassName.c_str(), 
						NULL, 
						WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS | dwStyles,  
						_m_iLeft,	
						_m_iTop,	 
						_m_iWidth, 
						_m_iHeight, 
						hParent,	 
						(HMENU)hmnuID,			
						(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
						this); 

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------
void CXTab::vInsertTab(HWND /*hParent*/, HMENU /*hmnuID*/, LPSTR lpCaption, int iPos, int iImage) {
	assert(bIsWindow());

	TCITEM tci;		
	tci.pszText    = lpCaption;
	tci.cchTextMax = 20;
	tci.mask       = TCIF_IMAGE | TCIF_TEXT;
	tci.iImage     = iImage;
	////::SendDlgItemMessage(hParent, hmnuID, TCM_INSERTITEM, iPos, (LPARAM)&tci);
	::SendMessage(_m_hWnd, TCM_INSERTITEM, iPos, (LPARAM)&tci);			//??????????
	tci.pszText    = lpCaption;
}
//---------------------------------------------------------------------------
void CXTab::vAddDlg(HWND hPageDlg, int nPos) {
	assert(bIsWindow());

	RECT rect;		
	::GetClientRect(_m_hWnd, &rect);
	::SendMessage(_m_hWnd, TCM_ADJUSTRECT, 0, (LPARAM)&rect);
	::MoveWindow(hPageDlg, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, FALSE);

	TCITEM tci;	 
	tci.mask   = TCIF_PARAM;
	tci.lParam = reinterpret_cast<LPARAM>(hPageDlg);
	::SendMessage(_m_hWnd, TCM_SETITEM, (WPARAM)nPos, (LPARAM)&tci);
}
//---------------------------------------------------------------------------
BOOL CXTab::bShowTab(int nPos, BOOL fShow) {	
	assert(bIsWindow());

	TCITEM tci;		
	tci.mask   = TCIF_PARAM;
	::SendMessage(_m_hWnd, TCM_GETITEM, (WPARAM)nPos, (LPARAM)&tci);
	HWND hPageDlg = reinterpret_cast<HWND>(tci.lParam);
	if (NULL != hPageDlg) {
		::ShowWindow  (hPageDlg, ((fShow) ? SW_SHOW : SW_HIDE));
		::EnableWindow(hPageDlg, ((fShow) ? TRUE    : FALSE));
		return TRUE;
	} else {
		return FALSE;
	}
}
//---------------------------------------------------------------------------
LRESULT CXTab::iGetCurrSel() {
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, TCM_GETCURSEL, 0, 0);
}
//---------------------------------------------------------------------------
LRESULT CXTab::GetImageList()	{
	assert(bIsWindow());

	return ::SendMessage(_m_hWnd, TCM_GETIMAGELIST, NULL, NULL);
}
//---------------------------------------------------------------------------
HIMAGELIST CXTab::SetImageList(HIMAGELIST lImageList) {
	assert(bIsWindow());

// #define TCM_SETIMAGELIST        (TCM_FIRST + 3)
// #define TabCtrl_SetImageList(hwnd, himl) \
// 		(HIMAGELIST)SNDMSG((hwnd), TCM_SETIMAGELIST, 0, (LPARAM)(HIMAGELIST)(himl))

	return (HIMAGELIST)::SendMessage(_m_hWnd, TCM_SETIMAGELIST, (WPARAM)NULL, (LPARAM)lImageList);
}
//---------------------------------------------------------------------------
