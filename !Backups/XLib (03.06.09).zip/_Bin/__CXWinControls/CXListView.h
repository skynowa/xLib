/****************************************************************************
*	CXListView
*
*****************************************************************************/


#ifndef CXListView_H
#define CXListView_H
//---------------------------------------------------------------------------
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
class CXListView : public CXSubclassWnd {
	private:
		int           m_ColumnCount;
		int           m_ItemCount;
		HIMAGELIST    m_hLargeImageList; //image list for icon view 
		HIMAGELIST    m_hSmallImageList; //image list for other views 
	
	public:
		LVHITTESTINFO m_HitTestInfo;

		              CXListView              ();
		BOOL          Create                  (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);
		HIMAGELIST    LargeImageList          ();
		HIMAGELIST    SmallImageList          ();
		int           GetColumnCount          ();
		int           GetItemCount            ();
		void          View                    (UINT View);
		UINT          View                    ();
		int           AddSmallIcon            (HICON Icon);
		int           AddLargeIcon            (HICON Icon);
		BOOL          RemoveAllIcons          ();
		HICON         GetSelectedIcon         (BOOL Small);
		int           GetFirstSelectedIndex   ();
		void          SelectItem              (int Index);
		BOOL          AddColumn               (string Text);
		BOOL          AddColumn               (string Text, int Width);
		BOOL          DeleteColumn            (int Index);
		int           AddItem                 (string Text);
		int           AddItem                 (string Text, LPARAM lParam);
		int           AddItem                 (string Text, LPARAM lParam, int Image);
		BOOL          SetItem                 (string Text, int Index, int SubItem);
		BOOL          SetItem                 (string Text, int Index, int SubItem, int Image);
		BOOL          DeleteAllItems          ();
		BOOL          SortItems               (PFNLVCOMPARE pfnCompare, LPARAM lParamSort);
		BOOL          SetColumnWidth          (int Column, int Width);
		int           HitTest                 (LPLVHITTESTINFO pinfo);
		void          AutoSizeColumns         ();
		BOOL          Arrange                 ();
		BOOL          Arrange                 (UINT Code);
		int           GetSelectedCount        ();
		LPARAM        GetItemParam            (int Index);
		LPARAM        GetSelectedItemParam    ();
		POINT         GetOrigin               ();
		BOOL          Scroll                  (int x, int y);
		int           GetTopIndex             ();
		BOOL          EnsureVisible           (int Index, BOOL PartialOK);
		void          SetExtendedListViewStyle(DWORD ExStyle);
		int           HitTest                 (int x, int y);
		int           SubItemHitTest          (int x, int y);
		string        GetItemText             (int Item, int SubItem);
		BOOL          GetColumnOrderArray     (int *Order);
		BOOL          SetColumnOrderArray     (int *Order);
		HWND          GetHeader               ();

		void          (*OnNMClick)            (LPNMITEMACTIVATE lpnmitem);
		void          (*OnItemChanged)        (LPNMLISTVIEW pNMLV);
		void          (*OnColumnClick)        (LPNMLISTVIEW pNMLV);
};
//---------------------------------------------------------------------------
#endif
