/****************************************************************************
*	CXApp
*
*****************************************************************************/


#include <XLib/CXWinControls/CXApp.h>
//---------------------------------------------------------------------------
CXApp::CXApp() {
	_m_hInstance  = NULL;
	_m_sClassName = "CXApp";
	_m_hIcon      = NULL;
	_m_hAccel     = NULL;
	_m_iWidth     = 544;
	_m_iHeight    = 375;
	_m_iTop       = _m_iLeft = CW_USEDEFAULT;
}
//---------------------------------------------------------------------------
//Create the window
BOOL CXApp::Create(HINSTANCE hInstance, INT nCmdShow) {
	WNDCLASSEX wincl;	//Data structure for the windowclass

	//The Window structure
	wincl.hInstance     = hInstance;		
	wincl.lpszClassName = _m_sClassName.c_str();
	wincl.lpfnWndProc   = (WNDPROC)StatiCXWndProc;	//This function is called by windows
	wincl.style         = CS_DBLCLKS;				//Catch double-clicks
	wincl.cbSize        = sizeof(WNDCLASSEX);

	//Use default icon and mouse-pointer
	wincl.hIcon         = _m_hIcon;	//LoadIcon (hInstance, 0);
	wincl.hIconSm       = NULL;		//LoadIcon (hInstance, 0);
	wincl.hCursor       = NULL;		//LoadCursor (NULL, IDC_ARROW);
	wincl.lpszMenuName  = NULL;
	wincl.cbClsExtra    = 0;		//No extra bytes after the window class
	wincl.cbWndExtra    = 0;		//structure or the window instance
	wincl.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);

	//Register the window class, and if it fails quit the program
	if (!RegisterClassEx(&wincl)) {
		return false;
	} 

	//The class is registered, let's create the program
	_m_hWnd = ::CreateWindowEx(
				0,								//Extended possibilites for variation
				_m_sClassName.c_str(),			//Classname
				_m_sText.c_str(),				//Title Text
				/*WS_OVERLAPPEDWINDOW |*/ DS_CENTER | WS_MINIMIZEBOX | WS_POPUP | WS_CAPTION | WS_SYSMENU,			//default window
				_m_iLeft, _m_iTop, _m_iWidth,	//The programs width
				_m_iHeight,						//and height in pixels
				HWND_DESKTOP,					//The window is a child-window to desktop
				_m_hMenu,						//Menu
				hInstance,						//Program Instance handler
				this);							//Pointer to the current class
	
	if (_m_hWnd == NULL) {
		return false;
	} 

	HFONT hFont = CreateFont(13, 0, 0, 0, 0, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Tahoma");
	::SendMessage(_m_hWnd, WM_SETFONT, (WPARAM)hFont, 1);

	//Make the window visible on the screen
	ShowWindow(_m_hWnd, nCmdShow);

	return true;
}
//---------------------------------------------------------------------------
//Runs the window (waits for messages and processes them)
void CXApp::Run() {
	MSG messages; //Here messages to the application are saved

	while (GetMessage(&messages, NULL, 0, 0)) {
		if (NULL != _m_hAccel && TranslateAccelerator(_m_hWnd, _m_hAccel, &messages)) {
			continue;
		} 
		//Translate virtual-key messages into character messages
		TranslateMessage(&messages);
		//Send message to WindowProcedure
		DispatchMessage(&messages);
	}
}
//---------------------------------------------------------------------------
HICON CXApp::Icon() {
	return _m_hIcon;
}
//---------------------------------------------------------------------------
void CXApp::Icon(HICON hIcon) {
	_m_hIcon = hIcon;
}
//---------------------------------------------------------------------------
HACCEL CXApp::Accelerators() {
	return _m_hAccel;
}
//---------------------------------------------------------------------------
void CXApp::Accelerators(HACCEL hAccel) {
	_m_hAccel = hAccel;
}
//---------------------------------------------------------------------------
BOOL CXApp::IsMaximized() {
	return IsZoomed(_m_hWnd);
	}
//---------------------------------------------------------------------------
void CXApp::vProcessMessages() {
	MSG msg;
	while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}
}
//---------------------------------------------------------------------------