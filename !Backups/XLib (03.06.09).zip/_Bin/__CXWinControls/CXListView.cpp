/****************************************************************************
*	CXListView
*
*****************************************************************************/


#include <XLib/CXWinControls/CXListView.h>
//---------------------------------------------------------------------------
CXListView::CXListView() {
	_m_sClassName = WC_LISTVIEW;
	_m_iLeft      = 0;
	_m_iTop       = 0;
	_m_iWidth     = 200;
	_m_iHeight    = 200;
	m_ColumnCount = 0;
	m_ItemCount   = 0;
	OnNMClick     = NULL;
	OnItemChanged = NULL;
	OnColumnClick = NULL;
}
//---------------------------------------------------------------------------
BOOL CXListView::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	vStartCommonControls(ICC_LISTVIEW_CLASSES);

	_m_hWnd = ::CreateWindowEx(
						dwExStyles, 
						_m_sClassName.c_str(), 
						NULL, 
						WS_CHILD | WS_VISIBLE | WS_TABSTOP | LVS_REPORT | dwStyles,  
						_m_iLeft,	
						_m_iTop,	 
						_m_iWidth, 
						_m_iHeight, 
						hParent,	 
						(HMENU)hmnuID,			
						(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
						this); 

	if (_m_hWnd == NULL) {
		return FALSE;
	} 

	//HICON hiconItem;     //icon for list-view items 

	//Create the full-sized icon image lists. 
	m_hLargeImageList = ImageList_Create(GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), ILC_MASK | ILC_COLOR16, 1, 1);
	m_hSmallImageList = ImageList_Create(GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), ILC_MASK | ILC_COLOR16, 1, 1);

	//Add an icon to each image list.  
	/*hiconItem = NULL;//LoadIcon (NULL, IDI_APPLICATION);
	ImageList_AddIcon(hLarge, hiconItem); 
	ImageList_AddIcon(hSmall, hiconItem); 
	DestroyIcon(hiconItem); */

	ListView_SetImageList(_m_hWnd, m_hLargeImageList, LVSIL_NORMAL);
	ListView_SetImageList(_m_hWnd, m_hSmallImageList, LVSIL_SMALL);

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------
int CXListView::AddSmallIcon(HICON Icon) {
	return ImageList_AddIcon(m_hSmallImageList, Icon);
}
//---------------------------------------------------------------------------
int CXListView::AddLargeIcon(HICON Icon) {
	return ImageList_AddIcon(m_hLargeImageList, Icon);
}
//---------------------------------------------------------------------------
BOOL CXListView::RemoveAllIcons() {
	return ImageList_RemoveAll(m_hLargeImageList) && ImageList_RemoveAll(m_hSmallImageList);
}
//---------------------------------------------------------------------------
int CXListView::GetColumnCount() {
	return m_ColumnCount;
}
//---------------------------------------------------------------------------
int CXListView::GetItemCount() {
	return m_ItemCount;
}
//---------------------------------------------------------------------------
BOOL CXListView::AddColumn(string Text) {
	return AddColumn(Text, 100);
}
//---------------------------------------------------------------------------
BOOL CXListView::AddColumn(string Text, int Width) {
	assert(bIsWindow());

	LVCOLUMN lvc;
	lvc.mask = LVCF_TEXT | LVCF_WIDTH;
	lvc.pszText = (char*)Text.c_str();
	lvc.cx = Width;

	return ListView_InsertColumn(_m_hWnd, m_ColumnCount ++, &lvc) !=  - 1;
}
//---------------------------------------------------------------------------
BOOL CXListView::DeleteColumn(int Index) {
	assert(bIsWindow());

	if (ListView_DeleteColumn(_m_hWnd, Index)) {
		m_ColumnCount --;
		return TRUE;
	} else {
		return FALSE;
	} 
}
//---------------------------------------------------------------------------
int CXListView::AddItem(string Text) {
	return AddItem(Text, 0, 0);
}
//---------------------------------------------------------------------------
int CXListView::AddItem(string Text, LPARAM lParam) {
	assert(bIsWindow());

	return AddItem(Text, lParam, 0);
}
//---------------------------------------------------------------------------
int CXListView::AddItem(string Text, LPARAM lParam, int Image) {
	assert(bIsWindow());

	LVITEM lvi;
	lvi.mask = LVIF_TEXT | LVIF_PARAM;
	lvi.iItem = m_ItemCount;
	lvi.iSubItem = 0;
	lvi.pszText = (char*)Text.c_str();
	if (lParam != 0) {
		lvi.mask |= LVIF_PARAM;
		lvi.lParam = lParam;
	}
	if (Image != 0) {
		lvi.mask |= LVIF_IMAGE;
		lvi.iImage = Image;
	}
	
	int i = ListView_InsertItem(_m_hWnd, &lvi);
	if (i !=  - 1) {
		m_ItemCount ++;
	} 
	
	return i;
}
//---------------------------------------------------------------------------
BOOL CXListView::SetItem(string Text, int Index, int SubItem) {
	return SetItem(Text, Index, SubItem, 0);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetItem(string Text, int Index, int SubItem, int Image) {
	assert(bIsWindow());

	LVITEM lvi;
	lvi.mask = LVIF_TEXT;
	lvi.iItem = Index;
	lvi.iImage = Image;
	lvi.iSubItem = SubItem;
	lvi.pszText = (char*)Text.c_str();

	return ListView_SetItem(_m_hWnd, &lvi) !=  - 1;
}
//---------------------------------------------------------------------------
BOOL CXListView::SortItems(PFNLVCOMPARE pfnCompare, LPARAM lParamSort) {
	assert(bIsWindow());

	return ListView_SortItems(_m_hWnd, pfnCompare, lParamSort);
}
//---------------------------------------------------------------------------
void CXListView::AutoSizeColumns() {
	assert(bIsWindow());

	for (int i = 0; i < m_ColumnCount; i ++) {
		ListView_SetColumnWidth(_m_hWnd, i, LVSCW_AUTOSIZE_USEHEADER);
	} 
}
//---------------------------------------------------------------------------
BOOL CXListView::DeleteAllItems() {
	assert(bIsWindow());

	return TRUE == ListView_DeleteAllItems(_m_hWnd);
}
//---------------------------------------------------------------------------
int CXListView::GetSelectedCount() {
	assert(bIsWindow());

	return ListView_GetSelectedCount(_m_hWnd);
}
//---------------------------------------------------------------------------
LPARAM CXListView::GetItemParam(int Index) {
	assert(bIsWindow());

	LVITEM lvi;
	lvi.iItem = Index;
	lvi.iSubItem = 0;
	lvi.mask = LVIF_PARAM;
	if (ListView_GetItem(_m_hWnd, &lvi)) {
		return lvi.lParam;
	} else {
		return 0;
	} 
}
//---------------------------------------------------------------------------
LPARAM CXListView::GetSelectedItemParam() {
	assert(bIsWindow());

	int iSelIndex = ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
	if (- 1 == iSelIndex) {
		return 0;
	}

	return GetItemParam(iSelIndex);
}
//---------------------------------------------------------------------------
POINT CXListView::GetOrigin() {
	assert(bIsWindow());

	POINT p;
	ListView_GetOrigin(_m_hWnd, &p);

	return p;
}
//---------------------------------------------------------------------------
BOOL CXListView::Scroll(int x, int y) {
	assert(bIsWindow());

	return ListView_Scroll(_m_hWnd, x, y) == TRUE;
}
//---------------------------------------------------------------------------
int CXListView::GetTopIndex() {
	assert(bIsWindow());

	return ListView_GetTopIndex(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXListView::EnsureVisible(int Index, BOOL PartialOK) {
	assert(bIsWindow());

	return ListView_EnsureVisible(_m_hWnd, Index, PartialOK) == TRUE;
}
//---------------------------------------------------------------------------
void CXListView::SetExtendedListViewStyle(DWORD ExStyle) {
	assert(bIsWindow());

	ListView_SetExtendedListViewStyle(_m_hWnd, ExStyle);
}
//---------------------------------------------------------------------------
void CXListView::View(UINT View) {
	assert(bIsWindow());

	LONG nStyle = ::GetWindowLong(_m_hWnd, GWL_STYLE);
	if ((nStyle &LVS_TYPEMASK) != View) {
		::SetWindowLong(_m_hWnd, GWL_STYLE, (nStyle &~LVS_TYPEMASK) | View);
	} 
}
//---------------------------------------------------------------------------
UINT CXListView::View() {
	assert(bIsWindow());

	return ::GetWindowLong(_m_hWnd, GWL_STYLE) &LVS_TYPEMASK;
}
//---------------------------------------------------------------------------
int CXListView::HitTest(int x, int y) {
	assert(bIsWindow());

	m_HitTestInfo.pt.x = x;
	m_HitTestInfo.pt.y = y;
	
	return ListView_HitTest(_m_hWnd, &m_HitTestInfo);
}
//---------------------------------------------------------------------------
int CXListView::SubItemHitTest(int x, int y) {
	m_HitTestInfo.pt.x = x;
	m_HitTestInfo.pt.y = y;
	return ListView_SubItemHitTest(_m_hWnd, &m_HitTestInfo);
}
//---------------------------------------------------------------------------
string CXListView::GetItemText(int Item, int SubItem) {
	assert(bIsWindow());

	CHAR sText[1024];
	ListView_GetItemText(_m_hWnd, Item, SubItem, sText, 1024);

	return string(sText);
}
//---------------------------------------------------------------------------
BOOL CXListView::Arrange() {
	return Arrange(LVA_DEFAULT);
}
//---------------------------------------------------------------------------
BOOL CXListView::Arrange(UINT Code) {
	assert(bIsWindow());

	return ListView_Arrange(_m_hWnd, Code);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetColumnWidth(int Column, int Width) {
	assert(bIsWindow());

	return ListView_SetColumnWidth(_m_hWnd, Column, Width);
}
//---------------------------------------------------------------------------
BOOL CXListView::GetColumnOrderArray(int *Order) {
	assert(bIsWindow());

	if (Order == NULL) {
		Order = new int[m_ColumnCount];
	} 
	
	return ListView_GetColumnOrderArray(_m_hWnd, m_ColumnCount, Order);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetColumnOrderArray(int *Order) {
	return ListView_SetColumnOrderArray(_m_hWnd, m_ColumnCount, Order);
}
//---------------------------------------------------------------------------
HIMAGELIST CXListView::LargeImageList() {
	return m_hLargeImageList;
}
//---------------------------------------------------------------------------
HIMAGELIST CXListView::SmallImageList() {
	return m_hSmallImageList;
}
//---------------------------------------------------------------------------
HICON CXListView::GetSelectedIcon(BOOL Small) {
	assert(bIsWindow());

	int iSelIndex = ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
	if (iSelIndex ==  - 1) {
		return 0;
	} 

	LVITEM lvi;
	lvi.iItem = iSelIndex;
	lvi.iSubItem = 0;
	lvi.mask = LVIF_IMAGE;
	if (!ListView_GetItem(_m_hWnd, &lvi)) {
		return 0;
	} 

	HICON Icon = ImageList_GetIcon(Small ? m_hSmallImageList : m_hLargeImageList, lvi.iImage, ILD_NORMAL);

	return Icon;
}
//---------------------------------------------------------------------------
int CXListView::GetFirstSelectedIndex() {
	assert(bIsWindow());

	return ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
}
//---------------------------------------------------------------------------
void CXListView::SelectItem(int Index) {
	assert(bIsWindow());

	ListView_SetItemState(_m_hWnd, Index, LVNI_SELECTED, LVNI_SELECTED);
}
//---------------------------------------------------------------------------
int CXListView::HitTest(LPLVHITTESTINFO pinfo) {
	assert(bIsWindow());

	return ListView_HitTest(_m_hWnd, pinfo);
}
//---------------------------------------------------------------------------
HWND CXListView::GetHeader() {
	assert(bIsWindow());

	return ListView_GetHeader(_m_hWnd);
}
//---------------------------------------------------------------------------