/****************************************************************************
* Class name:  CXSmtp
* Description: SMTP ������ (RFC 2821)
* File name:   CXSmtp.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

    
//---------------------------------------------------------------------------
#include <XLib/CXSmtp.h> 

#include <stdio.h>   
#include <string>   
#include <iostream> 
#include <XLib/CXFsoString.h> 
#include <XLib/CXLog.h> 
#include <XLib/xassert.h> 

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------  


/****************************************************************************
*	Public methods
*
*****************************************************************************/

//---------------------------------------------------------------------------
CXSmtp::CXSmtp() {   
	WSocket::Init();   
}   
//--------------------------------------------------------------------------- 
CXSmtp::~CXSmtp() {   
	WSocket::iClean();   
}   
//--------------------------------------------------------------------------- 
bool CXSmtp::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort) {   
	m_sUser   = csUser;   
	m_sPass   = csPass;   
	m_sServer = csServer;   
	m_usPort  = usPort;   

	return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bConnect() {   
    bool bRes = false;

	//-------------------------------------
	//Create sock   
    bRes = m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);   
	if (false == bRes) {
		return false;
	}
    
	//-------------------------------------
	//Parse domain   
    CHAR szIpAddr[16] = {0};
	
	bRes = WSocket::bDnsParse(m_sServer.c_str(), szIpAddr);
	if (false == bRes) {   
        return false;   
	}
    
	//-------------------------------------
	//Connect   
	bRes = m_scktSocket.bConnect(szIpAddr, m_usPort);
	if (false == bRes) {  
        return false;   
	}
    
    //-------------------------------------
	//[welcome message]   
    CHAR szRecv[ms_cuiRecvSize] = {0}; 

    INT iRecv = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRecv,                            false);
    /*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);
    
#ifdef _DEBUG   
    szRecv[iRecv] = '\0';   
    printf("Recv SMTP  Resp: %s", szRecv);   
#endif   
   
    return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bLogin() {   
    INT  iRes = - 1;
    CHAR szRecv[ms_cuiRecvSize] = {0};  

    //-------------------------------------
    //[USER\r\n]
    std::string sUserCmd = "USER " + m_sUser + "\r\n";

    iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sUserCmd.size() == iRes, false);

    iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
    /*DEBUG*/XASSERT_RET(0 < iRes, false);
    /*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);
  
#ifdef _DEBUG   
    szRecv[iRes] = '\0';   
    printf("Recv USER Resp: %s", szRecv);   
#endif     
        
    //-------------------------------------
    //[PASS\r\n]   
    std::string sPassCmd = "PASS " + m_sPass + "\r\n";

    iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sPassCmd.size() == iRes, false);
    
    iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
    /*DEBUG*/XASSERT_RET(0 < iRes, false);
    /*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);
        
#ifdef _DEBUG   
    szRecv[iRes] = '\0';   
    printf("Recv PASS Resp: %s", szRecv);   
#endif         
    
    return true;   
}   
//---------------------------------------------------------------------------    
bool CXSmtp::bSendRaw(const std::string &sFilePath, const std::string &sFrom, const std::string &sTo) {   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_scktSocket, false);
	/*DEBUG*/XASSERT_RET(false == sFrom.empty(),         false); 
	/*DEBUG*/XASSERT_RET(false == sTo.empty(),		     false); 
	
	INT         iRes  = - 1;   

 	CHAR        szSend[1024 + 1]       = {0};  
	CHAR        szRecv[ms_cuiRecvSize] = {0}; 

	std::string sHelloCmd = "HELO\r\n";
	std::string sFromCmd  = "MAIL FROM:<" + sFrom + ">\r\n";
	std::string sToCmd    = "RCPT TO:<"   + sTo   + ">\r\n";
	std::string sDataCmd  = "DATA\r\n";
	std::string sEndCmd   = "\r\n.\r\n";

	//-------------------------------------
	//[HELO\r\n]
	iRes = m_scktSocket.iSend(sHelloCmd.c_str(), sHelloCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sHelloCmd.size() == iRes, false);

	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);

	//-------------------------------------
	//[MAIL FROM:<my_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sFromCmd.c_str(), sFromCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sFromCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);
	
	//-------------------------------------	
	//[RCPT TO:<your_mail@mail.ru>\r\n]
	iRes = m_scktSocket.iSend(sToCmd.c_str(), sToCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sToCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);	
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);
	
	//-------------------------------------
	//[DATA\r\n]
	iRes = m_scktSocket.iSend(sDataCmd.c_str(), sDataCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sDataCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);

	//-------------------------------------
	//������ �� ����� � ����� ����� � �����
	FILE *pFile = fopen(sFilePath.c_str(), "r");
	/*DEBUG*/XASSERT_RET(NULL != pFile, false);
	
        	size_t uiSendSize = sizeof(szSend); //1024;
        	for (;;) {
        		size_t uiReadSize = fread(szSend, 1, uiSendSize, pFile); 
        		/*DEBUG*/XASSERT_RET(0 == ferror(pFile), false);
                if (uiReadSize <= 0) {
        			break;
        		}

        		iRes = m_scktSocket.iSend(szSend, uiReadSize, 0);   
        		/*DEBUG*/XASSERT_RET(uiReadSize == iRes, false);
        		if (iRes < 0) {   
        			break;  
        		} 
        	}

	/*DEBUG*/XASSERT_RET(NULL != pFile, false);   
	if (NULL != pFile) {
		fclose(pFile);	pFile = NULL;
	}
	
	//-------------------------------------
	//[\r\n.\r\n]
	iRes = m_scktSocket.iSend(sEndCmd.c_str(), sEndCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sEndCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0); 
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);

	return true;   
}   
//---------------------------------------------------------------------------   
bool CXSmtp::bDisconnect() {   
	INT iRes = - 1;
  
	CHAR        szRecv[ms_cuiRecvSize] = {0};  
	std::string sQuitCmd               = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sQuitCmd.size() == iRes, false);
    
	iRes = m_scktSocket.iRecv(szRecv, sizeof(szRecv) - 1, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes, false);
	/*DEBUG*/XASSERT_EX_RET(false == bIsError(szRecv), szRecv, false);

#ifdef _DEBUG   
	szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", szRecv);   
#endif     

	m_scktSocket.iClose();   

	return true;   
}   
//---------------------------------------------------------------------------   



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
INT CXSmtp::iSmtpSend(LPSTR pszInBuff, INT iInBuffSize, INT iFlags) {   
	/*DEBUG*/XASSERT_RET(NULL != pszInBuff,   - 1);
	/*DEBUG*/XASSERT_RET(0     < iInBuffSize, - 1);

	INT iRes    = - 1;   
	INT iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iSend(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		if (iRes < 0) {  
			/*DEBUG*/XASSERT_RET(false, - 1);
			return - 1;   
		}

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((LPSTR)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
bool CXSmtp::bIsError(const std::string &sText) {
    /*DEBUG*/XASSERT_RET(false == sText.empty(), true);
     
    /*int iResponseCode[] =
    {
        {500, "Syntax error, command unrecognized"                            },
        {501, "Syntax error in parameters or arguments"                       },
        {502, "Command not implemented"                                       },
        {503, "Bad sequence of commands"                                      },
        {504, "Command parameter not implemented"                             },
        {211, "System status, or system help reply"                           },
        {214, "Help message"                                                  },
        {220, "<domain> Service ready"                                        },
        {221, "<domain> Service closing transmission channel"                 },
        {421, "<domain> Service not available, closing transmission channel"  },
        {250, "Requested mail action okay, completed"                         },
        {251, "User not local; will forward to <forward-path>"                },
        {252, "Cannot VRFY user, but will accept message and attempt delivery"},
        {450, "Requested mail action not taken: mailbox unavailable"          },
        {550, "Requested action not taken: mailbox unavailable"               },
        {451, "Requested action aborted: error in processing"                 },
        {551, "User not local; please try <forward-path>"                     },
        {452, "Requested action not taken: insufficient system storage"       },
        {552, "Requested mail action aborted: exceeded storage allocation"    },
        {553, "Requested action not taken: mailbox name not allowed"          },
        {554, "Transaction failed"                                            },
        {354, "Start mail input; end with <CRLF>.<CRLF>"                      }
    };*/

	bool bRes = !(
			!memcmp(sText.c_str(), "220", 3) || 
			!memcmp(sText.c_str(), "250", 3) || 
			!memcmp(sText.c_str(), "354", 3) || 
			!memcmp(sText.c_str(), "221", 3)
	);
	 
	return bRes;
}
//---------------------------------------------------------------------------