/**********************************************************************
*	CThread class
*
***********************************************************************/


#if !defined(CThreadHPP)
#define CThreadHPP
//---------------------------------------------------------------------------
#include <windows.h>
////#include <process.h>    //_beginthreadex
//---------------------------------------------------------------------------
namespace NLib {
	/****************************************************************************
	*	CThread.h
	*
	*****************************************************************************/
	
	template <class T, class P>
	class CThread {
		public:
			typedef void (T::*ThreadFunc)(P);
			
					 CThread();
			virtual ~CThread();

			//Run - Start the Thread and run the method pClass->(*pfFunc), passing p as an argument.
			//Returns true if the thread was created successfully, false otherwise
			bool bRun(T *pClass, ThreadFunc pfFunc, const P &p);	////--P p

			//Suspend - Suspends the thread (if one is active)
			void vSuspend();

			//Resume - Resumes a previously suspended thread
			void vResume();

			//Terminate - Terminates the thread (if one is active).
			//Prefer another means of exiting the thread, as
			//calling Terminate() does not allow the thread to free any resources it may hold
			void vTerminate();

			//IsThreadActive - Called in the context of another
			//(external) thread to test whether the thread is currently running
			bool bIsThreadActive() const;

		protected:
			//Static Thread Proc - The ThreadProc called by the Windows CreateThread() function.  
			//The parameter is a pointer to the thread instance that is being started.  
			static DWORD WINAPI dwStartThread(void *pvParam);

			//Handle to the created Thread
			HANDLE      m_hThread;

			//ID of the created thread
			DWORD       m_dwThreadID;

			//ThreadFunc invoketion members
			T          *m_pInstance;
			ThreadFunc	m_pfFunc;
			P			m_Param;
	};
	//---------------------------------------------------------------------------


	/****************************************************************************
	*	CThread.cpp
	*
	*****************************************************************************/

	//---------------------------------------------------------------------------
	template <class T, class P>
	CThread<T, P>::CThread() : m_hThread(NULL), m_dwThreadID((DWORD) - 1), m_pInstance(NULL), m_pfFunc(NULL) {

	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	CThread<T, P>::~CThread() {  
		if (bIsThreadActive() == true) {
			vTerminate();	
		}
	}	
	//---------------------------------------------------------------------------
	template <class T, class P>
	bool CThread<T, P>::bRun(T *pClass, ThreadFunc pfFunc, const P &param) {		////--P param
		//Store the values in this class instance so the static StartThread() function 
		//can call the appropriate method on the object
		m_pInstance = pClass;
		m_pfFunc    = pfFunc;
		m_Param     = param;

		m_hThread = ::CreateThread(NULL, 0, dwStartThread, this, 0, &m_dwThreadID);
		
		return (m_hThread != NULL);
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	void CThread<T, P>::vSuspend() {
		::SuspendThread(m_hThread);
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	void CThread<T, P>::vResume()	{
		int iResumeCount = ::ResumeThread(m_hThread);
		while (iResumeCount > 1) {
			iResumeCount = ::ResumeThread(m_hThread);
		}
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	void CThread<T, P>::vTerminate() {
        if (m_hThread) {
		    ::TerminateThread(m_hThread, 0);	//GetExitCodeThread
		    ::CloseHandle(m_hThread);
            m_hThread = NULL;
        }
    }
	//---------------------------------------------------------------------------
	template <class T, class P>
	bool CThread<T, P>::bIsThreadActive() const {
		return ((m_hThread != NULL) && (::WaitForSingleObject(m_hThread, 0) != WAIT_OBJECT_0));
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	DWORD WINAPI CThread<T, P>::dwStartThread(void *pvParam) {
		CThread *pInstance = reinterpret_cast<CThread*>(pvParam);
		if (!pInstance) {
			return (DWORD) - 1;
		}

		//Get the invoketion variables so we don't have to
		//use even more funky syntax
		T          *pClassInstance = pInstance->m_pInstance;
		ThreadFunc  pfFunc         = pInstance->m_pfFunc;
		P           param          = pInstance->m_Param;

		//We have a valid instance of the Thread class, use
		//the thread's stored parameters to call the client
		//(worker) function.  This will continue to run in
		//the context of this (seperate) thread until finished
		((*pClassInstance).*pfFunc)(param);

		return 0;
	}
}
//---------------------------------------------------------------------------
#endif