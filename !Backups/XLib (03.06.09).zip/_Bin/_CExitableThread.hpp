/**********************************************************************
*	CExitableThread class
*
***********************************************************************/


#if !defined(CExitableThreadHPP)
#define CExitableThreadHPP
//---------------------------------------------------------------------------
#include "CThread.hpp"
//---------------------------------------------------------------------------
namespace NLib {
	/****************************************************************************
	*	CExitableThread.h
	*
	*****************************************************************************/
	
	template <class T, class P>
	class CExitableThread : public CThread<T, P> {
		public:
			typedef void (T::*ThreadFunc)(P);

			         CExitableThread();
			virtual ~CExitableThread();

			//ExitThread methods - Called within the context of an
			//external thread to instruct the embedded (running) thread to exit.  
			//
			//ExitThread() - Signals the event and immediately returns.  
			//
			//ExitThreadAndWait() - Signals the event and waits 
			//until the thread actually exits or the timeout
			//expires.  Returns true if the thread exited, or
			//false if the timeout expired
			void vExit();
			bool bExitAndWait(DWORD dwTimeoutMS = 5000/*INFINITE*/);

			//IsExitEventSet - Called by the embedded (running)
			//thread to test if the exit event is set.  Returns
			//true if the event has been set, and the thread
			//should exit, and false otherwise
			bool bIsExitEventSet();
			
		protected:		
			//Handle to the Exit Event
			HANDLE m_hExitThreadEvent;
	};
	//---------------------------------------------------------------------------


	/****************************************************************************
	*	CExitableThread.cpp
	*
	*****************************************************************************/

	//---------------------------------------------------------------------------
	template <class T, class P>
	CExitableThread<T, P>::CExitableThread() : m_hExitThreadEvent(NULL)	{
		//Create the Exit Event - Should the args to CreateEvent be customizable?  
		//What should be done if CreateEvent() fails?
		//NOTE: Since we will have only one consumer of the exit event,
		//it is safe to make the event an auto-reset event
		m_hExitThreadEvent = ::CreateEvent(NULL, false, false, NULL);
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	CExitableThread<T, P>::~CExitableThread()	{
		if (m_hExitThreadEvent) {
			////--::ResetEvent(m_hExitThreadEvent);	//Nonzero if the function was successful; otherwise 0.
			::CloseHandle(m_hExitThreadEvent);
			m_hExitThreadEvent = NULL;
		}
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	void CExitableThread<T, P>::vExit()	{
		::SetEvent(m_hExitThreadEvent);
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	bool CExitableThread<T, P>::bExitAndWait(DWORD dwTimeoutMS)	{
		//Set the event telling the thread to exit
		::SetEvent(m_hExitThreadEvent);

		//Wait for the thread to actually exit
		DWORD dwResult = ::WaitForSingleObject(m_hThread, dwTimeoutMS);
		////if (dwResult != WAIT_FAILED) {
		////	DWORD dwExitCode = 0;
		////	GetExitCodeProcess(m_hThread, &dwExitCode);
	    ////}


		//////////////WAIT_TIMEOUT

		//////////////DWORD dwCode = 0;
		//////////////if (GetExitCodeThread(m_hThread, &dwCode) == 0) {	//If the function fails, the return value is zero
		//////////////	MessageBox(0, "0", "", MB_OK);
		//////////////} else {
		//////////////	if (dwCode == STILL_ACTIVE) {
		//////////////		MessageBox(0, "STILL_ACTIVE", "", MB_OK);
		//////////////	}
		//////////////}

		////////////MessageBox(0, "STILL_ACTIVE", "", MB_OK);

		//Cleanup handle
		////if (m_hThread) {
			::CloseHandle(m_hThread);
			m_hThread = NULL;
		////}

		return (dwResult == WAIT_OBJECT_0);
	}
	//---------------------------------------------------------------------------
	template <class T, class P>
	bool CExitableThread<T, P>::bIsExitEventSet()	{
		DWORD dwRes = ::WaitForSingleObject(m_hExitThreadEvent, 0);
		
		return (dwRes == WAIT_OBJECT_0);
	}
}
//---------------------------------------------------------------------------
#endif