/****************************************************************************
* Class name:  CXLog
* Description: �����������
* File name:   CXLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 10:24:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <XLib/CXSync/CXCriticalSection.h>
#include <XLib/CXConsole.h>
//---------------------------------------------------------------------------
class CXLog {
		_NO_COPY(CXLog);
		
	public:
		//Translation mode
		//typedef enum {
		//	wmFile,
		//	wmTrace,
		//	wmListBox,
		//	wmEventLog,
		//	wmDB,
		//	wmConsole
		//} EWriteMode;	

		enum ELogSizes{
			DEFAULT_MAX_LOG_SIZE = 20,
			LIMIT_LOG_SIZE       = 100
		};	
					             
								 CXLog           ();
								 CXLog           (const std::string &csFilePath, ULONG ulMaxFileSize = 20);
					            ~CXLog           ();

		BOOL                     bWriteToFile    (LPCSTR pcszFormat, ...); /*+*/
		BOOL                     bWriteToListBox (HWND hLst, LPCSTR pcszFormat, ...); /*+*/
		BOOL                     bTrace          (LPCSTR pcszFormat, ...); /*+*/
		BOOL                     bWriteToConsole (LPCSTR pcszFormat, ...); /*+*/

		BOOL                     bOpenFile       ();
		BOOL                     bClearFile      ();
		BOOL                     bDeleteFile     ();
	
	private:
		std::string              m_sLogPath;
		ULONG                    m_ulMaxFileSize;
		
		static CXCriticalSection ms_csFile;	
		static CXCriticalSection ms_csListBox;  //Mutex
		static CXCriticalSection ms_csConsole;  

		BOOL                     bDeleteFileIfFull();
};
//---------------------------------------------------------------------------
#endif