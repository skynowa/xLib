/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.cpp
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <sstream>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include <tchar.h>
#include <stdlib.h>
#include <cctype>

#include <XLib/Debug/xassert.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
//TODO: + bStrToUCHAR  
BOOL bStrToUCHAR(const std::string &csStr, UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(),     FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pucBuff,            FALSE);    
    /*DEBUG*/XASSERT_RET(0 < uiBuffSize,             FALSE); 
    /*DEBUG*/XASSERT_RET(csStr.size() <= uiBuffSize, FALSE);     

	for (UINT i = 0; i < csStr.size(); i ++)  { 
		pucBuff[i]  = static_cast<UCHAR>(csStr.at(i)); 
	}    
   
	////std::vector<unsigned char> data;
	////std::copy(csStr.begin(), csStr.end(), std::back_inserter(data));
	////pucBuff = data;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sUCHARToStr 
std::string sUCHARToStr(UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT_RET(NULL != pucBuff, "");    
    /*DEBUG*/XASSERT_RET(0 < uiBuffSize,  ""); 
	
	return std::string((CHAR *)pucBuff, uiBuffSize);
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO: + sTrimChar  
std::string sTrimChar(const std::string &csStr, CHAR chChar) {
    /*DEBUG*///not need
    
    std::string sRes;
    sRes.assign(csStr);

    while ((!sRes.empty()) && (chChar == *sRes.begin())) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (chChar == *sRes.rbegin())) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;	
}
//---------------------------------------------------------------------------
//TODO: + sTrimSpace 
std::string sTrimSpace(const std::string &csStr) {
	/*DEBUG*///not need

	return sTrimChar(csStr, ' ');
}
//---------------------------------------------------------------------------
//TODO: + sTrimLeftChar 
std::string sTrimLeftChar(const std::string &csStr, CHAR chChar) {
	/*DEBUG*///not need

	std::string sRes;
	sRes.assign(csStr);

	while ((!sRes.empty()) && (chChar == *sRes.begin())) {
		sRes.erase(sRes.begin());
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sTrimRightChar 
std::string sTrimRightChar(const std::string &csStr, CHAR chChar) {
	/*DEBUG*///not need

	std::string sRes;
	sRes.assign(csStr);

	while ((!sRes.empty()) && (chChar == *sRes.rbegin())) {
		sRes.erase(sRes.end() - 1);
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sRemoveEOL  
std::string sRemoveEOL(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes;
    sRes.assign(csStr);

	//������� \r\n
	sRes.assign(sTrimRightChar(sRes, '\n'));
	sRes.assign(sTrimRightChar(sRes, '\r'));
    
    return sRes;	
}
//---------------------------------------------------------------------------
//TODO: + sReplaceAll
std::string sReplaceAll(const std::string &csStr, const std::string &csOldStr, const std::string &csNewStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(),    "");	
    /*DEBUG*/XASSERT_RET(false == csOldStr.empty(), csStr);  

	std::string sRes;
	sRes.assign(csStr);
	
	size_t uiPos = std::string::npos;

	while (std::string::npos != (uiPos = sRes.find(csOldStr))) {
		sRes = sRes.replace(uiPos, 1, csNewStr);
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sReplaceAll  
std::string sReplaceAll(const std::string &csStr, CHAR chOldStr, CHAR chNewStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes;
    sRes.assign(csStr);
	
	for (size_t i = 0; i < sRes.size(); i ++) {
		if (sRes.at(i) == chOldStr) {
			sRes.at(i) =  chNewStr;	
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sRemoveAll
std::string sRemoveAll(const std::string &csStr, const std::string &csRemoveStr) {
	/*DEBUG*/XASSERT_RET(false == csStr.empty(),       "");
	/*DEBUG*/XASSERT_RET(false == csRemoveStr.empty(), "");

	std::string sRes;
	sRes.assign(csStr);

	size_t uiPos = std::string::npos;

	while (std::string::npos != (uiPos = sRes.find(csRemoveStr))) {
		sRes.erase(uiPos, csRemoveStr.size());
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + ��������� ������ �� ��������� �� �������-�����������, ��������� ������ ����� (vector)
std::vector<std::string> vecsSplit(const std::string &csStr, const std::string &csDelimiter) {
	/*DEBUG*/XASSERT_RET(false == csDelimiter.empty(),                       std::vector<std::string>());	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(),                             std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(csStr.substr(0, csDelimiter.size()) != csDelimiter, std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(std::string::npos != csStr.find(csDelimiter),       std::vector<std::string>());

	/*DEBUG*///XASSERT_RET(csStr.substr(csStr.size() - csDelimiter.size(), csDelimiter.size()) != csDelimiter, std::vector<std::string>());
	/*DEBUG*///////////////////XASSERT(csStr.substr(csStr.size() - csDelimiter.size(), csDelimiter.size()) != csDelimiter);

	std::vector<std::string> vescRes;
	std::size_t              uiPrevPos = 0; 	//start of string
	std::size_t              uiPos     = 0;
	
	while (std::string::npos != (uiPos = csStr.find(csDelimiter, uiPrevPos))) {
		vescRes.push_back(csStr.substr(uiPrevPos, uiPos - uiPrevPos));
		uiPrevPos = uiPos + csDelimiter.size();
	}
	vescRes.push_back(csStr.substr(uiPrevPos, csStr.size() - uiPrevPos));

	return vescRes;
}
//---------------------------------------------------------------------------
//TODO: + vecsSplitKeyValue
std::vector<std::string> vecsSplitKeyValue(const std::string &csStr, const std::string &csDelimiter) {
	/*DEBUG*/XASSERT_RET(false == csDelimiter.empty(),                       std::vector<std::string>());	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(),                             std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(csStr.substr(0, csDelimiter.size()) != csDelimiter, std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(std::string::npos != csStr.find(csDelimiter),       std::vector<std::string>());

	std::vector<std::string> vescRes;
	std::size_t              uiPrevPos = 0; 	//start of string
	std::size_t              uiPos     = 0;

	uiPos = csStr.find(csDelimiter, uiPrevPos);
	if (std::string::npos == uiPos) {
		XASSERT(FALSE);
	}	
	
	vescRes.push_back(csStr.substr(uiPrevPos, uiPos - uiPrevPos));
	uiPrevPos = uiPos + csDelimiter.size();
	
	vescRes.push_back(csStr.substr(uiPrevPos, csStr.size() - uiPrevPos));

	return vescRes;
}











//---------------------------------------------------------------------------
//TODO: + sJoin ("���������" ������ ������� ��������-������������)
std::string sJoin(const std::vector<std::string> &cvecsVec, const std::string &csDelimiter) {
	std::string sRes;


	////for (std::string::iterator itr = s.begin(); itr != s.end(); ++ itr) {
	////	if (*itr == '\\' || *itr == '!') {
	////		*itr = '/';
	////		}
	////	}
	////}
	
	size_t uiVecSize = cvecsVec.size();
	for (size_t i = 0; i < uiVecSize; i ++) {
		sRes.append(cvecsVec.at(i));   
		sRes.append(csDelimiter);           
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO:  sCut 
std::string sCut(const std::string &csStr, const std::string &csFirstLeftDelimiter, const std::string &csFirstRightDelimiter) {
	/*DEBUG*///not need
	
	//To: =?windows-1251?B?x+Di4+7w7uTt//8=?= <gfikc@meta.ua>
	std::string sRes            = "";
	size_t      uiStartDelimPos = 0;
	size_t      uiStopDelimPos  = 0;
	
	uiStartDelimPos = csStr.find(csFirstLeftDelimiter);
	CHECK_RET(std::string::npos == uiStartDelimPos, "");
	uiStartDelimPos += csFirstLeftDelimiter.size();

	uiStopDelimPos  = csStr.rfind(csFirstRightDelimiter);
	CHECK_RET(std::string::npos == uiStopDelimPos, "");
	
	CHECK_RET(uiStartDelimPos >= uiStopDelimPos, "");	
	
	sRes = csStr.substr(uiStartDelimPos, uiStopDelimPos - uiStartDelimPos);
	/*DEBUG*/XASSERT_RET(false == sRes.empty(), "");	
	
	return sRes;
}
//---------------------------------------------------------------------------
//TODO: cHexToChar
CHAR cHexToChar(CHAR *pszStr) {
    /*DEBUG*/XASSERT_RET(NULL != pszStr, '\0');        
	/*DEBUG*/XASSERT_RET('\0' != *pszStr, '\0'); 

	CHAR ch = '\0';

	if (pszStr[0] >= 'A') {
		ch = ((pszStr[0] & 0xdf) - 'A') + 10;
	} else {
		ch = pszStr[0] - '0';
	}

	ch <<= 4;

	if (pszStr[1] >= 'A') {
		ch += ((pszStr[1] & 0xdf) - 'A') + 10;
	} else {
		ch += pszStr[1] - '0';
	}

	return ch;
}
//-------------------------------------------------------------------------
//TODO: + sToLowerCase   
std::string sToLowerCase(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += (CHAR)std::tolower(csStr.at(i));
	}
		
	return sRes;

	/* 
	//explicit cast needed to resolve ambiguity
	std::transform(myString.begin(), myString.end(), myString.begin(), (int(*)(int)) std::tolower);
	*/
}
//---------------------------------------------------------------------------
//TODO: + sToUpperCase   
std::string sToUpperCase(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += (CHAR)std::toupper(csStr.at(i));
	}
		
	return sRes;

	/*
	//explicit cast needed to resolve ambiguity
	std::transform(s.begin(), s.end(), s.begin(), (int(*)(int)) std::toupper);
	return s;
	*/
}
//---------------------------------------------------------------------------
//TODO: + iCharCodeAt  
INT	iCharCodeAt(const std::string &csStr, INT iIndex) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), - 1); 
    /*DEBUG*/XASSERT_RET(0 < iIndex,             - 1); 
        
	return static_cast<INT>(csStr.at(iIndex));
}
//void SetAt(int nIndex, CT ch) {
//		ASSERT(this->size() > static_cast<MYSIZE>(nIndex));
//		this->at(static_cast<MYSIZE>(nIndex))		= ch;
//}
//---------------------------------------------------------------------------
//TODO: + bCompareNoCase2  
BOOL bCompareNoCase2(const std::string &csStr1, const std::string &csStr2) {
	CHECK_RET(csStr1.size() != csStr2.size(), FALSE);
    
	std::string sStrA;
	sStrA.assign(csStr1);
    std::string::iterator itA;

	std::string sStrB;
	sStrB.assign(csStr2);
    std::string::iterator itB;

	for (itA = sStrA.begin(), itB = sStrB.begin();	itA < sStrA.end(), itB < sStrB.end();    itA ++, itB ++) {
		if (std::tolower(*itA) != std::tolower(*itB)) {
			return FALSE;
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCompareNoCase (Compares two character strings. The comparison is not case-sensitive.) 
BOOL bCompareNoCase(const std::string &csStr1, const std::string &csStr2) {
	INT iRes = - 1;

	iRes = ::lstrcmpi(csStr1.c_str(), csStr2.c_str());
	/*DEBUG*///not need
	CHECK_RET(0 != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//This is ASCII specific but is safe with chars >= 0x80
//---------------------------------------------------------------------------
//TODO: + bIsPunctuation  
BOOL bIsPunctuation(CHAR ch) {
	return isascii(ch) && ispunct(ch);
}
//---------------------------------------------------------------------------
//TODO: + bIsADigit  
BOOL bIsADigit(CHAR ch) {
	return isascii(ch) && isdigit(ch);
}
//---------------------------------------------------------------------------
//TODO: + bIsLowerCase   
BOOL bIsLowerCase(CHAR ch) {
	return isascii(ch) && islower(ch);
}
//---------------------------------------------------------------------------
//TODO: + bIsUpperCase   
BOOL bIsUpperCase(CHAR ch) {
	return isascii(ch) && isupper(ch);
}
//---------------------------------------------------------------------------
//TODO: + bIsSpaceOrTab   
BOOL bIsSpaceOrTab(UINT ch) {
	return (ch == ' ') || (ch == '\t');
}
//---------------------------------------------------------------------------
//TODO: + bIsDigit
BOOL bIsDigit(UINT ch) {
	return (ch >= '0') && (ch <= '9');
}
//---------------------------------------------------------------------------
//TODO: + bIsDigit  
BOOL bIsDigit(UINT ch, UINT base) {
	if (base <= 10) {
		return (ch >= '0') && (ch < '0' + base);
	} else {
		return ((ch >= '0') && (ch <= '9'))            ||
		       ((ch >= 'A') && (ch < 'A' + base - 10)) ||
		       ((ch >= 'a') && (ch < 'a' + base - 10));
	}
}
//---------------------------------------------------------------------------
//TODO:  iGetHexChar
INT iGetHexChar(UCHAR hd1, UCHAR hd2) {
	int iHexValue = 0;
	
	if (hd1 >= '0' && hd1 <= '9') {
		iHexValue += 16 * (hd1 - '0');
	} else if (hd1 >= 'A' && hd1 <= 'F') {
		iHexValue += 16 * (hd1 - 'A' + 10);
	} else if (hd1 >= 'a' && hd1 <= 'f') {
		iHexValue += 16 * (hd1 - 'a' + 10);
	} else {
		return - 1;
	}

	if (hd2 >= '0' && hd2 <= '9') {
		iHexValue += hd2 - '0';
	} else if (hd2 >= 'A' && hd2 <= 'F') {
		iHexValue += hd2 - 'A' + 10;
	} else if (hd2 >= 'a' && hd2 <= 'f') {
		iHexValue += hd2 - 'a' + 10;
	} else {
		return - 1;
	}
		
	return iHexValue;
}
//---------------------------------------------------------------------------
//TODO: + bIsLetter  
BOOL bIsLetter(CHAR ch) {
	return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'));
}
//---------------------------------------------------------------------------
//TODO: + bIsSpace
BOOL bIsSpace(UINT ch) {
    return (ch == ' ') || ((ch >= 0x09) && (ch <= 0x0d));
}
//---------------------------------------------------------------------------
//TODO: + cMakeUpperCase (non-Unicode characters only)
CHAR cMakeUpperCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
		return static_cast<CHAR>(ch - 'a' + 'A');
	}
}
//---------------------------------------------------------------------------
//TODO: + cMakeLowerCase (non-Unicode characters only)
CHAR cMakeLowerCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
        return static_cast<CHAR>(ch - 'A' + 'a');
	}
}
//---------------------------------------------------------------------------
//TODO: + IsEOLChar 
BOOL IsEOLChar(CHAR ch) {
	return ('\r' == ch) || ('\n' == ch);
}
//---------------------------------------------------------------------------
//TODO: + bIsSlash 
BOOL bIsSlash(CHAR ch) {
	return ('\\' == ch) || ('/' == ch );
}
//---------------------------------------------------------------------------
//TODO: ulCountDigits (���������� ���� ��������� n) (���������)
ULONG ulCountDigits(ULONG ulDigit) {
    ULONG ulRes = 0;
    
	for (; (ulDigit /= 10); ulRes ++);
    
	return ulRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO:   
std::string sFormatStr_Depr_(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat,  "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	std::vector<CHAR> vecchBuff(128, 0);
	INT               iWrittenSize = - 1;

	va_list palArgs = NULL;
	va_start(palArgs, pcszFormat);

	for (;;) {
		//���� win32 �� ���������� _vsnprintf (��� C++Builder - vsnprintf)
		iWrittenSize = vsnprintf(&vecchBuff[0], vecchBuff.size(), pcszFormat, palArgs);	//error - 1
		/*DEBUG*/XASSERT_RET(NULL != palArgs, ""); 
		if (iWrittenSize > - 1 && iWrittenSize < (INT)vecchBuff.size()) {	//!����� ���� ������ �����!
			break; //succeeded
		}
		vecchBuff.resize(vecchBuff.size() * 2);
	}

	va_end(pcszFormat);

	return std::string(vecchBuff.begin(), vecchBuff.begin() + iWrittenSize/* - 1*/);
}
//---------------------------------------------------------------------------
//TODO: + sFormatStr
std::string sFormatStr(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat,  "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	std::string sBuff(128, '\0');
	INT         iWrittenSize = - 1;

	va_list palArgs = NULL;
	va_start(palArgs, pcszFormat);

	for (;;) {
		//���� win32 �� ���������� _vsnprintf (��� C++Builder - vsnprintf)
		iWrittenSize = vsnprintf(&sBuff[0], sBuff.size(), pcszFormat, palArgs);	//error - 1
		/*DEBUG*/XASSERT_RET(NULL != palArgs, ""); 
		
		if (iWrittenSize > - 1 && iWrittenSize < (INT)sBuff.size()) {	//!����� ���� ������ �����!
			break; //succeeded
		}
		sBuff.resize(sBuff.size() * 2);
	}

	va_end(pcszFormat);

	return std::string(sBuff.begin(), sBuff.begin() + iWrittenSize/* - 1*/);
}
//---------------------------------------------------------------------------
//TODO: + sFormatStr2
std::string sFormatStr2(LPCSTR pcszFormat, ...) {	//!������������ ������!
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	const ULONG culBufSize             = 1024;	//The maximum size of the buffer is 1024 bytes.
	CHAR        szBuff[culBufSize + 1] = {0}; 

	va_list pszArgList = NULL;
	va_start(pszArgList, pcszFormat);
	
	INT iRes = - 1;

	iRes = ::wvsprintf(szBuff, pcszFormat, pszArgList);
	szBuff[culBufSize] = '\0';
	/*DEBUG*/XASSERT_RET(::lstrlen(szBuff) == iRes, ""); 	

	va_end(pszArgList);

	return std::string(szBuff, iRes);
}
//---------------------------------------------------------------------------
//TODO: + sFormatStrV
std::string sFormatStrV(LPCSTR pcszFormat, va_list palArgs) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat,  "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	std::string sBuff(128, '\0');
	INT         iWrittenSize = - 1;

	for (;;) {
		//���� win32 �� ���������� _vsnprintf (��� C++Builder - vsnprintf)
		iWrittenSize = vsnprintf(&sBuff[0], sBuff.size(), pcszFormat, palArgs);	//error - 1
		/*DEBUG*/XASSERT_RET(NULL != palArgs, ""); 
		
		if (iWrittenSize > - 1 && iWrittenSize < (INT)sBuff.size()) {	//!����� ���� ������ �����!
			break; //succeeded
		}
		sBuff.resize(sBuff.size() * 2);
	}

	return std::string(sBuff.begin(), sBuff.begin() + iWrittenSize/* - 1*/);
}
//---------------------------------------------------------------------------
//TODO: + sMinimizeStr  
std::string sMinimizeStr(const std::string &csStr, const UINT cuiMaxLen) {	
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    /*DEBUG*/XASSERT_RET(0 < cuiMaxLen,          ""); 
	
	std::string sRes("");

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < 3) {
			sRes = csStr.substr(0, cuiMaxLen);
    	} else {
			sRes = csStr.substr(0, cuiMaxLen - 3) + "...";
		}
	} else {
		sRes.assign(csStr);
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: + sCreatePlainGUID  
std::string sCreatePlainGUID() {        //GUIDToString
	std::string sRes   = "";
	GUID        guidId = {0};
	HRESULT     hrGuid = ::CoCreateGuid(&guidId);   
	/*DEBUG*/XASSERT_RET(SUCCEEDED(hrGuid), "");

	sRes = sFormatStr(
			"%04X-%02X-%02X-%02X%02X-%02X%02X%02X%02X%02X%02X",
			guidId.Data1, 
			guidId.Data2, 
			guidId.Data3,
			guidId.Data4[0], guidId.Data4[1],
			guidId.Data4[2], guidId.Data4[3], guidId.Data4[4], guidId.Data4[5], guidId.Data4[6], guidId.Data4[7]
	);
	/*DEBUG*/XASSERT_RET(false == sRes.empty(), "");

	return sRes;	
}   
//---------------------------------------------------------------------------
//TODO: + bIsRepeatedStr
BOOL bIsRepeatedStr(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), FALSE); 
    
	size_t uiStrLen = csStr.size();
	for (size_t i = 1; i < uiStrLen; i ++) {
		if (csStr.at(0) != csStr.at(i)) {
			return FALSE;
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sLastErrorStr   
std::string sLastErrorStr(ULONG ulLastError) {
	std::string sRes;
	LPVOID      pvBuff = NULL;
	ULONG       ulRes  = 0;

	ulRes = ::FormatMessage( 
					FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
					NULL,
					ulLastError,
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
					(LPSTR) &pvBuff,
					0,
					NULL
	);
	/*DEBUG*/XASSERT_RET(0 != ulRes, "");

	sRes = sRemoveEOL(std::string((LPCSTR)pvBuff, ulRes));

	HLOCAL hRes; 
	hRes = ::LocalFree(pvBuff); 
	/*DEBUG*/XASSERT_RET(NULL == hRes, "");	
	
	return sRes;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Random
*
*****************************************************************************/

//--------------------------------------------------------------------------
//////void RandomizeTimer() {
//////	  std::srand(std::time(0));
//////}
//--------------------------------------------------------------------------


/****************************************************************************
*	�������������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: sDecode (������������� �� cp1251 � koi-8r � �������)
/*
// win -> koi
AnsiString s=decode(CP_1251,20866,org_str);

// koi -> win
AnsiString s=decode(20866,CP_1251,org_str);
*/
std::string sDecodeWinKoi(const std::string &csStr, UINT uiFrom, UINT uiTo) {
	WCHAR *pwszBuff = new WCHAR[csStr.size()];
	/*DEBUG*/XASSERT_RET(NULL != pwszBuff, "");

	::MultiByteToWideChar(uiFrom, 0, csStr.c_str(), csStr.size(), pwszBuff, csStr.size());
	::WideCharToMultiByte(uiTo, 0, pwszBuff, - 1, (LPSTR)csStr.c_str(), csStr.size(), NULL, NULL);

	delete [] pwszBuff;

	return csStr;
}
//---------------------------------------------------------------------------
//TODO: + sTranslitLatToRus   
std::string sTranslitLatToRus(const std::string &csStr) {
	/*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes("");
	sRes.assign(csStr);

	//-------------------------------------
	//�������
	const INT   ciDictSize = 66;
	std::string sDict[ciDictSize][2] = {
		{"�", "Y"}, {"�", "C"},  {"�", "U"},   {"�", "K"},	{"�", "E"}, {"�", "E"}, {"�", "N"},	
		{"�", "G"}, {"�", "SH"}, {"�", "SH'"}, {"�", "Z"},  {"�", "H"}, {"�", "`"}, {"�", "F"}, 
		{"�", "I"}, {"�", "V"},  {"�", "A"},   {"�", "P"},	{"�", "R"}, {"�", "O"}, {"�", "L"},  
		{"�", "D"}, {"�", "ZH"}, {"�", "E"},   {"�", "YA"}, {"�", "4"}, {"�", "S"}, {"�", "M"},   
		{"�", "I"}, {"�", "T"},  {"�", "'"},   {"�", "B"},  {"�", "YU"},

		{"�", "y"}, {"�", "c"},  {"�", "u"},   {"�", "k"},  {"�", "e"}, {"�", "e"}, {"�", "n"},	 
		{"�", "g"}, {"�", "sh"}, {"�", "sh'"}, {"�", "z"},	{"�", "h"}, {"�", "`"}, {"�", "f"}, 
		{"�", "i"}, {"�", "v"},  {"�", "a"},   {"�", "p"},  {"�", "r"}, {"�", "o"}, {"�", "l"},  
		{"�", "d"}, {"�", "zh"}, {"�", "e"},   {"�", "ya"}, {"�", "4"}, {"�", "s"}, {"�", "m"},  
		{"�", "i"}, {"�", "t"},  {"�", "'"},   {"�", "b"},  {"�", "yu"}
		};

	//-------------------------------------
	//������ ��������
	for (INT i = 0; i < ciDictSize; i ++) {
		sRes = sReplaceAll(sRes, sDict[i][0], sDict[i][1]);
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + bCharToWide 
BOOL bCharToWide(const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize) {
	/*DEBUG*/XASSERT_RET(NULL != pszSrc,    FALSE);        
	/*DEBUG*/XASSERT_RET('\0' != *pszSrc,   FALSE); 
	/*DEBUG*/XASSERT_RET(NULL != pwszDest,  FALSE);        
	/*DEBUG*/XASSERT_RET('\0' != *pwszDest, FALSE); 

	INT  iRes = 0;

	iRes = ::MultiByteToWideChar(CP_ACP, 0, pszSrc, - 1, pwszDest, iDestSize);
	/*DEBUG*/XASSERT_RET(0 != iRes, FALSE);

	return TRUE;		
}
//---------------------------------------------------------------------------
//TODO: + sStrToRtf  
std::string sStrToRtf(std::string sStr) {
	/*DEBUG*/XASSERT_RET(false == sStr.empty(), ""); 

	std::ostringstream    ss;
	std::string::iterator i = sStr.begin();

	while (i < sStr.end()) {
		//if ( ( ( INT ) ( unsigned char ) *i ) > 127 )
		INT c = static_cast<INT>(static_cast<UCHAR>(*i));
		if (c > 127) {
			//ss << hex << "\\\'" << ( INT ) ( unsigned char ) *i;
			ss << std::hex << "\\\'" << c;
			} else {
				//ss << ( UCHAR ) *i;
				ss << static_cast<UCHAR>( *i );
			}
		i ++;
	}

	return ss.str();
}
//---------------------------------------------------------------------------
//TODO: + sRtfToStr  
std::string sRtfToStr(std::string sStr) {
	/*DEBUG*/XASSERT_RET(false == sStr.empty(), ""); 

	std::string::size_type	resultPos = 0;
	std::string::size_type	startFind = 0;
	std::ostringstream		ss;
	CHAR					buf[]     = "ff";
	CHAR				   *resPos    = &buf[0];
	CHAR				   *pstr      = NULL;

	//Search \'xx
	while (std::string::npos != (resultPos = sStr.find("\\\'", startFind))) {
		//copy start part of string
		if (resultPos > startFind) {
			ss << sStr.substr(startFind, resultPos - startFind);
		}

		//if (end) exit
		if (resultPos + 4 > sStr.size()) {
			break;
		}

		//Copy char
		sStr.copy(buf, 2, resultPos + 2);
		LONG CharCode = strtoul(resPos, &pstr, 16);
		if (CharCode > 127) {
			ss << static_cast<UCHAR>(strtoul(resPos, &pstr, 16)); // 16 == hex base
			startFind = resultPos + 4;
		} else {
				ss << "\\\'";
				startFind = resultPos + 2;
		}
	}

	//copy end part of string
	if (startFind < sStr.size()) {
		ss << sStr.substr(startFind, sStr.size() - startFind );
	}

	return ss.str();
}
//---------------------------------------------------------------------------




/****************************************************************************
*    ������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + sSizeToStr (������������ ����� � ������)
std::string sSizeToStr(ULONG ulSize) {
	/*DEBUG*/XASSERT_RET(0 < ulSize, "");

	std::ostringstream oss;
	oss.setf(std::ios_base::fixed);

	FLOAT       fSize = 0.0;
	std::string sUnit = "";

	if (ulSize < 1000) { //1KB
		fSize = (FLOAT)ulSize;
		sUnit = " B";
	} else if (ulSize < 1000000) { //1MB
		fSize = ulSize / (FLOAT)0x400;
		sUnit = " KB";
	} 
	else if (ulSize < 1000000000) { //1GB
		fSize = ulSize / (FLOAT)0x100000;
		sUnit = " MB";
	} else {
		fSize = ulSize / (FLOAT)0x40000000;
		sUnit = " GB";
	}

	if (fSize == (INT)fSize) {
		oss.precision(0);
	} else if (fSize < 10) {
		oss.precision(2);
	} else if (fSize < 100) {
		oss.precision(1);
	} else {
		oss.precision(0);
	} 

	if (oss << fSize << sUnit) {
		return oss.str();
	} else {
		return "";
	} 
}
//--------------------------------------------------------------------------
/*
function BytesToStr(const i64Size: Int64): string;
const
  i64GB = 1024 * 1024 * 1024;
  i64MB = 1024 * 1024;
  i64KB = 1024;
begin
  if i64Size div i64GB > 0 then
    Result := Format('%.2f GB', [i64Size / i64GB])
  else if i64Size div i64MB > 0 then
    Result := Format('%.2f MB', [i64Size / i64MB])
  else if i64Size div i64KB > 0 then
    Result := Format('%.2f KB', [i64Size / i64KB])
  else
    Result := IntToStr(i64Size) + ' Byte(s)';
end;

*/


/****************************************************************************
*	��������
*
*****************************************************************************/


//--------------------------------------------------------------------------
////////tString is a TCHAR std::string
//////typedef std::basic_string<TCHAR> tString;
//////
//////
//////
//////inline tString CharToTString(const char* s)	{
//////	//Handy for converting char to TCHAR
//////	tString tstr;
//////#ifdef UNICODE
//////	int len = 1 + strlen(s);
//////
//////	TCHAR* t = new TCHAR[len];
//////	if (NULL == t) throw std::bad_alloc();
//////
//////	mbstowcs(t, s, len);
//////	tstr = t;
//////	delete []t;
//////#else
//////	tstr = s;
//////#endif
//////	return tstr;
//////}
//////
//////inline std::string TCharToString(LPCTSTR t)	{
//////	// Handy for converting TCHAR to char
//////	// If the conversion fails, an empty string is returned.
//////	std::string str;
//////#ifdef UNICODE
//////	// calculate the size of the char string required
//////	// Note: If wcstombs encounters a wide character it cannot convert
//////	//       to a multibyte character, it returns �1.
//////	int len = 1 + wcstombs(0, t, 0);
//////	if (0 == len) return str;
//////
//////	char* c = new char[len];
//////	if (NULL == c) throw std::bad_alloc();
//////	c[0] = '\0';
//////
//////	wcstombs(c, t, len);
//////	str = c;
//////	delete []c;
//////#else
//////	str = t;
//////#endif
//////	return str;
//////}

//---------------------------------------------------------------------------
//TODO:   convert path separators to forward slashes
void convert_path_separators(std::string &s) {
	for (std::string::iterator itr = s.begin(); itr != s.end(); ++ itr) {
		if (*itr == '\\' || *itr == '!') {
			*itr = '/';
		}
	}
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------

/*WrapText	��������� ������ �� ���������.*/

////////// Some ATL string conversion enhancements
////////// ATL's string conversions allocate memory on the stack, which can
////////// be undesirable if converting huge strings.  These enhancements
////////// provide for a pre-allocated memory block to be used as the 
////////// destination for the string conversion.
////////#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
////////#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)
////////
////////typedef std::wstring StringW;
////////typedef std::string  StringA;
////////
////////#ifdef _UNICODE
////////typedef StringW String;
////////#define _W2T(dst,src) lstrcpyW(dst,src)
////////#define _T2W(dst,src) lstrcpyW(dst,src)
////////#define _T2A(dst,src) _W2A(dst,src)
////////#define _A2T(dst,src) _A2W(dst,src)
////////#else
////////typedef StringA String;
////////#define _W2T(dst,src) _W2A(dst,src)
////////#define _T2W(dst,src) _A2W(dst,src)
////////#define _T2A(dst,src) lstrcpyA(dst,src)
////////#define _A2T(dst,src) lstrcpyA(dst,src)
////////#endif

/**********************************************************************
*
*   <<< ������ �������������: >>>
*   std::string str;
*   int         iVal;
*   float       fVal;
*
*   str = sTypeToStr(iVal);
*   str = sTypeToStr(fVal);
*
*   iVal = iStrToType<int>(str);
*   fVal = iStrToType<float>(str);
*
***********************************************************************/
/**********************************************************************
LARGE_INTEGER li = {1234567890};
std::stringstream ss;
ss << li;
std::string s = ss.str();
***********************************************************************/

/*
/// Return decimal code of a hex number
inline unsigned char HexCode( const char ch )
{
if ( ch > 47 && ch < 58 )
{
return ( ch - 48 );
}
else
if ( ch > 64 && ch < 71 )
{
return ( ch - 55 );
}

return 0;
}
*/

/*
string lo_case(const string & str) {
    string result;
    result.resize( str.size());
    std::transform( str.begin(), str.end(), result.begin(), tolower);
    return result;
}

void str_replace( string & str, const string & find, const string & replace) {
    size_t pos = 0;
    while ( true) {
        size_t next = str.find( find, pos);
        if ( next == string::npos) 
            break;
        str.erase( next, find.length() );
        str.insert( next, replace);
        pos = next + replace.size();
    }
}

std::string narrow(const std::wstring & str)
{
  std::string result;
  result.assign( str.begin(), str.end());
  return result;
}
std::wstring widen(const std::string & str)
{
  std::wstring result;
  result.assign( str.begin(), str.end());
  return result;
}
*/


/*
//--------------------------------------------------------------------------
ReplaceNoCase
//--------------------------------------------------------------------------
FindNoCase
//--------------------------------------------------------------------------



// -------------------------------------------------------------------------
	// Trim and its variants
	// -------------------------------------------------------------------------
	MYTYPE& Trim()
	{
		return TrimLeft().TrimRight();
	}

	MYTYPE& TrimLeft()
	{
		this->erase(this->begin(),
			std::find_if(this->begin(), this->end(), NotSpace<CT>()));

		return *this;
	}

	MYTYPE&  TrimLeft(CT tTrim)
	{
		this->erase(0, this->find_first_not_of(tTrim));
		return *this;
	}

	MYTYPE&  TrimLeft(PCMYSTR szTrimChars)
	{
		this->erase(0, this->find_first_not_of(szTrimChars));
		return *this;
	}

	MYTYPE& TrimRight()
	{
		// NOTE:  When comparing reverse_iterators here (MYRITER), I avoid using
		// operator!=.  This is because namespace rel_ops also has a template
		// operator!= which conflicts with the global operator!= already defined
		// for reverse_iterator in the header <utility>.
		// Thanks to John James for alerting me to this.

		MYRITER it = std::find_if(this->rbegin(), this->rend(), NotSpace<CT>());
		if ( !(this->rend() == it) )
			this->erase(this->rend() - it);

		this->erase(!(it == this->rend()) ? this->find_last_of(*it) + 1 : 0);
		return *this;
	}

	MYTYPE&  TrimRight(CT tTrim)
	{
		MYSIZE nIdx	= this->find_last_not_of(tTrim);
		this->erase(MYBASE::npos == nIdx ? 0 : ++nIdx);
		return *this;
	}

	MYTYPE&  TrimRight(PCMYSTR szTrimChars)
	{
		MYSIZE nIdx	= this->find_last_not_of(szTrimChars);
		this->erase(MYBASE::npos == nIdx ? 0 : ++nIdx);
		return *this;
	}

*/