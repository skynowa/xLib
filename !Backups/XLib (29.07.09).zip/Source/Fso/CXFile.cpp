/****************************************************************************
* Class name:  CXFile
* Description: �������� � ������, �������
* File name:   CXFile.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     03.06.2009 16:30:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXFile.h>

#include <vector>
#include <hash_map>
#include <map>
#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <ostream>
#include <fstream>
#include <io.h>   
#include <algorithm>
#include <iterator>
#include <ctime>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <sharc.h>

#include <XLib/CXString.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
#define RANDOMIZE() (srand((UINT)time(NULL))) 
#define RANDOM(x)   (rand() % x)

const std::string csWinSlash  = "\\";
const std::string csUnixSlash = "/";
//---------------------------------------------------------------------------
CXFile::CXFile() :
	_m_hFile(INVALID_HANDLE_VALUE)
{
}
//---------------------------------------------------------------------------
CXFile::~CXFile() { 

}
//---------------------------------------------------------------------------
BOOL CXFile::bOpen(const std::string &csFilePath, ULONG ulAccess, ULONG ulShareMode, ULONG ulFlags, ULONG ulAttributes) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
    
	////bClose();

	_m_hFile = ::CreateFile(csFilePath.c_str(), ulAccess, ulShareMode, NULL, ulFlags, ulAttributes, NULL);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bCreate(const std::string &csFilePath, ULONG ulAccess, ULONG ulShareMode, ULONG ulFlags, ULONG ulAttributes) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	return bOpen(csFilePath, ulAccess, ulShareMode, ulFlags, ulAttributes);
}
//---------------------------------------------------------------------------
BOOL CXFile::bClose() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	::CloseHandle(_m_hFile);    _m_hFile = INVALID_HANDLE_VALUE;

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bIsOpen() {
	/*DEBUG*///not need

	return INVALID_HANDLE_VALUE != _m_hFile;
}
//---------------------------------------------------------------------------
BOOL CXFile::bAttach(HANDLE hHandle) {
	/*DEBUG*///not need

	bClose();
	_m_hFile = hHandle;

	return TRUE;
}   
//---------------------------------------------------------------------------
HANDLE CXFile::bDetach() {
	/*DEBUG*///not need

	HANDLE hFile = _m_hFile;
	_m_hFile = INVALID_HANDLE_VALUE;
    
	return hFile;
}
//---------------------------------------------------------------------------
BOOL CXFile::bRead(LPVOID pvBuff, ULONG ulCount) {    
	/*DEBUG*/XASSERT_RET(_m_hFile != INVALID_HANDLE_VALUE,  FALSE);
	/*DEBUG*/XASSERT_RET(pvBuff   != NULL,                  FALSE);
	/*DEBUG*/XASSERT_RET(!::IsBadWritePtr(pvBuff, ulCount), FALSE);

	ULONG ulBytesRead = 0;
	
	if (0 == ulCount) {
		return TRUE;   // avoid Win32 "null-read"
	}

	BOOL bRes = FALSE;
    
	bRes = ::ReadFile(_m_hFile, pvBuff, ulCount, &ulBytesRead, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bRead(LPVOID pvBuf, ULONG ulCount, LPDWORD pulRead) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
	/*DEBUG*/XASSERT_RET(NULL                 != pvBuf,    FALSE);
	/*DEBUG*/XASSERT_RET(!::IsBadWritePtr(pvBuf, ulCount), FALSE);
	/*DEBUG*/XASSERT_RET(NULL                 != pulRead,  FALSE);
    
	*pulRead = 0;

	if (0 == ulCount) {
		return TRUE;   // aVOID Win32 "null-read"
	}

	BOOL bRes = FALSE;

	bRes = ::ReadFile(_m_hFile, pvBuf, ulCount, pulRead, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bWrite(LPCVOID pvBuf, ULONG ulCount) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
	/*DEBUG*/XASSERT_RET(NULL                 != pvBuf,   FALSE);
	/*DEBUG*/XASSERT_RET(!::IsBadReadPtr(pvBuf, ulCount), FALSE);   
    
	if (0 == ulCount) {
		return TRUE; // aVOID Win32 "null-write" option
	}

	BOOL bRes = FALSE;
    
	ULONG ulBytesWritten = 0;

	bRes = ::WriteFile(_m_hFile, pvBuf, ulCount, &ulBytesWritten, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bWrite(LPCVOID pvBuf, ULONG ulCount, LPDWORD pulWritten) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile,    FALSE);
	/*DEBUG*/XASSERT_RET(NULL                 != pvBuf,      FALSE);
	/*DEBUG*/XASSERT_RET(!::IsBadReadPtr(pvBuf, ulCount),    FALSE); 
	/*DEBUG*/XASSERT_RET(NULL                 != pulWritten, FALSE); 
    
	*pulWritten = 0;

	if (0 == ulCount) {
		return TRUE; // avoid Win32 "null-write" option
	}

	BOOL bRes = FALSE;

	bRes = ::WriteFile(_m_hFile, pvBuf, ulCount, pulWritten, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXFile::ulSetPosition(LONG liOff, EPointerPosition fpPos) {    
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, INVALID_SET_FILE_POINTER);
    
	ULONG ulRes = INVALID_SET_FILE_POINTER;
	
	ulRes = ::SetFilePointer(_m_hFile, liOff, NULL, (ULONG)fpPos);
	/*DEBUG*/XASSERT_RET(INVALID_SET_FILE_POINTER != ulRes, INVALID_SET_FILE_POINTER);

	return ulRes;
}
//---------------------------------------------------------------------------
ULONG CXFile::ulGetPosition() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, INVALID_SET_FILE_POINTER);
    
	return ulSetPosition(0, ppCurr);
}
//---------------------------------------------------------------------------
BOOL CXFile::bLock(ULONG ulOffset, ULONG ulSize) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	BOOL bRes = FALSE;

	bRes = ::LockFile(_m_hFile, ulOffset, 0, ulSize, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bUnlock(ULONG ulOffset, ULONG ulSize) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	BOOL bRes = FALSE;

	bRes = ::UnlockFile(_m_hFile, ulOffset, 0, ulSize, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bSetEOF() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetEndOfFile(_m_hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bFlush() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);

	BOOL bRes = FALSE;

	bRes = ::FlushFileBuffers(_m_hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXFile::ulGetSize() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
	
	ULONG ulLowPart  = 0;
	ULONG ulHighPart = 0;

	ulLowPart = ::GetFileSize(_m_hFile, &ulHighPart);
	if (INVALID_FILE_SIZE == ulLowPart) {
		/*DEBUG*/XASSERT_RET(NO_ERROR == ::GetLastError(), INVALID_FILE_SIZE);
	}

	return ((ULONGLONG)(ulHighPart) << 32) | ulLowPart;


	//////ULONG ulRes = 0;
	//////   
	//////ulRes = ::GetFileSize(_m_hFile, NULL);
	///////*DEBUG*/XASSERT_RET(INVALID_FILE_SIZE != ulRes, INVALID_FILE_SIZE);

	//////return ulRes;
}
//---------------------------------------------------------------------------
ULONG/*EFileType*/ CXFile::ulGetType() {	
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	ULONG ulRes = (ULONG)ftUnknown;

	ulRes = ::GetFileType(_m_hFile);
	/*DEBUG*/XASSERT_RET((ULONG)ftUnknown != ulRes, (ULONG)ftUnknown);

	return ulRes;
}
//---------------------------------------------------------------------------
BOOL CXFile::bGetTime(FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    
	BOOL bRes = FALSE;

	bRes = ::GetFileTime(_m_hFile, pftCreate, pftAccess, pftModified);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bSetTime(FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
 
	BOOL bRes = FALSE;

	bRes = ::SetFileTime(_m_hFile, pftCreate, pftAccess, pftModified);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFile::bDuplicateHandle(HANDLE hOther) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != _m_hFile, FALSE);
    /*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hOther,   FALSE);

	BOOL   bRes = FALSE;
 	HANDLE hProcess = ::GetCurrentProcess();

	bRes = ::DuplicateHandle(hProcess, hOther, hProcess, &_m_hFile, NULL, FALSE, DUPLICATE_SAME_ACCESS);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
    
	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Static
*
*****************************************************************************/

//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bIsExists(const std::string &csFilePath) {
	///////////*DEBUG*/XASSERT_RET(!::IsBadStringPtr(csFilePath.c_str(), MAX_PATH), FALSE);
	//////////   
	//////////ULONG ulErrMode = ::SetErrorMode(SEM_FAILCRITICALERRORS);
	//////////ULONG ulAttribs = ::GetFileAttributes(csFilePath.c_str());
	//////////::SetErrorMode(ulErrMode);
	//////////   
	//////////return (ulAttribs != (ULONG) -1) && (ulAttribs & FILE_ATTRIBUTE_DIRECTORY) == 0;

	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	ULONG ulAttr = (ULONG)faInvalid;

	ulAttr = ulGetAttr(csFilePath.c_str());

	if (faInvalid == ulAttr) {	//��� �� ���� � �� ����� � �� ...
		return FALSE;
	}
	if (ulAttr & faDirectory/*faDirectory == ulAttr*/) {	//��� �����
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bDelete(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePath), FALSE);

	BOOL bRes = FALSE;

	bRes = bSetAttr(csFilePath, faNormal);
	if (FALSE == bRes) {
		return FALSE;
	}	

	bRes = ::DeleteFile(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bMove(const std::string &csFilePathIn, const std::string &csFilePathOut) {
	/*DEBUG*/XASSERT_RET(false == csFilePathIn.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bIsExists(csFilePathIn), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePathOut.empty(), FALSE);

	//-------------------------------------
	//������� ������� "������ ������"
	if (TRUE == bIsExists(csFilePathOut)) {
		if (FALSE == bSetAttr(csFilePathOut, faNormal)) {
			return FALSE;
		}
	}
	if (FALSE == bSetAttr(csFilePathIn, faNormal)) {
		return FALSE;
	}

	//-------------------------------------
	//����������
	BOOL bRes = FALSE;

	bRes = ::MoveFile(csFilePathIn.c_str(), csFilePathOut.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXFile::sCreateTempName(const std::string &csExt) {	//csDirPath - ��� �����
	/*DEBUG*/CHAR szFatalChars[] = {'\\', '/', ':', '*', '<', '>', '|', '?', '"', '\t', '\n', '\r'};
	/*DEBUG*/for (INT i = 0; i <  sizeof(szFatalChars)/sizeof szFatalChars[0]; i ++) {
	/*DEBUG*/	XASSERT_RET(std::string::npos == csExt.find(szFatalChars[i]), "");	
	/*DEBUG*/}

	std::string sRes = "";

	if (true == csExt.empty()) {
		sRes = sCreatePlainGUID();
	} else {
		sRes = sCreatePlainGUID() + "." + csExt;
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXFile::bCopy(const std::string &csFilePathFrom, const std::string &csFilePathTo) {
	/*DEBUG*/XASSERT_RET(false == csFilePathFrom.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePathFrom), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePathTo.empty(),      FALSE);

	std::ifstream ifsStream(csFilePathFrom.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return FALSE;
	}
	std::ofstream ofsStream(csFilePathTo.c_str()); 
	if (!ofsStream || ofsStream.fail() || !ofsStream.good() || !ofsStream.is_open() || ofsStream.eof()) {
		return FALSE;
	}

	ofsStream << ifsStream.rdbuf();
	ofsStream.close();

	return TRUE;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXFile::bCopy(const std::string &csFilePathFrom, const std::string &csFilePathTo, BOOL bFailIfExists) {
	/*DEBUG*/XASSERT_RET(false == csFilePathFrom.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePathFrom), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePathTo.empty(),      FALSE);

	BOOL bRes = FALSE;

	bRes = ::CopyFile(csFilePathFrom.c_str(), csFilePathTo.c_str(), bFailIfExists);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//#define _WIN32_WINNT 0x0500
/*static*/BOOL CXFile::bReplace(const std::string &csOldFileName, const std::string &csNewFilePath, const std::string &csBackupFilePath) {
	/*DEBUG*/XASSERT_RET(false == csOldFileName.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bIsExists(csOldFileName),  FALSE);
	/*DEBUG*/XASSERT_RET(false == csNewFilePath.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bIsExists(csNewFilePath),  FALSE);
	/*DEBUG*/XASSERT_RET(false == csBackupFilePath.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::ReplaceFile(csOldFileName.c_str(), csNewFilePath.c_str(), csBackupFilePath.c_str(), REPLACEFILE_WRITE_THROUGH/* | REPLACEFILE_IGNORE_MERGE_ERRORS*/, (LPVOID)NULL, (LPVOID)NULL); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: bSecureDeleteFile
///////*I set _stklen to 512 because there shouldn't be that much going to the
//////functions and i wanted to save memory I set _fmode to binary so i
//////could take it out of the sopen statement because im lazy*/
//////extern unsigned _stklen = 512;
//////extern int      _fmode  = 0x8000;	O_BINARY
/////*static*/BOOL CXFile::bSecureDeleteFile(const std::string &csFilePath, unsigned int uiPasses) {
//////const int     ciO_BINARY    = 0x8000;
//////const int     ciO_TRUNC     = 0x0200;
//////const int     ciO_WRONLY    = 2;
//////const int     ciS_IFREG     = 0x0000;
//////const int     ciSH_DENYNO   = 0x0040;

//////const ULONG culBuffLen     = 32768;
//////const ULONG culClusterSize = 32768;

//////INT   hFile              = NULL; 
//////ULONG ulFileSize         = 0;
//////UCHAR ucBuff[culBuffLen] = {0};

////////-------------------------------------
////////CHECK
//////if (FALSE == bIsExists(csFilePath)) {
//////	return FALSE;
//////}

////////-------------------------------------
////////�������� ������� "������ ������"
//////if (FALSE == bSetAttr(csFilePath, faNormal)) {
//////	return FALSE;
//////}

////////-------------------------------------
////////�������� ������� ������
//////if (FALSE == bSetFileCompressedAttr(csFilePath, false)) {
//////	return FALSE;
//////}

////////-------------------------------------
////////����� ��������� ������ � ����, ������� �� 32kb, �������-�� ���
//////hFile = sopen(csFilePath.c_str(), O_WRONLY, SH_DENYNO, S_IFREG);
//////if (hFile ==  - 1) {
//////	close(hFile);
//////	return FALSE;
//////}

////////�������� ������ ����� � ���������� ������ ������ ��� �����
//////ulFileSize = filelength(hFile);
//////ulFileSize += (culClusterSize - (ulFileSize % culClusterSize));

//////for (UINT i = 1; i <= uiPasses; i ++) {
//////	RANDOMIZE();
//////	for (register UINT i = 0; i < ulFileSize; i += culBuffLen) {
//////		for (register ULONG j = 0; j < culBuffLen; j ++) {
//////			ucBuff[j] = random(255) + 1;
//////		}  
//////		write(hFile, ucBuff, culBuffLen);
//////	}
//////	flushall();

//////	//���������� �� ������ �����
//////	if (-1L == lseek(hFile, 0L, 0)) {
//////		close(hFile);
//////		return FALSE;
//////	}
//////}

//////close(hFile);

////////-------------------------------------
////////���������� (���� ��������/�����������/���������� ��������� � ������ ��������)
//////if (FALSE == bSetRandomFileDate(csFilePath)) {
//////	return FALSE;
//////}

////////-------------------------------------
////////������������� �������� ���� (����� ����������� ��������� ��� ����� ����� ��� MAX_PATH)
//////const INT    ciMaxPath          = 255; 
//////char         chSymbols[53]      = {'q', 'w', 'e',  'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '!', '@', '#', '$', '%', '^', '&', '(', ')', '_', '+', '�', ';', '%', '.', ',', '~'};

//////INT          iFileDirPathLen    = sExtractFileDir(csFilePath).size();
//////INT          iSlashLen          = 1;
//////std::string  sRandomFileName("");
//////UINT         uiRandomFileNameLen = ciMaxPath - iFileDirPathLen - iSlashLen;

//////CHAR *pszRandomFileName = new CHAR[uiRandomFileNameLen + 1];		
//////if (NULL == pszRandomFileName) {
//////	return FALSE;
//////}

////////������� ��� �����
//////RANDOMIZE();
//////for (register UINT i = 0; i < uiRandomFileNameLen; ) {
//////	//������� ��������� ������
//////	char chChar = random(255) + 1;
//////	//�������� �� ��� ������?
//////	for (register ULONG x = 0; x < 53; x ++) {
//////		if (chChar == chSymbols[x]) {
//////			pszRandomFileName[i] = chChar;
//////			i ++;
//////		}			
//////	}  
//////}
//////pszRandomFileName[uiRandomFileNameLen] = '\0';

//////sRandomFileName = std::string(pszRandomFileName, uiRandomFileNameLen);

////////����������� ������
///////*DEBUG*/XASSERT_RET(NULL != pszRandomFileName, FALSE);
//////if (NULL != pszRandomFileName) {
//////	delete [] pszRandomFileName;    pszRandomFileName = NULL;
//////}

////////���������������
//////std::string sFilePathOut("");
//////sFilePathOut = sExtractFileDir(csFilePath) + "\\" + sRandomFileName;
//////if (0 != rename(csFilePath.c_str(), sFilePathOut.c_str())) {
//////	return FALSE;
//////}

////////-------------------------------------
////////������� ����
//////hFile = sopen(sFilePathOut.c_str(), O_WRONLY | O_TRUNC, SH_DENYNO, S_IFREG);
//////close(hFile);

////////-------------------------------------
////////������� ����
//////if (- 1 == remove(sFilePathOut.c_str())) {
//////	return FALSE;
//////}

//////return TRUE;
////}
//--------------------------------------------------------------------------
/*static*/BOOL CXFile::bCutFromEnd(const std::string &csFilePath, LONG lDistanceToCut) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),   FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bIsExists(csFilePath), FALSE);
	/*DEBUG*/XASSERT_RET(0 < lDistanceToCut,            FALSE);

	//-------------------------------------
	//JOB
	BOOL bRes = FALSE;

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,NULL);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
	if (INVALID_SET_FILE_POINTER != ::SetFilePointer(hFile, - (lDistanceToCut), NULL, FILE_END)) {
		if (TRUE == ::SetEndOfFile(hFile)) {
			bRes = TRUE;
		}
	}

	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}


	return TRUE;
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bCutFromEnd(FILE *pFile, ULONG ulDistanceToCut) {
	/*DEBUG*/XASSERT_RET(NULL != pFile, false);
	/*DEBUG*/XASSERT_RET(0 < ulDistanceToCut, false);

	BOOL bRes = FALSE;
	
	//////////if (0 != chsize(fileno(pFile), ulFileSize(pFile) - ulDistanceToCut)) {
	//////////	return FALSE;
	//////////}

	return /*TRUE*/FALSE;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXFile::bCheckSignature(LPCSTR pcszBuff, LPCSTR pcszSignature, INT iSignatureSize) {
	/*DEBUG*/XASSERT_RET(NULL != pcszBuff,             FALSE);
	/*DEBUG*/XASSERT_RET(0 < ::lstrlen(pcszBuff),      FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pcszSignature,        FALSE);
	/*DEBUG*/XASSERT_RET(0 < ::lstrlen(pcszSignature), FALSE);
	/*DEBUG*/XASSERT_RET(0 < iSignatureSize,           FALSE);

	////const char signature[] = "\xFF\xD8\xFF\xE0\x00\x10JFIF";
	for (INT i = 0; i < iSignatureSize; i++) {
		if (pcszSignature[i] != pcszBuff[i]) {
			return FALSE;
		}
	}

	return TRUE;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXFile::bSetRandomDate(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csFilePath), FALSE);

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
	//��� ������ ����� ������� ���� FILE_FLAG_BACKUP_SEMANTICS.
	////HANDLE hFile = CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL)
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);

	//-------------------------------------
	//���� ��������
	FILETIME ftCreationTime = {0}; 
	RANDOMIZE();
	ftCreationTime.dwHighDateTime = rand();
	RANDOMIZE();
	ftCreationTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� �������
	FILETIME ftLastAccessTime = {0};  
	RANDOMIZE();
	ftLastAccessTime.dwHighDateTime = rand();
	RANDOMIZE();
	ftLastAccessTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� ���������
	FILETIME ftLastWriteTime = {0};  
	RANDOMIZE();
	ftLastWriteTime.dwHighDateTime = rand();
	RANDOMIZE();
	ftLastWriteTime.dwLowDateTime  = rand();

	//-------------------------------------
	//������ ��������
	BOOL bRes = ::SetFileTime(hFile, &ftCreationTime, &ftLastAccessTime, &ftLastWriteTime);	//(LPFILETIME)NULL  
	if (FALSE == bRes) {
		/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
		if (INVALID_HANDLE_VALUE != hFile) {
			::CloseHandle(hFile); hFile = INVALID_HANDLE_VALUE;
		}
		return FALSE;
	}

	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
	if (INVALID_HANDLE_VALUE != hFile) {
		::CloseHandle(hFile); hFile = INVALID_HANDLE_VALUE;
	}

	return TRUE;
}
//--------------------------------------------------------------------------
/*static*/ULONGLONG CXFile::ullGetCompressedSize(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	ULONG ulLowPart  = 0;
	ULONG ulHighPart = 0;
		
	ulLowPart = ::GetCompressedFileSize(csFilePath.c_str(), &ulHighPart);
	if (INVALID_FILE_SIZE == ulLowPart) {
		/*DEBUG*/XASSERT_RET(NO_ERROR == ::GetLastError(), INVALID_FILE_SIZE);
	}

	return ((ULONGLONG)(ulHighPart) << 32) | ulLowPart;
}
//--------------------------------------------------------------------------



/****************************************************************************
* ��������
*
*****************************************************************************/


//---------------------------------------------------------------------------
/*static*/ULONG CXFile::ulGetAttr(const std::string &csFilePath) { 	
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), 0);

	return ::GetFileAttributes(csFilePath.c_str());
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bSetAttr(const std::string &csFilePath, ULONG ulFileAttr) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	//������� ������� "������ ������"
	BOOL bRes = FALSE;

	bRes = ::SetFileAttributes(csFilePath.c_str(), ulFileAttr);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bSetUncompressedAttr(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	ULONG ulFileAttr = FALSE;

	//������ �������� �����
	ulFileAttr = ulGetAttr(csFilePath.c_str());
	if (faInvalid == ulFileAttr)	{
		return FALSE;
	}

	//������� ������� "������"
	if (FALSE == bSetAttr(csFilePath.c_str(), ulFileAttr | faCompressed)) {
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
/*static*/BOOL CXFile::bSetCompressedAttr(const std::string &csFilePath, BOOL bCompress) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	BOOL   bRes            = FALSE;
	HANDLE hFile           = INVALID_HANDLE_VALUE;
	SHORT  siCompression   = COMPRESSION_FORMAT_NONE;
	ULONG  ulBytesReturned = 0;
	BOOL   bForceCompress  = TRUE;

	if (FALSE != bForceCompress || (ulGetAttr(csFilePath.c_str()) && faCompressed)) {
		hFile = ::CreateFile(csFilePath.c_str(), grRead | grWrite, 0, NULL, cfOpenExisting, 0, 0);
		/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);

		if (TRUE == bCompress) {
			siCompression = COMPRESSION_FORMAT_DEFAULT;
		} else {
			siCompression = COMPRESSION_FORMAT_NONE;
		}

		bRes = ::DeviceIoControl(hFile, FSCTL_SET_COMPRESSION, &siCompression, sizeof(SHORT), NULL, 0, &ulBytesReturned, NULL);
		if (FALSE == bRes) {
			/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
			::CloseHandle(hFile); 	hFile = INVALID_HANDLE_VALUE;

			return FALSE;
		}

		/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
		::CloseHandle(hFile); 	hFile = INVALID_HANDLE_VALUE;

		return TRUE;
	} 
	
	return TRUE;
}
//--------------------------------------------------------------------------





//--------------------------------------------------------------------------
/*static*/bool CXFile::bWriteText(const std::string &csFilePath, const std::string &csText) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), false);

	bool bRes = false;

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);

	DWORD dwWrittenBytes = 0;
	BOOL bWriteRes = ::WriteFile(hFile, csText.c_str(), (DWORD)csText.size(), &dwWrittenBytes, NULL);
	if (FALSE == bWriteRes) {
		return false;
	}

	if (csText.size() != dwWrittenBytes) {
		bRes = false;
	} else {
		bRes = true;
	}

	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}

	return bRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXFile::sReadText(const std::string &csFilePath) {	///char -> BYTE
	/*
	std::string xstr;
	std::ifstream xfile("inputfile.txt", std::ios::binary);

	//������ ������ �����, � �������� ������ � ������
	xfile.seekg( 0, std::ios_base::end );
	xstr.resize( xfile.tellg() );
	xfile.seekg( 0, std::ios_base::beg );

	//�������� ������
	xfile.read( (void*)xstr.data(), xstr.size() );
	*/

	/*
	std::ifstream iFile("inputfile.txt");
	std::string mystr(std::istreambuf_iterator<char>(iFile), std::istreambuf_iterator<char>());
	*/

	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), "");
	/*DEBUG*/XASSERT_RET(TRUE == CXFile::bIsExists(csFilePath), "");

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, "");

	//-------------------------------------
	//�������� ������ �����
	DWORD dwFileSize = ::GetFileSize(hFile, NULL);
	if (0xFFFFFFFF == dwFileSize || 0 == dwFileSize) {
		/*DEBUG*/XASSERT_RET(NULL != hFile, "");
		if (NULL != hFile) {
			::CloseHandle(hFile); 	hFile = NULL;
		}

		return "";
	}

	//-------------------------------------
	//������ ����
	std::string  sRes        = "";
	ULONG        dwRealyRead = 0;
	CHAR        *pBuff       = new CHAR[dwFileSize + 1];  	
	if (NULL == pBuff) {
		::CloseHandle(hFile);

		return "";		
	}
	if (FALSE == ::ReadFile(hFile, pBuff, dwFileSize, &dwRealyRead, NULL)) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	} 
	if (dwFileSize != dwRealyRead) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	}

	//-------------------------------------
	//������ � std::string
	sRes = std::string(pBuff, dwFileSize);

	//-------------------------------------
	//��������� ���� � ������� �����3
	/*DEBUG*/XASSERT_RET(NULL != pBuff, "");
	if (NULL != pBuff) {
		delete [] pBuff;    pBuff = NULL;
	}

	/*DEBUG*/XASSERT_RET(NULL != hFile, "");
	if (NULL != hFile) {
		::CloseHandle(hFile); 	hFile = NULL;
	}    

	return sRes;
}
//--------------------------------------------------------------------------
