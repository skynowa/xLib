/****************************************************************************
* Class name:  CXIni
* Description: ������ � ini-�������
* File name:   CXIni.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.04.2009 12:10:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXIni.h>

#include <iostream>
#include <stdio.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXStdioFile.h>
//-------------------------------------------------------------------------
CXIni::CXIni(const std::string &csFileName, const std::string &csDefaultContent) {
	/*DEBUG*/XASSERT(false == csFileName.empty());        
	
	_m_sFilePath = CXPath::sChangeFullFileName(CXPath::sExePath(), csFileName);
	
	//���� INI-����� ��� - �������	
	if (false == CXStdioFile::bIsExists(_m_sFilePath)) {	//????????????
		if (false == bCreateDefaultINI(_m_sFilePath.c_str(), csDefaultContent)) {
			return;
		}
	}
}
//-------------------------------------------------------------------------
CXIni::~CXIni() {

}
//-------------------------------------------------------------------------
bool CXIni::bCreateDefaultINI(const std::string &csFilePath, const std::string &csStr) {
    /*DEBUG*/XASSERT(false == csFilePath.empty());
	
	bool bRes = false;

	FILE *pFile = fopen(csFilePath.c_str(), "w");
	/*DEBUG*/XASSERT(NULL != pFile);

	fprintf(pFile, csStr.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
	if (NULL != pFile) {
		fflush(pFile);
		fclose(pFile);	pFile = NULL;
	}

	return bRes;
}
//-------------------------------------------------------------------------

//������
//-------------------------------------------------------------------------
INT CXIni::iReadInteger(const std::string &csSection, const std::string &csKey, INT iDefaultValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty());

	INT iRes = ::GetPrivateProfileInt(csSection.c_str(), csKey.c_str(), iDefaultValue, _m_sFilePath.c_str());
	
	return iRes;
}
//-------------------------------------------------------------------------
DOUBLE CXIni::dReadFloat(const std::string &csSection, const std::string &csKey, DOUBLE dDefaultValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty());

	DOUBLE  dRes                          = 0.0;
	CHAR    szResult [_ms_ciLineSize + 1] = {0};
	CHAR    szDefault[_ms_ciLineSize + 1] = {0};
	
	::wsprintf(szDefault, "%d", dDefaultValue);
	::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), szDefault, szResult, _ms_ciLineSize, _m_sFilePath.c_str());
	dRes = atof(szResult);
	
	return dRes;
}
//-------------------------------------------------------------------------
bool CXIni::bReadBoolean(const std::string &csSection, const std::string &csKey, bool bDefaultValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty());
  
	bool bRes                          = false;
	CHAR szResult [_ms_ciLineSize + 1] = {0};
	CHAR szDefault[_ms_ciLineSize + 1] = {0};

	::wsprintf(szDefault, "%s", bDefaultValue ? "True" : "False");
	::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), szDefault, szResult, _ms_ciLineSize, _m_sFilePath.c_str());
	bRes = (0 == ::lstrcmp(szResult, "True") || 0 == ::lstrcmp(szResult, "true")) ? true : false;	//lowcase uppercase
	
	return bRes;
}
//-------------------------------------------------------------------------
std::string CXIni::sReadString(const std::string &csSection, const std::string &csKey, const std::string &csDefaultValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty());

	CHAR szBuff[_ms_ciLineSize + 1] = {0};
	
	::GetPrivateProfileString(csSection.c_str(), csKey.c_str(), csDefaultValue.c_str(), szBuff, _ms_ciLineSize, _m_sFilePath.c_str());
	
	return std::string(szBuff);
}
//-------------------------------------------------------------------------


//�����
//-------------------------------------------------------------------------
VOID CXIni::vWriteInteger(const std::string &csSection, const std::string &csKey, INT iValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty()); 

	CHAR szBuff[_ms_ciLineSize + 1] = {0};
	
	::wsprintf(szBuff, "%d", iValue);
	BOOL bWrited = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), szBuff, _m_sFilePath.c_str());
	/*DEBUG*/XASSERT(FALSE != bWrited);
}
//-------------------------------------------------------------------------
VOID CXIni::vWriteFloat(const std::string &csSection, const std::string &csKey, FLOAT fValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty());

	CHAR szBuff[_ms_ciLineSize + 1] = {0};
	
	::wsprintf(szBuff, "%f", fValue);
	BOOL bWrited = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), szBuff, _m_sFilePath.c_str());
    /*DEBUG*/XASSERT(FALSE != bWrited);
}
//-------------------------------------------------------------------------
VOID CXIni::vWriteBoolean(const std::string &csSection, const std::string &csKey, bool bBoolValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty()); 

	CHAR szBuff[_ms_ciLineSize + 1] = {0};
	
	::wsprintf(szBuff, "%s", bBoolValue ? "True" : "False");
	BOOL bWrited = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), szBuff, _m_sFilePath.c_str());
    /*DEBUG*/XASSERT(FALSE != bWrited);
}
//-------------------------------------------------------------------------
VOID CXIni::vWriteString(const std::string &csSection, const std::string &csKey, const std::string &csValue) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());
	/*DEBUG*/XASSERT(false == csKey.empty()); 

	BOOL bWrited = ::WritePrivateProfileString(csSection.c_str(), csKey.c_str(), csValue.c_str(), _m_sFilePath.c_str());
    /*DEBUG*/XASSERT(FALSE != bWrited);
}
//-------------------------------------------------------------------------
VOID CXIni::vClearSection(const std::string &csSection) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	BOOL bWrited = ::WritePrivateProfileSection(csSection.c_str(), "", _m_sFilePath.c_str());
    /*DEBUG*/XASSERT(FALSE != bWrited);
}
//-------------------------------------------------------------------------
VOID CXIni::vReadSectionsNames() {	/*-*/
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));

	CHAR szBuff[1024 + 1] = {0};
	
	::GetPrivateProfileSectionNames(szBuff, 1024, _m_sFilePath.c_str());
	//"SectionName1"0"SectionName2"0"SectionName3"
	::MessageBox(0, szBuff, "", MB_OK);
}
//-------------------------------------------------------------------------
VOID CXIni::vReadSectionKeysAndValues(const std::string &csSection) { /*-*/
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	CHAR szBuff[1024 + 1] = {0};
	
	::GetPrivateProfileSection(csSection.c_str(), szBuff, 1024, _m_sFilePath.c_str());

	//"Key1=xxx1"0"Key2=xxx2"0"Key2=xxx2"	
	::MessageBox(0, szBuff, "", MB_OK);
}
//-------------------------------------------------------------------------
ULONG CXIni::ulSectionSize(const std::string &csSection) {
	/*DEBUG*/XASSERT(false == _m_sFilePath.empty());
	/*DEBUG*/XASSERT(TRUE  == CXStdioFile::bIsExists(_m_sFilePath));
	/*DEBUG*/XASSERT(false == csSection.empty());

	ULONG      ulRes     = 0; 
	CONST UINT uiBuffLen = _ms_ciLinesPerSection * _ms_ciLineSize;
	CHAR      szBuff[uiBuffLen + 1] = {0};
	
	::GetPrivateProfileSection(csSection.c_str(), szBuff, uiBuffLen, _m_sFilePath.c_str());
	//"Key1=xxx1"0"Key2=xxx2"0"Key2=xxx2"
	
	//���� ������ ������
	if ('\0' == szBuff[0]) {
		return 0;
	} 
	
	//������ �� ������
	for (INT i = 0; i < uiBuffLen; i ++) {
		if ('\0' == szBuff[i]) {
			ulRes ++;
			
			//����� ������ '\0\0'
			if ('\0' == szBuff[i + 1]) {
				break;
			}				
		}
	}	
	
	return ulRes;
}
//-------------------------------------------------------------------------

/*
Free - ������� ������ TIniFile 
FileName - ���������� ��� �����, � ������� ������ ������ TIniFile 
DeleteKey - ������� ���� � ������� 
EraseSection - ������� ������ 
ReadInteger - ��������� �� ����� ������������� ������ 
ReadString - ��������� �� ����� ��������� ������ 
ReadBool - ��������� �� ����� ���������� (true, false) ������ 
WriteBool - ���������� � ���� ���������� ������ 
WriteString - ���������� � ���� ��������� ������ 
WriteInteger - ���������� � ���� ������������� ������ 
ReadSection - ��������� ����� ��������������� � ��������� ������� INI - ����� 
ReadSections - ��������� ��� ����� �������� 
ReadSectionValues - ��������� �� ��������� ������� ��� ����� 
ReadBinaryStream - ��������� ����� �� ����� 
WriteBinaryStream - �����
*/

/*
GetPrivateProfileInt
GetPrivateProfileSection
GetPrivateProfileSectionNames
GetPrivateProfileString
GetPrivateProfileStruct
GetProfileInt
GetProfileSection
GetProfileString
WritePrivateProfileSection
WritePrivateProfileString
WritePrivateProfileStruct
WriteProfileSection
WriteProfileString
*/