/**********************************************************************
*	�����  CXRandom (CXRandom.cpp)  
*	
***********************************************************************/


#include <XLib/CXRandom.h>
//---------------------------------------------------------------------------
CXRandom::CXRandom() {
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
CXRandom::~CXRandom() {	
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
//Init CryptoAPI for random generation
BOOL CXRandom::bInitialize() {
	return ::CryptAcquireContext(&m_hCrypt, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT);
}
//---------------------------------------------------------------------------
//Clean up CryptoAPI
BOOL CXRandom::bFinalize() {
	return ::CryptReleaseContext(m_hCrypt, 0);
}
//---------------------------------------------------------------------------
//Return a single random byte from 0x00 to 0xFF
CHAR CXRandom::cGetRandomByte() {
	CHAR cRes;
	vGetRandomBytes(sizeof(cRes), &cRes);
	
	return cRes;
}
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF
VOID CXRandom::vGetRandomBytes(INT iSize, CHAR *pszBuff) {
	::CryptGenRandom(m_hCrypt, iSize, (UCHAR *)pszBuff);
} 
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF + '\0'
VOID CXRandom::vGetRandomBytes(INT iSize, UCHAR *pucBuff) {
	::CryptGenRandom(m_hCrypt, iSize, pucBuff);
	pucBuff[iSize - 1] = '\0';
} 
//---------------------------------------------------------------------------
//Return a random integer from 0 to INT_MAX
INT CXRandom::iGetRandomInt() {
	INT iRes;
	vGetRandomBytes(sizeof(iRes), (CHAR *)&iRes);

	return iRes;
}
//---------------------------------------------------------------------------




/****************************************************************************
	������:

	int main(int argc, char* argv[]) {
		CXRandom R;
		char szBuff[8];
		
		for (int i = 0; i < 10; i ++) {
			if (FALSE == R.bInitialize()) {
				std::cout << "FALSE == R.bInitialize()" << std::endl;
			} else {
				std::cout << "TRUE == R.bInitialize()" << std::endl;
			}

			R.vGetRandomBytes(8, szBuff);
    		std::cout << szBuff << std::endl;
			
			if (FALSE == R.bFinalize()) {
				std::cout << "FALSE == R.bFinalize()" << std::endl;
			} else {
				std::cout << "TRUE == R.bFinalize()" << std::endl;
			}
		}


		system("pause");

		return 0;
	}

*****************************************************************************/