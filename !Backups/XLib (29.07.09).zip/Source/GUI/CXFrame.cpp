/****************************************************************************
* Class name:  CXFrame
* Description: ������ � ������
* File name:   CXFrame.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXFrame.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXFrame::CXFrame() {
	LOG();

	BOOL bRes = FALSE;

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXFRAME_CONTROL_CLASS;
	_m_ulStyle        = CXFRAME_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXFRAME_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = CW_USEDEFAULT;
	_m_iTop           = CW_USEDEFAULT;
	_m_iWidth         = CXFRAME_DEFAULT_WIDTH;
	_m_iHeight        = CXFRAME_DEFAULT_HEIGHT;

	//-------------------------------------
	//Set the default data for the window class.
	//These can be reset in the derived class's constructor.
	WNDCLASSEX _m_WndClass = {0};

	_m_WndClass.hInstance     = CXApplication::hGetInstance(); 	
	_m_WndClass.lpszClassName = _m_sClassName.c_str();
	_m_WndClass.lpfnWndProc   = (WNDPROC)s_BaseWndProc;		//This function is called by windows
	_m_WndClass.style         = CS_DBLCLKS;					//Catch double-clicks
	_m_WndClass.cbSize        = sizeof(WNDCLASSEX);
	_m_WndClass.hIcon         = NULL;						//_m_hIcon;	//LoadIcon (hInstance, 0);
	_m_WndClass.hIconSm       = NULL;						//LoadIcon (hInstance, 0);
	_m_WndClass.hCursor       = NULL;						//LoadCursor (NULL, IDC_ARROW);
	_m_WndClass.lpszMenuName  = NULL;
	_m_WndClass.cbClsExtra    = 0;							//256;		//No extra bytes after the window class
	_m_WndClass.cbWndExtra    = 0;							//dialog box not from resource file
	_m_WndClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);

	bRes = bRegisterClassEx(&_m_WndClass);
	////CHECK_RET(FALSE == bRes, FALSE);
}
//---------------------------------------------------------------------------
CXFrame::~CXFrame() {
	LOG();
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnCreate(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnPaint(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam){
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnNotify(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnClose(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	/*::DestroyWindow(hWnd);*/
	
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnDestroy(HWND hWnd, WPARAM wParam, LPARAM lParam) {
	/*::PostQuitMessage(0);*/
	
	return FALSE;
}
//---------------------------------------------------------------------------
/*
BEGIN_MSG_MAP(thisClass)
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)				
	MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseMove)
END_MSG_MAP()
*/
//#define HANDLE_MSG(hWnd, uiMsg, lpFunc)  case (uiMsg): this->##lpFunc((hWnd), (wParam), (lParam)); break;
/*virtual*/LRESULT CXFrame::pWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam, PBOOL pbProcessed) {
	switch (uiMsg) {
		XHANDLE_MSG(hWnd, WM_CREATE,  OnCreate);
		XHANDLE_MSG(hWnd, WM_PAINT,   OnPaint);
		XHANDLE_MSG(hWnd, WM_COMMAND, OnCommand);
		XHANDLE_MSG(hWnd, WM_NOTIFY,  OnNotify);
		XHANDLE_MSG(hWnd, WM_CLOSE,   OnClose);    
		XHANDLE_MSG(hWnd, WM_DESTROY, OnDestroy);  
		//WM_KEYDOWN
		//WM_CHAR

		default:
			*pbProcessed = FALSE;	//not processed
	}
	
	*pbProcessed = TRUE;	        //Yes, message was processed.
	
	return ::DefWindowProc(hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------