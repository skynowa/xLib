/****************************************************************************
* Class name:  CXWindow
* Description: ������ � ������
* File name:   CXWindow.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:09:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXWindow.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
//TODO: + CXWindow
CXWindow::CXWindow() :
	_m_hWnd      (0),
	_m_ulExStyle (0),
	_m_sClassName(""),
	_m_sText     (""),
	_m_ulStyle   (0),
	_m_iWidth    (0),
	_m_iHeight   (0),
	_m_iLeft     (0),
	_m_iTop      (0),
	_m_hParent   (NULL),		
	_m_iMenu     (0),
	_m_Font      (NULL)
{
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + ~CXWindow
/*virtual*/CXWindow::~CXWindow () {
	LOG();

	BOOL bRes = FALSE;
	
	/*DEBUG*/XASSERT(NULL != _m_Font);
	bRes = ::DeleteObject(_m_Font);	_m_Font = NULL;
	/*DEBUG*/XASSERT(FALSE != bRes);	
}
//---------------------------------------------------------------------------



/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsWindow
BOOL CXWindow::bIsWindow() const {
	/*DEBUG*///not need
	
	return _m_hWnd && ::IsWindow(_m_hWnd);
}
//---------------------------------------------------------------------------
//TODO: hGetHandle
HWND CXWindow::hGetHandle() { 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

    return _m_hWnd; 
}
//---------------------------------------------------------------------------
//TODO: sGetText
std::string CXWindow::sGetText() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	std::string sRes;
	
	const INT ciSize = ::GetWindowTextLength(_m_hWnd);
	if (ciSize > 0) {
		sRes.resize(ciSize + 1);
		::GetWindowText(_m_hWnd, &sRes[0], ciSize + 1);
		sRes.resize(ciSize);
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: bSetText
BOOL CXWindow::bSetText(const std::string &csText) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::SetWindowText(_m_hWnd, csText.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	
	_m_sText = csText;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bSetSize
BOOL CXWindow::bSetSize(INT iWidth, INT iHeight) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = bSetWndPos(NULL, 0, 0, iWidth, iHeight, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	CHECK_RET(FALSE != bRes, FALSE);
	
	_m_iWidth  = iWidth;
	_m_iHeight = iHeight;

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: bSetPos
BOOL CXWindow::bSetPos(INT iLeft, INT iTop) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = bSetWndPos(NULL, iLeft, iTop, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);
	CHECK_RET(FALSE != bRes, FALSE);

	_m_iLeft = iLeft;
	_m_iTop  = iTop;

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: bSetWindowPos
BOOL CXWindow::bSetWndPos(HWND hWndInsertAfter, INT iLeft, INT iTop, INT iWidth, INT iHeight, UINT uiFlags) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::SetWindowPos(_m_hWnd, hWndInsertAfter, iLeft, iTop, iWidth, iHeight, uiFlags);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	
	_m_iLeft   = iTop;
	_m_iTop    = iWidth;
	_m_iWidth  = iWidth;
	_m_iHeight = iHeight;

	return TRUE;
}
//---------------------------------------------------------------------------
RECT CXWindow::GetRect() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd,  RECT());


	RECT rectRes = {0};

	BOOL bRes = FALSE;
	bRes = ::GetWindowRect(_m_hWnd, &rectRes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, RECT());    

	return rectRes;
}
//---------------------------------------------------------------------------
BOOL CXWindow::SetRect(RECT Rect) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	_m_iWidth  = Rect.right  - Rect.left;
	_m_iHeight = Rect.bottom - Rect.top;
	_m_iLeft   = Rect.left;
	_m_iTop    = Rect.top;

	bRes = bSetWndPos(NULL, _m_iLeft, _m_iTop, _m_iWidth, _m_iHeight, SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOZORDER);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bShow
BOOL CXWindow::bShow(INT iCmdShow) {
	/*DEBUG*/////XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	INT iRes = - 1;
	/*iCmdShow
	SW_FORCEMINIMIZE
	SW_HIDE
	SW_MAXIMIZE
	SW_MINIMIZE
	SW_RESTORE
	SW_SHOW
	SW_SHOWDEFAULT
	SW_SHOWMAXIMIZED
	SW_SHOWMINIMIZED
	SW_SHOWMINNOACTIVE
	SW_SHOWNA
	SW_SHOWNOACTIVATE
	SW_SHOWNORMAL*/

	iRes = ::ShowWindow(_m_hWnd, iCmdShow);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUpdate
BOOL CXWindow::bUpdate() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::UpdateWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - SendMessage
LRESULT CXWindow::lSendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LRESULT lpRes = FALSE;

	lpRes = ::SendMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/// ??? XASSERT_RET(FALSE == (BOOL)lpRes, FALSE); 

	return lpRes;
}
//---------------------------------------------------------------------------
//TODO: + PostMessage
BOOL CXWindow::bPostMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDestroy
BOOL CXWindow::bDestroy() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::DestroyWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
	
	///::PostQuitMessage(0);
}
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL CXWindow::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return bPostMessage(WM_CLOSE, NULL, NULL);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	�����
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetFont
HFONT CXWindow::hGetFont() {
	/*DEBUG*/XASSERT_RET(NULL != _m_Font, NULL);

	return (HFONT)lSendMessage(WM_GETFONT, 0, 0);
}
//---------------------------------------------------------------------------
//TODO: + bSetFont
BOOL CXWindow::bSetFont(HFONT hFont) {
	/*DEBUG*/XASSERT_RET(NULL != hFont, NULL);

	return (BOOL)lSendMessage(WM_SETFONT, (WPARAM)hFont, TRUE);
}
//---------------------------------------------------------------------------
//TODO: + bSetDefaultFont
BOOL CXWindow::bSetDefaultFont() {
	/*DEBUG*///not need

	_m_Font = ::CreateFont(- 11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	/*DEBUG*/XASSERT_RET(NULL != _m_Font, NULL);

	return bSetFont(_m_Font);
}
//---------------------------------------------------------------------------



/****************************************************************************
*	protected
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + bInitCommonControls
BOOL CXWindow::bInitCommonControls(ULONG ulFlags) {
	BOOL bRes = FALSE;

	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = ulFlags;

	bRes = ::InitCommonControlsEx(&iccx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRegisterClassEx
BOOL CXWindow::bRegisterClassEx(const WNDCLASSEX *cpwcWndClassEx) {
	/*DEBUG*/XASSERT_RET(NULL != cpwcWndClassEx, FALSE);

	BOOL bRes = FALSE;

	bRes = ::RegisterClassEx(cpwcWndClassEx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCreateEx
BOOL CXWindow::bCreateEx(ULONG ulExStyle, const std::string &csClassName, const std::string &csText, ULONG ulStyle, 
						 INT iLeft, INT iTop, INT iWidth, INT iHeight, HWND hParent, INT iID, LPVOID lpParam)
{
	/*DEBUG*/XASSERT_RET(NULL  == _m_hWnd,             NULL);
	/*DEBUG*/XASSERT_RET(false == csClassName.empty(), NULL);

	BOOL bRes = FALSE;

	_m_hWnd = ::CreateWindowEx(_m_ulExStyle | ulExStyle, _m_sClassName.c_str(), _m_sText.c_str(), _m_ulStyle | ulStyle, iLeft, iTop, iWidth, iHeight, hParent, (HMENU)iID, CXApplication::hGetInstance(), lpParam);
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	bRes = bSetDefaultFont();
	CHECK_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_ulExStyle  = _m_ulExStyle | ulExStyle;    
	_m_sClassName = _m_sClassName;
	_m_sText      = _m_sText;
	_m_ulStyle    = _m_ulStyle | ulStyle;
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;
	_m_hParent    =	hParent;	
	_m_iMenu      = iID;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCreate
BOOL CXWindow::bCreate(INT iID, HWND hParent, INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulExStyle) {
	/*DEBUG*/XASSERT_RET(NULL == _m_hWnd, FALSE);

	BOOL bRes = FALSE;

	bRes = bCreateEx(ulExStyle, _m_sClassName, _m_sText, ulStyle, iLeft, iTop, iWidth, iHeight, hParent, iID, (VOID *)this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + s_BaseWndProc
LRESULT CALLBACK CXWindow::s_BaseWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != hWnd, NULL);

	//A pointer to the object is passed in the CREATESTRUCT
	if (WM_NCCREATE == uiMsg) {
		::SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)((LPCREATESTRUCT)lParam)->lpCreateParams);
	}

	BOOL    bProcessed = FALSE;
	LRESULT lResult    = NULL;

	//Retrieve the pointer
	CXWindow *pObj = (CXWindow *)::GetWindowLongPtr(hWnd, GWLP_USERDATA);

	//Filter message through child classes
	if (NULL != pObj) {
		lResult = pObj->pWndProc(hWnd, uiMsg, wParam, lParam, &bProcessed);
	}

	if (TRUE == bProcessed) {
		return lResult;
	} else {
		//If message was unprocessed, send it back to Windows.
		return ::DefWindowProc(hWnd, uiMsg, wParam, lParam);
	}
}
//---------------------------------------------------------------------------
//TODO: + pWndProc
/*virtual*/LRESULT CXWindow::pWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam, PBOOL pbProcessed) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	//This may be overridden to process messages.
	*pbProcessed = FALSE;

	return NULL;
}
//---------------------------------------------------------------------------