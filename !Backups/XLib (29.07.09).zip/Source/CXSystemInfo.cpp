/****************************************************************************
* Class name:  CXSystemInfo
* Description: ��������� ����������
* File name:   CXSystemInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSystemInfo.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXSystemInfo::CXSystemInfo() {

}
//---------------------------------------------------------------------------
CXSystemInfo::~CXSystemInfo(){

}
//---------------------------------------------------------------------------
/*static*/CXSystemInfo::EOs CXSystemInfo::GetOS() {
	OSVERSIONINFO OSversion = {0};

	OSversion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&OSversion);

	// This switch statement comes from
	// http://www.codeproject.com/win32/osdetect.asp
	// Originally written by Agus Kurniawan, but I've
	// modified it a bit.

	switch (OSversion.dwPlatformId) {
		case VER_PLATFORM_WIN32s: 
			return osWindows3;

		case VER_PLATFORM_WIN32_WINDOWS:
			{
				if (0 == OSversion.dwMinorVersion) {
					return osWindows95;
				} else if (10 == OSversion.dwMinorVersion) { 
					return osWindows98;
				} else if (90 == OSversion.dwMinorVersion) {  
					return osWindows98;
				}
			}
			break;

		case VER_PLATFORM_WIN32_NT:
			{
				if (5 == OSversion.dwMajorVersion && 0 == OSversion.dwMinorVersion) {
					return osWindows2000;
				} else if (5 == OSversion.dwMajorVersion &&  1 == OSversion.dwMinorVersion) {
					return osWindowsXP;
				} else if (OSversion.dwMajorVersion <= 4) {
					return osWindowsNT;
				} else {	
					//for unknown windows/newest windows version
					return osWindows2003;
				}
			}
			break;

		default:	
			return osUnknown;
			break;
	}      

	return osUnknown;
}
//---------------------------------------------------------------------------
/*static*/std::string CXSystemInfo::sComputerName() {
	BOOL        bRes                                = FALSE;
	ULONG       ulBuffSize                          = MAX_COMPUTERNAME_LENGTH;
	CHAR        szBuff[MAX_COMPUTERNAME_LENGTH + 1] = {0};

	bRes = ::GetComputerName(szBuff, &ulBuffSize);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, "LOCALHOST"); 

	return std::string(szBuff, ulBuffSize);
}
//---------------------------------------------------------------------------
