/**********************************************************************
*	�����  CXRandom (CXRandom.h)
*
***********************************************************************/


#ifndef CXRandomH
#define CXRandomH     
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXRandom {
		_NO_COPY(CXRandom);
		
	public:
		           CXRandom         ();
		          ~CXRandom         ();

		BOOL       bInitialize      ();
		BOOL       bFinalize        ();
		CHAR       cGetRandomByte   ();
		VOID       vGetRandomBytes  (INT iSize, CHAR *pszBuff);
		VOID       vGetRandomBytes  (INT iSize, UCHAR *ucBuff); 
		INT        iGetRandomInt    ();
	
	private:
		HCRYPTPROV m_hCrypt;
};
//---------------------------------------------------------------------------
#endif