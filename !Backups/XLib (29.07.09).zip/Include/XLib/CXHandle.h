/****************************************************************************
* Class name:  CXHandle
* Description: ������ � ��������
* File name:   CXHandle.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.05.2009 19:48:48
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#ifndef CXHandleH
#define CXHandleH
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
class CXHandle {
    public:
		         CXHandle()                throw();
		         CXHandle(CXHandle &h)     throw();
		explicit CXHandle(HANDLE h)        throw();
		        ~CXHandle()                throw();

		CXHandle& operator = (CXHandle &h) throw();
		operator HANDLE()          const   throw();

		VOID     vAttach(HANDLE h)         throw();
		HANDLE   hDetach()                 throw();
		VOID     vClose ()                 throw();

    public:
    	HANDLE   m_hHandle;
};
//---------------------------------------------------------------------------
#endif