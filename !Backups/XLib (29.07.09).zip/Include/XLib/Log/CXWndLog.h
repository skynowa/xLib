/****************************************************************************
* Class name:  CXWndLog
* Description: ����������� � ����
* File name:   CXWndLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXWndLogH
#define CXWndLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXWndLog {
		_NO_COPY(CXWndLog);

	public:
		typedef enum {
		    wcNone,
			wcListBox,          
		} EWindowClass;	
			                     //CXWndLog();
								 CXWndLog(HWND hWnd, EWindowClass wcWC);
								~CXWndLog();
   		BOOL                     bWrite  (LPCSTR pcszFormat, ...); /*+*/
   		
   	private:	
   		HWND                     _m_hWnd;
   		EWindowClass             _m_eWC;
   		static CXCriticalSection ms_csListBox;  //Mutex
};
//---------------------------------------------------------------------------
#endif
