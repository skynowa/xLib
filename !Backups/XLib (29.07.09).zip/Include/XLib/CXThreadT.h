/****************************************************************************
* Class name:  CXThreadT
* Description: ������ � ��������
* File name:   CXThreadT.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2009 17:20:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXThreadH
#define CXThreadH
//---------------------------------------------------------------------------
#include <windows.h>
#include <process.h>
#include <string>
#include <XLib/Common.h>
#include <XLib/Debug/xassert.h>
#include <XLib/Sync/CXEvent.h>
//---------------------------------------------------------------------------
namespace XLib {
	template<class T, class P>
	class CXThreadT {
			_NO_COPY(CXThreadT);

		public:
			typedef VOID (T::*ThreadFunc)(P);
			
			         CXThreadT();
			virtual ~CXThreadT();

			//Run - Start the CXThreadT and run the method
			//pClass->(*pfFunc), passing p as an argument.
			//Returns true if the thread was created 
			//successfully, false otherwise
			BOOL bRun(T *pClass, ThreadFunc pfFunc, P p, BOOL bCreateSuspended);

			//Suspend - Suspends the thread (if one is active)
			BOOL bSuspend();

			//Resume - Resumes a previously suspended thread
			BOOL bResume();

			//bKill - Terminates the thread (if one is active).
			//Prefer another means of exiting the thread, as
			//calling Terminate() does not allow the thread to free
			//any resources it may hold
			BOOL bKill();

			//IsThreadActive - Called in the context of another
			//(external) thread to test whether the thread is
			//currently running
			BOOL bIsActive() const;
			
			//ExitThread methods - Called within the context of an
			//external thread to instruct the embedded (running)
			//thread to exit.  
			//
			//bExit() - Signals the event and immediately 
			//returns.  
			//
			//bExitAndWait() - Signals the event and waits 
			//until the thread actually exits or the timeout
			//expires.  Returns true if the thread exited, or
			//false if the timeout expired
			BOOL bExit       ();
			BOOL bExitAndWait(ULONG ulTimeoutMS = 5000);

			//IsExitEventSet - Called by the embedded (running)
			//thread to test if the exit event is set.  Returns
			//true if the event has been set, and the thread
			//should exit, and false otherwise
			BOOL bIsExitEventSet();
			
			
			BOOL bWaitForSingleObject(ULONG ulWaitTime = INFINITE);

		protected:
			//Static CXThreadT Proc - The ThreadProc called by the
			//Windows _beginthreadex() function.  The parameter is
			//a pointer to the thread instance that is being started.  
			static UINT/*ULONG*/ WINAPI ulThreadProc(VOID *pvParam);

			//Handle to the created CXThreadT
			HANDLE      _m_hThread;
			//Handle to the Exit Event
			////--HANDLE      _m_hExitEvent;
			CXEvent     _m_ExitEvent;

			//ID of the created thread
			UINT        _m_uiID;

			//ThreadFunc invoketion members
			T          *_m_pInstance;
			ThreadFunc	_m_pfFunc;
			P			_m_iParam;
	};

	//---------------------------------------------------------------------------
	template<class T, class P>
	CXThreadT<T, P>::CXThreadT() : 
		_m_hThread   (NULL),
		/*-- _m_hExitEvent(NULL)--*/
		_m_uiID      ((UINT) - 1),
		_m_pInstance (NULL),
		_m_pfFunc    (NULL)
	{
		//Create the Exit Event - Should the args to CreateEvent be
		//customizable?  What should be done if CreateEvent() fails?
		//NOTE: Since we will have only one consumer of the exit event,
		//it is safe to make the event an auto-reset event
		////--m_hExitEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
		if (FALSE == _m_ExitEvent.bCreate(NULL, FALSE, FALSE, NULL)) {
			return;
		}
	}

	//---------------------------------------------------------------------------
	template<class T, class P>
	CXThreadT<T, P>::~CXThreadT()	{
		/*DEBUG*/XASSERT(NULL != _m_hThread);
		/*DEBUG*/////--XASSERT(NULL != _m_hExitEvent);

		if (bIsActive()) {
			bKill();
		}
			
		/*DEBUG*/////--XASSERT(NULL != _m_hExitEvent);
		////--BOOL bRes = ::CloseHandle(m_hExitEvent);
		/*DEBUG*/////--XASSERT(FALSE != bRes);
		
		////--m_hExitEvent = NULL;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bRun(T *pClass, ThreadFunc pfFunc, P param, BOOL bCreateSuspended)	{
		/*DEBUG*/XASSERT_RET(NULL == _m_hThread,    FALSE);
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
		/*DEBUG*/XASSERT_RET(NULL != pClass,       FALSE);
		/*DEBUG*/XASSERT_RET(NULL != pfFunc,       FALSE);
		
		//Store the values in this class instance so
		//the static ulThreadProc() function can call
		//the appropriate method on the object
		_m_pInstance = pClass;
		_m_pfFunc    = pfFunc;
		_m_iParam    = param; 

		UINT uiGreationFlag = bCreateSuspended ? CREATE_SUSPENDED : 0;
		/*DEBUG*/XASSERT_RET((0 == uiGreationFlag) || (CREATE_SUSPENDED == uiGreationFlag), FALSE);
 
		////_m_hThread =     ::CreateThread(NULL, 0, ulThreadProc, this, 0, &m_ulID);
		_m_hThread = (HANDLE)_beginthreadex(NULL, 0, ulThreadProc, this, uiGreationFlag, &_m_uiID);
		/*DEBUG*/XASSERT_RET(NULL != _m_hThread, FALSE);		
		
		return TRUE/*(NULL != _m_hThread)*/;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bSuspend() {
		/*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE); 
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
			
		ULONG ulRes = (DWORD) -1;
		
		ulRes = ::SuspendThread(_m_hThread);
		/*DEBUG*/XASSERT_RET((DWORD) -1 != ulRes, FALSE);
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bResume()	{
		/*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
			
	    ULONG ulResumeCount = (DWORD) -1;
	    
		ulResumeCount = ::ResumeThread(_m_hThread);
		/*DEBUG*/XASSERT_RET((DWORD) -1 != ulResumeCount, FALSE);
		while (ulResumeCount > 1) {
			ulResumeCount = ::ResumeThread(_m_hThread);
			/*DEBUG*/XASSERT_RET((DWORD) -1 != ulResumeCount, FALSE);
		}
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bKill() {
		/*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE); 
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
		
		BOOL bRes = FALSE;  
	    bRes = ::TerminateThread(_m_hThread, 0);
	    /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	    
	    bRes = ::CloseHandle(_m_hThread);
	    /*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	    
        _m_hThread = NULL;
        
        return TRUE;
    }
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bIsActive() const {
	    /*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
	       
		return ((NULL != _m_hThread) && (WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread, 0)));            	//debug
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	UINT/*ULONG*/ WINAPI CXThreadT<T, P>::ulThreadProc(VOID *pvParam) {
		CXThreadT *pInstance = reinterpret_cast<CXThreadT *>(pvParam);
		/*DEBUG*/XASSERT_RET(NULL != pInstance, (ULONG) - 1);

		//Get the invoketion variables so we don't have to
		//use even more funky syntax
		T         *pClassInstance = pInstance->_m_pInstance;
		ThreadFunc pfFunc         = pInstance->_m_pfFunc;
		P          param          = pInstance->_m_iParam;
		/*DEBUG*/XASSERT_RET(NULL != pClassInstance, (ULONG) - 1);
		/*DEBUG*/XASSERT_RET(NULL != pfFunc,         (ULONG) - 1);

		//We have a valid instance of the CXThreadT class, use
		//the thread's stored parameters to call the client
		//(worker) function.  This will continue to run in
		//the context of this (seperate) thread until finished
		((*pClassInstance).*pfFunc)(param);

		return 0;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bExit()	{
	    /*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
	    
		BOOL bRes = FALSE;
		
		////--bRes = ::SetEvent(m_hExitEvent);
		/*DEBUG*/////--XASSERT_RET(FALSE != bRes, FALSE);
		bRes = _m_ExitEvent.bSet();
		if (FALSE == bRes) {
			return FALSE; 
		}
		
		return TRUE;
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bExitAndWait(ULONG ulTimeoutMS) {
	    /*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
		/*DEBUG*/////--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
	    
		BOOL bRes = FALSE;
		
		//Set the event telling the thread to exit
		////--bRes = ::SetEvent(m_hExitEvent);
		/*DEBUG*/////--XASSERT_RET(FALSE != bRes, FALSE);
		bRes = _m_ExitEvent.bSet();
		CHECK_RET(FALSE == bRes, FALSE);


		//Wait for the thread to actually exit
		ULONG ulRes = ::WaitForSingleObject(_m_hThread, ulTimeoutMS);            //debug

		//Cleanup handle
		/*DEBUG*/XASSERT(NULL != _m_hThread);
		bRes = ::CloseHandle(_m_hThread);
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
		_m_hThread = NULL;

		return (WAIT_OBJECT_0 == ulRes);
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bIsExitEventSet()	{
	    /*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
		/*DEBUG*///--XASSERT_RET(NULL != _m_hExitEvent, FALSE);
	        
		////--ULONG ulRes = ::WaitForSingleObject(m_hExitEvent, 0);							//debug
		ULONG ulRes = _m_ExitEvent.ulWaitForSingleObject(0);
		
		return (WAIT_OBJECT_0 == ulRes);
	}
	//---------------------------------------------------------------------------
	template<class T, class P>
	BOOL CXThreadT<T, P>::bWaitForSingleObject(ULONG ulWaitTime) {
	    /*DEBUG*/XASSERT_RET(NULL != _m_hThread,    FALSE);
	        
		ULONG ulRes = ::WaitForSingleObject(_m_hThread, ulWaitTime);					//debug

		return (WAIT_OBJECT_0 == ulRes);
	}
}
//---------------------------------------------------------------------------
#endif