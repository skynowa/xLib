/**********************************************************************
*	CSMTPConn.h
*
*	7021 - on
*	7020 - off
*   7022 - info
***********************************************************************/


#pragma once
#include <atlsmtpconnection.h>
#include <Windns.h>

#pragma comment(lib,"Dnsapi.lib")
//---------------------------------------------------------------------
class CSMTPConn : public CSMTPConnection {
	public:	
		BOOL Connect(LPCTSTR lpszHostDomain, DWORD dwTimeout /*= 10000*/) throw();
	
	private:
		void _GetSMTPList(LPCTSTR lpszHostDomain, CSimpleArray<CString>& arrSMTP);
};
//---------------------------------------------------------------------