#ifndef CXCOMMON_H
#define CXCOMMON_H

#ifndef WIN32
#    error This file is intended only for use with the Microsoft Windows API.
#endif
#ifndef __cplusplus
   #error XLib requires C++ compilation (use a .cpp suffix)
#endif


////////#ifndef STRICT
////////#    define STRICT 1
////////#endif

//////#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

//---------------------------------------------------------------------------
//#undef  FALSE
//#define FALSE       0
//
//#undef  TRUE
//#define TRUE        1
//
//#undef  NULL
//#define NULL        0
//
//#undef  CHAR        
//#define CHAR        char
//
//#undef  WCHAR       
//#define WCHAR       wchar_t
//
//#undef  UCHAR       
//#define UCHAR       unsigned char
//
//#undef  INT        
//#define INT         int
//
//#undef  UINT     
//#define UINT        unsigned int
//
//#undef  SHORT      
//#define SHORT       short
//
//#undef  USHORT      
//#define USHORT      unsigned short
//
//#undef  LONG         
//#define LONG        long
//
//#undef ULONG       
//#define ULONG       unsigned long

//#undef long long int
//#define long long int

//#undef  LONGLONG    
//#define LONGLONG    __int64
//
//#undef  ULONGLONG   
//#define ULONGLONG   unsigned __int64 

//#undef  VOID        (void)
//#define VOID        void
//
//#undef  CONST       const
//#define CONST       const

//#undef  LPSTR       
//#define LPSTR       char *
//
//#undef  LPCSTR      
//#define LPCSTR      const char *
//
//#undef  LPWSTR      
//#define LPWSTR      wchar_t *  
//
//#undef  LPWCSTR     
//#define LPWCSTR     const wchar_t
//
//#undef  LPTSTR     
//#define LPTSTR      wchar_t *
//
//#undef  LPTCSTR     
//#define LPTCSTR     const wchar_t *

/*
CHAR        char
WCHAR       wchar_t
UCHAR       unsigned char
INT         int
UINT        unsigned int
SHORT       short
USHORT      unsigned short
LONG        long
ULONG       unsigned long
            long long int
LONGLONG    __int64
ULONGLONG   unsigned __int64 
VOID        void
CONST       const
LPSTR       char *
LPCSTR      const char *
LPWSTR      wchar_t *  
LPWCSTR     const wchar_t
LPTSTR      wchar_t *
LPTCSTR     const wchar_t *
*/
//---------------------------------------------------------------------------
//#define SLASHCHAR _T('\\')
//#define XSLASHCHAR _T('/')

//#define SLASH _T("\\")
//#define DELIMITER _T(";")

//#ifdef _MBCS
/* note, the macro below assumes p is to pointer to a single-byte character
 * or the 1st byte of a double-byte character, in a string.
 */
//#define ISPSLASH(p)     ( ((p) == _mbschr((p), SLASHCHAR)) || ((p) == \
//_mbschr((p), XSLASHCHAR)) )
//#else  /* _MBCS */
//#define ISSLASH(c)      ( ((c) == SLASHCHAR) || ((c) == XSLASHCHAR) )
//#endif  /* _MBCS */
//---------------------------------------------------------------------------

/*
//Validation macro for OUT pointer Used in QI and CreateInstance
#define _ATL_VALIDATE_OUT_POINTER(x)\
	do {					\
	ATLASSERT(x != NULL);	\
	if (x == NULL)			\
		return E_POINTER;	\
	*x = NULL;				\
	} while(0)
*/

/*
#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)
*/


#define DELETE_POINTER(p)   if (NULL != (p)) {delete p;    p = NULL;} 
#define DELETE_ARRAY(a)		if (NULL != (a)) {delete [] a; a = NULL;}
#define ZERO_BUFF(x)        ::ZeroMemory(&x, sizeof(x));
#define SIZEOF(array)       (sizeof(array) / sizeof(array[0]))

#define CHECK_HANDLE(h)		((INVALID_HANDLE_VALUE != h) && (NULL != h) /*&& (FALSE != ::GetHandleInformation(h, HANDLE_FLAG_INHERIT))*/)
#define CLOSE_HANDLE(h)		if (INVALID_HANDLE_VALUE != h) {::CloseHandle(h);	h = INVALID_HANDLE_VALUE;}
//#define IsValidFileHandle(x)	((x) && ((x) != INVALID_HANDLE_VALUE))

//bool IsValid() const{
//	return (( NULL != _m_handle )&&( INVALID_HANDLE_VALUE != _m_handle ));
//};

//-------------------------------------
//
#define STRINGIZE2(x) #x
#define STRINGIZE(x) STRINGIZE2(x)
#define TODO(text_) message(__FILE__ "(" STRINGIZE(__LINE__) ") [" __FUNCTION__ "]: warning TODO: [" __FUNCTION__ "] " ## text_)
#define TODO_IMPL   TODO("Implement " __FUNCTION__ " function!")


//-------------------------------------
//
/*
vbCr			Chr(13)	//������� �������.
VbCrLf			Chr(13) & Chr(10)	//������� ������� � ������� ������.
vbFormFeed		Chr(12)	//������� ��������.
vbLf			Chr(10)	//������� ������.
vbNewLine		Chr(13) & Chr(10) or Chr(10)	//������������ ���������� (����������) ������ ����� ������.
vbNullChar		Chr(0)	//������ � ������� �����.
vbNullString	//������� �������� ���� �����, ��� ������ ������� ����� ("").
vbTab			Chr(9)	//������ ���������.
vbVerticalTab	Chr(11)	//������ ������������ ���������.
*/

/*
{$IFDEF MSWINDOWS}
PathDelim = '\';
DriveDelim = ':';
PathSep = ';';
AllFilesMask = '*.*';
{$ENDIF MSWINDOWS}
{$IFDEF UNIX}
PathDelim = '/';
AllFilesMask = '*';
{$ENDIF UNIX}
// Note: the else is on purpose, VCL is not defined for a console application
NullHandle = 0;
USDecimalSeparator = '.';

*/

////XASSERT(INVALID_HANDLE_VALUE != NULL);
////XASSERT(NULL != INVALID_HANDLE_VALUE);
////XASSERT(INVALID_HANDLE_VALUE != FALSE);
////XASSERT(FALSE != INVALID_HANDLE_VALUE);
////XASSERT(INVALID_HANDLE_VALUE == ((HANDLE)(ULONG) -1));
///XASSERT(DWORD == ULONG);


// Remove pointless warning messages
#ifdef _MSC_VER
  #pragma warning (disable : 4511) // copy operator could not be generated
  #pragma warning (disable : 4512) // assignment operator could not be generated
  #pragma warning (disable : 4702) // unreachable code (bugs in Microsoft's STL)
  #pragma warning (disable : 4786) // identifier was truncated
  #pragma warning (disable : 4996) // function or variable may be unsafe (deprecated)
  #ifndef _CRT_SECURE_NO_WARNINGS
    #define _CRT_SECURE_NO_WARNINGS // eliminate deprecation warnings for VS2005
  #endif
#endif // _MSC_VER
#ifdef __BORLANDC__
  #pragma option -w-8027		   // function not expanded inline
#endif

//Required for VS 2008 (fails on XP and Win2000 without this fix)
#ifndef _WIN32_WINNT
  #define _WIN32_WINNT 0x0500
#endif

#ifndef STRICT
  #define STRICT 1
#endif

//Prevent winsock.h #include's.
#define _WINSOCKAPI_            

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf

#include <windows.h>
#include <string>
#include <stdio.h>
#include <tchar.h>
////#include <shlwapi.h>
#include <XLib/CXMsgBox.h>




//////////////////////////////#ifdef INT
//////////////////////////////#    define INT int
//////////////////////////////#endif
//////////////////////////////#ifndef INT
//////////////////////////////#    define INT int
//////////////////////////////#endif


//-------------------------------------
//For compilers lacking Win64 support
////#ifndef  GetWindowLongPtr
////  #define GetWindowLongPtr   GetWindowLong
////  #define SetWindowLongPtr   SetWindowLong
////  #define GWLP_WNDPROC       GWL_WNDPROC
////  #define GWLP_HINSTANCE     GWL_HINSTANCE
////  #define GWLP_ID            GWL_ID
////  #define GWLP_USERDATA      GWL_USERDATA
////  #define DWLP_DLGPROC       DWL_DLGPROC
////  #define DWLP_MSGRESULT     DWL_MSGRESULT
////  #define DWLP_USER          DWL_USER
////  #define DWORD_PTR          DWORD
////  #define LONG_PTR           LONG
////  #define ULONG_PTR          LONG
////#endif
////#ifndef GetClassLongPtr
////  #define GetClassLongPtr    GetClassLong
////  #define SetClassLongPtr    SetClassLong
////  #define GCLP_HBRBACKGROUND GCL_HBRBACKGROUND
////  #define GCLP_HCURSOR       GCL_HCURSOR
////  #define GCLP_HICON         GCL_HICON
////  #define GCLP_HICONSM       GCL_HICONSM
////  #define GCLP_HMODULE       GCL_HMODULE
////  #define GCLP_MENUNAME      GCL_MENUNAME
////  #define GCLP_WNDPROC       GCL_WNDPROC
////#endif


/*#ifndef HAVE_BOOL
    #define TRUE   1
    #define FALSE  0
#endif*/

#ifndef TRUE
    #define TRUE 1
#endif

#ifndef FALSE
    #define FALSE 0
#endif
//-------------------------------------
//For Visual Studio 6 (without an updated platform SDK) and Dev-C++
#ifndef OPENFILENAME_SIZE_VERSION_400
  #define OPENFILENAME_SIZE_VERSION_400 sizeof(OPENFILENAME)
#endif

//-------------------------------------
//Automatically include the XLib namespace define NO_USING_NAMESPACE to skip this step
namespace XLib {}
#ifndef NO_USING_NAMESPACE
  using namespace XLib;
#endif

//-------------------------------------
//define useful macros from WindowsX.h
#define GET_X_LPARAM(lp)  ((int)(short)LOWORD(lp))
#define GET_Y_LPARAM(lp)  ((int)(short)HIWORD(lp))

//-------------------------------------
//Define min and max for Dev-C++ compatibility
#ifndef max
#    define max(a,b)  (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#    define min(a,b)  (((a) < (b)) ? (a) : (b))
#endif

//-------------------------------------
//Disable copy construction, Disable assignment operator
#define _NO_COPY(ClassName)		  private: ClassName(const ClassName &cSrc);  ClassName& operator = (const ClassName &cSrc)
#define DECLARE_NO_COPY_CLASS(classname)        \
    private:                                    \
        classname(const classname&);            \
        classname& operator=(const classname&);

#define DECLARE_NO_ASSIGN_CLASS(classname)      \
    private:                                    \
        classname& operator=(const classname&);
        
namespace XLib {
	enum Constants {
		MAX_STRING_SIZE = 255,
	};   
    
    
    /****************************************************************************
	* Definition of the CSize class
	* This class can be used to replace the SIZE structure
    *
    *****************************************************************************/

	class CSize : public SIZE {
		public:
			CSize()						{ cx = 0; cy = 0; }
			CSize(int CX, int CY)		{ cx = CX; cy = CY; }
			CSize(SIZE sz)				{ cx = sz.cx; cy = sz.cy; }
			CSize(POINT pt)				{ cx = pt.x;  cx = pt.y; }
			CSize(DWORD dw)				{ cx = (short)LOWORD(dw); cx = (short)HIWORD(dw); }
			void SetSize(int CX, int CY){ cx = CX; cy = CY; }
			BOOL operator == (SIZE sz)	{ return (cx == sz.cx && cy == sz.cy); }
			BOOL operator != (SIZE sz)	{ return (cx != sz.cx || cy != sz.cy); }
	};

    
    
    
    /****************************************************************************
	* Definition of the CPoint class
	* This class can be used to replace the POINT structure
    *
    *****************************************************************************/
    
	class CPoint : public POINT	{
		public:
			CPoint()					{ x = 0; y = 0; }
			CPoint(int X, int Y)		{ x = X; y = Y; }
			CPoint(SIZE sz)				{ x = sz.cx; y = sz.cy; }
			CPoint(POINT pt)			{ x = pt.x ; y = pt.y; }
			CPoint(DWORD dw)			{ x = (short)LOWORD(dw); y = (short)HIWORD(dw); }
			void Offset(int dx, int dy)	{ x += dx; y += dy; }
			void SetPoint(int X, int Y)	{ x = X; y = Y; }
			BOOL operator == (POINT pt)	{ return ((x == pt.x) && (y == pt.y)); }
			BOOL operator != (POINT pt)	{ return ((x != pt.x) || (y != pt.y)); }
	};

	inline CPoint GetCursorPos() {
		CPoint pt;
		::GetCursorPos(&pt);
		
		return pt;
	}


    
    /****************************************************************************
	* Definition of the CRect class
	* This class can be used to replace the RECT structure.
    *
    *****************************************************************************/
    
	class CRect : public RECT {
		public:
			CRect()
			{ left = top = right = bottom = 0; }

			CRect(int Left, int Top, int Right, int Bottom)
			{ left = Left; top = Top; right = Right; bottom = Bottom; }

			CRect(RECT rc)
			{ left = rc.left; top = rc.top; right = rc.right; bottom = rc.bottom; }

			CRect(POINT pt, SIZE sz)
			{ right = (left = pt.x) + sz.cx; bottom = (top = pt.y) + sz.cy; }

			CRect(POINT topLeft, POINT bottomRight)
			{ left = topLeft.x; top = topLeft.y; right = bottomRight.x; bottom = bottomRight.y; }

			operator LPRECT()
			{ return this; }

			operator LPCRECT() const
			{ return this; }

			BOOL operator == (RECT& rc)
			{ return ::EqualRect(this, &rc); }

			BOOL operator != (RECT& rc)
			{ return !::EqualRect(this, &rc); }

			void  operator=( RECT& srcRect)
			{ ::CopyRect(this, &srcRect); }

			int Height()
			{ return bottom - top; }

			int Width()
			{ return right - left; }

			void CopyRect(RECT* pRect)
			{ ::CopyRect(pRect, this); }

			BOOL EqualRect(const RECT* pRect)
			{ return ::EqualRect(pRect, this); }

			BOOL InflateRect(int dx, int dy)
			{ return ::InflateRect(this, dx, dy); }

			BOOL IntersectRect(LPCRECT lpRect1, LPCRECT lpRect2)
			{ return ::IntersectRect(this, lpRect1, lpRect2); }

			BOOL IsRectEmpty()
			{ return ::IsRectEmpty(this);}

			BOOL OffsetRect(int dx, int dy)
			{ return ::OffsetRect(this, dx, dy); }

			BOOL PtInRect(POINT pt)
			{ return ::PtInRect(this, pt); }

			BOOL SetRect(int left, int top, int right, int bottom)
			{ return ::SetRect(this, left, top, right, bottom); }

			BOOL SetRectEmpty()
			{ return ::SetRectEmpty(this); }

			BOOL SubtractRect(const RECT* pRcSrc1, const RECT* pRcSrc2)
			{ return ::SubtractRect(this, pRcSrc1, pRcSrc2); }

			BOOL UnionRect(const RECT* pRcSrc1, const RECT* pRcSrc2)
			{ return ::UnionRect(this, pRcSrc1, pRcSrc2); }
	};



    /****************************************************************************
    *   Declaration of the CWinException class
    *
    *****************************************************************************/

	class CWinException	{
		public:
			CWinException (LPCTSTR msg) : m_err (::GetLastError()), m_msg(msg) {}
			LPCTSTR What() const {return m_msg;}
			
			void MessageBox() const	{
				TCHAR buf1 [MAX_STRING_SIZE/2 -10] = _T("");
				TCHAR buf2 [MAX_STRING_SIZE/2 -10] = _T("");
				TCHAR buf3 [MAX_STRING_SIZE]       = _T("");

				lstrcpyn(buf1, m_msg, MAX_STRING_SIZE/2 -10);

				// Display Last Error information if it's useful
				if (m_err != 0)	{
					::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, m_err,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf2, MAX_STRING_SIZE/2 -10, NULL);

					::wsprintf(buf3, _T("%s\n\n     %s\n\n"), buf1, buf2);
				} else {
					::wsprintf(buf3, _T("%s"), buf1);
				}

				////TRACE(_T("*** ERROR: An Exception occured ***\n"));
				////TRACE(buf3);
				////TRACE(_T("\n\n"));

				::MessageBox (0, buf3, _T("Error"), MB_ICONEXCLAMATION | MB_OK);
			}

		private:
			DWORD  m_err;
			LPCTSTR m_msg;
	};
}   //namespace XLib 
//---------------------------------------------------------------------------
#endif  //CXCOMMON_H