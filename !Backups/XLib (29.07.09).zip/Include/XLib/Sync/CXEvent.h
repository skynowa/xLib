/****************************************************************************
* Class name:  CXEvent
* Description: ������ � ��������
* File name:   CXEvent.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXEventH
#define CXEventH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXEvent {
		_NO_COPY(CXEvent);

	public:
               CXEvent              ();
			  ~CXEvent              ();
        HANDLE hGetHandle           ();
		BOOL   bCreate              (PSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCSTR pcszName);
		BOOL   bOpen                (ULONG ulAccess, BOOL bInheritHandle, LPCSTR lpcszName);
		BOOL   bPulse               ();
		BOOL   bReset               ();
		BOOL   bSet                 ();
        ULONG  ulWaitForSingleObject(ULONG ulTimeout = INFINITE);

	private:
		HANDLE _m_hEvent;
};
//---------------------------------------------------------------------------
#endif