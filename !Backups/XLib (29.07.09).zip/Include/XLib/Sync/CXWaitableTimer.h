/****************************************************************************
* Class name:  CXWaitableTimer
* Description: ������ � �������� ��������
* File name:   CXWaitableTimer.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.05.2009 17:07:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXSemaphoreH
#define CXSemaphoreH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXWaitableTimer {
		_NO_COPY(CXWaitableTimer);

	public:
			   CXWaitableTimer      ();
			  ~CXWaitableTimer      ();
	    HANDLE hGetHandle           ();
		BOOL   bCreate              (BOOL bManualReset, LPCSTR pcszName = NULL, LPSECURITY_ATTRIBUTES lpTimerAttributes = NULL);
    	BOOL   bOpen                (LPCSTR pcszName, ULONG ulDesiredAccess = TIMER_ALL_ACCESS, BOOL bInheritHandle = FALSE);
		BOOL   bCancel              ();
		BOOL   bSet                 (LONGLONG i64DueTime/*milliseconds*/, LONG liPeriod = 0, PTIMERAPCROUTINE pfnCompletionRoutine = NULL, LPVOID pvArgToCompletionRoutine = NULL, BOOL bResume = FALSE);  
		ULONG  ulWaitForSingleObject(ULONG ulTimeout  = INFINITE);

	private:
		HANDLE _m_hWaitableTimer;
};
//---------------------------------------------------------------------------
#endif 