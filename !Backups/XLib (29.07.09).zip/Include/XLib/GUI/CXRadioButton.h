/****************************************************************************
* Class name:  CXRadioButton
* Description: 
* File name:   CXRadioButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXRadioButton_H
#define CXRadioButton_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXRadioButton: public CXWindow {
	public:
			 CXRadioButton();
			~CXRadioButton();
			
		BOOL bIsChecked   ();
		BOOL bCheck       (BOOL bChecked);
};
//---------------------------------------------------------------------------
#endif