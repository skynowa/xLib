/****************************************************************************
* Class name:  CXWindow
* Description: ������ � ������
* File name:   CXWindow.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:09:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXWindow_H
#define CXWindow_H
//---------------------------------------------------------------------------
#include <XLib/GUI/Common.h>
//---------------------------------------------------------------------------
class CXWindow {
    public:
		                         CXWindow     ();
		virtual                 ~CXWindow     () = 0;
        
		BOOL                     bCreate      (INT iID, HWND hParent, INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulExStyle);
		BOOL                     bIsWindow() const;
    	HWND                     hGetHandle   ();

		std::string              sGetText     ();
		BOOL                     bSetText     (const std::string &csText);

		BOOL                     bSetSize     (INT iWidth, INT iHeight);
		BOOL                     bSetPos      (INT iLeft,  INT iTop);
		BOOL                     bSetWndPos   (HWND hWndInsertAfter, INT iLeft, INT iTop, INT iWidth, INT iHeight, UINT uiFlags);

		RECT                     GetRect      ();
		BOOL                     SetRect      (RECT rectRect);
		
		BOOL                     bShow        (INT iCmdShow);
		BOOL                     bUpdate      ();

		LRESULT                  lSendMessage (UINT uiMsg, WPARAM wParam, LPARAM lParam);
		BOOL                     bPostMessage (UINT uiMsg, WPARAM wParam, LPARAM lParam);
		
		BOOL                     bDestroy     ();
		BOOL                     bClose       ();


		HFONT                    hGetFont            ();
		BOOL                     bSetFont            (HFONT hFont);
		BOOL                     bSetDefaultFont    ();
		
									
							 
		BOOL                    bAttach(HWND hWnd) {
										_m_hParent = ::GetParent(hWnd);
										_m_hWnd    = hWnd;
										
										return TRUE;
								};
								
    	
    	
    protected:
        CXTraceLog               _m_tlLog;
        
		HWND                     _m_hWnd;

		ULONG                    _m_ulExStyle;
		std::string              _m_sClassName;
		std::string              _m_sText;
		ULONG                    _m_ulStyle;
		INT                      _m_iWidth, _m_iHeight, _m_iLeft, _m_iTop;
		HWND                     _m_hParent;		
		INT                      _m_iMenu;
		HFONT                    _m_Font;

		BOOL                     bInitCommonControls(ULONG ulFlags);
		BOOL                     bRegisterClassEx(const WNDCLASSEX *cpwcWndClassEx);
		BOOL                     bCreateEx       (ULONG ulExStyle, const std::string &csClassName, const std::string &csText, ULONG ulStyle, INT iLeft, INT iTop, INT iWidth, INT iHeight, HWND hParent, INT iID, LPVOID lpParam);
    	static  LRESULT CALLBACK s_BaseWndProc   (HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam);
    	virtual LRESULT          pWndProc        (HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam, PBOOL pbProcessed);
};  
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#endif