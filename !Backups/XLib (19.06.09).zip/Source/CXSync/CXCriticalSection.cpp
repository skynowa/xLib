/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ ��������
* File name:   CXLockScope.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSync/CXCriticalSection.h>

#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXCriticalSection::CXCriticalSection() {
	::InitializeCriticalSection(&m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
#if (_WIN32_WINNT >= 0x0403)
CXCriticalSection::CXCriticalSection(ULONG ulSpinCount) {
	BOOL bRes = FALSE;	
	
	bRes = ::InitializeCriticalSectionAndSpinCount(&m_CS, ulSpinCount);
	/*DEBUG*/XASSERT(FALSE != bRes);
}
#endif
//---------------------------------------------------------------------------
CXCriticalSection::~CXCriticalSection() {
	::DeleteCriticalSection(&m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
VOID CXCriticalSection::vEnter() {
	::EnterCriticalSection(&m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
VOID CXCriticalSection::vLeave() {
	::LeaveCriticalSection(&m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
#if (_WIN32_WINNT >= 0x0403)
ULONG CXCriticalSection::ulSetSpinCount(ULONG ulSpinCount) {
	return ::SetCriticalSectionSpinCount(&m_CS, ulSpinCount);
	/*DEBUG*///not need
}
#endif
//---------------------------------------------------------------------------
#if(_WIN32_WINNT >= 0x0400)
BOOL CXCriticalSection::bTryEnter() {
	return ::TryEnterCriticalSection(&m_CS);
	/*DEBUG*///not need
}
#endif
//---------------------------------------------------------------------------