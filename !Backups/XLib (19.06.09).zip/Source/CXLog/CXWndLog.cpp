/****************************************************************************
* Class name:  CXWndLog
* Description: ����������� � ����
* File name:   CXWndLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXLog/CXWndLog.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFso/CXPath.h>
#include <XLib/CXSync/CXLockScope.h>

CXCriticalSection CXWndLog::ms_csListBox;
//---------------------------------------------------------------------------
CXWndLog::CXWndLog(HWND hWnd, EWindowClass iWC) :
	m_hWnd(NULL),
	m_eWC(wcNone)
{
	m_hWnd = hWnd;
	m_eWC  = iWC;
	
	/*DEBUG*/XASSERT(NULL      != m_hWnd);
	/*DEBUG*/XASSERT(wcListBox == m_eWC);
}
//---------------------------------------------------------------------------
CXWndLog::~CXWndLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXWndLog::bWrite(LPCSTR pcszFormat, ...) { 
	/*DEBUG*/XASSERT_RET(NULL != m_hWnd,     FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%d:%d:%d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	switch(m_eWC) {
		case wcListBox: 	
			{
				/*LOCK*/CXLockScope SL(ms_csListBox);
				
				//sRemoveEOL
				::SendMessage(m_hWnd, LB_ADDSTRING, 0, (LPARAM)(sTime + " " + sParam).c_str());
				::SendMessage(m_hWnd, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
			}
			break;

		default:	
				{
					/*DEBUG*/XASSERT_RET(FALSE, FALSE);
				}
			break;
	}
	
	return TRUE;
}
//---------------------------------------------------------------------------