/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.cpp
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#include <XLib/CXPerform.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFso/CXPath.h>
#include <XLib/CXFso/CXStdioFile.h>
//---------------------------------------------------------------------------
CXPerform::CXPerform(const std::string &csFileName, EPerfomMode pmPerformMode) {
	/*DEBUG*/XASSERT(false == csFileName.empty());
	/*DEBUG*/XASSERT(pmPerformMode < 2 || pmPerformMode > 0);
	
	bResetData(); 

	m_iPerfomModeNow = pmPerformMode;
	m_sLogPath       = CXPath::sExtractFileDir(CXPath::sExePath()) + "\\" + csFileName;
	
	bLog("------------------------------");
}
//---------------------------------------------------------------------------
CXPerform::~CXPerform() {	
	bLog("------------------------------");
}
//--------------------------------------------------------------------------
BOOL CXPerform::bStart() {
    switch (m_iPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				////////dtBeginTime = Time();
				////SYSTEMTIME stST = {0};
				////::GetLocalTime(&stST);

				////fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	
			}
			break;

        //pmGetTickCount
		case pmGetTickCount:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				m_dwBeginTime = ::GetTickCount();
			}
            break;
		
		//QueryPerformanceCounter
        case pmQueryPerformanceCounter:
			{
				if (!::QueryPerformanceFrequency(&m_liStart)) {
					::MessageBox(0, "��������� ����������", "Log", MB_OK);
					return FALSE;
				}
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::QueryPerformanceFrequency(&m_liBeginCount);
			}
            break;

		//pmGetThreadTimes
		case pmGetThreadTimes:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::GetThreadTimes(::GetCurrentThread(), &m_lpCreationTime, &m_lpExitTime, &m_lpKernelTime0, &m_lpUserTime0);
			}
			break;
		
		//pmUknown
		case pmUknown:
			{
				/*DEBUG*/XASSERT(false);
			}
			break; 

        default:	
			{
				/*DEBUG*/XASSERT_EX(false, "���������� �����");
				::MessageBox(0, "���������� �����", "Log", MB_OK);
			}
            break;
    }

    m_bWasStarted = TRUE;

	return TRUE;
}
//--------------------------------------------------------------------------
BOOL CXPerform::bStop(const std::string &csComment) {
	CHECK_RET(FALSE == m_bWasStarted, FALSE);

	switch (m_iPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				////dtEndTime = Time();
				////bLog(casComment, (dtEndTime - dtBeginTime).FormatString("hh:nn:ss:zz"));
			}
			break;

        //pmGetTickCount (��������)
        case pmGetTickCount:
            {
				m_dwEndTime = ::GetTickCount();
                bLog(csComment, sMilliSecToTimeString(m_dwEndTime - m_dwBeginTime));
            }
            break;

	    //QueryPerformanceCounter (�����)
	    case pmQueryPerformanceCounter:
            {
                ::QueryPerformanceCounter(&m_liEndCount);
                m_liCount.QuadPart = m_liEndCount.QuadPart - m_liBeginCount.QuadPart;
                bLog(csComment, sTypeToStr(m_liCount.QuadPart * 1000 / m_liStart.QuadPart));
            }
            break;

        //pmGetThreadTimes (��������)
        case pmGetThreadTimes:
            {
                ::GetThreadTimes(GetCurrentThread(), &m_lpCreationTime, &m_lpExitTime, &m_lpKernelTime1, &m_lpUserTime1);
                /*???? float*/bLog(csComment, sMilliSecToTimeString((iFiletimeToint64(m_lpUserTime1) - iFiletimeToint64(m_lpUserTime0)) / 10000));	//10000 - ������������; 10 - ������������
            }
            break;  
		
		//pmUknown
		case pmUknown:
			{
				/*DEBUG*/XASSERT(false);
			}
			break; 

		default:	
			{
				/*DEBUG*/XASSERT(false);
			}
			break;

	}

	bResetData();

	m_bWasStarted = FALSE;

	return TRUE;
}
//--------------------------------------------------------------------------
BOOL CXPerform::bPulse(const std::string &csComment) {
	BOOL bRes = FALSE;

	bRes = bStop(csComment);
    CHECK_RET(FALSE == bRes, FALSE);

	bRes = bStart();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bPulse(ULONG  ulComment) {
	BOOL bRes = FALSE;

    bRes = bStop(sTypeToStr(ulComment));
	CHECK_RET(FALSE == bRes, FALSE);
    
	bRes = bStart();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bDeleteLog() {
    BOOL bRes = FALSE;

	bRes = CXStdioFile::bIsExists(m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	bRes = CXStdioFile::bRemove(m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bOpenLog() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec("Notepad.exe", m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------







/****************************************************************************
*	Private methods	
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXPerform::bResetData() {
    m_iPerfomModeNow                = pmUknown;
    m_bWasStarted                   = FALSE;

	//pmGetTickCount
	m_dwBeginTime                   = 0;
	m_dwEndTime                     = 0;

    //QueryPerformanceCounter
    m_liStart.QuadPart              = 0;
	m_liBeginCount.QuadPart         = 0;
	m_liEndCount.QuadPart           = 0;

	//GetThreadTimes
	m_lpCreationTime.dwLowDateTime  = 0;
    m_lpCreationTime.dwHighDateTime = 0;
	m_lpExitTime.dwLowDateTime      = 0;
    m_lpExitTime.dwHighDateTime     = 0;
	m_lpKernelTime0.dwLowDateTime   = 0;
    m_lpKernelTime0.dwHighDateTime  = 0;
	m_lpUserTime0.dwLowDateTime     = 0;
    m_lpUserTime0.dwHighDateTime    = 0;
	m_lpKernelTime1.dwLowDateTime   = 0;
    m_lpKernelTime1.dwHighDateTime  = 0;
	m_lpUserTime1.dwLowDateTime     = 0;
    m_lpUserTime1.dwHighDateTime    = 0;
    
    ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);

	return TRUE;
}
//--------------------------------------------------------------------------
__int64 CXPerform::iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//--------------------------------------------------------------------------
BOOL CXPerform::bLog(const std::string &csText) {
	BOOL bRes = FALSE;

	CXStdioFile sfLog;

	bRes = sfLog.bOpen(m_sLogPath, "a");
	CHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	
	sfLog.iFprintf("[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bLog(const std::string &csComment, const std::string &csText) {
	BOOL bRes = FALSE;

	CXStdioFile sfLog;

	bRes = sfLog.bOpen(m_sLogPath, "a");
	CHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	
	sfLog.iFprintf("[%d:%d:%d]  %s: %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csText.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXPerform::sMilliSecToTimeString(__int64 i64MilliSec) {
	CHAR    szBuff[64 + 1] = {0};
    __int64 i64H  = 0;
    __int64 i64M  = 0;
    __int64 i64S  = 0;
    __int64 i64Ms = 0;

    i64H  = i64MilliSec / 3600000;
    i64M  = i64MilliSec % 3600000 / 60000;
    i64S  = i64MilliSec % 60000   / 1000;
    i64Ms = i64MilliSec % 1000;
	
    ::wsprintf(szBuff, "%I64d:%.2I64d:%.2I64d:%.3I64d", i64H, i64M, i64S, i64Ms);	
	
	return std::string(szBuff);
}
//---------------------------------------------------------------------------







/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

BOOL F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
INT main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/