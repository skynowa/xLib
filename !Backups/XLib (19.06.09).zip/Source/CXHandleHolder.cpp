/****************************************************************************
*    �����: CXHandleHolder (CXHandleHolder.h)
*
*****************************************************************************/


#include <XLib/CXHandleHolder.h>
#include <assert.h>
//---------------------------------------------------------------------------
CXHandleHolder::CXHandleHolder() { 
	m_hHandle = NULL; 
} 
//---------------------------------------------------------------------------
CXHandleHolder::CXHandleHolder(HANDLE hHandle) { 
	/*DEBUG*/assert(NULL                 != hHandle);
    /*DEBUG*/assert(INVALID_HANDLE_VALUE != hHandle);

	m_hHandle = hHandle; 
} 
//---------------------------------------------------------------------------
CXHandleHolder::~CXHandleHolder() { 
	/*DEBUG*/assert(NULL                 != m_hHandle);
    /*DEBUG*/assert(INVALID_HANDLE_VALUE != m_hHandle);

	if (m_hHandle) {
		::CloseHandle(m_hHandle);	m_hHandle = NULL;
	}
} 
//---------------------------------------------------------------------------
CXHandleHolder::operator HANDLE() { 
	/*DEBUG*/assert(NULL                 != m_hHandle);
    /*DEBUG*/assert(INVALID_HANDLE_VALUE != m_hHandle);

	return m_hHandle; 
} 
//---------------------------------------------------------------------------
HANDLE CXHandleHolder::operator = (HANDLE hHandle) { 
	/*DEBUG*/assert(NULL                 != hHandle);
    /*DEBUG*/assert(INVALID_HANDLE_VALUE != hHandle);

	return (m_hHandle = hHandle); 
} 
//---------------------------------------------------------------------------