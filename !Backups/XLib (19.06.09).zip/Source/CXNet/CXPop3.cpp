/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/

   

//---------------------------------------------------------------------------
#include <XLib/CXNet/CXPop3.h> 

#include <stdio.h>   
#include <string>   
#include <iostream>
#include <XLib/xassert.h>   
#include <XLib/CXString.h>
#include <XLib/CXFso/CXStdioFile.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------  


/****************************************************************************
*	Private methods
*
*****************************************************************************/



//---------------------------------------------------------------------------
CPop3::CPop3() { 
	::ZeroMemory(&m_szRecv, sizeof(m_szRecv));
	CXTcpClientSocket::bInit();
}   
//--------------------------------------------------------------------------- 
CPop3::~CPop3() {   
	////bDisconnect();
	CXTcpClientSocket::bClean();   
}   
//--------------------------------------------------------------------------- 
 BOOL CPop3::bCreate(const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort) {  
	 /*DEBUG*/XASSERT_RET(FALSE == csUser.empty(),          FALSE);
	 /*DEBUG*/XASSERT_RET(FALSE == csPass.empty(),          FALSE);
	 /*DEBUG*/XASSERT_RET(FALSE == csServer.empty(),        FALSE);
	 /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	 m_sUser   = csUser;   
	 m_sPass   = csPass;   
	 m_sServer = csServer;   
	 m_usPort  = usPort;   

	 return TRUE;  
 }   
//---------------------------------------------------------------------------    
 BOOL CPop3::bConnect() {   
     BOOL bRes = FALSE;

	 //-------------------------------------
	 //Create sock   
     bRes = m_scktSocket.bCreate(AF_INET, SOCK_STREAM, 0);  
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //Parse domain   
     CHAR szIpAddr[16] = {0};

	 bRes = CXTcpClientSocket::bDnsParse(m_sServer.c_str(), szIpAddr);
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //Connect   
	 bRes = m_scktSocket.bConnect(szIpAddr, m_usPort);
	 CHECK_RET(FALSE == bRes, FALSE);
    
	 //-------------------------------------
	 //[welcome message] 
     INT iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	 /*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	 /*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE); //��� "+OK"
    
#ifdef _DEBUG   
     m_szRecv[iRes] = '\0';   
     printf("Recv POP3 Resp: %s", m_szRecv);   
#endif   
    
     return TRUE;   
 }  
 //---------------------------------------------------------------------------
BOOL CPop3::bIsConnected() {
	//TODO: bIsConnected

	return FALSE;
}
//---------------------------------------------------------------------------    
BOOL CPop3::bLogin() {  
	INT  iRes = SOCKET_ERROR;

	//-------------------------------------
	//[USER\r\n]
	const std::string sUserCmd = "USER " + m_sUser + "\r\n";

	iRes = m_scktSocket.iSend(sUserCmd.c_str(), sUserCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sUserCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

#ifdef _DEBUG   
	m_szRecv[iRes] = '\0';   
	printf("Recv USER Resp: %s", m_szRecv);   
#endif     

	//-------------------------------------
	//[PASS\r\n]   
	std::string sPassCmd = "PASS " + m_sPass + "\r\n";

	iRes = m_scktSocket.iSend(sPassCmd.c_str(), sPassCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sPassCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

#ifdef _DEBUG   
	m_szRecv[iRes] = '\0';   
	printf("Recv PASS Resp: %s", m_szRecv);   
#endif         

	return TRUE; 
}   
//---------------------------------------------------------------------------
//������ ��������, ������ �� ������� 
BOOL CPop3::bList(std::vector<ULONG> &veculList) {
	/*
	+OK scan listing follows
	1 570829
	2 571012
	.
	*/
////	int  iRes = - 1; 
////	CHAR szRecv[100024];	    memset(szRecv, 0, sizeof(szRecv));  
////
////	//-------------------------------------
////	//[LIST\r\n]   
////	const std::string sListCmd = "LIST\r\n";
////
////	iRes =  m_scktSocket.iSend(sListCmd.c_str(), sListCmd.size(), 0); 
////	/*DEBUG*/XASSERT_RET(sListCmd.size() == iRes);
////
////	iRes = iPop3Recv(szRecv, sizeof(szRecv) - 1, 0);   
////	/*DEBUG*/XASSERT_RET(0 < iRes);
////	/*DEBUG*/XASSERT_RET(FALSE == bIsError(szRecv));  
////	szRecv[iRes] = '\0';   
////
////#ifdef _DEBUG   
////	printf("Recv LIST Resp: %s", szRecv);   
////#endif   
////	
////	///????std::vector veculRes = vecsExplode('\r\n', std::string(szRecv));


	return FALSE;  
}	
//---------------------------------------------------------------------------
//������ ������ � �������� ulIndex   
BOOL CPop3::bListAt(ULONG &ulIndex) {
	//...

	return FALSE;
}	               
//---------------------------------------------------------------------------    
BOOL CPop3::bStat(ULONG &ulSum, ULONG &ulSize) {   
	INT iRes = SOCKET_ERROR; 

	//-------------------------------------
	//[LIST\r\n]   
	const std::string sStatCmd = "STAT\r\n";

	iRes =  m_scktSocket.iSend(sStatCmd.c_str(), sStatCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sStatCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);  

	ulSum  = ulMailsSum (std::string(m_szRecv, iRes));	//???????????????????????????
	ulSize = ulMailsSize(std::string(m_szRecv, iRes));

#ifdef _DEBUG   
	m_szRecv[iRes] = '\0'; 

	printf("Recv STAT Resp: %s", m_szRecv); 
	//+OK 2 1141841
	printf("Recv STAT Resp: MailsSum  = %u\n", ulSum); 
	printf("Recv STAT Resp: MailsSize = %u\n", ulSize);
#endif  

	return TRUE;       
}
//---------------------------------------------------------------------------
//TODO: bDelete
BOOL CPop3::bDelete(ULONG ulMsgID) {
	INT  iRes = SOCKET_ERROR; 

	//-------------------------------------
	//[DELE 2\r\n]   
	const std::string sDeleCmd = "DELE " + sTypeToStr(ulMsgID) + "\r\n";

	iRes =  m_scktSocket.iSend(sDeleCmd.c_str(), sDeleCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sDeleCmd.size() == iRes, FALSE);

	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);  
 
#ifdef _DEBUG   
	m_szRecv[iRes] = '\0';  
	printf("Recv STAT Resp: %s", m_szRecv); 
	//+OK message 1 deleted
#endif  

	return TRUE;     
}
//---------------------------------------------------------------------------    
BOOL CPop3::bRetriveRaw(INT iNum, const std::string &csDirPath) {  //csDirPath ��� ����� 
	INT         iRes    = SOCKET_ERROR; 
	CXStdioFile stdFile;   
	INT         iFlag   = 0;   

	//-------------------------------------
	//[RETR 3\r\n]
	const std::string sRetrCmd = "RETR " + sTypeToStr(iNum) + "\r\n";
    
    iRes = m_scktSocket.iSend(sRetrCmd.c_str(), sRetrCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sRetrCmd.size() == iRes, FALSE);	

	//-------------------------------------
	//������ �� ������ � ����� ����� � ����
	for (;;) {   
		//-------------------------------------
		//������ � �������
		iRes = iPop3Recv(m_szRecv, ms_cuiRecvSize, 0);   
		/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);

		//-------------------------------------
		//������� ���� 
		if (0 == iFlag) {   
			iFlag = 1;   

			//TODO: ��� ����� = ID-������ + �����
			std::string sFileName = "Msg_" + sTypeToStr(iNum) + ".eml";

			iRes = stdFile.bOpen((csDirPath + "\\" + sFileName).c_str(), "wb");
			/*DEBUG*/XASSERT_RET(FALSE != iRes, FALSE);
		}   

		//-------------------------------------
		//����� �� ����
		size_t uiWriteSize = stdFile.uiWrite(m_szRecv, iRes); 

		if ((LPSTR)NULL != strstr(m_szRecv, "\r\n.\r\n")) {
			break; 
		}
	} 

    return TRUE;  
}   
//---------------------------------------------------------------------------
BOOL CPop3::bRetrieveHeader(INT iNum, CXMimeHeader &mhMimeHeader) {
	//TODO: bRetrieveHeader
	INT         iRes    = SOCKET_ERROR; 
	std::string sRes    = "";
	INT         iFlag   = 0;   

	//-------------------------------------
	//[RETR 3\r\n]
	const std::string sRetrCmd = "RETR " + sTypeToStr(iNum) + "\r\n";

	iRes = m_scktSocket.iSend(sRetrCmd.c_str(), sRetrCmd.size(), 0); 
	/*DEBUG*/XASSERT_RET(sRetrCmd.size() == iRes, FALSE);	

	//-------------------------------------
	//������ �� ������ � ����� ����� � ����

	for (;;) {   
		//-------------------------------------
		//������ � �������
		iRes = iPop3Recv(m_szRecv, ms_cuiRecvSize, 0);   
		/*DEBUG*/XASSERT_RET(0 < iRes, FALSE);

		//-------------------------------------
		//����� � ������
		sRes.append(m_szRecv, iRes);  


		size_t uiHeaderDelimPos = sRes.find("\r\n\r\n");
		if (std::string::npos != uiHeaderDelimPos) {
			std::string sHeader = "";

			sHeader = sRes.substr(0, uiHeaderDelimPos);
			////MsgBox(">" + sHeader + "<", "Header");

			//-------------------------------------
			//��������� �����
			std::multimap<std::string, std::string> mmFields;
			
			mhMimeHeader.bGetFields(sHeader, mmFields);


			break; 
		}
	} 

	return TRUE; 
}
//---------------------------------------------------------------------------
BOOL CPop3::bDisconnect() {   
	INT iRes = SOCKET_ERROR;

	const std::string sQuitCmd = "QUIT\r\n";
	
	//[QUIT]  
	iRes = m_scktSocket.iSend(sQuitCmd.c_str(), sQuitCmd.size(), 0); 
    /*DEBUG*/XASSERT_RET(sQuitCmd.size() == iRes, FALSE);
    
	iRes = m_scktSocket.iRecv(m_szRecv, ms_cuiRecvSize, 0);   
	/*DEBUG*/XASSERT_RET(0 < iRes,                                 FALSE);
	/*DEBUG*/XASSERT_EX_RET(FALSE == bIsError(m_szRecv), m_szRecv, FALSE);

#ifdef _DEBUG   
	m_szRecv[iRes] = '\0';   
	printf("Recv QUIT Resp: %s", m_szRecv);   
#endif     

	if (FALSE == m_scktSocket.bClose()) {
		return FALSE;
	}

	return TRUE; 
}   
//---------------------------------------------------------------------------   
///*BOOL CPop3::bGetSubject(LPSTR pszSubject, LPCSTR pcszBuf) {   
//    LPCSTR p = strstr(pcszBuf, "Subject: "); 
//	CHECK_RET(NULL == p, FALSE); 
//    
//    p = p + 9;   
//    for (int i = 0; i < 32; i ++) {   
//        if ('\r' == p[i] || '\n' == p[i]) {   
//            pszSubject[i] = '\0';   
//            break;   
//        }  
//
//        pszSubject[i] = p[i];   
//    }   
//    
//    return TRUE;   
//} */  
//---------------------------------------------------------------------------   
////int CPop3::iGetMailSum(const char *pcszBuff) {   
////	INT         iSum = 0;   
////	LPCSTR      p    = strstr(pcszBuff, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	p = strstr(p + 2, "\r\n");   
////	if (NULL == p) {   
////		return iSum;
////	}
////
////	while (NULL != (p = strstr(p + 2, "\r\n"))) {   
////		iSum ++;   
////	}   
////
////	return iSum;   
////}
//---------------------------------------------------------------------------
ULONG CPop3::ulMailsSum(const std::string &csServerAnswer) {
	//+OK 2 1141841
	ULONG       ulSum = 0;   
	std::string sSum  = ""; 
	
	sSum  = vecsSplit(" ", csServerAnswer).at(1); 
	ulSum = atol(sSum.c_str());		//!!! ul -> l
	
	return ulSum;
}
//---------------------------------------------------------------------------
ULONG CPop3::ulMailsSize(const std::string &csServerAnswer) {
	//+OK 2 1141841
	ULONG       ulSize = 0;   
	std::string sSize  = ""; 

	sSize  = vecsSplit(" ", csServerAnswer)[2]; 
	ulSize = atol(sSize.c_str());	//!!! ul+\r\n -> l

	return ulSize;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	Private methods
*
*****************************************************************************/


//---------------------------------------------------------------------------
INT CPop3::iPop3Recv(LPSTR pszInBuff, INT iInBuffSize, INT iFlags) {   
	/*DEBUG*/XASSERT_RET(NULL != pszInBuff,   - 1);
	/*DEBUG*/XASSERT_RET(0     < iInBuffSize, - 1);

	INT iRes    = SOCKET_ERROR;   
	INT iOffset = 0;   

	do {   
		if (iOffset > iInBuffSize - 2) { 
			return iOffset;   
		}

		iRes = m_scktSocket.iRecv(pszInBuff + iOffset, iInBuffSize - iOffset, iFlags);   
		/*DEBUG*/XASSERT_EX_RET(iRes >= 0, m_szRecv, - 1);	

		iOffset += iRes;   
		pszInBuff[iOffset] = '\0';   /////////////////////////////////////////////////////////////////
	} 
	while ((LPSTR)NULL == strstr(pszInBuff, "\r\n.\r\n"));   

	return iOffset;   
}   
//---------------------------------------------------------------------------
BOOL CPop3::bIsError(const std::string &csText) {
	/*DEBUG*/XASSERT_RET(FALSE == csText.empty(), TRUE);

	if (0 == memcmp(csText.c_str(), "+OK", 3)) {
		return FALSE;
	} 
	if (0 == memcmp(csText.c_str(), "-ERR", 4)) {
		return TRUE;
	} 
	
	/*DEBUG*/XASSERT_RET(FALSE, TRUE);
}
//---------------------------------------------------------------------------