/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXFso/CXPath.h>

#include <XLib/CXString.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
const std::string CXPath::ms_csWinSlash     = "\\"; //ms_csPathDelim
const std::string CXPath::ms_csUnixSlash    = "/";
const std::string CXPath::ms_csDriveDelim   = ":";
const std::string CXPath::ms_csPathSep      = ";";
const std::string CXPath::ms_csAllFilesMask = "*.*";
//---------------------------------------------------------------------------
CXPath::CXPath() {
	//code
}
//---------------------------------------------------------------------------
CXPath::~CXPath() {
	//code
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sExeDirPath() {
	return sExtractFileDir(sExePath());
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sExePath() {
	CHAR  szRes[MAX_PATH + 1] = {0};
	
	ULONG ulStored = ::GetModuleFileName(NULL, szRes, MAX_PATH);
	/*DEBUG*/XASSERT_RET(0    != ulStored, "");
	/*DEBUG*/XASSERT_RET(NULL != szRes,    "");        
	/*DEBUG*/XASSERT_RET('\0' != *szRes,   "");    

	return std::string(szRes, ulStored);	
}
//---------------------------------------------------------------------------
//��� + ���������
/*static*/std::string CXPath::sExtractFullFileName(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind(ms_csWinSlash, csFilePath.size());
	if (std::string::npos == uiEndOfPathIndex) {
		return "";
	}

	return csFilePath.substr(uiEndOfPathIndex + 1, csFilePath.size());
}
//--------------------------------------------------------------------------
//���
/*static*/std::string CXPath::sExtractFileName(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	return sRemoveFileExt(sExtractFullFileName(csFilePath));
}
//--------------------------------------------------------------------------
//Returns the path, without a trailing backslash '\'
/*static*/std::string CXPath::sExtractFileDir(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind(ms_csWinSlash, csFilePath.size());
	if (std::string::npos == uiEndOfPathIndex) {
		return "";
	}

	return csFilePath.substr(0, uiEndOfPathIndex);
}
//---------------------------------------------------------------------------
//����
/*static*/std::string CXPath::sExtractFileDrive(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiPos = csFilePath.find(ms_csDriveDelim);
	if (std::string::npos == uiPos) {
		return "";
	}

	return csFilePath.substr(0, uiPos + 1);

}
//---------------------------------------------------------------------------
//TODO: sExtractRelativePath
/*static*/std::string CXPath::sExtractRelativePath(const std::string &csFilePath) {

	return "";
}
//--------------------------------------------------------------------------
//TODO: sAddSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
/*static*/std::string CXPath::sAddSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	if ('\\' == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	}

	return csDirPath + ms_csWinSlash;
}
//--------------------------------------------------------------------------
//TODO: sDeleteSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
/*static*/std::string CXPath::sDeleteSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	const size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if ('\\' == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	}

	return csDirPath;
}
//--------------------------------------------------------------------------
//���������� ��� �����
/*static*/std::string CXPath::sExtractFileExt(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	return csFilePath.substr(csFilePath.rfind(".", csFilePath.size()) + 1);
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sChangeFileExt(const std::string &csFilePath, const std::string &csFileExt) {	
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if ('.' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileExt);

			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sChangeFullFileName(const std::string &csFilePath, const std::string &csFileName) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileName);

			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sRemoveFileExt(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.' - ������� ����� � ����������
		if ('.' == sRes.at(i - 1)) {
			sRes = sRes.erase(i - 1, sRes.size() - i + 1);

			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sMakeValidFileName(const std::string &csFileName) {
	const CHAR cszFatalChars[] = {'\\', '/', ':', '*', '<', '>', '|', '?', '"', '\t', '\n', '\r'};

	std::string sRes    = "";
	size_t      uiFound = 0;

	uiFound = csFileName.find_first_not_of(cszFatalChars);
	while (std::string::npos != uiFound) 	{
		std::string sChar(1, csFileName.at(uiFound));
		
		sRes.append(sChar);

		uiFound = csFileName.find_first_not_of(cszFatalChars, uiFound + 1);
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sGetEnvironmentVariable(const std::string &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(MAX_PATH, '\0');

	//not including the terminating null character
	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, ""); 

	sRes.resize(ulStored);

	if (sRes.size() < ulStored) {
		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, "");
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXPath::bSetEnvironmentVariable(const std::string &csVar, const std::string &csValue) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csVar.c_str(), csValue.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
/*static*/std::vector<std::string> CXPath::vecsGetEnvironmentStrings() {
	std::vector<std::string> vecsRes;

	LPSTR pszVar = NULL; 
	LPCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/XASSERT_RET(NULL != lpvEnv, std::vector<std::string>()); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPSTR)lpvEnv;

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		vecsRes.push_back(std::string(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	BOOL bRes = FALSE;

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sExpandEnvironmentStrings(const std::string &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(MAX_PATH, '\0');

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, ""); 

	sRes.resize(ulStored);	

	if (sRes.size() < ulStored) {
		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, "");
	}

	sRes.resize(ulStored - sizeof(CHAR));	//������� '\0', including the terminating null character

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sUnixToWinPath(const std::string &csUnixPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csUnixPath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csUnixPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('/' == sRes.at(i)) {
			sRes.at(i) = '\\';
		}
	}

	if (bNeedBackslashAtEnd && '\\' != sRes.at(sRes.size() - 1)) {
		sRes.append(ms_csWinSlash);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sWinToUnixPath(const std::string &csWinPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csWinPath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csWinPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('\\' == sRes.at(i)) {
			sRes.at(i) = '/';
		}
	}

	if (bNeedBackslashAtEnd && '/' != sRes.at(sRes.size() - 1)) {
		sRes.append(ms_csUnixSlash);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sMinimizeFileName(const std::string &csStr, const size_t cuiMaxLen) {	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,          "");

	std::string sRes("");
	std::string sTildaDotExt      = "~." + sExtractFileExt(csStr);
	size_t      uiTildaDotExtSize = sTildaDotExt.size();

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < uiTildaDotExtSize) {
			sRes = csStr.substr(0, cuiMaxLen);
		} else {
			sRes = csStr.substr(0, cuiMaxLen - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sMinimizePath(const std::string &csFilePath, const size_t cuiMaxLen) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,               "");

	std::string sRes("");
	sRes.assign(csFilePath);	

	std::string sDrive = sExtractFileDrive(csFilePath);					    //D:
	std::string sDir   = sExtractFileDir(csFilePath).erase(0, 2) + ms_csWinSlash;	//\XLib\Test\CXString\Project\Debug\ 
	std::string sName  = sExtractFullFileName(csFilePath);				    //Test.exe

	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/> cuiMaxLen)) { 
		if ((ms_csWinSlash + "..." + ms_csWinSlash) == sDir ) {
			sDrive.clear();
			sDir = "..." + ms_csWinSlash;
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			//-------------------------------
			//--sDir = _sCutFirstDirectory(sDir);
			BOOL   bRoot = FALSE;
			size_t P     = std::string::npos;

			if (ms_csWinSlash == sDir) {
				sDir.clear();
			} else {
				if (sDir.at(0) == '\\') {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = FALSE;
				}

				if ('.' == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//P = AnsiPos("\\", S); 
				P = sDir.find_first_of(ms_csWinSlash) + 1;

				if (std::string::npos != P) {
					//Delete(S, 1, P); - c ������� 1(0) P ��������
					sDir.erase(0, P);
					sDir = "..." + ms_csWinSlash + sDir;        
				} else {
					sDir.clear();
				}

				if (bRoot) {
					sDir = ms_csWinSlash + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------