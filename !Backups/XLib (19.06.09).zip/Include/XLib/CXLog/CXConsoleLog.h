/****************************************************************************
* Class name:  CXConsoleLog
* Description: ����������� ����� �������
* File name:   CXConsoleLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:53:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXConsoleLogH
#define CXConsoleLogH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <XLib/CXSync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXConsoleLog {
		_NO_COPY(CXConsoleLog);

	public:	
		     CXConsoleLog();
		    ~CXConsoleLog();
		BOOL bWrite      (LPCSTR pcszFormat, ...); /*+*/
		
	private:		
		static CXCriticalSection ms_csConsole;  
};
//---------------------------------------------------------------------------
#endif
