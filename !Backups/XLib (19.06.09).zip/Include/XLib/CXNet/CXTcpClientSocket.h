/****************************************************************************
* Class name:  CXTcpClientSocket
* Description: 
* File name:   CXTcpClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef CXClientSocketH
#define CXClientSocketH 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXTcpClientSocket { 
		_NO_COPY(CXTcpClientSocket);
		
    public: 
    	//
		typedef enum {
			etInvalid = INVALID_SOCKET,          
			tmError   = SOCKET_ERROR        
		} EErrorType;	
        
                	CXTcpClientSocket(SOCKET puiSocket = INVALID_SOCKET); 
                   ~CXTcpClientSocket(); 

    	BOOL        bCreate       (INT iAf, INT iType, INT iProtocol = 0); 
		BOOL        bIsReadible   ();
    	BOOL        bConnect      (LPCSTR cpszIp, USHORT usPort); 
    	INT         iSend         (LPCSTR cpszBuff, INT iSize, INT iFlags); 
    	INT         iRecv         (LPSTR pszBuf, INT iSize, INT iFlags); 
    	BOOL        bClose        (); 

		static BOOL bInit         (); 
		static BOOL bClean        (); 
    	static INT  iGetLastError (); 
    	static BOOL bDnsParse     (LPCSTR pcszDomain, LPSTR pszIp);


        CXTcpClientSocket& operator = (SOCKET s); 
    	operator SOCKET (); 

	protected: 
    	SOCKET m_puiSocket; 
}; 
//---------------------------------------------------------------------------
#endif


/*
---Server-----

Initialize Winsock.
Create a socket.
Bind the socket.
Listen on the socket for a client.
Accept a connection from a client.
Receive and send data.
Disconnect.
---Client----

Initialize Winsock.
Create a socket.
Connect to the server.
Send and receive data.
Disconnect.
*/