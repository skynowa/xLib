/****************************************************************************
*	CXButton
*
*****************************************************************************/


#ifndef CXButton_H
#define CXButton_H
//---------------------------------------------------------------------------
#include "CXSubclassWnd.h"
//---------------------------------------------------------------------------
class CXButton: public CXSubclassWnd {
	public:
		     CXButton  ();
		BOOL Create    (HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles);
		BOOL bCreateRes(HWND hParent, INT iResID);
		
		VOID (*OnCommand) (WPARAM wParam, LPARAM lParam);
};
//---------------------------------------------------------------------------
#endif