/****************************************************************************
* Class name:  CXDC
* Description: ������ � ���������� ����������
* File name:   CXDC.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.06.2009 21:30:49
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXDcH
#define CXDcH
//---------------------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------------------
class CXDC {
	public:
		         CXDC    ();
		virtual ~CXDC    ();
		BOOL     bAttach (HDC hDC);
		HDC      hDetach ();
		BOOL     bTextOut(INT xStart, INT yStart, std::string &csText, INT iText);
		BOOL     bTextOut(INT xStart, INT yStart, std::string &csText);
		
	private:
		HDC      _m_hDC;
};
//---------------------------------------------------------------------------------------
#endif