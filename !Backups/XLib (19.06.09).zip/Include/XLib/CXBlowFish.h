/**********************************************************************
*	����� CXBlowFish (CXBlowFish.h)
*
***********************************************************************/


#ifndef CXBlowFishH
#define CXBlowFishH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

  

//---------------------------------------------------------------------------
class CXBlowFish {
	public:
	                     CXBlowFish   ();
		                 ~CXBlowFish  ();
		void             vInitialize  (const char *pcszKey);
		int              iEncodeFile  (const char *pcszInFileName, const char *pcszOutFileName);
		int              iDecodeFile  (const char *pcszInFileName, const char *pcszOutFileName);
		void             vEncode      (unsigned char *pucIn, unsigned char *pucOut);
        void             vDecode      (unsigned char *pucIn, unsigned char *pucOut); 
		void             vShowErrorMsg(int code);

    private:
		unsigned int     ulFunction   (unsigned int uiData32);
		unsigned __int64 ui64Encode   (unsigned __int64 ui64Data64);  
		unsigned __int64 ui64Decode   (unsigned __int64 ui64Data64);  		
};
//---------------------------------------------------------------------------
#endif