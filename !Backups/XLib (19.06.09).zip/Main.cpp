/****************************************************************************
* Lib name:    XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>

//CXDso
#include <XLib/CXFso/CXPath.h>
#include <XLib/CXFso/CXFile.h>
#include <XLib/CXFso/CXIni.h>
#include <XLib/CXFso/CXDir.h>
#include <Xlib/CXFso/CXStdioFile.h>
#include <XLib/CXFso/CXDrive.h>

//CXLog
#include <XLib/CXLog/CXConsoleLog.h>
#include <XLib/CXLog/CXDbLog.h>
#include <XLib/CXLog/CXEventLog.h>
#include <XLib/CXLog/CXFileLog.h>
#include <XLib/CXLog/CXTraceLog.h>
#include <XLib/CXLog/CXWndLog.h>

//CXSync
#include <XLib/CXSync/CXCriticalSection.h>
#include <XLib/CXSync/CXEvent.h>
////#include <XLib/CXSync/CXLock.h>
#include <XLib/CXSync/CXMutex.h>
////#include <XLib/CXSync/CXScopeLocker.h>
#include <XLib/CXSync/CXSemaphore.h>
#include <XLib/CXSync/CXWaitableTimer.h>

//CXWinControls
#include <XLib/CXWinControls/CXWnd.h>
#include <XLib/CXWinControls/CXApp.h>
#include <XLib/CXWinControls/CXEdit.h>
#include <XLib/CXWinControls/CXStatic.h>
#include <XLib/CXWinControls/CXButton.h>
#include <XLib/CXWinControls/CXComboBox.h>
#include <XLib/CXWinControls/CXCheckBox.h>
#include <XLib/CXWinControls/CXGroupBox.h>
#include <XLib/CXWinControls/CXListBox.h>
#include <XLib/CXWinControls/CXListView.h>
#include <XLib/CXWinControls/CXRichEdit.h>
#include <XLib/CXWinControls/CXStatusBar.h>
#include <XLib/CXWinControls/CXProgressBar.h>
#include <XLib/CXWinControls/CXRadioButton.h>
#include <XLib/CXWinControls/CXTab.h>
#include <XLib/CXWinControls/CXTimer.h>
#include <XLib/CXWinControls/CXImageList.h>

//CXNet
#include <XLib/CXNet/CQueryList.hpp>
////#include <XLib/CXNet/CSMTPConn.h>
#include <XLib/CXNet/CXMimeHeader.h>
#include <XLib/CXNet/CXPop3.h>
#include <XLib/CXNet/CXSmtp.h>
#include <XLib/CXNet/CXTcpClientSocket.h>
#include <XLib/CXNet/CXTcpServerSocket.h>

//Other
#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXComPort.h>
#include <XLib/CXGuid.h>
#include <XLib/CXCrc32.h>
#include <XLib/CXHandleHolder.h>
#include <XLib/CXRandom.h>
#include <XLib/CXSafeMTLong.h>
#include <XLib/CXMsgBox.h>
#include <XLib/CXMsgBoxRtf.h>
////#include <XLib/CXMsgBoxRtfEx.h>
#include <XLib/CXPerform.h>
#include <XLib/CXClipboard.h>


#include <shellapi.h>
//---------------------------------------------------------------------------
int main(int argc /*, char* argv[]*/) {




	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------