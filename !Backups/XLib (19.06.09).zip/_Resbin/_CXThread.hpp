/**********************************************************************
*	����� CXThread (CXThread.h)
*
***********************************************************************/


#ifndef CXThreadH
#define CXThreadH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
//---------------------------------------------------------------------------
class CXThread {
	public:
	    CXThread();
		~CXThread();
		
		bool Run();

		//Suspend - Suspends the thread (if one is active)
		VOID Suspend();

		//Resume - Resumes a previously suspended thread
		VOID Resume();

		//Terminate - Terminates the thread (if one is active).
		//Prefer another means of exiting the thread, as
		//calling Terminate() does not allow the thread to free
		//any resources it may hold
		VOID Terminate();

		//IsThreadActive - Called in the context of another
		//(external) thread to test whether the thread is
		//currently running
		bool IsThreadActive() const;

		VOID ExitThread();
		bool ExitThreadAndWait(ULONG ulTimeoutMS);
		bool IsExitEventSet();
		
		/*-----------------------------------------------------------*/
		//SetPriority and GetPriority
		//IsRunning	Returns true if the thread is running.
		//IsTerminated	Returns true if the thread is terminated.
		//IsSuspend
		
    private:
		//Handle to the created Thread
		HANDLE m_hThread;

		//ID of the created thread
		UINT   m_uiThreadID;

		//ThreadFunc invoketion members
		HANDLE m_hExitThreadEvent;
};
//---------------------------------------------------------------------------
#endif




/**********************************************************************
*	����� CXThread (CXThread.cpp)
*
***********************************************************************/

////extern CXThread thT;
////
////UINT Counter; 
//---------------------------------------------------------------------------
UINT __stdcall DoExitableWork(VOID *pParam) {
	while (Counter < 1000000) {
		if (true == thT.IsExitEventSet()) {
			::MessageBox(0, "IsExitEventSet() == true", "_endthreadex(0);", MB_OK);
			_endthreadex(0);
			return 0;
		}

		Counter++;
		::Sleep(20);
	}


	::MessageBox(0, "DoExitableWork - ending....", "_endthreadex(0)", MB_OK);
	_endthreadex(0);

	return 0;
}
//---------------------------------------------------------------------------
CXThread::CXThread() {
	m_hExitThreadEvent = NULL;
	m_hExitThreadEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);

	//MessageBox(0, "CXThread()", "", MB_OK);
}
//---------------------------------------------------------------------------
CXThread::~CXThread() {
	if (m_hExitThreadEvent)	{
		::CloseHandle(m_hExitThreadEvent);
		m_hExitThreadEvent = NULL;
	}

	if (IsThreadActive()) {
		Terminate();
	}

	//MessageBox(0, "~CXThread()", "", MB_OK);
}
//--------------------------------------------------------------------------
bool CXThread::Run(/*struct*/) {
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, &DoExitableWork, (LPVOID)this/*struct*/, /*0*/CREATE_SUSPENDED, &m_uiThreadID);
	
	return (m_hThread != NULL);
}
//--------------------------------------------------------------------------
//Suspend - Suspends the thread (if one is active)
VOID CXThread::Suspend() {
	::SuspendThread(m_hThread);
}
//--------------------------------------------------------------------------
//Resume - Resumes a previously suspended thread
VOID CXThread::Resume() {
	INT resumeCount = ::ResumeThread(m_hThread);
	while (resumeCount > 1) {
		resumeCount = ::ResumeThread(m_hThread);
	}
}
//--------------------------------------------------------------------------
//Terminate - Terminates the thread (if one is active).
//Prefer another means of exiting the thread, as
//calling Terminate() does not allow the thread to free
//any resources it may hold
VOID CXThread::Terminate() {
    if (m_hThread) {
	    ::TerminateThread(m_hThread, 0);
	    ::CloseHandle(m_hThread);
        m_hThread = NULL;
    }
}
//--------------------------------------------------------------------------
bool CXThread::IsThreadActive() const {
	return ((m_hThread != NULL) && (::WaitForSingleObject(m_hThread, 0) != WAIT_OBJECT_0));
}
//--------------------------------------------------------------------------	
void CXThread::ExitThread() {
	::SetEvent(m_hExitThreadEvent);
}
//--------------------------------------------------------------------------
bool CXThread::ExitThreadAndWait(ULONG ulTimeoutMS) {
	//Set the event telling the thread to exit
	::SetEvent(m_hExitThreadEvent);

	//Wait for the thread to actually exit
	ULONG ulRes = ::WaitForSingleObject(m_hThread, ulTimeoutMS);

	//Cleanup handle
	::CloseHandle(m_hThread);
	m_hThread = NULL;

	return (ulRes == WAIT_OBJECT_0);
}
//--------------------------------------------------------------------------
bool CXThread::IsExitEventSet() {
	ULONG ulRes = ::WaitForSingleObject(m_hExitThreadEvent, 0);
	
	return (ulRes == WAIT_OBJECT_0);
}
//--------------------------------------------------------------------------
		
		
		
		
		
		
		
		
		
		

/*
	static enum {DW_OK					= 0x00000000,
				 DW_ERROR				= 0xFFFFFFFF,
				 DW_UNDEFINED			= 0xFFFFFFFE,
				 DW_TIMEOUT_ELAPSED		= 0xFFFFFFFD,
				 DW_INFINITE			= INFINITE,
				 THREAD_CREATED			= 0,
				 THREAD_STOPPED			= 1,
				 THREAD_RUNNING			= 2,
				 THREAD_PAUSED			= 3,
				 THREAD_CONTINUING		= 4,
				 THREAD_PENDING			= 5,
				 THREAD_USER_ACTIVITY	= 6};
*/