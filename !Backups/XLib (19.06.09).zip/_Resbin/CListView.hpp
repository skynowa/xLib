/**********************************************************************
*	����� CListView (CListView.h)
*
***********************************************************************/


#ifndef CListViewH
#define CListViewH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------------------------------
class CListView {
	public:
	                CListView          ();
		            ~CListView          ();

		void        vInit              (HWND hParent, int iRes);
		void        vClear             ();
		void        vAdd               (unsigned short iItem);
		void        vAddItem           (unsigned short iItem, LPTSTR pszCaption, LPTSTR pszSubItem1, LPTSTR pszSubItem2, LPTSTR pszSubItem3, LPTSTR pszSubItem4, LPTSTR pszSubItem5, LPTSTR pszSubItem6);
		void        vCaption           (unsigned short iItem, LPTSTR pszText);
		void        vSetSubItem        (unsigned short iItem, unsigned short SubItem, LPTSTR pszText);
		std::string vGetSubItem        (unsigned short iItem, unsigned short SubItem);
		int         iGetSelIndex       ();
		int         iItemsCount        ();
		void        vInsertColumn      (char *pszText, int iWidth, int nColumn);
		void        vSelectItem        (unsigned short nIndex);
		void        vDeleteItem        (unsigned short nIndex);
		void        vDeleteSelectedItem();
		void        vSwapItems         (int nSourceIndex, int nDestIndex);
		void        vSetGridLines      (bool bMode);
		void        vFullRowSelect     (bool bMode);

		void        vMoveFirst         ();	/*-*/
		void        vMoveLast          ();	/*-*/
		
    private:
		HWND m_hLV;	 
};
//---------------------------------------------------------------------------
#endif


/**********************************************************************
*	����� CListView (CListView.cpp)
*
***********************************************************************/

//---------------------------------------------------------------------------
CListView::CListView() {	
	m_hLV = NULL;
}
//---------------------------------------------------------------------------
CListView::~CListView() {	
	DestroyWindow(m_hLV);
}
//---------------------------------------------------------------------------
void CListView::vInit(HWND hParent, int iRes) {
	m_hLV = GetDlgItem(hParent, iRes);
}
//---------------------------------------------------------------------------
void CListView::vClear() {
	SetFocus(m_hLV);
	SendMessage(m_hLV, LVM_DELETEALLITEMS, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
void CListView::vAdd(unsigned short iItem) {
	SetFocus(m_hLV);

	//������ ������
	LV_ITEM lvi;	memset(&lvi, 0, sizeof(lvi));
	lvi.mask       = LVIF_TEXT;
	lvi.cchTextMax = TEXT_LEN;
	lvi.iItem      = iItem;
	lvi.pszText    = "";
	lvi.iSubItem   = 0;
	SendMessage(m_hLV, LVM_INSERTITEM, (WPARAM)0,(LPARAM)&lvi);  
}
//---------------------------------------------------------------------------
void CListView::vAddItem(unsigned short iItem, LPTSTR pszCaption, LPTSTR pszSubItem1, LPTSTR pszSubItem2, LPTSTR pszSubItem3, LPTSTR pszSubItem4, LPTSTR pszSubItem5, LPTSTR pszSubItem6) {
	SetFocus(m_hLV);

	//������ ������
	LV_ITEM lvi;	memset(&lvi, 0, sizeof(lvi));
	lvi.mask       = LVIF_TEXT;
	lvi.cchTextMax = TEXT_LEN;
	lvi.iItem      = iItem;
	lvi.pszText    = "";
	lvi.iSubItem   = 0;
	SendMessage(m_hLV, LVM_INSERTITEM, (WPARAM)0,(LPARAM)&lvi);      

	//���������
	lvi.iSubItem = 0;
	lvi.pszText  = pszCaption;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi);

	//���������
	lvi.iSubItem = 1;
	lvi.pszText  = pszSubItem1;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 

	lvi.iSubItem = 2;
	lvi.pszText  = pszSubItem2;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 

	lvi.iSubItem = 3;
	lvi.pszText  = pszSubItem3;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 

	lvi.iSubItem = 4;
	lvi.pszText  = pszSubItem4;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 

	lvi.iSubItem = 5;
	lvi.pszText  = pszSubItem5;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 

	lvi.iSubItem = 6;
	lvi.pszText  = pszSubItem6;
	SendMessage(m_hLV, LVM_SETITEM, (WPARAM)0, (LPARAM)&lvi); 
}
//---------------------------------------------------------------------------
void CListView::vCaption(unsigned short iItem, LPTSTR pszText) {
	SetFocus(m_hLV);

	LV_ITEM lvi;	memset(&lvi, 0, sizeof(lvi));
	lvi.mask       = LVIF_TEXT;
	lvi.cchTextMax = TEXT_LEN;
	lvi.iItem      = iItem;
	lvi.pszText    = pszText;
	lvi.iSubItem   = 0; 
	SendMessage(m_hLV, LVM_SETITEM, 0, (WPARAM) &lvi);
}
//---------------------------------------------------------------------------
void CListView::vSetSubItem(unsigned short iItem, unsigned short SubItem, LPTSTR pszText) {
	SetFocus(m_hLV);
	
	LV_ITEM lvi;	memset(&lvi, 0, sizeof(lvi));
	lvi.mask       = LVIF_TEXT;
	lvi.cchTextMax = TEXT_LEN;
	lvi.iItem      = iItem;
	lvi.iSubItem = SubItem;
	lvi.pszText  = pszText;
	SendMessage(m_hLV, LVM_SETITEM, 0, (WPARAM) &lvi);
}
//---------------------------------------------------------------------------
std::string CListView::vGetSubItem(unsigned short iItem, unsigned short SubItem) {
	char szBuf[MAX_PATH];	memset(szBuf, 0, sizeof(szBuf));
	
	LVITEM lvi;		memset(&lvi, 0, sizeof(lvi));
    lvi.mask       = LVIF_TEXT;
    lvi.iItem      = iItem;
    lvi.iSubItem   = SubItem;	            //6 - File Path
    lvi.pszText    = szBuf;
    lvi.cchTextMax = sizeof(szBuf) / sizeof(char);
	SendMessage(m_hLV, LVM_GETITEM, 0, (LPARAM)&lvi);

	return std::string(szBuf);
}
//---------------------------------------------------------------------------
int CListView::iGetSelIndex() {
	return SendMessage(m_hLV, LVM_GETNEXTITEM, -1, LVNI_SELECTED);
}
int CListView::iItemsCount() {
	return (int)SendMessage(m_hLV, LVM_GETITEMCOUNT, 0, 0L);
}
//---------------------------------------------------------------------------
void CListView::vInsertColumn(char *pszText, int iWidth, int nColumn) {
	SetFocus(m_hLV);

	LVCOLUMN lvc;	memset(&lvc, 0, sizeof(lvc));
	lvc.mask    = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 	
	lvc.fmt     = LVCFMT_LEFT;
	lvc.pszText = pszText; 
	lvc.cx      = iWidth;
	SendMessage(m_hLV, LVM_INSERTCOLUMN, nColumn, (LPARAM)&lvc);	//nColumn 01234
}
//---------------------------------------------------------------------------
void CListView::vSelectItem(unsigned short nIndex) {
	SetFocus(m_hLV);

	LV_ITEM lvi;	memset(&lvi, 0, sizeof(lvi));
	lvi.mask     = LVIF_STATE;
	lvi.state    = lvi.stateMask = LVIS_SELECTED | LVIS_FOCUSED;
	lvi.iSubItem = 0;
	lvi.iItem    = nIndex;
	SendMessage(m_hLV, LVM_SETITEM, 0, (LPARAM) &lvi);
}
//---------------------------------------------------------------------------
void CListView::vDeleteItem(unsigned short nIndex) {
	SetFocus(m_hLV);
	SendMessage(m_hLV, LVM_DELETEITEM, (WPARAM)nIndex, 0);
}
//---------------------------------------------------------------------------
void CListView::vDeleteSelectedItem() {
	SetFocus(m_hLV);

	int iItemIndex = SendMessage(m_hLV, LVM_GETNEXTITEM, -1, LVNI_SELECTED);
	vDeleteItem(iItemIndex);
}
//---------------------------------------------------------------------------
void CListView::vSwapItems(int nSourceIndex, int nDestIndex) {
	//get source
	char szSourceText[255];	memset(szSourceText, 0, sizeof(szSourceText)); 

	LVITEM lvSItem;		memset(&lvSItem, 0, sizeof(lvSItem));
	lvSItem.iSubItem   = 0;
	lvSItem.cchTextMax = 255;
	lvSItem.iItem      = nSourceIndex;
	lvSItem.pszText    = szSourceText;
	lvSItem.mask       = (LVIF_PARAM | LVIF_TEXT | LVIF_IMAGE);
	ListView_GetItem(m_hLV, &lvSItem);

	//get dest
	char szDestText[255];	memset(szDestText, 0, sizeof(szDestText));

	LVITEM lvDItem;		memset(&lvDItem, 0, sizeof(lvDItem));
	lvDItem.iSubItem   = 0;
	lvDItem.cchTextMax = 255;
	lvDItem.iItem      = nDestIndex;
	lvDItem.pszText    = szDestText;
	lvDItem.mask       = (LVIF_PARAM | LVIF_TEXT | LVIF_IMAGE);
	ListView_GetItem(m_hLV, &lvDItem);

	//now swap
	lvSItem.iItem = nDestIndex;              
	lvDItem.iItem = nSourceIndex; 

	lvSItem.iSubItem = nDestIndex;     //--         
	lvDItem.iSubItem = nSourceIndex; //--

	ListView_SetItem(m_hLV, &lvSItem);
	ListView_SetItem(m_hLV, &lvDItem);

	vSelectItem(nDestIndex);	
}
//---------------------------------------------------------------------------
void CListView::vSetGridLines(bool bMode) {
	if (bMode == true) {
		SendMessage(m_hLV, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_GRIDLINES, LVS_EX_GRIDLINES);
	} else {
		//���� ��� �����
	}
}
//---------------------------------------------------------------------------
void CListView::vFullRowSelect(bool bMode) {
	if (bMode == true) {
		SendMessage(m_hLV, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
	} else {
		//���� ��� �����
	}		
}
//---------------------------------------------------------------------------