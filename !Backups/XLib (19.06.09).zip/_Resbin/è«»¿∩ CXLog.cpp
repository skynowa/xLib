/****************************************************************************
* Class name:  CXLog
* Description: �����������
* File name:   CXLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 10:24:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXLog.h>

#include <stdio.h>
#include <stdlib.h>
#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
CXLog::CXLog() {

}
//---------------------------------------------------------------------------
CXLog::CXLog(const std::string &csFileName, ULONG ulMaxFileSize = 20) {
	if (std::string::npos != csFileName.find('\\')) {
		m_sLogPath = sExtractFileDir(sExePath()) + csFileName;
	} else {
		m_sLogPath = sExtractFileDir(sExePath()) + csFileName;
	}

	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::CXLog(ULONG ulMaxFileSize = 20) {
	m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + sExtractFullFileName(sExePath()) + ".log";
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	

}
//---------------------------------------------------------------------------


/****************************************************************************
*	vLog
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csStr) {     
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	//--FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	CXStdioFile sfFile;
	sfFile.bOpen(m_sLogPath, "a");
	
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csStr.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);						
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, const std::string &csStr) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csStr.c_str());	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, INT iValue) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %i\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), iValue);	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, ULONG ulValue) {
	this->vDeleteLogIfFull();
	
	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %ul\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), ulValue);	//ul?????

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogLastErrorStr(const std::string &csComment, ULONG ulLastError) {
	this->vDeleteLogIfFull();

	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);

	fprintf(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sLastErrorStr(ulLastError));	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogUCharAsHex(const std::string &csComment, UCHAR *pucBuff, ULONG ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes = "";   
	for (UINT i = 0; i < ulBuffSize; i ++) {
		if (pucBuff[i] < 16) {  
			CHAR szTemp[6] = {0};
			::wsprintf(szTemp, "0x0%x ", pucBuff[i]);
			sRes.append(szTemp);
		} else {
			CHAR szTemp[6] = {0};
			::wsprintf(szTemp, "0x%2x ", pucBuff[i]);
			sRes.append(szTemp);
	    }
	}

	//-------------------------------------
	//����� ���
	/*LOCK*/m_csLog.vEnter();
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogUCharAsStr(const std::string &csComment, UCHAR *pucBuff, ULONG ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes = ""; 
	for (UINT i = 0; i < ulBuffSize; i ++) {
		//sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
		sRes.push_back((CHAR)pucBuff[i]);      //???????????
	}

 	//-------------------------------------
 	//����� ���
 	/*LOCK*/m_csLog.vEnter();
 	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
 	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

 	/*UNLOCK*/m_csLog.vLeave();
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vTrace
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csStr) {
	::OutputDebugString((csStr + "\r\n").c_str());	//VERIFY
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, const std::string &csStr) {
	::OutputDebugString((csComment + "--->" + csStr + "\r\n").c_str());	
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, INT iValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(iValue) + "\r\n").c_str());
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, ULONG ulValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(ulValue) + "\r\n").c_str());
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
VOID CXLog::vTraceLastError(const std::string &csComment, ULONG ulLastError) {
	::OutputDebugString((csComment + "--->" + sLastErrorStr(ulLastError) + "\r\n").c_str());
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csStr) {
	/*DEBUG*/XASSERT_RET(NULL != hLst, (VOID)NULL);

	std::string sRes("");
	sRes.assign(csStr);

	sRes = sRemoveEOL(sRes);

	/*LOCK*/m_csLogToLst.vEnter();
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sRes.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/m_csLogToLst.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, const std::string &csStr) {
	/*DEBUG*/XASSERT_RET(NULL != hLst, (VOID)NULL);

	std::string sRes("");
	sRes = csComment + " --> " + csStr;
	sRes = sRemoveEOL(sRes);

	/*LOCK*/m_csLogToLst.vEnter();
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sRes.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/m_csLogToLst.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, INT iValue) {
	/*DEBUG*/XASSERT_RET(NULL != hLst, (VOID)NULL);

	std::string sRes("");
	sRes = csComment + " --> " + sTypeToStr(iValue);
	sRes = sRemoveEOL(sRes);

	/*LOCK*/m_csLogToLst.vEnter();
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sRes.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/m_csLogToLst.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, ULONG ulValue) {
	/*DEBUG*/XASSERT_RET(NULL != hLst, (VOID)NULL);

	std::string sRes("");
	sRes = csComment + " --> " + sTypeToStr(ulValue)/*csStr*/;
	sRes = sRemoveEOL(sRes);

	/*LOCK*/m_csLogToLst.vEnter();
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sRes.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/m_csLogToLst.vLeave();
}
//---------------------------------------------------------------------------
VOID CXLog::vLogLastErrorToLst(HWND hLst, const std::string &csComment, ULONG ulLastError) {
	/*DEBUG*/XASSERT_RET(NULL != hLst, (VOID)NULL);
	
	std::string sRes("");
	sRes = csComment + " --> " + sLastErrorStr(ulLastError);
	sRes = sRemoveEOL(sRes);

	/*LOCK*/m_csLogToLst.vEnter();
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sRes.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/m_csLogToLst.vLeave();
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vDelete() {
	//-------------------------------------
	//CHECK
    if (false == bFileExists(m_sLogPath)) {
		return;
	}	

	//-------------------------------------
	//JOB
	if (false == bSetFileAttr(m_sLogPath, faNormal)) {
        /*DEBUG*/XASSERT(false);
    }
    if (false == bDeleteFile(m_sLogPath)) {
        /*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
VOID CXLog::vOpen() {
	STARTUPINFO         si = {0};
	PROCESS_INFORMATION pi = {0};
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.2\\notepad++.exe " + m_sLogPath; 
	if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	::Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
VOID CXLog::vClear() {
	FILE *pFile = fopen(m_sLogPath.c_str(), "w");
	/*DEBUG*/XASSERT(NULL != pFile);
	
	/*LOCK*/m_csLog.vEnter();
	
	fprintf(pFile, "");	
	
	/*UNLOCK*/m_csLog.vLeave();

    /*DEBUG*/XASSERT(NULL != pFile);
	fflush(pFile);
	fclose(pFile);	pFile = NULL;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Other
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vMsgBoxLastError(const std::string &csComment) {
	ULONG       ulLastError = ::GetLastError();
	std::string sRes        = csComment + " ---> " + sLastErrorStr(ulLastError);

	::MessageBox(0, sRes.c_str(), "Last error", MB_OK);
}
//---------------------------------------------------------------------------




/****************************************************************************
*	Private methodz
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vDeleteLogIfFull() {
	//-------------------------------------
	//CHECK
	if (false == bFileExists(m_sLogPath)) {
		return;
	}
	
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ulFileSize(m_sLogPath) / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------