/****************************************************************************
* Class name:  CxTcpClientSocket
* Description: client socket
* File name:   CxTcpClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <xLib/Net/CxTcpClientSocket.h> 

//---------------------------------------------------------------------------
//TODO: + CxTcpClientSocket
/*virtual*/
CxTcpClientSocket::CxTcpClientSocket() {
	////--bSetTimeout(0, CxSocket::CxOptions::SOCKET_TIMEOUT);
}
//---------------------------------------------------------------------------
//TODO: + ~CxTcpClientSocket
CxTcpClientSocket::~CxTcpClientSocket() {

}
//---------------------------------------------------------------------------
//TODO: bIoctl (The ioctlsocket function controls the I/O mode of a socket.)
BOOL
CxTcpClientSocket::bIoctl(LONG liCmd, ULONG *pulArgp) {
#if defined(xOS_WIN)
    /*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

    _m_iRes = ::ioctlsocket(_m_puiSocket, liCmd, pulArgp);
    /*DEBUG*/xASSERT_RET(etError != _m_iRes, FALSE);
#elif defined(xOS_LINUX)
    xNOT_IMPLEMENTED_RET(FALSE);
#endif

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetNonBlockingMode
BOOL
CxTcpClientSocket::bSetNonBlockingMode(const BOOL cbFlag) {
#if defined(xOS_WIN)
	ULONG ulNonBlockingMode = static_cast<ULONG>(cbFlag);

	_m_bRes = bIoctl(FIONBIO, static_cast<ULONG FAR *>(&ulNonBlockingMode));
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	/*int bOptVal = TRUE;
	int bOptLen = sizeof(int);
	setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (char*)&bOptVal, bOptLen);*/
#elif defined(xOS_LINUX)
	INT iFlags;

	iFlags = fcntl(_m_puiSocket, F_GETFL);
	xCHECK_RET(etError == iFlags, FALSE);
		
	if (TRUE == cbFlag) {
		iFlags = (iFlags | O_NONBLOCK);
	} else {
		iFlags = (iFlags & ~O_NONBLOCK);
	}

	fcntl(_m_puiSocket, F_SETFL, iFlags);
#endif

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsReadible
BOOL
CxTcpClientSocket::bIsReadable() {
	timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	fd_set  fds       = {{0}};  FD_ZERO(&fds);

	FD_SET(_m_puiSocket, &fds); 

	_m_iRes = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	xCHECK_RET(_m_iRes <= 0 || !FD_ISSET(_m_puiSocket, &fds), FALSE); 

	return TRUE;
}  
//---------------------------------------------------------------------------
//TODO: + bIsWritable
BOOL
CxTcpClientSocket::bIsWritable() {
	timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	fd_set  fds       = {{0}};  FD_ZERO(&fds);

	FD_SET(_m_puiSocket, &fds); 

	_m_iRes = ::select(0, NULL, &fds, NULL, &tvTimeout);   
	xCHECK_RET(_m_iRes <= 0 || !FD_ISSET(_m_puiSocket, &fds), FALSE); 

	return TRUE;
}  
//--------------------------------------------------------------------------- 
//TODO: + bConnect
BOOL
CxTcpClientSocket::bConnect(const tString &csIp, USHORT usPort) {
	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket,        FALSE);
	/*DEBUG*/xASSERT_RET(false     == csIp.empty(),        FALSE);
	/*DEBUG*/xASSERT_RET((65535 > usPort) && (0 < usPort), FALSE);

	//конверт из UNICODE
	std::string asIp(csIp.begin(), csIp.end());

	sockaddr_in saSockAddr = {0};		   
	saSockAddr.sin_family      = _m_siFamily; 
	saSockAddr.sin_addr.s_addr = inet_addr(asIp.c_str());   
	saSockAddr.sin_port        = ::htons(usPort); //???????

	_m_iRes = ::connect(_m_puiSocket, (sockaddr *)&saSockAddr, sizeof(saSockAddr));  
	/*DEBUG*/xASSERT_RET(etError != _m_iRes, FALSE);

	return TRUE;   
}    
//---------------------------------------------------------------------------
BOOL
CxTcpClientSocket::bSetTimeout(LONG liSec, LONG liMicroSec) {
	/*DEBUG*/
	
	_m_tvTimeout.tv_sec  = liSec;
	_m_tvTimeout.tv_usec = liMicroSec;
	
	return TRUE;
} 
//---------------------------------------------------------------------------
BOOL
CxTcpClientSocket::bGetTimeout(LONG *pliSec, LONG *pliMicroSec) {
	/*DEBUG*/
	
	*pliSec      = _m_tvTimeout.tv_sec;
	*pliMicroSec = _m_tvTimeout.tv_usec;
	
	return TRUE;
} 
//---------------------------------------------------------------------------


/****************************************************************************
*	public: static
*
*****************************************************************************/

//--------------------------------------------------------------------------- 
//TODO: + bIsServerAlive
/*static*/
BOOL
CxTcpClientSocket::bIsServerAlive(const tString &csIp, USHORT usPort) {
	/*DEBUG*/xASSERT_RET(false == csIp.empty(),            FALSE);
	/*DEBUG*/xASSERT_RET((65535 > usPort) && (0 < usPort), FALSE);

	BOOL bIsAlive = FALSE;
	BOOL bRes     = FALSE;
	INT  iRes     = - 1;

	CxTcpClientSocket objSocket;

	//-------------------------------------
	//bCreate
	bRes = objSocket.bCreate(CxSocket::afIPv4, CxSocket::tpStream, CxSocket::ptIp);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//bConnect
	//convert from UNICODE
	std::string asIp(csIp.begin(), csIp.end());

	sockaddr_in saSockAddr = {0};
	saSockAddr.sin_family      = CxSocket::afIPv4;
	saSockAddr.sin_addr.s_addr = inet_addr(asIp.c_str());
	saSockAddr.sin_port        = ::htons(usPort); //???????

	//connect - [+] 0 [-] SOCKET_ERROR
	iRes = ::connect(objSocket.iGetSocket(), (sockaddr *)&saSockAddr, sizeof(saSockAddr));
	/*DEBUG*/// n/a

	(0 == iRes) ? (bIsAlive = TRUE) : (bIsAlive = FALSE);

	//-------------------------------------
	//bClose
#if defined(xOS_WIN)
    iRes = ::closesocket(objSocket.iGetSocket());
    /*DEBUG*/xASSERT_RET(etError != iRes, FALSE);
#elif defined(xOS_LINUX)
    iRes = ::close(objSocket.iGetSocket());
    /*DEBUG*/xASSERT_RET(etError != iRes, FALSE);
#endif

    ////objSocket = etInvalid;

	return bIsAlive;  
}
//---------------------------------------------------------------------------
 
