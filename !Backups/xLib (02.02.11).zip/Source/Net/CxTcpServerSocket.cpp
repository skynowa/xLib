/****************************************************************************
* Class name:  CxTcpServerSocket
* Description: server socket
* File name:   CxTcpServerSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <xLib/Net/CxTcpServerSocket.h> 


//---------------------------------------------------------------------------  
//TODO: + CxTcpServerSocket
CxTcpServerSocket::CxTcpServerSocket() {   
	////bSetTimeout(0, COptions::SOCKET_TIMEOUT);
} 
//---------------------------------------------------------------------------  
//TODO: + ~CxTcpServerSocket 
CxTcpServerSocket::~CxTcpServerSocket() {

}
//---------------------------------------------------------------------------
//TODO: - bBind (associates a local address with a socket.) 
BOOL
CxTcpServerSocket::bBind(USHORT usPort) {
    #if defined(xOS_WIN)
        //TODO: xOS_WIN
        /*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket,        FALSE);
        /*DEBUG*/xASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

        struct sockaddr_in saSockAddr = {0};
        saSockAddr.sin_family      = _m_siFamily;
        saSockAddr.sin_addr.s_addr = INADDR_ANY;
        saSockAddr.sin_port        = htons(usPort);

        _m_iRes = ::bind(_m_puiSocket, (const struct sockaddr *)&saSockAddr, sizeof(saSockAddr));
        /*DEBUG*/xASSERT_RET(etError != _m_iRes, FALSE);

        ////INT iOpt = 1;
        //???
        ////if (::setsockopt(_m_puiSocket, SOL_SOCKET, SO_REUSEADDR, (LPSTR)&iOpt, sizeof(iOpt)) < 0) {
        ////    return FALSE;
        ////}
    #elif defined(xOS_LINUX)
        //TODO: xOS_LINUX
        xNOT_IMPLEMENTED_RET(FALSE);
    #endif

    return TRUE;   
}   
//--------------------------------------------------------------------------- 
//TODO: - bListen (places a socket in a state in which it is listening for an incoming connection) 
BOOL
CxTcpServerSocket::bListen(INT iBacklog /*= SOMAXCONN*/) {
    #if defined(xOS_WIN)
        //TODO: xOS_WIN
    	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket, FALSE);

        _m_iRes = ::listen(_m_puiSocket, iBacklog);
        /*DEBUG*/xASSERT_RET(etError != _m_iRes, FALSE);
    #elif defined(xOS_LINUX)
        //TODO: xOS_LINUX
        xNOT_IMPLEMENTED_RET(FALSE);
    #endif

    return TRUE;   
}   
//---------------------------------------------------------------------------  
//TODO: - bAccept (permits an incoming connection attempt on a socket)
BOOL
CxTcpServerSocket::bAccept(CxTcpServerSocket *pscktAcceptSocket, tString *psFromIp) {
    #if defined(xOS_WIN)
        //TODO: xOS_WIN
    	/*DEBUG*/xASSERT_RET(etInvalid != _m_puiSocket,      FALSE);
        /*DEBUG*/xASSERT_RET(NULL      != pscktAcceptSocket, FALSE);
        /*DEBUG*/xASSERT_RET(NULL      != psFromIp,          FALSE);

        SOCKET scktClient = etInvalid;

        struct sockaddr_in cliaddr  = {0};
        INT                iAddrlen = sizeof(cliaddr);

        scktClient = ::accept(_m_puiSocket, (struct sockaddr *)&cliaddr, &iAddrlen);
        /*DEBUG*/xASSERT_RET(etInvalid != scktClient, FALSE);

        //TODO:
        ////scktAcceptSocket = scktClient;
        _m_bRes = (* pscktAcceptSocket).bAssign(scktClient);
        /*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

        //конверт из UNICODE
        std::string asFromIp = inet_ntoa(cliaddr.sin_addr);
    
        (*psFromIp).assign(asFromIp.begin(), asFromIp.end());
    #elif defined(xOS_LINUX)
        //TODO: xOS_LINUX
        xNOT_IMPLEMENTED_RET(FALSE);
    #endif
    
    return TRUE;   
}   
//---------------------------------------------------------------------------  
 
