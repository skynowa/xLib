/****************************************************************************
* Class name:  CxSystemInfo
* Description: system information
* File name:   CxSystemInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/CxSystemInfo.h>

#include <xLib/Fso/CxEnvironment.h>
#if defined(xOS_WIN)
    #include <Lmcons.h>
#elif defined(xOS_LINUX)
    #include <sys/utsname.h>
    #include <sys/sysinfo.h>
#endif

/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: osGetOS ()
/*static*/
CxSystemInfo::EOsType
CxSystemInfo::osGetOS() {
    /*DEBUG*/// n/a

#if defined(xOS_WIN)
    OSVERSIONINFO OSversion = {0};

    OSversion.dwOSVersionInfoSize = sizeof(OSversion);
    ::GetVersionEx(&OSversion);

    // This switch statement comes from
    // http://www.codeproject.com/win32/osdetect.asp
    // Originally written by Agus Kurniawan, but I've
    // modified it a bit.

    switch (OSversion.dwPlatformId) {
        case VER_PLATFORM_WIN32s:
            return otWindows3;

        case VER_PLATFORM_WIN32_WINDOWS:
            {
                if (0 == OSversion.dwMinorVersion) {
                    return otWindows95;
                }
                else if (10 == OSversion.dwMinorVersion) {
                    return otWindows98;
                }
                else if (90 == OSversion.dwMinorVersion) {
                    return otWindows98;
                }
            }
            break;

        case VER_PLATFORM_WIN32_NT:
            {
                if (5 == OSversion.dwMajorVersion && 0 == OSversion.dwMinorVersion) {
                    return otWindows2000;
                }
                else if (5 == OSversion.dwMajorVersion &&  1 == OSversion.dwMinorVersion) {
                    return otWindowsXP;
                }
                else if (OSversion.dwMajorVersion <= 4) {
                    return otWindowsNT;
                }
                else {
                    //for unknown windows/newest windows version
                    return otWindows2003;
                }
            }
            /*break;*/

        default:
            return otUnknown;
            /*break;*/
    }
#elif defined(xOS_LINUX)
    return otLinux;
#endif

	return otUnknown;
}
//---------------------------------------------------------------------------
//DONE: sFormatOSVersion ()
/*static*/
tString 
CxSystemInfo::sFormatOSVersion(ULONG ulOSVersion) {
	/*DEBUG*/// ulOsVersion - n/a

	tString sRes;

#if defined(xOS_WIN)
    //#define xWIN32_NT4       	0x0400	//Windows NT 4.0
    //#define xWIN32_2K     	0x0500	//Windows 2000
    //#define xWIN32_XP    	    0x0501	//Windows Server 2003, Windows XP
    //#define xWIN32_S03      	0x0502	//Windows Server 2003 with SP1, Windows XP with SP2
    //#define xWIN32_WIN6     	0x0600	//
    //#define xWIN32_VISTA     	0x0600	//Windows Vista
    //#define xWIN32_S08      	0x0600	//Windows Server 2008
    //#define xWIN32_LONGHORN   0x0600	//
    //#define xWIN32_7      	0x0601	//Windows 7

    switch (ulOSVersion) {
        case xWIN32_NT4:   { sRes = xT("Win NT 4.0");                      }	break;
        case xWIN32_2K:    { sRes = xT("Win 2000");                        }	break;
        case xWIN32_XP:    { sRes = xT("Win Server 2003, Win XP");         }	break;
        case xWIN32_S03:   { sRes = xT("Win Server 2003 SP1, Win XP SP2"); }	break;
        case xWIN32_VISTA: { sRes = xT("Win Vista, Win Server 2008");      }	break;
        case xWIN32_7:     { sRes = xT("Win 7");                           }	break;

        default:		   { sRes = xT("Unknown Win OS");                  }	break;
    }
#elif defined(xOS_LINUX)
    /*struct utsname {
        sysname    char[65];  // "Linux"
        nodename   char[65];  // "user-exm-5"
        release    char[65];  // "2.6.35-24-generic"
        version    char[65];  // "#42-Ubuntu SMP Thu Dec 2 01:41:57 UTC 2010"
        machine    char[65];  // "i686"
        domainname char[65];  // "(none)"
    };*/

    struct utsname unKernelInfo= {{0}};

    INT iRes = uname(&unKernelInfo);
    xASSERT_RET(- 1 != iRes, xT("Linux"));

    sRes.assign( CxString::sFormat(xT("%s %s (%s)"), unKernelInfo.sysname, unKernelInfo.release, unKernelInfo.version) );
#endif

	return sRes;
}
//---------------------------------------------------------------------------
//DONE: sGetComputerName (Retrieves the NetBIOS name of the local computer)
/*static*/
tString 
CxSystemInfo::sGetComputerName() {
	/*DEBUG*/// n/a

    tString sRes;

#if defined(xOS_WIN)
    BOOL    bRes                                = FALSE;
    ULONG   ulBuffSize                          = MAX_COMPUTERNAME_LENGTH;
    TCHAR   szBuff[MAX_COMPUTERNAME_LENGTH + 1] = {0};

    bRes = ::GetComputerName(szBuff, &ulBuffSize);
    /*DEBUG*/xASSERT_RET(FALSE != bRes, xT("LOCALHOST"));

    sRes.assign(szBuff, ulBuffSize);
#elif defined(xOS_LINUX)
    struct utsname unKernelInfo= {{0}};

    INT iRes = uname(&unKernelInfo);
    xASSERT_RET(- 1 != iRes, xT("LOCALHOST"));

    sRes.assign(unKernelInfo.nodename);
#endif

	return sRes;
}
//---------------------------------------------------------------------------
//DONE: bIsUserAnAdmin (is current user an admin)
/*static*/
BOOL
CxSystemInfo::bIsUserAnAdmin() {
    /*DEBUG*/

#if defined(xOS_WIN)
    ////BOOL bRes = IsUserAnAdmin();
    /////*DEBUG*/// n/a
    ////xCHECK_RET(FALSE == bRes, FALSE);

    HMODULE hMod = ::GetModuleHandle(xT("kernel32.dll"));
    /*DEBUG*/xASSERT_RET(NULL != hMod, FALSE);

    FARPROC fpAddr = ::GetProcAddress(hMod, "LoadLibraryW");
    xCHECK_RET(NULL == fpAddr, FALSE);
#elif defined(xOS_LINUX)
    const uid_t cuiRootId = 0;

    uid_t       uiUserId = - 1;

    uiUserId = getuid();
    /*DEBUG*/// n/a
    xCHECK_RET(cuiRootId != uiUserId, FALSE);

    uiUserId = geteuid();
    /*DEBUG*/// n/a
    xCHECK_RET(cuiRootId != uiUserId, FALSE);
#endif

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: + sGetUserName (Retrieves the name of the user associated with the current thread)
/*static*/
tString 
CxSystemInfo::sGetUserName() {
	/*DEBUG*/// n/a

    tString sRes;

#if defined(xOS_WIN)
    BOOL  bRes              = FALSE;
    ULONG ulBuffSize        = UNLEN;
    TCHAR szBuff[UNLEN + 1] = {0};

    bRes = ::GetUserName(&szBuff[0], &ulBuffSize);
    /*DEBUG*/xASSERT_RET(FALSE != bRes, tString());

    sRes.assign(szBuff, ulBuffSize);
#elif defined(xOS_LINUX)
    //http://www.metalshell.com/source_code/107/List_Users.html
    //http://www.metalshell.com/source_code/83/Get_GID_Name.html

    sRes = CxEnvironment::sGetVar(xT("USER"));
    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());

    //TODO:
    ////sRes = CxEnvironment::sGetVar(xT("USERNAME"));
    /////*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
#endif
	return sRes;
}
//---------------------------------------------------------------------------
//DONE: ulGetNumOfCPUs ()
/*static*/ 
ULONG 
CxSystemInfo::ulGetNumOfCPUs() {
	/*DEBUG*/// n/a

#if defined(xOS_WIN)
    SYSTEM_INFO siSysInfo = {0};

    ::GetSystemInfo(&siSysInfo);
    /*DEBUG*/// n/a

    //The processor architecture of the installed operating system
    USHORT    usProcessorArchitecture     = siSysInfo.wProcessorArchitecture;
    //The page size and the granularity of page protection and commitment
    ULONG     ulPageSize                  = siSysInfo.dwPageSize;
    //A pointer to the lowest memory address accessible to applications and dynamic-link libraries (DLLs)
    LPVOID    pvMinimumApplicationAddress = siSysInfo.lpMinimumApplicationAddress;
    //A pointer to the highest memory address accessible to applications and DLLs
    LPVOID    pvMaximumApplicationAddress = siSysInfo.lpMaximumApplicationAddress;
    //A mask representing the set of processors configured into the system
    DWORD_PTR pulActiveProcessorMask      = siSysInfo.dwActiveProcessorMask;
    //The number of physical processors in the system
    ULONG     ulNumberOfProcessors        = siSysInfo.dwNumberOfProcessors;
    //An obsolete member that is retained for compatibility
    ULONG     ulProcessorType             = siSysInfo.dwProcessorType;
    //The granularity for the starting address at which virtual memory can be allocated.
    ULONG     ulAllocationGranularity     = siSysInfo.dwAllocationGranularity;
    //The architecture-dependent processor level
    USHORT    usProcessorLevel            = siSysInfo.wProcessorLevel;
    //The architecture-dependent processor revision
    USHORT    usProcessorRevision         = siSysInfo.wProcessorRevision;

    return ulNumberOfProcessors;
#elif defined(xOS_LINUX)
    INT iNumberOfProcessors = get_nprocs();
    /*DEBUG*/xASSERT_RET(0 < iNumberOfProcessors, 0);

    return static_cast<ULONG>( iNumberOfProcessors );
#endif
}
//---------------------------------------------------------------------------
//TODO: + ulGetCurrCPUNum (Retrieves the number of the processor the current thread was running on during the call to this function)
/////*static*/
////ULONG
////CxSystemInfo::ulGetCurrCPUNum() {
////	/*DEBUG*/// n/a 
////
////	ULONG ulRes = (ULONG) - 1;
////
////	ulRes = ::GetCurrentProcessorNumber();
////	/*DEBUG*/// n/a 
////
////	return ulRes;
////}
//---------------------------------------------------------------------------
//TODO: - bIsUnicodeOS (is OS support unicode)
BOOL 
CxSystemInfo::bIsUnicodeOS()  {
	/*DEBUG*/// n/a

    BOOL bRes = FALSE;

#if defined(xOS_WIN)
    OSVERSIONINFOW oviInfo = {0};

    oviInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);

    bRes = (0 != ::GetVersionExW(&oviInfo));
#elif defined(xOS_LINUX)
    //TODO: xOS_LINUX
    bRes = TRUE;
#endif
	
	return bRes;
}
//---------------------------------------------------------------------------
//TODO: - iGetCpuSpeed (calculates the CPU speed in MHz)
/*static*/
INT
CxSystemInfo::iGetCpuSpeed() {
	/*DEBUG*/// n/a

	INT iRes = - 1;

#if defined(xOS_WIN)
    //TODO: xOS_WIN
//	//TODO: CxCycle
//	class CxCycle {
//		public:
//			static /*inline*/ unsigned __int64 ullGetCount();
//	};
//	unsigned __int64 CxCycle::ullGetCount() {
//			UINT uiTimeHigh = 0;
//			UINT uiTimeLow  = 0;
//
//			__asm {
//				rdtsc
//				mov uiTimeHigh, edx;
//				mov uiTimeLow,  eax;
//			}
//
//			return ((unsigned __int64)uiTimeHigh << 32) + (unsigned __int64)uiTimeLow;
//	};
//
//
//	const ULONGLONG ullStartCycle = CxCycle::ullGetCount();
//
//	::Sleep(1000);
//
//	iRes = static_cast<INT>( (CxCycle::ullGetCount() - ullStartCycle) / 1000000 );

	xNOT_IMPLEMENTED_RET(- 1);
#elif defined(xOS_LINUX)
    //TODO: xOS_LINUX
    xNOT_IMPLEMENTED_RET(- 1);
#endif

	return iRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxSystemInfo (construcor)
CxSystemInfo::CxSystemInfo() {

}
//---------------------------------------------------------------------------
//TODO: + ~CxSystemInfo (destructor)
CxSystemInfo::~CxSystemInfo(){

}
//---------------------------------------------------------------------------
