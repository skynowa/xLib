/****************************************************************************
* Class name:  CxDebugger
* Description: отладка кода
* File name:   CxDebugger.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     27.11.2009 16:39:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Debug/CxDebugger.h>

#include <xLib/CxDateTime.h>
#include <xLib/CxSystemInfo.h>
#include <xLib/Fso/CxPath.h> 
#include <xLib/Sync/CxProcess.h>

#if defined(xOS_WIN)
    #include <xLib/Gui/Dialogs/CxMsgBoxRtf.h>
#elif defined(xOS_LINUX)

#endif


/****************************************************************************
*	public
*
*****************************************************************************/

BOOL CxDebugger::_m_bIsEnabled = TRUE;

//---------------------------------------------------------------------------
//DONE: bGetEnabled (is debugging enabled)
/*static*/
BOOL
CxDebugger::bGetEnabled() {
    /*DEBUG*/// n/a

    return _m_bIsEnabled;
}
//---------------------------------------------------------------------------
//DONE: bSetEnabled (set debugging mode on/off)
/*static*/
BOOL
CxDebugger::bSetEnabled(BOOL bFlag) {
    /*DEBUG*/// n/a

    _m_bIsEnabled = bFlag;

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bBreak (attach to OS debugger)
/*static*/
BOOL
CxDebugger::bBreak() {
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);
    /*DEBUG*/// n/a

#if defined(xOS_WIN)
    _asm {int 3}
    ////::DebugBreak();
#elif defined(xOS_LINUX)
    INT iRes = kill(getpid(), SIGINT);
    xCHECK_RET(- 1 == iRes, FALSE);
#endif

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bIsPresent (is OS debugger presents)
/*static*/
BOOL
CxDebugger::bIsPresent() {
    /*DEBUG*/// n/a

    BOOL bRes = FALSE;

#if defined(xOS_WIN)
    bRes = ::IsDebuggerPresent();
    xCHECK_RET(FALSE == bRes, FALSE);
    ////::CheckRemoteDebuggerPresent()
#elif defined(xOS_LINUX)
    xUNUSED(bRes);
    //TODO: xOS_LINUX
    ////bRes = std::getenv("xLIB_ENABLE_DEBUGGER");
    ////xCHECK_RET(FALSE == bRes, FALSE);
#endif

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bLog (log to file)
/*static*/
BOOL
CxDebugger::bLog(const CxReport &rpReport)
{
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);
    /*DEBUG*/

    //-------------------------------------
    //Never corrupt the last error value
    ULONG _ulLastError = rpReport.ulGetLastError();

    _bLogAppend(rpReport.sGetReport());

    //-------------------------------------
    //Never corrupt the last error value
    CxLastError::bSet(_ulLastError);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bMsg (show MessageBox)
/*static*/
BOOL
CxDebugger::bMsg(const CxReport &rpReport)
{
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);
    /*DEBUG*/

    //-------------------------------------
    //Never corrupt the last error value
    ULONG _ulLastError = rpReport.ulGetLastError();

    //-------------------------------------
    //show message
#if defined(xOS_WIN)
    CxMsgBoxT::EModalResult mrRes = CxMsgBoxT::iShow(rpReport.sGetReport(), CxPath::sGetExe(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
    switch (mrRes) {
        case CxMsgBoxT::mrAbort: {
                CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
            }
            break;

        default:
        case CxMsgBoxT::mrIgnore: {
                //skip
            }
            break;

        case CxMsgBoxT::mrRetry: {
                if (TRUE == bIsPresent()) {
                    bBreak();
                } else {
                    CxMsgBoxT::iShow(xT("Debugger is not present.\nThe application will be terminated."), xT("xLib"), MB_OK | MB_ICONWARNING);
                    CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
                }
            }
            break;
    }
#elif defined(xOS_LINUX)
    //TODO: xOS_LINUX
#endif
	
    //-------------------------------------
    //Never corrupt the last error value
    CxLastError::bSet(_ulLastError);

	return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bMsgRtf (show MessageBox or std::out)
/*static*/
BOOL
CxDebugger::bMsgRtf(const CxReport &rpReport)
{
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);
    /*DEBUG*/

    //-------------------------------------
    //Never corrupt the last error value
    ULONG _ulLastError = rpReport.ulGetLastError();

    //-------------------------------------
    //format message
    const tString sReport = CxString::sFormat(
                        xT("{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}")
                        xT("{\\colortbl ;\\red0\\green0\\blue0;\\red255\\green0\\blue0;\\red0\\green0\\blue255;}")
                        xT("{\\*\\generator Msftedit 5.41.15.1515;}\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par")
                        xT("\\par")
                        xT("\\b %s\\b0   \\lang1033\\f1    \\cf1\\lang1049\\f0 %s\\cf2\\par")
                        xT("\\cf0\\b %s\\b0   \\lang1033\\f1            \\cf1\\lang1049\\f0 %s\\cf2\\par")
                        xT("\\cf0\\b %s\\b0   \\lang1033\\f1           \\cf1\\lang1049\\f0 %u\\cf0\\par")
                        xT("\\b %s\\b0  \\lang1033\\f1   \\lang1049\\f0  \\lang1033\\f1  \\cf3\\lang1049\\f0 %s\\cf0\\par")
                        xT("\\b %s\\b0   \\cf2 %s\\cf0\\par")
                        xT("\\b %s\\lang1033\\b0\\f1      \\cf2\\lang1049\\f0 %s\\cf0\\par")
                        xT("\\b %s\\lang1033\\b0\\f1    \\cf1\\lang1049\\f0 %s\\cf0\\par")
                        xT("\\b %s\\lang1033\\b0\\f1   \\cf1\\lang1049\\f0 %s\\cf0\\par")
                        xT("\\b %s\\b0  \\lang1033\\f1    \\cf1 %s\\lang1049\\f0\\par")
                        xT("}"),

                        xT("CxReport"),
                        xT("Program:"),    rpReport.sGetProgram().data(),
                        xT("File:"),       rpReport.sGetSourceFile().data(),
                        xT("Line:"),       rpReport.ulGetSourceLine(),
                        xT("Function:"),   rpReport.sGetFunctionName().data(),
                        xT("Expression:"), rpReport.sGetExpression().data(),
                        xT("LastError:"),  rpReport.sGetLastErrorStr().data(),
                        xT("Build date:"), rpReport.sGetBuildDate().data(),
                        xT("OS version:"), rpReport.sGetOSVersion().data(),
                        xT("Comment:"),    rpReport.sGetComment().data()
    );

    //-------------------------------------
    //show message
#if defined(xOS_WIN)
    CxMsgBoxRtf::EModalResult mrRes = CxMsgBoxRtf::iShow(NULL, sReport, CxPath::sGetExe());
    switch (mrRes) {
        case CxMsgBoxRtf::mrAbort: {
                CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
            }
            break;

        default:
        case CxMsgBoxRtf::mrIgnore: {
                //skip
            }
            break;

        case CxMsgBoxRtf::mrRetry: {
                if (TRUE == bIsPresent()) {
                    bBreak();
                } else {
                    CxMsgBoxT::iShow(xT("Debugger is not present.\nThe application will be terminated."), xT("xLib"), MB_OK | MB_ICONWARNING);
                    CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
                }
            }
            break;
    }
#elif defined(xOS_LINUX)
    //TODO: xOS_LINUX
#endif

    //-------------------------------------
    //Never corrupt the last error value
    CxLastError::bSet(_ulLastError);

	return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bMsgStdOut ()
/*static*/
BOOL
CxDebugger::bMsgStdOut(const CxReport &rpReport)
{
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);
    /*DEBUG*/

    //_tsetlocale(LC_ALL, xT(""));

    //-------------------------------------
    //Never corrupt the last error value
    ULONG _ulLastError = rpReport.ulGetLastError();

    //-------------------------------------
    //show message

    //commands from console
    enum ECmd {
        cmAbort  = xT('a'),
        cmIgnore = xT('i'),
        cmRetry  = xT('r')
    };

    tcerr << xT("\n####################################################################################################\n");
    tcerr << rpReport.sGetReport();
    tcerr << xT("\n####################################################################################################\n");
    tcerr << xT("\n");
    tcerr << xT("\nAbort (a), Ignore (i), Retry (r): ");
    tcerr.flush();

    ECmd cmRes = static_cast<ECmd>( tcin.get() );   tcin.ignore();
    switch (cmRes) {
        case cmAbort: {
                tcerr << xT("Abort...\n");  tcerr.flush();

                CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
            }
            break;

        default:
        case cmIgnore: {
                //skip
                tcerr << xT("Ignore...\n");  tcerr.flush();
            }
            break;

        case cmRetry: {
                tcerr << xT("Retry...\n");

                if (TRUE == bIsPresent()) {
                    bBreak();
                } else {
                    tcerr << xT("\n####################################################################################################\n");
                    tcerr << xT("CxDebugger\n");
                    tcerr << xT("\n");
                    tcerr << xT("OS debugger is not present.\nThe application will be terminated.\n");
                    tcerr << xT("####################################################################################################\n");
                    tcerr << xT("\n");
                    tcerr.flush();

                    CxProcess::bExit(CxProcess::ulGetCurrId(), FALSE);
                }
            }
            break;
    }

    tcerr << xT("\n");  tcerr.flush();

    //-------------------------------------
    //Never corrupt the last error value
    CxLastError::bSet(_ulLastError);

    return TRUE;
}
//---------------------------------------------------------------------------
//DONE: bTrace (tracing)
/*static*/
BOOL
CxDebugger::bTrace(LPCTSTR pcszFormat, ...) {
    /*DEBUG*/
    /*CHECK*/xCHECK_RET(FALSE == bGetEnabled(), TRUE);

    tString sRes;

    va_list palArgs = NULL;
    va_start(palArgs, pcszFormat);
    sRes = CxString::sFormatV(pcszFormat, palArgs);
    va_end(palArgs);

#if defined(xOS_WIN)
    ::OutputDebugString(sRes.c_str());
    /*CHECK*/// n/a
#elif defined(xOS_LINUX)
    tcout << sRes.data() << tendl;  tcout.flush();
#endif

    return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: + CxDebugger ()
CxDebugger::CxDebugger() {

}
//---------------------------------------------------------------------------
//DONE: + ~CxDebugger ()
CxDebugger::~CxDebugger() {

}
//---------------------------------------------------------------------------
//TODO: + _bLogAppend (append text to log, tracing)
/*static*/
BOOL
CxDebugger::_bLogAppend(const tString &csText) {
    /*DEBUG*/// n/a

    _tsetlocale(LC_ALL, xT(""));

    tString sFilePath = CxPath::sSetExt(CxPath::sGetExe(), xT("debug"));

    FILE *pFile = _tfopen(sFilePath.c_str(), xT("ab"));
    xCHECK_RET(NULL == pFile, FALSE);

    try {
        //formating
        const tString csMsg = CxString::sFormat(
            xT("\n")
            xT("####################################################################################################\n")
            xT("[%s]\n")
            xT("\n")
            xT("%s\n"),
            CxDateTime::dtGetCurrent().sGetDateTimeStr().c_str(),
            csText.c_str()
        );

        //in file
        _ftprintf(pFile, xT("%s"), csMsg.data());

        //tracing
        bTrace(csMsg.data());
    }
    catch (...) {}

    xCHECK_DO(NULL != pFile, fclose(pFile); pFile = NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
