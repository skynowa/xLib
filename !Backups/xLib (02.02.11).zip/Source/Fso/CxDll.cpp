/****************************************************************************
* Class name:  CxDll
* Description: DLL
* File name:   CxDll.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <xLib/Fso/CxDll.h>


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxDll 
CxDll::CxDll() :
	_m_bRes(FALSE),
    _m_hDLL(NULL)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CxDll
/*virtual*/
CxDll::~CxDll() {
	_m_bRes = bFree();
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + bIsLoaded
BOOL CxDll::bIsLoaded() {
	/*DEBUG*/// n/a

	return NULL != _m_hDLL;
}
//---------------------------------------------------------------------------
//TODO: + bLoad 
BOOL CxDll::bLoad(const tString &csDllPath) {
	/*DEBUG*/// n/a
	/*DEBUG*/xASSERT_RET(false == csDllPath.empty(), FALSE);

	_m_bRes = bFree();
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	_m_hDLL = ::LoadLibrary(csDllPath.c_str());
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + fpGetProcAddress
FARPROC CxDll::fpGetProcAddress(const tString &csProcName) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hDLL, NULL);

	FARPROC fpRes = NULL;

	fpRes = ::GetProcAddress(_m_hDLL, xTS2S(csProcName).c_str());
	/*DEBUG*/xASSERT_RET(NULL != fpRes, NULL);

	return fpRes;
}
//---------------------------------------------------------------------------
//TODO: + bFree 
BOOL CxDll::bFree() {
	/*DEBUG*/// n/a

	xCHECK_RET(FALSE == bIsLoaded(), TRUE);

	_m_bRes = ::FreeLibrary(_m_hDLL);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	
	_m_hDLL = NULL;	

	return TRUE;
}
//---------------------------------------------------------------------------