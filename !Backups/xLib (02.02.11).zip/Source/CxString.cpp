/****************************************************************************
* Class name:  CxString
* Description: strings
* File name:   CxString.cpp
* String type: ansi, unicode
* Compilers:   Visual C++ 2008
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#include <xLib/CxString.h>


//---------------------------------------------------------------------------
//TODO: + bBoolToStr  
/*static*/
BOOL 
CxString::bBoolToStr(BOOL bBool, tString *psStr) {
//    /*DEBUG*/// bBool - n/a
//    /*DEBUG*/xASSERT_RET(NULL != psStr, FALSE);

    xCHECK_RET(NULL == psStr, FALSE);

    *psStr = (FALSE == bBool) ? (xT("false")) : (xT("true"));

    return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bStrToBool  
/*static*/
BOOL 
CxString::bStrToBool(const tString &csStr, BOOL *pbBool) {
//    /*DEBUG*/xASSERT_RET(false == csStr.empty(), FALSE);
//    /*DEBUG*/xASSERT_RET(NULL  != pbBool,        FALSE);

    xCHECK_RET(true == csStr.empty(), FALSE);
    xCHECK_RET(NULL == pbBool,        FALSE);

    if (TRUE == bCompareNoCase(xT("true"), csStr)) {
        *pbBool = TRUE;

        return TRUE;
    }
    if (TRUE == bCompareNoCase(xT("false"), csStr)) {
        *pbBool = FALSE;

        return TRUE;
    }

    return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + sTrimLeftChars 
/*static*/
tString 
CxString::sTrimLeftChars(const tString &csStr, const tString &csChars) { 
    /*DEBUG*/// csStr   - n/a
    /*DEBUG*/// csChars - n/a

    tString sRes;
    sRes.assign(csStr);

    return sRes.erase(0, sRes.find_first_not_of(csChars));
}
//---------------------------------------------------------------------------
//TODO: + sTrimRightChars 
/*static*/
tString 
CxString::sTrimRightChars(const tString &csStr, const tString &csChars) {
    /*DEBUG*/// csStr   - n/a
    /*DEBUG*/// csChars - n/a

    tString sRes;
    sRes.assign(csStr);

    return sRes.erase(sRes.find_last_not_of(csChars) + 1);
}
//---------------------------------------------------------------------------
//TODO: + sTrimChars  
/*static*/
tString 
CxString::sTrimChars(const tString &csStr, const tString &csChars) {
    /*DEBUG*/// csStr   - n/a
    /*DEBUG*/// csChars - n/a

    tString sRes;
    sRes.assign(csStr);

    sRes.assign( sTrimRightChars(sRes, csChars) );
    sRes.assign( sTrimLeftChars (sRes, csChars) );

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sTrimSpace 
/*static*/
tString 
CxString::sTrimSpace(const tString &csStr) {
    /*DEBUG*/// csStr - n/a

    return sTrimChars(csStr, CxConst::xWHITE_SPACES);
}
//---------------------------------------------------------------------------
//TODO: + sRemoveEOL  
/*static*/
tString 
CxString::sRemoveEOL(const tString &csStr) {
    /*DEBUG*/// csStr - n/a

    return sTrimRightChars(csStr, CxConst::xEOL);
}
//---------------------------------------------------------------------------
//TODO: + sReplaceAll
/*static*/
tString 
CxString::sReplaceAll(const tString &csStr, const tString &csOldStr, const tString &csNewStr) {
    /*DEBUG*/// csStr    - n/a
    /*DEBUG*/// csOldStr - n/a
    /*DEBUG*/// csNewStr - n/a

    xCHECK_RET(true == csStr.empty(),    csStr);
    xCHECK_RET(true == csOldStr.empty(), csStr);

    tString sRes;
    sRes.assign(csStr);

    std::size_t uiPos = 0;

    for ( ;; ) {
        uiPos = sRes.find(csOldStr, uiPos);
        xCHECK_DO(tString::npos == uiPos, break);

        sRes.replace(uiPos, csOldStr.size(), csNewStr);

        uiPos += csNewStr.size();
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sReplaceAll  
/*static*/
tString 
CxString::sReplaceAll(const tString &csStr, TCHAR chOldStr, TCHAR chNewStr) {
    /*DEBUG*/// csStr    - n/a
    /*DEBUG*/// chOldStr - n/a
    /*DEBUG*/// chNewStr - n/a
    
    return sReplaceAll(csStr, tString(1, chOldStr), tString(1, chNewStr));
}
//---------------------------------------------------------------------------
//TODO: + sRemoveAll
/*static*/
tString 
CxString::sRemoveAll(const tString &csStr, const tString &csRemoveStr) {
    /*DEBUG*/// csStr      - n/a
    /*DEBUG*/// csRemoveStr - n/a

    return sReplaceAll(csStr, csRemoveStr, tString());
}
//---------------------------------------------------------------------------
//TODO: + разбивает строку на фрагменты по символу-разделителю, возвращая массив строк (vector)
/*static*/
BOOL 
CxString::bSplit(const tString &csStr, const tString &csSep, std::vector<tString> *pvecsOut) {
    /*DEBUG*/// csStr    - n/a
    /*DEBUG*/// csSep    - n/a
    /*DEBUG*/// pvecsOut - n/a

    xCHECK_RET(true == csStr.empty(), TRUE);
    xCHECK_RET(true == csSep.empty(), TRUE);
    xCHECK_RET(NULL == pvecsOut,      FALSE);

    std::size_t uiPrevPos = 0;     //start of string
    std::size_t uiPos     = 0;

    (*pvecsOut).clear();
    while (tString::npos != (uiPos = csStr.find(csSep, uiPrevPos))) {
        (*pvecsOut).push_back(csStr.substr(uiPrevPos, uiPos - uiPrevPos));
        uiPrevPos = uiPos + csSep.size();
    }
    (*pvecsOut).push_back(csStr.substr(uiPrevPos, csStr.size() - uiPrevPos));

    return TRUE;
}
////static void SplitString(const ::std::string& str, char delimiter, ::std::vector< ::std::string>* dest) {
////    ::std::vector< ::std::string> parsed;
////    ::std::string::size_type pos = 0;
////    while (::testing::internal::AlwaysTrue()) {
////        const ::std::string::size_type colon = str.find(delimiter, pos);
////        if (colon == ::std::string::npos) {
////            parsed.push_back(str.substr(pos));
////            break;
////        } else {
////            parsed.push_back(str.substr(pos, colon - pos));
////            pos = colon + 1;
////        }
////    }
////    dest->swap(parsed);
////}
//---------------------------------------------------------------------------
//TODO: + bSplitKeyValue
/*static*/
BOOL 
CxString::bSplitKeyValue(const tString &csStr, const tString &csSep, std::vector<tString> *pvecsKeyValue) {
//    /*DEBUG*/xASSERT_RET(false == csSep.empty(),                 FALSE);
//    /*DEBUG*/xASSERT_RET(false == csStr.empty(),                 FALSE);
//    /*DEBUG*/xASSERT_RET(NULL  != pvecsKeyValue,                 FALSE);
//    /*DEBUG*/xASSERT_RET(csStr.substr(0, csSep.size()) != csSep, FALSE);
//    /*DEBUG*/xASSERT_RET(tString::npos != csStr.find(csSep),     FALSE);


    std::size_t uiPrevPos = 0;     //start of string
    std::size_t uiPos;

    uiPos = csStr.find(csSep, uiPrevPos);
//    /*DEBUG*/xASSERT_RET(tString::npos != uiPos, FALSE);

    (*pvecsKeyValue).clear();

    (*pvecsKeyValue).push_back(csStr.substr(uiPrevPos, uiPos - uiPrevPos));
    uiPrevPos = uiPos + csSep.size();

    (*pvecsKeyValue).push_back(csStr.substr(uiPrevPos, csStr.size() - uiPrevPos));

    return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sJoin ("склеивает" строки вектора символом-разделителем)
/*static*/
tString 
CxString::sJoin(const std::vector<tString> &cvecsVec, const tString &csSep) {
    /*DEBUG*/// cvecsVec - n/a
    /*DEBUG*/// csSep    - n/a

    tString sRes;

    for (std::vector<tString>::const_iterator it = cvecsVec.begin(); it != cvecsVec.end(); ++ it) {
        sRes.append(*it);
        sRes.append(csSep);
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sJoin ("склеивает" строки вектора символом-разделителем)
/*static*/
tString 
CxString::sJoin(const std::vector<tString> &cvecsVec, TCHAR chSep) {
    /*DEBUG*/// cvecsVec - n/a
    /*DEBUG*/// csSep    - n/a

    tString sRes;

    for (std::vector<tString>::const_iterator it = cvecsVec.begin(); it != cvecsVec.end(); ++ it) {
        sRes.append(*it);
        sRes.push_back(chSep);
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: - sCut 
/*static*/
tString 
CxString::sCut(const tString &csStr, const tString &csLeftSep, const tString &csRightSep) {
    /*DEBUG*/// csStr      - n/a
    /*DEBUG*/// csLeftSep  - n/a
    /*DEBUG*/// csRightSep - n/a

    //To: =?windows-1251?B?x+Di4+7w7uTt//8=?= <gfikc@meta.ua>
    tString     sRes;
    std::size_t uiStartDelimPos = 0;
    std::size_t uiStopDelimPos  = 0;

    uiStartDelimPos = csStr.find(csLeftSep);
    xCHECK_RET(tString::npos == uiStartDelimPos, tString());
    uiStartDelimPos += csLeftSep.size();

    uiStopDelimPos  = csStr.rfind(csRightSep);
    xCHECK_RET(tString::npos == uiStopDelimPos, tString());

    xCHECK_RET(uiStartDelimPos >= uiStopDelimPos, tString());

    sRes = csStr.substr(uiStartDelimPos, uiStopDelimPos - uiStartDelimPos);

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: - sCut
/*static*/
tString 
CxString::sCut(const tString &csStr, std::size_t uiStartPos /*= 0*/, std::size_t uiEndPos /*= std::string:npos*/) {
    /*
    + Если indexA = indexB, возвращается пустая строка
    + Если indexB не указан, substring возвращает символы до конца строки
    - Если какой-то из аргументов меньше 0 или является NaN - он считается равным 0
    + Если какой-то из аргументов больше, чем длина строки - он считается равным длине строки
    + Если indexA > indexB, тогда substring ведет себя, как будто аргументы поменялись местами.
    - Если строка не найдена, вызов возвращает -1
    */

    xCHECK_RET(true       == csStr.empty(), tString());
    xCHECK_RET(uiStartPos >  uiEndPos,      tString());

    std::size_t uiSize = ( (std::string::npos == uiEndPos) ? (csStr.size()) : (uiEndPos) ) - uiStartPos/* + 1*/;

    return csStr.substr(uiStartPos, uiSize);
}
//---------------------------------------------------------------------------
//TODO: + sToLowerCase (convert to lowcase)
/*static*/
tString 
CxString::sToLowerCase(const tString &csStr) {
    /*DEBUG*/// n/a
    xCHECK_RET(true == csStr.empty(), tString());

    tString sRes;

#if defined(xOS_WIN)
    sRes.assign(csStr);

    sRes = tString(::CharLower(static_cast<LPTSTR>( &sRes[0] )));
    /*DEBUG*/// n/a
#elif defined(xOS_LINUX)
    //_tsetlocale(LC_ALL, _tsetlocale(LC_ALL, NULL));
    //_tsetlocale(LC_ALL, xT(""));
    ////setlocale(LC_ALL,"ru_RU.UTF-8");

    //#include <boost/algorithm/string.hpp>
    //boost::to_lower();

    ////printf("Locale is: %s\n", setlocale(LC_ALL, NULL) );

    sRes.assign(csStr);
    std::transform(sRes.begin(), sRes.end(), sRes.begin(), ::_totlower);


//    for (tString::const_iterator it = csStr.begin(); it != csStr.end(); ++ it) {
//        sRes.append(1, static_cast<TCHAR>( std::_totlower(*it) ));
//    }
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sToUpperCase (convert to uppercase)
/*static*/
tString 
CxString::sToUpperCase(const tString &csStr) {
    /*DEBUG*/// n/a
    xCHECK_RET(true == csStr.empty(), tString());

    tString sRes;

#if defined(xOS_WIN)
    sRes.assign(csStr);

    sRes = tString(::CharUpper(static_cast<LPTSTR>( &sRes[0] )));
    /*DEBUG*/// n/a
#elif defined(xOS_LINUX)
    ////_tsetlocale(LC_ALL, xT(""));

    for (tString::const_iterator it = csStr.begin(); it != csStr.end(); ++ it) {
        sRes.append(1, static_cast<TCHAR>( std::_totupper(*it) ));
    }
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sToLowerCase 
/*static*/
tString 
CxString::sToLowerCase(const tString &csStr, ULONG ulLength) {
    /*DEBUG*/// n/a
    xCHECK_RET(true == csStr.empty(), tString());

    tString sRes;

#if defined(xOS_WIN)
    sRes.assign(csStr);

    ULONG ulRes = ::CharLowerBuff(static_cast<LPTSTR>( &sRes[0] ), ulLength);
    /*DEBUG*/xASSERT_RET(ulLength == ulRes, tString());
#elif defined(xOS_LINUX)
    ////_tsetlocale(LC_ALL, xT(""));

    for (tString::const_iterator it = csStr.begin(); it != csStr.end(); ++ it) {
        xCHECK_DO(ulLength <= sRes.size(), break);

        sRes.append(1, static_cast<TCHAR>( std::_totlower(*it) ));
    }
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sToUpperCase 
/*static*/
tString 
CxString::sToUpperCase(const tString &csStr, ULONG ulLength) {
    /*DEBUG*/// n/a
    xCHECK_RET(true == csStr.empty(), tString());

    tString sRes;

#if defined(xOS_WIN)
    sRes.assign(csStr);

    ULONG ulRes = ::CharUpperBuff(static_cast<LPTSTR>( &sRes[0] ), ulLength);
    /*DEBUG*/xASSERT_RET(ulLength == ulRes, tString());
#elif defined(xOS_LINUX)
    ////_tsetlocale(LC_ALL, xT(""));

    for (tString::const_iterator it = csStr.begin(); it != csStr.end(); ++ it) {
        xCHECK_DO(ulLength <= sRes.size(), break);

        sRes.append(1, static_cast<TCHAR>( std::_totupper(*it) ));
    }
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + bCompareNoCase (Compares two character strings. The comparison is not case-sensitive.) 
/*static*/
BOOL 
CxString::bCompareNoCase(const tString &csStr1, const tString &csStr2) {
    /*DEBUG*/// csStr1 - n/a
    /*DEBUG*/// csStr2 - n/a
    xCHECK_RET(csStr1.size() != csStr2.size(), FALSE);

#if defined(xOS_WIN)
    INT iRes = - 1;

    iRes = ::lstrcmpi(csStr1.c_str(), csStr2.c_str());
    /*DEBUG*/// n/a
    xCHECK_RET(0 != iRes, FALSE);
#elif defined(xOS_LINUX)
    for (tString::const_iterator itA = csStr1.begin(), itB = csStr2.begin();
         itA < csStr1.end(), itB < csStr2.end();
         ++ itA, ++ itB)
    {
        xCHECK_RET(std::_totlower(*itA) != std::_totlower(*itB), FALSE);  //TODO: FIX IT
    }
#endif

    return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - iWildCompare () 
/*static*/
INT 
CxString::iWildCompare(LPCTSTR pcszStr, LPCTSTR pcszWild) {
    // Written by Jack Handy - jakkhandy@hotmail.com

    LPCTSTR cp = NULL;
    LPCTSTR mp = NULL;

    while ((*pcszStr) && (xT('*') != *pcszWild)) {
        if ((*pcszWild != *pcszStr) && (xT('?') != *pcszWild)) {
            return 0;
        }

        pcszWild ++;
        pcszStr  ++;
    }

    while (*pcszStr) {
        if (xT('*') == *pcszWild) {
            if (!*++pcszWild) {
                return 1;
            }
            mp = pcszWild;
            cp = pcszStr+1;
        }
        else if ((*pcszWild == *pcszStr) || (xT('?') == *pcszWild)) {
            pcszWild ++;
            pcszStr  ++;
        }
        else {
            pcszWild = mp;
            pcszStr  = cp++;
        }
    }

    while (xT('*') == *pcszWild) {
        pcszWild++;
    }

    return !*pcszWild;
}
//---------------------------------------------------------------------------


/****************************************************************************
*    остальные
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + sFormat
/*static*/
tString 
CxString::sFormat(LPCTSTR pcszFormat, ...) {        //vswprintf
    /*DEBUG*/xASSERT_RET(NULL != pcszFormat, tString());        //FIX: csStr    - n/a

    tString sRes;

    va_list palArgs = NULL;
    va_start(palArgs, pcszFormat);

    sRes = sFormatV(pcszFormat, palArgs);

    va_end(palArgs);

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sFormatA (ANSI-версия)
/*static*/
std::string 
CxString::sFormatA(LPCSTR pcszFormat, ...) {        
    /*DEBUG*/xASSERT_RET(NULL != pcszFormat,  std::string());    //FIX: csStr    - n/a

    std::string sBuff(128, '\0');
    INT         iWrittenSize = - 1;

    va_list palArgs = NULL;
    va_start(palArgs, pcszFormat);

    for (;;) {
        //если win32 то используем _vsnprintf (для C++Builder - vsnprintf)
        iWrittenSize = vsnprintf(&sBuff[0], sBuff.size(), pcszFormat, palArgs);    //error - 1
//        /*DEBUG*/xASSERT_RET(NULL != palArgs, std::string());

        if (iWrittenSize > - 1 && iWrittenSize < static_cast<INT>(sBuff.size())) {    //!может быть урезан буфер!
            break; //succeeded
        }
        sBuff.resize(sBuff.size() * 2);
    }

    va_end(palArgs);

    return std::string(sBuff.begin(), sBuff.begin() + iWrittenSize);
}
//---------------------------------------------------------------------------
//TODO: + sFormatV
/*static*/
tString 
CxString::sFormatV(LPCTSTR pcszFormat, va_list palArgs) {
//    /*DEBUG*/xASSERT_RET(NULL != pcszFormat, tString());        //FIX: csStr    - n/a

    tString sBuff;
    INT     iWrittenSize = - 1;

    sBuff.resize(128);
    for (;;) {
        //если win32 то используем _vsnprintf (для C++Builder - vsnprintf)
        iWrittenSize = _vsntprintf(&sBuff.at(0), sBuff.size(), pcszFormat, palArgs);    //error - 1
//        /*DEBUG*/xASSERT_RET(NULL != palArgs, tString());

        if (iWrittenSize > - 1 && iWrittenSize < static_cast<INT>(sBuff.size())) {    //!может быть урезан буфер!
            break; //succeeded
        }
        sBuff.resize(sBuff.size() * 2);
    }

    return tString(sBuff.begin(), sBuff.begin() + iWrittenSize);
}
/*String 
String::Format(const char * format, ...) {
    char      buffer[4096];
    const int kBufferSize = sizeof(buffer)/sizeof(buffer[0]);

    va_list args;
    va_start(args, format);

    const int size = vsnprintf(buffer, kBufferSize, format, args);

    va_end(args);

    // vsnprintf()'s behavior is not portable.  When the buffer is not
    // big enough, it returns a negative value in MSVC, and returns the
    // needed buffer size on Linux.  When there is an output error, it
    // always returns a negative value.  For simplicity, we lump the two
    // error cases together.
    if (size < 0 || size >= kBufferSize) {
        return String("<formatting error or buffer exceeded>");
    } else {
        return String(buffer, size);
    }
}*/
//---------------------------------------------------------------------------
//TODO: + sMinimize  
/*static*/
tString 
CxString::sMinimize(const tString &csStr, const UINT cuiMaxLen) {
//    /*DEBUG*/xASSERT_RET(false == csStr.empty(), tString());    //FIX: csStr    - n/a
//    /*DEBUG*/xASSERT_RET(0 < cuiMaxLen,          tString());    //FIX: csStr    - n/a

    tString sRes;

    if (csStr.size() > cuiMaxLen) {
        if (cuiMaxLen < CxConst::x3DOT.size()) {
            sRes = csStr.substr(0, cuiMaxLen);
        } else {
            sRes = csStr.substr(0, cuiMaxLen - CxConst::x3DOT.size()) + CxConst::x3DOT;
        }
    } else {
        sRes.assign(csStr);
    }

    return sRes;
}
//--------------------------------------------------------------------------
//TODO: + sCreateGUID (генерация GUID)
/*static*/
tString 
CxString::sCreateGUID() { 
    /*DEBUG*/// n/a

    tString sRes;

#if defined(xOS_WIN)
    GUID    guidId = {0};
    HRESULT hrGuid = S_FALSE;

    hrGuid = CoCreateGuid(&guidId);
    /*DEBUG*/xASSERT_RET(SUCCEEDED(hrGuid), tString());

    sRes = sFormat(
                //xT("%04X-%02X-%02X-%02X%02X-%02X%02X%02X%02X%02X%02X"),
                xT("%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X"),
                guidId.Data1,
                guidId.Data2,
                guidId.Data3,
                guidId.Data4[0], guidId.Data4[1],
                guidId.Data4[2], guidId.Data4[3], guidId.Data4[4], guidId.Data4[5], guidId.Data4[6], guidId.Data4[7]
    );
    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
#elif defined(xOS_LINUX)
    //TODO: (xOS_LINUX)
    sRes = xT("");
#endif

    return sRes;
}  
//---------------------------------------------------------------------------
//TODO: + bIsRepeated
/*static*/
BOOL CxString::bIsRepeated(const tString &csStr) {
//    /*DEBUG*/xASSERT_RET(false == csStr.empty(), FALSE);    //FIX: csStr    - n/a
    
    return static_cast<BOOL>(tString::npos == csStr.find_first_not_of(csStr.at(0)));
}
//---------------------------------------------------------------------------
//TODO: + sLastErrorStr   
//--/*static*/
//tString
//CxString::sLastErrorStr(ULONG ulLastError) {
//    /*DEBUG*/// ulLastError - n/a
//
//    tString sRes;
//
//#if defined(xOS_WIN)
//    ULONG   ulRes  = 0;
//    LPVOID  pvBuff = NULL;
//    HLOCAL  hRes   = NULL;
//
//    ulRes = ::FormatMessage(
//                    FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
//                    NULL,
//                    ulLastError,
//                    0/*MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)*/,  // язык по умолчанию
//                    reinterpret_cast<LPTSTR>(&pvBuff),
//                    0,
//                    NULL
//    );
//    /*DEBUG*/xASSERT_RET(0 != ulRes, tString());
//
//    sRes = sRemoveEOL(tString(static_cast<LPCTSTR>(pvBuff), ulRes));
//
//    hRes = ::LocalFree(pvBuff);
//    /*DEBUG*/xASSERT_RET(NULL == hRes, tString());
//#elif defined(xOS_LINUX)
//    //TODO: unicode
//    ////INT iRes = - 1;
//
//    //not thread safe - not thread safe
//    {
//        sRes.assign( strerror( static_cast<INT>(ulLastError) ) );
//    }
//
//    //strerror_r - thread safe
//    {
//        ////sRes.resize(256);
//
//        ////iRes = strerror_r(static_cast<INT>(ulLastError), &sRes.at(0), sRes.size());
//        /////*DEBUG*/xASSERT_RET(- 1 != iRes, tString());
//
//        ////sRes.assign(sRes.c_str());
//    }
//#endif
//
//    return sRes;
//--}
//---------------------------------------------------------------------------


/****************************************************************************
*    Перекодировки
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + sTranslitLatToRus   
/*static*/
tString 
CxString::sTranslitLatToRus(const tString &csStr) {
    /*DEBUG*/// n/a
    xCHECK_RET(true == csStr.empty(), tString());

    tString sRes;
    sRes.assign(csStr);

    //-------------------------------------
    //translit table
    const tString csDict[][2] = {
        {xT("Й"), xT("Y")},   {xT("Ц"), xT("C")},  {xT("У"), xT("U")},
        {xT("К"), xT("K")},      {xT("Е"), xT("E")},  {xT("Ё"), xT("E")},
        {xT("Н"), xT("N")},      {xT("Г"), xT("G")},  {xT("Ш"), xT("SH")},
        {xT("Щ"), xT("SH'")}, {xT("З"), xT("Z")},  {xT("Х"), xT("H")},
        {xT("Ъ"), xT("`")},   {xT("Ф"), xT("F")},  {xT("Ы"), xT("I")},
        {xT("В"), xT("V")},   {xT("А"), xT("A")},  {xT("П"), xT("P")},
        {xT("Р"), xT("R")},   {xT("О"), xT("O")},  {xT("Л"), xT("L")},
        {xT("Д"), xT("D")},   {xT("Ж"), xT("ZH")}, {xT("Э"), xT("E")},
        {xT("Я"), xT("YA")},  {xT("Ч"), xT("4")},  {xT("С"), xT("S")},
        {xT("М"), xT("M")},   {xT("И"), xT("I")},  {xT("Т"), xT("T")},
        {xT("Ь"), xT("'")},   {xT("Б"), xT("B")},  {xT("Ю"), xT("YU")},

        {xT("й"), xT("y")},   {xT("ц"), xT("c")},  {xT("у"), xT("u")},
        {xT("к"), xT("k")},   {xT("е"), xT("e")},  {xT("ё"), xT("e")},
        {xT("н"), xT("n")},      {xT("г"), xT("g")},  {xT("ш"), xT("sh")},
        {xT("щ"), xT("sh'")}, {xT("з"), xT("z")},  {xT("х"), xT("h")},
        {xT("ъ"), xT("`")},   {xT("ф"), xT("f")},  {xT("ы"), xT("i")},
        {xT("в"), xT("v")},   {xT("а"), xT("a")},  {xT("п"), xT("p")},
        {xT("р"), xT("r")},   {xT("о"), xT("o")},  {xT("л"), xT("l")},
        {xT("д"), xT("d")},   {xT("ж"), xT("zh")}, {xT("э"), xT("e")},
        {xT("я"), xT("ya")},  {xT("ч"), xT("4")},  {xT("с"), xT("s")},
        {xT("м"), xT("m")},   {xT("и"), xT("i")},  {xT("т"), xT("t")},
        {xT("ь"), xT("'")},   {xT("б"), xT("b")},  {xT("ю"), xT("yu")}
    };

    //-------------------------------------
    //replacing
    for (std::size_t i = 0; i < xARRAY_SIZE(csDict); ++ i) {
        sRes.assign( sReplaceAll(sRes, csDict[i][0], csDict[i][1]) );
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sFormatBytes (форматирование байтов в Bits, Bytes, KB, MB, GB) 
/*static*/
tString 
CxString::sFormatBytes(DOUBLE dBytes) {
    /*DEBUG*/// dBytes - n/a

    tString sRes = xT("Uknown");

    ////const ULONGLONG cui64TB   = 1024 * 1024 * 1024 * 1024;
    const ULONGLONG cui64GB   = 1024 * 1024 * 1024;
    const ULONGLONG cui64MB   = 1024 * 1024;
    const ULONGLONG cui64KB   = 1024;
    const ULONGLONG cui64Byte = 1;

    if (     static_cast<ULONGLONG>(dBytes) / cui64GB   > 0) {
        sRes = sFormat(xT("%.2f GB"),      dBytes / static_cast<DOUBLE>(cui64GB));
    }
    else if (static_cast<ULONGLONG>(dBytes) / cui64MB   > 0) {
        sRes = sFormat(xT("%.2f MB"),      dBytes / static_cast<DOUBLE>(cui64MB));
    }
    else if (static_cast<ULONGLONG>(dBytes) / cui64KB   > 0) {
        sRes = sFormat(xT("%.2f KB"),      dBytes / static_cast<DOUBLE>(cui64KB));
    }
    else if (static_cast<ULONGLONG>(dBytes) / cui64Byte > 0) {
        sRes = sFormat(xT("%.2f Byte(s)"), dBytes / static_cast<DOUBLE>(cui64Byte));
    }
    else {
        sRes = sFormat(xT("%.2f Bit(s)"),  dBytes);
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sFormatBytes (форматирование байтов в Bits, Bytes, KB, MB, GB) 
/*static*/
tString 
CxString::sFormatBytes(ULONGLONG ullBytes) {
    /*DEBUG*/// ulBytes - n/a

    tString sRes = xT("Uknown");

    ////const ULONGLONG cui64TB   = 1024 * 1024 * 1024 * 1024;
    const ULONGLONG cull64GB   = 1024 * 1024 * 1024;
    const ULONGLONG cull64MB   = 1024 * 1024;
    const ULONGLONG cull64KB   = 1024;
    const ULONGLONG cull64Byte = 1;

    if (     ullBytes / cull64GB   > 0) {
        sRes = sFormat(xT("%.2f GB"),      static_cast<DOUBLE>(ullBytes) / static_cast<DOUBLE>(cull64GB));
    }
    else if (ullBytes / cull64MB   > 0) {
        sRes = sFormat(xT("%.2f MB"),      static_cast<DOUBLE>(ullBytes) / static_cast<DOUBLE>(cull64MB));
    }
    else if (ullBytes / cull64KB   > 0) {
        sRes = sFormat(xT("%.2f KB"),      static_cast<DOUBLE>(ullBytes) / static_cast<DOUBLE>(cull64KB));
    }
    else if (ullBytes / cull64Byte > 0) {
        sRes = sFormat(xT("%.2f Byte(s)"), static_cast<DOUBLE>(ullBytes) / static_cast<DOUBLE>(cull64Byte));
    }
    else {
        sRes = sFormat(xT("%.2f Bit(s)"),  static_cast<DOUBLE>(ullBytes));
    }

    return sRes;
}
//---------------------------------------------------------------------------
//TODO:
/*static*/
////tString 
////CxString::sFormatBytes(ULONGLONG ullBytes) {
////    /*DEBUG*/// ulBytes - n/a
////
////    tString sRes = xT("Uknown");
////
////    if (ullBytes < 1024) {
////        sRes = sFormat(xT("%d B"),     (INT)(ullBytes & 0xffffffff));
////    }
////    else if (ullBytes < 1024*1024) {
////        sRes = sFormat(xT("%.02f KB"), (DOUBLE)ullBytes / (1024.0));
////    }
////    else if (ullBytes < 1024*1024*1024) {
////        sRes = sFormat(xT("%.02f MB"), (DOUBLE)ullBytes / (1024.0*1024.0));
////    }
////    else if (ullBytes < (ULONGLONG)1024*1024*1024*1024) {
////        sRes = sFormat(xT("%.02f GB"), (DOUBLE)ullBytes / (1024.0*1024.0*1024.0));
////    }
////    else if (ullBytes < (ULONGLONG)1024*1024*1024*1024*1024) {
////        sRes = sFormat(xT("%.02f TB"), (DOUBLE)ullBytes / (1024.0*1024.0*1024.0*1024.0));
////    }
////    else {
////        sRes = sFormat(xT("%.02f PB"), (DOUBLE)ullBytes / (1024.0*1024.0*1024.0*1024.0*1024.0));
////    }
////
////    return sRes;
////}
//---------------------------------------------------------------------------
//TODO: - sFormatPercentage (COMMENTS)
/*static*/
tString 
CxString::sFormatPercentage(ULONGLONG ullMaxValue, ULONGLONG ullCurrValue) {
    /*DEBUG*/// ullMaxValue  - n/a
    /*DEBUG*/// ullCurrValue - n/a
    xCHECK_RET(0 == ullMaxValue, xT("0%"));    //devision by zero

    tString sRes;

    sRes = lexical_cast( ullCurrValue * 100 / ullMaxValue );
    xCHECK_RET(true == sRes.empty(), xT("0%"));

    return sRes + xT("%");
}
//---------------------------------------------------------------------------
//TODO: + sStrToWStr (преобразование std::string в std::wstring)
/*static*/
std::wstring 
CxString::sStrToWStr(const std::string &csStr, UINT uiCodePage) {
    /*DEBUG*/// csStr - n/a
    /*DEBUG*/// uiCodePage - n/a

    std::wstring sRes;

#if defined(xOS_WIN)
    INT iSize = ::MultiByteToWideChar(uiCodePage, 0, csStr.c_str(), - 1, NULL, 0);
    /*DEBUG*/xASSERT_RET(0 < iSize, std::wstring());

    sRes.resize(iSize - 1);    //без '\0'
    iSize = ::MultiByteToWideChar(uiCodePage, 0, csStr.c_str(), - 1, static_cast<LPWSTR>(&sRes.at(0)), iSize);
    /*DEBUG*/xASSERT_RET(0 < iSize, std::wstring());
#elif defined(xOS_LINUX)
    //TODO: (xOS_LINUX)
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sWStrToStr (преобразование std::wstring в std::string)
/*static*/
std::string 
CxString::sWStrToStr(const std::wstring &cwsStr, UINT uiCodePage) {
    /*DEBUG*/// cwsStr - n/a
    /*DEBUG*/// uiCodePage - n/a

    std::string sRes;

#if defined(xOS_WIN)
    INT iSize = ::WideCharToMultiByte(uiCodePage, 0, cwsStr.c_str(), - 1, NULL, 0, NULL, NULL);
    /*DEBUG*/xASSERT_RET(0 < iSize, std::string());

    sRes.resize(iSize - 1);    //без '\0'
    iSize = ::WideCharToMultiByte(uiCodePage, 0, cwsStr.c_str(), - 1, static_cast<LPSTR>(&sRes.at(0)), iSize, NULL, NULL);
    /*DEBUG*/xASSERT_RET(0 < iSize, std::string());


    ////char aClassName[1024], aWindowTitle[1024];
    ////WideCharToMultiByte(CP_ACP, 0, WindowTitle, -1, aWindowTitle, 1024, NULL, NULL);
    ////CreateWindowA(aClassName, aWindowTitle, ...);
#elif defined(xOS_LINUX)
    //TODO: (xOS_LINUX)
#endif

    return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sConvertCodePage (конвертирование кодировок
/*static*/
std::string 
CxString::sConvertCodePage(const std::string &csSource, UINT uiCodePageSource, UINT uiCodePageDest) {
//    /*DEBUG*/xASSERT_RET(false == csSource.empty(), std::string());        //FIX: csStr    - n/a
//    /*DEBUG*/// uiCodePageSource
//    /*DEBUG*/// uiCodePageDest

    //CP_ACP(ANSI) <-> CP_UTF8(UTF-8)
    //1251  (WIN)  <-> 20866  (KOI-8r)

    return sWStrToStr(sStrToWStr(csSource, uiCodePageSource), uiCodePageDest);
}
//---------------------------------------------------------------------------
//TODO: - asCharToOemBuff
/*static*/ 
std::string 
CxString::asCharToOemBuff(const tString &csSrc) {
    std::string sDst;

#if defined(xOS_WIN)
    BOOL bRes = FALSE;

    sDst.resize(csSrc.size());

    bRes = ::CharToOemBuff(csSrc.c_str(), &sDst.at(0), sDst.size());
    /*DEBUG*/xASSERT_RET(FALSE != bRes, std::string());
#elif defined(xOS_LINUX)
    //TODO: (xOS_LINUX)
#endif

    return sDst;
}
//---------------------------------------------------------------------------
//TODO: - sOemToCharBuff 
/*static*/ 
tString 
CxString::sOemToCharBuff(const std::string &csSrc) {
    tString sDst;

#if defined(xOS_WIN)
    BOOL bRes = FALSE;

    sDst.resize(csSrc.size());

    bRes = ::OemToCharBuff(csSrc.c_str(), &sDst.at(0), sDst.size());
    /*DEBUG*/xASSERT_RET(FALSE != bRes, tString());
#elif defined(xOS_LINUX)
    //TODO: (xOS_LINUX)
#endif

    return sDst;
}
//---------------------------------------------------------------------------


/****************************************************************************
*    <stdlib.h>
*
*****************************************************************************/

////---------------------------------------------------------------------------
////TODO: - sIntToStr (INT)
///*static*/
//tString
//CxString::sIntToStr(INT iValue, INT iRadix) {
//    /*DEBUG*/// ulValue - n/a
//    /*DEBUG*/xASSERT_RET(2 <= iRadix && iRadix <= 36, tString());
//
//    tString sRes;
//
//    TCHAR szBuff[32 + 1] = {0};        //up to 33 bytes
//
//    sRes = _itot(iValue, szBuff, iRadix);
//    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
//
//    return sRes;
//}
////---------------------------------------------------------------------------
////TODO: - sIntToStr (LONG)
///*static*/
//tString
//CxString::sIntToStr(LONG liValue, INT iRadix) {
//    /*DEBUG*/// ulValue - n/a
//    /*DEBUG*/xASSERT_RET(2 <= iRadix && iRadix <= 36, tString());
//
//    tString sRes;
//
//    TCHAR szBuff[32 + 1] = {0};        //up to 33 bytes
//
//    sRes = _ltot(liValue, szBuff, iRadix);
//    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
//
//    return sRes;
//}
////---------------------------------------------------------------------------
////TODO: + sIntToStr (ULONG)
///*static*/
//tString
//CxString::sIntToStr(ULONG ulValue, INT iRadix) {
//    /*DEBUG*/// ulValue - n/a
//    /*DEBUG*/xASSERT_RET(2 <= iRadix && iRadix <= 36, tString());
//
//    tString sRes;
//
//    TCHAR szBuff[32 + 1] = {0};        //up to 33 bytes
//
//    sRes = _ultot(ulValue, szBuff, iRadix);
//    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
//
//    return sRes;
//}
////---------------------------------------------------------------------------
////TODO: - sIntToStr (LONGLONG)
///*static*/
//tString
//CxString::sIntToStr(LONGLONG i64Value, INT iRadix) {
//    /*DEBUG*/// ulValue - n/a
//    /*DEBUG*/xASSERT_RET(2 <= iRadix && iRadix <= 36, tString());
//
//    tString sRes;
//
//    TCHAR szBuff[64 + 1] = {0};        //up to 65 bytes
//
//    sRes = _i64tot(i64Value, szBuff, iRadix);
//    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
//
//    return sRes;
//}
////---------------------------------------------------------------------------
////TODO: - sIntToStr (ULONGLONG)
///*static*/
//tString
//CxString::sIntToStr(ULONGLONG ui64Value, INT iRadix) {
//    /*DEBUG*/// ulValue - n/a
//    /*DEBUG*/xASSERT_RET(2 <= iRadix && iRadix <= 36, tString());
//
//    tString sRes;
//
//    TCHAR szBuff[64 + 1] = {0};        //up to 65 bytes
//
//    sRes = _ui64tot(ui64Value, szBuff, iRadix);
//    /*DEBUG*/xASSERT_RET(false == sRes.empty(), tString());
//
//    return sRes;
//}
////---------------------------------------------------------------------------



/****************************************************************************
*    другие
*
*****************************************************************************/





/****************************************************************************
*    черновик
*
*****************************************************************************/


//--------------------------------------------------------------------------
////////tString is a TCHAR tString
//////
//////
//////
//////
//////inline tString CharToTString(const char* s)    {
//////    //Handy for converting char to TCHAR
//////    tString tstr;
//////#ifdef UNICODE
//////    int len = 1 + strlen(s);
//////
//////    TCHAR* t = new TCHAR[len];
//////    if (NULL == t) throw std::bad_alloc();
//////
//////    mbstowcs(t, s, len);
//////    tstr = t;
//////    delete []t;
//////#else
//////    tstr = s;
//////#endif
//////    return tstr;
//////}
//////
//////inline tString TCharToString(LPCTSTR t)    {
//////    // Handy for converting TCHAR to char
//////    // If the conversion fails, an empty string is returned.
//////    tString str;
//////#ifdef UNICODE
//////    // calculate the size of the char string required
//////    // Note: If wcstombs encounters a wide character it cannot convert
//////    //       to a multibyte character, it returns –1.
//////    int len = 1 + wcstombs(0, t, 0);
//////    if (0 == len) return str;
//////
//////    char* c = new char[len];
//////    if (NULL == c) throw std::bad_alloc();
//////    c[0] = '\0';
//////
//////    wcstombs(c, t, len);
//////    str = c;
//////    delete []c;
//////#else
//////    str = t;
//////#endif
//////    return str;
//////}



//---------------------------------------------------------------------------

/*WrapText    Разбивает строку на подстроки.*/

////////// Some ATL string conversion enhancements
////////// ATL's string conversions allocate memory on the stack, which can
////////// be undesirable if converting huge strings.  These enhancements
////////// provide for a pre-allocated memory block to be used as the 
////////// destination for the string conversion.
////////#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
////////#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)
////////
////////typedef std::wstring StringW;
////////typedef std::string  StringA;
////////
////////#ifdef _UNICODE
////////typedef StringW String;
////////#define _W2T(dst,src) lstrcpyW(dst,src)
////////#define _T2W(dst,src) lstrcpyW(dst,src)
////////#define _T2A(dst,src) _W2A(dst,src)
////////#define _A2T(dst,src) _A2W(dst,src)
////////#else
////////typedef StringA String;
////////#define _W2T(dst,src) _W2A(dst,src)
////////#define _T2W(dst,src) _A2W(dst,src)
////////#define _T2A(dst,src) lstrcpyA(dst,src)
////////#define _A2T(dst,src) lstrcpyA(dst,src)
////////#endif



/*
//--------------------------------------------------------------------------
ReplaceNoCase
//--------------------------------------------------------------------------
FindNoCase
//--------------------------------------------------------------------------



// -------------------------------------------------------------------------
    // Trim and its variants
    // -------------------------------------------------------------------------
    MYTYPE& Trim()
    {
        return TrimLeft().TrimRight();
    }

    MYTYPE& TrimLeft()
    {
        this->erase(this->begin(),
            std::find_if(this->begin(), this->end(), NotSpace<CT>()));

        return *this;
    }

    MYTYPE&  TrimLeft(CT tTrim)
    {
        this->erase(0, this->find_first_not_of(tTrim));
        return *this;
    }

    MYTYPE&  TrimLeft(PCMYSTR szTrimChars)
    {
        this->erase(0, this->find_first_not_of(szTrimChars));
        return *this;
    }

    MYTYPE& TrimRight()
    {
        // NOTE:  When comparing reverse_iterators here (MYRITER), I avoid using
        // operator!=.  This is because namespace rel_ops also has a template
        // operator!= which conflicts with the global operator!= already defined
        // for reverse_iterator in the header <utility>.
        // Thanks to John James for alerting me to this.

        MYRITER it = std::find_if(this->rbegin(), this->rend(), NotSpace<CT>());
        if ( !(this->rend() == it) )
            this->erase(this->rend() - it);

        this->erase(!(it == this->rend()) ? this->find_last_of(*it) + 1 : 0);
        return *this;
    }

    MYTYPE&  TrimRight(CT tTrim)
    {
        MYSIZE nIdx    = this->find_last_not_of(tTrim);
        this->erase(MYBASE::npos == nIdx ? 0 : ++nIdx);
        return *this;
    }

    MYTYPE&  TrimRight(PCMYSTR szTrimChars)
    {
        MYSIZE nIdx    = this->find_last_not_of(szTrimChars);
        this->erase(MYBASE::npos == nIdx ? 0 : ++nIdx);
        return *this;
    }

*/
