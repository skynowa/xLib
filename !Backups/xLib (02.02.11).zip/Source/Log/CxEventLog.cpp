/****************************************************************************
* Class name:  CxEventLog
* Description: logging to "Event Log"
* File name:   CxEventLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:52:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <xLib/Log/CxEventLog.h>

#include <xLib/CxDateTime.h>
#include <xLib/Fso/CxPath.h>


/****************************************************************************
*    public
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CxEventLog ()
CxEventLog::CxEventLog() {

}
//---------------------------------------------------------------------------
//TODO: + ~CxEventLog ()
CxEventLog::~CxEventLog() {

}
//---------------------------------------------------------------------------
