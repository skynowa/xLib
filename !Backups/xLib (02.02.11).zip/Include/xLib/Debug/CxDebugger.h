/****************************************************************************
* Class name:  CxDebugger
* Description: отладка кода
* File name:   CxDebugger.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     27.11.2009 16:39:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Debug_CxDebuggerH
#define xLib_Debug_CxDebuggerH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
#include <xLib/CxNonCopyable.h>
#include <xLib/Debug/CxReport.h>
//---------------------------------------------------------------------------
class CxReport;
class CxDebugger : public CxNonCopyable {
	public:
        static BOOL  bGetEnabled();
        static BOOL  bSetEnabled(BOOL bFlag);
        static BOOL  bIsPresent ();
        static BOOL  bBreak     ();

		static BOOL  bLog       (const CxReport &rpReport);
		static BOOL  bMsg       (const CxReport &rpReport);
        static BOOL  bMsgRtf    (const CxReport &rpReport);
        static BOOL  bMsgStdOut (const CxReport &rpReport);

        static BOOL  bTrace     (LPCTSTR pcszFormat, ...);

	private:
        static BOOL  _m_bIsEnabled;

	                 CxDebugger ();
		    	    ~CxDebugger ();

	    static BOOL  _bLogAppend(const tString &csText);
};
//---------------------------------------------------------------------------
#endif	//xLib_Debug_CxDebuggerH




