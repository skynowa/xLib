/****************************************************************************
* Class name:  CxMySql
* Description: MySQL data base
* File name:   CxMySql.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     25.01.2011 23:27:12
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Db_CxMySqlH
#define xLib_Db_CxMySqlH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
//---------------------------------------------------------------------------
class CxMySql : public CxNonCopyable {
	public:
				 CxMySql();
		virtual ~CxMySql();
};
//---------------------------------------------------------------------------
#endif //xLib_Db_CxMySqlH
