/****************************************************************************
* Class name:  CxSystemInfo
* Description: system information
* File name:   CxSystemInfo.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_CxSystemInfoH
#define xLib_CxSystemInfoH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
//---------------------------------------------------------------------------
class CxSystemInfo : public CxNonCopyable {
   public:
		//OS version
		enum EOsType {
		    otUnknown,
			otWindows95,
			otWindows98,
			otWindowsNT,
			otWindows2000,
			otWindowsXP,
			otWindows2003,
            otWindows3,
			otLinux
		};

		static EOsType osGetOS         ();
		static tString sFormatOSVersion(ULONG ulOSVersion);
		static tString sGetComputerName();
		static BOOL    bIsUserAnAdmin  ();  //TODO: make test
		static tString sGetUserName    ();
		static ULONG   ulGetNumOfCPUs  ();
		////static ULONG   ulGetCurrCPUNum ();  Vista
		static BOOL    bIsUnicodeOS    ();
		static INT     iGetCpuSpeed    ();

   private:
		               CxSystemInfo    ();
		virtual       ~CxSystemInfo    ();
};
//---------------------------------------------------------------------------
#endif	//xLib_CxSystemInfoH
