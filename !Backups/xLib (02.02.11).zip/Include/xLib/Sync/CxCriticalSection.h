/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ ��������
* File name:   CXLockScope.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Sync_CxCriticalSectionH
#define xLib_Sync_CxCriticalSectionH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
#include <xLib/CxNonCopyable.h>
//---------------------------------------------------------------------------
class CxCriticalSection : public CxNonCopyable {
	public:
		                  CxCriticalSection();
#if (_WIN32_WINNT >= 0x0403)
		explicit          CxCriticalSection(ULONG ulSpinCount);
#endif
		                 ~CxCriticalSection();

		VOID              vEnter           ();
		VOID              vLeave           ();
#if (_WIN32_WINNT >= 0x0403)
		ULONG             ulSetSpinCount   (ULONG ulSpinCount);
#endif
#if (_WIN32_WINNT >= 0x0400)
		BOOL              bTryEnter        ();
#endif

	private:
    #if defined(xOS_WIN)
        CRITICAL_SECTION  _m_CS;
    #elif defined(xOS_LINUX)
        //TODO:
    #endif
};
//---------------------------------------------------------------------------
#endif	//xLib_Sync_CxCriticalSectionH
