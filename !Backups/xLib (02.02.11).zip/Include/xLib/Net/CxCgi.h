/****************************************************************************
* Class name:  CxCgi
* Description: common gateway interace
* File name:   CxCgi.h
* Compilers:   Visual C++ 2010
* String type: Ansi
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     11:01:2010 13:20:00
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
//---------------------------------------------------------------------------
class CxCgi : public CxNonCopyable  {
	public:
        typedef std::map<tString, tString> TStringMap;

        		   CxCgi                  ();
		virtual   ~CxCgi                  ();
		
        //Environ

        //Cookie (http://tools.ietf.org/html/rfc2965)
        tString    sGetCookieValueByName  (const tString &csCookieName);
        ULONG      ulGetCookieCount       ();
        BOOL       bSetCookie             (const tString &csName, const tString &csValue, const tString &csExpires, const tString &csDomain, const tString &csPath, BOOL bSecure);
        BOOL       bDeleteCookie          (const tString &csName/*, const tString &csPath, const tString &csDomain*/);
        //SetCookieForNSeconds(*name, *value, atoi(*seconds), "/docs/web", 0, 0);

		//Query
		BOOL       bInitQuery             ();
		BOOL       bIsPostQuery			  ();
		BOOL       bIsGetQuery            ();
		tString    sGetQueryParamByName   (const tString &csParam);
		ULONG      ulGetQueryParamCount   ();
		

		
		//GetCookieValueByIndex(i, value); // получаем значение параметра по его индексу
		//GetCookieNameByIndex(i, name);   // получаем имя параметра
		
		//-------------------------Other----------------------------------------------------
		//Escape
		//Unescape

		BOOL       bWorkProxy             ();
		BOOL	   bRedirect			  (const tString &csUrl);
		BOOL	   bRedirectToReferer	  ();

		//md5
		size_t     uiContentLength        ();	//не использ.
		VOID       vLog                   (const tString &csText);

	private:
		TStringMap m_msQuery;
		tString    m_sQueryStr;
		TStringMap m_msCookie;
		
		BOOL       m_bFillQueryStr        (tString &sQueryStr);
};
//---------------------------------------------------------------------------


/*
GET  in QUERY_STRING
POST in std::in
*/
 
