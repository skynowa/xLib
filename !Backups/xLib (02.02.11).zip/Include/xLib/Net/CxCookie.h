/****************************************************************************
* Class name:  CxCookie
* Description: cookie
* File name:   CxCookie.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     26.01.2011 0:04:44
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Net_CxCookieH
#define xLib_Net_CxCookieH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
//---------------------------------------------------------------------------
class CxCookie : public CxNonCopyable {
    public:
                 CxCookie();
        virtual ~CxCookie();

        BOOL     bIsExists (const tString &csName);
        tString  sGet      (const tString &csName);
        BOOL     bSet      (const tString &csName, const tString &csValue);
        BOOL     bDelete   (const tString &csName);
        BOOL     bGetValues(std::vector<tString> *pvecsValues);

    private:
        typedef std::map<tString, tString> TStringMap;

        TStringMap m_msCookie;

};
//---------------------------------------------------------------------------
#endif //xLib_Net_CxCookieH
