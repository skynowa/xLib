/****************************************************************************
* Class name:  CxDll
* Description: DLL
* File name:   CxDll.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     06.11.2009 23:39:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_Fso_CxDllH 
#define xLib_Fso_CxDllH
//---------------------------------------------------------------------------
#include <xLib/xCommon.h>
//---------------------------------------------------------------------------
class CxDll : public CxNonCopyable {
	public:
		         CxDll           ();
		virtual ~CxDll           ();

		BOOL     bIsLoaded       ();
		BOOL     bLoad           (const tString &csDllPath);
		FARPROC  fpGetProcAddress(const tString &csProcName);
		BOOL     bFree           ();

	private:
		BOOL     _m_bRes;
		HMODULE  _m_hDLL;
};
//---------------------------------------------------------------------------
#endif //xLib_Fso_CxDllH