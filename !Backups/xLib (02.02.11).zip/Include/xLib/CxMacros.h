/****************************************************************************
* Class name:  CxMacros
* Description: functions like macroses
* File name:   CxMacros.h
* Compilers:   Visual C++ 2010, C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     10.12.2010 19:13:57
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_CxMacrosH
#define xLib_CxMacrosH
//---------------------------------------------------------------------------
#if defined(__cplusplus)
    #include <xLib/xCommon.h>
#endif
//---------------------------------------------------------------------------
////class CxMacros {
	////public:
		#define xPTR_DELETE(p)   	  { if (NULL != (p)) {delete p;     p = NULL;} }
		/*template<class T>
		static inline VOID 
		xPTR_DELETE(T *&a_ptr) {
			if (NULL != a_ptr)  {
				delete a_ptr;
				a_ptr = NULL;
			}
		}*/
//        template <class T>
//        inline void zap(T & x)
//        {
//                {assert(x != NULL);}
//                delete x;
//                x = NULL;
//        }

		#define xARRAY_DELETE(a)	  { if (NULL != (a)) {delete [] a;  a = NULL;} }
		/*template<class T>
		static inline VOID 
		xARRAY_DELETE(T *&a_ptr) {
			if (NULL != a_ptr)  {
				delete [] a_ptr;
				a_ptr = NULL;
			}
		}*/

		#define xARRAY_ZERO_DELETE(a) { if (NULL != (a)) {xBUFF_ZERO(a); delete [] a;  a = NULL;} } 
        #define xARRAY_SIZE(a)        ( sizeof(a) / sizeof((a)[0]) )

        #define xBUFF_ZERO(Buff)      { memset((void *)&Buff[0], 0, sizeof(Buff)); }
        #define xSTRUCT_ZERO(Buff)    { memset((void *)&Buff,    0, sizeof(Buff)); }
        #define xBUFF_FREE(pvBuff)    { if (NULL != pvBuff) { free(pvBuff); pvBuff = NULL;} }

		#define xS2US(s)			  uString( (s).begin(),  (s).begin()  + (s).size()  )
		#define xUS2S(us)			  tString( (us).begin(), (us).begin() + (us).size() )

		#define xS2TS(s)			  tString( (s).begin(),  (s).begin()  + (s).size()  )
		#define xTS2S(ts)			  std::string( (ts).begin(), (ts).begin() + (ts).size() )

		#define xRANDOMIZE() 		  ( srand( (UINT)::GetTickCount() ) ) 
		#define xRANDOM(x)            ( rand() % x )

        #define xFCLOSE(f)            { if (NULL != (f)) { fclose(f); f = NULL; } }

        #define xMAX(a, b)            ( ((a) > (b)) ? (a) : (b) )
        #define xMIN(a, b)            ( ((a) < (b)) ? (a) : (b) )
        #define xUNUSED(arg)          ( arg = arg );

	////private:
	////			 CxMacros();
	////	        ~CxMacros();
////};
//---------------------------------------------------------------------------
#endif //CxMacrosH
