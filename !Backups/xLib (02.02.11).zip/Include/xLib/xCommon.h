/****************************************************************************
* Class name:  CxCommon
* Description: common header for xLib
* File name:   CxCommon.h
* Compilers:   Visual C++ 2010, C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, xLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     23.12.2010 23:24:26
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef xLib_xCommonH
#define xLib_xCommonH
//---------------------------------------------------------------------------
#ifndef __cplusplus
    #error xLib: require C++ compilation (use a .cpp suffix)
#endif
//---------------------------------------------------------------------------

/****************************************************************************
*   xLib configs
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: main configs
//#define __linux
//#define _UNICODE
//----------------------------------------------------------------------------------------------------

/****************************************************************************
*	Predefined xLib macros
*
*****************************************************************************/

//---------------------------------------------------------------------------
//DONE: OS family (http://predef.sourceforge.net/preos.html)
#if defined(_WIN32) || defined(_WIN64) || defined(__WIN32__) || defined(__TOS_WIN__) || defined(__WINDOWS__) 
	#define xOS_WIN
    #pragma message("  --- xLib: xOS_WIN ---")
#elif defined(linux) || defined(__linux)
	#define xOS_LINUX
    #pragma message("  --- xLib: xOS_LINUX ---")
#else
    #define xOS_UNSUPPORTED
    #error xLib: unsupported OS
#endif
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//C library
#include <stdio.h>
#include <stdlib.h>
////#include <conio.h>
#include <cctype>
#include <cstring>
#include <ctime>
#include <errno.h>
#include <stdarg.h>
#include <time.h>
#include <stddef.h>
#include <math.h>

//stl
#include <string>
#include <sstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator>
#include <utility>
#include <iomanip>	//std::setbase
////#include <typeinfo> //typeid
#include <cerrno>

//POSIX
#include <fcntl.h>              //File opening, locking and other operations.
#include <sys/stat.h>           //File information (stat et al.).
#include <sys/types.h>          //Various data types used elsewhere.
//---------------------------------------------------------------------------
#if defined(UNICODE) || defined(_UNICODE)
    #define xT(x)					         L ## x

    typedef wchar_t                          TCHAR;
    typedef wchar_t *                        LPTSTR;
    typedef const wchar_t *                  LPCTSTR;

	typedef std::wstring                     tString;     
	typedef std::basic_string<unsigned char> uString;
	typedef std::wostringstream		         tostringstream; 
	typedef std::wistringstream		         tistringstream;
	typedef std::wifstream			         tifstream;      
	typedef std::wofstream			         tofstream;  

	#define tcin					         std::wcin
	#define tcout					         std::wcout
    #define tcerr                            std::wcerr
    #define tclog                            std::wclog
	#define tendl                            std::endl

    #pragma message("  --- xLib: xUNICODE ---")
#else   
	#define xT(x)					         x
	
    typedef char                             TCHAR;
    typedef char *                           LPTSTR;
    typedef const char *                     LPCTSTR;

	typedef std::string                      tString;       
	typedef std::basic_string<unsigned char> uString;
	typedef std::ostringstream               tostringstream; 
	typedef std::istringstream               tistringstream;
	typedef std::ifstream                    tifstream;      
	typedef std::ofstream                    tofstream;     
	typedef std::ostream                     tcout; 

	#define tcin                             std::cin  
	#define tcout                            std::cout   
    #define tcerr                            std::cerr
    #define tclog                            std::clog
	#define tendl                            std::endl   

    #pragma message("  --- xLib: xANSI ---")
#endif  /*_UNICODE*/

    typedef char *                           LPSTR;   //ansi
    typedef const char *                     LPCSTR;  //ansi

////#if !defined(INT)
////    typedef int INT; 
////#endif
////#if !defined(BOOL)
////    typedef int BOOL; 
////#endif

//---------------------------------------------------------------------------
//Automatically include the xLib namespace, define xNO_USING_NAMESPACE to skip this step
namespace NxLib {}
#ifndef xNO_USING_NAMESPACE
    using namespace NxLib;
#endif
//---------------------------------------------------------------------------
#if defined(xOS_WIN)
    #include "xCommon_Win.h"
#elif defined(xOS_LINUX)
    #include "xCommon_Linux.h"
#endif
//---------------------------------------------------------------------------
#include <xLib/xLinking.h>
#include <xLib/CxMacros.h>
#include <xLib/CxConst.h>
#include <xLib/CxNonCopyable.h>
#include <xLib/Debug/CxTodo.h>
#include <xLib/Debug/xDebug.h>
#include <xLib/CxString.h>
//---------------------------------------------------------------------------
#endif  //xLib_xCommonH
