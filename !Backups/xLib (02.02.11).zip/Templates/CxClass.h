/****************************************************************************
* Class name:  CxClass
* Description: cookie
* File name:   CxClass.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     26.01.2011 0:08:50
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxClassH
#define CxClassH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
//---------------------------------------------------------------------------
class CxClass : public CxNonCopyable {
	public:
				 CxClass();
		virtual ~CxClass();
};
//---------------------------------------------------------------------------
#endif //CxClassH
