/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CThreadH
#define XLib_Sync_CThreadH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXEvent.h>
#include <XLib/Sync/CXSleeper.h>
//---------------------------------------------------------------------------
class CXThread : public CXNonCopyable {
	public:
		//-------------------------------------
		//��������� ������
		static class CXPriority {
			public:
				static const INT tpError        = THREAD_PRIORITY_ERROR_RETURN;
				static const INT tpTimeCritical = THREAD_PRIORITY_TIME_CRITICAL;
				static const INT tpHighest      = THREAD_PRIORITY_HIGHEST;
				static const INT tpAboveNormal  = THREAD_PRIORITY_ABOVE_NORMAL;
				static const INT tpNormal       = THREAD_PRIORITY_NORMAL;
				static const INT tpBelowNormal  = THREAD_PRIORITY_BELOW_NORMAL;
				static const INT tpLowest       = THREAD_PRIORITY_LOWEST;
				static const INT tpIdle         = THREAD_PRIORITY_IDLE;

			private:
				CXPriority();
		};

		////typedef CXPriority CXPriority;

		//-------------------------------------
		//
		typedef      UINT              (WINAPI *pThreadFunc)(VOID *pvParams); 

			         CXThread          (BOOL bSuspended, BOOL bAutoDelete);
		virtual     ~CXThread          () = 0;

		//��������
		BOOL         bCreate           (pThreadFunc ptfStartAddr = 0, VOID *pvParam = NULL);
		BOOL         bIsActive         () const;
		BOOL         bResume           () const;
		BOOL         bSuspend          () const;
		//BOOL       bPauseResume      () { if ( m_bRunning ) m_pEvents[ 1 ]->ResetEvent(); }
		BOOL         bExit             ();

		BOOL         bIsExited         () const;

		BOOL         bYield            () const;
		BOOL         bSleep            (ULONG ulTimeout) const;
		BOOL         bKill             () const;
		BOOL         bWait             (ULONG ulTimeout) const;

		/*
		//Info: Attaches a Thread Function
		void Attach( LPTHREAD_START_ROUTINE lpThreadFunc );

		//Info: Detaches the Attached Thread Function
		void  Detach( void );
		*/

		//���������
		BOOL         bPostMessage       (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL         bSendMessage       (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL         bPostThreadMessage (UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL         bMessageWaitQueue  (UINT uiMsg, INT *piParam1, INT *piParam2) const;

		//���������
		BOOL         bSetPriority       (INT iPriority) const;
		INT          iGetPriority       () const; 
        BOOL         bSpeedUp           () const;
		BOOL         bSlowDown          () const;

		BOOL         bSetAffinityMask   (DWORD_PTR pulMask) const;

		BOOL         bSetIdealCPU       (ULONG ulIdealProcessor) const;
		ULONG        ulGetIdealCPU      () const;

		//���������
		ULONG        ulGetId            ();
		ULONG        ulGetExitCode      () const;      
		BOOL         bSetDebugNameA     (LPCSTR pcszName) const;

		UINT         uiGetStackSize      () const;
		UINT         uiSetStackSize      ();

	protected:
		virtual UINT uiExecute          (VOID *pvParam) = 0;

		//�������
		virtual VOID vOnEnter           ();
		virtual VOID vOnExit            ();	
		
	private:
		BOOL         _m_bAutoDelete;
		BOOL         _m_bSuspended;
		HANDLE       _m_hThread;
		ULONG        _m_ulID;
		////CXEvent  _m_evExit;
		CXSleeper    _m_slSleeper;


		UINT         _m_uiRes;
		pThreadFunc  _m_ptfStartAddress;
		VOID        *_m_pvParam;

		//��������� �������
		volatile BOOL _m_bIsExited;
		//bIsCreated
		//bIsRunning
		//bIsSuspened
		//bIsKilled



		static UINT __stdcall _s_uiStartFunc(VOID *pvParam);
		
		//-------------------------------------
		//��������, ������� ���������� � �������
		class CXData : public CXNonCopyable {
			public:
				VOID *m_pvData;

					  CXData() : m_pvData(NULL) {};
					 ~CXData() {}

			private:

		};
		CXData m_objData;
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CThreadH



/*
void ThreadSetDefault (void) {
	SYSTEM_INFO info;

	if (numthreads == -1)	// not set manually
	{
		GetSystemInfo (&info);
		numthreads = info.dwNumberOfProcessors;
		if (numthreads < 1 || numthreads > 32)
		numthreads = 1;
	}

	Msg ("%i threads\n", numthreads);
}

*/
