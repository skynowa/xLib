/****************************************************************************
* Class name:  CXSafeMTLong
* Description: ���������������� LONG
* File name:   CXSafeMTLong.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.11.2009 10:03:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CXSafeMTLongH
#define XLib_CXSafeMTLongH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXSafeMTLong : public CXNonCopyable {
	public:
		CXSafeMTLong()  { 
			::InterlockedExchange(&_m_liValue, 0); 
		}

		~CXSafeMTLong() {

		}

		CXSafeMTLong& operator += (const CXSafeMTLong &cRight) {
			::InterlockedExchangeAdd(&_m_liValue, cRight._m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator -= (const CXSafeMTLong &cRight) {
			::InterlockedExchange(&_m_liValue, _m_liValue - cRight._m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator = (const CXSafeMTLong &cRight)	{
			::InterlockedExchange(&_m_liValue, cRight._m_liValue); 

			return *this;
		}

		CXSafeMTLong& operator += (const LONG cliRight) {
			::InterlockedExchangeAdd(&_m_liValue, cliRight); 

			return *this;
		}

		CXSafeMTLong& operator -= (const LONG cliRight) {
			::InterlockedExchange(&_m_liValue, _m_liValue - cliRight); 

			return *this;
		}

		CXSafeMTLong& operator = (const LONG cliRight) {
			::InterlockedExchange(&_m_liValue, cliRight); 

			return *this;
		}

		BOOL operator == (const CXSafeMTLong &cRight) {
			return _m_liValue == cRight._m_liValue;
		}

		BOOL operator != (const CXSafeMTLong &cRight) {
			return !(_m_liValue == cRight._m_liValue);
		}

		BOOL operator == (const LONG cliRight) {
			return _m_liValue == cliRight;
		}

		BOOL operator != (const LONG cliRight) {
			return !(_m_liValue == cliRight);
		}

		operator LONG () {
			return _m_liValue;
		}

		operator BOOL () {
			return _m_liValue ? TRUE : FALSE; 
		}

		CXSafeMTLong& operator ++ (INT iPos)	{
			if (0 == iPos) {
				::InterlockedIncrement(&_m_liValue);
			} else {
				::InterlockedExchangeAdd(&_m_liValue, iPos + 1);
			}

			return *this;
		}

		CXSafeMTLong& operator -- (INT iPos)	{
			if (0 == iPos) {
				::InterlockedDecrement(&_m_liValue);
			} else {
				::InterlockedExchangeAdd(&_m_liValue, - (iPos + 1));
			}

			return *this;
		}

	private:
		LONG _m_liValue;
};
//---------------------------------------------------------------------------
#endif	//XLib_CXSafeMTLongH