/****************************************************************************
* Class name:  CXMsgBoxT
* Description: ����� ���������, ������ ���� ������
* File name:   CXMsgBoxT.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.04.2009 10:24:49
* Version:     1.0
*
*****************************************************************************/
 

#ifndef XLib_CXMsgBoxTH	
#define XLib_CXMsgBoxTH   
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <sstream>
//---------------------------------------------------------------------------
template <typename TTextT, typename TTitleT> 
void MsgBox(TTextT tmplText, TTitleT tmplTitle, UINT uiType = MB_OK) {			
	tostringstream ossText;
	ossText << tmplText;

	tostringstream ossTitle;
	ossTitle << tmplTitle;

	::MessageBox(0, ossText.str().c_str(), ossTitle.str().c_str(), uiType);
}
//---------------------------------------------------------------------------
#endif	//XLib_CXMsgBoxTH