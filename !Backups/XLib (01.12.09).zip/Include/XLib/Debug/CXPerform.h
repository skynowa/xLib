/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.h
* String type: Ansi (tstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#ifndef XLib_Debug_CXPerformH
#define XLib_Debug_CXPerformH       
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXPerform : public CXNonCopyable {
	public:
		//Perfomance mode
		static enum EMode {
					pmUknown, 
					pmTime, 
					pmTickCount, 
					pmPerformanceCount, 
					pmThreadTimes
				};
		
		
		////class CXMode {
		////	public:
		////		////static const INT pmUknown                  = 0;
		////		////static const INT pmTime                    = 1;
		////		////static const INT pmGetTickCount            = 2;
		////		////static const INT pmQueryPerformanceCounter = 3;
		////		////static const INT pmGetThreadTimes          = 4;

		////		static enum EMode {
		////			pmUknown, 
		////			pmTime, 
		////			pmGetTickCount, 
		////			pmQueryPerformanceCounter, 
		////			pmGetThreadTimes
		////		};

		////	private:
		////		CXMode();
		////};
		////typedef CXMode::EMode TMode;
		
		              CXPerform            (const tstring &csFileName, EMode pmMode); //TODO: csFileName + iPerfomMode
		             ~CXPerform            ();

		BOOL          bStart               ();
		BOOL          bStop                (const tstring &csComment);
        BOOL          bPulse               (const tstring &csComment);     
        BOOL          bPulse               (ULONG ulComment);
        BOOL          bOpenLog             ();
		BOOL          bDeleteLog           ();

    private:
		EMode		  _m_pmModeNow;		 
        BOOL          _m_bWasStarted;

		BOOL          _bResetData           ();
        tstring       _sMilliSecToTimeString(LONGLONG i64MilliSec); 
		
		//pmTime
		//TDateTime    dtBeginTime;
		//TDateTime    dtEndTime;

		//pmGetTickCount
		ULONG         _m_ulBeginTime;
		ULONG         _m_ulEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER _m_liStart;
		LARGE_INTEGER _m_liBeginCount;
		LARGE_INTEGER _m_liEndCount;
		LARGE_INTEGER _m_liCount;
		
		//GetThreadTimes
		FILETIME      _m_lpCreationTime;  
		FILETIME      _m_lpExitTime;
		FILETIME      _m_lpKernelTime0;
		FILETIME      _m_lpUserTime0;
		FILETIME      _m_lpKernelTime1;
		FILETIME      _m_lpUserTime1;
		LONGLONG      _iFiletimeToint64     (FILETIME F);

		//���
		tstring       _m_sLogPath;
		BOOL          _bLog                 (const tstring &csText);
        BOOL          _bLog                 (const tstring &csComment, const tstring &csText); 
};
//---------------------------------------------------------------------------
#endif	//XLib_Debug_CXPerformH