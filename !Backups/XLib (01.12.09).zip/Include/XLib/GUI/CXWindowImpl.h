/****************************************************************************
* Class name:  CXWindowImpl
* Description: ������ � ������
* File name:   CXWindowImpl.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXWindowImplH
#define XLib_Gui_CXWindowImplH
//---------------------------------------------------------------------------
#include <XLib/Gui/CXWindow.h>
//---------------------------------------------------------------------------
class CXWindowImpl : public CXWindow {
	public:
				     CXWindowImpl();
				    ~CXWindowImpl(); /*virtual*/

		X_DECLARE_MSG_MAP        ()

		BOOL         bCreate     (INT iID, HWND hParent, const tstring &csWndName, 
							      INT iLeft, INT iTop, INT iWidth, INT iHeight, 
							      ULONG ulStyle, ULONG ulExStyle);
		BOOL         bCreateRes  (INT iID, HWND hParent);
		INT          iShowModal  ();
		//BOOL         bShowModaless();

		
		
		virtual VOID OnCreate	 (WPARAM wParam, LPARAM lParam);
		virtual VOID OnPaint     (WPARAM wParam, LPARAM lParam);
		virtual VOID OnCommand   (WPARAM wParam, LPARAM lParam);
		virtual VOID OnNotify    (WPARAM wParam, LPARAM lParam);
		virtual VOID OnSize      (WPARAM wParam, LPARAM lParam);
		virtual VOID OnClose     (WPARAM wParam, LPARAM lParam);  
		virtual VOID OnDestroy   (WPARAM wParam, LPARAM lParam);

	private:
		BOOL         _m_bDestroyed;		//���� ���������� ����
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXWindowImplH