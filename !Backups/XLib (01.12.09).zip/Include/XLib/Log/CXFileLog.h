/****************************************************************************
* Class name:  CXFileLog
* Description: ����������� � ����
* File name:   CXFileLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:40:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXFileLogH
#define CXFileLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXFileLog : public CXNonCopyable {
	public:
		enum ELogSizes{
			DEFAULT_MAX_LOG_SIZE = 200,
			LIMIT_LOG_SIZE       = 500
		};	
			
								 CXFileLog    ();
								 CXFileLog    (const std::string &csFilePath, ULONG ulMaxFileSize = 20);
							    ~CXFileLog    ();
		BOOL                     bWrite       (LPCSTR pcszFormat, ...); /*+*/
		BOOL                     bOpen        ();
		BOOL                     bClear       ();
		BOOL                     bDelete      ();
	   
	private:	
		std::string              _m_sLogPath;
		ULONG                    _m_ulMaxFileSize;
		CXCriticalSection        _m_csFile;  //Mutex
		
		BOOL                     _bDeleteIfFull();
};
//---------------------------------------------------------------------------
#endif