/****************************************************************************
* Class name:  
* Description: 
* File name:   Common.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:09:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef Common_H__x
#define Common_H__x
//---------------------------------------------------------------------------
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#pragma comment(lib, "comctl32.lib")
#include <string>
#include <XLib/Debug/xassert.h>
#include <XLib/Log/CXTraceLog.h>
//---------------------------------------------------------------------------


#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
//����� ������� ���������
#define CXFRAME_CONTROL_CLASS                  "XFRAME"
#define CXBUTTON_CONTROL_CLASS                 "BUTTON"
#define CXCOMBOBOX_CONTROL_CLASS               "COMBOBOX"
#define CXEDIT_CONTROL_CLASS                   "EDIT"
#define CXMDICLIENT_CONTROL_CLASS              "MDICLIENT"
#define CXRICHEDIT_CLASS_CONTROL_CLASS         "RICHEDIT_CLASS"
#define CXSCROLLBAR_CONTROL_CLASS              "SCROLLBAR"
#define CXSTATIC_CONTROL_CLASS                 "STATIC"
#define CXGROUPBOX_CONTROL_CLASS               "BUTTON"
#define CXRADIOBUTTON_CONTROL_CLASS            "BUTTON"
#define CXLISTBOX_CONTROL_CLASS                "LISTBOX"
#define CXSTATUSBAR_CONTROL_CLASS              STATUSCLASSNAME
#define CXPROGRESSBAR_CONTROL_CLASS            PROGRESS_CLASS
#define CXLISTVIEW_CONTROL_CLASS               WC_LISTVIEW
#define CXRICHEDIT_CONTROL_CLASS               RICHEDIT_CLASS
//---------------------------------------------------------------------------
//��������� ������� ����� ���������
#define CXFRAME_DEFAULT_WINDOW_STYLE           WS_OVERLAPPEDWINDOW | DS_CENTER | WS_MINIMIZEBOX | WS_POPUP | WS_CAPTION | WS_SYSMENU
#define CXFRAME_DEFAULT_WINDOW_STYLE_EX        0

#define CXBUTTON_DEFAULT_WINDOW_STYLE          WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP
#define CXBUTTON_DEFAULT_WINDOW_STYLE_EX       0

#define CXCHECKBOX_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX
#define CXCHECKBOX_DEFAULT_WINDOW_STYLE_EX     0

#define CXCOMBOBOX_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP
#define CXCOMBOBOX_DEFAULT_WINDOW_STYLE_EX     0

#define CXEDIT_DEFAULT_WINDOW_STYLE            WS_CHILD | WS_VISIBLE | WS_TABSTOP
#define CXEDIT_DEFAULT_WINDOW_STYLE_EX         WS_EX_CLIENTEDGE

#define CXMDICLIENT_DEFAULT_WINDOW_STYLE       0
#define CXMDICLIENT_DEFAULT_WINDOW_STYLE_EX    0

#define CXSCROLLBAR_DEFAULT_WINDOW_STYLE       0
#define CXSCROLLBAR_DEFAULT_WINDOW_STYLE_EX    0

#define CXSTATIC_DEFAULT_WINDOW_STYLE          WS_CHILD | WS_VISIBLE | WS_TABSTOP
#define CXSTATIC_DEFAULT_WINDOW_STYLE_EX       0

#define CXGROUPBOX_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_GROUPBOX
#define CXGROUPBOX_DEFAULT_WINDOW_STYLE_EX     0

#define CXRADIOBUTTON_DEFAULT_WINDOW_STYLE     WS_CHILD | WS_VISIBLE | WS_TABSTOP | /*BS_RADIOBUTTON*/BS_AUTORADIOBUTTON
#define CXRADIOBUTTON_DEFAULT_WINDOW_STYLE_EX  0

#define CXLISTBOX_DEFAULT_WINDOW_STYLE         WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | LBS_HASSTRINGS | LBS_NOINTEGRALHEIGHT
#define CXLISTBOX_DEFAULT_WINDOW_STYLE_EX      WS_EX_CLIENTEDGE

#define CXSTATUSBAR_DEFAULT_WINDOW_STYLE       WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPSIBLINGS | CCS_BOTTOM
#define CXSTATUSBAR_DEFAULT_WINDOW_STYLE_EX    0

#define CXPROGRESSBAR_DEFAULT_WINDOW_STYLE     WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER
#define CXPROGRESSBAR_DEFAULT_WINDOW_STYLE_EX  0

#define CXLISTVIEW_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP | LVS_REPORT
#define CXLISTVIEW_DEFAULT_WINDOW_STYLE_EX     0

#define CXRICHEDIT_DEFAULT_WINDOW_STYLE        WS_CHILD | WS_VISIBLE | WS_TABSTOP
#define CXRICHEDIT_DEFAULT_WINDOW_STYLE_EX     0
//---------------------------------------------------------------------------
//��������� ������� ��������� (������, ������)
#define CXFRAME_DEFAULT_WIDTH                  CW_USEDEFAULT
#define CXFRAME_DEFAULT_HEIGHT                 CW_USEDEFAULT

#define CXBUTTON_DEFAULT_WIDTH                 75
#define CXBUTTON_DEFAULT_HEIGHT                25

#define CXCHECKBOX_DEFAULT_WIDTH               120
#define CXCHECKBOX_DEFAULT_HEIGHT              17

#define CXCOMBOBOX_DEFAULT_WIDTH               120
#define CXCOMBOBOX_DEFAULT_HEIGHT              21 * 20

#define CXEDIT_DEFAULT_WIDTH                   120
#define CXEDIT_DEFAULT_HEIGHT                  21

#define CXMDICLIENT_DEFAULT_WIDTH              CW_USEDEFAULT
#define CXMDICLIENT_DEFAULT_HEIGHT             CW_USEDEFAULT

#define CXSCROLLBAR_DEFAULT_WIDTH              0
#define CXSCROLLBAR_DEFAULT_HEIGHT             0

#define CXSTATIC_DEFAULT_WIDTH                 120
#define CXSTATIC_DEFAULT_HEIGHT                13

#define CXGROUPBOX_DEFAULT_WIDTH               200
#define CXGROUPBOX_DEFAULT_HEIGHT              200

#define CXRADIOBUTTON_DEFAULT_WIDTH            120
#define CXRADIOBUTTON_DEFAULT_HEIGHT           17

#define CXLISTBOX_DEFAULT_WIDTH                100
#define CXLISTBOX_DEFAULT_HEIGHT               120

#define CXSTATUSBAR_DEFAULT_WIDTH              0
#define CXSTATUSBAR_DEFAULT_HEIGHT             0

#define CXPROGRESSBAR_DEFAULT_WIDTH            120
#define CXPROGRESSBAR_DEFAULT_HEIGHT           23

#define CXLISTVIEW_DEFAULT_WIDTH               200
#define CXLISTVIEW_DEFAULT_HEIGHT              200

#define CXRICHEDIT_DEFAULT_WIDTH               120
#define CXRICHEDIT_DEFAULT_HEIGHT              120
//---------------------------------------------------------------------------
#define XHANDLE_MSG(hWnd, uiMsg, lpFunc)   case (uiMsg): this->##lpFunc((hWnd), (wParam), (lParam)); break;
#define XHANDLE_CMDMSG(iId, lpFunc)  case (iId): this->##lpFunc(); break;
//---------------------------------------------------------------------------
#define LOG()                                  _m_tlLog.bWrite(__FUNCTION__)
//---------------------------------------------------------------------------
#endif