/****************************************************************************
* Class name:  CXFrame
* Description: ������ � ������
* File name:   CXFrame.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXFrameWnd_H
#define CXFrameWnd_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
#define XHANDLE_MSG(uiMsg, lpFunc)   case (uiMsg): this->##lpFunc((wParam), (lParam)); break;
#define XHANDLE_CMDMSG(hWnd, iId, lpFunc)  case (iId): this->##lpFunc(); break;
//---------------------------------------------------------------------------
class CXFrame : public CXWindow {
    public:
				           CXFrame  ();
		                  ~CXFrame  ();

						  UL_DECLARE_MSG_MAP()

		virtual LRESULT    OnCreate (/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		virtual LRESULT    OnPaint  (/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		virtual LRESULT    OnCommand(/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		virtual LRESULT    OnNotify (/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		virtual LRESULT    OnClose  (/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		virtual LRESULT    OnDestroy(/*HWND hWnd, */WPARAM wParam, LPARAM lParam);
		
	protected:
    	/*virtual*/LRESULT pWndProc (/*HWND hWnd, */UINT msg,	WPARAM wParam, LPARAM lParam, PBOOL pbProcessed);	
};
//---------------------------------------------------------------------------
#endif