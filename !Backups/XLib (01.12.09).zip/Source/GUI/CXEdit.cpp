/****************************************************************************
* Class name:  CXEdit
* Description: ������ � ��������� �����
* File name:   CXEdit.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXEdit.h>
//---------------------------------------------------------------------------
//TODO: + CXEdit
CXEdit::CXEdit() {
	LOG();
	
	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXEDIT_CONTROL_CLASS;
	_m_ulStyle        = CXEDIT_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = CXEDIT_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXEDIT_DEFAULT_WIDTH;
	_m_iHeight        = CXEDIT_DEFAULT_HEIGHT;

	_m_bIsControl = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXEdit
CXEdit::~CXEdit() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXEdit::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
							 CXResources::sGetText(iID), 
							 CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
							 CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
							 CXResources::ulGetStyle(iID), 
							 CXResources::ulGetStyleEx(iID),
							 this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bLimitText
LRESULT CXEdit::bLimitText(UINT uiSize) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(EM_LIMITTEXT, uiSize, NULL);
}
//---------------------------------------------------------------------------














/*
VOID CXEdit::CopyEditToClipboard() {
	lSendMessage(EM_SETSEL, 0, 65535L);
	lSendMessage(WM_COPY,   0, 0);
	lSendMessage(EM_SETSEL, 0, 0);
}
*/
//---------------------------------------------------------------------------