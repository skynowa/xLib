/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXPath.h>

#include <XLib/CXString.h>
//---------------------------------------------------------------------------
//TODO:
CXPath::CXPath() {
	//code
}
//---------------------------------------------------------------------------
//TODO:
CXPath::~CXPath() {
	//code
}
//---------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sExeDirPath() {
	return sExtractFileDir(sExePath());
}
//---------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sExePath() {
	TCHAR  szRes[MAX_PATH + 1] = {0};
	
	ULONG ulStored = ::GetModuleFileName(NULL, szRes, MAX_PATH);
	/*DEBUG*/XASSERT_RET(0        != ulStored, tstring());
	/*DEBUG*/XASSERT_RET(NULL     != szRes,    tstring());        
	/*DEBUG*/XASSERT_RET(_T('\0') != *szRes,   tstring());    

	return tstring(szRes, ulStored);	
}
//---------------------------------------------------------------------------
//TODO:   ��� + ���������
/*static*/tstring CXPath::sExtractFullFileName(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	size_t uiEndOfPathIndex = csFilePath.rfind(xWIN_SLASH, csFilePath.size());
	
	return csFilePath.substr(uiEndOfPathIndex + 1, csFilePath.size());
}
//--------------------------------------------------------------------------
//TODO:   ���
/*static*/tstring CXPath::sExtractFileName(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	return sRemoveFileExt(sExtractFullFileName(csFilePath));
}
//--------------------------------------------------------------------------
//TODO:  Returns the path, without a trailing backslash '\'
/*static*/tstring CXPath::sExtractFileDir(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	size_t uiEndOfPathIndex = csFilePath.rfind(xWIN_SLASH, csFilePath.size());

	return csFilePath.substr(0, uiEndOfPathIndex);
}
//---------------------------------------------------------------------------
//TODO:  ����
/*static*/tstring CXPath::sExtractFileDrive(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	size_t uiPos = csFilePath.find(xDRIVE_DELIM);

	return csFilePath.substr(0, uiPos + 1);
}
//---------------------------------------------------------------------------
//TODO: sExtractRelativePath
/*static*/tstring CXPath::sExtractRelativePath(const tstring &csFilePath) {

	return tstring();
}
//--------------------------------------------------------------------------
//TODO: sAddSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
/*static*/tstring CXPath::sAddSlash(const tstring &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), tstring()); 

	tstring sRes;

	if (_T('\\') == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	}
	
	sRes.assign(csDirPath + xWIN_SLASH);

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: sDeleteSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
/*static*/tstring CXPath::sRemoveSlash(const tstring &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), tstring()); 

	const size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if (_T('\\') == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	}

	return csDirPath;
}
//--------------------------------------------------------------------------
//TODO:���������� ��� �����
/*static*/tstring CXPath::sExtractFileExt(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());

	return csFilePath.substr(uiDotPos + 1);
}
//---------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sChangeFileExt(const tstring &csFilePath, const tstring &csFileExt) {	
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	tstring sRes;
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if (_T('.') == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileExt);

			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sChangeFullFileName(const tstring &csFilePath, const tstring &csFileName) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	tstring sRes;
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if (_T('\\') == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileName);

			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: + sRemoveFileExt
/*static*/tstring CXPath::sRemoveFileExt(const tstring &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());

	return csFilePath.substr(0, uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: + sRemoveFileExtIf
/*static*/tstring CXPath::sRemoveFileExtIf(const tstring &csFilePath, const tstring &csFileExt) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring()); 

	//���� ��� ������ ����������, �� ���������� �������� ������
	size_t uiFileExtPos = csFilePath.rfind(xDOT + csFileExt, csFilePath.size());
	if (tstring::npos == uiFileExtPos) {
		return csFilePath;
	}

	size_t uiDotPos = csFilePath.rfind(xDOT, csFilePath.size());

	return csFilePath.substr(0, uiDotPos);
}
//---------------------------------------------------------------------------
//TODO: + sMakeValidFileName
/*static*/tstring CXPath::sMakeValidFileName(const tstring &csFileName) {
	tstring sRes;
	sRes.assign(csFileName);

	const INT ciFileNameMaxSize = 255;

	//-------------------------------------
	//��� ����� �� ������ ������
	if (true == sRes.empty()) {
		return tstring();
	}

	//-------------------------------------
	//��� ����� �� ������ 255 ��������
	if (ciFileNameMaxSize <= sRes.size()) {
		return tstring();
	}

	//-------------------------------------
	//��� ����� �� ����� �������� ������ �� ����� �����
	size_t uiDotPos = sRes.find_first_not_of(_T("."));
	if (uiDotPos == tstring::npos) {
		return tstring();
	}

	//-------------------------------------
	//������ ������ - �� �����  	// if the first character is a dot, the filename is okay
	if (_T('.') == sRes.at(0)) {  //or space
		return tstring();
	}

	//-------------------------------------
	//A device name was used. You can pass this value to GetIsValidFileNameErrStr to obtain a pointer to the name of this device.


	//-------------------------------------
	//All characters greater than ASCII 31 to be used except for the following:    "/*:<>?\|
	const tstring csFatalChars = _T("\\/:*<>|?\"\t\n\r");

	size_t uiFound = sRes.find_first_of(csFatalChars);
	while (tstring::npos != uiFound) 	{
		sRes.erase(uiFound, 1);
		uiFound = sRes.find_first_of(csFatalChars, uiFound);
	}

	//-------------------------------------
	//The following device names cannot be used for a file name nor may they
	//be used for the first segment of a file name (that part which precedes the  first dot):
	//CLOCK$, AUX, CON, NUL, PRN, COM1, COM2, COM3, COM4, COM5, COM6, COM7, COM8,
	//COM9, LPT1, LPT2, LPT3, LPT4, LPT5, LPT6, LPT7, LPT8, LPT9
	//Device names are case insensitve. aux, AUX, Aux, etc. are identical.

	const tstring csReserved[] = { 
		_T("CON"),  _T("PRN"),  _T("AUX"),  _T("CLOCK$"), _T("NUL"),
		_T("COM0"), _T("COM1"), _T("COM2"), _T("COM3"),   _T("COM4"), _T("COM5"), _T("COM6"), _T("COM7"), _T("COM8"), _T("COM9"),
		_T("LPT0"), _T("LPT1"), _T("LPT2"), _T("LPT3"),   _T("LPT4"), _T("LPT5"), _T("LPT6"), _T("LPT7"), _T("LPT8"), _T("LPT9") 
	};

	tstring sFileName = sRemoveFileExt(sRes);

	for (size_t i = 0; i < sizeof(csReserved)/sizeof(csReserved[0]); ++ i) {
		CHECK_RET(TRUE == bCompareNoCase(sFileName, csReserved[i]), tstring());
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sGetEnvironmentVariable(const tstring &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), tstring()); 

	ULONG       ulStored = FALSE;
	tstring sRes(MAX_PATH, _T('\0'));

	//not including the terminating null character
	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, tstring()); 

	sRes.resize(ulStored);

	if (sRes.size() < ulStored) {
		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, tstring());
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO:
/*static*/BOOL CXPath::bSetEnvironmentVariable(const tstring &csVar, const tstring &csValue) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csVar.c_str(), csValue.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//TODO:
/*static*/std::vector<tstring> CXPath::vecsGetEnvironmentStrings() {
	std::vector<tstring> vecsRes;

	LPTSTR pszVar = NULL; 
	LPTCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/XASSERT_RET(NULL != lpvEnv, std::vector<tstring>()); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPTSTR)lpvEnv;

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		vecsRes.push_back(tstring(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	BOOL bRes = FALSE;

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<tstring>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
//TODO:
/*static*/tstring CXPath::sExpandEnvironmentStrings(const tstring &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), tstring()); 

	ULONG       ulStored = FALSE;
	tstring sRes(MAX_PATH, _T('\0'));

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, tstring()); 

	sRes.resize(ulStored);	

	if (sRes.size() < ulStored) {
		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, tstring());
	}

	sRes.resize(ulStored - sizeof(TCHAR));	//������� '\0', including the terminating null character

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: 
/*static*/tstring CXPath::sUnixToWinPath(const tstring &csUnixPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csUnixPath.empty(), tstring()); 

	tstring sRes;
	sRes.assign(csUnixPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if (_T('/') == sRes.at(i)) {
			sRes.at(i) = _T('\\');
		}
	}

	if (bNeedBackslashAtEnd && _T('\\') != sRes.at(sRes.size() - 1)) {
		sRes.append(xWIN_SLASH);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: 
/*static*/tstring CXPath::sWinToUnixPath(const tstring &csWinPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csWinPath.empty(), tstring()); 

	tstring sRes;
	sRes.assign(csWinPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if (_T('\\') == sRes.at(i)) {
			sRes.at(i) = _T('/');
		}
	}

	if (bNeedBackslashAtEnd && _T('/') != sRes.at(sRes.size() - 1)) {
		sRes.append(xNIX_SLASH);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
//TODO: 
/*static*/tstring CXPath::sMinimizeFileName(const tstring &csStr, const size_t cuiMaxLen) {	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(), tstring());
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,          tstring());

	tstring sRes;
	tstring sTildaDotExt      = _T("~.") + sExtractFileExt(csStr);
	size_t  uiTildaDotExtSize = sTildaDotExt.size();

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < uiTildaDotExtSize) {
			sRes = csStr.substr(0, cuiMaxLen);
		} else {
			sRes = csStr.substr(0, cuiMaxLen - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: 
/*static*/tstring CXPath::sMinimizePath(const tstring &csFilePath, const size_t cuiMaxLen) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), tstring());
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,               tstring());

	tstring sRes;
	sRes.assign(csFilePath);	

	tstring sDrive = sExtractFileDrive(csFilePath);					    //D:
	tstring sDir   = sExtractFileDir(csFilePath).erase(0, 2) + xWIN_SLASH;	//\XLib\Test\CXString\Project\Debug\ 
	tstring sName  = sExtractFullFileName(csFilePath);				    //Test.exe

	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/> cuiMaxLen)) { 
		if ((tstring(xWIN_SLASH) + _T("...") + tstring(xWIN_SLASH)) == sDir ) {
			sDrive.clear();
			sDir = _T("...") + tstring(xWIN_SLASH);
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			BOOL   bRoot = FALSE;
			size_t P     = tstring::npos;

			if (xWIN_SLASH == sDir) {
				sDir.clear();
			} else {
				if (sDir.at(0) == _T('\\')) {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = FALSE;
				}

				if (_T('.') == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//P = AnsiPos("\\", S); 
				P = sDir.find_first_of(xWIN_SLASH) + 1;

				if (tstring::npos != P) {
					//Delete(S, 1, P); - c ������� 1(0) P ��������
					sDir.erase(0, P);
					sDir = _T("...") + tstring(xWIN_SLASH) + sDir;        
				} else {
					sDir.clear();
				}

				if (bRoot) {
					sDir = xWIN_SLASH + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*
CommandLineToArgvA
    PCHAR*
    CommandLineToArgvA(
        PCHAR CmdLine,
        int* _argc
        )
    {
        PCHAR* argv;
        PCHAR  _argv;
        ULONG   len;
        ULONG   argc;
        CHAR   a;
        ULONG   i, j;

        BOOLEAN  in_QM;
        BOOLEAN  in_TEXT;
        BOOLEAN  in_SPACE;

        len = strlen(CmdLine);
        i = ((len+2)/2)*sizeof(PVOID) + sizeof(PVOID);

        argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
            i + (len+2)*sizeof(CHAR));

        _argv = (PCHAR)(((PUCHAR)argv)+i);

        argc = 0;
        argv[argc] = _argv;
        in_QM = FALSE;
        in_TEXT = FALSE;
        in_SPACE = TRUE;
        i = 0;
        j = 0;

        while( a = CmdLine[i] ) {
            if(in_QM) {
                if(a == '\"') {
                    in_QM = FALSE;
                } else {
                    _argv[j] = a;
                    j++;
                }
            } else {
                switch(a) {
                case '\"':
                    in_QM = TRUE;
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    in_SPACE = FALSE;
                    break;
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    if(in_TEXT) {
                        _argv[j] = '\0';
                        j++;
                    }
                    in_TEXT = FALSE;
                    in_SPACE = TRUE;
                    break;
                default:
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    _argv[j] = a;
                    j++;
                    in_SPACE = FALSE;
                    break;
                }
            }
            i++;
        }
        _argv[j] = '\0';
        argv[argc] = NULL;

        (*_argc) = argc;
        return argv;
    }
*/

/*

 String
   FileUtilities::GetShortPath(const String &sInPath)
   {
      TCHAR szModuleShort[_MAX_PATH];
      GetShortPathName(sInPath, szModuleShort, _MAX_PATH );

      return szModuleShort;
   }

   String
   FileUtilities::GetLongPath(const String &sInPath)
   {
      TCHAR szLong[_MAX_PATH];
      GetLongPathName(sInPath, szLong, _MAX_PATH );

      return szLong;
   }




//--------------------------------------------------------------------------
*/