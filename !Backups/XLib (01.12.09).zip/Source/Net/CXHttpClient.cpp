/****************************************************************************
* Class name:  CXHttpClient
* Description: ���������� ���������� HTTP/1.0 (RFC 1945)  HTTP/1.1 (...)
* File name:   CXHttpClient.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     16.11.2009 14:43:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CXHttpClient.h>  //65536
//---------------------------------------------------------------------------
CXHttpClient::CXHttpClient() {
	//code
}
//---------------------------------------------------------------------------
CXHttpClient::~CXHttpClient() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bHead ()
BOOL CXHttpClient::bHead(const std::string &csUrl, std::string *psResponse) {
	BOOL bRes = FALSE;

	//csUrl = http://dn1.berloga.net/83841/zombie_baseball_2.swf

	std::string sStartLine;
	std::string sHeader;
	std::string sBody;
	
	sStartLine = "HEAD /83841/zombie_baseball_2.swf HTTP/1.1"         + xCRLF;
		
	sHeader    = "Host: dn1.berloga.net"                              + xCRLF +
			     "Accept: text/html, */*"                             + xCRLF +
				 "Accept-Encoding: identity"                          + xCRLF +
				 "User-Agent: Mozilla/3.0 (compatible; Indy Library)" + xCRLF + xCRLF;	

	sBody      = "";

	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGet ()
BOOL CXHttpClient::bGet(const std::string &csUrl,  std::string *psResponse) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bPost ()
BOOL CXHttpClient::bPost(const std::string &csUrl,  const std::string &csParams, std::string *psResponse) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bOptions ()
BOOL CXHttpClient::bOptions(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bTrace ()
BOOL CXHttpClient::bTrace(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bPut ()
BOOL CXHttpClient::bPut(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bDelete ()
BOOL CXHttpClient::bDelete(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bConnect ()
BOOL CXHttpClient::bConnect(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bPatch ()
BOOL CXHttpClient::bPatch(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bLink ()
BOOL CXHttpClient::bLink(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: - bUnlink ()
BOOL CXHttpClient::bUnlink(const std::string &csUrl) {
	return FALSE;
}
//---------------------------------------------------------------------------
