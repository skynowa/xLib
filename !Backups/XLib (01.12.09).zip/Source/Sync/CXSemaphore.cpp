/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXSemaphore.h>

#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
CXSemaphore::CXSemaphore() 
	: _m_hSemaphore(NULL)
{
	
}
//---------------------------------------------------------------------------
CXSemaphore::~CXSemaphore() {
	/*DEBUG*/XASSERT(NULL != _m_hSemaphore);

	if (NULL != _m_hSemaphore) {
		BOOL bRes = FALSE;

		bRes = ::CloseHandle(_m_hSemaphore);	_m_hSemaphore = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXSemaphore::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, NULL);

	return _m_hSemaphore;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG nInitialCount, LONG nMaxCount, LPCTSTR pcszName) {
	_m_hSemaphore = ::CreateSemaphore(lpsaAttributes, nInitialCount, nMaxCount, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXSemaphore::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);
	
	_m_hSemaphore = ::OpenSemaphore(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//void AddItem(void * NewItem)
BOOL CXSemaphore::bRelease(LONG liReleaseCount, LONG *pliOldCount) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, FALSE);

	BOOL bRes = FALSE;
	
	bRes = ::ReleaseSemaphore(_m_hSemaphore, liReleaseCount, pliOldCount);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//void GetItem(void * Item)
ULONG CXSemaphore::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hSemaphore, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return ::WaitForSingleObject(_m_hSemaphore, ulTimeout);
}
//---------------------------------------------------------------------------