/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXThread.h>
#if defined(_MT) || defined(_DLL)
#	include <process.h>
#endif // _MT


/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXThread (�����������)
CXThread::CXThread(BOOL bSuspended, BOOL bAutoDelete) :
	_m_bSuspended     (bSuspended == TRUE ? CREATE_SUSPENDED : 0),
	_m_bAutoDelete    (bAutoDelete),
	_m_hThread        (NULL),
	_m_ulID           (0),
	_m_uiRes          (0),
	_m_pvParam        (NULL),
	_m_ptfStartAddress(0),
	_m_bIsExited      (FALSE)
{
}
//---------------------------------------------------------------------------
//TODO: + ~CXThread (����������)
CXThread::~CXThread() {
	//if (TRUE == bIsActive()) {
	//	////bKill();
	//}

	CLOSE_HANDLE(_m_hThread);
}
//---------------------------------------------------------------------------
//TODO: + bCreate (������ ������)
BOOL CXThread::bCreate(pThreadFunc ptfStartAddr/* = 0*/, VOID *pvParam/* = NULL*/) {
	////if(NULL != m_hThread) {
	////	::CloseHandle(m_hThread);
	////	m_hThread = NULL;
	////}


	/*DEBUG*/XASSERT_RET(!CHECK_HANDLE(_m_hThread), FALSE); 
	/*DEBUG*///ptfStartAddr - not need
	/*DEBUG*///pvParam      - not need

	_m_ptfStartAddress = ptfStartAddr;
	_m_pvParam         = pvParam;
#ifdef _MT
	_m_hThread = reinterpret_cast<HANDLE>(_beginthreadex(NULL, 0, _s_uiStartFunc, this, _m_bSuspended, (UINT *)&_m_ulID));
#else
	_m_hThread = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)_s_uiStartFunc, this, _m_bSuspended, &_m_ulID);
#endif 
	/*DEBUG*/XASSERT_RET(NULL != _m_hThread, FALSE);

	//terminate

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsActive (�������� ���������� ������)
BOOL CXThread::bIsActive() const {
	/*DEBUG*///not need 

	return (TRUE          == CHECK_HANDLE(_m_hThread)               && 
		   (WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread, 0))) && 
		   (STILL_ACTIVE  == ulGetExitCode()); 
}
//---------------------------------------------------------------------------
//TODO: + bResume (������������� ������)
BOOL CXThread::bResume() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	ULONG ulResumeCount = (ULONG) - 1;

	ulResumeCount = ::ResumeThread(_m_hThread);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulResumeCount, FALSE);

	while (ulResumeCount > 1) {
		ulResumeCount = ::ResumeThread(_m_hThread);
		/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulResumeCount, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSuspend (������������ ������)
BOOL CXThread::bSuspend() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	ULONG ulRes = (ULONG) -1;

	ulRes = ::SuspendThread(_m_hThread);         
	/*DEBUG*/XASSERT_RET((ULONG) -1 != ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExit (����� �� ������ - ��������� ����� ������ �� ������)
BOOL CXThread::bExit() {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	//bResume()

	////return _m_evExit.bSet();
	_m_bIsExited = TRUE;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bYield (�������� ������� ������� ������, ������� ����� � ���������� �� !������� ����������!)
BOOL CXThread::bYield() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 
	
	::SwitchToThread();
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleep (Suspends the execution of the current thread until the time-out interval elapses)
BOOL CXThread::bSleep(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	BOOL bRes = FALSE;  

	bRes = _m_slSleeper.bSleep(ulTimeout);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsExited (��������� �� ���� ������ ��� ������)
BOOL CXThread::bIsExited() const {
	/*DEBUG*/ 

	////return _m_evExit.bIsSignaled();
	return _m_bIsExited;
}
//---------------------------------------------------------------------------
//TODO: - bKill (����������� ������)
BOOL CXThread::bKill() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	BOOL bRes = FALSE;  

	bRes = ::TerminateThread(_m_hThread, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	ULONG ulRes = 0;
	for (;;) {
		bRes = ::GetExitCodeThread(_m_hThread, &ulRes);
		/*DEBUG*/XASSERT_DO(FALSE == bRes, break);
		
		CHECK_DO(STILL_ACTIVE != ulRes, break);

		bSleep(1);
	}

	////bRes = ::CloseHandle(_m_hThread);	_m_hThread = NULL;
	/////*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait (�������� ������)
BOOL CXThread::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	//WAIT_OBJECT_0   ������ ������� � ��������� ���������� 
	//WAIT_TIMEOUT    ������  ��  �������  �  ���������  ����������  �� ��������� ������ ������� 
	//WAIT_ABANDONED  ������ ������� ���� �������� ��-�� ������ �� ���� 
	//WAIT_FAILED     ��������� ������
	ULONG ulRes = ::WaitForSingleObject(_m_hThread, ulTimeout);   

	return (WAIT_OBJECT_0 == ulRes);
}
//---------------------------------------------------------------------------






//---------------------------------------------------------------------------
//TODO: + bPostMessage (������� ��������� �� ������ � ����)
BOOL CXThread::bPostMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread),   FALSE);		
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(hHwnd),        FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != ::IsWindow(hHwnd), FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSendMessage (������� ��������� �� ������ � ����)
BOOL CXThread::bSendMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread),   FALSE);
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(hHwnd),        FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != ::IsWindow(hHwnd), FALSE);

	::SendMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*///- not need 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPostThreadMessage (������� ��������� � �����)
BOOL CXThread::bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostThreadMessage(_m_ulID, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue (�������� ��������� c ����������� �� ������� ������)
BOOL CXThread::bMessageWaitQueue(UINT uiMsg, INT *piParam1, INT *piParam2) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE);
	/*DEBUG*/XASSERT_RET(0    <  uiMsg,            FALSE);

	BOOL bRes   = - 1;
	MSG  msgMsg = {0};

	while (bRes = ::GetMessage(&msgMsg, NULL, 0, 0 )) {
		if (- 1 == bRes) {
			/*DEBUG*/XASSERT_RET(FALSE, FALSE);
			break;
		}

		if (uiMsg == msgMsg.message) {
			if (NULL != piParam1) {
				*piParam1 = static_cast<INT>(msgMsg.lParam);
			}

			if (NULL != piParam2) {
				*piParam2 = static_cast<INT>(msgMsg.wParam);
			}

			break;
		}

		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return TRUE;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO: + bSetPriority (��������� ���������� ������)
BOOL CXThread::bSetPriority(INT iPriority) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriority(_m_hThread, iPriority);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iGetPriority (��������� ���������� ������)
INT CXThread::iGetPriority() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), CXPriority::tpError); 

	INT iRes = CXPriority::tpError;

	iRes = ::GetThreadPriority(_m_hThread);
	/*DEBUG*/XASSERT_RET(CXPriority::tpError != iRes, CXPriority::tpError);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: - bSpeedUp ()
BOOL CXThread::bSpeedUp() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	INT iOldLevel = CXPriority::tpError;
	INT iNewLevel = CXPriority::tpError;

	iOldLevel = iGetPriority();
	switch (iOldLevel) {
		case CXPriority::tpTimeCritical:
    		return TRUE;
			break;

		case CXPriority::tpHighest: 
		    iNewLevel = CXPriority::tpTimeCritical;
			break;

		case CXPriority::tpAboveNormal: 
		    iNewLevel = CXPriority::tpHighest;
			break;

		case CXPriority::tpNormal: 
			iNewLevel = CXPriority::tpAboveNormal;
			break;

		case CXPriority::tpBelowNormal: 
			iNewLevel = CXPriority::tpNormal;
			break;

		case CXPriority::tpLowest: 
			iNewLevel = CXPriority::tpBelowNormal;
			break;

		case CXPriority::tpIdle: 
			iNewLevel = CXPriority::tpLowest;
			break;

		default:
			/*XASSERT*/XASSERT_RET(FALSE, CXPriority::tpNormal);	
			break;
	}

	return bSetPriority(iNewLevel);
} 
//---------------------------------------------------------------------------
//TODO: - bSlowDown ()
BOOL CXThread::bSlowDown() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	INT iOldLevel = CXPriority::tpError;
	INT iNewLevel = CXPriority::tpError;

	iOldLevel = iGetPriority();
	switch (iOldLevel) {
		case CXPriority::tpTimeCritical: 
			iNewLevel = CXPriority::tpHighest;
			break;

		case CXPriority::tpHighest: 
			iNewLevel = CXPriority::tpAboveNormal;
			break;

		case CXPriority::tpAboveNormal: 	
			iNewLevel = CXPriority::tpNormal;
			break;

		case CXPriority::tpNormal: 	
			iNewLevel = CXPriority::tpBelowNormal;
			break;

		case CXPriority::tpBelowNormal: 	
			iNewLevel = CXPriority::tpLowest;
			break;

		case CXPriority::tpLowest: 	
			iNewLevel = CXPriority::tpIdle;
			break;

		case CXPriority::tpIdle: 	
			return TRUE;
			break;

		default:
			break;
	}

	return bSetPriority(iNewLevel);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + bSetAffinityMask (Sets a processor affinity mask for the specified thread)
BOOL CXThread::bSetAffinityMask(DWORD_PTR pulMask) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	DWORD_PTR pulRes = 0;

	pulRes = ::SetThreadAffinityMask(_m_hThread, pulMask);	//ERROR_INVALID_PARAMETER	
	/*DEBUG*/XASSERT_RET(0 != pulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetIdealProcessor (Sets a preferred processor for a thread, ulIdealProcessor - this value is zero-based)
BOOL CXThread::bSetIdealCPU(ULONG ulIdealProcessor) const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), FALSE); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread, ulIdealProcessor);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulRes, FALSE); 
	
	//TODO: - XASSERT_RET
	///*DEBUG*/XASSERT_RET(ulIdealProcessor != ulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ulGetIdealProcessor ()
ULONG CXThread::ulGetIdealCPU() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), 0); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread, MAXIMUM_PROCESSORS);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulRes, FALSE); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetId (ID ������)
ULONG CXThread::ulGetId() {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), 0); 

	ULONG ulRes = 0;

	ulRes = ::GetCurrentThreadId();
	/*DEBUG*/XASSERT_RET(0 != ulRes, 0);
	/*DEBUG*///TODO: - XASSERT_RET(static_cast<ULONG>(_m_uiID) == ulRes, 0);

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + bGetExitCode (Retrieves the termination status of the specified thread)
ULONG CXThread::ulGetExitCode() const {
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(_m_hThread), 0); 

	ULONG ulRes = 0;	//STILL_ACTIVE
	BOOL  bRes  = 0;

	bRes = ::GetExitCodeThread(_m_hThread, &ulRes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, 0);

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: - bSetDebugName (Name your threads in the VC debugger thread list)
BOOL CXThread::bSetDebugNameA(LPCSTR pcszName) const {
	/*DEBUG*/XASSERT_RET(0    <  _m_ulID,              FALSE); 
	/*DEBUG*/XASSERT_RET(NULL != pcszName,             FALSE); 
	/*DEBUG*/XASSERT_RET(32   >  ::lstrlenA(pcszName), FALSE); //MAX_NAME_SIZE 32

	BOOL bRes = FALSE;

	typedef struct tagTHREADNAME_INFO {
		DWORD  dwType;     //must be 0x1000
		LPCSTR szName;     //pointer to name (in user addr space)
		DWORD  dwThreadID; //thread ID (-1=caller thread)
		DWORD  dwFlags;    //reserved for future use, must be zero
	} THREADNAME_INFO;

	////bRes = ::IsDebuggerPresent();
	////CHECK_RET(FALSE == bRes, FALSE);

	THREADNAME_INFO tiInfo = {0};
	tiInfo.dwType     = 0x1000;
	tiInfo.szName     = pcszName;
	tiInfo.dwThreadID = - 1;	//_m_ulID;
	tiInfo.dwFlags    = 0;

	__try {
		::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), static_cast<DWORD *>( static_cast<LPVOID>(&tiInfo) ));
	}
	__except (EXCEPTION_CONTINUE_EXECUTION)	{
		/*DEBUG*/XASSERT_RET(FALSE, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------





/****************************************************************************
*	protected 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + iExecute (������� ������)
/*virtual*/ UINT CXThread::uiExecute(VOID *pvParam) {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_RET(FALSE, 0);

	//must override this

	/*UINT uiRes = 0;

	for (;;) {
		if (TRUE == bIsExited()) {
			return uiRes;
		}
		if (TRUE == bIsPaused()) {
			WaitCancelPause();
		}

		//...
	}	

	return uiRes;*/

	return 0;
}
//---------------------------------------------------------------------------
//TODO: + vOnConstruct (������� �� ��������������� ������)
/*virtual*/ VOID CXThread::vOnEnter() {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_DO(FALSE, return);

	//must override this

	return;
}
//---------------------------------------------------------------------------
//TODO: + vOnDestroy (������� �� ���������� ������)
/*virtual*/ VOID CXThread::vOnExit() {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_DO(FALSE, return);

	//must override this

	return;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_uiStartFunc (����������� ������� ������)
UINT __stdcall CXThread::_s_uiStartFunc(VOID *pvParam) {
	/*DEBUG*/XASSERT_RET(NULL != pvParam, 0);

	UINT uiRes = 0;
	BOOL bRes  = 0;

	CXThread *pthThis = static_cast<CXThread *>(pvParam); 
	/*DEBUG*/XASSERT_RET(NULL != pthThis,                   0);
	/*DEBUG*/XASSERT_RET(CHECK_HANDLE(pthThis->_m_hThread), 0); 

	__try {
		//-------------------------------------
		//_m_evExit
		////bRes = pthThis->_m_evExit.bCreate(NULL, FALSE, FALSE, NULL);
		////CHECK_RET(FALSE == bRes, 0);

		/*if (! Thread.Terminated) {
			try {
				Thread.Execute;
			} except {
				Thread.FFatalException := AcquireExceptionObject;
			}
		}*/

		//-------------------------------------
		//�������� �� ������ ���������� ������� ������
		pthThis->vOnEnter();

		//-------------------------------------
		//������� ������
		if (0 == pthThis->_m_ptfStartAddress) {
			uiRes = pthThis->_m_uiRes = pthThis->uiExecute(pthThis->_m_pvParam);
		} else {
			uiRes = pthThis->_m_ptfStartAddress(pthThis->_m_pvParam);
		}

		//-------------------------------------
		//�������� ����� ��������� ���������� ������� ������
		pthThis->vOnExit();
	} 
	__finally {

	}

	//-------------------------------------
	//��������������� ������
	////CHECK_DO(TRUE == pthThis->_m_bAutoDelete, DELETE_POINTER(pthThis) /*, ClearMembers*/);
	
	return uiRes;
}
//---------------------------------------------------------------------------












/*
bool CSocketServer::p_StopTcpPump(void)
{
DWORD dwExitCode = 0;

if(this->p_bTcpPumpActive)
{
this->p_bShutdownTcpPump = true;

while(GetExitCodeThread(this->p_hTcpPump, &dwExitCode))
{
if(dwExitCode != STILL_ACTIVE)
{
CloseHandle(this->p_hTcpPump);
return true;
}
Sleep(1);
}

return this->p_ThrowError(24);
}

return true;
}
*/