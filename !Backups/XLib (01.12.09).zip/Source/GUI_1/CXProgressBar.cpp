/****************************************************************************
* Class name:  CXProgressBar
* Description: ��������� ����������
* File name:   CXProgressBar.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.07.2009 11:05:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXProgressBar.h>
//---------------------------------------------------------------------------
CXProgressBar::CXProgressBar() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXPROGRESSBAR_CONTROL_CLASS;
	_m_ulStyle        = CXPROGRESSBAR_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXPROGRESSBAR_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXPROGRESSBAR_DEFAULT_WIDTH;
	_m_iHeight        = CXPROGRESSBAR_DEFAULT_HEIGHT;
	
	//TODO: bInitCommonControls
	bInitCommonControls(ICC_PROGRESS_CLASS);
}
//---------------------------------------------------------------------------
CXProgressBar::~CXProgressBar() {
	LOG();
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetRange(INT nMin, INT nMax) {	 //�������� ��������� �������� � ��������� �������� (� �������� �� 0 �� 65535).
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETRANGE, (WPARAM)0, (LPARAM)MAKELPARAM(nMin, nMax));
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetRange32(INT nMin, INT nMax) {	 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETRANGE32, (WPARAM)nMin, (LPARAM)nMax);
}
//---------------------------------------------------------------------------
BOOL CXProgressBar::bGetRange(PPBRANGE pPBRange) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(PBM_GETRANGE, (WPARAM)TRUE, (LPARAM)pPBRange);
	
	return TRUE;
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetRangeLimit(BOOL bLimit) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_GETRANGE, (WPARAM)bLimit, (LPARAM)NULL);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetMaxValue() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_GETRANGE, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetMinValue() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_GETRANGE, (WPARAM)1, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetPos(INT nPos) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETPOS, nPos, 0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::GetPos() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_GETPOS, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::DeltaPos(INT nDelta) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_DELTAPOS, nDelta, 0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::SetStep(INT nStep) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETSTEP, (WPARAM)nStep, (LPARAM)0);
}
//---------------------------------------------------------------------------
INT CXProgressBar::StepIt() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_STEPIT, (WPARAM)0, (LPARAM)0);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBarColour(COLORREF clrBar) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETBARCOLOR , (WPARAM)0, (LPARAM)(COLORREF)clrBar);
}
//---------------------------------------------------------------------------
COLORREF CXProgressBar::SetBkColour(COLORREF clrBk) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(PBM_SETBKCOLOR, (WPARAM)0, (LPARAM)(COLORREF)clrBk);
}
//---------------------------------------------------------------------------