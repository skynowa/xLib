/****************************************************************************
* Class name:  CXFrame
* Description: ������ � ������
* File name:   CXFrame.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXFrame.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXFrame::CXFrame() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName = CXFRAME_CONTROL_CLASS;
	_m_ulStyle    = CXFRAME_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle  = CXFRAME_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft      = CW_USEDEFAULT;
	_m_iTop       = CW_USEDEFAULT;
	_m_iWidth     = CXFRAME_DEFAULT_WIDTH;
	_m_iHeight    = CXFRAME_DEFAULT_HEIGHT;

	_m_bIsFrame   = TRUE;
}
//---------------------------------------------------------------------------
CXFrame::~CXFrame() {
	LOG();
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnCreate(/*HWND hWnd, */WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnPaint(/*HWND hWnd, */WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnCommand(/*HWND hWnd, */WPARAM wParam, LPARAM lParam){
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnNotify(/*HWND hWnd, */WPARAM wParam, LPARAM lParam) {
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnClose(/*HWND hWnd, */WPARAM wParam, LPARAM lParam) {
	/*::DestroyWindow(hWnd);*/
	
	return FALSE;
}
//---------------------------------------------------------------------------
LRESULT CXFrame::OnDestroy(/*HWND hWnd, */WPARAM wParam, LPARAM lParam) {
	/*::PostQuitMessage(0);*/
	
	return FALSE;
}
//---------------------------------------------------------------------------

UL_BEGIN_MSG_MAP(CXFrame)
	UL_MSG(/*hWnd, */WM_CREATE,     OnCreate);
	//XHANDLE_MSG(hWnd, WM_INITDIALOG, OnCommand);
	UL_MSG(/*hWnd, */WM_PAINT,   OnPaint);
	UL_MSG(/*hWnd, */WM_COMMAND, OnCommand);
	UL_MSG(/*hWnd, */WM_NOTIFY,  OnNotify);
	UL_MSG(/*hWnd, */WM_CLOSE,   OnClose);    
	UL_MSG(/*hWnd, */WM_DESTROY, OnDestroy);  
UL_END_MSG_MAP_NOPARENT
/*
BEGIN_MSG_MAP(thisClass)
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)				
	MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseMove)
END_MSG_MAP()
*/
//#define HANDLE_MSG(hWnd, uiMsg, lpFunc)  case (uiMsg): this->##lpFunc((hWnd), (wParam), (lParam)); break;
///////*virtual*/LRESULT CXFrame::pWndProc(/*HWND hWnd, */UINT uiMsg, WPARAM wParam, LPARAM lParam, PBOOL pbProcessed) {
//////	switch (uiMsg) {
//////		XHANDLE_MSG(/*hWnd, */WM_CREATE,     OnCreate);
//////		//XHANDLE_MSG(hWnd, WM_INITDIALOG, OnCommand);
//////		XHANDLE_MSG(/*hWnd, */WM_PAINT,   OnPaint);
//////		XHANDLE_MSG(/*hWnd, */WM_COMMAND, OnCommand);
//////		XHANDLE_MSG(/*hWnd, */WM_NOTIFY,  OnNotify);
//////		XHANDLE_MSG(/*hWnd, */WM_CLOSE,   OnClose);    
//////		XHANDLE_MSG(/*hWnd, */WM_DESTROY, OnDestroy);  
//////		//WM_KEYDOWN
//////		//WM_CHAR
//////
//////		default:
//////			*pbProcessed = FALSE;	//not processed
//////	}
//////	
//////	*pbProcessed = TRUE;	        //Yes, message was processed.
//////	
//////	return FALSE;	//::DefWindowProc(hWnd, uiMsg, wParam, lParam);
//////}
////////---------------------------------------------------------------------------