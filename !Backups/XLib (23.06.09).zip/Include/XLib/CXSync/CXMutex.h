/****************************************************************************
* Class name:  CXMutex
* Description: ������ � ����������
* File name:   CXMutex.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:48:30
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXMutexH
#define CXMutexH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXMutex {
		_NO_COPY(CXMutex);

	public:
		       CXMutex              ();
			  ~CXMutex              ();
	    HANDLE hGetHandle           ();
		BOOL   bCreate              (LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bInitialState, LPCSTR pcszName);
		BOOL   bOpen                (ULONG ulAccess, BOOL bInheritHandle, LPCSTR pcszName);
		BOOL   bRelease             ();
		ULONG  ulWaitForSingleObject(ULONG ulTimeout = INFINITE);

	private:
		HANDLE m_hMutex;
};
//---------------------------------------------------------------------------
#endif