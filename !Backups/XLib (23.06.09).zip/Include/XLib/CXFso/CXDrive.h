/****************************************************************************
* Class name:  CXDrive
* Description: �������� � �������
* File name:   CXDrive.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:25:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXDriveH
#define CXDriveH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXDrive {
	public:
		//Types
		typedef enum {
			dtUnknown   = DRIVE_UNKNOWN,		//The drive type cannot be determined
			dtNoRoot    = DRIVE_NO_ROOT_DIR,	//The root path is invalid
			dtRemovable = DRIVE_REMOVABLE,		//The drive has removable media
			dtFixed     = DRIVE_FIXED,			//The drive has fixed media
			dtRemote    = DRIVE_REMOTE,			//The drive is a remote (network) drive
			dtCdRom     = DRIVE_CDROM,			//The drive is a CD-ROM drive
			dtRam       = DRIVE_RAMDISK,		//The drive is a RAM disk
		} EType;	

			        CXDrive        ();
			       ~CXDrive        ();
		static BOOL bIsReady       (const std::string &csDrivePath); /*+*/
		static BOOL bGetFreeSpace  (const std::string &csDirPath/*in*/, ULONGLONG *lpFreeBytesAvailableToCaller, ULONGLONG *lpTotalNumberOfBytes, ULONGLONG *lpTotalNumberOfFreeBytes); 

		//TODO: DefineDosDevice
		//TODO: DeleteVolumeMountPoint
		//TODO: FindFirstVolume
		//TODO: FindFirstVolumeMountPoint
		//TODO: FindNextVolume
		//TODO: FindNextVolumeMountPoint
		//TODO: FindVolumeClose
		//TODO: FindVolumeMountPointClose

		static EType dtGetType     (const std::string &csDrivePath);

		//TODO: GetLogicalDrives
		//TODO: GetLogicalDriveStrings

		static BOOL bGetInformation(
									const std::string &csDrivePath,
									LPSTR              pszVolumeNameBuffer/*out*/,
									ULONG              ulVolumeNameSize,
									ULONG             *pulVolumeSerialNumber/*out*/,
									ULONG             *pulMaximumComponentLength/*out*/,
									ULONG             *pulFileSystemFlags/*out*/,
									LPSTR              pszFileSystemNameBuffer/*out*/,
									ULONG              ulFileSystemNameSize);

		//TODO: GetVolumeInformationByHandleW
		//TODO: GetVolumeNameForVolumeMountPoint
		//TODO: GetVolumePathName
		//TODO: GetVolumePathNamesForVolumeName
		//TODO: QueryDosDevice
		//TODO: SetVolumeLabel
		//TODO: SetVolumeMountPoint
};
//---------------------------------------------------------------------------
#endif
