/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXPop3H 
#define CXPop3H 
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <XLib/CXNet/CXTcpClientSocket.h> 
#include <XLib/CXNet/CXMimeHeader.h> 
#include <vector>
#include <map>
//---------------------------------------------------------------------------
class CXPop3 { 
		_NO_COPY(CXPop3);
		
	public: 
                    	    CXPop3         (); 
                    	   ~CXPop3         (); 
		BOOL                bCreate        (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); /*+*/
		BOOL                bConnect       (); /*+*/
	    BOOL                bIsConnected   (); /*-*/
 		BOOL                bLogin         (); /*+*/
		BOOL                bStat          (ULONG &ulSum, ULONG &ulSize); /*+*/
		BOOL                bList          (std::vector<ULONG> &veculList);	/*-*/
		BOOL                bListAt        (ULONG &ulIndex); /*-*/
		BOOL                bTop           (INT iNum, INT iLines, std::string &sBuff); /*-*/
		BOOL                bRetriveRaw    (INT iNum, const std::string &csDirPath); /*+*/ 
		BOOL                bRetrieveHeader(INT iNum, CXMimeHeader &mhMimeHeader); /*-*/
		BOOL                bDelete        (ULONG ulMsgID); /*-*/
		BOOL                bDisconnect    (); /*+*/

	private: 
		CXTcpClientSocket   m_scktSocket; 
		std::string         m_sUser; 
		std::string         m_sPass; 
		std::string         m_sServer; 
		USHORT              m_usPort; 

		static const size_t ms_cuiRecvSize = 32768;
		CHAR                m_szRecv[ms_cuiRecvSize + 1];

		INT				    iPop3Recv      (LPSTR pszRecv, INT iRecvSize, INT iFlags); /*+*/
		std::string         sRecvBytes     (); 


		BOOL                bIsError       (const std::string &sText); /*+*/  
		ULONG               ulMailsSum     (const std::string &csServerAnswer); /*+*/
		ULONG               ulMailsSize    (const std::string &csServerAnswer); /*+*/
}; 
//---------------------------------------------------------------------------
#endif 
