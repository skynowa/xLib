/****************************************************************************
* Class name:  CXTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CXTraceLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXTraceLogH
#define CXTraceLogH
//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
//---------------------------------------------------------------------------
class CXTraceLog {
	    _NO_COPY(CXTraceLog);
	
	public:	
			 CXTraceLog();
			~CXTraceLog();
		BOOL bWrite    (LPCSTR pcszFormat, ...); /*+*/
};
//---------------------------------------------------------------------------
#endif
