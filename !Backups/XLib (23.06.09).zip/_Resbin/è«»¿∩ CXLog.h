/****************************************************************************
* Class name:  CXLog
* Description: �����������
* File name:   CXLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 10:24:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <XLib/CXSync/CXCriticalSection.h>
#include <XLib/CXStdioFile.h>
//---------------------------------------------------------------------------
class CXLog {
	public:
					             CXLog             ();
					             CXLog             (const std::string &csFileName, ULONG ulMaxFileSize);
						         CXLog			   (ULONG ulMaxFileSize);
					            ~CXLog             ();

		BOOL                     bLog              (const std::string &csStr);
		BOOL                     bLog              (const std::string &csComment, const std::string &csStr);
		BOOL                     bLog              (const std::string &csComment, INT iValue);
		BOOL                     bLog              (const std::string &csComment, ULONG ulLastError);
					
		VOID                     vLogUCharAsHex    (const std::string &csFileTextDescription, UCHAR *pucFileText, ULONG ulFileTextLen);
        VOID                     vLogUCharAsStr    (const std::string &csFileTextDescription, UCHAR *pucFileText, ULONG ulFileTextLen);
		VOID                     vLogLastErrorStr  (const std::string &csComment, ULONG ulLastError);	
        
		VOID                     vLogToLst         (HWND hLst, const std::string &csStr); 
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, const std::string &csStr); 
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, INT iValue);
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, ULONG ulValue);
		VOID                     vLogLastErrorToLst(HWND hLst, const std::string &csComment, ULONG ulLastError);  

		static VOID              vTrace            (const std::string &csStr); 
		static VOID              vTrace            (const std::string &csComment, const std::string &csStr); 
		static VOID              vTrace            (const std::string &csComment, INT iValue);
		static VOID              vTrace            (const std::string &csComment, ULONG ulValue);
		static VOID              vTraceLastError   (const std::string &csComment, ULONG ulLastError);

		VOID                     vOpen             ();
		VOID                     vClear            ();
		VOID                     vDelete           ();

		static VOID			     vMsgBoxLastError  (const std::string &csComment);
	
	private:
		std::string              m_sLogPath;
		ULONG                    m_ulMaxFileSize;
		
		CXCriticalSection		 m_csLog;	
		CXCriticalSection        m_csLogToLst;  //Mutex

		VOID                     vDeleteLogIfFull  ();
};
//---------------------------------------------------------------------------
#endif