/****************************************************************************
*	CXStatusBar
*
*****************************************************************************/


#include <XLib/CXWinControls/CXStatusBar.h>
//---------------------------------------------------------------------------
CXStatusBar::CXStatusBar() {
	_m_sClassName  = STATUSCLASSNAME;
	m_iDefaultSize = - 1;
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	vStartCommonControls(ICC_BAR_CLASSES);

	_m_hWnd = ::CreateWindowEx(
						dwExStyles, 
						_m_sClassName.c_str(), 
						NULL, 
						WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP | WS_CLIPSIBLINGS | CCS_BOTTOM | dwStyles,
						0, 
						0, 
						0, 
						0, 
						hParent,  
						(HMENU)hmnuID,	
						(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
						NULL); 

	if (_m_hWnd == NULL) {
		return FALSE;
	}

	/*InitCommonControlsO;
	hStatusWindow = CreateStatusWindow(WS_CHILD � WS_VISIBLE,"Menu sample", hWnd, wId);
	if(!hStatusWindow) {
		MessageBox(NULL, "Cannot create status window", "Error", MB_OK);
		retum 0;
	}*/

	SetDefaultFont();		//????
	Subclass();				//????

	return TRUE;
}
//---------------------------------------------------------------------------
void CXStatusBar::SetSimple(BOOL Simple) {
	assert(bIsWindow());
	::SendMessage(_m_hWnd, SB_SIMPLE, (WPARAM)Simple, 0);
}
//---------------------------------------------------------------------------
int CXStatusBar::Height() {
	RECT rect = GetRect();
	
	return rect.bottom - rect.top;
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetMinHeight(int iHeight) {
	assert(bIsWindow());

	return (BOOL)::SendMessage(_m_hWnd, SB_SETMINHEIGHT, (WPARAM)iHeight, (LPARAM)0);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(int nPart, HICON hIcon) {
	assert(bIsWindow());

	return (BOOL)::SendMessage(_m_hWnd, SB_SETICON, (WPARAM)nPart, (LPARAM)hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(int PartIndex, HINSTANCE hInstance, int IdIcon) {
	HICON hIcon = (HICON)::LoadImage(hInstance, MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return SetIcon(PartIndex, hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetText(int PartIndex, TCHAR *PartText) {
	assert(bIsWindow());

	return (BOOL)::SendMessage(_m_hWnd, SB_SETTEXT, PartIndex, (LPARAM)PartText);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetSize(int PartIndex, int Size) {
	assert(bIsWindow());

	if (PartIndex >= m_iNumParts) {
		return FALSE;
	}
	m_iPartsWidths[PartIndex] = Size;

	return (BOOL)::SendMessage(_m_hWnd, SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart() {
	return AddPart(m_iDefaultSize);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText) {
	return AddPart(PartText, m_iDefaultSize);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText, HICON hIcon) {
	return AddPart(PartText, hIcon, m_iDefaultSize);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText, HINSTANCE hInstance, int IdIcon) {
	HICON hIcon = (HICON)::LoadImage(hInstance, MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);
	
	return AddPart(PartText, hIcon);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(int Size) {
	assert(bIsWindow());

	m_iPartsWidths[m_iNumParts] = 0;
	for (int Cnt = 0; Cnt < m_iNumParts; Cnt ++) {
		m_iPartsWidths[m_iNumParts] += m_iPartsWidths[Cnt];
	}
	m_iPartsWidths[m_iNumParts] += Size;
	m_iNumParts ++;
	if (!::SendMessage(_m_hWnd, SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths)) {
		return  - 1;
	}
	
	return m_iNumParts - 1;
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText, int Size) {
	int Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetText(m_iNumParts - 1, PartText);
	
	return Index;
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText, HICON hIcon, int Size) {
	int Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);
	SetText(m_iNumParts - 1, PartText);
	
	return Index;
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(TCHAR *PartText, HINSTANCE hInstance, int IdIcon, int Size) {
	HICON hIcon = (HICON)::LoadImage(hInstance, MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return AddPart(PartText, hIcon, Size);
}
//---------------------------------------------------------------------------
int CXStatusBar::AddPart(HICON hIcon, int Size) {
	int Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);

	return Index;
}
//---------------------------------------------------------------------------