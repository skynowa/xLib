/****************************************************************************
* Class name:  CXDrive
* Description: �������� � �������
* File name:   CXDrive.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:25:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXFso/CXDrive.h>

#include <XLib/CXString.h>
#include <XLib/CXFso/CXPath.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXDrive::CXDrive() {
	//code
}
//---------------------------------------------------------------------------
CXDrive::~CXDrive() {
	//code
}
//---------------------------------------------------------------------------

/****************************************************************************
*	public
*
*****************************************************************************/

//--------------------------------------------------------------------------
//���������� ���������� �����
/*static*/BOOL CXDrive::bIsReady(const std::string &csDrive) {   
	HANDLE          hFile      = INVALID_HANDLE_VALUE; 
	WIN32_FIND_DATA stFindData = {0};   

	hFile = ::FindFirstFile((csDrive + "\\*.*").c_str(), &stFindData);   
	if (INVALID_HANDLE_VALUE == hFile) {   
		return FALSE; 
	} 

	BOOL bRes = FALSE;
	bRes = ::FindClose(hFile); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;   
}
//--------------------------------------------------------------------------
//���������� � ������� �����
/*static*/BOOL CXDrive::bGetFreeSpace(
							   const std::string &csDirPath, 
							   ULONGLONG         *lpFreeBytesAvailableToCaller,
							   ULONGLONG         *lpTotalNumberOfBytes,
							   ULONGLONG         *lpTotalNumberOfFreeBytes) 
{			   
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;
	bRes = ::GetDiskFreeSpaceEx(csDirPath.c_str(), (PULARGE_INTEGER)lpFreeBytesAvailableToCaller, (PULARGE_INTEGER)lpTotalNumberOfBytes, (PULARGE_INTEGER)lpTotalNumberOfFreeBytes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//��� �����
/*static*/CXDrive::EType CXDrive::dtGetType(const std::string &csDrivePath) {
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), dtUnknown);  
	
	return (EType)(::GetDriveType(CXPath::sAddSlash(csDrivePath).c_str()));
	/*DEBUG*///not need
}
//--------------------------------------------------------------------------
//���������� � �����
/*static*/BOOL CXDrive::bGetInformation(const std::string &csDrivePath,
										LPSTR              pszVolumeNameBuffer/*out*/,
										ULONG              ulVolumeNameSize,
										ULONG             *pulVolumeSerialNumber/*out*/,
										ULONG             *pulMaximumComponentLength/*out*/,
										ULONG             *pulFileSystemFlags/*out*/,
										LPSTR              pszFileSystemNameBuffer/*out*/,
										ULONG              ulFileSystemNameSize)
{
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), dtUnknown); 

	BOOL bRes = FALSE; 
	
	bRes = ::GetVolumeInformation(
						csDrivePath.c_str(), 
						pszVolumeNameBuffer, 
						ulVolumeNameSize, 
						pulVolumeSerialNumber, 
						pulMaximumComponentLength, 
						pulFileSystemFlags, 
						pszFileSystemNameBuffer, 
						ulFileSystemNameSize);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------