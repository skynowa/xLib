/****************************************************************************
* Class name:  CXTcpClientSocket
* Description: 
* File name:   CXTcpClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/CXNet/CXTcpClientSocket.h> 

#include <stdio.h>   
#include <iostream> 
#include <XLib/xassert.h>   
//---------------------------------------------------------------------------  
#ifdef WIN32   
#	pragma comment(lib, "wsock32")   
#endif   
//---------------------------------------------------------------------------  
CXTcpClientSocket::CXTcpClientSocket(SOCKET puiSocket) :
	m_puiSocket(INVALID_SOCKET) /*??? SOCKET_ERROR*/
{   
	m_puiSocket = puiSocket;   
}   
//---------------------------------------------------------------------------   
 CXTcpClientSocket::~CXTcpClientSocket() {
 
 }   
//---------------------------------------------------------------------------
//Init winsock DLL 
/*static*/BOOL CXTcpClientSocket::bInit() {  
#ifdef WIN32   
	const USHORT cusVersion     = 2;
	const USHORT cusHighVersion = 2;

	INT     iRes     = SOCKET_ERROR;
	WSADATA wsaData  = {0};
    WORD    wVersion = MAKEWORD(cusVersion, cusHighVersion);   //2.0

	//WSAStartup - [+] returns zero. [-] Otherwise, it returns one of the error codes listed below.
	iRes = ::WSAStartup(wVersion, &wsaData);      
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	//-------------------------------------
	//Confirm that the WinSock DLL supports 2.2.
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */

	if (cusVersion != LOBYTE(wsaData.wVersion) || cusHighVersion != HIBYTE(wsaData.wVersion)) {
		/*Tell the user that we could not find a usable WinSock DLL*/
		bClean(); 	//::WSACleanup();

		return FALSE;
	} 
#endif   

    return TRUE;   
}   
//--------------------------------------------------------------------------- 
//Clean winsock DLL 
/*static*/BOOL CXTcpClientSocket::bClean() { 
#ifdef WIN32
	INT iRes = SOCKET_ERROR;

	//WSACleanup - [+] 0 [-] SOCKET_ERROR
	iRes = ::WSACleanup();
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);
#endif  
 
	return TRUE;  
}   
//--------------------------------------------------------------------------- 
 CXTcpClientSocket& CXTcpClientSocket::operator = (SOCKET puiSocket) {   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != puiSocket, (*this)); //?????????????7
	 m_puiSocket = puiSocket;  

     return *this;   
 }   
//--------------------------------------------------------------------------- 
 CXTcpClientSocket::operator SOCKET () {   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, INVALID_SOCKET);

	 return m_puiSocket;   
 }   
//--------------------------------------------------------------------------- 
 BOOL CXTcpClientSocket::bCreate(INT iAf, INT iType, INT iProtocol) {
     /*DEBUG*/
     
	 //socket - [+] socket returns a descriptor referencing the new socket. [-] INVALID_SOCKET
	 m_puiSocket = ::socket(iAf, iType, iProtocol);   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, FALSE);

     return TRUE;   
 }  
 //---------------------------------------------------------------------------
 BOOL CXTcpClientSocket::bIsReadible() {   
	 timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	 fd_set  fds;        FD_ZERO(&fds);   

	 FD_SET(m_puiSocket, &fds); 

	 INT iStatus = SOCKET_ERROR;

	 iStatus = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	 CHECK_RET(SOCKET_ERROR == iStatus || 0 == iStatus, FALSE);   

	 return TRUE;
 }  
//--------------------------------------------------------------------------- 
BOOL CXTcpClientSocket::bConnect(LPCSTR cpszIp, USHORT usPort) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket,    FALSE);
	/*DEBUG*/XASSERT_RET(NULL           != cpszIp,         FALSE);
    /*DEBUG*/XASSERT_RET(0              <  strlen(cpszIp), FALSE);
    /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	struct sockaddr_in saSockAddr = {0};		   
	saSockAddr.sin_family      = AF_INET; 
	saSockAddr.sin_addr.s_addr = inet_addr(cpszIp);   
	saSockAddr.sin_port        = ::htons(usPort); //???????

	//connect - [+] 0 [-] SOCKET_ERROR
	INT iRes = ::connect(m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(struct sockaddr_in/*saSockAddr*/));  
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;   
}   
//---------------------------------------------------------------------------  
INT CXTcpClientSocket::iSend(LPCSTR pcszBuff, INT iBuffSize, INT iFlags) { 
    /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket,      - 1);
    /*DEBUG*/XASSERT_RET(NULL           != pcszBuff,         - 1);
	/*DEBUG*/XASSERT_RET(0              != strlen(pcszBuff), - 1);

    INT iRes   = - 1;         
    INT iCount = 0;   

    while (iCount < iBuffSize) {   
        //send - [+] total number of bytes sent, which can be less than the number requested to be sent in the len parameter. [-] SOCKET_ERROR
        iRes = ::send(m_puiSocket, pcszBuff + iCount, iBuffSize - iCount, iFlags);
        /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, - 1);  
        /*DEBUG*/XASSERT_RET(0            != iRes, - 1); 
      
        iCount += iRes;   
    }    

    return iCount;   
}   
//---------------------------------------------------------------------------  
 INT CXTcpClientSocket::iRecv(LPSTR pszBuff, INT iBuffSize, INT iFlags) {  
 	 /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, - 1);
     /*DEBUG*/XASSERT_RET(NULL           != pszBuff,     - 1);

	 INT iRes = SOCKET_ERROR;
	 ::ZeroMemory(pszBuff, iBuffSize);	//����� ������� �������� �����
	 
	 //recv - [+] number of bytes received and the buffer pointed to by the buf parameter will contain this data received. [-] SOCKET_ERROR [-] 0 gracefully closed 
	 iRes = ::recv(m_puiSocket, pszBuff, iBuffSize, iFlags);
	 /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, - 1);
	 /*DEBUG*/////XASSERT_RET(0            != iRes, - 1);

	 return iRes;   
 }   
//--------------------------------------------------------------------------- 
BOOL CXTcpClientSocket::bClose() {		
    /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, FALSE);

#ifdef WIN32 
    INT iRes = SOCKET_ERROR;

    //shutdown - [+] 0. [-] SOCKET_ERROR
    iRes = ::shutdown(m_puiSocket, SD_BOTH);	 
    /*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

    //closesocket - [+] zero. [-] SOCKET_ERROR
    iRes = ::closesocket(m_puiSocket); 
    /*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

    m_puiSocket = INVALID_SOCKET;

    return TRUE;
#else   
    return ::close(m_puiSocket);   
#endif   
}   
//---------------------------------------------------------------------------
/*static*/INT CXTcpClientSocket::iGetLastError() {   
#ifdef WIN32   
    return ::WSAGetLastError();   
#else   
    return errno;   
#endif   
}   
//--------------------------------------------------------------------------- 
/*static*/BOOL CXTcpClientSocket::bDnsParse(LPCSTR pcszDomain, LPSTR pszIp) {   
    /*DEBUG*/XASSERT_RET(NULL != pcszDomain,        FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pszIp,             FALSE);
    /*DEBUG*/XASSERT_RET(0    < strlen(pcszDomain), FALSE);

    struct hostent *pHostent = ::gethostbyname(pcszDomain); 
    /*DEBUG*/XASSERT_RET(NULL != pHostent, FALSE);

    ::wsprintf(
                pszIp,
                "%u.%u.%u.%u",   
                (UCHAR)pHostent->h_addr_list[0][0],    
                (UCHAR)pHostent->h_addr_list[0][1],    
                (UCHAR)pHostent->h_addr_list[0][2],    
                (UCHAR)pHostent->h_addr_list[0][3]
    );   

    return TRUE;   
}   
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: SendNBytes
INT iSendNBytes(int nSocket, char *pBuffer, int iMessageLength) {
	INT     iRC         = 0;
	INT     iSendStatus = 0;
	timeval SendTimeout;

	//��������� �������� ��������
	SendTimeout.tv_sec  = 0;
	SendTimeout.tv_usec = _SOCKET_TIMEOUT;              

	fd_set fds;
	FD_ZERO(&fds);
	FD_SET(nSocket, &fds);


	//..�� ��� ���, ���� ��� ����� �������� ������...
	while(iMessageLength > 0) {
		iRC = select(0, NULL, &fds, NULL, &SendTimeout);

		//����� �������, ������� ������
		if(!iRC)
			return -1;

		//��������� ������
		if(iRC < 0)
			return WSAGetLastError();

		//��������� ��������� ����
		iSendStatus = send(nSocket, pBuffer, iMessageLength, 0);   

		//��������� ������ � ������ �������� ������
		if(iSendStatus < 0) {
			return WSAGetLastError();
		} else {
			//�������� ����� � �������
			iMessageLength -= iSendStatus;
			pBuffer += iSendStatus;
		}
	}

	return 0;
}
//---------------------------------------------------------------------------
//TODO: ReceiveNBytes
INT iReceiveNBytes(int nSocket, char *pBuffer, int iStillToReceive) {
	INT     iRC               = 0;
	INT     iReceiveStatus    = 0;
	timeval ReceiveTimeout;

	//��������� �������� ��������
	fd_set fds;
	FD_ZERO(&fds);
	FD_SET(nSocket, &fds);

	ReceiveTimeout.tv_sec  = 0;
	ReceiveTimeout.tv_usec = _SOCKET_TIMEOUT;             // 500 ms

	//..���� ������ �� �������..
	while (iStillToReceive > 0) {
		iRC = select(0, &fds, NULL, NULL, &ReceiveTimeout);

		//����� �� ��������
		if (!iRC)
			return -1;

		//��������� ����� �� ������
		if(iRC < 0)
			return WSAGetLastError();

		//����� ���������� ����
		iReceiveStatus = recv(nSocket, pBuffer, iStillToReceive, 0);

		//��������� ������ � ������ ������� recv()
		if(iReceiveStatus < 0)
		{
			return WSAGetLastError();
		}
		else
		{
			//�������� �������� �������� � �����
			iStillToReceive -= iReceiveStatus;
			pBuffer += iReceiveStatus;
		}
	}

	return 0;
}
//---------------------------------------------------------------------------
