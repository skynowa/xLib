/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/CXNet/CXTcpServerSocket.h> 

#include <stdio.h>   
#include <iostream> 
#include <XLib/xassert.h>   
//---------------------------------------------------------------------------  
#ifdef WIN32   
#	pragma comment(lib, "wsock32")   
#endif   
//---------------------------------------------------------------------------  
CXTcpServerSocket::CXTcpServerSocket(SOCKET puiSocket) :
	m_puiSocket(INVALID_SOCKET) /*??? SOCKET_ERROR*/
{   
	m_puiSocket = puiSocket;   
}   
//---------------------------------------------------------------------------   
 CXTcpServerSocket::~CXTcpServerSocket() {
 
 }   
//---------------------------------------------------------------------------
//Init winsock DLL 
/*static*/BOOL CXTcpServerSocket::bInit() {  
#ifdef WIN32   
	const USHORT cusVersion     = 2;
	const USHORT cusHighVersion = 2;

	INT     iRes     = SOCKET_ERROR;
	WSADATA wsaData  = {0};
    WORD    wVersion = MAKEWORD(cusVersion, cusHighVersion);   //2.0

	//WSAStartup - [+] returns zero. [-] Otherwise, it returns one of the error codes listed below.
	iRes = ::WSAStartup(wVersion, &wsaData);      
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	//-------------------------------------
	//Confirm that the WinSock DLL supports 2.2.
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */

	if (cusVersion != LOBYTE(wsaData.wVersion) || cusHighVersion != HIBYTE(wsaData.wVersion)) {
		/*Tell the user that we could not find a usable WinSock DLL*/
		bClean(); 	//::WSACleanup();

		return FALSE;
	} 
#endif   

    return TRUE;   
}   
//--------------------------------------------------------------------------- 
//Clean winsock DLL 
/*static*/BOOL CXTcpServerSocket::bClean() { 
#ifdef WIN32
	INT iRes = SOCKET_ERROR;

	//WSACleanup - [+] 0 [-] SOCKET_ERROR
	iRes = ::WSACleanup();
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);
#endif  
 
	return TRUE;  
}   
//--------------------------------------------------------------------------- 
 CXTcpServerSocket& CXTcpServerSocket::operator = (SOCKET puiSocket) {   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != puiSocket, (*this)); //?????????????7
	 m_puiSocket = puiSocket;  

     return *this;   
 }   
//--------------------------------------------------------------------------- 
 CXTcpServerSocket::operator SOCKET () {   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, INVALID_SOCKET);

	 return m_puiSocket;   
 }   
//--------------------------------------------------------------------------- 
 BOOL CXTcpServerSocket::bCreate(INT iAf, INT iType, INT iProtocol) {
     /*DEBUG*/
     
	 //socket - [+] socket returns a descriptor referencing the new socket. [-] INVALID_SOCKET
	 m_puiSocket = ::socket(iAf, iType, iProtocol);   
     /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, FALSE);

     return TRUE;   
 }   
 //---------------------------------------------------------------------------
 BOOL CXTcpServerSocket::bIsReadible() {   
	 timeval tvTimeout = {0, 0};   
	 fd_set  fds;        FD_ZERO(&fds);   

	 FD_SET(m_puiSocket, &fds); 

	 INT iStatus = SOCKET_ERROR;

	 iStatus = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	 CHECK_RET(SOCKET_ERROR == iStatus || 0 == iStatus, FALSE);   

	 return TRUE;
 } 
//---------------------------------------------------------------------------
 BOOL CXTcpServerSocket::bBind(USHORT usPort) {   
    /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket,    FALSE);
    /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);	

    struct sockaddr_in saSockAddr = {0};	     
    saSockAddr.sin_family      = AF_INET;   
    saSockAddr.sin_addr.s_addr = INADDR_ANY;   
    saSockAddr.sin_port        = htons(usPort);   
    
    INT iOpt = 1;  
    //???
    if (::setsockopt(m_puiSocket, SOL_SOCKET, SO_REUSEADDR, (LPSTR)&iOpt, sizeof(iOpt)) < 0) {   
        return FALSE;   
    }

    //???
	INT iRes = ::bind(m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(saSockAddr)); 
    /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, FALSE);  

    return TRUE;   
}   
//--------------------------------------------------------------------------- 
 BOOL CXTcpServerSocket::bListen(INT iBacklog) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, FALSE);

	//???
	INT iRes = ::listen(m_puiSocket, iBacklog/*SOMAXCONN*/); 
    /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, FALSE);

    return TRUE;   
}   
//---------------------------------------------------------------------------  
BOOL CXTcpServerSocket::bAccept(CXTcpServerSocket &s, LPSTR pszFromIp) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket,       FALSE);
	/*DEBUG*/XASSERT_RET(NULL           != pszFromIp,         FALSE);
	/*DEBUG*/XASSERT_RET(0               < strlen(pszFromIp), FALSE);

    struct sockaddr_in cliaddr  = {0};   
    INT                iAddrlen = sizeof(cliaddr);

	SOCKET sock = ::accept(m_puiSocket, (struct sockaddr *)&cliaddr, &iAddrlen); 
    /*DEBUG*/     
    if (SOCKET_ERROR == sock) {   
        return FALSE;   
    }   
    
    s = sock;   
	if (NULL != pszFromIp) {  
	    ::wsprintf(pszFromIp, "%s", inet_ntoa(cliaddr.sin_addr));   
	}
    
    return TRUE;   
}   
//---------------------------------------------------------------------------  
INT CXTcpServerSocket::iSend(LPCSTR pcszBuff, INT iBuffSize, INT iFlags) { 
    /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket,      - 1);
    /*DEBUG*/XASSERT_RET(NULL           != pcszBuff,         - 1);
	/*DEBUG*/XASSERT_RET(0              != strlen(pcszBuff), - 1);

    INT iRes   = - 1;         
    INT iCount = 0;   

    while (iCount < iBuffSize) {   
        //send - [+] total number of bytes sent, which can be less than the number requested to be sent in the len parameter. [-] SOCKET_ERROR
        iRes = ::send(m_puiSocket, pcszBuff + iCount, iBuffSize - iCount, iFlags);
        /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, - 1);  
        /*DEBUG*/XASSERT_RET(0            != iRes, - 1); 
      
        iCount += iRes;   
    }    

    return iCount;   
}   
//---------------------------------------------------------------------------  
 INT CXTcpServerSocket::iRecv(LPSTR pszBuff, INT iBuffSize, INT iFlags) {  
 	 /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, - 1);
     /*DEBUG*/XASSERT_RET(NULL           != pszBuff,     - 1);

	 INT iRes = SOCKET_ERROR;
	 ::ZeroMemory(pszBuff, iBuffSize);	//����� ������� �������� �����
	 
	 //recv - [+] number of bytes received and the buffer pointed to by the buf parameter will contain this data received. [-] SOCKET_ERROR [-] 0 gracefully closed 
	 iRes = ::recv(m_puiSocket, pszBuff, iBuffSize, iFlags);
	 /*DEBUG*/XASSERT_RET(SOCKET_ERROR != iRes, - 1);
	 /*DEBUG*/XASSERT_RET(0            != iRes, - 1);

	 return iRes;   
 }   
//--------------------------------------------------------------------------- 
BOOL CXTcpServerSocket::bClose() {		
    /*DEBUG*/XASSERT_RET(INVALID_SOCKET != m_puiSocket, FALSE);

#ifdef WIN32 
    INT iRes = SOCKET_ERROR;

    //shutdown - [+] 0. [-] SOCKET_ERROR
    iRes = ::shutdown(m_puiSocket, SD_BOTH);	 
    /*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

    //closesocket - [+] zero. [-] SOCKET_ERROR
    iRes = ::closesocket(m_puiSocket); 
    /*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

    m_puiSocket = INVALID_SOCKET;

    return TRUE;
#else   
    return ::close(m_puiSocket);   
#endif   
}   
//---------------------------------------------------------------------------
/*static*/INT CXTcpServerSocket::iGetLastError() {   
#ifdef WIN32   
    return ::WSAGetLastError();   
#else   
    return errno;   
#endif   
}   
//--------------------------------------------------------------------------- 
BOOL CXTcpServerSocket::bDnsParse(LPCSTR pcszDomain, LPSTR pszIp) {   
    /*DEBUG*/XASSERT_RET(NULL != pcszDomain,        FALSE);
    /*DEBUG*/XASSERT_RET(NULL != pszIp,             FALSE);
    /*DEBUG*/XASSERT_RET(0    < strlen(pcszDomain), FALSE);

    struct hostent *pHostent = ::gethostbyname(pcszDomain); 
    /*DEBUG*/XASSERT_RET(NULL != pHostent, FALSE);

    ::wsprintf(
                pszIp,
                "%u.%u.%u.%u",   
                (UCHAR)pHostent->h_addr_list[0][0],    
                (UCHAR)pHostent->h_addr_list[0][1],    
                (UCHAR)pHostent->h_addr_list[0][2],    
                (UCHAR)pHostent->h_addr_list[0][3]
    );   

    return TRUE;   
}   
//---------------------------------------------------------------------------
