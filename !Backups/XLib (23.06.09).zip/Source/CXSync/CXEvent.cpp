/****************************************************************************
* Class name:  CXEvent
* Description: ������ � ��������
* File name:   CXEvent.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/CXSync/CXEvent.h>

#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXEvent::CXEvent() 
	: m_hEvent(NULL)
{
	
}
//---------------------------------------------------------------------------
CXEvent::~CXEvent() {
	/*DEBUG*/XASSERT(NULL != m_hEvent);
	
	if (NULL != m_hEvent) {
		BOOL bRes = FALSE;
		
		bRes = ::CloseHandle(m_hEvent);	m_hEvent = NULL; 
		/*DEBUG*/XASSERT(FALSE != bRes);		
	}
}
//---------------------------------------------------------------------------
HANDLE CXEvent::hGetHandle() {
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, NULL);
    
    return m_hEvent;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCSTR pcszName) {
	m_hEvent = ::CreateEvent(lpsaAttributes, bManualReset, bInitialState, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCSTR pcszName) {
	/*DEBUG*/XASSERT(NULL != m_hEvent);		//////////////////
	
	/*EVENT_MODIFY_STATE, EVENT_ALL_ACCESS, EVENT_MODIFY_STATE*/
	m_hEvent = ::OpenEvent(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bPulse() {
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, FALSE);
	
	BOOL bRes = FALSE;

	bRes = ::PulseEvent(m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bReset() {
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, FALSE);

	BOOL bRes = FALSE;

	bRes = ::ResetEvent(m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXEvent::bSet() {
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetEvent(m_hEvent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
ULONG CXEvent::ulWaitForSingleObject(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(NULL != m_hEvent, WAIT_FAILED);

	//WAIT_ABANDONED, WAIT_OBJECT_0, WAIT_TIMEOUT, WAIT_FAILED
    return ::WaitForSingleObject(m_hEvent, ulTimeout);
}
//---------------------------------------------------------------------------