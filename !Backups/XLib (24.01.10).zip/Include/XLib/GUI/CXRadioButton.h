/****************************************************************************
* Class name:  CXRadioButton
* Description: 
* File name:   CXRadioButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXRadioButtonH
#define XLib_Gui_CXRadioButtonH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXRadioButton: public CXWindow {
	public:
			 CXRadioButton();
			~CXRadioButton();
			
	   BOOL bCreateRes(INT iID, HWND hParent);

		BOOL bIsChecked   ();
		BOOL bCheck       (BOOL bChecked);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXRadioButtonH