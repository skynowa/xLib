/****************************************************************************
* Class name:  -
* Description: ����� ��������� 
* File name:   XMessageMap.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     31.08.2009 16:44:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_XMessageMapH
#define XLib_Gui_XMessageMapH
//---------------------------------------------------------------------------
#include <XLib/GUI/Common.h>
//---------------------------------------------------------------------------
#define X_DECLARE_MSG_MAP() \
				virtual LRESULT lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam); 

#define X_BEGIN_MSG_MAP_NO_DECLARE() \
				virtual LRESULT lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	

#define X_BEGIN_MSG_MAP(ClassName) \
				LRESULT ClassName::lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	

#define X_MSG(msg, func)					\
				if (uiMsg == msg) {			\
					func(wParam, lParam);	\
					return FALSE;           \
				}

#define X_CMD(id, func)                                                         \
				if ((uiMsg == WM_COMMAND) && (id == LOWORD(wParam))) {			\
					/*LOG*/_m_tlLog.bWrite(_T("X_CMD:  %i, %i"), wParam, lParam);	\
																				\
					func(LOWORD(wParam), lParam);								\
					return FALSE;												\
				}

#define X_END_MSG_MAP(theParentClass)                                               \
					return theParentClass::lpProcessMessage(uiMsg, wParam, lParam); \
				};

#define X_END_MSG_MAP_NOPARENT    \
					return FALSE; \
				};
//---------------------------------------------------------------------------
#endif //XLib_Gui_XMessageMapH