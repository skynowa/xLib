/****************************************************************************
* Class name:  CXTls
* Description: ��������� ������ ������
* File name:   CXTls.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.01.2010 14:42:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLib_Sync_CXTlsH
#define CXLib_Sync_CXTlsH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXTls : public CXNonCopyable {
	public:
		CXTls();
	   ~CXTls();
	   
		BOOL  bAlloc    ();
		BOOL  bFree     (); 
		VOID *pvGetValue(); 
		BOOL  bSetValue (VOID *pvValue);
	   
	private:
		ULONG _m_ulIndex;
};
//---------------------------------------------------------------------------
#endif	//CXLib_Sync_CXTlsH
