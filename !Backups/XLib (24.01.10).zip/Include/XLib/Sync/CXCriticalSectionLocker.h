/****************************************************************************
* Class name:  CXCriticalSectionLocker
* Description: ������ � ������������ �������� � �����
* File name:   CXCriticalSectionLocker.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXCriticalSectionLockerH
#define XLib_Sync_CXCriticalSectionLockerH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXCriticalSectionLocker : public CXNonCopyable {
	public:
						   CXCriticalSectionLocker(CXCriticalSection &csCS);
						   CXCriticalSectionLocker(CXCriticalSection &csCS, BOOL bTry);
   					      ~CXCriticalSectionLocker();

	private:
		CXCriticalSection &_m_csCS;
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXCriticalSectionLockerH