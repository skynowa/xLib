/****************************************************************************
* Class name:  CXEvent
* Description: ������
* File name:   CXEvent.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXEventH
#define XLib_Sync_CXEventH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXHandleT.h>
//---------------------------------------------------------------------------
class CXEvent : public CXNonCopyable {
	public:
               CXEvent    ();
			  ~CXEvent    ();
			  
        HANDLE hGetHandle () const ;
		BOOL   bCreate    (PSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCTSTR pcszName);
		BOOL   bOpen      (ULONG ulAccess, BOOL bInheritHandle, LPCTSTR lpcszName);
		BOOL   bPulse     () const;
		BOOL   bReset     () const;
		BOOL   bSet       () const;
		BOOL   bWait      (ULONG ulTimeout) const;

		BOOL   bIsSignaled() const; 
		//BOOL bIsExists  () const; 

	private:
		CXHandleT<NULL> _m_hEvent; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXEventH