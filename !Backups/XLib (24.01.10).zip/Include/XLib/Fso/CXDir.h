/****************************************************************************
* Class name:  CXDir
* Description: �������� � �������
* File name:   CXDir.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Fso_CXDirH
#define XLib_Fso_CXDirH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <vector>
//---------------------------------------------------------------------------
class CXDir {
	public:
								   	CXDir        ();
								   ~CXDir        ();
									   
		static BOOL                 bIsExists    (const tstring &csDirPath); 
		static BOOL                 bIsEmpty     (const tstring &csDirPath, const tstring &csMask); 
		static tstring              sGetCurrent  ();  
		static BOOL                 bSetCurrent  (const tstring &csDirPath); 
		static tstring              sGetTempPath (); 
		static BOOL                 bCreate      (const tstring &csDirPath); 
		static VOID                 vForceCreate (const tstring &csDirPath); 
		static BOOL                 bCopy        (const tstring &csDirPathFrom, const tstring &cscsDirPathTo, BOOL bFailIfExists); 
		static BOOL                 bDelete      (const tstring &csDirPath); 
		static BOOL                 bForceClear  (const tstring &csDirPath); 
		static BOOL                 bForceDelete (const tstring &csDirPath); 
		static std::vector<tstring> vecsListFiles(const tstring &csDirPath, const tstring &csMask); 
		static std::vector<tstring> vecsListDirs (const tstring &csDirPath); 
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXDirH
