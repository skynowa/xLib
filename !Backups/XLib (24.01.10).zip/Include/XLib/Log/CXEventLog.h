/****************************************************************************
* Class name:  CXEventLog
* Description: ����������� ����� "Event Log"
* File name:   CXEventLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:52:35
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CXEventLogH
#define XLib_Log_CXEventLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXEventLog : public CXNonCopyable {
	public:
		CXEventLog();
	   ~CXEventLog();

	private:
};
//---------------------------------------------------------------------------
#endif	//XLib_Log_CXEventLogH
