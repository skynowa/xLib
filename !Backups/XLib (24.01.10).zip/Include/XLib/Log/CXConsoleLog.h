/****************************************************************************
* Class name:  CXConsoleLog
* Description: ����������� ����� �������
* File name:   CXConsoleLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:53:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CXConsoleLogH
#define XLib_Log_CXConsoleLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXConsoleLog : public CXNonCopyable {
	public:	
		                         CXConsoleLog();
		                        ~CXConsoleLog();
		BOOL                     bWrite      (LPCTSTR pcszFormat, ...); 
		
	private:		
		static CXCriticalSection _ms_csConsole;  
};
//---------------------------------------------------------------------------
#endif	//XLib_Log_CXConsoleLogH
