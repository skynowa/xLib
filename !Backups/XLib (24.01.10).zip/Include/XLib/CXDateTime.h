/****************************************************************************
* Class name:  CXDateTime
* Description: ������ � ������
* File name:   CXDateTime.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     12.06.2009 15:37:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CXDateTimeH
#define XLib_CXDateTimeH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXDateTime : public CXNonCopyable {
	public:
				           CXDateTime        (); 
				           CXDateTime        (ULONGLONG ullDateTime); 
						   CXDateTime        (USHORT usYear, USHORT usMonth, USHORT usDay, USHORT usHour, USHORT usMinute, USHORT usSecond, USHORT usMilliseconds); 
				          ~CXDateTime        (); 
				          
	    CXDateTime         dtNow             (); 
		
		//��������������
		tstring			   sFormatDateTimeStr(); 
		tstring            sFormatDateStr    (); 
		tstring            sFormatTimeStr    (); 

		static BOOL        bMSecToDateTime   (ULONGLONG ullMilliSec, SYSTEMTIME *stST); 
		static ULONGLONG   ullDateTimeToMSec (const SYSTEMTIME &stST); 

		//-------------------------------------
		//���������
		CXDateTime        &operator =        (CXDateTime dtDT);
		CXDateTime         operator +        (CXDateTime dtDT);
		CXDateTime         operator -        (CXDateTime dtDT);
		//++
		//--
		//+=
		//-=
		//

   	private:
   		SYSTEMTIME         _m_stDateTime;
		ULONGLONG          _m_ullDateTime;
};
//---------------------------------------------------------------------------
#endif	//XLib_CXDateTimeH

/*
typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
*/





//GetTimeFormatEx
//GetDateFormat