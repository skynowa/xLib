#ifndef FILENAME_H
#define FILENAME_H

/* Copyright (c) 2004-2007 Alex Martynov, amart at mail dot ru

// define FILENAME_IN_MARTY_NAMESPACE for use ::marty::filename::* insted of ::filename::*
// also you can define MARTY_NAMESPACE macro, which automaticaly define FILENAME_IN_MARTY_NAMESPACE
// define FILENAME_OLD_NAMES for use old short names
// define FILENAME_USE_TEST for use included test cases 
// define FILENAME_USING_TSTRING for use filename::tstring in global namespace
// define FILENAME_PRINT_ALL_TESTS for output all tests results, not only failed
// define FILENAME_COMPARISON_ALWAYS_USE_LOCALE if you want unified unterface for 
   // equal, less, lessEqual, greater, greaterEqual, compareTo functions


// Module interface small description

namespace filename
{

#ifdef _WIN32
namespace localeAux
{

// wrapper for GetLocaleInfo
tstring getLocaleInfo(LCID lcid, LCTYPE lctype);
// return CRT compatible locale name
tstring getLocaleCrtName(LCID lcid, bool getOemLocale);

}; // namespace localeAux
#endif


// create CRT locale object for file names comparison (LOCALE_SYSTEM_DEFAULT locale used)
::std::locale makeCurrentLocale(bool getOemLocale = false);

// case conversion wich uses C++ locale object
tstring upperCase(const tstring &str, const ::std::locale &loc = ::filename::utils::makeCurrentLocale());
tstring lowerCase(const tstring &str, const std::locale &loc = ::filename::utils::makeCurrentLocale());

// typedefs makes shorter aliases
typedef tstring::size_type pos_type_t;
typedef ::std::pair<pos_type_t, pos_type_t> pos_pair_t;

typedef tstring::iterator               iter_t;
typedef tstring::const_iterator         const_iter_t;

typedef ::std::pair<iter_t, iter_t>               iter_pair_t;
typedef ::std::pair<const_iter_t, const_iter_t>   const_iter_pair_t;

// predicates for testing chars in file names
struct  isPathSeparator;
typedef isPathSeparator isExtSeparator;

struct defaultIsPathSeparator : isPathSeparator(PATH_SEPARATORS);
struct defaultIsExtSeparator  : isExtSeparator(PATH_EXT_SEPARATOR_STR);


////////////////////////
// filename functions //
////////////////////////

//-----------------------------------------------------------------------------
// iterator version of splitFilename
template <typename Iter, typename pathPred, typename extPred>
void splitFilename(::std::pair<Iter, Iter> pair, // fullName
                   ::std::pair<Iter, Iter> &pathPair,
                   ::std::pair<Iter, Iter> &namePair,
                   ::std::pair<Iter, Iter> &extPair,
                   pathPred pPath, extPred pExt);

// string version of splitFilename
void splitFilename(const tstring &fullName,
                   tstring &path,
                   tstring &name,
                   tstring &ext,
                   const TCHAR* pathSeparators = PATH_SEPARATORS,
                   const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);

//-----------------------------------------------------------------------------
// iterator version of splitPath
template <typename Iter, typename pathPred>
void splitPath(::std::pair<Iter, Iter> path, 
               ::std::vector<::std::pair<Iter, Iter> > &parts,
               pathPred pred);

// string version of splitPath
void splitPath(const tstring &path, ::std::vector<tstring> &pathParts,
               const TCHAR* pathSeparators = PATH_SEPARATORS);

//-----------------------------------------------------------------------------
// iterator version of getPath
template <typename Iter, typename Pred>
::std::pair<Iter, Iter> getPath(::std::pair<Iter, Iter> pair, Pred pred);

// string version of getPath
tstring getPath(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS);

//-----------------------------------------------------------------------------
// obsolete string version of getPath. Be carefully, path function return path string 
// with removed trailing slash, but getPath returns path with trailing slash
tstring path(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS);

// string functions based on splitFilename
// return name + ext
tstring getFile(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS);
// obsolete
tstring file(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS);
// return ext
tstring getExtention( const tstring &fullName, 
                      const TCHAR* pathSeparators = PATH_SEPARATORS, 
                      const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);
// obsolete
tstring extention( const tstring &fullName, 
                   const TCHAR* pathSeparators = PATH_SEPARATORS, 
                   const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);
// return name only
tstring getName( const tstring &fullName, 
                 const TCHAR* pathSeparators = PATH_SEPARATORS, 
                 const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);
// return path and name without ext
tstring getPathName( const tstring &fullName, 
                 const TCHAR* pathSeparators = PATH_SEPARATORS, 
                 const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);

// obsolete, works like getPathName, not like getFile
tstring name( const tstring &fullName, 
              const TCHAR* pathSeparators = PATH_SEPARATORS, 
              const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR);

// concatenates paths, check first part has trailing slash
tstring appendPath(const tstring &path, const tstring &pathAppend,
                   const TCHAR* pathSeparators = PATH_SEPARATORS,
                   TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

// appends extention, checks that ext has leading dot and add it if not exist
tstring appendExtention(const tstring &name, const tstring &ext,
                        const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                        TCHAR extSeparator = PATH_EXT_SEPARATOR)

// utility functions
void pathRemoveTrailingSlashInplace(tstring &path, const TCHAR* pathSeparators = PATH_SEPARATORS);
tstring pathRemoveTrailingSlash(const tstring &path, const TCHAR* pathSeparators = PATH_SEPARATORS);


template <typename Iter>
tstring mergeFilename(::std::pair<Iter, Iter> pathPair,
                      ::std::pair<Iter, Iter> namePair,
                      ::std::pair<Iter, Iter> extPair,
                      const TCHAR* pathSeparators = PATH_SEPARATORS,
                      TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR,
                      const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                      TCHAR extSeparator = PATH_EXT_SEPARATOR);

tstring mergeFilename( const tstring &path,
                       const tstring &name,
                       const tstring &ext,
                       const TCHAR* pathSeparators = PATH_SEPARATORS,
                       TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR,
                       const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                       TCHAR extSeparator = PATH_EXT_SEPARATOR);

tstring changeExtention( const tstring &fullName, 
                         const tstring &newExt,
                         const TCHAR* pathSeparators = PATH_SEPARATORS,
                         const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                         TCHAR extSeparator = PATH_EXT_SEPARATOR);

template <typename Iter, typename Pred>
bool isUncAbsolutePath(::std::pair<Iter, Iter> name, Pred pred);

bool isUncAbsolutePath(const tstring &fullName, 
                       const TCHAR* pathSeparators = PATH_SEPARATORS);

template <typename Iter> 
bool isDriveAbsolutePath(::std::pair<Iter, Iter> name);

template <typename Iter, typename Pred> 
bool isDriveAbsolutePath(::std::pair<Iter, Iter> name, Pred pred);

bool isDriveAbsolutePath(const tstring &fullName, 
                         const TCHAR* pathSeparators = PATH_SEPARATORS);

template <typename Iter, typename Pred> 
bool isUnixAbsolutePath(::std::pair<Iter, Iter> name, Pred pred);

bool isUnixAbsolutePath(const tstring &fullName, 
                        const TCHAR* pathSeparators = PATH_SEPARATORS);

template <typename Iter, typename Pred> 
bool isAbsolutePath(::std::pair<Iter, Iter> name, Pred pred);

bool isAbsolutePath(const tstring &fullName, 
                    const TCHAR* pathSeparators = PATH_SEPARATORS);

tstring makeFullPath(const tstring &basePath, const tstring &relPath,
                     const TCHAR*  pathSeparators = PATH_SEPARATORS,
                     TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );


namespace util
{

template <typename Iter>
bool equaiPairs( ::std::pair<Iter, Iter> p1, ::std::pair<Iter, Iter> p2);

template <typename Iter>
bool equaiToPair( const tstring &str, ::std::pair<Iter, Iter> p);

}; // namespace util


template <typename Iter>
bool isCurrentDirectorySpecialName(::std::pair<Iter, Iter> dirNamePair );

bool isCurrentDirectorySpecialName(const tstring& dirName );

template <typename Iter>
bool isUpperDirectorySpecialName(::std::pair<Iter, Iter> dirNamePair );

bool isUpperDirectorySpecialName(const tstring& dirName );


// makeCanonical removes all '.' and '..' directories from path
template <typename Iter, typename Pred>
void makeCanonical(const ::std::vector<::std::pair<Iter, Iter> > &srcPathParts,
                   Pred pathPred,
                   ::std::vector<::std::pair<Iter, Iter> > &resVec);
// string version of makeCanonical also change 
// all path separator chars to preffered char in target system
tstring makeCanonical(const tstring &path, 
                      const TCHAR* pathSeparators,
                      TCHAR pathPrefferedSeparator);

tstring makeCanonical(const tstring &path);

// obsolete
bool isDotDirectory ( const tstring& dir )
// obsolete
tstring canonical(const tstring &filename,
                  const TCHAR*  pathSeparators = PATH_SEPARATORS,
                  TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );


bool equal( const tstring &name1, const tstring &name2,
            #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
            const ::std::locale &loc = ::filename::makeCurrentLocale(),
            #endif
            const TCHAR* pathSeparators = PATH_SEPARATORS,
            TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

bool less( const tstring &name1, const tstring &name2,
           #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
           const ::std::locale &loc = ::filename::makeCurrentLocale(),
           #endif
           const TCHAR*  pathSeparators = PATH_SEPARATORS,
           TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

bool lessEqual( const tstring &name1, const tstring &name2,
                #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                const ::std::locale &loc = ::filename::makeCurrentLocale(),
                #endif
                const TCHAR* pathSeparators = PATH_SEPARATORS,
                TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

bool greater( const tstring &name1, const tstring &name2,
              #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
              const ::std::locale &loc = ::filename::makeCurrentLocale(),
              #endif
              const TCHAR* pathSeparators = PATH_SEPARATORS,
              TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

bool greaterEqual( const tstring &name1, const tstring &name2,
                   #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                   const ::std::locale &loc = ::filename::makeCurrentLocale(),
                   #endif
                   const TCHAR* pathSeparators = PATH_SEPARATORS,
                   TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR );

struct compareTo;


// iterator version
template <typename Iter, typename ChangeCase>
bool matchMask(::std::pair<Iter, Iter> name, 
               ::std::pair<Iter, Iter> mask,
               const ChangeCase &changeCase
              );
// exactly mach - no char case conversions
bool matchMaskE(const tstring &name, const tstring &mask);
// case independent mach
bool matchMaskI(const tstring &name, const tstring &mask, 
                ::std::locale &loc = ::filename::utils::makeCurrentLocale());
// mach using OS rules (Win32 - case insens, *nix - case exact )
bool matchMask(const tstring &name, const tstring &mask);

}; // namespace filename

*/


#ifdef MARTY_NAMESPACE
    #ifndef FILENAME_IN_MARTY_NAMESPACE
        #define FILENAME_IN_MARTY_NAMESPACE
    #endif
#endif



//-----------------------------------------------------------------------------
#ifdef __BORLANDC__
    #define __USELOCALES__
#endif

//-----------------------------------------------------------------------------
#ifdef _UNICODE
    #ifndef UNICODE
        #define UNICODE
    #endif /* UNICODE */
#endif /* _UNICODE */

#ifdef UNICODE
    #ifndef _UNICODE
        #define _UNICODE
    #endif /* _UNICODE */
#endif /* UNICODE */

//-----------------------------------------------------------------------------
/* std/stl headers */

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_LOCALE_) && !defined(_STLP_LOCALE) && !defined(__STD_LOCALE__) && !defined(_CPP_LOCALE) && !defined(_GLIBCXX_LOCALE)
    #include <locale>
#endif

#ifdef FILENAME_USE_TEST
    #if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
        #include <iostream>
    #endif

    #ifdef _UNICODE
        #define tcout ::std::wcout
    #else
        #define tcout ::std::cout
    #endif /* _UNICODE */
#endif /* FILENAME_USE_TEST */

//-----------------------------------------------------------------------------
/* platform headers */

#ifdef _WIN32
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

    #include <winnls.h>

    #if !defined(_INC_TCHAR) && !defined(__TCHAR_H)    
        #include <tchar.h>
    #endif
#endif

//-----------------------------------------------------------------------------
#ifndef _TCHAR_DEFINED
    #define _TCHAR_DEFINED
    #ifdef _UNICODE
        typedef wchar_t TCHAR;
    #else
        typedef char    TCHAR;
    #endif /* _UNICODE*/
#endif /* _TCHAR_DEFINED*/

//-----------------------------------------------------------------------------
#ifndef _T
    #ifdef _UNICODE
        #define _T(str) L##str
    #else
        #define _T(str) str
    #endif /* _UNICODE*/
#endif /* _T */


//-----------------------------------------------------------------------------
#ifdef FILENAME_IN_MARTY_NAMESPACE
namespace marty {
#endif
namespace filename
{
#ifndef __FILENAME_TSTRING_DEFINED__
#define __FILENAME_TSTRING_DEFINED__
typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;
#endif 
}; // namespace filename
#ifdef FILENAME_IN_MARTY_NAMESPACE
}; // namespace marty
#endif



#ifdef FILENAME_USING_TSTRING
    #ifdef FILENAME_IN_MARTY_NAMESPACE
    using ::marty::filename::tstring;
    #else
    using ::filename::tstring;
    #endif
#endif



//-----------------------------------------------------------------------------
#if defined(_WIN32)
    #define PATH_SEPARATORS                _T("\\/")
    #define PATH_PREFFERED_SEPARATOR_STR   _T("\\")
    #define PATH_PREFFERED_SEPARATOR       _T('\\')
    #define PATH_EXT_SEPARATOR_STR         _T(".")
    #define PATH_EXT_SEPARATOR             _T('.')
#else
    #define PATH_SEPARATORS                _T("/")
    #define PATH_PREFFERED_SEPARATOR_STR   _T("/")
    #define PATH_PREFFERED_SEPARATOR       _T('/')
    #define PATH_EXT_SEPARATOR_STR         _T(".")
    #define PATH_EXT_SEPARATOR             _T('.')
#endif

//-----------------------------------------------------------------------------
/*
#ifndef ISNPOS
    #define ISNPOS(pos)                          (pos==tstring::npos)
#endif
*/
#define NSFN_ISALPHAAUX(ch, alphaMin, alphaMax)   ((ch)>=(alphaMin) && (ch)<=(alphaMax))
#define NSFN_ISUPPERALPHA(ch)                     NSFN_ISALPHAAUX(ch, _T('A'), _T('Z'))
#define NSFN_ISLOWERALPHA(ch)                     NSFN_ISALPHAAUX(ch, _T('a'), _T('z'))
#define NSFN_ISALPHA(ch)                          (NSFN_ISUPPERALPHA(ch) || NSFN_ISLOWERALPHA(ch))





//-----------------------------------------------------------------------------

#ifdef FILENAME_IN_MARTY_NAMESPACE
namespace marty {
#endif

namespace filename
{
namespace utils
{

// sync C++ locale with system
#ifdef _WIN32
namespace localeAux
{

//-----------------------------------------------------------------------------
inline
tstring getLocaleInfo(LCID lcid, LCTYPE lctype)
   {
    TCHAR buf[128];
    buf[ GetLocaleInfo(lcid, lctype, buf, sizeof(buf)/sizeof(buf[0])-1) ] = 0;
    return tstring(buf);
   }

//-----------------------------------------------------------------------------
inline 
tstring getLocaleCrtName(LCID lcid, bool getOemLocale)
   {
    tstring res = getLocaleInfo(lcid, LOCALE_SENGLANGUAGE);
    
    if (res.empty()) return tstring(_T("C"));

    tstring country = getLocaleInfo(lcid, LOCALE_SENGCOUNTRY);
    if (!country.empty())
       {
        res.append(_T("_"));
        res.append(country);
       }

    tstring cpName = getLocaleInfo(lcid, getOemLocale ? LOCALE_IDEFAULTCODEPAGE : LOCALE_IDEFAULTANSICODEPAGE);
    if (!cpName.empty())
       {
        res.append(_T("."));
        res.append(cpName);
       }

    return res;
   }

}; // namespace localeAux

#endif
//-----------------------------------------------------------------------------
::std::locale makeCurrentLocale(bool getOemLocale = false)
   {
    #ifdef _WIN32
    //return ::std::locale(localeAux::getLocaleCrtName(GetThreadLocale(), getOemLocale).c_str());
    //return ::std::locale(localeAux::getLocaleCrtName(LOCALE_USER_DEFAULT, getOemLocale).c_str());
    return ::std::locale(localeAux::getLocaleCrtName(LOCALE_SYSTEM_DEFAULT, getOemLocale).c_str());
    #else
    #error "Keeping in sync system and C++ locales are not supported on this target or not needed"
    return ::std::locale::global();
    #endif
   }

//-----------------------------------------------------------------------------


// 1) in BCC 5.6 (BCB 6) we need to undef folowing macroses 
#ifdef __BORLANDC__
    #ifdef toupper
        #undef toupper
    #endif
    
    #ifdef tolower
        #undef tolower
    #endif
#endif

// 2) There is a bug in BCC 5.5 runtime - 
// lowercase char 'ya' (255) case not changed to 'YA' (159) in ANSI codepage
// workaround is to always use lowercase strings in path names comparison

struct uppercaseChar
{
    private:
        const ::std::locale &loc;
        uppercaseChar& operator=(const uppercaseChar&) { return *this; }
    public:
        uppercaseChar(const ::std::locale &loc) : loc(loc) {}
        TCHAR operator()(TCHAR c) const
           {
            #ifdef __BORLANDC__
            return ::std::toupper(c); 
            #else
            return ::std::toupper(c, loc); 
            #endif
           }
};

struct lowercaseChar
{
    private:
        const ::std::locale &loc;
        lowercaseChar& operator=(const lowercaseChar&) { return *this; }
    public:
        lowercaseChar(const ::std::locale &loc) : loc(loc) {}
        TCHAR operator()(TCHAR c) const
           { 
            #ifdef __BORLANDC__
            return ::std::tolower(c); 
            #else
            return ::std::tolower(c, loc); 
            #endif
           }
};

struct keepcaseChar
{
    private:
        keepcaseChar& operator=(const keepcaseChar&) { return *this; }
    public:
        keepcaseChar() {}
        TCHAR operator()(TCHAR c) const { return c; }
};


inline
tstring upperCase(const tstring &str, const ::std::locale &loc = ::filename::utils::makeCurrentLocale())
   {
    tstring res(str);
    ::std::transform(res.begin(), res.end(), res.begin(), uppercaseChar(loc));
    return res;
   }

inline
tstring lowerCase(const tstring &str, const std::locale &loc = ::filename::utils::makeCurrentLocale())
   {
    tstring res(str);
    ::std::transform(res.begin(), res.end(), res.begin(), lowercaseChar(loc));
    return res;
   }

}; // namespace utils

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
// used for testing false and true results
struct genericTestCaseResStruct
{
    TCHAR *inputVal;
    TCHAR *checkVal;
    bool   res;
};

//-----------------------------------------------------------------------------
// used for truth cases
struct genericTestCaseStruct
{
    TCHAR *inputVal;
    TCHAR *checkVal;
};

typedef genericTestCaseStruct genericTestCaseStruct1;
typedef tstring (*strfn1_t)( const tstring & );

struct genericTestCaseStruct2
{
    TCHAR *inputVal1;
    TCHAR *inputVal2;
    TCHAR *checkVal;
};

typedef tstring (*strfn2_t)( const tstring &, const tstring & );

struct genericTestCaseStruct3
{
    TCHAR *inputVal1;
    TCHAR *inputVal2;
    TCHAR *inputVal3;
    TCHAR *checkVal;
};

typedef tstring (*strfn3_t)( const tstring &, const tstring &, const tstring & );


//-----------------------------------------------------------------------------
template<typename TestFn>
int genericTestSuite(
                     const genericTestCaseResStruct *pTestData,
                     int *pTotalTests, /* pointer to var that incremented with total num of tests */
                     const TCHAR* testName,
                     TestFn fn
                    )
   {
    int failedTests = 0;
    int i = 0;
    for(; pTestData && pTestData->inputVal; ++i, ++pTestData)
       {
        if (!fn(tstring(pTestData->inputVal), tstring(pTestData->checkVal), pTestData->res))
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" failed\n");
            ++failedTests;
           }
        #ifdef FILENAME_PRINT_ALL_TESTS
        else
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" passed\n");
           }
        #endif
       }

    if (pTotalTests)
       *pTotalTests += i;

    tcout<<testName<<_T(": total tests - ")<<i<<_T(", failed tests - ")<<failedTests<<_T("\n---\n");

    return failedTests;
   }

//-----------------------------------------------------------------------------
//template<typename TestFn>
int genericTestSuite(
                     const genericTestCaseStruct *pTestData,
                     int *pTotalTests, /* pointer to var that incremented with total num of tests */
                     const TCHAR* testName,
                     strfn1_t fn
                    )
   {
    int failedTests = 0;
    int i = 0;
    for(; pTestData && pTestData->inputVal; ++i, ++pTestData)
       {
        tstring strRes = fn(tstring(pTestData->inputVal));
        if (strRes != tstring(pTestData->checkVal))
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" failed, result: ")<<strRes<<_T(", awaited res: ")<<pTestData->checkVal<<_T("\n");
            ++failedTests;
           }
        #ifdef FILENAME_PRINT_ALL_TESTS
        else
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" passed\n");
           }
        #endif
       }

    if (pTotalTests)
       *pTotalTests += i;

    tcout<<testName<<_T(": total tests - ")<<i<<_T(", failed tests - ")<<failedTests<<_T("\n---\n");

    return failedTests;
   }

//-----------------------------------------------------------------------------
//template<typename TestFn>
int genericTestSuite(
                     const genericTestCaseStruct2 *pTestData,
                     int *pTotalTests, /* pointer to var that incremented with total num of tests */
                     const TCHAR* testName,
                     strfn2_t fn
                    )
   {
    int failedTests = 0;
    int i = 0;
    for(; pTestData && pTestData->inputVal1; ++i, ++pTestData)
       {
        tstring strRes = fn(tstring(pTestData->inputVal1), tstring(pTestData->inputVal2));
        if (strRes != tstring(pTestData->checkVal))
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" failed, result: ")<<strRes<<_T(", awaited res: ")<<pTestData->checkVal<<_T("\n");
            ++failedTests;
           }
        #ifdef FILENAME_PRINT_ALL_TESTS
        else
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" passed\n");
           }
        #endif
       }

    if (pTotalTests)
       *pTotalTests += i;

    tcout<<testName<<_T(": total tests - ")<<i<<_T(", failed tests - ")<<failedTests<<_T("\n---\n");

    return failedTests;
   }

//-----------------------------------------------------------------------------
//template<typename TestFn>
int genericTestSuite(
                     const genericTestCaseStruct3 *pTestData,
                     int *pTotalTests, /* pointer to var that incremented with total num of tests */
                     const TCHAR* testName,
                     strfn3_t fn
                    )
   {
    int failedTests = 0;
    int i = 0;
    for(; pTestData && pTestData->inputVal1; ++i, ++pTestData)
       {
        tstring strRes = fn(tstring(pTestData->inputVal1), tstring(pTestData->inputVal2), tstring(pTestData->inputVal3));
        if (strRes != tstring(pTestData->checkVal))
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" failed, result: ")<<strRes<<_T(", awaited res: ")<<pTestData->checkVal<<_T("\n");
            ++failedTests;
           }
        #ifdef FILENAME_PRINT_ALL_TESTS
        else
           {
            tcout<<_T("Test ")<<testName<<_T(":")<<i+1<<_T(" passed\n");
           }
        #endif
       }

    if (pTotalTests)
       *pTotalTests += i;

    tcout<<testName<<_T(": total tests - ")<<i<<_T(", failed tests - ")<<failedTests<<_T("\n---\n");

    return failedTests;
   }

//-----------------------------------------------------------------------------
}; // namespace test


#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

typedef tstring::size_type pos_type_t;
typedef ::std::pair<pos_type_t, pos_type_t> pos_pair_t;

typedef tstring::iterator               iter_t;
typedef tstring::const_iterator         const_iter_t;

typedef ::std::pair<iter_t, iter_t>               iter_pair_t;
typedef ::std::pair<const_iter_t, const_iter_t>   const_iter_pair_t;

//-----------------------------------------------------------------------------
struct isPathSeparator
{
    /* private:
     *     const tstring &sepList;
     *     isPathSeparator& operator=(const isPathSeparator & ips) { ips; return *this; }
     *  
     * public:
     *     isPathSeparator(const tstring &s) : sepList(s) {}
     *     bool operator()(TCHAR c) { return ISNPOS(sepList.find( c, 0)) ? false : true; }
     */
    private:
        const TCHAR *sepList;
    public:
        isPathSeparator(const TCHAR *s) : sepList(s) {}
        bool operator()(TCHAR c)
           {
            for(const TCHAR *p = sepList; *p; ++p) if (*p==c) return true;
            return false;
           }
};

typedef isPathSeparator isExtSeparator;

//-----------------------------------------------------------------------------
/*
struct defaultIsPathSeparator : public isPathSeparator
{
        defaultIsPathSeparator() : isPathSeparator(PATH_SEPARATORS) {} 
        // bug here - tsring is temporary object, and we store reference to it
        defaultIsPathSeparator(const defaultIsPathSeparator &s) : isPathSeparator(s) {}

};

//-----------------------------------------------------------------------------
struct defaultIsExtSeparator : public isExtSeparator
{
        defaultIsExtSeparator() : isExtSeparator(PATH_EXT_SEPARATOR_STR) {}
        defaultIsExtSeparator(const defaultIsExtSeparator &s) : isExtSeparator(s) {}
};
*/

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

template <typename Iter, typename pathPred, typename extPred>
void splitFilename(::std::pair<Iter, Iter> pair, // fullName
                   ::std::pair<Iter, Iter> &pathPair,
                   ::std::pair<Iter, Iter> &namePair,
                   ::std::pair<Iter, Iter> &extPair,
                   pathPred pPath, extPred pExt)
   {
    Iter it               = pair.first;
    Iter lastFoundPathSep = pair.first;
    Iter foundExtSep      = pair.first;

    for(; it!=pair.second; ++it)
       {
        if (pPath(*it))
           { // found path separator
            lastFoundPathSep = it; ++lastFoundPathSep;
            foundExtSep      = pair.first;
           }
        else if (pExt(*it) && foundExtSep==pair.first)
           {
            foundExtSep = it;
           }
       }

    pathPair.first  = pair.first;
    pathPair.second = lastFoundPathSep;
    

    namePair.first = pathPair.second;
    //if (namePair.first!=pair.first) ++namePair.first; // skip path separator

    if (foundExtSep == pair.first)
       { // ext not found
        extPair.first = extPair.second = pair.first;
        namePair.second = pair.second;
       }
    else
       {
        extPair.first = foundExtSep;
        extPair.second = pair.second;
        namePair.second = foundExtSep;
       }
   }

//-----------------------------------------------------------------------------
inline
void splitFilename(const tstring &fullName,
                   tstring &path,
                   tstring &name,
                   tstring &ext,
                   const TCHAR* pathSeparators = PATH_SEPARATORS,
                   const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR)
   {
    ::std::pair<const_iter_t, const_iter_t> pathPair, namePair, extPair;
    ::filename::splitFilename(::std::make_pair(fullName.begin(), fullName.end()),
                              pathPair, namePair, extPair,
                              isPathSeparator(pathSeparators),
                              isExtSeparator(extSeparators));

    #ifdef __BORLANDC__
    // call assign causes 
    // Unresolved external basic_string::::replace<const char *>
    //                     (char *, char *, const char *, const char *)
    tstring(pathPair.first, pathPair.second).swap(path);
    tstring(namePair.first, namePair.second).swap(name);
    tstring(extPair.first, extPair.second).swap(ext);
    #else
    path.assign(pathPair.first, pathPair.second);
    name.assign(namePair.first, namePair.second);
    ext .assign(extPair.first, extPair.second);
    #endif
   }

//-----------------------------------------------------------------------------
template <typename Iter, typename pathPred>
void splitPath(::std::pair<Iter, Iter> path, 
               ::std::vector<::std::pair<Iter, Iter> > &parts,
               pathPred pred)
   {
    Iter beginIt = path.first;
    Iter endIt   = beginIt;
    for(; endIt!=path.second && pred(*endIt); ++endIt);
    for(; endIt!=path.second; endIt++)
       {
        if (pred(*endIt))
           { // found separator
            if (beginIt!=endIt) // skip multiple path separator occurences
               parts.push_back(::std::make_pair(beginIt, endIt));            
            beginIt = endIt;
            beginIt++;
           }
       }
    if (beginIt!=endIt) // skip multiple path separator occurences
       parts.push_back(::std::make_pair(beginIt, endIt));
   }

//-----------------------------------------------------------------------------
inline
void splitPath(const tstring &path, ::std::vector<tstring> &pathParts,
               const TCHAR* pathSeparators = PATH_SEPARATORS)
   {
    ::std::vector< ::std::pair<const_iter_t, const_iter_t> > parts;

    ::filename::splitPath( ::std::make_pair(path.begin(), path.end()), 
                           parts, isPathSeparator(pathSeparators) );
    for(::std::vector<::std::pair<const_iter_t, const_iter_t> >::const_iterator it = parts.begin();
        it!=parts.end();
        ++it)
       {
        pathParts.push_back(tstring(it->first, it->second));
       }
   }
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

inline
::std::ostream& printStringVector(::std::ostream &os, const ::std::vector<tstring> &vec, const tstring &sep)
   {
    ::std::vector<tstring>::const_iterator it = vec.begin();
    for(; it!=vec.end(); ++it)
       {
        if (it!=vec.begin()) os<<sep;
        os<<*it;
       }
    return os;
   }

inline
::std::ostream& printSplitPath(::std::ostream &os, const tstring &path)
   {
    ::std::vector<tstring> vec;
    ::filename::splitPath(path, vec);
    ::filename::test::printStringVector(os, vec, _T(","));
    return os;
   }

//-----------------------------------------------------------------------------
inline
bool splitFilenameTest(const tstring &fullName, const tstring &chkPath, const tstring &chkName, const tstring &chkExt )
   {
    tstring path, name, ext;
    ::filename::splitFilename(fullName, path, name, ext);

    bool bRes = true;

    if (path!=chkPath || name!=chkName || ext!=chkExt)
       {
        bRes = false;

        tcout<<_T("splitFilename test failed, wrong");
        
        if (path!=chkPath) tcout<<_T(" path");
    
        if (name!=chkName) tcout<<_T(" name");       

        if (ext!=chkExt)   tcout<<_T(" ext");       
       }

    if (!bRes)
       {
        std::cout<<_T(" - path: [")<<path<<_T("], name: [")<<name<<_T("], ext: [")<<ext<<_T("]\n");
       }
    #ifdef FILENAME_PRINT_ALL_TESTS
    else
       {
        std::cout<<_T("splitFilename test passed. Path: [")<<path<<_T("], name: [")<<name<<_T("], ext: [")<<ext<<_T("]\n");
       }
    #endif
    return bRes;
   }

//-----------------------------------------------------------------------------
struct CFilenameTestStruct
{
    TCHAR *name;
    TCHAR *res1;
    TCHAR *res2;
    TCHAR *res3;
};

// return num of failed tests
inline
int splitFilenameTestSuite(int *pTotalTests /* pointer to var that incremented with total num of tests */)
   {
    CFilenameTestStruct tests[] = {
                                   { _T("c:\\winnt/system32/file.ext"), _T("c:\\winnt/system32/"), _T("file"), _T(".ext") },
                                   { _T("c:\\winnt/system32/file.ext1.ext2"), _T("c:\\winnt/system32/"), _T("file"), _T(".ext1.ext2") },
                                   { _T("file.ext"), _T(""), _T("file"), _T(".ext") },
                                   { _T("file.ext1.ext2"), _T(""), _T("file"), _T(".ext1.ext2") },
                                   //{ _T(""), _T(""), _T(""), _T("") },
                                   { 0, 0, 0, 0 }
                                  };
    int failedTests = 0;
    int i = 0;
    CFilenameTestStruct *pTests = tests;
    for(; pTests->name; ++i, ++pTests)
       {
        if (!::filename::test::splitFilenameTest(pTests->name, pTests->res1, pTests->res2, pTests->res3))
           {
            ++failedTests;
           }
       }

    if (pTotalTests)
       *pTotalTests += i;

    tcout<<_T("splitFilenameTestSuite: total tests - ")<<i<<_T(", failed tests - ")<<failedTests<<_T("\n---\n");

    return failedTests;
   }

}; // namespace test
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

template <typename Iter, typename Pred>
::std::pair<Iter, Iter> getPath(::std::pair<Iter, Iter> pair, Pred pred)
   {
    Iter it = pair.first;
    Iter lastFoundIt = pair.first;
    for(; it!=pair.second; )
       if (pred(*it++)) { lastFoundIt = it; }
    return ::std::make_pair( pair.first, lastFoundIt );
   }

//-----------------------------------------------------------------------------
inline
tstring getPath(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS)
   {
    std::pair<const_iter_t, const_iter_t> res = ::filename::getPath(
                                   ::std::make_pair(fullName.begin(), fullName.end()), 
                                   isPathSeparator(pathSeparators)
                                                                   );
    return tstring(res.first, res.second); 
   }

//-----------------------------------------------------------------------------
#ifdef FILENAME_OLD_NAMES
inline
tstring path(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS)
   {
    std::pair<const_iter_t, const_iter_t> res = ::filename::getPath(
                                   ::std::make_pair(fullName.begin(), fullName.end()), 
                                   isPathSeparator(pathSeparators)
                                                                   );
    if (res.first!=res.second)
       return tstring(res.first, --res.second);
    else
       return tstring(res.first, res.second);
   }
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
inline
bool getPathTest(const tstring &fullName, const tstring &resPath, bool rightRes)
   {
    bool res = (::filename::getPath(fullName)==resPath);
    return (res==rightRes);
   }

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int getPathTestSuite(int *pTotalTests /* pointer to var that incremented with total num of tests */)
   {
    genericTestCaseResStruct tests[] = {
                                     { _T("c:\\winnt\\system32"), _T("c:\\winnt\\"), true },
                                     { _T("c:\\winnt\\system32"), _T("c:\\winnt"), false },
                                     { _T("c:/winnt\\system32"), _T("c:/winnt\\"), true },
                                     { _T("file.txt"), _T(""), true },
                                     //{ _T(""), _T(""), false },
                                     { 0, 0, false }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("getPath"), ::filename::test::getPathTest);
   }

}; // namespace test
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
inline
tstring getFile(const tstring &fullName, const TCHAR* pathSeparators)
   {
    ::std::pair<const_iter_t, const_iter_t> pathPair, namePair, extPair;
    ::filename::splitFilename(::std::make_pair(fullName.begin(), fullName.end()),
                              pathPair, namePair, extPair,
                              isPathSeparator(pathSeparators),
                              isPathSeparator(PATH_SEPARATORS));
    if (namePair.first==namePair.second)
        return tstring(namePair.first, namePair.second);
    else // name and ext
        return tstring(namePair.first, fullName.end());
   }

//-----------------------------------------------------------------------------
inline tstring getFile(const tstring &fullName)
   { return ::filename::getFile(fullName, PATH_SEPARATORS); }

//-----------------------------------------------------------------------------
#ifdef FILENAME_OLD_NAMES
inline
tstring file(const tstring &fullName, const TCHAR* pathSeparators = PATH_SEPARATORS)
   { return getFile(fullName, pathSeparators); }
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int getFileTestSuite(int *pTotalTests /* pointer to var that incremented with total num of tests */)
   {
    genericTestCaseStruct tests[] = {
                                     { _T("c:\\winnt\\system32/file.txt"), _T("file.txt") },
                                     { _T("c:\\winnt\\system32/file"), _T("file") },
                                     { _T("file.txt"), _T("file.txt") },
                                     { _T("file"), _T("file") },
                                     //{ _T(""), _T("") },
                                     { 0, 0 }
                                    };
    
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("getFile"), ::filename::getFile);
   }

}; // namespace test
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

inline
tstring getExtention( const tstring &fullName, 
                      const TCHAR*  pathSeparators, 
                      const TCHAR*  extSeparators)
   {
    ::std::pair<const_iter_t, const_iter_t> pathPair, namePair, extPair;
    ::filename::splitFilename(::std::make_pair(fullName.begin(), fullName.end()),
                              pathPair, namePair, extPair,
                              isPathSeparator(pathSeparators),
                              isExtSeparator(extSeparators));
    return tstring(extPair.first, extPair.second);
   }

//-----------------------------------------------------------------------------
inline tstring getExtention( const tstring &fullName )
   { return ::filename::getExtention(fullName, PATH_SEPARATORS, PATH_EXT_SEPARATOR_STR); }

//-----------------------------------------------------------------------------
#ifdef FILENAME_OLD_NAMES
inline
tstring extention( const tstring &fullName, 
                   const TCHAR* pathSeparators = PATH_SEPARATORS, 
                   const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR)
   { return getExtention(fullName, pathSeparators, extSeparators); }
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int getExtentionTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct tests[] = {
                                     { _T("c:\\winnt\\system32/file.txt"), _T(".txt") },
                                     { _T("c:\\winnt\\system32/file"), _T("") },
                                     { _T("file.txt"), _T(".txt") },
                                     { _T("file"), _T("") },
                                     //{ _T(""), _T("") },
                                     { 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("getExtention"), ::filename::getExtention);
   }

}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
inline
tstring getName( const tstring &fullName, 
                 const TCHAR* pathSeparators, 
                 const TCHAR* extSeparators)
   {
    extSeparators;
    ::std::pair<const_iter_t, const_iter_t> pathPair, namePair, extPair;
    ::filename::splitFilename(::std::make_pair(fullName.begin(), fullName.end()),
                              pathPair, namePair, extPair,
                              isPathSeparator(pathSeparators),
                              isExtSeparator(extSeparators));
    return tstring(namePair.first, namePair.second);
   }

//-----------------------------------------------------------------------------
inline tstring getName( const tstring &fullName )
   { return ::filename::getName( fullName, PATH_SEPARATORS, PATH_EXT_SEPARATOR_STR); }

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int getNameTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct tests[] = {
                                     { _T("c:\\winnt\\system32/file.txt"), _T("file") },
                                     { _T("c:\\winnt\\system32\\file"), _T("file") },
                                     { _T("file.txt"), _T("file") },
                                     { _T("file"), _T("file") },
                                     //{ _T(""), _T("") },
                                     { 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("getName"), ::filename::getName);
   }

}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
inline
tstring getPathName( const tstring &fullName, 
                     const TCHAR*  pathSeparators, 
                     const TCHAR*  extSeparators)
   {
    extSeparators;
    ::std::pair<const_iter_t, const_iter_t> pathPair, namePair, extPair;
    ::filename::splitFilename(::std::make_pair(fullName.begin(), fullName.end()),
                              pathPair, namePair, extPair,
                              isPathSeparator(pathSeparators),
                              isExtSeparator(extSeparators));
    return tstring(pathPair.first, namePair.second);
   }

//-----------------------------------------------------------------------------
inline
tstring getPathName( const tstring &fullName)
   { return ::filename::getPathName( fullName, PATH_SEPARATORS, PATH_EXT_SEPARATOR_STR); }

//-----------------------------------------------------------------------------

#ifdef FILENAME_OLD_NAMES
inline
tstring name( const tstring &fullName, 
              const TCHAR*  pathSeparators = PATH_SEPARATORS, 
              const TCHAR*  extSeparators = PATH_EXT_SEPARATOR_STR)
   { return ::filename::getPathName(fullName, pathSeparators, extSeparators); }
#endif


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int getPathNameTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct tests[] = {
                                     { _T("c:\\winnt\\system32/file.txt"), _T("c:\\winnt\\system32/file") },
                                     { _T("c:\\winnt\\system32\\file"), _T("c:\\winnt\\system32\\file") },
                                     { _T("file.txt"), _T("file") },
                                     { _T("file"), _T("file") },
                                     //{ _T(""), _T("") },
                                     { 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("getPathName"), ::filename::getPathName);
   }

}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
inline
tstring appendPath(const tstring &path, const tstring &pathAppend,
                   const TCHAR*  pathSeparators,
                   TCHAR pathPrefferedSeparator)
   {
    tstring tmp = path;
    if (!tmp.empty() && !isPathSeparator(pathSeparators)(tmp[tmp.size()-1]))
        tmp.append(1, pathPrefferedSeparator);
    return tmp + pathAppend;
   }

//-----------------------------------------------------------------------------
inline tstring appendPath(const tstring &path, const tstring &pathAppend )
   { return ::filename::appendPath(path, pathAppend, PATH_SEPARATORS, PATH_PREFFERED_SEPARATOR ); }


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{
inline int appendPathTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct2 tests[] = {
                                     { _T("c:\\winnt\\system32"), _T("file"), _T("c:\\winnt\\system32\\file")},
                                     { _T("c:\\winnt\\system32\\"), _T("file"), _T("c:\\winnt\\system32\\file")},
                                     { _T("c:\\winnt\\system32/"), _T("file"), _T("c:\\winnt\\system32/file")},
                                     { _T("c:\\winnt\\system32"), _T("file.ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt\\system32\\"), _T("file.ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt\\system32/"), _T("file.ext"), _T("c:\\winnt\\system32/file.ext")},

                                     { _T("c:\\winnt"), _T("system32\\file"), _T("c:\\winnt\\system32\\file")},
                                     { _T("c:\\winnt\\"), _T("system32\\file"), _T("c:\\winnt\\system32\\file")},
                                     { _T("c:\\winnt\\"), _T("system32/file"), _T("c:\\winnt\\system32/file")},
                                     { _T("c:\\winnt\\"), _T("system32\\file.ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt\\"), _T("system32\\file.ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt"), _T("system32/file.ext"), _T("c:\\winnt\\system32/file.ext")},
                                     { _T(""), _T("file.ext"), _T("file.ext")},
                                     { 0, 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("appendPathName"), ::filename::appendPath);
   }
}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
inline
tstring appendExtention(const tstring &name, const tstring &ext,
                        const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                        TCHAR extSeparator = PATH_EXT_SEPARATOR)
   {
    tstring tmp = name;
    if (!ext.empty() && !isExtSeparator(extSeparators)(ext[0]))
        tmp.append(1, extSeparator);
    return tmp + ext;
   }

//-----------------------------------------------------------------------------
inline tstring appendExtention(const tstring &name, const tstring &ext)
   { return ::filename::appendExtention(name, ext, PATH_EXT_SEPARATOR_STR, PATH_EXT_SEPARATOR); }


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{
inline int appendExtentionTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct2 tests[] = {
                                     { _T("c:\\winnt\\system32\\file"), _T("ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt\\system32\\file"), _T(".ext"), _T("c:\\winnt\\system32\\file.ext")},
                                     { _T("c:\\winnt\\system32\\file.ext1"), _T("ext2"), _T("c:\\winnt\\system32\\file.ext1.ext2")},
                                     { _T("c:\\winnt\\system32\\file.ext1"), _T(".ext2"), _T("c:\\winnt\\system32\\file.ext1.ext2")},
                                     { _T("file"), _T(".ext"), _T("file.ext")},
                                     { _T("file"), _T("ext"), _T("file.ext")},
                                     { _T("file.ext1"), _T(".ext2"), _T("file.ext1.ext2")},
                                     { _T("file.ext1"), _T("ext2"), _T("file.ext1.ext2")},
                                     { 0, 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("appendExtentionName"), ::filename::appendExtention);
   }
}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
void pathRemoveTrailingSlashInplace(tstring &path, const TCHAR* pathSeparators = PATH_SEPARATORS)
   {
    if (path.empty() && isPathSeparator(pathSeparators)(path[path.size()-1]))
       path.erase(path.size()-1); 
   }

//-----------------------------------------------------------------------------
tstring pathRemoveTrailingSlash(const tstring &path, const TCHAR* pathSeparators = PATH_SEPARATORS)
   {
    tstring copy = path;
    ::filename::pathRemoveTrailingSlashInplace(copy, pathSeparators);
    return copy;
   }

//-----------------------------------------------------------------------------
template <typename Iter>
tstring mergeFilename(::std::pair<Iter, Iter> pathPair,
                      ::std::pair<Iter, Iter> namePair,
                      ::std::pair<Iter, Iter> extPair,
                      const TCHAR* pathSeparators = PATH_SEPARATORS,
                      TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR,
                      const TCHAR* extSeparators = PATH_EXT_SEPARATOR_STR,
                      TCHAR extSeparator = PATH_EXT_SEPARATOR)
   {
    return ::filename::appendPath(tstring(pathPair.first, pathPair.second), 
                                  ::filename::appendExtention( tstring(namePair.first, namePair.second), 
                                                               ext, extSeparators, extSeparator), 
                                  pathSeparators, pathPrefferedSeparator 
                                 );
   }

//-----------------------------------------------------------------------------
inline
tstring mergeFilename( const tstring &path,
                       const tstring &name,
                       const tstring &ext,
                       const TCHAR* pathSeparators,
                       TCHAR pathPrefferedSeparator,
                       const TCHAR* extSeparators,
                       TCHAR extSeparator)
                   
   {
    return ::filename::appendPath(path, 
                                  ::filename::appendExtention(name, ext, extSeparators, extSeparator), 
                                  pathSeparators, pathPrefferedSeparator );
   }

//-----------------------------------------------------------------------------
inline
tstring mergeFilename( const tstring &path,
                       const tstring &name,
                       const tstring &ext)
                   
   {
    return ::filename::appendPath(path, 
                     ::filename::appendExtention(name, ext, PATH_EXT_SEPARATOR_STR, PATH_EXT_SEPARATOR), 
                     PATH_SEPARATORS, PATH_PREFFERED_SEPARATOR );
   }

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{
inline int mergeFilenameTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct3 tests[] = {
                                     { _T("c:\\winnt\\"), _T("file"), _T("ext"), _T("c:\\winnt\\file.ext") },
                                     { _T("c:\\winnt"), _T("file"), _T("ext"), _T("c:\\winnt\\file.ext") },
                                     { _T("c:\\winnt/"), _T("file"), _T("ext"), _T("c:\\winnt/file.ext") },

                                     { _T("c:\\winnt\\"), _T("file"), _T(".ext"), _T("c:\\winnt\\file.ext") },
                                     { _T("c:\\winnt"), _T("file"), _T(".ext"), _T("c:\\winnt\\file.ext") },
                                     { _T("c:\\winnt/"), _T("file"), _T(".ext"), _T("c:\\winnt/file.ext") },

                                     { _T("c:\\winnt\\"), _T("file"), _T(""), _T("c:\\winnt\\file") },
                                     { _T("c:\\winnt"), _T("file"), _T(""), _T("c:\\winnt\\file") },
                                     { _T("c:\\winnt/"), _T("file"), _T(""), _T("c:\\winnt/file") },

                                     //{ _T(""), _T(""), _T(""), _T("") },
                                     { 0, 0, 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("mergeFilename"), ::filename::mergeFilename);
   }
}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
inline
tstring changeExtention( const tstring &fullName, 
                         const tstring &newExt,
                         const TCHAR*  pathSeparators = PATH_SEPARATORS,
                         const TCHAR*  extSeparators = PATH_EXT_SEPARATOR_STR,
                         TCHAR extSeparator = PATH_EXT_SEPARATOR)
   {
    return ::filename::appendExtention( ::filename::getPathName(fullName, pathSeparators, extSeparators), 
                                        newExt, extSeparators, extSeparator);
   }

//-----------------------------------------------------------------------------
template <typename Iter, typename Pred>
bool isUncAbsolutePath(::std::pair<Iter, Iter> name, Pred pred)
   {
    unsigned i = 0;
    for(; name.first!=name.second && i<2; ++name.first, ++i)
       {
        if (!pred(*name.first)) break;
       }
    return i>=2;
   }

//-----------------------------------------------------------------------------
inline
bool isUncAbsolutePath(const tstring &fullName, 
                       const TCHAR*  pathSeparators = PATH_SEPARATORS)
   {
    return ::filename::isUncAbsolutePath(
                     ::std::make_pair(fullName.begin(), fullName.end()), 
                     isPathSeparator(pathSeparators));
   }

//-----------------------------------------------------------------------------
template <typename Iter> 
bool isDriveAbsolutePath(::std::pair<Iter, Iter> name)
   {
    #ifdef _WIN32
    if (name.first==name.second)    return false;
    if (!NSFN_ISALPHA(*name.first)) return false;
    if (++name.first==name.second)  return false;
    if (*name.first!=_T(':'))       return false;
    return true;
    #else
    return false;   
    #endif
   }

//-----------------------------------------------------------------------------
// pred not used, for same fn signature as other fns
template <typename Iter, typename Pred> 
bool isDriveAbsolutePath(::std::pair<Iter, Iter> name, Pred pred)
   {
    #ifdef _WIN32
    if (name.first==name.second)    return false;
    if (!NSFN_ISALPHA(*name.first)) return false;
    if (++name.first==name.second)  return false;
    if (*name.first!=_T(':'))       return false;
    return true;
    #else
    return false;   
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool isDriveAbsolutePath(const tstring &fullName, 
                         const TCHAR*  pathSeparators = PATH_SEPARATORS)
   {
    pathSeparators;
    #ifdef _WIN32
    return ::filename::isDriveAbsolutePath(
                     ::std::make_pair(fullName.begin(), fullName.end())
                                          );
    #else
    fullName;
    return false;   
    #endif
   }

//-----------------------------------------------------------------------------
template <typename Iter, typename Pred> 
bool isUnixAbsolutePath(::std::pair<Iter, Iter> name, Pred pred)
   {
    // Unix-style absolute path also used in Win32
    // as absolute path from current drive root
    if (name.first==name.second) return false;
    if (!pred(*name.first))      return false;
    return true;
   }

//-----------------------------------------------------------------------------
inline
bool isUnixAbsolutePath(const tstring &fullName, 
                        const TCHAR*  pathSeparators = PATH_SEPARATORS)
   {
    return ::filename::isUnixAbsolutePath(
                     ::std::make_pair(fullName.begin(), fullName.end()),
                     isPathSeparator(pathSeparators)
                                         );
   }

//-----------------------------------------------------------------------------
template <typename Iter, typename Pred> 
bool isAbsolutePath(::std::pair<Iter, Iter> name, Pred pred)
   {
    return isUncAbsolutePath(name, pred) ||
           //isDriveAbsolutePath(name, pred) ||
           isDriveAbsolutePath(name) ||
           isUnixAbsolutePath(name, pred);
   }

//-----------------------------------------------------------------------------
inline
bool isAbsolutePath(const tstring &fullName, 
                    const TCHAR*  pathSeparators = PATH_SEPARATORS)
   {
    return ::filename::isAbsolutePath(
                     ::std::make_pair(fullName.begin(), fullName.end()),
                     isPathSeparator(pathSeparators)
                                     );
   }

//-----------------------------------------------------------------------------
inline
tstring makeFullPath(const tstring &basePath, const tstring &relPath,
                     const TCHAR*  pathSeparators = PATH_SEPARATORS,
                     TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    if (isAbsolutePath(relPath, pathSeparators)) return relPath;
    return appendPath(basePath, relPath, pathSeparators, pathPrefferedSeparator );
   }



//-----------------------------------------------------------------------------
namespace utils
{
//-----------------------------------------------------------------------------
template <typename Iter>
bool equaiPairs( ::std::pair<Iter, Iter> p1, ::std::pair<Iter, Iter> p2)
   {
    for(; p1.first!=p1.second && p2.first!=p2.second; ++p1.first, ++p2.first)
       {
        if (*p1.first != *p2.first) return false;
       }
    return p1.first==p1.second && p2.first==p2.second;
   }

//-----------------------------------------------------------------------------
template <typename Iter>
bool equaiToPair( const tstring &str, ::std::pair<Iter, Iter> p)
   {
    return equaiPairs( ::std::make_pair(str.begin(), str.end()), p);
   }
}; /* namespace utils */
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
template <typename Iter>
bool isCurrentDirectorySpecialName(::std::pair<Iter, Iter> dirNamePair )
   { return ::filename::utils::equaiToPair( _T("."), dirNamePair); }

//-----------------------------------------------------------------------------
inline
bool isCurrentDirectorySpecialName(const tstring& dirName )
   { return ::filename::isCurrentDirectorySpecialName(::std::make_pair(dirName.begin(), dirName.end()) ); }

//-----------------------------------------------------------------------------
template <typename Iter>
bool isUpperDirectorySpecialName(::std::pair<Iter, Iter> dirNamePair )
   { return ::filename::utils::equaiToPair( _T(".."), dirNamePair); }

//-----------------------------------------------------------------------------
inline
bool isUpperDirectorySpecialName(const tstring& dirName )
   { return ::filename::isUpperDirectorySpecialName(::std::make_pair(dirName.begin(), dirName.end()) ); }

//-----------------------------------------------------------------------------
template <typename Iter, typename Pred>
void makeCanonical(const ::std::vector<::std::pair<Iter, Iter> > &srcPathParts,
                   Pred pathPred,
                   ::std::vector<::std::pair<Iter, Iter> > &resVec)
   {
    resVec.reserve(srcPathParts.size());
    ::std::vector<::std::pair<Iter, Iter> >::const_iterator it = srcPathParts.begin();

    for(;it!=srcPathParts.end(); ++it)
       {
        if (::filename::isCurrentDirectorySpecialName(*it))
           { // skip current directory
            if (resVec.empty()) // don't skip first element in path
               resVec.push_back(*it);
           }
        else if (::filename::isUpperDirectorySpecialName(*it))
           { // go one level up
            if (resVec.empty()) 
               resVec.push_back(*it); // possible error, but we ignoring it
            else if (resVec.size()>1) 
               {
                if (::filename::isUpperDirectorySpecialName(resVec.back()))
                   resVec.push_back(*it); // possible error, but we ignoring it
                else
                   resVec.pop_back(); // Ok
               }
            else if (::filename::isAbsolutePath(*(resVec.begin()), pathPred))
               resVec.push_back(*it); // possible error, but we ignoring it
            else
               {
                if (::filename::isUpperDirectorySpecialName(resVec.back()))
                   resVec.push_back(*it); // possible error, but we ignoring it
                else
                   resVec.pop_back(); // Ok
               }
           }
        else
           resVec.push_back(*it);
       }
   }

//-----------------------------------------------------------------------------
inline
tstring makeCanonical(const tstring &path, 
                      const TCHAR* pathSeparators,
                      TCHAR pathPrefferedSeparator)
   {
    ::std::vector<::std::pair<const_iter_t, const_iter_t> > srcParts;
    ::filename::splitPath(::std::make_pair(path.begin(), path.end()), srcParts, isPathSeparator(pathSeparators));

    ::std::vector<::std::pair<const_iter_t, const_iter_t> > resParts;
    ::filename::makeCanonical(srcParts, isPathSeparator(pathSeparators), resParts);

    tstring res; res.reserve(path.size());
    
    ::std::vector<::std::pair<const_iter_t, const_iter_t> >::const_iterator it = resParts.begin();
    for(;it!=resParts.end(); ++it)
       {
        if (!res.empty()) res.append(1, pathPrefferedSeparator);
        #ifdef __BORLANDC__
        // call append directly causes 
        // Unresolved external basic_string::::replace<const char *>
        //                     (char *, char *, const char *, const char *)
        res.append(tstring(it->first, it->second));
        #else
        res.append(it->first, it->second);
        #endif
       }
    
    return res;   
   }

//-----------------------------------------------------------------------------
inline
tstring makeCanonical(const tstring &path)
   { return ::filename::makeCanonical(path, PATH_SEPARATORS, PATH_PREFFERED_SEPARATOR); }

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
   
#ifdef FILENAME_USE_TEST
namespace test
{
inline int makeCanonicalTestSuite(int *pTotalTests)
   {
    genericTestCaseStruct1 tests[] = {
                                     { _T("c:\\winnt\\system32/drivers\\etc/hosts"), _T("c:\\winnt\\system32\\drivers\\etc\\hosts") },
                                     { _T("c:\\winnt\\system32/.\\drivers\\etc/hosts"), _T("c:\\winnt\\system32\\drivers\\etc\\hosts") },
                                     { _T("c:\\winnt\\..\\winnt\\system32/..\\.\\system32/drivers\\etc/hosts"), _T("c:\\winnt\\system32\\drivers\\etc\\hosts") },
                                     { _T(".\\winnt\\system32/drivers\\etc/hosts"), _T(".\\winnt\\system32\\drivers\\etc\\hosts") },
                                     { _T("\\\\server\\winnt\\./system32/drivers\\etc/hosts"), _T("\\\\server\\winnt\\system32\\drivers\\etc\\hosts") },
                                     { _T("\\\\server\\../winnt\\./system32/drivers\\etc/hosts"), _T("\\\\server\\..\\winnt\\system32\\drivers\\etc\\hosts") },

                                     //{ _T(""), _T("") },
                                     { 0, 0 }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("makeCanonical"), ::filename::makeCanonical);
   }
}; // namespace test
#endif
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------




#ifdef FILENAME_OLD_NAMES
inline
bool isDotDirectory ( const tstring& dir )
   {
    return dir==_T(".");
   }

//-----------------------------------------------------------------------------
inline
tstring canonical(const tstring &filename,
                  const TCHAR*  pathSeparators = PATH_SEPARATORS,
                  TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    std::vector<tstring> pathParts;

    splitPath(filename, pathParts, pathSeparators);

    std::vector<tstring>::iterator end = std::remove_if ( 
                                              pathParts.begin(), 
                                              pathParts.end(), 
                                              isDotDirectory 
                                                        );
    std::vector<tstring> resVec;
    resVec.reserve(pathParts.size());

    std::vector<tstring>::iterator it = pathParts.begin();
    for(;it!=end; ++it)
       {
        if (*it==_T(".."))
           { // go one level up
            if (resVec.empty()) 
               resVec.push_back(*it); // possible error, but we ignoring it
            else if (resVec.size()>1) 
               {
                if (resVec.back()==_T(".."))
                   resVec.push_back(*it); // possible error, but we ignoring it
                else
                   resVec.pop_back(); // Ok
               }
            else if (isAbsolutePath(resVec[0], pathSeparators))
               resVec.push_back(*it); // possible error, but we ignoring it
            else
               {
                if (resVec.back()==_T(".."))
                   resVec.push_back(*it); // possible error, but we ignoring it
                else
                   resVec.pop_back(); // Ok
               }
           }
        else
           resVec.push_back(*it);       
       }

    tstring res;
    res.reserve(filename.size());

    it = resVec.begin();
    for(;it!=resVec.end(); ++it)
       {
        if (!res.empty()) res.append(1, pathPrefferedSeparator);
        res.append(*it);
       }

    return res;
   }
#endif /* FILENAME_OLD_NAMES*/
//-----------------------------------------------------------------------------



typedef bool (*compareProcType)( const tstring &n1, const tstring &n2,
                                 #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                                 const ::std::locale &loc,
                                 #endif
                                 const TCHAR* pathSeparators,
                                 TCHAR pathPrefferedSeparator);


inline
bool equal( const tstring &name1, const tstring &name2,
            #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
            const ::std::locale &loc = ::filename::utils::makeCurrentLocale(),
            #endif
            const TCHAR* pathSeparators = PATH_SEPARATORS,
            TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    #ifdef _WIN32
     return utils::lowerCase(::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator), loc)
         == utils::lowerCase(::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator), loc);
    #else
     return ::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator)
         == ::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator);
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool less( const tstring &name1, const tstring &name2,
           #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
           const ::std::locale &loc = ::filename::utils::makeCurrentLocale(),
           #endif
           const TCHAR*  pathSeparators = PATH_SEPARATORS,
           TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    #ifdef _WIN32
     return utils::lowerCase(::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator), loc)
          < utils::lowerCase(::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator), loc);
    #else
     return ::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator)
          < ::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator);
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool lessEqual( const tstring &name1, const tstring &name2,
                #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                const ::std::locale &loc = ::filename::utils::makeCurrentLocale(),
                #endif
                const TCHAR* pathSeparators = PATH_SEPARATORS,
                TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    #ifdef _WIN32
     return utils::lowerCase(::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator), loc)
         <= utils::lowerCase(::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator), loc);
    #else
     return ::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator)
         <= ::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator);
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool greater( const tstring &name1, const tstring &name2,
              #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
              const ::std::locale &loc = ::filename::utils::makeCurrentLocale(),
              #endif
              const TCHAR* pathSeparators = PATH_SEPARATORS,
              TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    #ifdef _WIN32
     return utils::lowerCase(::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator), loc)
          > utils::lowerCase(::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator), loc);
    #else
     return ::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator)
          > ::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator);
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool greaterEqual( const tstring &name1, const tstring &name2,
                   #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                   const ::std::locale &loc = ::filename::utils::makeCurrentLocale(),
                   #endif
                   const TCHAR* pathSeparators = PATH_SEPARATORS,
                   TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR )
   {
    #ifdef _WIN32
     return utils::lowerCase(::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator), loc)
         >= utils::lowerCase(::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator), loc);
    #else
     return ::filename::makeCanonical(name1, pathSeparators, pathPrefferedSeparator)
         >= ::filename::makeCanonical(name2, pathSeparators, pathPrefferedSeparator);
    #endif
   }



/* //-----------------------------------------------------------------------------
 * struct equalTo
 * {
 *     tstring name;
 *     tstring pathSeparators;
 *     TCHAR   pathPrefferedSeparator;
 *  
 *     equalTo(const tstring &name,
 *             const tstring &pathSeparators = PATH_SEPARATORS,
 *             TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR)
 *        : name(name)
 *        , pathSeparators(pathSeparators)
 *        , pathPrefferedSeparator(pathPrefferedSeparator)
 *        {}
 *  
 *     bool operator() (const tstring &cmpName)
 *        {
 *         return equal( name, cmpName, pathSeparators, pathPrefferedSeparator);
 *        }
 * };
 */

//-----------------------------------------------------------------------------

template <typename TCompare>
struct compareTo
{
    tstring  name;
    const TCHAR* pathSeparators;
    TCHAR    pathPrefferedSeparator;
    TCompare compare;
    #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
    ::std::locale loc;
    #endif
 
    compareTo(const tstring &name,
              TCompare       cmp,
              #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
              ::std::locale  &l = ::filename::utils::makeCurrentLocale(),
              #endif
              const TCHAR* pathSeparators = PATH_SEPARATORS,
              TCHAR pathPrefferedSeparator = PATH_PREFFERED_SEPARATOR)
       : name(name)
       , compare(cmp)
       #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
       , loc(l)
       #endif
       , pathSeparators(pathSeparators)
       , pathPrefferedSeparator(pathPrefferedSeparator)
       {}
 
    bool operator() (const tstring &cmpName)
       {
        return compare( name, 
                        cmpName, 
                        #if defined(_WIN32) || defined(FILENAME_COMPARISON_ALWAYS_USE_LOCALE)
                        loc,
                        #endif
                        pathSeparators, 
                        pathPrefferedSeparator
                      );
       }
};



//-----------------------------------------------------------------------------
template <typename Iter, typename ChangeCase>
bool matchMask(::std::pair<Iter, Iter> name, 
               ::std::pair<Iter, Iter> mask,
               const ChangeCase &changeCase
              )
   {
    while(name.first!=name.second && mask.first!=mask.second)
       {
        switch(*mask.first)
           {
            case _T('*'):
                while(mask.first!=mask.second && *mask.first==_T('*'))
                   ++mask.first; // skip '*'
                if (mask.first==mask.second) return true;
                for(; name.first!=name.second; ++name.first)
                   {
                    if (matchMask(::std::make_pair(name.first, name.second), ::std::make_pair(mask.first, mask.second), changeCase))
                       return true;
                   }
                return false;

            case _T('?'):
                // simple skip character
                ++name.first; ++mask.first;
                break;

            default:
                if (changeCase(*name.first)!=changeCase(*mask.first))
                   return false;
                ++name.first; ++mask.first;
           };
       }
    if (name.first==name.second && mask.first!=mask.second)
       {
        while(mask.first!=mask.second && *mask.first==_T('*'))
           ++mask.first; // skip trailing '*'
       }

    if (name.first!=name.second || mask.first!=mask.second)
       return false;

    return true;
   }

//-----------------------------------------------------------------------------
inline
bool matchMaskE(const tstring &name, const tstring &mask)
   {
    return ::filename::matchMask( ::std::make_pair(name.begin(), name.end()),
                                  ::std::make_pair(mask.begin(), mask.end()),
                                  ::filename::utils::keepcaseChar()
                                );
   }

//-----------------------------------------------------------------------------
inline
bool matchMaskI(const tstring &name, const tstring &mask, 
                const ::std::locale &loc = ::filename::utils::makeCurrentLocale())
   {
    return ::filename::matchMask( ::std::make_pair(name.begin(), name.end()),
                                  ::std::make_pair(mask.begin(), mask.end()),
                                  ::filename::utils::lowercaseChar(loc)
                                );
   }

//-----------------------------------------------------------------------------
inline
bool matchMask(const tstring &name, const tstring &mask)
   {
    #ifdef _WIN32
    return ::filename::matchMask( ::std::make_pair(name.begin(), name.end()),
                                  ::std::make_pair(mask.begin(), mask.end()),
                                  ::filename::utils::lowercaseChar(::filename::utils::makeCurrentLocale())
                                );
    #else
    return ::filename::matchMask( ::std::make_pair(name.begin(), name.end()),
                                  ::std::make_pair(mask.begin(), mask.end()),
                                  ::filename::utils::keepcaseChar()
                                );
    #endif
   }

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef FILENAME_USE_TEST
namespace test
{

//-----------------------------------------------------------------------------
inline
bool matchMaskTest(const tstring &name, const tstring &mask, bool rightRes)
   {
    bool res = ::filename::matchMask(name, mask);
    return (res==rightRes);
   }

//-----------------------------------------------------------------------------
// return num of failed tests
inline
int matchMaskTestSuite(int *pTotalTests /* pointer to var that incremented with total num of tests */)
   {
    genericTestCaseResStruct tests[] = {
                                     { "ab"           , "a*?b"     , false },
                                     { ".cxxp"        , ".c*p"     , true  },
                                     { ".information" , ".in*mat*" , true  },
                                     { ".inmat"       , ".in*mat*" , true  },
                                     { ".infwat"      , ".in*mat*" , false },
                                     { ".infwat"      , ".in*?at*" , true  },
                                     { ".cpp"         , ".cxx"     , false },
                                     { ".hpp"         , ".c??"     , false },
                                     { ".cpp"         , ".c??"     , true  },
                                     { ".cxx"         , ".c??"     , true  },
                                     { ".hpp"         , ".c*"      , false },
                                     { ".cpp"         , ".c*"      , true  },
                                     { ".cxx"         , ".c*"      , true  },
                                     { ".c"           , ".c*"      , true  },
                                     { "bla-bla"      , "*"        , true  },
                                     { "bla-bla"      , "*?"       , true  },
                                     { "bla-bla"      , "*?a"      , true  },
                                     { "bla-bla"      , "*?c"      , false },
                                     { "bla-bla"      , "bla-*?"   , true },
                                     { "bla-bla"      , "*?bla"    , true },
                                     { "bla-bla"      , "?*bla"    , true },
                                     { 0, 0, false }
                                    };
    return ::filename::test::genericTestSuite(tests, pTotalTests, _T("matchMask"), ::filename::test::matchMaskTest);
   }
}; // namespace test
#endif

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



}; // namespace filename

#ifdef FILENAME_IN_MARTY_NAMESPACE
}; // namespace marty
#endif


//#undef ISNPOS


#endif /* FILENAME_H */

