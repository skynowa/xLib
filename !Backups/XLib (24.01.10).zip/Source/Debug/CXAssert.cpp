/****************************************************************************
* Class name:  CXAssert
* Description: ������� ����
* File name:   CXAssert.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.11.2009 16:39:23
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/CXAssert.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h> 
#include <XLib/Gui/CXMsgBoxRtf.h>
//---------------------------------------------------------------------------
//TODO: + CXAssert ()
CXAssert::CXAssert() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXAssert ()
CXAssert::~CXAssert() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + vLogAppend (������� �������� � ������, ������ � ����)
/*static*/ VOID CXAssert::_vLogAppend(LPCTSTR pszFilePath, LPCTSTR pszText) {
	/*CHECK*/

	FILE *pFile = _tfopen(pszFilePath, _T("a"));
	if (NULL == pFile) {
		return;
	}

	__try {
		SYSTEMTIME stST = {0};
		::GetLocalTime(&stST);
		_ftprintf(pFile, _T("[%d:%d:%d]  %s\n---------------------------------------------------------------------------\n\n"), 
			stST.wHour, stST.wMinute, stST.wSecond, pszText);
	}
	__finally {
		if (NULL != pFile) {
			fflush(pFile);
			fclose(pFile);	pFile = NULL;
		}
	}
}
//---------------------------------------------------------------------------
//TODO: + vLog (������� �������� � ������)
/*static*/VOID CXAssert::vLog(LPCTSTR pcszExp, ULONG ulLastError, LPCTSTR pcszFile, ULONG ulLine, LPCTSTR pcszFunc, LPCTSTR pcszDate, LPCTSTR pcszTime, LPCTSTR pcszComment) {
	/*CHECK*/

	//-------------------------------------
	//Never corrupt the last error value
	ULONG _ulLastError = ulLastError;

	//-------------------------------------
	//�������� ���������
	tstring sProgram   = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), FALSE);
	tstring sFile      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(pcszFile,           45), FALSE);
	tstring sLastError = lexical_cast(ulLastError) + _T(" - \"") + sLastErrorStr(ulLastError) + _T("\"");
	tstring sExeName   = CXPath::sExtractFileName(CXPath::sExePath());							

	tstring sFStr = sFormatStr(
						_T("%s\n\n")
						_T("%s  %s\n")
						_T("%s  %s\n")
						_T("%s  %i\n")
						_T("%s  %s\n")
						_T("%s  %s\n")
						_T("%s  %s\n")		
						_T("%s  %s/%s\n")		
						_T("%s  %s"),	

						_T("Assertion failed."),
						_T("Program:"),    sProgram.c_str(),
						_T("File:"),       sFile.c_str(),
						_T("Line:"),       ulLine,
						_T("Function:"),   pcszFunc,
						_T("Expression:"), pcszExp,
						_T("LastError:"),  sLastError.c_str(),
						_T("Build date:"), pcszDate, pcszTime,
						_T("Comment:"),    pcszComment);

	//-------------------------------------
	//�������� ��� �����
	tstring sFilePath = CXPath::sChangeFileExt(CXPath::sExePath(), _T("debug"));

	//-------------------------------------
	//������� � ���
	_vLogAppend(sFilePath.c_str(), sFStr.c_str());	

	//-------------------------------------
	//Never corrupt the last error value
	::SetLastError(_ulLastError);
}
//---------------------------------------------------------------------------
//TODO: + vMsg (������� �������� � ������, ����� ����������� ����)
/*static*/VOID CXAssert::vMsg(LPCTSTR pcszExp, ULONG ulLastError, LPCTSTR pcszFile, ULONG ulLine, LPCTSTR pcszFunc, LPCTSTR pcszDate, LPCTSTR pcszTime, LPCTSTR pcszComment/* = _T("")*/) {
	/*CHECK*/

	//-------------------------------------
	//Never corrupt the last error value
	ULONG _ulLastError = ulLastError;

	//-------------------------------------
	//�������� ���������
	tstring sProgram   = CXPath::sWinToUnixPath(CXPath::sMinimizePath(CXPath::sExePath(), 45), FALSE);
	tstring sFile      = CXPath::sWinToUnixPath(CXPath::sMinimizePath(pcszFile,           45), FALSE);
	tstring sLastError = lexical_cast(ulLastError) + _T(" - \"") + sLastErrorStr(ulLastError) + _T("\"");
	tstring sExeName   = CXPath::sExtractFileName(CXPath::sExePath());

#ifdef XLib_Debug_MsgBoxLite
	tstring sFStr = sFormatStr(
						_T("%s\n\n")
						_T("%s  %s\n")
						_T("%s  %s\n")
						_T("%s  %i\n")
						_T("%s  %s\n")
						_T("%s  %s\n")
						_T("%s  %s\n")	
						_T("%s  %s/%s\n")								
						_T("%s  %s"),	

						_T("Assertion failed."),
						_T("Program:"),    sProgram.c_str(),
						_T("File:"),       sFile.c_str(),
						_T("Line:"),       ulLine,
						_T("Function:"),   pcszFunc,
						_T("Expression:"), pcszExp,
						_T("LastError:"),  sLastError.c_str(),
						_T("Build date:"), pcszDate, pcszTime,
						_T("Comment:"),    pcszComment);

	//-------------------------------------
	//������� MessageBox
	INT iRes = ::MessageBox(NULL, sFStr.c_str(), sExeName.c_str(), MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
				exit(- 1);
			}
			break;

		case IDIGNORE: {
				//����������
			}
			break;

		case IDRETRY: {
				if (TRUE == ::IsDebuggerPresent()) {		//CheckRemoteDebuggerPresent
					////::DebugBreak();
					_asm {int 3}
				} else {
					MsgBox(_T("Debugger is not present.\nThe application will be terminated."), _T("XLib"), MB_OK | MB_ICONWARNING);
					exit(- 1);
				}	
			}
			break;
	}
#else //XLib_Debug_MsgBoxLite
	tstring sFStr = sFormatStr(
						_T("{\\rtf1\\ansi\\ansicpg1251\\deff0\\deflang1049{\\fonttbl{\\f0\\fswiss\\fcharset204{\\*\\fname Arial;}Arial CYR;}{\\f1\\fswiss\\fcharset0 Arial;}}")
						_T("{\\colortbl ;\\red255\\green0\\blue0;}")
						_T("\\viewkind4\\uc1\\pard\\ul\\b\\f0\\fs20 %s\\ulnone\\b0\\par")
						_T("\\par")
						_T("\\b %s\\b0   \\lang1033\\f1    \\cf1\\lang1049\\f0 %s\\par")
						_T("\\cf0\\b %s\\b0   \\lang1033\\f1            \\cf1\\lang1049\\f0 %s\\par")
						_T("\\cf0\\b %s\\b0   \\lang1033\\f1           \\cf1\\lang1049\\f0 %i\\cf0\\par")
						_T("\\b %s\\b0  \\lang1033\\f1   \\lang1049\\f0  \\lang1033\\f1  \\cf1\\lang1049\\f0 %s\\cf0\\par")
						_T("\\b %s\\b0   \\lang1033\\f1 \\cf1\\lang1049\\f0 %s\\cf0\\par")
						_T("\\b %s\\b0\\lang1033\\f1      \\cf1\\lang1049\\f0 %s\\cf0\\par")
						_T("\\b %s\\b0\\lang1033\\f1    \\cf1\\lang1049\\f0 %s %s\\cf0\\par")
						_T("\\b %s\\b0  \\lang1033\\f1    \\cf1 %s\\cf0\\lang1049\\f0\\par}"),		 

						_T("Assertion failed."),
						_T("Program:"),    sProgram.c_str(),
						_T("File:"),       sFile.c_str(),
						_T("Line:"),       ulLine,
						_T("Function:"),   pcszFunc,
						_T("Expression:"), pcszExp,
						_T("LastError:"),  sLastError.c_str(),
						_T("Build date:"), pcszDate, pcszTime,
						_T("Comment:"),    pcszComment 
	);

	//-------------------------------------
	//������� CXMsgBoxRtf
	INT iRes = CXMsgBoxRtf::iShow(NULL, sFStr, sExeName);
	switch (iRes) {
		case CXMsgBoxRtf::mrAbort: {
				exit(- 1);
			}
			break;

		case CXMsgBoxRtf::mrIgnore: {
				//����������
			}
			break;

		case CXMsgBoxRtf::mrRetry: {
			if (TRUE == ::IsDebuggerPresent()) {		//CheckRemoteDebuggerPresent
				////::DebugBreak();
				_asm {int 3}
			} else {
				MsgBox(_T("Debugger is not present.\nThe application will be terminated."), _T("XLib"), MB_OK | MB_ICONWARNING);
				exit(- 1);
			}				
	   }
	   break;	
	}
#endif //XLib_Debug_MsgBoxLite

	//-------------------------------------
	//Never corrupt the last error value
	::SetLastError(_ulLastError);
}
//---------------------------------------------------------------------------