/****************************************************************************
* Class name:  CXConsoleLog
* Description: ����������� ����� �������
* File name:   CXConsoleLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:53:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXConsoleLog.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Sync/CXCriticalSectionLocker.h>
#include <XLib/Fso/CXStdioFile.h>
//---------------------------------------------------------------------------
CXCriticalSection CXConsoleLog::_ms_csConsole;
//---------------------------------------------------------------------------
//TODO: + CXConsoleLog ()
CXConsoleLog::CXConsoleLog() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXConsoleLog ()
CXConsoleLog::~CXConsoleLog() {
	//code
}
//---------------------------------------------------------------------------




/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CXConsoleLog::bWrite(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tstring    sTime;
	SYSTEMTIME stST = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr(_T("[%.2d:%.2d:%.2d]"), stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	tstring sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXCriticalSectionLocker SL(_ms_csConsole);

	CXStdioFile::iPrintf(_T("%s %s"), sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------