/****************************************************************************
* Class name:  CXWndLog
* Description: ����������� � ����
* File name:   CXWndLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXWndLog.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Sync/CXCriticalSectionLocker.h>
//---------------------------------------------------------------------------
CXCriticalSection CXWndLog::_ms_csListBox;
//---------------------------------------------------------------------------
//TODO: + CXWndLog ()
CXWndLog::CXWndLog(EWindowClass wcWC) :
	_m_eWC (wcWC)
{
	/*DEBUG*/XASSERT_DO(wcListBox == _m_eWC, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXWndLog ()
CXWndLog::~CXWndLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CXWndLog::bWrite(HWND hWnd, LPCTSTR pcszFormat, ...) { 
	/*DEBUG*/XASSERT_RET(NULL != hWnd,       FALSE);
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tstring     sTime;
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr(_T("[%.2d:%.2d:%.2d]"), stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	tstring sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	switch(_m_eWC) {
		case wcListBox: {
				/*LOCK*/CXCriticalSectionLocker SL(_ms_csListBox);
				
				//sRemoveEOL
				::SendMessage(hWnd, LB_ADDSTRING, 0, (LPARAM)(sRemoveEOL(sTime + _T(" ") + sParam)).c_str());
				::SendMessage(hWnd, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
			}
			break;

		default: {
				/*DEBUG*/XASSERT_RET(FALSE, FALSE);
			}
			break;
	}
	
	return TRUE;
}
//---------------------------------------------------------------------------