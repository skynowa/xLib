// Copyright 2003 "Gilles Degottex"

// This file is part of "CppAddons"

// "CppAddons" is free software; you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// "CppAddons" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


#include <XLib/Random/CXRandom.h>

////#include <cmath>
#include <math.h>
//---------------------------------------------------------------------------
const int CXRandom::A = 48271;
//const int CXRandom::M = 2147483647;
const int CXRandom::M = RAND_MAX;
const int CXRandom::Q = M / A;
const int CXRandom::R = M % A;

CXRandom CXRandom::s_random;
//---------------------------------------------------------------------------
CXRandom::CXRandom(long seed) {
	m_haveNextNextGaussian=false;

	setSeed(seed);

	next();
}
//---------------------------------------------------------------------------
void CXRandom::setSeed(long seed) {
	srand(seed);

	if(seed < 0)	seed += M+1;
	m_seed = seed;
	if(m_seed==0)	m_seed = 1;

	m_haveNextNextGaussian = false;
}
//---------------------------------------------------------------------------
long CXRandom::next() {
//	int tmp = A * (m_seed % Q) - R * (m_seed / Q);
//	if(tmp>=0)	m_seed = tmp;
//	else		m_seed = tmp + M;
//
//	return m_seed;

	return rand();
}
//---------------------------------------------------------------------------
int CXRandom::nextInt() {
	return (int)next();
}
//---------------------------------------------------------------------------
int CXRandom::nextInt(int max) {
	return nextInt()%max;
}
//---------------------------------------------------------------------------
int CXRandom::nextInt(int a, int b) {
	return nextInt()%(b-a) + a;
}
//---------------------------------------------------------------------------
long CXRandom::nextLong()	{
	return next();
}
//---------------------------------------------------------------------------
bool CXRandom::nextBoolean() {
	return next() % 2 == 0;
}
//---------------------------------------------------------------------------
float CXRandom::nextFloat() {
	return nextInt() / float(M);
}
//---------------------------------------------------------------------------
double CXRandom::nextDouble() {
	return nextInt() / double(M);
}
//---------------------------------------------------------------------------
char CXRandom::nextLetter() {
	return char(('z' - 'a' + 1) * nextDouble() + 'a');
}
//---------------------------------------------------------------------------
char CXRandom::nextFigure() {
	return char(('9' - '0' + 1) * nextDouble() + '0');
}
//---------------------------------------------------------------------------
double CXRandom::nextGaussian() {
//	Throw("nextGaussian", "not yet implemented");

	// See Knuth, ACP, Section 3.4.1 Algorithm C.
	if(m_haveNextNextGaussian) {
    	m_haveNextNextGaussian = false;
    	return m_nextNextGaussian;
	} else {
		double v1, v2, s;
    	do {
			v1 = 2 * nextDouble() - 1; // between -1 and 1
			v2 = 2 * nextDouble() - 1; // between -1 and 1
			s = v1 * v1 + v2 * v2;
    	}
		while (s >= 1 || s == 0);

		double multiplier = sqrt(-2 * log(s)/s);

    	m_nextNextGaussian     = v2 * multiplier;
		m_haveNextNextGaussian = true;

		return v1 * multiplier;
	}
}
//---------------------------------------------------------------------------