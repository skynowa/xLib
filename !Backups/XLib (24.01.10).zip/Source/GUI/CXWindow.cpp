/****************************************************************************
* Class name:  CXWindow
* Description: ����� root ��� ���� �������� ���� 
* File name:   CXWindow.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     31.08.2009 16:44:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXWindow.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXTraceLog CXWindow::_m_tlLog;           
//---------------------------------------------------------------------------

/****************************************************************************
*	public
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + CXWindow
CXWindow::CXWindow() :
	_m_hWnd      (NULL),
	_m_iID       (0),
	_m_sClassName(_T("")),
	_m_hParentWnd(NULL),		
	_m_sText     (_T("")),
	_m_iLeft     (CW_USEDEFAULT),
	_m_iTop      (CW_USEDEFAULT),
	_m_iWidth    (0),
	_m_iHeight   (0),
	_m_ulStyleEx (0),
	_m_ulStyle   (0),
	////_m_iMenu     (0),
	_m_hFont     (NULL),
	_m_bIsControl(FALSE)
{
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + ~CXWindow
CXWindow::~CXWindow() {
	LOG();
	
	///bDeleteFont();
}
//---------------------------------------------------------------------------
//TODO: + lpProcessMessage
LRESULT CXWindow::lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	/*virtual*/
	return ::DefWindowProc(_m_hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------
//TODO: + bIsWindow
BOOL CXWindow::bIsWindow() const {
	/*DEBUG*///not need

	return (NULL != _m_hWnd) && (INVALID_HANDLE_VALUE != _m_hWnd) && (FALSE != ::IsWindow(_m_hWnd));
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle
HWND CXWindow::hGetHandle() const { 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return _m_hWnd; 
}
//---------------------------------------------------------------------------
//TODO: + iGetID
INT CXWindow::iGetID() const {
	/*DEBUG*/XASSERT_RET(0 < _m_iID, 0);   

	return _m_iID;
}
//---------------------------------------------------------------------------
//TODO: + bSetID
BOOL CXWindow::bSetID(INT iID) {
	/*DEBUG*/XASSERT_RET(0 < iID, FALSE);   

	_m_iID = iID;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCreate
BOOL CXWindow::bCreate(INT iID, HWND hParent, const tstring &csClassName, const tstring &csText, 
					   INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulExStyle, LPVOID lpParam)
{
	/*DEBUG*/XASSERT_RET(NULL  == _m_hWnd,             FALSE);

	/*DEBUG*/XASSERT_RET(0     <  iID,                 FALSE);
	/*DEBUG*/XASSERT_RET(false == csClassName.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iLeft,               FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iTop,                FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iWidth,              FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iHeight,             FALSE);

	BOOL bRes = FALSE;
	HWND hWnd = NULL;

	hWnd = ::CreateWindowEx(_m_ulStyleEx | ulExStyle, 
							csClassName.c_str(), 
							csText.c_str(), 
							_m_ulStyle | ulStyle, 
							iLeft, iTop, iWidth, iHeight, 
							hParent, 
							(tstring::npos != csClassName.find(CXWINDOW_CONTROL_CLASS)) ? static_cast<HMENU>(NULL) : reinterpret_cast<HMENU>(iID),	/*���� - NULL, ������� - iID*/ 
							CXApplication::hGetInstance(), 
							lpParam);
	/*DEBUG*/XASSERT_RET(NULL != hWnd, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_hWnd       = hWnd;
	_m_iID        = iID;
	_m_sClassName = _m_sClassName;
	_m_hParentWnd =	hParent;	
	_m_sText      = csText;
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;
	_m_ulStyleEx  = _m_ulStyleEx | ulExStyle;    
	_m_ulStyle    = _m_ulStyle   | ulStyle;
	////_m_iMenu  = iMenu;

	//-------------------------------------
	//��������� �����
    bRes = bSetDefaultFont();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE; 
}
//---------------------------------------------------------------------------
//TODO: + bShow
BOOL CXWindow::bShow(INT iCmdShow) const {
	/*DEBUG*/////XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	INT  iRes = - 1;
	BOOL bRes = FALSE;

	iRes = ::ShowWindow(_m_hWnd, iCmdShow);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	bRes = bUpdate();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUpdate
BOOL CXWindow::bUpdate()const  {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::UpdateWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO + bMove
BOOL CXWindow::bMove(INT iLeft, INT iTop, INT iWidth, INT iHeight) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::MoveWindow(_m_hWnd, iLeft , iTop , iWidth , iHeight, TRUE);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO + bMoveCenter
BOOL CXWindow::bMoveCenter(HWND hParentWnd) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	RECT rcDlg     = {0};
	RECT rcWnd     = {0};
	RECT rcDesktop = {0};
	INT  iLeft     = 0;
	INT  iTop      = 0;
	INT  iWidth    = 0;
	INT  iHeight   = 0;

	::GetWindowRect(_m_hWnd,    &rcDlg);
	::GetWindowRect(hParentWnd, &rcWnd);

	iWidth  = rcDlg.right  - rcDlg.left;
	iHeight = rcDlg.bottom - rcDlg.top;

	bRes = ::SystemParametersInfo(SPI_GETWORKAREA, 0, &rcDesktop, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	iLeft = rcWnd.left + ((rcWnd.right - rcWnd.left - iWidth) / 2);

	if (iLeft < 0) {
	    iLeft = 0;
	} else {
		if (iLeft + iWidth > (rcDesktop.right - rcDesktop.left)) {
			iLeft = rcDesktop.right - rcDesktop.left - iWidth;
		}
	}

	iTop = rcWnd.top + ((rcWnd.bottom - rcWnd.top - iHeight) / 2);

	if (iTop < 0) {
		iTop = 0;
	} else {
		if (iTop + iHeight > (rcDesktop.bottom - rcDesktop.top)) {
			iTop = rcDesktop.bottom - rcDesktop.top - iHeight;
		}
	}

	bRes = bSetPos(iLeft, iTop, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
	/*DEBUG*/CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetPos
BOOL CXWindow::bSetPos(INT iLeft, INT iTop, INT iWidth, INT iHeight, UINT uiFlags) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::SetWindowPos(_m_hWnd, 0, iLeft, iTop, iWidth, iHeight, uiFlags);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: + bEnable
BOOL CXWindow::bEnable(BOOL bFlag) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::EnableWindow(_m_hWnd, bFlag);
	/*DEBUG*/XASSERT_RET(0 == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - lSendMessage
LRESULT CXWindow::lSendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LRESULT lpRes = FALSE;

	lpRes = ::SendMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*///not need

	return lpRes;
}
//---------------------------------------------------------------------------
//TODO: + bPostMessage
BOOL CXWindow::bPostMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDestroy
BOOL CXWindow::bDestroy() const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::DestroyWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL CXWindow::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return bPostMessage(WM_CLOSE, NULL, NULL);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_pWndProc
LRESULT CXWindow::_s_pWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	CXWindow *pWnd = NULL;

	switch (uiMsg) {
		////case WM_INITDIALOG:
		////	{
		////		::SetWindowLong(hWnd, GWL_USERDATA, (LONG)lParam);
		////		pWnd = (CXWindow *)lParam;										//������� ��������� �� �����
		////		/*DEBUG*/XASSERT(NULL != pWnd);
		////		pWnd->_m_hWnd = hWnd;
		////	}
		////	break;

		case WM_NCCREATE:
			{
				LONG ulNewLong = 0;

				ulNewLong = reinterpret_cast<INT>  ( ( reinterpret_cast<LPCREATESTRUCT>(lParam) )->lpCreateParams ); 
				::SetWindowLong(hWnd, GWL_USERDATA, ulNewLong);
				pWnd      = static_cast<CXWindow *>( ( reinterpret_cast<LPCREATESTRUCT>(lParam) )->lpCreateParams );	//������� ��������� �� �����
				/*DEBUG*/XASSERT(NULL != pWnd);
				pWnd->_m_hWnd = hWnd;
			}
			break;

		default:
			{
				//������� ��������� �� �����
				pWnd = reinterpret_cast<CXWindow *>(::GetWindowLong(hWnd, GWL_USERDATA)); 
				/*DEBUG*///not need
			}
			break;
	}

	if (NULL != pWnd) {
		return pWnd->lpProcessMessage(uiMsg, wParam, lParam);
	}

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + _bInitCommonControls
BOOL CXWindow::_bInitCommonControls(ULONG ulFlags) {		/*static*/
	BOOL bRes = FALSE;

	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = ulFlags;

	bRes = ::InitCommonControlsEx(&iccx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bRegisterClass(const WNDCLASSEX *cpwcWndClassEx) {		/*static*/
	/*DEBUG*/XASSERT_RET(NULL != cpwcWndClassEx, FALSE);

	BOOL bRes = FALSE;

	bRes = ::RegisterClassEx(cpwcWndClassEx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bUnregisterClass(const tstring &csClassName) {		/*static*/
	/*DEBUG*///XASSERT_RET(false != csClassName.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::UnregisterClass(csClassName.c_str(), CXApplication::hGetInstance());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	�����
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetFont
HFONT CXWindow::hGetFont() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	HFONT hFont = NULL;

	hFont = reinterpret_cast<HFONT>(lSendMessage(WM_GETFONT, 0, 0));
	/*DEBUG*/XASSERT_RET(NULL != hFont, NULL);	//NULL if the control is using the system font.

	return hFont;
}
//---------------------------------------------------------------------------
//TODO: + bSetFont
BOOL CXWindow::bSetFont(HFONT hFont) {
	/*DEBUG*/XASSERT_RET(NULL != hFont, FALSE);

	BOOL bRes = FALSE;

	//TODO: reinterpret_cast
	bRes = (BOOL)lSendMessage(WM_SETFONT, (WPARAM)hFont, /*MAKELPARAM(TRUE, 0)*/TRUE);	
	/*DEBUG*///not return a value

	_m_hFont = hFont;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetDefaultFont
BOOL CXWindow::bSetDefaultFont() {
	/*DEBUG*///not need

	//_m_hFont = ::CreateFont(- 11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
	//					      OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	_m_hFont = ::CreateFont(- 11, 0, 0, 0, 400, 0, 0, 0, 0xCC, 0, 0, 0, DEFAULT_PITCH, /*_T("Arial Black")*/_T("Tahoma"));
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	return bSetFont(_m_hFont);
}
//---------------------------------------------------------------------------
//TODO: + bDeleteFont
BOOL CXWindow::bDeleteFont() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, FALSE);

	BOOL bRes = FALSE;

	bRes = ::DeleteObject(_m_hFont);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------