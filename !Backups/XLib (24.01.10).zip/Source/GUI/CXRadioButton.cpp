/****************************************************************************
* Class name:  CXRadioButton
* Description: 
* File name:   CXRadioButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXRadioButton.h>
//---------------------------------------------------------------------------
//TODO: CXRadioButton
CXRadioButton::CXRadioButton() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXRADIOBUTTON_CONTROL_CLASS;
	_m_ulStyle        = CXRADIOBUTTON_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = CXRADIOBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXRADIOBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = CXRADIOBUTTON_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
//TODO: ~CXRadioButton
CXRadioButton::~CXRadioButton() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXRadioButton::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
		CXResources::sGetText(iID), 
		CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
		CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
		CXResources::ulGetStyle(iID), 
		CXResources::ulGetStyleEx(iID),
		this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bIsChecked
BOOL CXRadioButton::bIsChecked() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);
	
	BOOL bRes = FALSE;
	
	bRes = (BOOL)lSendMessage(BM_GETCHECK, 0, 0) == BST_CHECKED;
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bCheck
BOOL CXRadioButton::bCheck(BOOL bChecked) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	lSendMessage(BM_SETCHECK, bChecked ? BST_CHECKED : BST_UNCHECKED, 0);
	/*DEBUG*/
	
	return TRUE;
}
//---------------------------------------------------------------------------