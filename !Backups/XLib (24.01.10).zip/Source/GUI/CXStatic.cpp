/****************************************************************************
* Class name:  CXStatic
* Description: ������ � ����������� �����
* File name:   CXStatic.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:20:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXStatic.h>
//---------------------------------------------------------------------------
//TODO: + CXStatic
CXStatic::CXStatic() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXSTATIC_CONTROL_CLASS;
	_m_ulStyle        = CXSTATIC_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = CXSTATIC_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXSTATIC_DEFAULT_WIDTH;
	_m_iHeight        = CXSTATIC_DEFAULT_HEIGHT;

	_m_bIsControl = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXStatic
CXStatic::~CXStatic() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXStatic::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
							 CXResources::sGetText    (iID), 
							 CXResources::iGetLeft    (iID), CXResources::iGetTop(iID), 
							 CXResources::iGetWidth   (iID), CXResources::iGetHeight(iID), 
							 CXResources::ulGetStyle  (iID), 
							 CXResources::ulGetStyleEx(iID),
							 this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------