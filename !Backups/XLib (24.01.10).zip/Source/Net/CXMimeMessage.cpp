/****************************************************************************
* Class name:  CXMimeMessage
* Description: �������� ��������� (RFC 822)
* File name:   CXMimeMessage.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.07.2009 19:09:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Net/CXMimeMessage.h>
//---------------------------------------------------------------------------
CXMimeMessage::CXMimeMessage() {
	//code
}
//---------------------------------------------------------------------------
CXMimeMessage::~CXMimeMessage() {
	//code
}
//---------------------------------------------------------------------------
/*static*/BOOL CXMimeMessage::bParse(const tstring &csRawMessage, CXMimeHeader &Header, CXMimeBody &Body) {
	BOOL bRes = FALSE;
	
	//m_Header;
	//m_Body;
	
	return FALSE;
}
//---------------------------------------------------------------------------
/*static*/BOOL	bLoadFromRawFile(const tstring &csFilePath) {
	BOOL bRes = FALSE;

	return FALSE;
}
//---------------------------------------------------------------------------
/*static*/BOOL bSaveToRawFile  (const tstring &csFilePath) {
	BOOL bRes = FALSE;

	return FALSE;
}
//---------------------------------------------------------------------------