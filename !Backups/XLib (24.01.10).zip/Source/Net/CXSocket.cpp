/****************************************************************************
* Class name:  CXSocket
* Description: 
* File name:   CXSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/Net/CXSocket.h> 

#include <iostream> 
#include <XLib/CXString.h>   
//---------------------------------------------------------------------------  
//TODO: + CXSocket
CXSocket::CXSocket() :
	_m_puiSocket(INVALID_SOCKET)
{   
	bSetTimeout(0, COptions::SOCKET_TIMEOUT);
} 
//---------------------------------------------------------------------------  
//TODO: + CXSocket
CXSocket::CXSocket(SOCKET puiSocket) :
	_m_puiSocket(puiSocket)
{  
    bSetTimeout(0, COptions::SOCKET_TIMEOUT);
}   
//---------------------------------------------------------------------------   
//TODO: + ~CXSocket
CXSocket::~CXSocket() {
	/*DEBUG*//////////XASSERT(INVALID_SOCKET == _m_puiSocket);
}   
//---------------------------------------------------------------------------


/****************************************************************************
* operators
*
*****************************************************************************/

//--------------------------------------------------------------------------- 
//TODO: + operator =
CXSocket& CXSocket::operator = (SOCKET puiSocket) {   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != puiSocket, (*this)); //?????????????7

	_m_puiSocket = puiSocket;  

	return *this;   
}   
//--------------------------------------------------------------------------- 
//TODO: + operator SOCKET
CXSocket::operator SOCKET () {   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket, INVALID_SOCKET);

	return _m_puiSocket;   
} 
//---------------------------------------------------------------------------


/****************************************************************************
* 
*
*****************************************************************************/
  
//--------------------------------------------------------------------------- 
//TODO: bCreate
BOOL CXSocket::bCreate(INT iAf, INT iType, INT iProtocol) {
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET == _m_puiSocket, FALSE);

	//socket - [+] socket returns a descriptor referencing the new socket. [-] INVALID_SOCKET
	_m_puiSocket = ::socket(iAf, iType, iProtocol);   
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

	return TRUE;   
}  
//---------------------------------------------------------------------------
//TODO: bIoctl (The ioctlsocket function controls the I/O mode of a socket.)
BOOL CXSocket::bIoctl(LONG liCmd, ULONG *pulArgp) {
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

	INT iRes = etError;

	iRes = ::ioctlsocket(_m_puiSocket, liCmd, pulArgp);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetNonBlockingMode
BOOL CXSocket::bSetNonBlockingMode(const BOOL cbFlag) {
	BOOL bRes = FALSE;

#ifdef WIN32	
	ULONG ulNonBlockingMode = static_cast<ULONG>(cbFlag);
	bRes = bIoctl(FIONBIO, static_cast<ULONG FAR *>(&ulNonBlockingMode));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 
#else
	INT opts;

	opts = fcntl(m_sock, F_GETFL);

	if (opts < 0) { 
		return FALSE; 
	}

	if (cbFlag) {
		opts = (opts | O_NONBLOCK);
	} else {
		opts = (opts & ~O_NONBLOCK);
	}

	fcntl(m_sock, F_SETFL, opts);
#endif

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsReadible
BOOL CXSocket::bIsReadable() {   
	timeval tvTimeout = {1, 0};     /*seconds, microseconds*/
	fd_set  fds       = {0};  FD_ZERO(&fds);   

	FD_SET(_m_puiSocket, &fds); 

	INT iStatus = etError;

	iStatus = ::select(0, &fds, NULL, NULL, &tvTimeout);   
	CHECK_RET(etError == iStatus || 0 == iStatus, FALSE);   

	return TRUE;
}  
//--------------------------------------------------------------------------- 
//TODO: + bConnect
BOOL CXSocket::bConnect(const std::string &csIp, USHORT usPort) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket,   FALSE);
	/*DEBUG*/XASSERT_RET(false          == csIp.empty(),   FALSE);
    /*DEBUG*/XASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);

	INT iRes = etError;
	
	struct sockaddr_in saSockAddr = {0};		   
	saSockAddr.sin_family      = AF_INET; 
	saSockAddr.sin_addr.s_addr = inet_addr(csIp.c_str());   
	saSockAddr.sin_port        = ::htons(usPort); //???????

	//connect - [+] 0 [-] SOCKET_ERROR
	iRes = ::connect(_m_puiSocket, (struct sockaddr *)&saSockAddr, sizeof(struct sockaddr_in));  
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;   
}   
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL CXSocket::bClose() {		
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

#ifdef WIN32 
	INT iRes = etError;

	//shutdown - [+] 0. [-] SOCKET_ERROR
	iRes = ::shutdown(_m_puiSocket, SD_BOTH);	 
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	//closesocket - [+] zero. [-] SOCKET_ERROR
	iRes = ::closesocket(_m_puiSocket); 
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	_m_puiSocket = etInvalid;

	return TRUE;
#else   
	return ::close(_m_puiSocket);   
#endif   
}   
//---------------------------------------------------------------------------
BOOL CXSocket::bSetTimeout(LONG liSec, LONG liMicroSec) {
	/*DEBUG*/

	_m_tvTimeout.tv_sec  = liSec;
	_m_tvTimeout.tv_usec = liMicroSec;

	return TRUE;
} 
//---------------------------------------------------------------------------
BOOL CXSocket::bGetTimeout(LONG *pliSec, LONG *pliMicroSec) {
	/*DEBUG*/

	*pliSec      = _m_tvTimeout.tv_sec;
	*pliMicroSec = _m_tvTimeout.tv_usec;

	return TRUE;
} 
//---------------------------------------------------------------------------


/****************************************************************************
* I/O
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: iSend
INT CXSocket::iSend(LPCSTR pcszBuff, INT iBuffSize, INT iFlags) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket,     etError);
	/*DEBUG*/XASSERT_RET(NULL           != pcszBuff,         etError);
	/*DEBUG*/XASSERT_RET(0              <  strlen(pcszBuff), etError);

	INT iRes = etError;         

#ifdef WIN32
	//send - [+] total number of bytes sent, which can be less than the number requested to be sent in the len parameter. [-] SOCKET_ERROR
	iRes = ::send(_m_puiSocket, pcszBuff, iBuffSize, iFlags);
	/*DEBUG*/XASSERT_RET(etError   != iRes && WSAEWOULDBLOCK != iGetLastError(), etError);  
	/*DEBUG*/XASSERT_RET(iBuffSize >= iRes,                                      etError); 
#else
	iRes = ::send(_m_puiSocket, pcszBuff, iBuffSize, MSG_NOSIGNAL);
#endif

	return iRes;   
} 
//---------------------------------------------------------------------------
//TODO: bSendAll
BOOL CXSocket::bSendAll(const std::string &csBuff, INT iFlags) { 
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket,   etError);
	/*DEBUG*/XASSERT_RET(false          == csBuff.empty(), etError);
	/*DEBUG*/XASSERT_RET(0              <  csBuff.size(),  etError);

	std::string  sRes;
	INT          iRes = etError;   

	//-------------------------------------
	//������ �� ������ ������� � ����� � ������
	INT iCurrPos  = 0;
	INT iLeftSize = csBuff.size();			//TODO: !!!!!!  bSendAll (overflow)

	//���� ������ ������ ������ ������� ������ - ������ ������ SOCKET_BUFF_SIZE
	INT iBuffOutSize  = 0;
	if (iLeftSize >= COptions::SOCKET_BUFF_SIZE) {
		iBuffOutSize = COptions::SOCKET_BUFF_SIZE;
	} else {
		iBuffOutSize = iLeftSize;
	}

	for (;;) {		/*uiLeftSize > 0*/
		iRes = iSend(&csBuff[0] + iCurrPos, iBuffOutSize, iFlags);  
		if (etError == iRes) {
			break;
		}
		if (0 == iRes) {
			break;
		}	

		iCurrPos  += iRes;
		iLeftSize -= iRes;

		if (iLeftSize < iBuffOutSize) {
			iBuffOutSize = iLeftSize;		
		}

		//���� ����������� ������, �� �������
		if (0 >= iLeftSize) {
			/*DEBUG*/XASSERT_RET(csBuff.size() == iCurrPos, FALSE);
			break;
		}
	} 

	return TRUE;    
} 
//---------------------------------------------------------------------------  
//TODO: + iRecv
INT CXSocket::iRecv(LPSTR pszBuff, INT iBuffSize, INT iFlags) {  
	/*DEBUG*/XASSERT_RET(INVALID_SOCKET != _m_puiSocket, etError);
	/*DEBUG*/XASSERT_RET(NULL           != pszBuff,      etError);
	/*DEBUG*/XASSERT_RET(0              < iBuffSize,     etError);

	INT iRes = etError;
	::ZeroMemory(pszBuff, iBuffSize);	//����� ������� �������� �����

	//recv - [+] number of bytes received and the buffer pointed to by the buf parameter will contain this data received. [-] SOCKET_ERROR [-] 0 gracefully closed 
	iRes = ::recv(_m_puiSocket, pszBuff, iBuffSize, iFlags);
	/*DEBUG*/XASSERT_RET(etError != iRes && WSAEWOULDBLOCK != iGetLastError(), etError);
	/*DEBUG*/////XASSERT_RET(0            != iRes, etError);
	/*DEBUG*/XASSERT_RET(iBuffSize >= iRes,                                    etError);

	return iRes;   
}   
//--------------------------------------------------------------------------- 
//TODO: + sRecvBytes (��������� ������ �� ������ ������)
std::string CXSocket::sRecvAll(INT iFlags) {
	std::string  sRes                    = "";
	BOOL         bRes                    = FALSE;
	
	const size_t cuiBuffSize             = 1024;
	CHAR         szBuff[cuiBuffSize + 1] = {0};

	for (;;) {
		ULONG ulArg = (ULONG)FALSE;    
		if (0 != ::ioctlsocket(_m_puiSocket, FIONREAD, &ulArg)) {
			break;
		}
		
		if (0 == ulArg) {
			break;
		}

		if (cuiBuffSize < ulArg) {
		    ulArg = cuiBuffSize;
		}

		INT iRes = ::recv(_m_puiSocket, szBuff, ulArg, 0);
		if (iRes <= 0) {
			break;
		}

		sRes.append(std::string(szBuff, iRes));
	}

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + sRecvBytes (��������� ������ �� �����������, ���. ���)
std::string CXSocket::sRecvAll(INT iFlags, const std::string &csDelimiter) {   
	std::string  sRes      = "";
	INT          iRes      = etError;   
	const size_t cuiInSize = COptions::SOCKET_BUFF_SIZE;
	std::string  sIn(cuiInSize, '\0');

	//-------------------------------------
	//������ �� ������ ������� � ����� � ������
	for (;;) {   
		iRes = iRecv(&sIn[0], cuiInSize, iFlags);  
		if (etError == iRes) {
			break;
		}
		if (0 == iRes) {
			break;
		}	

		sRes.append(sIn.begin(), sIn.begin() + iRes);
		
		//���� ����� �����������, �� �������
		size_t uiDelimiterPos = std::string::npos;

		uiDelimiterPos = sRes.find(csDelimiter);
		if (std::string::npos != uiDelimiterPos) {
			break;
		}
	} 
	
	return sRes;  
} 
//---------------------------------------------------------------------------
//TODO: SendNBytes
INT CXSocket::iSendBytes(LPSTR pszBuff, INT iMessageLength) {
	INT     iRC         = 0;
	INT     iSendStatus = 0;
	timeval SendTimeout = {0};

	//��������� �������� ��������
	SendTimeout.tv_sec  = 0;
	SendTimeout.tv_usec = COptions::SOCKET_TIMEOUT;              

	fd_set fds          = {0};
	FD_ZERO(&fds);
	FD_SET(_m_puiSocket, &fds);

	//..�� ��� ���, ���� ��� ����� �������� ������...
	while (iMessageLength > 0) {
		iRC = ::select(0, NULL, &fds, NULL, &SendTimeout);

		//����� �������, ������� ������
		if (!iRC) {
			return etError;
		}

		//��������� ������
		if (iRC < 0) {
			return ::WSAGetLastError();
		}

		//��������� ��������� ����
		iSendStatus = ::send(_m_puiSocket, pszBuff, iMessageLength, 0);   

		//��������� ������ � ������ �������� ������
		if (iSendStatus < 0) {
			return ::WSAGetLastError();
		} else {
			//�������� ����� � �������
			iMessageLength -= iSendStatus;
			pszBuff        += iSendStatus;
		}
	}

	return 0;
}
//---------------------------------------------------------------------------
//TODO: ReceiveNBytes
INT CXSocket::iReceiveBytes(LPSTR pszBuff, INT iStillToReceive) {
	INT     iRC               = 0;
	INT     iReceiveStatus    = 0;
	timeval ReceiveTimeout    = {0};

	//��������� �������� ��������
	ReceiveTimeout.tv_sec  = 0;
	ReceiveTimeout.tv_usec = COptions::SOCKET_TIMEOUT;             //500 ms

	fd_set fds                = {0};
	FD_ZERO(&fds);
	FD_SET(_m_puiSocket, &fds);

	//..���� ������ �� �������..
	while (iStillToReceive > 0) {
		iRC = ::select(0, &fds, NULL, NULL, &ReceiveTimeout);

		//����� �� ��������
		if (!iRC) {
			return etError;
		}

		//��������� ����� �� ������
		if (iRC < 0) {
			return ::WSAGetLastError();
		}

		//����� ���������� ����
		iReceiveStatus = ::recv(_m_puiSocket, pszBuff, iStillToReceive, 0);

		//��������� ������ � ������ ������� recv()
		if (iReceiveStatus < 0) {
			return ::WSAGetLastError();
		} else {
			//�������� �������� �������� � �����
			iStillToReceive -= iReceiveStatus;
			pszBuff         += iReceiveStatus;
		}
	}

	return 0;
}
//---------------------------------------------------------------------------


/****************************************************************************
* static 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bInit (Init winsock DLL) 
/*static*/BOOL CXSocket::bInit() {  
	INT     iRes    = etError;
	WSADATA wsaData = {0};

	//WSAStartup - [+] returns zero. [-] Otherwise, it returns one of the error codes listed below.
	iRes = ::WSAStartup(MAKEWORD(CVersion::m_cusVersion, CVersion::m_cusHighVersion), &wsaData);      
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	//-------------------------------------
	//Confirm that the WinSock DLL supports 2.2.
	if (CVersion::m_cusVersion != LOBYTE(wsaData.wVersion) || CVersion::m_cusHighVersion != HIBYTE(wsaData.wVersion)) {
		bClean(); 	

		/*DEBUG*/XASSERT_RET(FALSE, FALSE);
	} 

	return TRUE;   
}   
//--------------------------------------------------------------------------- 
//TODO: + bClean (Clean winsock DLL) 
/*static*/BOOL CXSocket::bClean() { 
	INT iRes = etError;

	//WSACleanup - [+] 0 [-] SOCKET_ERROR
	iRes = ::WSACleanup();
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	return TRUE;  
} 
//---------------------------------------------------------------------------
//TODO: + iGetLastError
/*static*/INT CXSocket::iGetLastError() {   
    return ::WSAGetLastError();   
}   
//--------------------------------------------------------------------------- 
//TODO: + bDnsParse
/////*static*/BOOL CXSocket::bDnsParse(const std::string &csDomain, std::string &sIp) {   
////    /*DEBUG*/XASSERT_RET(false == csDomain.empty(), FALSE);
////
////	std::string sRes;
////
////    struct hostent *pHostent = ::gethostbyname(csDomain.c_str()); 
////    /*DEBUG*/XASSERT_RET(NULL != pHostent, FALSE);
////
////    sRes = sFormatStrA("%u.%u.%u.%u",   
////					   static_cast<UCHAR>(pHostent->h_addr_list[0][0]),    
////					   static_cast<UCHAR>(pHostent->h_addr_list[0][1]),    
////					   static_cast<UCHAR>(pHostent->h_addr_list[0][2]),    
////					   static_cast<UCHAR>(pHostent->h_addr_list[0][3])
////    ); 
////	/*DEBUG*/XASSERT_RET(false == sRes.empty(), FALSE);
////
////	sIp.assign(sRes);
////
////    return TRUE;   
////}
/*static*/BOOL CXSocket::bDnsParse(const tstring &csDomain, tstring &sIp) {   
	/*DEBUG*/XASSERT_RET(false == csDomain.empty(), FALSE);

	tstring sRes;

	struct hostent *pHostent = ::gethostbyname(csDomain.c_str()); 
	/*DEBUG*/XASSERT_RET(NULL != pHostent, FALSE);

	sRes = sFormatStrA("%u.%u.%u.%u",   
		static_cast<UCHAR>(pHostent->h_addr_list[0][0]),    
		static_cast<UCHAR>(pHostent->h_addr_list[0][1]),    
		static_cast<UCHAR>(pHostent->h_addr_list[0][2]),    
		static_cast<UCHAR>(pHostent->h_addr_list[0][3])
	); 
	/*DEBUG*/XASSERT_RET(false == sRes.empty(), FALSE);

	sIp.assign(sRes);

	return TRUE;   
} 
//---------------------------------------------------------------------------
//TODO: + iSelect (determines the status of one or more sockets, waiting if necessary, to perform synchronous I/O.)
INT CXSocket::iSelect(INT nfds, fd_set *pReadfds, fd_set *pWritefds, fd_set *pExceptfds/*,  const struct timeval *pTimeout*/) {
	 /*DEBUG*/
	 
	 INT iRes = etError;
	 
	 iRes = ::select(nfds, pReadfds, pWritefds, pExceptfds, &_m_tvTimeout);
	 /*DEBUG*/XASSERT_RET(etError != iRes, etError);
	 /*DEBUG*/////XASSERT_RET(0       != iRes, 0);  //zero if the time limit expired

	return iRes;	 
}
//---------------------------------------------------------------------------











/*
INT CXSocket::WaitForData(SOCKET *pSocketForReceiving, SOCKET *pSocketForSending, SOCKET *pSocketForExceptions) {
	int nSocketsReady = 0;
	
	fd_set FdSetReceive;	FD_ZERO(&FdSetReceive);
	fd_set FdSetSend;   	FD_ZERO(&FdSetSend);
	fd_set FdSetError;  	FD_ZERO(&FdSetError);

	if (pSocketForReceiving) {
		FD_SET(*pSocketForReceiving, &FdSetReceive);
	}
	if (pSocketForSending) {
		FD_SET(*pSocketForSending, &FdSetSend);
	}
	if (pSocketForExceptions) {
		FD_SET(*pSocketForExceptions, &FdSetError);
	}

	TIMEVAL tv;
	TIMEVAL *ptv = NULL;

	if (_m_tvTimeout) {
		tv.tv_sec =  _m_tvTimeout / 1000;
		tv.tv_usec = _m_tvTimeout * 1000 - tv.tv_sec * 1000000;
		ptv = &tv;
	} else {
		ptv = NULL; // NULL for blocking operation (never times out)
	}

	nSocketsReady = select(0, &FdSetReceive, &FdSetSend, &FdSetError, ptv);

	//If the operation timed out, set a more natural error message
	if (nSocketsReady == 0) {
		SetLastError(WSAETIMEDOUT);
		nSocketsReady = SOCKET_ERROR;
	}

	return nSocketsReady;
}
*/



/*
procedure FlushRecvBufferUntil(s:TSOCKET;condition:Char);
var
	iReceiveRes : integer;
	cDummy : char;
	begin
repeat
	iReceiveRes := recv(s, cDummy, sizeof(cDummy), 0);
	until NOT ((iReceiveRes<>SOCKET_ERROR) and (iReceiveRes<>0) and
	(cDummy<>condition));
end;
*/



/*
//////-------------------------------------
//////��������� �������� ��������
////timeval ReceiveTimeout = {0};
////ReceiveTimeout.tv_sec  = 0;
////ReceiveTimeout.tv_usec = COptions::SOCKET_TIMEOUT;              

////fd_set fds = {0};
////FD_ZERO(&fds);
////FD_SET(_m_puiSocket, &fds);

//-------------------------------------
//������ �� ������

////FD_CLR(_m_puiSocket, &fds);
*/