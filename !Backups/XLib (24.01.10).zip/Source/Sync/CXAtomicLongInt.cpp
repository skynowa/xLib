/****************************************************************************
* Class name:  CXAtomicLongInt
* Description: ���������������� LONG
* File name:   CXAtomicLongInt.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.11.2009 10:03:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXAtomicLongInt.h>
#include <XLib/Debug/CXAssert.h>
//---------------------------------------------------------------------------
//TODO: + CXAtomicLongInt ()
CXAtomicLongInt::CXAtomicLongInt() : 
    _m_liValue(0)      
{ 
    ::InterlockedExchange(&_m_liValue, 0);
}
//---------------------------------------------------------------------------
//TODO: + ~CXAtomicLongInt ()
CXAtomicLongInt::~CXAtomicLongInt() {

}
//---------------------------------------------------------------------------
//TODO: + operator += ()
CXAtomicLongInt& CXAtomicLongInt::operator += (const CXAtomicLongInt &cRight) {
	::InterlockedExchangeAdd(&_m_liValue, cRight._m_liValue); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator -= ()
CXAtomicLongInt& CXAtomicLongInt::operator -= (const CXAtomicLongInt &cRight) {
	::InterlockedExchange(&_m_liValue, _m_liValue - cRight._m_liValue); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator = ()
CXAtomicLongInt& CXAtomicLongInt::operator = (const CXAtomicLongInt &cRight)	{
	::InterlockedExchange(&_m_liValue, cRight._m_liValue); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator += ()
CXAtomicLongInt& CXAtomicLongInt::operator += (const LONG cliRight) {
	::InterlockedExchangeAdd(&_m_liValue, cliRight); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator -= ()
CXAtomicLongInt& CXAtomicLongInt::operator -= (const LONG cliRight) {
	::InterlockedExchange(&_m_liValue, _m_liValue - cliRight); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator = ()
CXAtomicLongInt& CXAtomicLongInt::operator = (const LONG cliRight) {
	::InterlockedExchange(&_m_liValue, cliRight); 

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator == ()
BOOL CXAtomicLongInt::operator == (const CXAtomicLongInt &cRight) const {
	return _m_liValue == cRight._m_liValue;
}
//---------------------------------------------------------------------------
//TODO: + operator != ()
BOOL CXAtomicLongInt::operator != (const CXAtomicLongInt &cRight) const {
	return !(_m_liValue == cRight._m_liValue);
}
//---------------------------------------------------------------------------
//TODO: + operator == ()
BOOL CXAtomicLongInt::operator == (const LONG cliRight) const {
	return _m_liValue == cliRight;
}
//---------------------------------------------------------------------------
//TODO: + operator != ()
BOOL CXAtomicLongInt::operator != (const LONG cliRight) const {
	return !(_m_liValue == cliRight);
}
//---------------------------------------------------------------------------
//TODO: + operator LONG ()
CXAtomicLongInt::operator LONG () const {
	return _m_liValue;
}
//---------------------------------------------------------------------------
//TODO: + operator BOOL ()
CXAtomicLongInt::operator BOOL () const {
	return _m_liValue ? TRUE : FALSE; 
}
//---------------------------------------------------------------------------
//TODO: + operator ++ ()
CXAtomicLongInt& CXAtomicLongInt::operator ++ (INT iPos) {
	if (0 == iPos) {
		::InterlockedIncrement(&_m_liValue);    
	} else {
		::InterlockedExchangeAdd(&_m_liValue, iPos + 1);
	}

	return *this;
}
//---------------------------------------------------------------------------
//TODO: + operator -- ()
CXAtomicLongInt& CXAtomicLongInt::operator -- (INT iPos) {
	if (0 == iPos) {
		::InterlockedDecrement(&_m_liValue);
	} else {
		::InterlockedExchangeAdd(&_m_liValue, - (iPos + 1));
	}

	return *this;
}
//---------------------------------------------------------------------------