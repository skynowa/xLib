/****************************************************************************
* Class name:  CXCriticalSectionLocker
* Description: ������ � ������������ �������� � �����
* File name:   CXCriticalSectionLocker.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXCriticalSectionLocker.h>

/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXCriticalSectionLocker (�����������)
CXCriticalSectionLocker::CXCriticalSectionLocker(CXCriticalSection &csCS) : 
	_m_csCS(csCS) 
{
	_m_csCS.vEnter();
}
//---------------------------------------------------------------------------
//TODO: + CXCriticalSectionLocker (�����������)
CXCriticalSectionLocker::CXCriticalSectionLocker(CXCriticalSection &csCS, BOOL bTry) : 
	_m_csCS(csCS) 
{
	if (TRUE == bTry) {
		while (FALSE == _m_csCS.bTryEnter()) {
			::OutputDebugString(_T("bTryEnter is FALSE\n"));
			::Sleep(1000); 
		}
	} else {
		_m_csCS.vEnter();
	}
}
//---------------------------------------------------------------------------
//TODO: + ~CXCriticalSectionLocker (����������)
CXCriticalSectionLocker::~CXCriticalSectionLocker() {
	_m_csCS.vLeave();
}
//---------------------------------------------------------------------------