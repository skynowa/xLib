/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ ��������
* File name:   CXLockScope.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXCriticalSection.h>

/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXCriticalSection ()
CXCriticalSection::CXCriticalSection() {
	ZERO_BUFF(_m_CS);

	::InitializeCriticalSection(&_m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
//TODO: + CXCriticalSection ()
#if (_WIN32_WINNT >= 0x0403)
CXCriticalSection::CXCriticalSection(ULONG ulSpinCount) {
	/*DEBUG*///ulSpinCount - not need

	BOOL bRes = FALSE;	
	
	bRes = ::InitializeCriticalSectionAndSpinCount(&_m_CS, ulSpinCount);
	/*DEBUG*/XASSERT_DO(FALSE != bRes, return);
}
#endif
//---------------------------------------------------------------------------
//TODO: + ~CXCriticalSection ()
CXCriticalSection::~CXCriticalSection() {
	::DeleteCriticalSection(&_m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
//TODO: + vEnter ()
VOID CXCriticalSection::vEnter() {
	::EnterCriticalSection(&_m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
//TODO: + vLeave ()
VOID CXCriticalSection::vLeave() {
	::LeaveCriticalSection(&_m_CS);
	/*DEBUG*///not return
}
//---------------------------------------------------------------------------
//TODO: + ulSetSpinCount ()
#if (_WIN32_WINNT >= 0x0403)
ULONG CXCriticalSection::ulSetSpinCount(ULONG ulSpinCount) {
	/*DEBUG*///ulSpinCount - not need

	return ::SetCriticalSectionSpinCount(&_m_CS, ulSpinCount);
	/*DEBUG*///not need
}
#endif
//---------------------------------------------------------------------------
//TODO: + bTryEnter ()
#if(_WIN32_WINNT >= 0x0400)
BOOL CXCriticalSection::bTryEnter() {
	return ::TryEnterCriticalSection(&_m_CS);
	/*DEBUG*///not need
}
#endif
//---------------------------------------------------------------------------