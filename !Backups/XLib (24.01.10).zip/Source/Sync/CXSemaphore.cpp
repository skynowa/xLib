/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXSemaphore.h>
//---------------------------------------------------------------------------
//TODO: + CXSemaphore ()
CXSemaphore::CXSemaphore() {

}
//---------------------------------------------------------------------------
//TODO: + ~CXSemaphore ()
CXSemaphore::~CXSemaphore() {
	/*DEBUG*/XASSERT(FALSE != _m_hSemaphore.bIsValid());

	//--CLOSE_HANDLE(_m_hSemaphore);
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXSemaphore::hGetHandle() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), NULL);

	return _m_hSemaphore.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + bCreate (Creates or opens a named or unnamed semaphore object)
BOOL CXSemaphore::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(FALSE == _m_hSemaphore.bIsValid(),					  FALSE);
	/*DEBUG*///lpsaAttributes - not need
	/*DEBUG*/XASSERT_RET(0 <= liInitialCount && liInitialCount <= liMaxCount, FALSE);
	/*DEBUG*///pcszName       - The name is limited to MAX_PATH characters

	HANDLE hRes = NULL;

	hRes = ::CreateSemaphore(lpsaAttributes, liInitialCount, liMaxCount, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hSemaphore.m_hHandle = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXSemaphore::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), FALSE);
	/*DEBUG*///ulAccess - not need
	/*DEBUG*///pcszName - not need
	
	HANDLE hRes = NULL;

	hRes = ::OpenSemaphore(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	_m_hSemaphore.m_hHandle = hRes;
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bRelease ()
BOOL CXSemaphore::bRelease(LONG liReleaseCount, LONG *pliOldCount) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), FALSE);
	/*DEBUG*///liReleaseCount - not need
	/*DEBUG*///pliOldCount    - not need

	BOOL bRes = FALSE;
	
	bRes = ::ReleaseSemaphore(_m_hSemaphore.m_hHandle, liReleaseCount, pliOldCount);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXSemaphore::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - not need

	ULONG ulRes = WAIT_FAILED;

	ulRes = ::WaitForSingleObject(_m_hSemaphore.m_hHandle, ulTimeout); 
	/*DEBUG*/XASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + liGetValue ()
LONG CXSemaphore::liGetValue() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(), - 1);

	LONG liRes = - 1; 
	BOOL bRes  = FALSE;

	bRes = bRelease(0, &liRes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, - 1);

	return liRes; 
}
//---------------------------------------------------------------------------
//TODO: + bReset ()
BOOL CXSemaphore::bReset(LONG liInitialCount, LONG liMaxCount) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hSemaphore.bIsValid(),                   FALSE);
	/*DEBUG*/XASSERT_RET(0 <= liInitialCount && liInitialCount <= liMaxCount, FALSE);

	BOOL bRes = FALSE;

	//--CLOSE_HANDLE(_m_hSemaphore.m_hHandle); 
	bRes = _m_hSemaphore.bClose();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	bRes = bCreate(NULL, liInitialCount, liMaxCount, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------