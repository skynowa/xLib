/****************************************************************************
* Class name:  CXEvent
* Description: ������
* File name:   CXEvent.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 17:53:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXEvent.h>


//---------------------------------------------------------------------------
//TODO: + CXEvent (�����������)
CXEvent::CXEvent() {

}
//---------------------------------------------------------------------------
//TODO: + ~CXEvent (����������)
CXEvent::~CXEvent() {
	/*DEBUG*/XASSERT(FALSE != _m_hEvent.bIsValid());
	
	//--CLOSE_HANDLE(_m_hEvent);
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle (A handle to the event object)
HANDLE CXEvent::hGetHandle() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), NULL);
    
    return _m_hEvent.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + bCreate (Creates or opens a named or unnamed event object)
BOOL CXEvent::bCreate(LPSECURITY_ATTRIBUTES lpsaAttributes, BOOL bManualReset, BOOL bInitialState, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(FALSE == _m_hEvent.bIsValid(), FALSE);
	/*DEBUG*/

	HANDLE hRes = NULL;

	hRes = ::CreateEvent(lpsaAttributes, bManualReset, bInitialState, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	////--_m_hEvent = hRes;
	_m_hEvent.m_hHandle = hRes; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen (Opens an existing named event object)
BOOL CXEvent::bOpen(ULONG ulAccess, BOOL bInheritHandle, LPCTSTR pcszName) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), FALSE);		
	/*DEBUG*/
	
	HANDLE hRes = NULL;

	/*EVENT_MODIFY_STATE, EVENT_ALL_ACCESS, EVENT_MODIFY_STATE*/
	hRes = ::OpenEvent(ulAccess, bInheritHandle, pcszName);
	/*DEBUG*/XASSERT_RET(NULL != hRes, FALSE);

	////--_m_hEvent = hRes;
	_m_hEvent.m_hHandle = hRes; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPulse (Sets the specified event object to the signaled state and then resets it to the nonsignaled state after releasing the appropriate number of waiting threads)
BOOL CXEvent::bPulse() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), FALSE);		
	/*DEBUG*/
	
	BOOL bRes = FALSE;

	bRes = ::PulseEvent(_m_hEvent.m_hHandle);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReset (Sets the specified event object to the nonsignaled state)
BOOL CXEvent::bReset() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), FALSE);		
	/*DEBUG*/

	BOOL bRes = FALSE;

	bRes = ::ResetEvent(_m_hEvent.m_hHandle);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSet (Sets the specified event object to the signaled state) 
BOOL CXEvent::bSet() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), FALSE);		
	/*DEBUG*/

	BOOL bRes = FALSE;

	bRes = ::SetEvent(_m_hEvent.m_hHandle);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait (Waits until the specified event is in the signaled state or the time-out interval elapses)
BOOL CXEvent::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hEvent.bIsValid(), FALSE);		
	/*DEBUG*///not need

	//WAIT_OBJECT_0   ������ ������� � ��������� ���������� 
	//WAIT_TIMEOUT    ������  ��  �������  �  ���������  ����������  �� ��������� ������ ������� 
	//WAIT_ABANDONED  ������ ������� ���� �������� ��-�� ������ �� ���� 
	//WAIT_FAILED     ��������� ������

	ULONG ulRes = ::WaitForSingleObject(_m_hEvent.m_hHandle, ulTimeout); 
	/*DEBUG*///not need

	return (WAIT_OBJECT_0 == ulRes);
}
//---------------------------------------------------------------------------
//TODO: + bIsSignaled (�������� ���������)
BOOL CXEvent::bIsSignaled() const {
	/*DEBUG*///not need

	ULONG ulRes = ::WaitForSingleObject(_m_hEvent.m_hHandle, 0);  

	return (FALSE != _m_hEvent.bIsValid()) && (WAIT_OBJECT_0 == ulRes);
}
//---------------------------------------------------------------------------
