/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXThread.h>

#include <XLib/CXSystemInfo.h>
#include <XLib/CXString.h>

#if defined(_MT) || defined(_DLL)
#	include <process.h>
#endif // _MT


/****************************************************************************
*	[public]
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXThread (�����������)
CXThread::CXThread(BOOL bIsPaused, BOOL bIsAutoDelete, BOOL bIsUsingCOM) :
	//���������
	_m_culStillActiveTimeout(2L),	
	_m_culExitTimeout       (5000L),       

	//������ ������
	_m_ulID					(0L),
	_m_uiExitCode			(0),
	_m_pvParam				(NULL),
	_m_ptfStartAddress		(0),
	_m_cbIsAutoDelete		(bIsAutoDelete),

	//��������� �������
	_m_bIsCreated			(FALSE),
	_m_bIsRunning			(FALSE),
	_m_bIsPaused			(bIsPaused/*TRUE == bIsPaused ? CREATE_SUSPENDED : 0*/),
	_m_bIsSleeping			(FALSE),
#ifdef defVarPolicy
	_m_bIsExited			(FALSE),
#else 
	//...
#endif

	//
	///_vOnExit                (NULL),

	//���������     
	_m_pevStarter			(NULL),
	_m_cbIsUsingCOM         (bIsUsingCOM),
	_m_pcomCOM              (NULL)
{
	////this->hMainThread	= ::GetCurrentThread ();
	////this->hMainThreadId = ::GetCurrentThreadId ();   
}
//---------------------------------------------------------------------------
//TODO: + ~CXThread (����������)
/*virtual*/ CXThread::~CXThread() {
	/*DEBUG*/

	BOOL bRes = FALSE;

    //-------------------------------------
	//��������� �����, ���� �� �������� - ??? typa na vsykiy sluchay???
	bRes = bIsRunning();
	if (TRUE == bRes) {
		bRes = bExit(_m_culExitTimeout);   
		if (FALSE == bRes) {
            bKill(_m_culExitTimeout);
		}
	}

	//-------------------------------------
	//��������� �������
	_vSetDefaultStates();
}
//---------------------------------------------------------------------------

/****************************************************************************
*	��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bCreate (������ ������)
BOOL CXThread::bCreate(UINT uiStackSize, const pThreadProc ptfStartAddress, VOID *pvParam) {
	/*DEBUG*/XASSERT_RET(FALSE == _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///uiStackSize  - not need
	/*DEBUG*///ptfStartAddr - not need
	/*DEBUG*///pvParam      - not need

	BOOL   bRes = FALSE;
	HANDLE hRes = NULL;

	_m_ptfStartAddress = ptfStartAddress;
	_m_pvParam         = pvParam; 

	//-------------------------------------
	//_m_evStarter
	_m_pevStarter = new CXEvent();
	/*DEBUG*/XASSERT_RET(NULL != _m_pevStarter, FALSE);

	bRes = _m_pevStarter->bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

#ifdef _MT              
	hRes = reinterpret_cast<HANDLE>(_beginthreadex(NULL, uiStackSize, _s_uiStartFunc, this, 0, xreinterpret_cast<UINT *>(&_m_ulID)));
#else
	hRes = ::CreateThread(NULL, uiStackSize, xreinterpret_cast<LPTHREAD_START_ROUTINE>(_s_uiStartFunc), this, 0, &_m_ulID);
#endif 
	/*DEBUG*/XASSERT_RET(NULL != hRes,    FALSE);
	/*DEBUG*/XASSERT_RET(0    <  _m_ulID, FALSE);

	_m_hThread/*.m_hHandle*/ = hRes;

	//-------------------------------------
	//_m_evPause
	bRes = _m_evPause.bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	bRes = _m_evExit.bCreate(NULL, FALSE, FALSE, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	_m_bIsCreated = TRUE;
	_m_bIsRunning = TRUE;
	/*_m_bIsPaused*/
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/	

	//-------------------------------------
	//������� ����� ����� �������������
	bRes = _m_pevStarter->bSet();  
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bResume (�������������)
BOOL CXThread::bResume() {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);    

	BOOL bRes = FALSE;

	bRes = _m_evPause.bSet();  
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	_m_bIsPaused = FALSE;
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPause (�����)
BOOL CXThread::bPause() {
	/*DEBUG*/XASSERT_MSG_RET(FALSE != _m_hThread.bIsValid(), lexical_cast(_m_hThread.m_hHandle).c_str(), FALSE); 

	BOOL Res = FALSE;

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	_m_bIsPaused = TRUE;
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExit (����� �� ������ - ��������� ����� ������ �� ������)
BOOL CXThread::bExit(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - not need

	BOOL bRes = FALSE;
	
	//-------------------------------------
	//��������� �������
#ifdef defVarPolicy
	_m_bIsExited = TRUE;
#else 
	_m_evExit.bSet();					
#endif
	/*_m_bIsCreated*/	
	/*_m_bIsRunning*/
	/*_m_bIsPaused*/	CHECK_DO(TRUE == bIsPaused(),   bResume());		//���� ����� ���������������� (bPause) - ������������
	/*_m_bIsSleeping*/	CHECK_DO(TRUE == bIsSleeping(), bBreakSleep());	//���� ����� ����             (bSleep) - �����
	                                                                    //���� ������� ����-�� 
	//-- ���� ���� ���� --
	////bRes = bWait(ulTimeout);
	/////*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bKill (����������� ������)
BOOL CXThread::bKill(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);        
	/*DEBUG*///ulTimeout - not need

	ULONG ulRes = 0;
	BOOL  bRes  = FALSE;

	_m_uiExitCode = 0;
	bRes = ::TerminateThread(_m_hThread.m_hHandle, _m_uiExitCode);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	for (;;) {
		ulRes = ulGetExitCode();
		CHECK_DO(STILL_ACTIVE != ulRes, break);            

		bSleep(_m_culStillActiveTimeout);
	}

	//-- ���� ���� ���� --
	////bRes = bWait(ulTimeout); //TODO: - 
	/////*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	_m_uiExitCode = ulRes;

	//-------------------------------------
	//������ ��������
	////CLOSE_HANDLE(_m_hThread);
	_m_ulID            = 0;
	//_m_uiExitCode    = 0;	//???
	_m_ptfStartAddress = 0;
	_m_pvParam         = NULL;
	//_m_bIsAutoDelete - not need 

	//-------------------------------------
	//��������� �������
	_vSetDefaultStates();

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait (�������� ������)
BOOL CXThread::bWait(ULONG ulTimeout) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*///ulTimeout - not need

	//-------------------------------------
	//��������� �������
	//?????????

	XASSERT(CXThread::ulGetCurrId() != _m_ulID);		//TODO: ?????
	CHECK_RET(CXThread::ulGetCurrId() == _m_ulID, TRUE);		//TODO: ?????

	ULONG ulRes = WAIT_FAILED;
	ulRes = ::WaitForSingleObject(_m_hThread.m_hHandle, ulTimeout); 
	/*DEBUG*/XASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	����� ��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsCreated (������ �� �����)
BOOL CXThread::bIsCreated() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	return _m_bIsCreated;
}
//---------------------------------------------------------------------------
//TODO: + bIsRunning (�������� ���������� ������)
BOOL CXThread::bIsRunning() const {
	/*DEBUG*///_m_hThread - not need

	BOOL bRes = FALSE;
	
	/*
	return  ( FALSE         != _m_hThread.bIsValid()             ) && 
			( 0L            <  _m_ulID                              ) &&
			( TRUE          == _m_bIsRunning                        ) &&
			( WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread.m_hHandle, 0) ) && 
			( STILL_ACTIVE  == ulGetExitCode()                      ); 
	*/

	BOOL bCond1 = ( FALSE         != _m_hThread.bIsValid()                );		
	BOOL bCond2 = ( 0L            <  _m_ulID                              );
	BOOL bCond3 = ( TRUE          == _m_bIsRunning                        );
	/*BOOL bCond4 = ( WAIT_OBJECT_0 != ::WaitForSingleObject(_m_hThread.m_hHandle, 0) );*/ 
	/*BOOL bCond5 = ( STILL_ACTIVE  == ulGetExitCode()                      );*/

	bRes = bCond1 && bCond2 && bCond3 /*&& bCond4 && bCond5*/;

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + bIsPaused (������������� �� �����)
BOOL CXThread::bIsPaused() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	return _m_bIsPaused;
}
//---------------------------------------------------------------------------
//TODO: + bIsSleeping (���� �� �����)
BOOL CXThread::bIsSleeping() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	return _m_bIsSleeping;
}
//---------------------------------------------------------------------------
//TODO: + bIsExited (��������� �� ���� ������ ��� ������)
BOOL CXThread::bIsExited() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), TRUE);

#ifdef defVarPolicy
	return _m_bIsExited;
#else 
	return _m_evExit.bIsSignaled();
#endif
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bPostMessage (������� ��������� �� ������ � ����)
BOOL CXThread::bPostMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);		
	/*DEBUG*/XASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSendMessage (������� ��������� �� ������ � ����)
BOOL CXThread::bSendMessage(HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/XASSERT_RET(NULL  != hHwnd,                 FALSE);
	/*DEBUG*/XASSERT_RET(FALSE != ::IsWindow(hHwnd),     FALSE);

	::SendMessage(hHwnd, uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*///- not need 
	/*DEBUG*/XASSERT(0 == ::GetLastError());

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bPostThreadMessage (������� ��������� � �����)
BOOL CXThread::bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::PostThreadMessage(ulGetId(), uiMsg, static_cast<WPARAM>(iParam1), static_cast<WPARAM>(iParam2));
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMessageWaitQueue (�������� ��������� c ����������� �� ������� ������)
BOOL CXThread::bMessageWaitQueue(UINT uiMsg, INT *piParam1, INT *piParam2) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE);
	/*DEBUG*/XASSERT_RET(0    <  uiMsg,                  FALSE);

	BOOL bRes   = - 1;
	MSG  msgMsg = {0};

	while (bRes = ::GetMessage(&msgMsg, NULL, 0, 0 )) {
		if (- 1 == bRes) {
			/*DEBUG*/XASSERT_RET(FALSE, FALSE);
			break;
		}

		if (uiMsg == msgMsg.message) {
			if (NULL != piParam1) {
				*piParam1 = static_cast<INT>(msgMsg.lParam);
			}

			if (NULL != piParam2) {
				*piParam2 = static_cast<INT>(msgMsg.wParam);
			}

			break;
		}

		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetPriority (��������� ���������� ������)
BOOL CXThread::bSetPriority(EPriority tpPriority) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriority(_m_hThread.m_hHandle, tpPriority);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iGetPriority (��������� ���������� ������)
CXThread::EPriority CXThread::tpGetPriority() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), PRIORITY_ERROR); 

	CXThread::EPriority tpRes = PRIORITY_ERROR;

	tpRes = static_cast<EPriority>(::GetThreadPriority(_m_hThread.m_hHandle));
	/*DEBUG*/XASSERT_RET(PRIORITY_ERROR != tpRes, PRIORITY_ERROR);

	return tpRes;
}
//---------------------------------------------------------------------------
//TODO: + sGetPriorityString (��������� ���������� ������ ��� ������)
tstring CXThread::sGetPriorityString() const {
	/*DEBUG*///not need

	switch ( tpGetPriority() ) {
		case PRIORITY_ABOVE_NORMAL:		return _T("Above normal");
		case PRIORITY_BELOW_NORMAL:		return _T("Below normal");
		case PRIORITY_HIGHEST:			return _T("Highest");
		case PRIORITY_IDLE:				return _T("Idle");
		case PRIORITY_LOWEST:			return _T("Lowest");
		case PRIORITY_NORMAL:			return _T("Normal");
		case PRIORITY_TIME_CRITICAL:	return _T("Time critical");
	}

	return _T("N/A");
}
//---------------------------------------------------------------------------
//TODO: + bPriorityUp (��������� ���������� �� ���� �������)
BOOL CXThread::bPriorityUp() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = PRIORITY_ERROR;
	EPriority tpiNewLevel = PRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case PRIORITY_TIME_CRITICAL:	return TRUE;							break;
		case PRIORITY_HIGHEST: 		    tpiNewLevel = PRIORITY_TIME_CRITICAL;	break;
		case PRIORITY_ABOVE_NORMAL: 	tpiNewLevel = PRIORITY_HIGHEST;			break;
		case PRIORITY_NORMAL: 			tpiNewLevel = PRIORITY_ABOVE_NORMAL;	break;
		case PRIORITY_BELOW_NORMAL: 	tpiNewLevel = PRIORITY_NORMAL;			break;
		case PRIORITY_LOWEST: 			tpiNewLevel = PRIORITY_BELOW_NORMAL;	break;
		case PRIORITY_IDLE: 			tpiNewLevel = PRIORITY_LOWEST;			break;

		default:			/*XASSERT*/XASSERT_RET(FALSE, PRIORITY_NORMAL);		break;
	}

	return bSetPriority(tpiNewLevel);
} 
//---------------------------------------------------------------------------
//TODO: + bPriorityDown (��������� ���������� �� ���� �������)
BOOL CXThread::bPriorityDown() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	EPriority tpOldLevel  = PRIORITY_ERROR;
	EPriority tpiNewLevel = PRIORITY_ERROR;

	tpOldLevel = tpGetPriority();
	switch (tpOldLevel) {
		case PRIORITY_TIME_CRITICAL:	tpiNewLevel = PRIORITY_HIGHEST;			break;
		case PRIORITY_HIGHEST: 			tpiNewLevel = PRIORITY_ABOVE_NORMAL;	break;
		case PRIORITY_ABOVE_NORMAL: 	tpiNewLevel = PRIORITY_NORMAL;			break;
		case PRIORITY_NORMAL: 			tpiNewLevel = PRIORITY_BELOW_NORMAL;	break;
		case PRIORITY_BELOW_NORMAL: 	tpiNewLevel = PRIORITY_LOWEST;			break;
		case PRIORITY_LOWEST: 			tpiNewLevel = PRIORITY_IDLE;			break;
		case PRIORITY_IDLE: 			return TRUE;							break;

		default:			/*XASSERT*/XASSERT_RET(FALSE, PRIORITY_NORMAL);		break;
	}

	return bSetPriority(tpiNewLevel);
}
//---------------------------------------------------------------------------
//TODO: + bIsPriorityBoost (Retrieves the priority boost control state of the specified thread)
BOOL CXThread::bIsPriorityBoost() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	BOOL bDisablePriorityBoost = TRUE;

	bRes = ::GetThreadPriorityBoost(_m_hThread.m_hHandle, &bDisablePriorityBoost);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	//bDisablePriorityBoost == TRUE  - dynamic boosting is disabled
	//bDisablePriorityBoost == FALSE - normal behavior

	return ! bDisablePriorityBoost;
}
//---------------------------------------------------------------------------
//TODO: + bSetPriorityBoost (Disables or enables the ability of the system to temporarily boost the priority of a thread)
BOOL CXThread::bSetPriorityBoost(BOOL bIsEnabled) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetThreadPriorityBoost(_m_hThread.m_hHandle, ! bIsEnabled);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	CPU
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bSetAffinityMask (Sets a processor affinity mask for the specified thread)
BOOL CXThread::bSetAffinityMask(DWORD_PTR pulMask) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	DWORD_PTR pulRes = 0;

	pulRes = ::SetThreadAffinityMask(_m_hThread.m_hHandle, pulMask);	//ERROR_INVALID_PARAMETER	
	/*DEBUG*/XASSERT_RET(0 != pulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetIdealProcessor (Sets a preferred processor for a thread, ulIdealProcessor - this value is zero-based)
BOOL CXThread::bSetIdealCPU(ULONG ulIdealCPU) const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, ulIdealCPU);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulRes, FALSE); 
	
	//TODO: - XASSERT_RET
	///*DEBUG*/XASSERT_RET(ulIdealCPU != ulRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ulGetIdealProcessor (current ideal processor without changing it)
ULONG CXThread::ulGetIdealCPU() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = (ULONG) - 1;

	ulRes = ::SetThreadIdealProcessor(_m_hThread.m_hHandle, MAXIMUM_PROCESSORS);
	/*DEBUG*/XASSERT_RET((ULONG) - 1 != ulRes, FALSE); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCPUCount (���-�� ����������� �� �����)
ULONG CXThread::ulGetCPUCount() const {
	/*DEBUG*///_m_hThread - not need 

	ULONG ulRes = 0;

	ulRes = CXSystemInfo::ulGetNumOfCPUs();
	CHECK_RET(ulRes < 1 || ulRes > 32, 1);

	return ulRes;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetHandle (������ ������)
HANDLE CXThread::hGetHandle() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), NULL); 

	return _m_hThread.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + ulGetId (ID ������)
ULONG CXThread::ulGetId() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	return _m_ulID;
}
//---------------------------------------------------------------------------
//TODO: + bGetExitCode (Retrieves the termination status of the specified thread)
ULONG CXThread::ulGetExitCode() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), 0); 

	ULONG ulRes = 0;	
	BOOL  bRes  = 0;

	bRes = ::GetExitCodeThread(_m_hThread.m_hHandle, &ulRes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, ulRes/*0*/);

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetDebugName (Name your threads in the VC debugger thread list)
BOOL CXThread::bSetDebugNameA(LPCSTR pcszName) const {
	/*DEBUG*/XASSERT_RET(0    <  _m_ulID,              FALSE); 
	/*DEBUG*/XASSERT_RET(NULL != pcszName,             FALSE); 
	/*DEBUG*/XASSERT_RET(32   >  ::lstrlenA(pcszName), FALSE); //MAX_NAME_SIZE 32

	BOOL bRes = FALSE;

	typedef struct tagTHREADNAME_INFO {
		DWORD  dwType;     //must be 0x1000
		LPCSTR szName;     //pointer to name (in user addr space)
		DWORD  dwThreadID; //thread ID (-1=caller thread)
		DWORD  dwFlags;    //reserved for future use, must be zero
	} THREADNAME_INFO;

	THREADNAME_INFO tiInfo = {0};
	tiInfo.dwType     = 0x1000;
	tiInfo.szName     = pcszName;
	tiInfo.dwThreadID = ulGetId() /*- 1*/;	//_m_ulID;
	tiInfo.dwFlags    = 0;

	__try {
		//::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), static_cast<DWORD *>( static_cast<LPVOID>(&tiInfo) ));
		::RaiseException(0x406D1388, 0, sizeof(tiInfo) / sizeof(DWORD), xreinterpret_cast<DWORD *>(&tiInfo));
	}
	__except (EXCEPTION_CONTINUE_EXECUTION)	{
		/*DEBUG*/XASSERT_RET(FALSE, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	static
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hOpen (Opens an existing thread object.)
/*static*/ HANDLE CXThread::hOpen(ULONG ulAccess, BOOL bInheritHandle, ULONG ulId) {
	/*DEBUG*///ulAccess       - not need 
	/*DEBUG*///bInheritHandle - not need
	/*DEBUG*/XASSERT_RET(0 < ulId, NULL); 

	HANDLE hRes = NULL;

	hRes = ::OpenThread(ulAccess, bInheritHandle, ulId);
	/*DEBUG*/XASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------
//TODO: + ulGetCurrId (Retrieves the thread identifier of the calling thread.)
/*static*/ ULONG CXThread::ulGetCurrId() {
	/*DEBUG*///not need 

	ULONG ulRes = 0;

	ulRes = ::GetCurrentThreadId();
	/*DEBUG*/XASSERT_RET(0 < ulRes, 0); 

	return ulRes;
}
//---------------------------------------------------------------------------
//TODO: + hGetCurrHandle (Retrieves a pseudo handle for the calling thread)
/*static*/ HANDLE CXThread::hGetCurrHandle() {
	/*DEBUG*///not need 

	HANDLE hRes = NULL;

	hRes = ::GetCurrentThread();
	/*DEBUG*/XASSERT_RET(NULL != hRes, NULL); 

	return hRes;
}
//---------------------------------------------------------------------------

/****************************************************************************
*    callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnEnter ()
VOID CXThread::vAttachHandler_OnEnter(Closure<VOID(CXThread *pthSender)> Callback) {
	_m_Callback_OnEnter = Callback;
	//_m_bFlag_OnEnter  = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnEnter ()
////VOID vDetachHandler_OnEnter(CXThread *pthSender) {
////	//_m_bFlag_OnEnter         = FALSE;
////	_m_Callback_OnEnter.p_this = NULL;
////}
//---------------------------------------------------------------------------
//TODO: + vAttachHandler_OnExit ()
VOID CXThread::vAttachHandler_OnExit(Closure<VOID(CXThread *pthSender)> Callback) {
	_m_Callback_OnExit = Callback;
	//_m_bFlag_OnExit    = TRUE;
}
//---------------------------------------------------------------------------
//TODO: - vDetachHandler_OnExit ()
////VOID vDetachHandler_OnExit(CXThread *pthSender) {
////	//_m_bFlag_OnExit         = FALSE;
////	_m_Callback_OnExit.p_this = NULL;
////}
//---------------------------------------------------------------------------




/****************************************************************************
*	[protected] 
*
*****************************************************************************/

/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + uiOnRun (������� ������)
/*virtual*/ UINT CXThread::uiOnRun(VOID *pvParam) {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_RET(FALSE, 0);

	//must override this

	/*UINT uiRes = 0;

	for (;;) {
		if (TRUE == bIsExited()) {
			return uiRes;
		}
		if (TRUE == bIsPaused()) {
			_bWaitResumption();
		}

		//...
	}	

	return uiRes;*/

	return 0;
}
//---------------------------------------------------------------------------
//TODO: + vOnEnter (������� �� ��������������� ������)
/*virtual*/ VOID CXThread::vOnEnter() {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_DO(FALSE, return);

	//must override this

	return;
}
//---------------------------------------------------------------------------
//TODO: + vOnExit (������� �� ���������� ������)
/*virtual*/ VOID CXThread::vOnExit() {
	/*DEBUG*///not need
	/*DEBUG*/XASSERT_DO(FALSE, return);

	//must override this

	return;
}
//---------------------------------------------------------------------------

/****************************************************************************
*	���������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bYield (�������� ������� ������� ������, ������� ����� � ���������� �� !������� ����������!)
BOOL CXThread::bYield() const {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	::SwitchToThread();
	/*DEBUG*///not need

	//-------------------------------------
	//��������� �������
	//not need

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSleep (Suspends the execution of the current thread until the time-out interval elapses)
BOOL CXThread::bSleep(ULONG ulTimeout) {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 
	/*DEBUG*///ulTimeout - not need

	BOOL bRes = FALSE;  

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	/*_m_bIsPaused*/
	_m_bIsSleeping = TRUE;
	/*_m_bIsExited*/

	bRes = _m_slSleeper.bSleep(ulTimeout);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	/*_m_bIsPaused*/
	_m_bIsSleeping = FALSE;		//�����
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bBreakSleep (���������� ������� bSleep - ����� �� ������� ���������)
BOOL CXThread::bBreakSleep() {
	/*DEBUG*/XASSERT_RET(FALSE != _m_hThread.bIsValid(), FALSE); 

	BOOL bRes = FALSE;

	bRes = _m_slSleeper.bReset();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	/*_m_bIsPaused*/
	_m_bIsSleeping = FALSE;
	/*_m_bIsExited*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsTimeToExit (���� �� �������� �� ������)
BOOL CXThread::bIsTimeToExit() {   
	/*DEBUG*///not need

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	///bSleep(1);

	bRes = bIsExited();
	CHECK_RET(TRUE == bRes, TRUE);

	//-------------------------------------
	//����� / �������������
	///bSleep(1);

	bRes = bIsPaused();
	CHECK_RET(TRUE == bRes, !_bWaitResumption());

	//-------------------------------------
	//��������� �������
	//[not need]

	return FALSE;
}
//BOOL CXThread::bIsTimeToExit() {   
//	/*DEBUG*///not need
//
//	BOOL bRes = FALSE;
//
//	//-------------------------------------
//	//�����
//	::Sleep(1);
//
//	bRes = bIsExited();
//	CHECK_RET(TRUE == bRes, FALSE);
//
//	//-------------------------------------
//	//����� / �������������
//	::Sleep(1);
//
//	bRes = bIsPaused();
//	CHECK_RET(TRUE == bRes, _bWaitResumption());
//
//	//-------------------------------------
//	//��������� �������
//	//[not need]
//
//	return TRUE;
//}
//---------------------------------------------------------------------------




/****************************************************************************
*	[private]
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_uiStartFunc (����������� ������� ������)
UINT WINAPI CXThread::_s_uiStartFunc(VOID *pvParam) {
	/*DEBUG*/XASSERT_RET(NULL != pvParam, 0);

	UINT uiRes = 0;
	BOOL bRes  = 0;

	CXThread *pthThis = static_cast<CXThread *>(pvParam); 
	/*DEBUG*/XASSERT_RET(NULL != pthThis, 0);

	//-------------------------------------
	//���� ���� ����� ��� ��������
	//::Sleep(5);
	bRes = pthThis->_m_pevStarter->bWait(/*+INFINITE*/1000);  
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	DELETE_POINTER(pthThis->_m_pevStarter);

	/*DEBUG*/XASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 

	//-------------------------------------
	//������ �� ���������������� �����?
	CHECK_DO(TRUE == pthThis->bIsPaused(), pthThis->_bWaitResumption());

	//-------------------------------------
	//������������� COM
	if (TRUE == pthThis->_m_cbIsUsingCOM) {
		pthThis->_m_pcomCOM = new CXCOM(COINIT_MULTITHREADED);
		/*DEBUG*/XASSERT_DO(NULL != pthThis->_m_pcomCOM, 0);
	}

	try {
		//-------------------------------------
		//�������� �� ������ ���������� ������� ������
		try {
			//--pthThis->vOnEnter();
			pthThis->_vRaiseHandler_OnEnter(pthThis);
		} catch (...) {
			/*DEBUG*/::OutputDebugString(_T("_vRaiseHandler_OnEnter fail\n"));
			/*DEBUG*/XASSERT(FALSE);
		}
		/*DEBUG*/XASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 



		//-------------------------------------
		//������� ������
		try {
			if (0 == pthThis->_m_ptfStartAddress) {
				uiRes = pthThis->uiOnRun(pthThis->_m_pvParam);
			} else {
				uiRes = pthThis->_m_ptfStartAddress(pthThis->_m_pvParam);
			}
		} catch (...) {
			/*DEBUG*/::OutputDebugString(_T("uiOnRun fail\n"));
			/*DEBUG*/XASSERT(FALSE);
		}
		/*DEBUG*/XASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 



		//-------------------------------------
		//�������� ����� ��������� ���������� ������� ������
		try {
			//--pthThis->vOnExit();
			pthThis->_vRaiseHandler_OnExit(pthThis);
		} catch (...) {
			/*DEBUG*/::OutputDebugString(_T("_vRaiseHandler_OnExit fail\n"));

			/*DEBUG*/XASSERT(FALSE);
		}
		/*DEBUG*/XASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	} catch (...) {
		/*DEBUG*/XASSERT_MSG(FALSE, _T("[catch (...)]: ���������� ���� ����"));

		//TODO: - vRaiseHandler_OnError
		//--pthThis->vOnError();
		//pthThis->_vRaiseHandler_OnError(pthThis);
	}
	
	/*DEBUG*/XASSERT_RET(NULL  != pthThis, 0);
	/*DEBUG*/XASSERT_RET(FALSE != pthThis->_m_hThread.bIsValid(), 0); 
	
	//-------------------------------------
	//��������������� COM
	if (TRUE == pthThis->_m_cbIsUsingCOM) {
		DELETE_POINTER(pthThis->_m_pcomCOM);
	}

	//-------------------------------------
	//������ �������� (���� �� ���������???)												
	bRes = pthThis->_m_hThread.bClose();
	/*DEBUG*/XASSERT_RET(FALSE != bRes, 0);

	pthThis->_m_ulID            = 0;
	pthThis->_m_uiExitCode      = uiRes;	//???
	pthThis->_m_ptfStartAddress = 0;
	pthThis->_m_pvParam         = NULL;
	//pthThis->_m_bIsAutoDelete - not need 

	//-------------------------------------
	//��������� �������
	pthThis->_vSetDefaultStates();

	//-------------------------------------
	//��������������� ������
	CHECK_DO(TRUE == pthThis->_m_cbIsAutoDelete, DELETE_POINTER(pthThis));

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: + _bWaitForResume (���� ������ �����)
BOOL CXThread::_bWaitResumption() {
	/*DEBUG*/

	BOOL  bRes  = FALSE;
	ULONG ulRes = 0;

	//-------------------------------------
	//��������� �������
	/*_m_bIsCreated*/
	/*_m_bIsRunning*/
	_m_bIsPaused = TRUE;           
	/*_m_bIsSleeping*/
	/*_m_bIsExited*/

	ulRes = ::WaitForSingleObject(_m_evPause.hGetHandle(), INFINITE); 
	/*DEBUG*///- not need

	return TRUE;

	/*
	//a mechanism for terminating thread should be implemented
	//not allowing the method to be run from the main thread
	if (::GetCurrentThreadId () == this->hMainThreadId) {
		return 0;
	} else {
		::MessageBoxW (0, _T("I'm running in a different thread!"), _T("CMyThread"), MB_OK);

		return 0;
	}
	*/
}
//---------------------------------------------------------------------------
//TODO: + _vSetDefaultStates ()
VOID CXThread::_vSetDefaultStates() {
	/*DEBUG*///not need 

	//-------------------------------------
	//��������� �������
	_m_bIsCreated  = FALSE;
	_m_bIsRunning  = FALSE;
	_m_bIsPaused   = FALSE;
	_m_bIsSleeping = FALSE;
#ifdef defVarPolicy
	_m_bIsExited   = FALSE;
#else 
	//???
#endif
}
//---------------------------------------------------------------------------

/****************************************************************************
*    callback ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + vRaiseHandler_OnEnter ()
VOID CXThread::_vRaiseHandler_OnEnter(CXThread *pthSender)	{
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnEnter) {
	if (NULL != _m_Callback_OnEnter) {
		_m_Callback_OnEnter(pthSender);
	}
}
//---------------------------------------------------------------------------
//TODO: + vRaiseHandler_OnExit ()
VOID CXThread::_vRaiseHandler_OnExit(CXThread *pthSender) {
	//���� ��������� ������� ����� �� ����� ������...
	//if (TRUE == _m_bFlag_OnExit) {
	if (NULL != _m_Callback_OnExit) {
		_m_Callback_OnExit(pthSender);
	}
}
//---------------------------------------------------------------------------