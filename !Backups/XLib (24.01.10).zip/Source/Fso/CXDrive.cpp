/****************************************************************************
* Class name:  CXDrive
* Description: �������� � �������
* File name:   CXDrive.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:25:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXDrive.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXDir.h>
//---------------------------------------------------------------------------
CXDrive::CXDrive() {
	//code
}
//---------------------------------------------------------------------------
CXDrive::~CXDrive() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public
*
*****************************************************************************/


//--------------------------------------------------------------------------
//TODO: + bIsReady (���������� ���������� �����)
/*static*/BOOL CXDrive::bIsReady(const tstring &csDrivePath) {  
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), FALSE);

	BOOL    bRes           = FALSE;
	UINT    uiOldErrorMode = 0;
	tstring sOldDirectory  = _T("");

	uiOldErrorMode = ::SetErrorMode(SEM_NOOPENFILEERRORBOX);
	sOldDirectory  = CXDir::sGetCurrent();

	//-------------------------------------
	//�������� ����� �� ��������� ����
	ULONG ulRes = ::SetCurrentDirectory(CXPath::sAddSlash(csDrivePath).c_str());
	if (0 == ulRes) {  // 0 - error
		bRes = FALSE;
	} else {
		bRes = TRUE;
	}

	CXDir::bSetCurrent(sOldDirectory);
	::SetErrorMode(uiOldErrorMode);

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: + bIsEmpty (���� �� ����)
/*static*/BOOL CXDrive::bIsEmpty(const tstring &csDrivePath) {
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), FALSE);

	BOOL            bRes       = TRUE;
	HANDLE          hFile      = INVALID_HANDLE_VALUE; 
	WIN32_FIND_DATA stFindData = {0};   

	hFile = ::FindFirstFile((CXPath::sAddSlash(csDrivePath) + _T("*.*")).c_str(), &stFindData);   
	if (INVALID_HANDLE_VALUE == hFile) {   
		return TRUE; 
	} 

	bRes = ::FindClose(hFile); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, TRUE); 

	return FALSE;   
}
//--------------------------------------------------------------------------
//TODO: + bDefineDosDevice (Defines, redefines, or deletes MS-DOS device names.)
/*static*/BOOL CXDrive::bDefineDosDevice(ULONG ulFlags, const tstring &csDeviceName, const tstring &csTargetPath) {
	/*DEBUG*/XASSERT_RET(false == csDeviceName.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csTargetPath.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::DefineDosDevice(ulFlags, csDeviceName.c_str(), csTargetPath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;   
}
//--------------------------------------------------------------------------
//TODO: + bDeleteVolumeMountPoint (Deletes a drive letter or mounted folder.)
/*static*/BOOL CXDrive::bDeleteVolumeMountPoint(const tstring &csVolumeMountPoint) {
	/*DEBUG*/XASSERT_RET(false == csVolumeMountPoint.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::DeleteVolumeMountPoint(csVolumeMountPoint.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;  
}
//--------------------------------------------------------------------------
//TODO: + hFindFirstVolume (Retrieves the name of a volume on a computer)
/*static*/HANDLE CXDrive::hFindFirstVolume(tstring *psVolumeName) {
	/*DEBUG*/XASSERT_RET(NULL != psVolumeName, INVALID_HANDLE_VALUE);
	
	HANDLE hRes = INVALID_HANDLE_VALUE;

	psVolumeName->clear();
	psVolumeName->resize(MAX_PATH);

	hRes = ::FindFirstVolume(&(*psVolumeName)[0], psVolumeName->size());
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hRes, INVALID_HANDLE_VALUE); 

	return hRes;
}
//--------------------------------------------------------------------------
//TODO: + hFindFirstVolumeMountPoint (Retrieves the name of a mounted folder on the specified volume)
/*static*/HANDLE CXDrive::hFindFirstVolumeMountPoint(const tstring &csRootPathName, tstring *psVolumeMountPoint) {
	/*DEBUG*/XASSERT_RET(false == csRootPathName.empty(), INVALID_HANDLE_VALUE);
	/*DEBUG*/XASSERT_RET(NULL != psVolumeMountPoint,      INVALID_HANDLE_VALUE);

	HANDLE hRes = INVALID_HANDLE_VALUE;

	psVolumeMountPoint->clear();
	psVolumeMountPoint->resize(MAX_PATH);

	hRes = ::FindFirstVolumeMountPoint(csRootPathName.c_str(), &(*psVolumeMountPoint)[0], psVolumeMountPoint->size());
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hRes, INVALID_HANDLE_VALUE); 

	return hRes;
}
//--------------------------------------------------------------------------
//TODO: + sFindNextVolume (Continues a volume search started by a call to the FindFirstVolume function.)
/*static*/tstring CXDrive::sFindNextVolume(HANDLE hFindVolume) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFindVolume, _T(""));

	BOOL        bRes                          = FALSE;
	const ULONG culBuffSize                   = MAX_PATH;
	TCHAR        szVolumeName[culBuffSize + 1] = {0};

	bRes = ::FindNextVolume(hFindVolume, &szVolumeName[0], culBuffSize);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, _T("")); 

	return tstring(szVolumeName); 
}
//--------------------------------------------------------------------------
//TODO: + bFindNextVolumeMountPoint (Continues a mounted folder search started by a call to the FindFirstVolumeMountPoint function)
/*static*/BOOL CXDrive::bFindNextVolumeMountPoint(HANDLE hFindVolumeMountPoint, tstring *psVolumeMountPoint) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFindVolumeMountPoint, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != psVolumeMountPoint,                    FALSE);

	BOOL bRes = FALSE;

	psVolumeMountPoint->clear();
	psVolumeMountPoint->resize(MAX_PATH);

	bRes = ::FindNextVolumeMountPoint(hFindVolumeMountPoint, &(*psVolumeMountPoint)[0], psVolumeMountPoint->size());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;  
}
//--------------------------------------------------------------------------
//TODO: + bFindVolumeClose (Closes the specified volume search handle)
/*static*/BOOL CXDrive::bFindVolumeClose(HANDLE hFindVolume) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFindVolume, FALSE);

	BOOL bRes = FALSE;

	bRes = ::FindVolumeClose(hFindVolume);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE; 
}
//--------------------------------------------------------------------------
//TODO: + bFindVolumeMountPointClose (Closes the specified mounted folder search handle)
/*static*/BOOL CXDrive::bFindVolumeMountPointClose(HANDLE hFindVolumeMountPoint) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFindVolumeMountPoint, FALSE);

	BOOL bRes = FALSE;

	bRes = ::FindVolumeMountPointClose(hFindVolumeMountPoint);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE; 
}
//--------------------------------------------------------------------------
//TODO: + bGetFreeSpace (���������� � ������� �����)
/*static*/BOOL CXDrive::bGetFreeSpace(
							   const tstring &csDirPath, 
							   ULONGLONG         *lpFreeBytesAvailableToCaller,
							   ULONGLONG         *lpTotalNumberOfBytes,
							   ULONGLONG         *lpTotalNumberOfFreeBytes) 
{			   
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;
	
	bRes = ::GetDiskFreeSpaceEx(
				csDirPath.c_str(), 
				(PULARGE_INTEGER)lpFreeBytesAvailableToCaller, 
				(PULARGE_INTEGER)lpTotalNumberOfBytes, 
				(PULARGE_INTEGER)lpTotalNumberOfFreeBytes
	);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: + dtGetType (��� �����)
/*static*/CXDrive::EType CXDrive::dtGetType(const tstring &csDrivePath) {
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), dtUnknown);  
	
	return (EType)(::GetDriveType(CXPath::sAddSlash(csDrivePath).c_str()));
	/*DEBUG*///not need
}
//--------------------------------------------------------------------------
//TODO: + bGetLogicalDrives (������ ���� ��������� ������)
/*static*/BOOL CXDrive::bGetLogicalDrives(std::vector<tstring> *vecsDrives) {
	/*DEBUG*/XASSERT_RET(NULL != vecsDrives, FALSE);

	ULONG ulDrives = 0;
		
	ulDrives = ::GetLogicalDrives();
	/*DEBUG*/XASSERT_RET(0 != ulDrives, FALSE);

	vecsDrives->clear();
	for (INT i = 0; i < 26; i ++) {
		if (1 == ((ulDrives >> i) & 0x00000001)) {
			tstring sDrivePath;

			sDrivePath.push_back(TCHAR(65 + i)); 
			sDrivePath.push_back(_T(':'));

			vecsDrives->push_back(sDrivePath);
		}
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bGetLogicalUsbDrives (������ ���� ��������� ������)
/*static*/BOOL CXDrive::bGetLogicalDrives(std::vector<tstring> *vecsDrives, EType dtDriveType) {
	/*DEBUG*/XASSERT_RET(NULL != vecsDrives, FALSE);

	ULONG ulDrives = 0;

	ulDrives = ::GetLogicalDrives();
	/*DEBUG*/XASSERT_RET(0 != ulDrives, FALSE);

	vecsDrives->clear();
	for (INT i = 0; i < 26; i ++) {
		if (1 == ((ulDrives >> i)&0x00000001)) {
			tstring sDrivePath;

			sDrivePath.push_back(TCHAR(65 + i));
			sDrivePath.push_back(_T(':'));       
			
			CHECK_DO(dtDriveType != CXDrive::dtGetType(sDrivePath), continue);

			vecsDrives->push_back(sDrivePath);
		}
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + sGetLogicalStrings (Fills a buffer with strings that specify valid drives in the _tsystem.)
/*static*/tstring CXDrive::sGetLogicalStrings() {
	ULONG   ulRes      = 0;
	ULONG   ulBuffSize = MAX_PATH;
	tstring sBuff      = _T("");

	sBuff.resize(ulBuffSize);
	ulRes = ::GetLogicalDriveStrings(ulBuffSize, &sBuff[0]);
	if (ulRes > ulBuffSize) {
		sBuff.resize(ulRes);
		ulRes = ::GetLogicalDriveStrings(ulBuffSize, &sBuff[0]);
	} 
	/*DEBUG*/XASSERT_RET(0 != ulRes, _T("")); 

	return tstring(sBuff, ulRes);
}
//--------------------------------------------------------------------------
//TODO: + bGetInformation (���������� � �����)
/*static*/BOOL CXDrive::bGetInformation(const tstring &csDrivePath,
										LPTSTR             pszVolumeNameBuffer/*out*/,
										ULONG              ulVolumeNameSize,
										ULONG             *pulVolumeSerialNumber/*out*/,
										ULONG             *pulMaximumComponentLength/*out*/,
										ULONG             *pulFileSystemFlags/*out*/,
										LPTSTR             pszFileSystemNameBuffer/*out*/,
										ULONG              ulFileSystemNameSize)
{
	/*DEBUG*/XASSERT_RET(false == csDrivePath.empty(), FALSE); 

	BOOL bRes = FALSE; 
	
	bRes = ::GetVolumeInformation(
				        CXPath::sAddSlash(csDrivePath).c_str(), 
						pszVolumeNameBuffer, 
						ulVolumeNameSize, 
						pulVolumeSerialNumber, 
						pulMaximumComponentLength, 
						pulFileSystemFlags, 
						pszFileSystemNameBuffer, 
						ulFileSystemNameSize);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + sGetVolumeNameForVolumeMountPoint (Retrieves a volume GUID path for the volume that is associated with the specified volume mount point (drive letter, volume GUID path, or mounted folder)
/*static*/tstring CXDrive::sGetVolumeNameForVolumeMountPoint(const tstring &csVolumeMountPoint) {
	/*DEBUG*/XASSERT_RET(false == csVolumeMountPoint.empty(), _T(""));

	TCHAR szRes[50 + 1] = {0};
	BOOL  bRes          = FALSE;

	bRes = ::GetVolumeNameForVolumeMountPoint(CXPath::sAddSlash(csVolumeMountPoint).c_str(), &szRes[0], MAX_PATH);
	/*DEBUG*/////XASSERT_RET(FALSE != bRes, _T(""));
	CHECK_RET(FALSE == bRes, _T("")); 

	return tstring(szRes);
} 
//--------------------------------------------------------------------------
//TODO: + sGetVolumePathName (Retrieves the volume mount point where the specified path is mounted.)
/*static*/tstring CXDrive::sGetVolumePathName(const tstring &csFileName) {
	/*DEBUG*/XASSERT_RET(false == csFileName.empty(), _T(""));

	BOOL        bRes                               = FALSE;
	const ULONG culBuffSize                        = MAX_PATH;
	TCHAR        szVolumePathName[culBuffSize + 1] = {0};

	bRes = ::GetVolumePathName(csFileName.c_str(), &szVolumePathName[0], culBuffSize);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, _T(""));

	return tstring(szVolumePathName);
}
//--------------------------------------------------------------------------
//TODO: + sGetVolumePathNamesForVolumeName (Retrieves a list of drive letters and volume GUID paths for the specified volume.)
/*static*/tstring CXDrive::sGetVolumePathNamesForVolumeName(const tstring &csVolumeName) {
	/*DEBUG*/XASSERT_RET(false == csVolumeName.empty(), _T(""));

	BOOL        bRes                           = FALSE;
	const ULONG culBuffSize                    = MAX_PATH;
	tstring     sVolumePathNames(culBuffSize, 0);
	ULONG       ulReturnLength                 = 0;
	ULONG       ulLastError                    = 0;

	bRes        = ::GetVolumePathNamesForVolumeName(csVolumeName.c_str(), &sVolumePathNames[0], culBuffSize, &ulReturnLength);
	ulLastError = ::GetLastError();
	if (FALSE == bRes && ERROR_MORE_DATA == ulLastError) {
		sVolumePathNames.resize(ulReturnLength);
		bRes        = ::GetVolumePathNamesForVolumeName(csVolumeName.c_str(), &sVolumePathNames[0], culBuffSize, &ulReturnLength);
		ulLastError = ::GetLastError();
	}
	/*DEBUG*/XASSERT_RET(FALSE != bRes && ulLastError != ERROR_MORE_DATA, _T(""));

	return tstring(sVolumePathNames, ulReturnLength);
}
//--------------------------------------------------------------------------
//TODO: + sQueryDosDevice (Retrieves information about MS-DOS device names)
/*static*/tstring CXDrive::sQueryDosDevice(const tstring &csDeviceName) {
	/*DEBUG*/XASSERT_RET(false == csDeviceName.empty(), _T(""));

	ULONG       ulRes                     = 0;
	const ULONG culMax                    = MAX_PATH;
	TCHAR        szTargetPath[culMax + 1] = {0};
	ULONG       ulLastError               = 0;
	
	ulRes       = ::QueryDosDevice(csDeviceName.c_str(), &szTargetPath[0], culMax);
	ulLastError = ::GetLastError();
	/*DEBUG*/XASSERT_RET(0 != ulRes && ERROR_INSUFFICIENT_BUFFER != ulLastError, _T("")); 

	return tstring(szTargetPath, ulRes);
}
//--------------------------------------------------------------------------
//TODO: + bSetVolumeLabel (Sets the label of a file _tsystem volume.)
/*static*/BOOL CXDrive::bSetVolumeLabel(const tstring &csRootPathName, const tstring &cslpVolumeName) {
	/*DEBUG*/XASSERT_RET(false == csRootPathName.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == cslpVolumeName.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetVolumeLabel(csRootPathName.c_str(), cslpVolumeName.c_str()); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + bSetVolumeMountPoint (Associates a volume with a drive letter or a directory on another volume.)
/*static*/BOOL CXDrive::bSetVolumeMountPoint(const tstring &csVolumeMountPoint, const tstring &csVolumeName) {
	/*DEBUG*/XASSERT_RET(false == csVolumeMountPoint.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csVolumeName.empty(),       FALSE);

	BOOL bRes = FALSE;

	bRes = ::SetVolumeMountPoint(csVolumeMountPoint.c_str(), csVolumeName.c_str()); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//--------------------------------------------------------------------------