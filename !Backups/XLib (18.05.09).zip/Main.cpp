/****************************************************************************
* Lib name:  XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


/*#ifndef STRICT
#define STRICT 1
#endif*/

//---------------------------------------------------------------------------
#include <XLib/CXCommon.h>
#include <XLib/WSocket.h>
#include <XLib/CXPop3.h>
#include <XLib/CXSmtp.h>

#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>
#include <XLib/CXFile.h>
#include <XLib/CXComPort.h>
#include <XLib/CXGuid.h>
#include <XLib/CXCrc32.h>
#include <XLib/CXHandleHolder.h>
#include <XLib/CXRandom.h>
#include <XLib/CXSafeMTLong.h>
#include <XLib/CXIni.h>
#include <XLib/CXLog.h>
#include <XLib/CXMsgBox.h>
#include <XLib/CXMsgBoxRtf.h>
////#include <XLib/CXMsgBoxRtfEx.h>
#include <XLib/CXPerform.h>


#include <XLib/CXWinControls/CXWnd.h>
#include <XLib/CXWinControls/CXApp.h>
#include <XLib/CXWinControls/CXEdit.h>
#include <XLib/CXWinControls/CXStatic.h>
#include <XLib/CXWinControls/CXButton.h>
#include <XLib/CXWinControls/CXComboBox.h>
#include <XLib/CXWinControls/CXCheckBox.h>
#include <XLib/CXWinControls/CXGroupBox.h>
#include <XLib/CXWinControls/CXListBox.h>
#include <XLib/CXWinControls/CXListView.h>
#include <XLib/CXWinControls/CXRichEdit.h>
#include <XLib/CXWinControls/CXStatusBar.h>
#include <XLib/CXWinControls/CXProgressBar.h>
#include <XLib/CXWinControls/CXRadioButton.h>
#include <XLib/CXWinControls/CXTab.h>
#include <XLib/CXWinControls/CXTimer.h>
#include <XLib/CXWinControls/CXImageList.h>

using namespace std;
//---------------------------------------------------------------------------
int main(int argc/*, char* argv[]*/) {

	CHAR BUFFER_1[10];

	BUFFER_1[12] = 'y';
	
	
	XASSERT(false);



	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------