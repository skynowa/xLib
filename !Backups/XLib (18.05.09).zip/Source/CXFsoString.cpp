/****************************************************************************
* Class name:  CXFsoString
* Description: ������ ��� ������ � �������� ��������
* File name:   CXFsoString.cpp
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:02:43
*
*****************************************************************************/



//---------------------------------------------------------------------------
#include <XLib/CXFsoString.h>

#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <ostream>
#include <fstream>
#include <io.h>    //chsize
#include <algorithm>
#include <iterator>
#include <ctime>
//#include <fentl.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
//#include <sharc.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#define randomize() (srand((unsigned)time(NULL))) 
#define random(x)   (rand() % x)

const std::string csWinSlash  = "\\";
const std::string csUnixSlash = "/";
//---------------------------------------------------------------------------


/****************************************************************************
* �������� � ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
std::string sExeDirPath() {
	return sExtractFileDir(sExePath());
}
//---------------------------------------------------------------------------
std::string sExePath() {
	CHAR  szExePath[MAX_PATH + 1] = {0};
	ULONG ulStored = ::GetModuleFileName(NULL, szExePath, MAX_PATH);
	/*DEBUG*/XASSERT_RET(0 != ulStored, "");
    /*DEBUG*/XASSERT_RET(NULL != szExePath, "");        
	/*DEBUG*/XASSERT_RET('\0' != *szExePath, "");    

	return std::string(szExePath, ulStored);	
}
//---------------------------------------------------------------------------
//��� + ���������
std::string sExtractFullFileName(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind("\\", csFilePath.size());
	if (std::string::npos == uiEndOfPathIndex) {
		return "";
	}

	return csFilePath.substr(uiEndOfPathIndex + 1, csFilePath.size());
}
//--------------------------------------------------------------------------
//���
std::string sExtractFileName(const std::string &csFilePath) {
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
    
	//std::string sRes("");
	//sRes.assign(csFilePath);

	//sRes = sRemoveFileExt(sExtractFullFileName(csFilePath));

	return sRemoveFileExt(sExtractFullFileName(csFilePath));;
}
//--------------------------------------------------------------------------
//Returns the path, without a trailing backslash '\'
std::string sExtractFileDir(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind("\\", csFilePath.size());
	if (std::string::npos == uiEndOfPathIndex) {
		return "";
	}

	return csFilePath.substr(0, uiEndOfPathIndex);
}
//---------------------------------------------------------------------------
//����
std::string sExtractFileDrive(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiPos = csFilePath.find(":");
	if (std::string::npos == uiPos) {
		return "";
	}

	return csFilePath.substr(0, uiPos + 1);

}
//---------------------------------------------------------------------------
//TODO: sExtractRelativePath
std::string sExtractRelativePath(const std::string &csFilePath) {
	
	return "";
}
//--------------------------------------------------------------------------
//TODO: sAddSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
std::string sAddSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	if ('\\' == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	}
	
	return csDirPath + csWinSlash;
}
//--------------------------------------------------------------------------
//TODO: sDeleteSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
std::string sDeleteSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	const size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if ('\\' == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	}

	return csDirPath;
}
//--------------------------------------------------------------------------
//���������� ��� �����
std::string sExtractFileExt(const std::string &csFilePath) {
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
    
	return csFilePath.substr(csFilePath.rfind('.', csFilePath.size()) + 1);
}
//---------------------------------------------------------------------------
std::string sChangeFileExt(const std::string &csFilePath, const std::string &csFileExt) {	
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
        
	std::string sRes("");
	sRes.assign(csFilePath);
	
	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if ('.' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileExt);
			
			break;
		}
	}
	
	return sRes;
}
//---------------------------------------------------------------------------
std::string sChangeFullFileName(const std::string &csFilePath, const std::string &csFileName) {
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
    
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileName);
			
			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
std::string sRemoveFileExt(const std::string &csFilePath) {
    /*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
    
	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.' - ������� ����� � ����������
		if ('.' == sRes.at(i - 1)) {
			sRes = sRes.erase(i - 1, sRes.size() - i + 1);
			
			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
//function MakeValidFileName(const FileName: TFileName;
//ReplaceBadChar: Char): TFileName;
//var
//I: Integer;
//begin
//Result := FileName;
//for I := 1 to Length(Result) do
//if HasChar(Result[I], '''":?*\/') then
//Result[I] := ReplaceBadChar;
//end;
std::string sMakeValidFileName(const std::string &csFileName) {
	const CHAR cszFatalChars[] = {'\\', '/', ':', '*', '<', '>', '|', '?', '"', '\t', '\n', '\r'};

	std::string sRes    = "";
	size_t      uiFound = 0;

	uiFound = csFileName.find_first_not_of(cszFatalChars);
	while (std::string::npos != uiFound) 	{
		sRes += csFileName.at(uiFound);
		
		uiFound = csFileName.find_first_not_of(cszFatalChars, uiFound + 1);
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::string sGetEnvironmentVariable(const std::string &csVar) {
    /*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(1024, '\0');

	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(FALSE != ulStored, ""); 
	
	if (sRes.size() < ulStored) {
		sRes.resize(ulStored);

		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(FALSE != ulStored, "");
	}

	return sRes;
}
//--------------------------------------------------------------------------
BOOL bSetEnvironmentVariable(const std::string &csvVar, const std::string &csValue) {
	/*DEBUG*/XASSERT_RET(false == csvVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csvVar.c_str(), csValue.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
std::vector<std::string> vecsGetEnvironmentStrings() {
	std::vector<std::string> vecsRes;

	LPSTR pszVar = NULL; 
	LPCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/XASSERT_RET(NULL != lpvEnv, std::vector<std::string>()); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPSTR)lpvEnv;

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		vecsRes.push_back(std::string(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	BOOL bRes = FALSE;

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
std::string sExpandEnvironmentStrings(const std::string &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(1024, '\0');

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(FALSE != ulStored, ""); 

	if (sRes.size() < ulStored) {
		sRes.resize(ulStored);

		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(FALSE != ulStored, "");
	}

	return sRes;
}
//--------------------------------------------------------------------------
std::string sUnixToWinPath(const std::string &csUnixPath, bool bNeedBackslashAtEnd) {
    /*DEBUG*/XASSERT_RET(false == csUnixPath.empty(), ""); 
    
	std::string sRes("");
	sRes.assign(csUnixPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('/' == sRes.at(i)) {
			sRes.at(i) = '\\';
		}
	}

	if (bNeedBackslashAtEnd && '\\' != sRes.at(sRes.size() - 1)) {
		sRes.append("\\");
	}

	return sRes; 
}
//--------------------------------------------------------------------------
std::string sWinToUnixPath(const std::string &csWinPath, bool bNeedBackslashAtEnd) {
    /*DEBUG*/XASSERT_RET(false == csWinPath.empty(), ""); 
    
	std::string sRes("");
	sRes.assign(csWinPath);
	
	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('\\' == sRes.at(i)) {
			sRes.at(i) = '/';
		}
	}

	if (bNeedBackslashAtEnd && '/' != sRes.at(sRes.size() - 1)) {
		sRes.append("/");
	}

	return sRes; 
}
//--------------------------------------------------------------------------
std::string sMinimizeFileName(const std::string &csStr, const size_t cuiMaxLen) {	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen, "");

	std::string sRes("");
	std::string sTildaDotExt      = "~." + sExtractFileExt(csStr);
	size_t      uiTildaDotExtSize = sTildaDotExt.size();

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < uiTildaDotExtSize) {
			sRes = csStr.substr(0, cuiMaxLen);
		} else {
			sRes = csStr.substr(0, cuiMaxLen - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//---------------------------------------------------------------------------
//--std::string _sCutFirstDirectory(const std::string &csS) {
//	/*DEBUG*/XASSERT_RET(false == csS.empty(), "");
//
//	std::string S("");
//	S.assign(csS);	
//
//	bool   bRoot = false;
//	size_t P     = - 1;
//
//	if ("\\" == S) {
//		S.clear();
//	} else {
//		if (S[0] == '\\') {
//			bRoot = true;
//			//������� � 1(0) ������� 1 ������
//			//Delete(S, 1, 1);
//			S.erase(0, 1);
//		} else {
//			bRoot = false;
//		}
//
//		if ('.' == S[0]) {
//			//Delete(S, 1, 4);
//			S.erase(0, 4);
//		}
//
//		//P = AnsiPos("\\", S); 
//		P = S.find_first_of("\\") + 1;
//
//		if (std::string::npos != P) {
//			//Delete(S, 1, P); - c ������� 1(0) P ��������
//			S.erase(0, P);
//			S = "...\\" + S;        
//		} else {
//			S.clear();
//		}
//
//		if (bRoot) {
//			S = "\\" + S;
//		}
//	}
//
//	return S;
//--}
//---------------------------------------------------------------------------
std::string sMinimizePath(const std::string &csFilePath, const size_t cuiMaxLen) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen, "");
	
	std::string sRes("");
	sRes.assign(csFilePath);	

	std::string sDrive = sExtractFileDrive(csFilePath);					    //D:
	std::string sDir   = sExtractFileDir(csFilePath).erase(0, 2) + "\\";	//\XLib\Test\CXString\Project\Debug\ 
	std::string sName  = sExtractFullFileName(csFilePath);				    //Test.exe

	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/> cuiMaxLen)) { 
		if ("\\...\\" == sDir ) {
			sDrive.clear();
			sDir = "...\\";
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			//-------------------------------
			//--sDir = _sCutFirstDirectory(sDir);
			bool   bRoot = false;
			size_t P     = - 1;

			if ("\\" == sDir) {
				sDir.clear();
			} else {
				if (sDir.at(0) == '\\') {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = false;
				}

				if ('.' == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//P = AnsiPos("\\", S); 
				P = sDir.find_first_of("\\") + 1;

				if (std::string::npos != P) {
					//Delete(S, 1, P); - c ������� 1(0) P ��������
					sDir.erase(0, P);
					sDir = "...\\" + sDir;        
				} else {
					sDir.clear();
				}

				if (bRoot) {
					sDir = "\\" + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------



/****************************************************************************
* ������ �����
*
*****************************************************************************/


//--------------------------------------------------------------------------
ULONG ulFileLines(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), 0);
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csFilePath), 0);

	ULONG ulLines = 0;   //������� �����

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return 0;
	}

	CHAR cChar = '\0';
	while (ifsStream.get(cChar)) {
		if ('\n' == cChar) {
			ulLines ++;
		}
	} 
	ulLines ++;
	ifsStream.close();

	return ulLines;
}
//--------------------------------------------------------------------------
ULONG ulFileSize(FILE *pFile) {
	/*DEBUG*/XASSERT_RET(NULL != pFile, 0);

	ULONG ulRes = 0;	
	
	if (0 != fseek(pFile, 0, SEEK_END)) {
		return 0;
	}

	ulRes = ftell(pFile);
	rewind(pFile);

	return ulRes;
	/*
	file.seekg (0, std::ios::end);
	size = file.tellg();
	file.seekg (0, std::ios::beg);
	*/
}
//---------------------------------------------------------------------------
ULONG ulFileSize(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), 0);

	ULONG ulRes = 0;

	FILE *pFile = fopen(csFilePath.c_str(), "rb");
	/*DEBUG*/XASSERT_RET(NULL != pFile, 0);	
	
	if (0 != fseek(pFile, 0, SEEK_END)) {
		fclose(pFile);
		return 0;
	}

	ulRes = ftell(pFile);
	rewind(pFile);

	fclose(pFile);

	return ulRes;
}
//---------------------------------------------------------------------------
ULONGLONG ui64GetFileSize(HANDLE hFile) {
	/*DEBUG*/XASSERT_RET(NULL != hFile, 0);

	ULONG dw1 = 0;
	ULONG dw2 = 0;
	dw1 = ::GetFileSize(hFile, &dw2);

	return (dw1 | (ULONGLONG) (dw2) << 32);
}
//---------------------------------------------------------------------------
bool bGetCompressedFileSize(LPCTSTR pcwszFileName, ULONGLONG &size) {
	/*DEBUG*/XASSERT_RET(NULL != pcwszFileName, false);
    /*DEBUG*/XASSERT_RET('\0' != *pcwszFileName, false);
	
	ULONG highPart = 0;
	ULONG lowPart  = ::GetCompressedFileSize(pcwszFileName, &highPart);
	if (INVALID_FILE_SIZE == lowPart) {
		if (NO_ERROR != ::GetLastError()) {
			return false;
		}
	}

	size = ((ULONGLONG)(highPart) << 32) | lowPart;

	return true;
}
//--------------------------------------------------------------------------
bool bGetCompressedFileSizeW(LPCWSTR pcwszFileName, ULONGLONG  &size) {
	/*DEBUG*/XASSERT_RET(NULL != pcwszFileName, false);
    /*DEBUG*/XASSERT_RET('\0' != *pcwszFileName, false); 

	ULONG highPart = 0;
	ULONG lowPart  = ::GetCompressedFileSizeW(pcwszFileName, &highPart);
	if (INVALID_FILE_SIZE == lowPart) {
		if (NO_ERROR != ::GetLastError()) {
			return false;
		}
	}

	size = ((ULONGLONG)(highPart) << 32) | lowPart;

	return true;
}
//--------------------------------------------------------------------------


/****************************************************************************
* ��������
*
*****************************************************************************/


//---------------------------------------------------------------------------
ULONG ulGetFileAttr(const std::string &csFilePath) { 	
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), 0);

	return ::GetFileAttributes(csFilePath.c_str());
}
//---------------------------------------------------------------------------
BOOL bSetFileAttr(const std::string &csFilePath, ULONG ulFileAttr) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	//������� ������� "������ ������"
	BOOL bRes = FALSE;
	
	bRes = ::SetFileAttributes(csFilePath.c_str(), ulFileAttr);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
BOOL bSetFileUncompressedAttr(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	ULONG  ulFileAttr = FALSE;

	//������ �������� �����
	ulFileAttr = ulGetFileAttr(csFilePath.c_str());
	if (0xFFFFFFFF == ulFileAttr)	{
		return FALSE;
	}

	//������� ������� "������"
	if (FALSE == bSetFileAttr(csFilePath.c_str(), ulFileAttr | faCompressed)) {
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL bSetFileCompressedAttr(const std::string &csFilePath, bool bCompress) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	HANDLE hFile           = NULL;
	SHORT  siCompression   = 0;
	DWORD  ulBytesReturned = 0;
	BOOL   bForceCompress  = TRUE;

	if (FALSE != bForceCompress || (ulGetFileAttr((csFilePath).c_str()) && faCompressed)) {
		hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, 0);
		if (INVALID_HANDLE_VALUE == hFile) {
			return FALSE;
		}
		
		if (TRUE == bCompress) {
			siCompression = COMPRESSION_FORMAT_DEFAULT;
		} else {
			siCompression = COMPRESSION_FORMAT_NONE;
		}

		if (FALSE == ::DeviceIoControl(hFile, FSCTL_SET_COMPRESSION, &siCompression, sizeof(SHORT), NULL, 0, &ulBytesReturned, NULL)) {
            /*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
        	if (INVALID_HANDLE_VALUE != hFile) {
                ::CloseHandle(hFile); 	hFile = INVALID_HANDLE_VALUE;
        	}

			return FALSE;
		}

        /*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
    	if (INVALID_HANDLE_VALUE != hFile) {
            ::CloseHandle(hFile); 	hFile = INVALID_HANDLE_VALUE;
    	}

		return TRUE;
	} else {
		return TRUE;
	}
}
//--------------------------------------------------------------------------
UINT uiIsFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), faInvalidFileAttr);
	
	return ulGetFileAttr(csFilePath.c_str());	
} 
//--------------------------------------------------------------------------




/****************************************************************************
* ������ / ������ �����
*
*****************************************************************************/

//--------------------------------------------------------------------------
VOID vFileToArray(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), VOID(NULL));
	
	//ulFileLines(csFilePath);
	//...
}
//--------------------------------------------------------------------------
std::vector<std::string> vecsReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePath), std::vector<std::string>());
	
	std::vector<std::string> vecRes;
	std::string              sStr("");
	std::ifstream            ifsStream(csFilePath.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, std::vector<std::string>());
	}	

	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		vecRes.push_back(sStr);
	}

	return vecRes;
}
//--------------------------------------------------------------------------
std::vector<char> vecchReadFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), std::vector<char>());
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csFilePath), std::vector<char>());

	std::ifstream ifsStream(csFilePath.c_str(), std::ios::in | std::ios::binary);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, std::vector<char>());
	}

	std::vector<CHAR>       vecchBuffer;
	std::ifstream::pos_type uiSize = 0;

	if (ifsStream.seekg(0, std::ios::end)) {
		uiSize = ifsStream.tellg();
	}

	if (uiSize && ifsStream.seekg(0, std::ios::beg)) {
		vecchBuffer.resize(uiSize);
		ifsStream.read(&vecchBuffer[0], uiSize);
	}

	return vecchBuffer;
}
//--------------------------------------------------------------------------
//���������� ����� Name1=Value1\r\r\nName2=Value2\r\n...
std::map<std::string, std::string> mapReadFile(const std::string &csFilePath, const std::string &csDelimiter) {
	//return std::map<std::string, std::string>(); 
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(),      (std::map<std::string, std::string>()));
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePath), (std::map<std::string, std::string>()));

	std::map<std::string, std::string> mapLines;
	std::string                        sStr("");
	std::ifstream                      ifsStream(csFilePath.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		/*DEBUG*/XASSERT_RET(false, (std::map<std::string, std::string>()));
	}	

	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		
		std::vector<std::string> vecsLine = vecsSplit(csDelimiter, sStr);

		mapLines[vecsLine.at(0)] = vecsLine.at(1);
	}

	return mapLines;
}
//--------------------------------------------------------------------------
bool bWriteText(const std::string &csFilePath, const std::string &csText) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), false);

	bool bRes = false;
	
	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);
	
	DWORD dwWrittenBytes = 0;
	BOOL bWriteRes = ::WriteFile(hFile, csText.c_str(), (DWORD)csText.size(), &dwWrittenBytes, NULL);
	if (FALSE == bWriteRes) {
		return false;
	}

	if (csText.size() != dwWrittenBytes) {
		bRes = false;
	} else {
		bRes = true;
	}

	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}

	return bRes;
}
//--------------------------------------------------------------------------
std::string sReadText(const std::string &csFilePath) {	///char -> BYTE
	/*
	std::string xstr;
	std::ifstream xfile("inputfile.txt", std::ios::binary);

	//������ ������ �����, � �������� ������ � ������
	xfile.seekg( 0, std::ios_base::end );
	xstr.resize( xfile.tellg() );
	xfile.seekg( 0, std::ios_base::beg );

	//�������� ������
	xfile.read( (void*)xstr.data(), xstr.size() );
	*/

	/*
	std::ifstream iFile("inputfile.txt");
	std::string mystr(std::istreambuf_iterator<char>(iFile), std::istreambuf_iterator<char>());
	*/

	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), "");
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csFilePath), "");

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, "");

	//-------------------------------------
    //�������� ������ �����
    DWORD dwFileSize = ::GetFileSize(hFile, NULL);
    if (0xFFFFFFFF == dwFileSize || 0 == dwFileSize) {
        /*DEBUG*/XASSERT_RET(NULL != hFile, "");
    	if (NULL != hFile) {
            ::CloseHandle(hFile); 	hFile = NULL;
    	}

        return "";
    }

	//-------------------------------------
    //������ ����
	std::string  sRes        = "";
	ULONG        dwRealyRead = 0;
    CHAR        *pBuff       = new CHAR[dwFileSize + 1];  	
	if (NULL == pBuff) {
		::CloseHandle(hFile);

		return "";		
	}
	if (FALSE == ::ReadFile(hFile, pBuff, dwFileSize, &dwRealyRead, NULL)) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	} 
	if (dwFileSize != dwRealyRead) {
		delete [] pBuff;
		::CloseHandle(hFile);		

		return "";	
	}
	
	//-------------------------------------
    //������ � std::string
	sRes = std::string(pBuff, dwFileSize);

	//-------------------------------------
    //��������� ���� � ������� �����3
	/*DEBUG*/XASSERT_RET(NULL != pBuff, "");
	if (NULL != pBuff) {
		delete [] pBuff;    pBuff = NULL;
	}

	/*DEBUG*/XASSERT_RET(NULL != hFile, "");
	if (NULL != hFile) {
		::CloseHandle(hFile); 	hFile = NULL;
	}    

	return sRes;
}
//--------------------------------------------------------------------------


/****************************************************************************
* �������� � �������
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL bFileExists(const std::string &csFilePath) { 
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);

	ULONG ulAttr = faInvalidFileAttr;
		
	ulAttr = ulGetFileAttr(csFilePath.c_str());
	
	if (faInvalidFileAttr == ulAttr) {	//��� �� ���� � �� ����� � �� ...
		return FALSE;
	}
	if (faDirectory == ulAttr) {	//��� �����
		return FALSE;
	}

	return TRUE;
}
//--------------------------------------------------------------------------
std::string sCreateTempFileName(const std::string &csExt) {	//csDirPath - ��� �����
	/*DEBUG*/CHAR szFatalChars[] = {'\\', '/', ':', '*', '<', '>', '|', '?', '"', '\t', '\n', '\r'};
	/*DEBUG*/for (INT i = 0; i <  sizeof(szFatalChars)/sizeof szFatalChars[0]; i ++) {
	/*DEBUG*/	XASSERT_RET(std::string::npos == csExt.find(szFatalChars[i]), "");	
	/*DEBUG*/}
	
	std::string sRes = "";
	
	if (true == csExt.empty()) {
		sRes = sCreatePlainGUID();
	} else {
		sRes = sCreatePlainGUID() + "." + csExt;
	}
	
	return sRes;
}
//--------------------------------------------------------------------------
bool bCopyFile(const std::string &csFilePathFrom, const std::string &csFilePathTo) {
	/*DEBUG*/XASSERT_RET(false == csFilePathFrom.empty(), false);
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePathFrom), false);
	/*DEBUG*/XASSERT_RET(false == csFilePathTo.empty(), false);

	std::ifstream ifsStream(csFilePathFrom.c_str());
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return false;
	}
	std::ofstream ofsStream(csFilePathTo.c_str()); 
	if (!ofsStream || ofsStream.fail() || !ofsStream.good() || !ofsStream.is_open() || ofsStream.eof()) {
		return false;
	}

	ofsStream << ifsStream.rdbuf();
	ofsStream.close();

	return true;
}
//--------------------------------------------------------------------------
BOOL bCopyFile(const std::string &csFilePathFrom, const std::string &csFilePathTo, BOOL bFailIfExists) {
	/*DEBUG*/XASSERT_RET(false == csFilePathFrom.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePathFrom), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePathTo.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::CopyFile(csFilePathFrom.c_str(), csFilePathTo.c_str(), bFailIfExists);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
BOOL bMoveFile(const std::string &csFilePathIn, const std::string &csFilePathOut) {
	/*DEBUG*/XASSERT_RET(false == csFilePathIn.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csFilePathIn), FALSE);
	/*DEBUG*/XASSERT_RET(false == csFilePathOut.empty(), FALSE);

	//-------------------------------------
	//������� ������� "������ ������"
	if (TRUE == bFileExists(csFilePathOut)) {
		if (FALSE == bSetFileAttr(csFilePathOut, faNormal)) {
			return FALSE;
		}
	}
	if (FALSE == bSetFileAttr(csFilePathIn, faNormal)) {
		return FALSE;
	}

	//-------------------------------------
	//����������
	BOOL bRes = FALSE;
	
	bRes = ::MoveFile(csFilePathIn.c_str(), csFilePathOut.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//#define _WIN32_WINNT 0x0500
BOOL bReplaceFile(const std::string &csOldFileName, const std::string &csNewFilePath, const std::string &csBackupFilePath) {
	/*DEBUG*/XASSERT_RET(false == csOldFileName.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csOldFileName), FALSE);
	/*DEBUG*/XASSERT_RET(false == csNewFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csNewFilePath), FALSE);
	/*DEBUG*/XASSERT_RET(false == csBackupFilePath.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::ReplaceFile(csOldFileName.c_str(), csNewFilePath.c_str(), csBackupFilePath.c_str(), REPLACEFILE_WRITE_THROUGH/* | REPLACEFILE_IGNORE_MERGE_ERRORS*/, (LPVOID)NULL, (LPVOID)NULL); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);	

	return bRes;
}
//---------------------------------------------------------------------------
BOOL bDeleteFile(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePath), FALSE);

	BOOL bRes = FALSE;
	
	bRes = bSetFileAttr(csFilePath, faNormal);
	if (FALSE == bRes) {
		return FALSE;
	}	
	
	bRes = ::DeleteFile(csFilePath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: bSecureDeleteFile
///////*I set _stklen to 512 because there shouldn't be that much going to the
//////functions and i wanted to save memory I set _fmode to binary so i
//////could take it out of the sopen statement because im lazy*/
//////extern unsigned _stklen = 512;
//////extern int      _fmode  = 0x8000;	O_BINARY
BOOL bSecureDeleteFile(const std::string &csFilePath, unsigned int uiPasses) {
	const int     ciO_BINARY    = 0x8000;
	const int     ciO_TRUNC     = 0x0200;
	const int     ciO_WRONLY    = 2;
	const int     ciS_IFREG     = 0x0000;
	const int     ciSH_DENYNO   = 0x0040;

	const ULONG culBuffLen     = 32768;
	const ULONG culClusterSize = 32768;

	INT   hFile              = NULL; 
	ULONG ulFileSize         = 0;
	UCHAR ucBuff[culBuffLen] = {0};
	
	//-------------------------------------
	//CHECK
	if (FALSE == bFileExists(csFilePath)) {
		return FALSE;
	}

	//-------------------------------------
	//�������� ������� "������ ������"
	if (FALSE == bSetFileAttr(csFilePath, faNormal)) {
		return FALSE;
	}

	//-------------------------------------
	//�������� ������� ������
	if (FALSE == bSetFileCompressedAttr(csFilePath, false)) {
		return FALSE;
	}
	
	//-------------------------------------
	//����� ��������� ������ � ����, ������� �� 32kb, �������-�� ���
	hFile = sopen(csFilePath.c_str(), O_WRONLY, SH_DENYNO, S_IFREG);
	if (hFile ==  - 1) {
		close(hFile);
		return FALSE;
	}

	//�������� ������ ����� � ���������� ������ ������ ��� �����
	ulFileSize = filelength(hFile);
	ulFileSize += (culClusterSize - (ulFileSize % culClusterSize));

	for (UINT i = 1; i <= uiPasses; i ++) {
		randomize();
		for (register UINT i = 0; i < ulFileSize; i += culBuffLen) {
			for (register ULONG j = 0; j < culBuffLen; j ++) {
				ucBuff[j] = random(255) + 1;
			}  
			write(hFile, ucBuff, culBuffLen);
		}
		flushall();
		
		//���������� �� ������ �����
		if (-1L == lseek(hFile, 0L, 0)) {
			close(hFile);
			return FALSE;
		}
	}

	close(hFile);

	//-------------------------------------
	//���������� (���� ��������/�����������/���������� ��������� � ������ ��������)
	if (FALSE == bSetRandomFileDate(csFilePath)) {
		return FALSE;
	}

	//-------------------------------------
	//������������� �������� ���� (����� ����������� ��������� ��� ����� ����� ��� MAX_PATH)
	const INT    ciMaxPath          = 255; 
	char         chSymbols[53]      = {'q', 'w', 'e',  'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '!', '@', '#', '$', '%', '^', '&', '(', ')', '_', '+', '�', ';', '%', '.', ',', '~'};
	
	INT          iFileDirPathLen    = sExtractFileDir(csFilePath).size();
	INT          iSlashLen          = 1;
	std::string  sRandomFileName("");
	UINT         uiRandomFileNameLen = ciMaxPath - iFileDirPathLen - iSlashLen;
	
	CHAR *pszRandomFileName = new CHAR[uiRandomFileNameLen + 1];		
	if (NULL == pszRandomFileName) {
		return FALSE;
	}

	//������� ��� �����
	randomize();
	for (register UINT i = 0; i < uiRandomFileNameLen; ) {
		//������� ��������� ������
		char chChar = random(255) + 1;
		//�������� �� ��� ������?
		for (register ULONG x = 0; x < 53; x ++) {
			if (chChar == chSymbols[x]) {
				pszRandomFileName[i] = chChar;
				i ++;
			}			
		}  
	}
	pszRandomFileName[uiRandomFileNameLen] = '\0';

	sRandomFileName = std::string(pszRandomFileName, uiRandomFileNameLen);

	//����������� ������
	/*DEBUG*/XASSERT_RET(NULL != pszRandomFileName, FALSE);
    if (NULL != pszRandomFileName) {
        delete [] pszRandomFileName;    pszRandomFileName = NULL;
    }

	//���������������
	std::string sFilePathOut("");
	sFilePathOut = sExtractFileDir(csFilePath) + "\\" + sRandomFileName;
	if (0 != rename(csFilePath.c_str(), sFilePathOut.c_str())) {
		return FALSE;
	}

	//-------------------------------------
	//������� ����
	hFile = sopen(sFilePathOut.c_str(), O_WRONLY | O_TRUNC, SH_DENYNO, S_IFREG);
	close(hFile);

	//-------------------------------------
	//������� ����
	if (- 1 == remove(sFilePathOut.c_str())) {
		return FALSE;
	}

	return TRUE;
}
//--------------------------------------------------------------------------
bool bCutFileFromEnd(const std::string &csFilePath, LONG lDistanceToCut) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), false);
	/*DEBUG*/XASSERT_RET(TRUE == bFileExists(csFilePath), false);
	/*DEBUG*/XASSERT_RET(0 < lDistanceToCut, false);

	//-------------------------------------
	//JOB
	bool bRes = false;

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,NULL);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);
	if (INVALID_SET_FILE_POINTER != ::SetFilePointer(hFile, - (lDistanceToCut), NULL, FILE_END)) {
		if (TRUE == ::SetEndOfFile(hFile)) {
			bRes = true;
		}
	}
	
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, false);
	if (NULL != hFile) {
		::CloseHandle(hFile); hFile = NULL;
	}


	return bRes;
}
//---------------------------------------------------------------------------
bool bCutFileFromEnd(FILE *pFile, ULONG ulDistanceToCut) {
    /*DEBUG*/XASSERT_RET(NULL != pFile, false);
	/*DEBUG*/XASSERT_RET(0 < ulDistanceToCut, false);

	if (0 != chsize(fileno(pFile), ulFileSize(pFile) - ulDistanceToCut)) {
		return false;
	}

	return true;
}
//--------------------------------------------------------------------------
bool bCheckSignature(CHAR *pszBuff, CHAR *pszSignature, INT iSignatureSize) {
	/*DEBUG*/XASSERT_RET(NULL != pszBuff, false);
	/*DEBUG*/XASSERT_RET(0 < ::lstrlen(pszBuff), false);
	/*DEBUG*/XASSERT_RET(NULL != pszSignature, false);
	/*DEBUG*/XASSERT_RET(0 < ::lstrlen(pszSignature), false);
	/*DEBUG*/XASSERT_RET(0 < iSignatureSize, false);
	
	////const char signature[] = "\xFF\xD8\xFF\xE0\x00\x10JFIF";
	for (INT i = 0; i < iSignatureSize; i++) {
		if (pszSignature[i] != pszBuff[i]) {
			return false;
		}
	}

	return true;
}
//--------------------------------------------------------------------------
BOOL bSetRandomFileDate(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bFileExists(csFilePath), FALSE);

	HANDLE hFile = ::CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    //��� ������ ����� ������� ���� FILE_FLAG_BACKUP_SEMANTICS.
	////HANDLE hFile = CreateFile(csFilePath.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL)
    /*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
	
	//-------------------------------------
	//���� ��������
	FILETIME ftCreationTime = {0}; 
	randomize();
	ftCreationTime.dwHighDateTime = rand();
	randomize();
	ftCreationTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� �������
	FILETIME ftLastAccessTime = {0};  
	randomize();
	ftLastAccessTime.dwHighDateTime = rand();
	randomize();
	ftLastAccessTime.dwLowDateTime  = rand();

	//-------------------------------------
	//���� ���������� ���������
	FILETIME ftLastWriteTime = {0};  
	randomize();
	ftLastWriteTime.dwHighDateTime = rand();
	randomize();
	ftLastWriteTime.dwLowDateTime  = rand();

	//-------------------------------------
	//������ ��������
	BOOL bRes = ::SetFileTime(hFile, &ftCreationTime, &ftLastAccessTime, &ftLastWriteTime);	//(LPFILETIME)NULL  
	if (FALSE == bRes) {
		/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
		if (INVALID_HANDLE_VALUE != hFile) {
			::CloseHandle(hFile); hFile = INVALID_HANDLE_VALUE;
		}
		return FALSE;
	}

	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE);
	if (INVALID_HANDLE_VALUE != hFile) {
		::CloseHandle(hFile); hFile = INVALID_HANDLE_VALUE;
	}

	return TRUE;
}
//--------------------------------------------------------------------------


/****************************************************************************
*    �������� � �������
*
*****************************************************************************/


//---------------------------------------------------------------------------
//����������, ���������� �� ��������� �������.
BOOL bDirExists(const std::string &csDirPath) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);

	if (faDirectory == ulGetFileAttr(csDirPath.c_str())) {
		return TRUE;
	}
	
	return FALSE;
}
//---------------------------------------------------------------------------
//���������� ���� ������� ��� ���
BOOL bIsDirEmpty(const std::string &csDirPath, const std::string &csMask) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csMask.empty(),    FALSE);

	BOOL            bRes;
	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            _bRet;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	if (INVALID_HANDLE_VALUE == hFile) {
		return TRUE;
	}

	do {
		std::string sFileName = std::string(fd.cFileName);

		if ("." != sFileName && ".." != sFileName) {
			bRes = FALSE;	//�� ������
		} else {
			bRes = TRUE;	//������
		}

		_bRet = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == _bRet); 

	_bRet = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != _bRet, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//���������� ������ ��� �������� ��������
std::string sGetCurrentDir() {
	TCHAR szBuff[MAX_PATH + 1] = {0};
	ULONG ulRes = ::GetCurrentDirectory(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(0 != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//������������� ������� �������
BOOL bSetCurrentDir(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 	

	return ::SetCurrentDirectory(csDirPath.c_str());
}
//--------------------------------------------------------------------------
//���������� ���� � �������� %Temp%
std::string sGetTempPath() {
	TCHAR szBuff[MAX_PATH + 1] = {'\0'};		
	ULONG ulRes = ::GetTempPath(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(FALSE != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//������� �������
BOOL bCreateDir(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 
	
	BOOL bRes = ::CreateDirectory(csDirPath.c_str(), NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//--------------------------------------------------------------------------
//������� ��� ����������� �������� �� ��������� ����
VOID vForceCreateDir(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), VOID(NULL));

	CHAR szPath[MAX_PATH + 1] = {0};

	::lstrcpy(szPath, sUnixToWinPath(csDirPath, true).c_str());  

	LPSTR pszTemp = szPath;

	if (':' == pszTemp[1]) {
		pszTemp += 3;
	}

	while (*pszTemp) {
		CHAR szPathNow[MAX_PATH + 1] = {0};

		pszTemp = strchr(pszTemp, '\\') + 1;
		::lstrcpyn(szPathNow, szPath, pszTemp - szPath);
		if (FALSE == ::CreateDirectory(szPathNow, NULL) && ERROR_ALREADY_EXISTS != ::GetLastError()) {
			throw ::GetLastError();
		}
	}
}
//---------------------------------------------------------------------------
//������� �������� �������
BOOL bDeleteDir(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = ::RemoveDirectory(csDirPath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//������� �� ���������� ����������
BOOL bForceClearDir(const std::string &csDirPath) { //��� �����
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            bRes   = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, FALSE); 	

	do {
		std::string sFileName = std::string(fd.cFileName);
		
		if ("." != sFileName && ".." != sFileName) {
			if (faDirectory == ulGetFileAttr(sPath + sFileName/*fd.dwFileAttributes*/)) {
				bRes = bForceDeleteDir(sPath + sFileName);
			} else {
				bRes = bDeleteFile(sPath + sFileName);
			}
			//if not Result then Exit;
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//������� ���������� � ��� � ����������
BOOL bForceDeleteDir(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;

	bForceClearDir(csDirPath);
	bRes = bDeleteDir(csDirPath);

	return bRes;
}
//---------------------------------------------------------------------------
//���������� ������ ������ � ����������
std::vector<std::string> vecsListFiles(const std::string &csDirPath, const std::string &csMask) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), std::vector<std::string>()); 

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;


	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, std::vector<std::string>()); 
	
	do {
		//���������� �����
		if (!(faDirectory == (fd.dwFileAttributes & faDirectory))) {
			vecsRes.push_back(std::string(fd.cFileName));	
		} 

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
//���������� ������ ���������� � ����������
std::vector<std::string> vecsListDirs(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), std::vector<std::string>()); 

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != hFile, std::vector<std::string>()); 

	do {
		//���������� ����� � "." ".."
		if ((faDirectory == (fd.dwFileAttributes & faDirectory)) && ("." != std::string(fd.cFileName)) && (".." != std::string(fd.cFileName))) {
			vecsRes.push_back(fd.cFileName);
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------


/****************************************************************************
*    �������� � �������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//���������� ���������� �����
//--BOOL bIsDriveReady(const std::string &csDrivePath) {	//���� �� ������
//	BOOL bRes          = FALSE;
//
//	//������ ���������
//	UINT uiOldErrorMode = ::SetErrorMode(SEM_FAILCRITICALERRORS);  //SEM_NOOPENFILEERRORBOX
//
//	//�������� ������� ����������
//	bRes = bSetCurrentDir(csDrivePath);
//	
//	::SetErrorMode(uiOldErrorMode);
//
//	//������ ���������� �� "�://"
//	bSetCurrentDir("C:" + csWinSlash);
//
//	return bRes;
//--}
BOOL bIsDriveReady(const std::string &csDrive) {   
	HANDLE          hFile      = INVALID_HANDLE_VALUE; 
	WIN32_FIND_DATA stFindData = {0};   

	hFile = ::FindFirstFile((csDrive + "\\*.*").c_str(), &stFindData);   
	if (INVALID_HANDLE_VALUE == hFile) {   
		return FALSE; 
	} 

	BOOL bRes = FALSE;
	bRes = ::FindClose(hFile); 
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;   
}
//--------------------------------------------------------------------------
//���������� � ������� �����
BOOL bGetDiskFreeSpace(const std::string &csDirPath, 
						ULONGLONG &lpFreeBytesAvailableToCaller,
						ULONGLONG &lpTotalNumberOfBytes,
						ULONGLONG &lpTotalNumberOfFreeBytes) 
{			   
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;
	bRes = ::GetDiskFreeSpaceEx(csDirPath.c_str(), (PULARGE_INTEGER)&lpFreeBytesAvailableToCaller, (PULARGE_INTEGER)&lpTotalNumberOfBytes, (PULARGE_INTEGER)&lpTotalNumberOfFreeBytes);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 
	
	return bRes;
}
//--------------------------------------------------------------------------


/****************************************************************************
* ����������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//������������ ������
template<class T> 
void vRandomShuffle(std::vector<T> &v) {
	std::random_shuffle(v.begin(), v.end());
	/*	std::vector<std::string>(v);
	v.push_back("111111");
	v.push_back("2222222");
	v.push_back("33333333");
	v.push_back("4444444444");
	v.push_back("55555555555");

	vRandomShuffle(v);

	for (unsigned int i = 0; i < v.size(); i ++) {
		::MessageBox(0, v.at(i).c_str(), "", MB_OK);
	}
	*/
}
//--------------------------------------------------------------------------
//��������� ������
template<class T> 
void vSortVector(std::vector<T> &v) {
	std::sort(v.begin(), v.end());
}
//--------------------------------------------------------------------------


/****************************************************************************
*    ������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//������������ ����� � ������
std::string sSizeToStr(ULONG ulSize) {
    /*DEBUG*/XASSERT_RET(0 < ulSize, "");

	std::ostringstream oss;
	oss.setf(std::ios_base::fixed);

	FLOAT       fSize = 0.0;
	std::string sUnit = "";

	if (ulSize < 1000) 
	{ //1KB
		fSize = (FLOAT)ulSize;
		sUnit = " B";
	} else if (ulSize < 1000000)
	{ //1MB
		fSize = ulSize / (FLOAT)0x400;
		sUnit = " KB";
	} else if (ulSize < 1000000000)
	
	{ //1GB
		fSize = ulSize / (FLOAT)0x100000;
		sUnit = " MB";
	} else {
		fSize = ulSize / (FLOAT)0x40000000;
		sUnit = " GB";
	}

	if (fSize == (INT)fSize) {
		oss.precision(0);
	} else if (fSize < 10) {
		oss.precision(2);
	} else if (fSize < 100) {
		oss.precision(1);
	} else {
		oss.precision(0);
	} 

	if (oss << fSize << sUnit) {
		return oss.str();
	} else {
		return "";
	} 
}
//--------------------------------------------------------------------------
//������������ FILETIME � time_t
std::string sFiletimeToStr(LPFILETIME ftFiletime) {
	if (0 == ftFiletime->dwLowDateTime && 0 == ftFiletime->dwHighDateTime) {
		return "";
	} 

	SYSTEMTIME st = {0};
	::FileTimeToSystemTime(ftFiletime, &st);
	
	CHAR szDate[20 + 1] = {0};
	::GetDateFormat(LOCALE_USER_DEFAULT, DATE_SHORTDATE, &st, NULL, szDate, 20);

	return std::string(szDate);
}
//--------------------------------------------------------------------------


/*****************************************************************************/
/*	TODO: CXFsoString (cpp)   
/*
/*****************************************************************************/


/*http://www.richelbilderbeek.nl/CppFileExists.htm*/