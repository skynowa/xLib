/**********************************************************************
*	�����  CXLog (CXLog.cpp)  
*	
***********************************************************************/


#include <XLib/CXLog.h>

#include <stdio.h>
#include <stdlib.h>

#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXFsoString.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
CXLog::CXLog() {

}
//---------------------------------------------------------------------------
CXLog::CXLog(const std::string &csFileName, ULONG ulMaxFileSize = 20) {
	/*LOCK*/::InitializeCriticalSection(&m_csLog);
	/*LOCK*/::InitializeCriticalSection(&m_csLogToLst);

	if (std::string::npos != csFileName.find('\\')) {
		m_sLogPath = sExtractFileDir(sExePath()) + csFileName;
	} else {
		m_sLogPath = sExtractFileDir(sExePath()) + csFileName;
	}

	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::CXLog(ULONG ulMaxFileSize = 20) {
	/*LOCK*/::InitializeCriticalSection(&m_csLog);
	/*LOCK*/::InitializeCriticalSection(&m_csLogToLst);

	m_sLogPath      = sExtractFileDir(sExePath()) + "\\" + sExtractFullFileName(sExePath()) + ".log";
	m_ulMaxFileSize = ulMaxFileSize;
}
//---------------------------------------------------------------------------
CXLog::~CXLog() {	
	/*UNLOCK*/::DeleteCriticalSection(&m_csLog);
	/*UNLOCK*/::DeleteCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vLog
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csStr) {     
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csStr.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);						
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, const std::string &csStr) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csStr.c_str());	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, int iValue) {
	this->vDeleteLogIfFull();
		
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %i\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), iValue);	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLog(const std::string &csComment, ULONG ulValue) {
	this->vDeleteLogIfFull();
	
	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%d:%d:%d]  %s --> %ul\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), ulValue);	//ul?????

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogLastErrorStr(const std::string &csComment, ULONG ulLastError) {
	this->vDeleteLogIfFull();

	//-------------------------------------
	//����� ���
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

    SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);

	fprintf(pFile, "[%d:%d:%d]  [%s]  %s", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sLastErrorStr(ulLastError));	

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogUCharAsHex(const std::string &csComment, unsigned char *pucBuff, ULONG ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes = "";   
	for (UINT i = 0; i < ulBuffSize; i ++) {
		if (pucBuff[i] < 16) {  
			CHAR szTemp[6] = {0};
			::wsprintf(szTemp, "0x0%x ", pucBuff[i]);
			sRes.append(szTemp);
		} else {
			CHAR szTemp[6] = {0};
			::wsprintf(szTemp, "0x%2x ", pucBuff[i]);
			sRes.append(szTemp);
	    }
	}

	//-------------------------------------
	//����� ���
	/**LOCK*/::EnterCriticalSection(&m_csLog);
	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogUCharAsStr(const std::string &csComment, UCHAR *pucBuff, ULONG ulBuffSize) {
	this->vDeleteLogIfFull();

	std::string sRes; 
	for (UINT i = 0; i < ulBuffSize; i ++) {
		//sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
		sRes.push_back((CHAR)pucBuff[i]);      //???????????
	}

 	//-------------------------------------
 	//����� ���
 	/*LOCK*/::EnterCriticalSection(&m_csLog);
 	FILE *pFile = fopen(m_sLogPath.c_str(), "a");
 	/*DEBUG*/XASSERT(NULL != pFile);

	SYSTEMTIME stST;	::ZeroMemory(&stST, sizeof(stST));
    ::GetLocalTime(&stST);
	fprintf(pFile, "[%dd:%dd:%dd] %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), sRes.c_str());

	/*DEBUG*/XASSERT(NULL != pFile);
    fflush(pFile);
	fclose(pFile);	pFile = NULL;

 	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vTrace
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csStr) {
	::OutputDebugString((csStr + "\r\n").c_str());	//VERIFY
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, const std::string &csStr) {
	::OutputDebugString((csComment + "--->" + csStr + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, int iValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(iValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
VOID CXLog::vTrace(const std::string &csComment, ULONG ulValue) {
	::OutputDebugString((csComment + "--->" + sTypeToStr(ulValue) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------
VOID CXLog::vTraceLastError(const std::string &csComment, ULONG ulLastError) {
	::OutputDebugString((csComment + "--->" + sLastErrorStr(ulLastError) + "\r\n").c_str());	
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csStr) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, const std::string &csStr) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + csStr;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, int iValue) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(iValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogToLst(HWND hLst, const std::string &csComment, ULONG ulValue) {
	/*DEBUG*/XASSERT(NULL != hLst);

	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sTypeToStr(ulValue)/*csStr*/;
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------
VOID CXLog::vLogLastErrorToLst(HWND hLst, const std::string &csComment, ULONG ulLastError) {
	/*DEBUG*/XASSERT(NULL != hLst);
	
	//-------------------------------------
	//CHECK

	//-------------------------------------
	//����� ���
	std::string sResStr("");
	sResStr = csComment + " --> " + sLastErrorStr(ulLastError);
	sResStr = sTrimChar(sResStr, '\n');
	sResStr = sTrimChar(sResStr, '\r');

	/*LOCK*/::EnterCriticalSection(&m_csLogToLst);
	::SendMessage(hLst, LB_ADDSTRING, 0, (LPARAM)sResStr.c_str());
    ::SendMessage(hLst, WM_VSCROLL, MAKEWORD(SB_LINEDOWN, 0), 0);
	/*UNLOCK*/::LeaveCriticalSection(&m_csLogToLst);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	vWriteToLst
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vDelete() {
	//-------------------------------------
	//CHECK
    if (false == bFileExists(m_sLogPath)) {
		return;
	}	

	//-------------------------------------
	//JOB
	if (false == bSetFileAttr(m_sLogPath, faNormal)) {
        /*DEBUG*/XASSERT(false);
    }
    if (false == bDeleteFile(m_sLogPath)) {
        /*DEBUG*/XASSERT(false);
    }
}
//---------------------------------------------------------------------------
VOID CXLog::vOpen() {
	STARTUPINFO si         = {0};
	PROCESS_INFORMATION pi = {0};
	//��������� �������� ��������� STARTUPINFO �� ���������
	si.cb = sizeof(STARTUPINFO);

	std::string sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.2\\notepad++.exe " + m_sLogPath; 
	if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		return;
	}	

	::Sleep(500);  //������� �������� � �������� ���� ������
	
	//������� ����������� ����������� �������� � ������� ��������
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);
}
//---------------------------------------------------------------------------
VOID CXLog::vClear() {
	FILE *pFile = fopen(m_sLogPath.c_str(), "w");
	/*DEBUG*/XASSERT(NULL != pFile);
	
	/*LOCK*/::EnterCriticalSection(&m_csLog);
	
	fprintf(pFile, "");	
	
	/*UNLOCK*/::LeaveCriticalSection(&m_csLog);

    /*DEBUG*/XASSERT(NULL != pFile);
	fflush(pFile);
	fclose(pFile);	pFile = NULL;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Other
*
*****************************************************************************/

//---------------------------------------------------------------------------
//VOID CXLog::vErrorMessageBox() {
//	LPVOID lpMsgBuf = NULL;
//	::FormatMessage( 
//		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
//		FORMAT_MESSAGE_FROM_SYSTEM | 
//		FORMAT_MESSAGE_IGNORE_INSERTS,
//		NULL,
//		GetLastError(),
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
//		(LPSTR) &lpMsgBuf,
//		0,
//		NULL
//	);
//	MessageBox(NULL, (LPCSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
//	LocalFree(lpMsgBuf);
//}
//---------------------------------------------------------------------------
VOID CXLog::vMsgBoxLastError(const std::string &csComment) {
	ULONG       ulLastError = ::GetLastError();
	std::string sRes        = csComment + " ---> " + sLastErrorStr(ulLastError);

	::MessageBox(0, sRes.c_str(), "Last error", MB_OK);
}
//---------------------------------------------------------------------------




/****************************************************************************
*	Private methodz
*
*****************************************************************************/

//---------------------------------------------------------------------------
VOID CXLog::vDeleteLogIfFull() {
	//-------------------------------------
	//CHECK
	if (false == bFileExists(m_sLogPath)) {
		return;
	}
	
	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if ((ulFileSize(m_sLogPath) / 1000000) >= m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		//MessageBox(0, "��� ����� ������", "", MB_OK);
		vDelete();
	}
}
//---------------------------------------------------------------------------