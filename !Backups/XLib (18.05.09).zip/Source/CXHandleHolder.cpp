/****************************************************************************
*    �����: CXHandleHolder (CXHandleHolder.h)
*
*****************************************************************************/


#include <XLib/CXHandleHolder.h>
//---------------------------------------------------------------------------
CXHandleHolder::CXHandleHolder() { 
	m_hHandle = NULL; 
} 
//---------------------------------------------------------------------------
CXHandleHolder::CXHandleHolder(HANDLE hHandle) { 
	/*DEBUG*/assert(NULL != hHandle);

	m_hHandle = hHandle; 
} 
//---------------------------------------------------------------------------
CXHandleHolder::~CXHandleHolder() { 
	/*DEBUG*/assert(NULL != m_hHandle);

	if (m_hHandle) {
		::CloseHandle(m_hHandle);	m_hHandle = NULL;
	}
} 
//---------------------------------------------------------------------------
CXHandleHolder::operator HANDLE() { 
	/*DEBUG*/assert(NULL != m_hHandle);

	return m_hHandle; 
} 
//---------------------------------------------------------------------------
HANDLE CXHandleHolder::operator = (HANDLE hHandle) { 
	/*DEBUG*/assert(NULL != hHandle);

	return (m_hHandle = hHandle); 
} 
//---------------------------------------------------------------------------

