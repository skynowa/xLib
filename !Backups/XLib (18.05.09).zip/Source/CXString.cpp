/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.cpp
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/CXString.h>

#include <windows.h>
#include <sstream>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include <tchar.h>
#include <stdlib.h>
#include <cctype>
#include <algorithm>
#include <ctime>

#include <XLib/xassert.h>

#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
size_t uiStrLen(const char * s) {
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		/* nothing */;
	return sc - s;
}
//---------------------------------------------------------------------------
//fast
inline char *findSubstr(char *str, char *substr) {
	char *tmp = str, *tmpsubstr, *match; // ����� �� �������� ��� register - ����� �������.
	char c;
	
	while(*tmp) {
		tmpsubstr = substr;

		c = *tmpsubstr;
		while (*tmp && (*tmp != c)) {
			tmp++;
		}

		// ��� ���:
		// tmp = strchr (str, *tmpsubstr);

		match = tmp; 

		while(*tmp && *tmpsubstr && (*tmp == *tmpsubstr)) {
			tmp ++;
			tmpsubstr ++;
		}
		if (!*tmpsubstr) {
			return match;
		}
	}

	return NULL;
}
//---------------------------------------------------------------------------
LONG StrToLONG(LPCTSTR pwszValue, LONG Default /*= 0*/, INT Radix /*= 0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        LONG nResult = _tcstol(pwszValue, &pszStop, Radix);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return (Default);  
}
//---------------------------------------------------------------------------
ULONG StrToDWORD(LPCTSTR pwszValue, DWORD Default /*= 0*/, INT Radix /*= 0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        LONG nResult = _tcstoul(pwszValue, &pszStop, Radix);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return Default;  
}
//---------------------------------------------------------------------------
BOOL StrToBOOL(LPCTSTR pwszValue, BOOL fDefault /* = FALSE */) {
    return *pwszValue != 0 ? _tcschr(_T("1tTyY"), pwszValue[0]) != NULL : fDefault;
}
//---------------------------------------------------------------------------
DOUBLE StrToDOUBLE(LPCTSTR pwszValue, DOUBLE Default /*= 0.0*/) {
    LPTSTR pszStop = NULL;
    if (0 != *pwszValue) {
        DOUBLE nResult = _tcstod(pwszValue, &pszStop);
        if (0 == *pszStop) {
            return nResult;
        }
    }

    return Default;    
}
//---------------------------------------------------------------------------
SHORT StrToSHORT(LPCTSTR pwszValue, SHORT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<SHORT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
USHORT StrToWORD(LPCTSTR pwszValue,WORD Default /*= 0*/, INT Radix /*= 0*/) {
	return LOWORD(/*= 0*/StrToDWORD(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
UCHAR StrToBYTE(LPCTSTR pwszValue, UCHAR Default /*= 0*/, INT Radix /*= 0*/) {
	return LOBYTE(LOWORD(/*= 0*/StrToDWORD(pwszValue, Default, Radix)));  
}
//---------------------------------------------------------------------------
bool StrToBool(LPCTSTR pwszValue, bool Default /* = false */) {
    return /*= 0*/StrToBOOL(pwszValue, Default) != 0;
}
//---------------------------------------------------------------------------
INT StrToINT(LPCTSTR pwszValue, INT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<INT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
UINT StrToUINT(LPCTSTR pwszValue, UINT Default /*= 0*/, INT Radix /*= 0*/) {
	return static_cast<UINT>(/*= 0*/StrToLONG(pwszValue, Default, Radix));
}
//---------------------------------------------------------------------------
bool bStrToUCHAR(const std::string &csStr, UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), false);
    /*DEBUG*/XASSERT_RET(NULL != pucBuff, false);    
    /*DEBUG*/XASSERT_RET(0 < uiBuffSize, false); 
    /*DEBUG*/XASSERT_RET(csStr.size() <= uiBuffSize, false);     

	for (UINT i = 0; i < csStr.size(); i ++)  { 
		pucBuff[i]  = static_cast<unsigned char>(csStr.at(i)); 
	}    
   
	////std::vector<unsigned char> data;
	////std::copy(csStr.begin(), csStr.end(), std::back_inserter(data));
	////pucBuff = data;

	return true;
}
//---------------------------------------------------------------------------
std::string sUCHARToStr(UCHAR *pucBuff, UINT uiBuffSize) {
    /*DEBUG*/XASSERT_RET(NULL != pucBuff, "");    
    /*DEBUG*/XASSERT_RET(0 < uiBuffSize, ""); 
	
	return std::string((CHAR *)pucBuff, uiBuffSize);
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
std::string sTrimSpace(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
   
    return sTrimChar(csStr, ' ');
}
//---------------------------------------------------------------------------
std::string sTrimChar(const std::string &csStr, CHAR cChar) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
    std::string sRes("");
    sRes.assign(csStr);

    while ((!sRes.empty()) && (cChar == *sRes.begin())) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (cChar == *sRes.rbegin())) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;	
}
//---------------------------------------------------------------------------
std::string sRemoveEOL(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes("");
    sRes.assign(csStr);

	//������� \r\n
	sRes = sTrimChar(sRes, '\n');
	sRes = sTrimChar(sRes, '\r');
    
    return sRes;	
}
//---------------------------------------------------------------------------
std::string sReplaceAll(const std::string &csStr, const std::string &csOldStr, const std::string &csNewStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), "");	
    /*DEBUG*/XASSERT_RET(false == csOldStr.empty(), csStr);  

	std::string sRes("");
	sRes.assign(csStr);
	
	std::string::size_type stPos = 0;

	while (std::string::npos != (stPos = sRes.find(csOldStr))) {
		sRes = sRes.replace(stPos, 1, csNewStr);
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::string sReplaceAll(const std::string &csStr, CHAR cOldStr, CHAR cNewStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes("");
    sRes.assign(csStr);
	
	for (UINT i = 0; i < sRes.size(); i ++) {
		if (sRes.at(i) == cOldStr) {
			sRes.at(i) = cNewStr;	
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::vector<std::string> vecsSplit(CHAR cDelimiter, const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), std::vector<std::string>()); 
    
	std::vector<std::string> vecRes;
	std::size_t              uiPos    = 0;	//start of string	
	std::size_t              uiOldPos = 0;	//start of string
   
   while (std::string::npos != (uiPos = csStr.find(cDelimiter, uiOldPos))) {
		vecRes.push_back(csStr.substr(uiOldPos, uiPos - uiOldPos));
		uiOldPos = uiPos + 1;
   }
   vecRes.push_back(csStr.substr(uiOldPos, - 1));
   
   return vecRes;
}
//---------------------------------------------------------------------------
std::vector<std::string> vecsSplitEx(CHAR *pszStr, CHAR *pszDelimiter) {
    /*DEBUG*/XASSERT_RET(NULL != pszStr, std::vector<std::string>());        
	/*DEBUG*/XASSERT_RET('\0' != *pszStr, std::vector<std::string>()); 
    /*DEBUG*/XASSERT_RET(NULL != pszDelimiter, std::vector<std::string>());        
	/*DEBUG*/XASSERT_RET('\0' != *pszDelimiter, std::vector<std::string>()); 

	std::vector<std::string> vescRes;
	std::size_t              uiPos     = 0; 
	std::size_t              uiPrevPos = 0;
	std::string              sCopy     = std::string(pszStr);

	while (std::string::npos != (uiPos = sCopy.find(pszDelimiter, uiPos))) {
		vescRes.push_back(std::string(sCopy, uiPrevPos, uiPos - uiPrevPos));
		uiPrevPos = ++ uiPos;
	}
	vescRes.push_back(std::string(sCopy, uiPrevPos, sCopy.size() - uiPrevPos));

	return vescRes;
}
//---------------------------------------------------------------------------
//��������� ������ �� ��������� �� �������-�����������, ��������� ������ ����� (vector)
std::vector<std::string> vecsSplit(const std::string &csSep, const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csSep.empty(), std::vector<std::string>());	
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(csStr.substr(0, csSep.size()) != csSep, std::vector<std::string>());
	/*DEBUG*/XASSERT_RET(csStr.substr(csStr.size()- csSep.size(), csSep.size()) != csSep, std::vector<std::string>());
	
	std::size_t              uiOldPos = 0; 	//start of string
	std::size_t              uiPos    = 0;
	std::vector<std::string> vescRes;
    while (std::string::npos != (uiPos = csStr.find(csSep, uiOldPos))) {
		vescRes.push_back(csStr.substr(uiOldPos, uiPos - uiOldPos));
		uiOldPos = uiPos + csSep.size()/*1*/;
	}
	vescRes.push_back(csStr.substr(uiOldPos, - 1));

	return vescRes;
}

//---------------------------------------------------------------------------
//vecsSplit_3
////std::vector<std::string> vecsSplit_3(const std::string &csStr, CHAR cDelimiter) {  
////	std::istringstream       isStr(csStr);
////	std::vector<std::string> vescRes((std::istream_iterator<std::string>(isStr)), (std::istream_iterator<std::string>()));
////	
////	std::copy(vescRes.begin(), vescRes.end(), std::ostream_iterator<std::string>(std::cout, cDelimiter));
////	
////	return vescRes;
////}
//---------------------------------------------------------------------------
//"���������" ������ ������� ��������-������������
std::string sJoin(CHAR chSep, std::vector<std::string> vecsVec) {
	std::string sRes;

	for (size_t i = 0; i < vecsVec.size(); i ++) {
		sRes += vecsVec.at(i);
		sRes += chSep;
	}

	return sRes;
}
//---------------------------------------------------------------------------
bool bCharToWide(const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize) {
    /*DEBUG*/XASSERT_RET(NULL != pszSrc, false);        
	/*DEBUG*/XASSERT_RET('\0' != *pszSrc, false); 
    /*DEBUG*/XASSERT_RET(NULL != pwszDest, false);        
	/*DEBUG*/XASSERT_RET('\0' != *pwszDest, false); 
    
	bool bRes = false;
	if (0 == ::MultiByteToWideChar(CP_ACP, 0, pszSrc, - 1, pwszDest, iDestSize)) {
		bRes = false;
	}

	return bRes;		
}
//---------------------------------------------------------------------------
CHAR cHexToChar(CHAR *pszStr) {
    /*DEBUG*/XASSERT_RET(NULL != pszStr, '\0');        
	/*DEBUG*/XASSERT_RET('\0' != *pszStr, '\0'); 

	CHAR ch = '\0';

	if (pszStr[0] >= 'A') {
		ch = ((pszStr[0] & 0xdf) - 'A') + 10;
	} else {
		ch = pszStr[0] - '0';
	}

	ch <<= 4;

	if (pszStr[1] >= 'A') {
		ch += ((pszStr[1] & 0xdf) - 'A') + 10;
	} else {
		ch += pszStr[1] - '0';
	}

	return ch;
}
//---------------------------------------------------------------------------
//%FF%E4%F0%E5%ED%E0%20%62%75%67%73 -> "������ bugs"
std::string sUrlUnescape(const std::string &csStr) {  /*sBase64Decode*/
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes("");
    sRes.assign(csStr);

	UINT uiSrc  = 0;
	UINT uiDest = 0;
	CHAR ch     = 0;
	
	for (uiSrc = 0, uiDest = 0; sRes.at(uiSrc); uiSrc ++, uiDest ++)   {
		ch = sRes.at(uiSrc);
		ch = ('+' == ch) ? ' ' : ch;
		sRes.at(uiDest) = ch;

		if ('%' == ch)	{
			sRes.at(uiDest) = cHexToChar(&sRes.at(uiSrc + 1));
			uiSrc += 2;
		}
	}
	sRes.at(uiDest) = '\0';		//�������� ��� ��� ���� ����� '\0'

	return std::string(sRes.c_str());	//���������� ��-���� ������, ��� �� ����
}
//---------------------------------------------------------------------------
//string -> %20%20%...
std::string sStrToBin(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes("");
	for (UINT i = 0; i < csStr.size(); i ++) {
		sRes.append("%" + sTypeToStr((INT)((UCHAR)csStr.at(i))));
	}

	return sRes;
}
//---------------------------------------------------------------------------
//%20%20%... -> string  ???????
std::string sBinToStr(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string              sRes     = "";
	std::vector<std::string> vecsList = vecsSplit('%', csStr);

	for (UINT i = 1; i < vecsList.size(); i ++) {	//i = 1 - ������ ������ ������
		//str(59) -> char() -> string
		INT  iIntValue  = iStrToType<INT>(vecsList.at(i));
		CHAR cCharValue = (CHAR)iIntValue;
		std::string sStrValue(1, cCharValue);

		sRes.append(sStrValue);
	}

	return sRes;
}
//---------------------------------------------------------------------------
std::string sTranslitLatToRus(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes("");
    sRes.assign(csStr);

	//-------------------------------------
	//�������
	const INT   ciDictSize = 66;
	std::string sDict[ciDictSize][2] = {
			{"�", "Y"}, {"�", "C"},  {"�", "U"},   {"�", "K"},	{"�", "E"}, {"�", "E"}, {"�", "N"},	
			{"�", "G"}, {"�", "SH"}, {"�", "SH'"}, {"�", "Z"},  {"�", "H"}, {"�", "`"}, {"�", "F"}, 
			{"�", "I"}, {"�", "V"},  {"�", "A"},   {"�", "P"},	{"�", "R"}, {"�", "O"}, {"�", "L"},  
			{"�", "D"}, {"�", "ZH"}, {"�", "E"},   {"�", "YA"}, {"�", "4"}, {"�", "S"}, {"�", "M"},   
			{"�", "I"}, {"�", "T"},  {"�", "'"},   {"�", "B"},  {"�", "YU"},
			
			{"�", "y"}, {"�", "c"},  {"�", "u"},   {"�", "k"},  {"�", "e"}, {"�", "e"}, {"�", "n"},	 
			{"�", "g"}, {"�", "sh"}, {"�", "sh'"}, {"�", "z"},	{"�", "h"}, {"�", "`"}, {"�", "f"}, 
			{"�", "i"}, {"�", "v"},  {"�", "a"},   {"�", "p"},  {"�", "r"}, {"�", "o"}, {"�", "l"},  
			{"�", "d"}, {"�", "zh"}, {"�", "e"},   {"�", "ya"}, {"�", "4"}, {"�", "s"}, {"�", "m"},  
			{"�", "i"}, {"�", "t"},  {"�", "'"},   {"�", "b"},  {"�", "yu"}
	};

	//-------------------------------------
	//������ ��������
	for (INT i = 0; i < ciDictSize; i ++) {
		sRes = sReplaceAll(sRes, sDict[i][0], sDict[i][1]);
		////--std::string            sOldStr = sDict[i][0];
		////std::string            sNewStr = sDict[i][1];
		////std::string::size_type stPos   = 0;

		////while (std::string::npos != (stPos = sRes.find(sOldStr))) {
		////	sRes.replace(stPos, 1, sNewStr);
		////--}
	}

	return sRes;
}
//-------------------------------------------------------------------------
std::string sToLowerCase(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += std::tolower(csStr.at(i));
	}
		
	return sRes;

	/* 
	//explicit cast needed to resolve ambiguity
	std::transform(myString.begin(), myString.end(), myString.begin(), (int(*)(int)) std::tolower);
	*/
}
//---------------------------------------------------------------------------
std::string sToUpperCase(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 

	std::string sRes("");
	for (size_t i = 0; i < csStr.size(); ++ i) {
		sRes += std::toupper(csStr.at(i));
	}
		
	return sRes;

	/*
	//explicit cast needed to resolve ambiguity
	std::transform(s.begin(), s.end(), s.begin(), (int(*)(int)) std::toupper);
	return s;
	*/
}
//---------------------------------------------------------------------------
INT	iCharCodeAt(const std::string &csStr, INT iIndex) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), 0); 
    /*DEBUG*/XASSERT_RET(0 < iIndex, 0); 
        
	return static_cast<INT>(csStr.at(iIndex));
}
//---------------------------------------------------------------------------




/****************************************************************************
*	�������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//This is ASCII specific but is safe with chars >= 0x80
bool bIsSpaceChar(UCHAR ch) {
	return (ch == ' ') || ((ch >= 0x09) && (ch <= 0x0d));
}
//---------------------------------------------------------------------------
bool bIsPunctuation(CHAR ch) {
	return isascii(ch) && ispunct(ch);
}
//---------------------------------------------------------------------------
bool bIsADigit(CHAR ch) {
	return isascii(ch) && isdigit(ch);
}
//---------------------------------------------------------------------------
bool bIsLowerCase(CHAR ch) {
	return isascii(ch) && islower(ch);
}
//---------------------------------------------------------------------------
bool bIsUpperCase(CHAR ch) {
	return isascii(ch) && isupper(ch);
}
//---------------------------------------------------------------------------
bool bIsASpaceOrTab(UINT ch) {
	return (ch == ' ') || (ch == '\t');
}
//---------------------------------------------------------------------------
bool bIsADigit(UINT ch) {
	return (ch >= '0') && (ch <= '9');
}
//---------------------------------------------------------------------------
bool bIsADigit(UINT ch, UINT base) {
	if (base <= 10) {
		return (ch >= '0') && (ch < '0' + base);
	} else {
		return ((ch >= '0') && (ch <= '9'))            ||
		       ((ch >= 'A') && (ch < 'A' + base - 10)) ||
		       ((ch >= 'a') && (ch < 'a' + base - 10));
	}
}
//---------------------------------------------------------------------------
INT iGetHexChar(UCHAR hd1, UCHAR hd2) {
	int iHexValue = 0;
	
	if (hd1 >= '0' && hd1 <= '9') {
		iHexValue += 16 * (hd1 - '0');
	} else if (hd1 >= 'A' && hd1 <= 'F') {
		iHexValue += 16 * (hd1 - 'A' + 10);
	} else if (hd1 >= 'a' && hd1 <= 'f') {
		iHexValue += 16 * (hd1 - 'a' + 10);
	} else {
		return - 1;
	}

	if (hd2 >= '0' && hd2 <= '9') {
		iHexValue += hd2 - '0';
	} else if (hd2 >= 'A' && hd2 <= 'F') {
		iHexValue += hd2 - 'A' + 10;
	} else if (hd2 >= 'a' && hd2 <= 'f') {
		iHexValue += hd2 - 'a' + 10;
	} else {
		return - 1;
	}
		
	return iHexValue;
}
//---------------------------------------------------------------------------
bool bIsLetter(CHAR ch) {
	return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'));
}
//---------------------------------------------------------------------------
bool bIsASpace(UINT ch) {
    return (ch == ' ') || ((ch >= 0x09) && (ch <= 0x0d));
}
//---------------------------------------------------------------------------
//non-Unicode characters only
CHAR cMakeUpperCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
		return static_cast<CHAR>(ch - 'a' + 'A');
	}
}
//---------------------------------------------------------------------------
//non-Unicode characters only
CHAR cMakeLowerCase(CHAR ch) {
	if (ch < 'a' || ch > 'z') {
		return ch;
	} else {
        return static_cast<CHAR>(ch - 'A' + 'a');
	}
}
//---------------------------------------------------------------------------
bool IsEOLChar(CHAR ch) {
	return ('\r' == ch) || ('\n' == ch);
}
//---------------------------------------------------------------------------
bool IsLineEndChar(CHAR ch) {
	return ('\n' == ch || '\r' == ch);
}
//---------------------------------------------------------------------------
bool bIsSlash(CHAR ch) {
	return ('\\' == ch || '/' == ch );
}
//---------------------------------------------------------------------------
//���������� ���� ��������� n (���������)
ULONG ulCountDigits(ULONG ulDigit) {
    ULONG ulRes = 0;
    
	for (; (ulDigit /= 10); ulRes ++);
    
	return ulRes;
}
//---------------------------------------------------------------------------



/****************************************************************************
*	���������
*
*****************************************************************************/


//---------------------------------------------------------------------------
std::string sStrToRtf(std::string sStr) {
    /*DEBUG*/XASSERT_RET(false == sStr.empty(), ""); 
    
    std::ostringstream    ss;
    std::string::iterator i = sStr.begin();

    while (i < sStr.end()) {
        //if ( ( ( INT ) ( unsigned char ) *i ) > 127 )
        INT c = static_cast<INT>(static_cast<UCHAR>(*i));
		if (c > 127) {
            //ss << hex << "\\\'" << ( INT ) ( unsigned char ) *i;
            ss << std::hex << "\\\'" << c;
		} else {
            //ss << ( UCHAR ) *i;
            ss << static_cast<UCHAR>( *i );
		}
        i ++;
    }

    return ss.str();
}
//---------------------------------------------------------------------------
std::string sRtfToStr(std::string sStr) {
    /*DEBUG*/XASSERT_RET(false == sStr.empty(), ""); 
    
    std::string::size_type	resultPos = 0;
    std::string::size_type	startFind = 0;
    std::ostringstream		ss;
    char					buf[]     = "ff";
    char				   *resPos    = &buf[0];
    char				   *pstr      = NULL;

    //Search \'xx
    while (std::string::npos != (resultPos = sStr.find("\\\'", startFind))) {
        //copy start part of string
		if (resultPos > startFind) {
            ss << sStr.substr(startFind, resultPos - startFind);
		}

        //if (end) exit
		if (resultPos + 4 > sStr.size()) {
            break;
		}

        //Copy char
        sStr.copy(buf, 2, resultPos + 2);
        LONG CharCode = strtoul(resPos, &pstr, 16);
        if (CharCode > 127) {
            ss << static_cast<UCHAR>(strtoul(resPos, &pstr, 16)); // 16 == hex base
            startFind = resultPos + 4;
        } else {
            ss << "\\\'";
            startFind = resultPos + 2;
        }
    }

    //copy end part of string
	if (startFind < sStr.size()) {
        ss << sStr.substr(startFind, sStr.size() - startFind );
	}

    return ss.str();
}
//---------------------------------------------------------------------------
std::string sFormatStr(LPCSTR pcszFormat, ...) {
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	std::vector<CHAR> vecchBuff(128, 0);
	INT               iWrittenSize = - 1;

	va_list pszArgList = NULL;
	va_start(pszArgList, pcszFormat);

	for (;;) {
		//���� win32 �� ���������� _vsnprintf (��� C++Builder - vsnprintf)
		iWrittenSize = vsnprintf(&vecchBuff[0], vecchBuff.size(), pcszFormat, pszArgList);	//error - 1
		/*DEBUG*/XASSERT_RET(NULL != pszArgList, ""); 
		/*DEBUG*/XASSERT_RET('\0' != pszArgList, ""); 
		if (iWrittenSize > - 1 && iWrittenSize < (INT)vecchBuff.size()) {	//!����� ���� ������ �����!
			break; //succeeded
		}
		vecchBuff.resize(vecchBuff.size() * 2);
	}

	va_end(pcszFormat);

	return std::string(vecchBuff.begin(), vecchBuff.begin() + iWrittenSize/* - 1*/);
}
//---------------------------------------------------------------------------
std::string sFormatStr2(LPCSTR pcszFormat, ...) {	//!������������ ������!
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, "");        
	/*DEBUG*/XASSERT_RET('\0' != *pcszFormat, ""); 

	const ULONG culBufSize                  = 1024;
	CHAR        szFormatBuf[culBufSize + 1] = {0}; 

	va_list pszArgList = NULL;
	va_start(pszArgList, pcszFormat);
	
	INT iStored = 0;

	iStored = ::wvsprintf(szFormatBuf, pcszFormat, pszArgList);
	szFormatBuf[culBufSize] = '\0';
	/*DEBUG*/XASSERT_RET(::lstrlen(szFormatBuf) == iStored, ""); 	
	/*DEBUG*/XASSERT_RET(NULL != pszArgList, ""); 
	/*DEBUG*/XASSERT_RET('\0' != pszArgList, ""); 

	va_end(pszArgList);

	return std::string(szFormatBuf, iStored);
}
//---------------------------------------------------------------------------
std::string sMinimizeStr(const std::string &csStr, const UINT cuiMaxLen) {	
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    /*DEBUG*/XASSERT_RET(0 < cuiMaxLen,          ""); 
	
	std::string sRes("");

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < 3) {
			sRes = csStr.substr(0, cuiMaxLen);
    	} else {
			sRes = csStr.substr(0, cuiMaxLen - 3) + "...";
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//--------------------------------------------------------------------------
std::string sCreatePlainGUID() { 
	GUID    _Guid = {0};
	HRESULT hrGuid = ::CoCreateGuid(&_Guid);
	/*DEBUG*/XASSERT_RET(SUCCEEDED(hrGuid), "");

	const INT ciGuidSize             = 36;
	CHAR      szBuff[ciGuidSize + 1] = {0};	
	
	INT iStored = ::wsprintf(
		szBuff, 
		"%04X-%02X-%02X-%02X%02X-%02X%02X%02X%02X%02X%02X",
		_Guid.Data1, 
		_Guid.Data2, 
		_Guid.Data3,
		_Guid.Data4[0], _Guid.Data4[1],
		_Guid.Data4[2], _Guid.Data4[3], _Guid.Data4[4], _Guid.Data4[5], _Guid.Data4[6], _Guid.Data4[7]
	);

	/*DEBUG*/XASSERT_RET(NULL != szBuff,                  "");
	/*DEBUG*/XASSERT_RET(ciGuidSize >= ::lstrlen(szBuff), "");
	/*DEBUG*/XASSERT_RET(ciGuidSize >= iStored,           "");
	/*DEBUG*/XASSERT_RET(MAX_PATH > ::lstrlen(szBuff),    "");


	return std::string(szBuff, iStored);
}   
//---------------------------------------------------------------------------
bool bIsRepeatedStr(const std::string &csStr) {
    /*DEBUG*/XASSERT_RET(false == csStr.empty(), ""); 
    
	size_t uiStrLen = csStr.size();
	for (size_t i = 1; i < uiStrLen; i ++) {
		if (csStr.at(0) != csStr.at(i)) {
			return false;
		}
	}

	return true;
}
//---------------------------------------------------------------------------
std::string sLastErrorStr(ULONG ulLastError) {
	std::string sRes     = "";
	LPVOID      lpMsgBuf = NULL;

	ULONG ulRes = FALSE;

	ulRes = ::FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
		(LPSTR) &lpMsgBuf,
		0,
		NULL
	);
	/*DEBUG*/XASSERT_RET(FALSE != ulRes, "");

	sRes = std::string((LPCSTR)lpMsgBuf);

	/*DEBUG*/XASSERT_RET(NULL != lpMsgBuf, "");
	::LocalFree(lpMsgBuf); lpMsgBuf = NULL;

	return sRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	Random
*
*****************************************************************************/


//--------------------------------------------------------------------------
//////void RandomizeTimer() {
//////	  std::srand(std::time(0));
//////}
//--------------------------------------------------------------------------



/****************************************************************************
*	��������
*
*****************************************************************************/


//---------------------------------------------------------------------------
//timestamp
std::string timestamp() {
	char        run_date[128] = {0};
	std::time_t tod;
	std::time(&tod );
	std::strftime(run_date, sizeof(run_date), "%Y-%m-%d %X UTC", std::gmtime(&tod));

	return std::string(run_date);
}
//---------------------------------------------------------------------------
//convert path separators to forward slashes
void convert_path_separators(std::string &s) {
	for (std::string::iterator itr = s.begin(); itr != s.end(); ++ itr) {
		if (*itr == '\\' || *itr == '!') {
			*itr = '/';
		}
	}
}
//---------------------------------------------------------------------------
//trim_left
/*std::string trim_left(std::string const &s ) {
	std::string::size_type const pos(s.find_first_not_of(' '));

	return (pos != std::string::npos) ? s.substr(pos, s.size() - pos + 1) : "";
}*/
//---------------------------------------------------------------------------
//split
/*std::vector<std::string> split(std::string const &s) {
	std::string::size_type const pos   (s.find_first_of(' '));
	std::vector<std::string>     result(1, s.substr( 0, pos ));

	if (pos == std::string::npos) {
		return result;
	}

	std::vector<std::string> const rest(split(trim_left(s.substr(pos, s.size() - pos + 1))));
	result.insert(result.end(), rest.begin(), rest.end());    

	return result;
} */
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
/*void RemoveChar(string & str, const char ch) {
    for (int i = str.find(ch); i != string::npos; i = str.find(ch)) {
        str.erase(i, 1);
    }
}*/
//---------------------------------------------------------------------------

/*WrapText	��������� ������ �� ���������.*/

////////// Some ATL string conversion enhancements
////////// ATL's string conversions allocate memory on the stack, which can
////////// be undesirable if converting huge strings.  These enhancements
////////// provide for a pre-allocated memory block to be used as the 
////////// destination for the string conversion.
////////#define _W2A(dst,src) AtlW2AHelper(dst,src,lstrlenW(src)+1)
////////#define _A2W(dst,src) AtlA2WHelper(dst,src,lstrlenA(src)+1)
////////
////////typedef std::wstring StringW;
////////typedef std::string  StringA;
////////
////////#ifdef _UNICODE
////////typedef StringW String;
////////#define _W2T(dst,src) lstrcpyW(dst,src)
////////#define _T2W(dst,src) lstrcpyW(dst,src)
////////#define _T2A(dst,src) _W2A(dst,src)
////////#define _A2T(dst,src) _A2W(dst,src)
////////#else
////////typedef StringA String;
////////#define _W2T(dst,src) _W2A(dst,src)
////////#define _T2W(dst,src) _A2W(dst,src)
////////#define _T2A(dst,src) lstrcpyA(dst,src)
////////#define _A2T(dst,src) lstrcpyA(dst,src)
////////#endif

/**********************************************************************
*
*   <<< ������ �������������: >>>
*   std::string str;
*   int         iVal;
*   float       fVal;
*
*   str = sTypeToStr(iVal);
*   str = sTypeToStr(fVal);
*
*   iVal = iStrToType<int>(str);
*   fVal = iStrToType<float>(str);
*
***********************************************************************/
/**********************************************************************
LARGE_INTEGER li = {1234567890};
std::stringstream ss;
ss << li;
std::string s = ss.str();
***********************************************************************/