/****************************************************************************
*	CXCheckBox
*
*****************************************************************************/


#include <Xlib/CXWinControls/CXCheckBox.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXCheckBox::CXCheckBox() {
	_m_sClassName = "BUTTON";
	_m_iLeft      = _m_iTop = 0;
	_m_iWidth     = _m_iHeight = 50;
}
//---------------------------------------------------------------------------
BOOL CXCheckBox::Create(HWND hParent, HMENU hmnuID, DWORD dwStyles, DWORD dwExStyles) {
	_m_hWnd = ::CreateWindowEx(
				dwExStyles,
				_m_sClassName.c_str(),  
				_m_sText.c_str(), 
				WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX | dwStyles,  
				_m_iLeft,		
				_m_iTop,		
				_m_iWidth,		
				_m_iHeight,		
				hParent,		
				(HMENU)hmnuID,			
				(HINSTANCE)::GetWindowLong(hParent, GWL_HINSTANCE), 
				this); 

	if (NULL == _m_hWnd) {
		return FALSE;
	} 

	SetDefaultFont();
	Subclass();

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXCheckBox::IsChecked() {
	/*DEBUG*/XASSERT(bIsWindow());

	return SendMessage(BM_GETCHECK, 0, 0) == BST_CHECKED;
}
//---------------------------------------------------------------------------
VOID CXCheckBox::Check(BOOL bChecked) {
	/*DEBUG*///XASSERT(this->bIsWindow());

	SendMessage(BM_SETCHECK, bChecked ? BST_CHECKED : BST_UNCHECKED, 0);
}
//---------------------------------------------------------------------------