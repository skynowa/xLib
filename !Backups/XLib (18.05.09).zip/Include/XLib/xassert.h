/****************************************************************************
* Class name:  xassert
* Description: ������� ����
* File name:   xassert.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     29.04.2009 12:45:18
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XASSERT_H
#define XASSERT_H
//---------------------------------------------------------------------------
#include <windows.h>
#include <stddef.h>
#include <string>
//---------------------------------------------------------------------------
#if defined(__GNUC__) || (defined(__MWERKS__) && (__MWERKS__ >= 0x3000)) || (defined(__ICC) && (__ICC >= 600))
#    define __OUT_FUNC__ __PRETTY_FUNCTION__
#elif defined(__DMC__) && (__DMC__ >= 0x810)
#    define __OUT_FUNC__ __PRETTY_FUNCTION__
#elif defined(__FUNCSIG__)
#    define __OUT_FUNC__ __FUNCTION__ /*__FUNCSIG__*/
#elif (defined(__INTEL_COMPILER) && (__INTEL_COMPILER >= 600)) || (defined(__IBMCPP__) && (__IBMCPP__ >= 500))
#    define __OUT_FUNC__ __FUNCTION__
#elif defined(__BORLANDC__) && (__BORLANDC__ >= 0x550)
#    define __OUT_FUNC__ __FUNC__
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 199901)
#    define __OUT_FUNC__ __func__
#else
#    define __OUT_FUNC__ "<unknown>"
#endif
//---------------------------------------------------------------------------
//#define NXDEBUG 0

#ifdef NDEBUG
    VOID vAssertLog(const std::string &csExp, ULONG ulLastError, const std::string &csFile, ULONG ulLine, const std::string &csFunc, const std::string &csComment = "");

	#define XASSERT(exp)                             if (!(exp)) {vAssertLog(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__);}
	#define XASSERT_EX(exp, comment)                 if (!(exp)) {vAssertLog(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__, comment);}
	#define XASSERT_RET(exp, return_exp)             if (!(exp)) {vAssertLog(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__); return return_exp;}
    #define XASSERT_EX_RET(exp, comment, return_exp) if (!(exp)) {vAssertLog(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__, comment); return return_exp;}
	
	//#pragma message ("*** COMPILING WITH DEBUG OFF! (NDEBUG undefined) ***")
#else /*NXDEBUG*/
    VOID vAssert(const std::string &csExp, ULONG ulLastError, const std::string &csFile, ULONG ulLine, const std::string &csFunc, const std::string &csComment = "");

	#define XASSERT(exp)                             if (!(exp)) {vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__);}
	#define XASSERT_EX(exp, comment)                 if (!(exp)) {vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__, comment);}
	#define XASSERT_RET(exp, return_exp)             if (!(exp)) {vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__); return return_exp;}
	#define XASSERT_EX_RET(exp, comment, return_exp) if (!(exp)) {vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __OUT_FUNC__, comment); return return_exp;}

	//#pragma message ("*** COMPILING WITH DEBUG ON! (NDEBUG defined) ***")										 
#endif /*NXDEBUG*/
//---------------------------------------------------------------------------
#endif /*XASSERT_H*/
