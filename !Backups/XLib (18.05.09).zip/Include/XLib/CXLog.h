/**********************************************************************
*	�����  CXLog (CXLog.hpp)
*
***********************************************************************/


#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
//---------------------------------------------------------------------------
class CXLog {
	public:
					             CXLog             ();
					             CXLog             (const std::string &csFileName, ULONG ulMaxFileSize);
						         CXLog			   (ULONG ulMaxFileSize);
					            ~CXLog             ();

		VOID                     vLog              (const std::string &csStr);
		VOID                     vLog              (const std::string &csComment, const std::string &csStr);
		VOID                     vLog              (const std::string &csComment, INT iValue);
		VOID                     vLog              (const std::string &csComment, ULONG ulLastError);
					
		VOID                     vLogUCharAsHex    (const std::string &csFileTextDescription, unsigned char *pucFileText, ULONG ulFileTextLen);
        VOID                     vLogUCharAsStr    (const std::string &csFileTextDescription, unsigned char *pucFileText, ULONG ulFileTextLen);
		VOID                     vLogLastErrorStr  (const std::string &csComment, ULONG ulLastError);	
        
		VOID                     vLogToLst         (HWND hLst, const std::string &csStr); 
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, const std::string &csStr); 
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, INT iValue);
		VOID                     vLogToLst         (HWND hLst, const std::string &csComment, ULONG ulValue);
		VOID                     vLogLastErrorToLst(HWND hLst, const std::string &csComment, ULONG ulLastError);  

		VOID                     vTrace            (const std::string &csStr); 
		VOID                     vTrace            (const std::string &csComment, const std::string &csStr); 
		VOID                     vTrace            (const std::string &csComment, INT iValue);
		VOID                     vTrace            (const std::string &csComment, ULONG ulValue);
		VOID                     vTraceLastError   (const std::string &csComment, ULONG ulLastError);

		VOID                     vOpen             ();
		VOID                     vClear            ();
		VOID                     vDelete           ();

		VOID					 vMsgBoxLastError  (const std::string &csComment);
	
	private:
		std::string              m_sLogPath;
		ULONG        m_ulMaxFileSize;
		CRITICAL_SECTION         m_csLog;
		CRITICAL_SECTION         m_csLogToLst;  //Mutex

		VOID                     vDeleteLogIfFull  ();
		////--std::string              sErrorMessageStr  (unsigned long ulLastError);
};
//---------------------------------------------------------------------------
#endif