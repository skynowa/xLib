/****************************************************************************
*    �����: CXCriticalSection (CXCriticalSection.h)
*
*****************************************************************************/


#ifndef CXCriticalSectionH
#define CXCriticalSectionH
//---------------------------------------------------------------------------
#include <iostream>
#include <windows.h>
#include <process.h>
#include <assert.h>
//---------------------------------------------------------------------------
class CXCriticalSection {
	public:
		                  CXCriticalSection();
#if (_WIN32_WINNT >= 0x0403)
		explicit          CXCriticalSection(unsigned long int ulSpinCount);
#endif
		                 ~CXCriticalSection();
		void              vEnter           ();
		void              vLeave           ();
#if (_WIN32_WINNT >= 0x0403)
		unsigned long int ulSetSpinCount   (unsigned long int ulSpinCount);
#endif
#if (_WIN32_WINNT >= 0x0400)
		BOOL              bTryEnter        ();
#endif
	private:
		CRITICAL_SECTION  m_CS;
};
//---------------------------------------------------------------------------
#endif