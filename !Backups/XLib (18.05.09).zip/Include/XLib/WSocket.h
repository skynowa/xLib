/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef WSocketH
#define WSocketH 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <windows.h>
//---------------------------------------------------------------------------
class WSocket { 
    public: 
                	WSocket      (SOCKET puiSocket = INVALID_SOCKET); 
                   ~WSocket      (); 
    	static bool bInit        (); 
    	static bool bClean       (); 
    	bool        bCreate      (INT iAf, INT iType, INT iProtocol = 0); 
    	bool        bConnect     (LPCSTR cpszIp, USHORT usPort); 
    	bool        bBind        (USHORT usPort); 
     	bool        bListen      (INT iBacklog = 5);  
    	bool        bAccept      (WSocket &s, LPSTR pszFromIp); 
    	INT         iSend        (LPCSTR cpszBuff, INT iSize, INT iFlags); 
    	INT         iRecv        (LPSTR pszBuf, INT iSize, INT iFlags); 
    	bool        bClose       (); 
    	INT         iGetLastError(); 
    	static bool bDnsParse    (LPCSTR pcszDomain, LPSTR pszIp);
		bool        bIsReadible  ();

        WSocket& operator = (SOCKET s); 
    	operator SOCKET (); 

	protected: 
    	SOCKET m_puiSocket; 
}; 
//---------------------------------------------------------------------------
#endif