/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXPop3H 
#define CXPop3H 
//---------------------------------------------------------------------------
#include "WSocket.h"
#include <windows.h>
#include <string>
#include <vector>
//---------------------------------------------------------------------------
class CPop3 { 
	public: 
                    	    CPop3      (); 
                    	   ~CPop3      (); 
		bool                bCreate    (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); /*+*/
		bool                bConnect   (); /*+*/
		bool                bLogin     (); /*+*/
		bool                bStat      (ULONG &ulSum, ULONG &ulSize); /*+*/
		bool                bList      (std::vector<ULONG> &veculList);	/*-*/
		bool                bListAt    (ULONG &ulIndex); /*-*/
		bool                bRetriveRaw(INT iNum, const std::string &csDirPath); /*+*/ 
		bool                bDisconnect(); /*+*/
		bool			    bGetSubject(LPSTR pszSubject, LPCSTR pcszBuf); /*+*/ 

	private: 
		WSocket             m_scktSocket; 
		std::string         m_sUser; 
		std::string         m_sPass; 
		std::string         m_sServer; 
		USHORT              m_usPort; 

		static const size_t ms_cuiRecvSize = 32768;
		CHAR                m_szRecv[ms_cuiRecvSize + 1];

		INT				    iPop3Recv  (LPSTR pszRecv, INT iRecvSize, INT iFlags); /*+*/
		bool                bIsError   (const std::string &sText); /*+*/  
		ULONG               ulMailsSum (const std::string &csServerAnswer); /*+*/
		ULONG               ulMailsSize(const std::string &csServerAnswer); /*+*/
}; 
//---------------------------------------------------------------------------
#endif 
