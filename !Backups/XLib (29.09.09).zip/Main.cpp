/****************************************************************************
* Lib name:    XLib
* Description: 
* File name:   XLib.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.04.2009 18:27:09
*
*****************************************************************************/


//---------------------------------------------------------------------------
#include <XLib/Common.h>

//CXDso
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXFile.h>
#include <XLib/Fso/CXIni.h>
#include <XLib/Fso/CXDir.h>
#include <XLib/Fso/CXStdioFile.h>
#include <XLib/Fso/CXDrive.h>

//CXLog
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXDbLog.h>
#include <XLib/Log/CXEventLog.h>
#include <XLib/Log/CXFileLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <XLib/Log/CXWndLog.h>

//CXSync
#include <XLib/Sync/CXCriticalSection.h>
#include <XLib/Sync/CXEvent.h>
////#include <XLib/Sync/CXLock.h>
#include <XLib/Sync/CXMutex.h>
////#include <XLib/Sync/CXScopeLocker.h>
#include <XLib/Sync/CXSemaphore.h>
#include <XLib/Sync/CXWaitableTimer.h>

//CXWinControls
#include <XLib/WinControls/CXWnd.h>
#include <XLib/WinControls/CXApp.h>
#include <XLib/WinControls/CXEdit.h>
#include <XLib/WinControls/CXStatic.h>
#include <XLib/WinControls/CXButton.h>
#include <XLib/WinControls/CXComboBox.h>
#include <XLib/WinControls/CXCheckBox.h>
#include <XLib/WinControls/CXGroupBox.h>
#include <XLib/WinControls/CXListBox.h>
#include <XLib/WinControls/CXListView.h>
#include <XLib/WinControls/CXRichEdit.h>
#include <XLib/WinControls/CXStatusBar.h>
#include <XLib/WinControls/CXProgressBar.h>
#include <XLib/WinControls/CXRadioButton.h>
#include <XLib/WinControls/CXTab.h>
#include <XLib/WinControls/CXTimer.h>
#include <XLib/WinControls/CXImageList.h>

//CXNet
////#include <XLib/CXNet/CQueryList.hpp>
////#include <XLib/CXNet/CSMTPConn.h>
#include <XLib/Net/CXMimeHeader.h>
#include <XLib/Net/CXPop3.h>
#include <XLib/Net/CXSmtp.h>
#include <XLib/Net/CXTcpClientSocket.h>
#include <XLib/Net/CXTcpServerSocket.h>

//Other
#include <XLib/xassert.h>
#include <XLib/CXString.h>
#include <XLib/CXComPort.h>
#include <XLib/CXGuid.h>
#include <XLib/CXCrc32.h>
#include <XLib/CXHandleHolder.h>
#include <XLib/CXRandom.h>
#include <XLib/CXSafeMTLong.h>
#include <XLib/CXMsgBox.h>
#include <XLib/CXMsgBoxRtf.h>
////#include <XLib/CXMsgBoxRtfEx.h>
#include <XLib/CXPerform.h>
#include <XLib/CXClipboard.h>


#include <shellapi.h>
//---------------------------------------------------------------------------
int main(int argc /*, char* argv[]*/) {




	system("pause");
 	return 0;
}
//---------------------------------------------------------------------------