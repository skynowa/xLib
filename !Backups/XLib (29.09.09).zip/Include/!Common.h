#ifndef __COMMON__H_
#define __COMMON__H_

namespace Common
{
  class NoCopyable
  {
  protected:
    NoCopyable() {}
  private:
    NoCopyable(const NoCopyable&);
    NoCopyable& operator = (const NoCopyable&);
  };

  template <typename T>
  class SyncObject
    : Common::NoCopyable
  {
  public:
    SyncObject(T& object)
      : Object(object)
    {
      Object.Enter();
    }
    ~SyncObject()
    {
      Object.Leave();
    }
  private:
    T& Object;
  };    

  template <typename T>
  class RefPtr
  {
  public:
    explicit RefPtr(T* ptr = 0)
      : Counter(0)
      , Ptr(ptr)
    {
      if (Ptr)
        *(Counter = new unsigned long) = 1;
    }
    template <typename TOther>
    explicit RefPtr(TOther* ptr)
      : Counter(0)
      , Ptr(ptr)
    {
      if (Ptr)
        *(Counter = new unsigned long) = 1;
    }
    RefPtr(const RefPtr& ptr)
      : Ptr(ptr.Ptr)
      , Counter(ptr.Counter)
    {
      if (Counter)
        (*Counter)++;
    }
    template <typename TOther>
    RefPtr(const RefPtr<TOther>& ptr)
      : Ptr(static_cast<T*>(const_cast<TOther*>(ptr.Get())))
      , Counter(ptr.Counter)
    {
      if (Counter)
        (*Counter)++;
    }
    RefPtr& operator = (const RefPtr& ptr)
    {
      if (ptr.Ptr == Ptr)
        return *this;
      Release();
      Ptr = ptr.Ptr;
      if ((Counter = ptr.Counter))
        (*Counter)++;
      return *this;
    }
    ~RefPtr()
    {
      Release();
    }
    void Release()
    {
      if (Counter && !--(*Counter))
      {
        delete Counter;
        delete Ptr;
      }
      Counter = 0;
      Ptr = 0;
    }
    T* Get()
    {
      return Ptr;
    }
    const T* Get() const
    {
      return Ptr;
    }
    T* operator -> () const
    {
      return Ptr;
    }
    operator bool () const
    {
      return !!Ptr;
    }
    bool operator ! () const
    {
      return !Ptr;
    }
    bool operator == (const T* ptr) const
    {
      return ptr == Ptr;
    }
    template <typename TOther>
    bool operator == (const TOther* ptr) const
    {
      return ptr == Ptr;
    }
    bool operator == (RefPtr<T> ptr) const
    {
      return ptr.Get() == Ptr;
    }
    template <typename TOther>
    bool operator == (RefPtr<TOther> ptr) const
    {
      return ptr.Get() == Ptr;
    }
    void Reset(RefPtr<T> ptr)
    {
      *this = ptr;
    }
    void Reset(T* ptr = 0)
    {
      Release();
      if ((Ptr = ptr))
        *(Counter = new unsigned long) = 1;
    }
    template <typename TOther>
    void Reset(TOther* ptr)
    {
      Release();
      if ((Ptr = ptr))
        *(Counter = new unsigned long) = 1;
    }
  private:
    unsigned long* Counter;
    T* Ptr;
    template <typename TOther>
    friend class RefPtr;
  };
}

#endif  // !__COMMON__H_
