/****************************************************************************
* Class name:  CXMsgBoxRtf
* Description: RTF �������������� ����� � ::MessageBox()
* File name:   CXMsgBoxRtf.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.04.2009 15:46:40
*
*****************************************************************************/


#ifndef CXMsgBoxRtfH
#define CXMsgBoxRtfH
//---------------------------------------------------------------------------
#include <windows.h>
#include <string>
#include <vector>
#include <tchar.h>
#include <richedit.h>
//---------------------------------------------------------------------------
namespace CXMsgBoxRtf {
	INT iShow(HWND hWnd, LPCSTR pcszText, LPCSTR pcszCaption, UINT uType);
}
//---------------------------------------------------------------------------
#endif
