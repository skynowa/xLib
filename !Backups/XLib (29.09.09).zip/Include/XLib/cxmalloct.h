/****************************************************************************
* Class name:  CXMallocT
* Description: ������ � ��������
* File name:   CXMallocT.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2009 17:20:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

/*
Usage:

	PSP_DEVICE_INTERFACE_DETAIL_DATA pData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(ulBytesReturned);
	...
	free(pData);

	CXMallocT<PSP_DEVICE_INTERFACE_DETAIL_DATA> diddDeviceInterfaceDetailData((size_t)ulBytesReturned);
*/

#ifndef CXMallocH
#define CXMallocH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
template<class PointerT>
class CXMallocT {
	public:
                 CXMallocT(size_t uiSize);
		        ~CXMallocT();

		PointerT pGetPtr();
            
	private:
        PointerT _m_pDataT;
};
//---------------------------------------------------------------------------
template<class PointerT>
CXMallocT<PointerT>::CXMallocT(size_t uiSize) :
	_m_pDataT(NULL)
{
	_m_pDataT = (PointerT)malloc(uiSize);
	/*DEBUG*/XASSERT(NULL != _m_pDataT);		//MessageBox(0, "Constructor", "", MB_OK);
}
//---------------------------------------------------------------------------
template<class PointerT>
PointerT CXMallocT<PointerT>::pGetPtr() {
	/*DEBUG*/XASSERT(NULL != _m_pDataT);

	return _m_pDataT; 
}
//---------------------------------------------------------------------------
template<class PointerT>
CXMallocT<PointerT>::~CXMallocT() {		
	/*DEBUG*/XASSERT(NULL != _m_pDataT);

	free(_m_pDataT);	
	_m_pDataT = NULL;							//MessageBox(0, "Destructor", "", MB_OK);
}
//---------------------------------------------------------------------------
#endif