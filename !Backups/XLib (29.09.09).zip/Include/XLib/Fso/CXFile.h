/****************************************************************************
* Class name:  CXFile
* Description: �������� � ������, �������
* File name:   CXFile.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     03.06.2009 16:30:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXFileH
#define CXFileH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXFile {
		_NO_COPY(CXFile);
	
    public:
		//�������� ������
		enum EAttributes {
			faInvalid           = INVALID_FILE_ATTRIBUTES,
			faReadOnly          = FILE_ATTRIBUTE_READONLY,  
			faHidden            = FILE_ATTRIBUTE_HIDDEN,  
			faSystem            = FILE_ATTRIBUTE_SYSTEM,  
			faDirectory         = FILE_ATTRIBUTE_DIRECTORY,  
			faArchive           = FILE_ATTRIBUTE_ARCHIVE,  
			faDevice            = FILE_ATTRIBUTE_DEVICE,  
			faNormal            = FILE_ATTRIBUTE_NORMAL,  
			faTemporary         = FILE_ATTRIBUTE_TEMPORARY,  
			faSparseFile        = FILE_ATTRIBUTE_SPARSE_FILE,  
			faReparsePoint      = FILE_ATTRIBUTE_REPARSE_POINT,  
			faCompressed        = FILE_ATTRIBUTE_COMPRESSED,  
			faOffline           = FILE_ATTRIBUTE_OFFLINE,  
			faNotContentIndexed = FILE_ATTRIBUTE_NOT_CONTENT_INDEXED,  
			faEncrypted         = FILE_ATTRIBUTE_ENCRYPTED,  
			//faVirtual           = FILE_ATTRIBUTE_VIRTUAL /*BC ++*/
		};
	
		//generic rights.
		typedef enum {
			grAll     = GENERIC_ALL,				//Read, write, and execute access
			grExecute = GENERIC_EXECUTE,			//Execute access
			grRead    = GENERIC_READ,				//Read access
			grWrite   = GENERIC_WRITE				//Write access
		} EGenericRights;

		//share modes
		typedef enum {
			smDenyAll = 0,							//Prevents other processes from opening a file or device if they request delete, read, or write access.
			smDelete  = FILE_SHARE_DELETE,			//Enables subsequent open operations on a file or device to request delete access. 
			smRead    = FILE_SHARE_READ,			//Enables subsequent open operations on a file or device to request read access. 
			smWrite   = FILE_SHARE_WRITE			//Enables subsequent open operations on a file or device to request write access. 
		} EShareMode;
	
		//Creation flags
		typedef enum {
			cfCreateAlways  = CREATE_ALWAYS,		//Creates a new file, always.
			cfCreateNew     = CREATE_NEW,			//Creates a new file, only if it does not already exist.
			cfOpenAlways    = OPEN_ALWAYS,			//Opens a file, always.
			cfOpenExisting  = OPEN_EXISTING,		//Opens a file or device, only if it exists.
			cfTruncExisting = TRUNCATE_EXISTING,	//Opens a file and truncates it so that its size is zero bytes, only if it exists.
		} ECreationFlags;

		//file position data for the given stream
		typedef enum {
			ppBegin = FILE_BEGIN,	
			ppCurr  = FILE_CURRENT,	
			ppEnd   = FILE_END,
		} EPointerPosition;

		//file types
		typedef enum {
			ftChar    = FILE_TYPE_CHAR,				//character file, typically an LPT device or a console.
			ftDisk    = FILE_TYPE_DISK,    		 	//disk file.
			ftPipe    = FILE_TYPE_PIPE,     		//socket, a named pipe, or an anonymous pipe.
			ftRemote  = FILE_TYPE_REMOTE,   		//Unused.
			ftUnknown = FILE_TYPE_UNKNOWN			//unknown, or the function failed.
		} EType;

					       CXFile              ();
				          ~CXFile              ();
		BOOL               bOpen               (const std::string &csFilePath, ULONG ulAccess = grRead,  ULONG ulShareMode = smRead,    ULONG ulFlags = cfOpenExisting, ULONG ulAttributes = faNormal);
		BOOL               bCreate             (const std::string &csFilePath, ULONG ulAccess = grWrite, ULONG ulShareMode = smDenyAll, ULONG ulFlags = cfCreateAlways, ULONG ulAttributes = faNormal);
		BOOL               bClose              ();
		BOOL               bIsOpen             ();
		BOOL               bAttach             (HANDLE hHandle);
		HANDLE             bDetach             ();
		BOOL               bRead               (LPVOID pvBuf, ULONG ulCount);
		BOOL               bRead               (LPVOID pvBuf, ULONG ulCount, LPDWORD pulRead);
		BOOL               bWrite              (LPCVOID pcvBuf, ULONG ulCount);
		BOOL               bWrite              (LPCVOID pcvBuf, ULONG ulCount, LPDWORD pulWritten);
		ULONG              ulSetPosition       (LONG liOff, EPointerPosition fpPos);
		ULONG              ulGetPosition       ();
		BOOL               bLock               (ULONG ulOffset, ULONG ulSize);
		BOOL               bUnlock             (ULONG ulOffset, ULONG ulSize);
		BOOL               bSetEOF             ();
		BOOL               bFlush              ();
		ULONG              ulGetSize           ();
		ULONG              ulGetType           ();
		BOOL               bGetTime            (FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified);
		BOOL               bSetTime            (FILETIME *pftCreate, FILETIME *pftAccess, FILETIME *pftModified);
		BOOL               bDuplicateHandle    (HANDLE hOther);
		
		static BOOL        bIsExists           (const std::string &csFilePath);  /*+*/
		static BOOL        bDelete             (const std::string &csFilePath);  /*+*/
		static BOOL        bMove               (const std::string &csFilePathIn, const std::string &csFilePathOut); //����, ������� /*+*/
		static std::string sCreateTempName     (const std::string &csPrefix); /*+*/
		static BOOL        bCopy               (const std::string &csFilePathFrom, const std::string &csFilePathTo); /*+*/
		static BOOL        bCopy               (const std::string &csFilePathFrom, const std::string &csFilePathTo, BOOL bFailIfExists); /*+*/
		static BOOL        bReplace            (const std::string &csOldFileName, const std::string &csNewFilePath, const std::string &csBackupFilePath);
		static BOOL        bSecureDelete       (const std::string &csFilePath, UINT uiPasses); /*-*/
		static BOOL        bCutFromEnd         (const std::string &csFilePath, LONG lDistanceToCut);	/*+*/
		static BOOL        bCutFromEnd         (FILE *pFile, ULONG ulDistanceToCut);	/*+*/
		static BOOL        bCheckSignature     (LPCSTR pcszBuff, LPCSTR pcszSignature, INT iSignatureSize);	/*-*/
		static BOOL        bSetRandomDate      (const std::string &csFilePath);
		static ULONGLONG   ullGetCompressedSize(const std::string &csFilePath);


		/****************************************************************************
		* ��������
		*
		*****************************************************************************/
		static ULONG       ulGetAttr           (const std::string &csFilePath);
		static BOOL        bSetAttr            (const std::string &csFilePath, ULONG ulFileAttr); /*+*/
		static BOOL	       bSetUncompressedAttr(const std::string &csFilePath); /*-*/
		static BOOL	       bSetCompressedAttr  (const std::string &csFilePath, BOOL bCompress); /*-*/


		static std::string				 sReadText   		      (const std::string &csFilePath); /*+*/
		static bool					 bWriteText  		      (const std::string &csFilePath, const std::string &csText); /*+*/








	private:
		HANDLE             _m_hFile;
};
//---------------------------------------------------------------------------
#endif



/*
BOOL CXLog::bOpen() {
STARTUPINFO         si = {0};
PROCESS_INFORMATION pi = {0};
//��������� �������� ��������� STARTUPINFO �� ���������
si.cb = sizeof(STARTUPINFO);

std::string sCmd = "D:\\My\\Soft (for using)\\Text\\Notepad++ 5.0.2\\notepad++.exe " + m_sLogPath; 
if (!::CreateProcess(NULL, (LPSTR)sCmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
return FALSE;
}	

::Sleep(500);  //������� �������� � �������� ���� ������

//������� ����������� ����������� �������� � ������� ��������
::CloseHandle(pi.hThread);
::CloseHandle(pi.hProcess);

return TRUE;
}

*/
