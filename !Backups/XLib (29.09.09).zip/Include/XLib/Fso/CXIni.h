/****************************************************************************
* Class name:  CXIni
* Description: ������ � ini-�������
* File name:   CXIni.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.04.2009 12:10:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXIniH
#define CXIniH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXIni {
		_NO_COPY(CXIni);
		
	public:
						 CXIni                     (const std::string &csFileName, const std::string &csDefaultContent);
						~CXIni                     ();

		BOOL             bCreateDefaultIni         (const std::string &csFilePath, const std::string &csContent);

		std::string      sReadString               (const std::string &csSection, const std::string &csKey, const std::string &csDefaultValue);
		BOOL             bWriteString              (const std::string &csSection, const std::string &csKey, const std::string &csValue);

		INT              iReadInteger              (const std::string &csSection, const std::string &csKey, INT    iDefaultValue);
		BOOL             bWriteInteger             (const std::string &csSection, const std::string &csKey, INT    iValue);

		DOUBLE           dReadFloat                (const std::string &csSection, const std::string &csKey, DOUBLE dDefaultValue);
		BOOL             bWriteFloat               (const std::string &csSection, const std::string &csKey, FLOAT  fValue);

		BOOL             bReadBoolean              (const std::string &csSection, const std::string &csKey, BOOL   bDefaultValue);
		BOOL             bWriteBoolean             (const std::string &csSection, const std::string &csKey, BOOL   bValue);

	

		//	DAte
		//	Float
		//	Time

		BOOL             bClearSection             (const std::string &csSection);
		BOOL             bReadSectionsNames        ();
		BOOL             bReadSectionKeysAndValues (const std::string &csSection);
		ULONG            ulSectionSize             (const std::string &csSection);
		

	private:
		static const INT _ms_ciLineSize        = 512;
		static const INT _ms_ciLinesPerSection = 50;	//����������� �������� � ������
		std::string      _m_sFilePath;
};
//---------------------------------------------------------------------------
#endif