/****************************************************************************
* Class name:  CXService
* Description: ������ � ��������
* File name:   CXService.h
* Compilers:   Visual C++ 2008
* std::string type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     20.07.2009 16:23:36
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXServiceH
#define CXServiceH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <Winsvc.h>
//---------------------------------------------------------------------------
class CXService {
		_NO_COPY(CXService);

	public:
		     CXService();
		    ~CXService();

		BOOL bRegisterService            (const std::string &csServiceName, const std::string &csServiceCaption);
		BOOL bUnregisterService          (const std::string &csServiceName);
		VOID vMakeDependentOn            (const std::string &csServiceName);

		BOOL bStartServiceOnLocalComputer(const std::string &csServiceName);
		BOOL bStopServiceOnLocalComputer (const std::string &csServiceName);

		SERVICE_STATUS stGetServiceStatus(const std::string &csServiceName);

		BOOL bUserControlService         (const std::string &csServiceName, ULONG OpCode);
		BOOL bDoesServiceExist           (const std::string &csServiceName);

	private:
		VOID _vSetDependency             (SC_HANDLE hHandle, LPSTR pszDependency);
		BOOL _bIsServiceDependentOnRPCSS (SC_HANDLE hService);
		int  _bGetDependencyStringLength (LPSTR pszString);
		BOOL _bReconfigureService        (SC_HANDLE hSCMManager, const std::string &csServiceName);


		/*
		ChangeServiceConfig
		ChangeServiceConfig2
		CloseServiceHandle
		ControlService
		ControlServiceEx
		CreateService
		DeleteService
		EnumDependentServices
		EnumServicesStatus
		EnumServicesStatusEx
		GetServiceDisplayName
		GetServiceKeyName
		Handler
		HandlerEx
		LockServiceDatabase
		NotifyBootConfigStatus
		NotifyServiceStatusChange
		OpenSCManager
		OpenService
		QueryServiceConfig
		QueryServiceConfig2
		QueryServiceLockStatus
		QueryServiceStatus
		QueryServiceStatusEx
		RegisterServiceCtrlHandler
		RegisterServiceCtrlHandlerEx
		ServiceMain
		SetServiceBits
		SetServiceStatus
		StartService
		StartServiceCtrlDispatcher
		UnlockServiceDatabase
		*/
};
//---------------------------------------------------------------------------
#endif