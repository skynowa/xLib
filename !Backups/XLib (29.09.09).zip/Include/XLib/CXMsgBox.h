/****************************************************************************
* Class name:  CXMsgBox
* Description: ����� ���������, ������ ���� ������
* File name:   CXMsgBox.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.04.2009 10:24:49
* Version:     1.0
*
*****************************************************************************/
 

#ifndef CXMsgBoxH	
#define CXMsgBoxH   
//---------------------------------------------------------------------------
#include <windows.h>
#include <sstream>
//---------------------------------------------------------------------------
template <typename T_1, typename T_2> 
void MsgBox(T_1 tmplText, T_2 tmplTitle, UINT uiType = MB_OK) {			
	std::ostringstream ossText;
	ossText << tmplText;

	std::ostringstream ossTitle;
	ossTitle << tmplTitle;

	::MessageBox(0, ossText.str().c_str(), ossTitle.str().c_str(), uiType);
}
//---------------------------------------------------------------------------
#endif