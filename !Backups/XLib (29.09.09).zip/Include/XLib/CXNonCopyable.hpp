/****************************************************************************
* Class name:  CXNonCopyable
* Description: ����� ��� ������� ��������� ������������ � ������������ �����������
* File name:   CXNonCopyable.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     02.09.2009 9:07:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXNonCopyableH
#define CXNonCopyableH
//---------------------------------------------------------------------------
class CXNonCopyable {
   protected:
       CXNonCopyable() {}
      ~CXNonCopyable() {}
      
   private:  
      CXNonCopyable (const CXNonCopyable& );
      const CXNonCopyable& operator = (const CXNonCopyable& );
};
//---------------------------------------------------------------------------
#endif


/*
//Disable copy construction, Disable assignment operator
//////////#define _NO_COPY(ClassName)		  private: ClassName(const ClassName &cSrc);  ClassName& operator = (const ClassName &cSrc)
//////////#define DECLARE_NO_COPY_CLASS(classname)        \
//////////    private:                                    \
//////////        classname(const classname&);            \
//////////        classname& operator=(const classname&);
//////////
//////////#define DECLARE_NO_ASSIGN_CLASS(classname)      \
//////////    private:                                    \
//////////        classname& operator=(const classname&);
*/