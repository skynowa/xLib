/****************************************************************************
* Class name:  CXGroupBox
* Description: 
* File name:   CXGroupBox.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:10:19
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXGroupBox_H
#define CXGroupBox_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXGroupBox: public CXWindow {
	public:
		 CXGroupBox();
		~CXGroupBox();
};
//---------------------------------------------------------------------------
#endif