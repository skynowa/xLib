/****************************************************************************
* Class name:  CXProgressBar
* Description: ��������� ����������
* File name:   CXProgressBar.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.07.2009 11:05:22
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXProgressBar_H
#define CXProgressBar_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXProgressBar: public CXWindow {
	public:
				 CXProgressBar();
				~CXProgressBar();
				
		INT      SetRange     (INT nMin, INT nMax);
		INT      SetRange32   (INT nMin, INT nMax);
		BOOL     bGetRange    (PPBRANGE pPBRange);
		INT      GetRangeLimit(BOOL bLimit);
		INT      GetMaxValue  ();
		INT      GetMinValue  ();
		INT      SetPos       (INT nPos);
		INT      GetPos       ();
		INT      DeltaPos	  (INT nDelta);
		INT      SetStep      (INT nStep);		
		INT      StepIt       ();
		COLORREF SetBarColour (COLORREF clrBar);
		COLORREF SetBkColour  (COLORREF clrBk);

/*
		BOOL SetText(LPCTSTR strMessage);
		BOOL SetSize(INT nSize);

*/
};
//---------------------------------------------------------------------------
#endif