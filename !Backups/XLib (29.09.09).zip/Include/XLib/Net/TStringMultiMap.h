#ifndef TStringMultiMapH 
#define TStringMultiMapH 
//---------------------------------------------------------------------------
struct CompareNoCase
{
	bool operator () (std::string const &csStr1, std::string const &csStr2) const 
	{
		bool bRes = ::lstrcmpi(csStr1.c_str(), csStr2.c_str()) < 0;

		return bRes;
	}
};

typedef std::multimap<std::string, std::string, CompareNoCase> TStringMultiMap;
//---------------------------------------------------------------------------
#endif