/****************************************************************************
* Class name:  CXTcpClientSocket
* Description: 
* File name:   CXTcpClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef CXClientSocketH
#define CXClientSocketH 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXTcpClientSocket { 
		_NO_COPY(CXTcpClientSocket);
		
    public: 
    	//������ ������
		typedef enum {
			etInvalid = INVALID_SOCKET,          
			etError   = SOCKET_ERROR        
		} EErrorType;	

		enum {
			SOCKET_TIMEOUT   = 0,		 //(1000000 / 10)  		//�������� �������� � �������������          
			SOCKET_BUFF_SIZE = 32768    // 32 KB      /*8192*//*1024*/    
		};	
        
					CXTcpClientSocket  (); 
					CXTcpClientSocket  (SOCKET puiSocket); 
                   ~CXTcpClientSocket  (); 

    	BOOL        bCreate            (INT iAf, INT iType, INT iProtocol = 0); 
		BOOL        bIsReadable        ();
    	BOOL        bConnect           (const std::string &csIp, USHORT usPort); 
		BOOL        bIoctl             (LONG liCmd, ULONG *pulArgp);
		BOOL        bSetNonBlockingMode(const BOOL cbFlag);
    	
		INT         iSend              (LPCSTR pcszBuff, INT iBuffSize, INT iFlags); 
		BOOL        bSendAll           (const std::string &csBuff, INT iFlags); 
		INT         iSend_DEPR         (LPCSTR cpszBuff, INT iSize, INT iFlags); 
    	
		INT         iRecv              (LPSTR  pszBuff,  INT iSize, INT iFlags); 
		std::string sRecvAll           (INT iFlags);   
		std::string sRecvAll           (INT iFlags, const std::string &csDelimiter);   

		INT         iSendBytes         (LPSTR pszBuff, INT iMessageLength);
		INT         iReceiveBytes      (LPSTR pszBuff, INT iStillToReceive);

		BOOL        bClose             (); 
		
		BOOL        bSetTimeout        (LONG liSec,   LONG liMicroSec);
		BOOL        bGetTimeout        (LONG *pliSec, LONG *pliMicroSec);
		

		
		/****************************************************************************
		* static 
		*
		*****************************************************************************/
		
		static BOOL bInit              (); 
		static BOOL bClean             (); 
    	static INT  iGetLastError      (); 
		static BOOL bDnsParse          (const std::string &csDomain, std::string &sIp);
		/*static*/ INT  iSelect            (INT nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds);
    	

		/****************************************************************************
		* operators
		*
		*****************************************************************************/

        CXTcpClientSocket& operator =  (SOCKET s); 
    	operator SOCKET                (); 

	protected: 
    	SOCKET      _m_puiSocket; 
    	timeval     _m_tvTimeout;
}; 
//---------------------------------------------------------------------------
#endif


/*
---Server-----

Initialize Winsock.
Create a socket.
Bind the socket.
Listen on the socket for a client.
Accept a connection from a client.
Receive and send data.
Disconnect.
---Client----

Initialize Winsock.
Create a socket.
Connect to the server.
Send and receive data.
Disconnect.
*/