/****************************************************************************
* Class name:  CXPop3
* Description: Pop3 ������
* File name:   CXPop3.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2009 16:44:49
*
*****************************************************************************/


#ifndef CXPop3H 
#define CXPop3H 
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Net/CXTcpClientSocket.h> 
#include <XLib/Net/CXMimeMessage.h> 
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <vector>
#include <map>
//---------------------------------------------------------------------------
class CXPop3 { 
		_NO_COPY(CXPop3);
		
	public: 
                    	  CXPop3              (); 
                    	 ~CXPop3              (); 

		BOOL              bCreate             (const std::string &csUser, const std::string &csPass, const std::string &csServer, USHORT usPort); 
		BOOL              bConnect            (); 
 		BOOL              bLogin              (); 
 		
		BOOL              bStat               (ULONG &ulSum, ULONG &ulSize); 
		BOOL              bList               (std::vector<ULONG> &veculList);	
		BOOL              bListAt             (ULONG &ulIndex); 
		BOOL              bNoop               ();
		BOOL              bRset               ();
		BOOL              bTop                (INT iNum, INT iLines, std::string &sBuff); 
		
		BOOL      /*RETR*/bRetrive            (INT iNum, const std::string &csRawMimeMessage); 
		BOOL      /*RETR*/bRetriveRaw         (INT iNum, const std::string &csDirPath, const std::string &csFileName);  
		BOOL      /*RETR*/bRetriveRawAndBackup(INT iNum, const std::string &csDirPath, const std::string &csBackupDirPath, const std::string &csFileName);  
		BOOL      /*TOP*/ bRetrieveHeader     (INT iNum, CXMimeHeader &mhMimeHeader); 
		
		BOOL              bDelete             (INT iNum); 
		BOOL              bDisconnect         (); 
		
	private: 
		CXTcpClientSocket _m_scktSocket; 
		CXConsoleLog      _m_ConsoleLog;
		std::string       _m_sUser; 
		std::string       _m_sPass; 
		std::string       _m_sServer; 
		USHORT            _m_usPort; 
	    BOOL              _m_bConnected;

		BOOL              _bCommand           (const std::string &csCmd, const std::string &csReplyDelimiter, std::string &sReply);   
		BOOL              _bIsError           (const std::string &csText);   
		ULONG             _ulMailsSum         (const std::string &csServerAnswer); 
		ULONG             _ulMailsSize        (const std::string &csServerAnswer); 
}; 
//---------------------------------------------------------------------------
#endif 

/*
RFC 1225

USER <SP> name <CRLF>
PASS <SP> secret <CRLF>
STAT <CRLF>
LIST <SP> [msg] <CRLF>
LIST <CRLF>
RETR <SP> msg <CRLF>
DELE <SP> msg <CRLF>
NOOP <CRLF>
LAST <CRLF>
RSET <CRLF>
QUIT <CRLF>
*/