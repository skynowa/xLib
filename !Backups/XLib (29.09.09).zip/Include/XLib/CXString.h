/****************************************************************************
* Class name:  CXString
* Description: ��������� ������
* File name:   CXString.h
* String type: Ansi (std::string, wstring)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 17:01:15
*
*****************************************************************************/


#ifndef CXStringH
#define CXStringH  
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator> 
//---------------------------------------------------------------------------

/****************************************************************************
*    ������ <--> �����
*
*****************************************************************************/

//std_string_cast
template <typename T> std::string /*lexical_cast*/lexical_cast       (T const &cValueT) {		
													    std::ostringstream oss;	
													    oss << cValueT;
													    oss.flush();

													    return oss.str();
												   };		
template<typename T> T            /*lexical_cast*/lexical_cast       (const std::string &csStr) {
														std::istringstream iss(csStr);
														T ValueT;	
														iss >> ValueT;

														return ValueT;
												   };	
BOOL                              bStrToUCHAR      (const std::string &csStr, UCHAR *pucBuff, UINT uiBuffLen);	
std::string                       sUCHARToStr      (UCHAR *pucBuff, UINT uiBuffLen);	



std::string                       sTrimChar        (const std::string &csStr, CHAR chChar); 
std::string                       sTrimSpace       (const std::string &csStr);	
std::string                       sTrimLeftChar    (const std::string &csStr, CHAR chChar); 
std::string                       sTrimRightChar   (const std::string &csStr, CHAR chChar); 
std::string                       sRemoveEOL       (const std::string &csStr);	

//////--------------------------------------------------------------------------
//////TODO: + ssTrimStr
/////*static*/std::string CXPath::ssTrimStr(const std::string &csFilePath) {
////	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 
////
////	size_t uiDotPos = csFilePath.rfind(ms_csDot, csFilePath.size());
////
////	return csFilePath.substr(0, uiDotPos);
////}

std::string                       sReplaceAll      (const std::string &csStr, const std::string &csOldStr, const std::string &csNewStr); 
std::string                       sReplaceAll      (const std::string &csStr, CHAR cOldStr, CHAR cNewStr); 
std::string                       sRemoveAll       (const std::string &csStr, const std::string &csRemoveStr); 

std::vector<std::string>          vecsSplit        (const std::string &csStr, const std::string &csDelimiter); 
BOOL                              bSplit           (const std::string &csStr, const std::string &csDelimiter, std::vector<std::string> *vecsOut); 

std::vector<std::string>          vecsSplitKeyValue(const std::string &csStr, const std::string &csDelimiter); 
std::string                       sJoin            (const std::vector<std::string> &cvecsVec, const std::string &csDelimiter); 
std::string                       sCut             (const std::string &csStr, const std::string &csFirstLeftDelimiter, const std::string &csFirstRightDelimiter); /*-*/

BOOL                              bStrToFile       (const std::string &csStr, const std::string &csFilePath);	/*-*/
std::string                       bStrFromFile     (const std::string &csStr, const std::string &csFilePath);	/*-*/

std::string						  sToLowerCase     (const std::string &csSrc);	
std::string                       sToUpperCase     (const std::string &csSrc);	
std::string						  sToLowerCase     (const std::string &csSrc, UINT uiPos);	/*-*/
std::string                       sToUpperCase     (const std::string &csSrc, UINT uiPos);	/*-*/

std::string                       sFormatStr       (LPCSTR pcszFormat, ...); 
std::string                       sFormatStr2      (LPCSTR pcszFormat, ...); 
std::string                       sFormatStrV      (LPCSTR pcszFormat, va_list palArgs);
std::string                       sMinimizeStr     (const std::string &csStr, const UINT cuiMaxLen); 

/****************************************************************************
*    CHAR
*
*****************************************************************************/

//This is ASCII specific but is safe with chars >= 0x80
BOOL                              bIsPunctuation   (CHAR ch); 
BOOL                              bIsADigit        (CHAR ch); 
BOOL                              bIsLowerCase     (CHAR ch); 
BOOL                              bIsUpperCase     (CHAR ch); 
BOOL                              bIsSpaceOrTab    (UINT ch); 
BOOL                              bIsDigit         (UINT ch); 
BOOL                              bIsDigit         (UINT ch, UINT base); 
BOOL                              bIsLetter        (CHAR ch); 
BOOL                              bIsSpace         (UINT ch); 
BOOL                              IsEOLChar        (CHAR ch); 
BOOL							  bIsSlash         (CHAR ch);  

CHAR                              cMakeUpperCase   (CHAR ch);  //non-Unicode characters only
CHAR                              cMakeLowerCase   (CHAR ch);  //non-Unicode characters only

INT                               iGetHexChar      (UCHAR hd1, UCHAR hd2);
CHAR                              cHexToChar       (CHAR *pszStr);
INT								  iCharCodeAt      (const std::string &csStr, INT nIndex);	
BOOL                              bCompareNoCase   (const std::string &csStr1, const std::string &csStr2); 
BOOL                              bCompareNoCase2  (const std::string &csStr1, const std::string &csStr2); 


/****************************************************************************
* ����������
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: + vRandomShuffleT (������������ ������)
template<class T> 
VOID vRandomShuffleT(std::vector<T> &v) {
	std::random_shuffle(v.begin(), v.end());
}
//--------------------------------------------------------------------------
//TODO: + vSortVectorT (��������� ������)
template<class T> 
VOID vSortVectorT(std::vector<T> &v) {
	std::sort(v.begin(), v.end());
}
//--------------------------------------------------------------------------


/****************************************************************************
*	�������������
*
*****************************************************************************/

std::string                       sDecodeWinKoi    (const std::string &csStr, UINT uiFrom, UINT uiTo);
std::string						  sTranslitLatToRus(const std::string &csStr);	
BOOL                              bCharToWide      (const CHAR *pszSrc, WCHAR *pwszDest, INT iDestSize);	/*-*/
std::string						  sStrToRtf        (std::string sStr);
std::string						  sRtfToStr        (std::string sStr);




/****************************************************************************
*    ������
*
*****************************************************************************/

std::string                       sCreatePlainGUID ();  
BOOL                              bIsRepeatedStr   (const std::string &csStr); 
std::string                       sLastErrorStr    (ULONG ulLastError);	
ULONG                             ulCountDigits    (ULONG ulDigit);	
std::string                       sSizeToStr       (ULONG dwSize);  /*-*/
/*FLOAT                             fGeneratRandomNumber between


Public Function GenRndNumber(Lower%, Upper%)
Randomize
GenRndNumber = Int((Upper% - Lower% + 1) * Rnd + Lower%)
End Function      */

//---------------------------------------------------------------------------
//TODO: + vPrintStdVectorT (������ � ������� std::vector) 
template<class T>
VOID vPrintStdVectorT(const std::vector<T> &t) {
	std::cout << std::endl << "Printing std::vector contents..." << std::endl << std::endl;

	std::vector<T>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it){
		std::cout << "Value: [" << (*it) << "]" << std::endl;
	}
	
	std::cout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
//TODO: + vPrintStdMultiMapT (������ � ������� std::multimap) 
template<class T1, class T2>
VOID vPrintStdMultiMapT(const std::multimap<T1, T2> &t) { 
	std::cout << std::endl << "Printing std::multimap contents..." << std::endl << std::endl;
	
	std::multimap<T1, T2>::const_iterator it;
	
	for (it = t.begin(); it != t.end(); ++ it) {
		std::cout << "Key: [" << (*it).first << "]" << "\t\t" 
			      << "Value: [" << (*it).second << "]" << std::endl;
	}

	std::cout << std::endl << std::endl;
}
//---------------------------------------------------------------------------
#endif