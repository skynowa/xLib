/****************************************************************************
* Class name:  CXHandle
* Description: ������ � ��������
* File name:   CXHandle.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.05.2009 19:48:48
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/CXHandle.h>
#include <XLib/xassert.h>
//---------------------------------------------------------------------------
CXHandle::CXHandle() throw() :
	m_hHandle(NULL)
{
}
//---------------------------------------------------------------------------
CXHandle::CXHandle(CXHandle& h) throw() :
	m_hHandle(NULL)
{
	vAttach(h.hDetach());
}
//---------------------------------------------------------------------------
CXHandle::CXHandle(HANDLE h) throw() :
	m_hHandle(h)
{
}
//---------------------------------------------------------------------------
CXHandle::~CXHandle() throw() {
	if (NULL != m_hHandle) {
		vClose();
	}
}
//---------------------------------------------------------------------------
CXHandle& CXHandle::operator=(CXHandle& h) throw() {
	if (this != &h)	{
		if (NULL != m_hHandle) {
			vClose();
		}
		vAttach(h.hDetach());
	}

	return *this;
}
//---------------------------------------------------------------------------
CXHandle::operator HANDLE() const throw() {
	return m_hHandle;
}
//---------------------------------------------------------------------------
void CXHandle::vAttach(HANDLE h) throw() {
	/*DEBUG*/XASSERT_RET(m_hHandle == NULL, (VOID)NULL);
	
	m_hHandle = h;  // Take ownership
}
//---------------------------------------------------------------------------
HANDLE CXHandle::hDetach() throw() {
	HANDLE h;

	h = m_hHandle;  // Release ownership
	m_hHandle = NULL;

	return h;
}
//---------------------------------------------------------------------------
void CXHandle::vClose() throw() {
	if (NULL != m_hHandle) {
		::CloseHandle(m_hHandle);
		m_hHandle = NULL;
	}
}
//---------------------------------------------------------------------------