/**********************************************************************
 *	����� CXUrlCoder (CXUrlCoder.cpp)
 *
 ***********************************************************************/


#include <string>
#include <vector>
#include <windows.h>
#include <wininet.h>
#include <tchar.h>

#include <XLib/Net/CXUrlCoder.h>
//---------------------------------------------------------------------------
CXUrlCoder::CXUrlCoder(){

}
//---------------------------------------------------------------------------
CXUrlCoder::~CXUrlCoder(){

}
//--------------------------------------------------------------------------
std::string CXUrlCoder::sEncode(const std::string &csStr) {
	std::string sRes("");
	int iLen = csStr.length();
	char *pszBuff = new char[iLen + 1];
	strcpy(pszBuff, csStr.c_str());
	
	
	for (int i = 0; i < iLen; i ++) {
		if (bIsOrdinaryChar(pszBuff[i])) {
			sRes = sRes + pszBuff[i];
		} else if (pszBuff[i] == ' ') {
			sRes = sRes + "+";
		} else {
			char tmp[6];
			sprintf(tmp, "%%%x", pszBuff[i]);
			sRes = sRes + tmp;
		}
	}

	delete [] pszBuff;
	return sRes;
}
//--------------------------------------------------------------------------
bool CXUrlCoder::bIsOrdinaryChar(char chChar) {
	char ch = tolower(chChar);
	if (ch == 'a' || ch == 'b' || ch == 'c' || ch == 'd' || ch == 'e' || ch == 'f'
		|| ch == 'g' || ch == 'h' || ch == 'i' || ch == 'j' || ch == 'k' || ch ==
		'l' || ch == 'm' || ch == 'n' || ch == 'o' || ch == 'p' || ch == 'q' || ch 
		== 'r' || ch == 's' || ch == 't' || ch == 'u' || ch == 'v' || ch == 'w' ||
		ch == 'x' || ch == 'y' || ch == 'z' || ch == '0' || ch == '1' || ch == '2' 
		|| ch == '3' || ch == '4' || ch == '5' || ch == '6' || ch == '7' || ch ==
		'8' || ch == '9') 
	{
		return true;
	} else {
		return false;
	}
}
//--------------------------------------------------------------------------
std::string CXUrlCoder::sDecode(const std::string &csStr) {
	std::string  Res("");
	int          iLen    = csStr.length();
	char        *pszBuff = new char[iLen + 1];
	strcpy(pszBuff, csStr.c_str());

	for (int i = 0; i < iLen; i ++) {
		if (pszBuff[i] == '+') {
			Res = Res + " ";
		} else if (pszBuff[i] == '%') {
			char tmp[4];
			char hex[4];
			hex[0] = pszBuff[ ++i];
			hex[1] = pszBuff[ ++i];
			hex[2] = '\0';
			//int hex_i = atoi(hex);
			sprintf(tmp, "%c", iConvertToDec(hex));
			Res = Res + tmp;
		} else {
			Res = Res + pszBuff[i];
		}
	}

	delete [] pszBuff;
	return Res;
}
//--------------------------------------------------------------------------
int CXUrlCoder::iConvertToDec(const char *hex) {
	int  iRes = 0;
	char szBuff[12];
	sprintf(szBuff, "%s", hex);
	int iLen = strlen(szBuff);

	for (int i = 0; i < iLen; i ++) {
		char tmp[4];
		tmp[0] = szBuff[i];
		tmp[1] = '\0';
		vGetAsDec(tmp);
		int tmp_i = atoi(tmp);
		int rs = 1;
		for (int j = i; j < (iLen - 1); j ++) {
			rs *= 16;
		}
		iRes += (rs *tmp_i);
	}

	return iRes;
}
//--------------------------------------------------------------------------
void CXUrlCoder::vGetAsDec(char *pchHex) {
	char chTmp = tolower(pchHex[0]);
	if (chTmp == 'a') {
		strcpy(pchHex, "10");
	} else if (chTmp == 'b') {
		strcpy(pchHex, "11");
	} else if (chTmp == 'c') {
		strcpy(pchHex, "12");
	} else if (chTmp == 'd') {
		strcpy(pchHex, "13");
	} else if (chTmp == 'e') {
		strcpy(pchHex, "14");
	} else if (chTmp == 'f') {
		strcpy(pchHex, "15");
	} else if (chTmp == 'g') {
		strcpy(pchHex, "16");
	}
}
//--------------------------------------------------------------------------