/****************************************************************************
* Class name:  CXWindowImpl
* Description: ������ � ������
* File name:   CXWindowImpl.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXWindowImpl.h>

#include <XLib/GUI/Common.h>
#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXWindowImpl::CXWindowImpl() :
	CXWindow     (),
    _m_bDestroyed(FALSE)
{
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName = CXWINDOW_CONTROL_CLASS + std::string("_") + sCreatePlainGUID();
	_m_ulStyle    = CXFRAME_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle  = CXFRAME_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft      = CW_USEDEFAULT;
	_m_iTop       = CW_USEDEFAULT;
	_m_iWidth     = CXFRAME_DEFAULT_WIDTH;
	_m_iHeight    = CXFRAME_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXWindowImpl::~CXWindowImpl() {
	BOOL bRes = FALSE;	

	bRes = _bUnregisterClass(_m_sClassName);
	CHECK_DO(FALSE == bRes, return);
}
//---------------------------------------------------------------------------
//����� ���������
X_BEGIN_MSG_MAP(CXWindowImpl)
	X_MSG(WM_CREATE,  OnCreate)	
	X_MSG(WM_PAINT,   OnPaint);
	X_MSG(WM_COMMAND, OnCommand);
	X_MSG(WM_NOTIFY,  OnNotify);
	X_MSG(WM_SIZE,    OnSize);
	X_MSG(WM_CLOSE,   OnClose); 
	X_MSG(WM_DESTROY, OnDestroy)
X_END_MSG_MAP(CXWindow)
//X_END_MSG_MAP_NOPARENT
//---------------------------------------------------------------------------
BOOL CXWindowImpl::bCreate(INT iID, HWND hParent, const std::string &csText, 
							INT iLeft, INT iTop, INT iWidth, INT iHeight, 
							ULONG ulStyle, ULONG ulExStyle,
							SHORT siIconID, SHORT siIconSmID, SHORT siBGColor)
{
	BOOL bRes = FALSE;	

	//-------------------------------------
	//������������ ����� ����
	WNDCLASSEX wcex = {0};

	wcex.cbSize         = sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)_s_pWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= CXApplication::hGetInstance();
	wcex.hIcon			= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconID);
	wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW + (HBRUSH)siBGColor);
	wcex.lpszMenuName	= (LPCTSTR)iID;
	wcex.lpszClassName	= _m_sClassName.c_str();
	wcex.hIconSm		= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconSmID);

	bRes = _bRegisterClass(&wcex);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//������� ����
	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, csText, 
							 iLeft, iTop, iWidth, iHeight,
							 _m_ulStyle | ulStyle, 
							 /*WS_EX_CLIENTEDGE | WS_EX_APPWINDOW*/ _m_ulExStyle | ulExStyle, 
							 (LPVOID)this);
	CHECK_RET(FALSE == bRes, FALSE);

    //-------------------------------------
	//���� ��� �������� ����, �� ��������� ������������
    if (NULL != hParent) {
		bRes = ::EnableWindow(hParent, FALSE);
		/*DEBUG*/XASSERT_RET(0 == bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXWindowImpl::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*////XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindowImpl::bCreate(iID, hParent, 
								CXResources::sGetText(iID), 
								CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
								CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
								CXResources::ulGetStyle(iID), 
								CXResources::ulGetStyleEx(iID),
								/*SHORT siIconID*/0, /*SHORT siIconSmID*/0, /*SHORT siBGColor*/1);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iShowModal
INT CXWindowImpl::iShowModal() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes   = FALSE;
	MSG  msgMsg = {0};   

	bRes = bShow(SW_SHOW);
	CHECK_RET(FALSE == bRes, FALSE);

	for (_m_bDestroyed = FALSE; !_m_bDestroyed && ::GetMessage(&msgMsg, NULL, 0, 0); ) {
		::TranslateMessage(&msgMsg);
		::DispatchMessage (&msgMsg);
	}

	return (INT)_m_bDestroyed;
}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnCreate(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnPaint(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	PAINTSTRUCT ps  = {0};
	HDC         hdc = NULL;

	hdc = ::BeginPaint(_m_hWnd, &ps);
	//TODO: Add any drawing code here...
	::EndPaint(_m_hWnd, &ps);
}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnCommand(WPARAM wParam, LPARAM lParam) {	/*virtual*/ 
	
}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnNotify(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	
}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnSize(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnClose(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	bDestroy();
}
//---------------------------------------------------------------------------
VOID CXWindowImpl::OnDestroy(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	_m_bDestroyed = TRUE;

	if (NULL != _m_hParentWnd) {
		BOOL bRes = FALSE;
		HWND hRes = NULL;

		bRes = bClose();
		/*DEBUG*/XASSERT(FALSE != bRes);

		bRes = ::EnableWindow(_m_hParentWnd, TRUE);
		/*DEBUG*/XASSERT(FALSE != bRes);

		////hRes = ::SetActiveWindow(_m_hParentWnd); 
		/////*DEBUG*/XASSERT(NULL != hRes);

		bRes = ::UpdateWindow(_m_hParentWnd);
		/*DEBUG*/XASSERT(FALSE != bRes);
		
		return;
	}

	CXApplication::vTerminate();
}
//---------------------------------------------------------------------------