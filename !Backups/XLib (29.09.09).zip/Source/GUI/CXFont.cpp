/****************************************************************************
* Class name:  CXFont
* Description: 
* File name:   CXFont.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.09.2009 13:45:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXFont.h>
//---------------------------------------------------------------------------

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
CXFont::CXFont() :
    _m_hFont(NULL)
{
	//code
}
//---------------------------------------------------------------------------
CXFont::~CXFont() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + hGet
HFONT CXFont::hGet() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	HFONT hFont = NULL;

	hFont = (HFONT)::SendMessage(WM_GETFONT, 0, 0);
	/*DEBUG*/XASSERT_RET(NULL != hFont, NULL);

	return hFont;
}
//---------------------------------------------------------------------------
//TODO: + bSet
BOOL CXFont::bSet(HFONT hFont) {
	/*DEBUG*/XASSERT_RET(NULL != hFont, NULL);

	BOOL bRes = FALSE;

	bRes = (BOOL)lSendMessage(WM_SETFONT, (WPARAM)hFont, /*MAKELPARAM(TRUE, 0)*/TRUE);
	//bRes = (BOOL)::SendMessage(this->_m_hWnd, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
	/*DEBUG*///XASSERT_RET(FALSE != bRes, FALSE);

	_m_hFont = hFont;

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetDefaultFont
BOOL CXFont::bSetDefaultFont() {
	/*DEBUG*///not need

	//_m_hFont = ::CreateFont(- 11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
	//					   OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	_m_hFont = ::CreateFont(- 11, 0, 0, 0, 400, 0, 0, 0, 0xCC, 0, 0, 0, DEFAULT_PITCH, "Arial Black"/*"Tahoma"*/);
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	return bSet(_m_hFont);
}
//---------------------------------------------------------------------------
//TODO: + bDelete
BOOL CXFont::bDelete() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	BOOL bRes = FALSE;

	bRes = ::DeleteObject(_m_hFont);
	/*DEBUG*/XASSERT_RET(FALSE != _m_hFont, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------




/****************************************************************************
*    Protected methods                                                       
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------




/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
