/****************************************************************************
* Class name:  CXWindow
* Description: ����� root ��� ���� �������� ���� 
* File name:   CXWindow.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     31.08.2009 16:44:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXWindow.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXTraceLog CXWindow::_m_tlLog;           
//---------------------------------------------------------------------------

/****************************************************************************
*	public
*
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + CXWindow
CXWindow::CXWindow() :
	_m_hWnd      (NULL),
	_m_iID       (0),
	_m_sClassName(""),
	_m_hParentWnd(NULL),		
	_m_sText     (""),
	_m_iLeft     (CW_USEDEFAULT),
	_m_iTop      (CW_USEDEFAULT),
	_m_iWidth    (0),
	_m_iHeight   (0),
	_m_ulExStyle (0),
	_m_ulStyle   (0),
	////_m_iMenu     (0),
	_m_hFont     (NULL)
{
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + ~CXWindow
CXWindow::~CXWindow() {
	LOG();
	
	////bDeleteFont();
}
//---------------------------------------------------------------------------
//TODO: + lpProcessMessage
LRESULT CXWindow::lpProcessMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	/*virtual*/
	return ::DefWindowProc(_m_hWnd, uiMsg, wParam, lParam);
}
//---------------------------------------------------------------------------
//TODO: + bIsWindow
BOOL CXWindow::bIsWindow() const {
	/*DEBUG*///not need

	return (NULL != _m_hWnd) && (INVALID_HANDLE_VALUE != _m_hWnd) && (FALSE != ::IsWindow(_m_hWnd));
}
//---------------------------------------------------------------------------
//TODO: + hGetHandle
HWND CXWindow::hGetHandle() const { 
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return _m_hWnd; 
}
//---------------------------------------------------------------------------
//TODO: + iGetID
INT CXWindow::iGetID() const {
	/*DEBUG*/XASSERT_RET(0 < _m_iID, 0);   

	return _m_iID;
}
//---------------------------------------------------------------------------
//TODO: + bSetID
BOOL CXWindow::bSetID(INT iID) {
	/*DEBUG*/XASSERT_RET(0 < iID, FALSE);   

	_m_iID = iID;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCreate
BOOL CXWindow::bCreate(INT iID, HWND hParent, const std::string &csClassName, const std::string &csText, 
					   INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulExStyle, LPVOID lpParam)
{
	/*DEBUG*/XASSERT_RET(NULL  == _m_hWnd,             FALSE);

	/*DEBUG*/XASSERT_RET(0     <  iID,                 FALSE);
	/*DEBUG*/XASSERT_RET(false == csClassName.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iLeft,               FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iTop,                FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iWidth,              FALSE);
	/*DEBUG*/XASSERT_RET(0     <= iHeight,             FALSE);

	BOOL bRes = FALSE;
	HWND hWnd = NULL;

	INT _iID = 0;
	size_t uiPos = csClassName.find(CXWINDOW_CONTROL_CLASS); 
	if (std::string::npos != csClassName.find(CXWINDOW_CONTROL_CLASS)) {
		_iID = NULL; 
	} else {
		_iID = iID; 
	}

	hWnd = ::CreateWindowEx(_m_ulExStyle | ulExStyle, 
							csClassName.c_str(), 
							csText.c_str(), 
							_m_ulStyle | ulStyle, 
							iLeft, iTop, iWidth, iHeight, 
							hParent, 
							(HMENU)_iID,
							///(std::string::npos != csClassName.find(CXFRAME_CONTROL_CLASS)) ? (HMENU)NULL : (HMENU)iID,	/*���� - NULL, ������� - iID*/ 
							CXApplication::hGetInstance(), 
							lpParam);
	/*DEBUG*/XASSERT_RET(NULL != hWnd, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_hWnd       = hWnd;
	_m_iID        = iID;
	_m_sClassName = _m_sClassName;
	_m_hParentWnd =	hParent;	
	_m_sText      = csText;
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;
	_m_ulExStyle  = _m_ulExStyle | ulExStyle;    
	_m_ulStyle    = _m_ulStyle   | ulStyle;
	////_m_iMenu  = iMenu;

	//-------------------------------------
	//��������� �����
    bRes = bSetDefaultFont();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bShow
BOOL CXWindow::bShow(INT iCmdShow) const {
	/*DEBUG*/////XASSERT_RET(bIsWindow(), FALSE);
	/*DEBUG*///not need

	INT  iRes = - 1;
	BOOL bRes = FALSE;

	iRes = ::ShowWindow(_m_hWnd, iCmdShow);
	/*DEBUG*/XASSERT_RET(0 == iRes, FALSE);

	bRes = bUpdate();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUpdate
BOOL CXWindow::bUpdate()const  {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::UpdateWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO + bMove
BOOL CXWindow::bMove(INT iLeft, INT iTop, INT iWidth, INT iHeight) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::MoveWindow(_m_hWnd, iLeft , iTop , iWidth , iHeight, TRUE);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�������������� ���� ������
	_m_iLeft      = iLeft;
	_m_iTop       = iTop;
	_m_iWidth     = iWidth; 
	_m_iHeight    = iHeight;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO + bMoveCenter
BOOL CXWindow::bMoveCenter() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes           = FALSE;

	RECT rcRect         = {0};
	INT  iHorScreenSize = 0;
	INT  iVerScreenSize = 0;
	INT  iLeft          = 0;
	INT  iTop           = 0;
	INT  iWidth         = 0;
	INT  iHeight        = 0;

	::GetWindowRect(_m_hWnd, &rcRect);
	iHorScreenSize = ::GetDeviceCaps(::GetDC(NULL), HORZRES);
	iVerScreenSize = ::GetDeviceCaps(::GetDC(NULL), VERTRES);
	
	iWidth  = rcRect.right  - rcRect.left;
	iHeight = rcRect.bottom - rcRect.top;
	iLeft   = (iHorScreenSize - iWidth ) / 2;
	iTop    = (iVerScreenSize - iHeight) / 2;
	
	bRes = bMove(iLeft, iTop, iWidth, iHeight);
	/*DEBUG*/CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bEnable
BOOL CXWindow::bEnable(BOOL bFlag) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::EnableWindow(_m_hWnd, bFlag);
	/*DEBUG*/XASSERT_RET(0 == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - SendMessage
LRESULT CXWindow::lSendMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LRESULT lpRes = FALSE;

	lpRes = ::SendMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*///--XASSERT_RET(FALSE == (BOOL)lpRes, FALSE);     //not need

	return lpRes;
}
//---------------------------------------------------------------------------
//TODO: + PostMessage
BOOL CXWindow::bPostMessage(UINT uiMsg, WPARAM wParam, LPARAM lParam) const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::PostMessage(_m_hWnd, uiMsg, wParam, lParam);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDestroy
BOOL CXWindow::bDestroy() const {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	BOOL bRes = FALSE;

	bRes = ::DestroyWindow(_m_hWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bClose
BOOL CXWindow::bClose() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return bPostMessage(WM_CLOSE, NULL, NULL);
}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _s_pWndProc
LRESULT CXWindow::_s_pWndProc(HWND hWnd, UINT uiMsg, WPARAM wParam, LPARAM lParam) {
	CXWindow *pWnd = NULL;

	switch (uiMsg) {
		////case WM_INITDIALOG:
		////	{
		////		::SetWindowLong(hWnd, GWL_USERDATA, (LONG)lParam);
		////		pWnd = (CXWindow *)lParam;										//������� ��������� �� �����
		////		/*DEBUG*/XASSERT(NULL != pWnd);
		////		pWnd->_m_hWnd = hWnd;
		////	}
		////	break;

		case WM_NCCREATE:
			{
				LONG ulNewLong = 0;

				ulNewLong = (INT)((LPCREATESTRUCT)lParam)->lpCreateParams;
				::SetWindowLong(hWnd, GWL_USERDATA, ulNewLong);
				pWnd = (CXWindow *)(((LPCREATESTRUCT)lParam)->lpCreateParams);	//������� ��������� �� �����
				/*DEBUG*/XASSERT(NULL != pWnd);
				pWnd->_m_hWnd = hWnd;
			}
			break;

		default:
			{
				//������� ��������� �� �����
				pWnd = (CXWindow *)::GetWindowLong(hWnd, GWL_USERDATA); 
				/*DEBUG*///not need
			}
			break;
	}

	if (NULL != pWnd) {
		return pWnd->lpProcessMessage(uiMsg, wParam, lParam);
	}

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + _bInitCommonControls
BOOL CXWindow::_bInitCommonControls(ULONG ulFlags) {		/*static*/
	BOOL bRes = FALSE;

	INITCOMMONCONTROLSEX iccx = {0};
	iccx.dwSize = sizeof(INITCOMMONCONTROLSEX);
	iccx.dwICC  = ulFlags;

	bRes = ::InitCommonControlsEx(&iccx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bRegisterClass(const WNDCLASSEX *cpwcWndClassEx) {		/*static*/
	/*DEBUG*/XASSERT_RET(NULL != cpwcWndClassEx, FALSE);

	BOOL bRes = FALSE;

	bRes = ::RegisterClassEx(cpwcWndClassEx);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + _bRegisterClassEx
BOOL CXWindow::_bUnregisterClass(const std::string &csClassName) {		/*static*/
	/*DEBUG*///XASSERT_RET(false != csClassName.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::UnregisterClass(csClassName.c_str(), CXApplication::hGetInstance());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	�����
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + hGetFont
HFONT CXWindow::hGetFont() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	HFONT hFont = NULL;

	hFont = (HFONT)lSendMessage(WM_GETFONT, 0, 0);
	/*DEBUG*/XASSERT_RET(NULL != hFont, NULL);	//NULL if the control is using the system font.

	return hFont;
}
//---------------------------------------------------------------------------
//TODO: + bSetFont
BOOL CXWindow::bSetFont(HFONT hFont) {
	/*DEBUG*/XASSERT_RET(NULL != hFont, FALSE);

	BOOL bRes = FALSE;

	bRes = (BOOL)lSendMessage(WM_SETFONT, (WPARAM)hFont, /*MAKELPARAM(TRUE, 0)*/TRUE);
	/*DEBUG*///not return a value

	_m_hFont = hFont;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetDefaultFont
BOOL CXWindow::bSetDefaultFont() {
	/*DEBUG*///not need

	//_m_hFont = ::CreateFont(- 11, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, 
	//					      OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	_m_hFont = ::CreateFont(- 11, 0, 0, 0, 400, 0, 0, 0, 0xCC, 0, 0, 0, DEFAULT_PITCH, /*"Arial Black"*/"Tahoma");
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, NULL);

	return bSetFont(_m_hFont);
}
//---------------------------------------------------------------------------
//TODO: + bDeleteFont
BOOL CXWindow::bDeleteFont() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hFont, FALSE);

	BOOL bRes = FALSE;

	bRes = ::DeleteObject(_m_hFont);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
