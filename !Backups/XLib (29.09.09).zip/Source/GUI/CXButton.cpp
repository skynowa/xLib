/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXButton.h>

#include <XLib/GUI/CXApplication.h>
#include <XLib/Gui/CXResources.h>
//---------------------------------------------------------------------------
//TODO: + CXButton
CXButton::CXButton() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXBUTTON_CONTROL_CLASS;
	_m_ulStyle        = CXBUTTON_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXBUTTON_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXBUTTON_DEFAULT_WIDTH;
	_m_iHeight        = CXBUTTON_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
//TODO: + ~CXButton
CXButton::~CXButton() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreate
BOOL CXButton::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
							 CXResources::sGetText(iID), 
							 CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
							 CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
							 CXResources::ulGetStyle(iID), 
							 CXResources::ulGetStyleEx(iID),
							 this);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------