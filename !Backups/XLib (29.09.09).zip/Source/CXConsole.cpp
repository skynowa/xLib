/**********************************************************************
*	�����  CXConsole (CXConsole.cpp)  
*	
***********************************************************************/


#include <XLib/CXConsole.h>

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <XLib/xassert.h>
#include <XLib/CXString.h>
//---------------------------------------------------------------------------
CXConsole::CXConsole() 
	: m_hWnd   (NULL),
	  m_hMenu  (NULL),
	  m_hStdIn (INVALID_HANDLE_VALUE),
	  m_hStdOut(INVALID_HANDLE_VALUE)
{
	/*DEBUG*/XASSERT(NULL                 == m_hWnd);
	/*DEBUG*/XASSERT(NULL                 == m_hMenu);	
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE == m_hStdIn);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE == m_hStdIn);

	m_hStdIn  = ::GetStdHandle(STD_INPUT_HANDLE);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hStdIn);
	/*DEBUG*/////XASSERT(NULL != m_hStdIn);

	m_hStdOut = ::GetStdHandle(STD_OUTPUT_HANDLE);
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hStdOut);

	bSetTitle(APP_NAME);
}
//---------------------------------------------------------------------------
CXConsole::~CXConsole() {
	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hStdIn);
	::CloseHandle(m_hStdIn);	m_hStdIn  = INVALID_HANDLE_VALUE;

	/*DEBUG*/XASSERT(INVALID_HANDLE_VALUE != m_hStdOut);
	::CloseHandle(m_hStdOut);	m_hStdOut = INVALID_HANDLE_VALUE;

	m_hMenu = NULL; 
	m_hWnd  = NULL; 
}
//---------------------------------------------------------------------------
void CXConsole::vSetLocale(const std::string &csLocale) {
	setlocale(LC_ALL, csLocale.c_str());
}
//---------------------------------------------------------------------------
BOOL CXConsole::bSetTextColor(UINT uiColor) {
	BOOL bRes = FALSE;

	bRes = ::SetConsoleTextAttribute(m_hStdOut, uiColor);	//�����
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bEnableClose(BOOL bFlag) {
	m_hWnd = hGetHandle();
	/*DEBUG*/XASSERT_RET(NULL != m_hWnd, FALSE);

	if (FALSE == bFlag) {
		m_hMenu = ::GetSystemMenu(m_hWnd, FALSE);
		if (FALSE == ::DeleteMenu(m_hMenu, SC_CLOSE, MF_BYCOMMAND)) {
			return FALSE;
		}
	} else {
		m_hMenu = ::GetSystemMenu(m_hWnd, TRUE);
		if (FALSE == ::AppendMenu(m_hMenu, SC_CLOSE, MF_BYCOMMAND, "")) {
			return FALSE;
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXConsole::sGetTitle() {
	const ULONG culBuffSize             = 1024; 
	CHAR        szBuff[culBuffSize + 1] = {0};
	ULONG       ulTitleSize             = 0;              

	ulTitleSize = ::GetConsoleTitle(szBuff, culBuffSize);
	/*DEBUG*/XASSERT_RET(0 < ulTitleSize, "");

	return std::string(culBuffSize, ulTitleSize);
}
//---------------------------------------------------------------------------
BOOL CXConsole::bSetTitle(const std::string &csTitle) {
	BOOL bRes = FALSE; 
	
	bRes = ::SetConsoleTitle(csTitle.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bSetFullScreen() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != m_hStdOut, FALSE);

	BOOL bRes = FALSE;
	
	COORD crdCoord = ::GetLargestConsoleWindowSize(m_hStdOut);
	if (crdCoord.X == 0 && crdCoord.Y == 0) {
		return FALSE;
	}
	
	crdCoord.X -= 2;
	crdCoord.Y -= 2;

	SMALL_RECT recSmallRec = {
		0,					//Left
		0,					//Top
		crdCoord.X - 2,		//Right
		crdCoord.Y - 2		//Bottom
	};
	
	bRes = ::SetConsoleScreenBufferSize(m_hStdOut, crdCoord);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);
	
	bRes = ::SetConsoleWindowInfo(m_hStdOut, TRUE, &recSmallRec);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	bRes = bCenterWindow();
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bCenterWindow() {
	BOOL bRes = FALSE;
	
	m_hWnd = hGetHandle() /*GetConsoleWindow()*/;
	/*DEBUG*/XASSERT_RET(NULL != m_hWnd,  FALSE);

	RECT recOriginWnd = {0};
	bRes = ::GetWindowRect(m_hWnd, &recOriginWnd);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	RECT recDesktopWnd = {0};
	bRes = ::SystemParametersInfo(SPI_GETWORKAREA, 0, &recDesktopWnd, 0);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);
	
	INT iDesktopX  = (recDesktopWnd.right  - recDesktopWnd.left) / 2;
	INT iDesktopY  = (recDesktopWnd.bottom - recDesktopWnd.top)  / 2;
	INT iWndWidth  = (recOriginWnd.right   - recOriginWnd.left);
	INT iWndHeight = (recOriginWnd.bottom  - recOriginWnd.top);
	INT X          = iDesktopX - iWndWidth / 2;		if (X < 0) {X = 0;}
	
	bRes = ::MoveWindow(m_hWnd, X, iDesktopY - iWndHeight / 2, iWndWidth, iWndHeight, TRUE);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	return TRUE;

	
	//-------------------------------------
	//������� �2
	////POINT   Point;
	////RECT    DialogRect;
	////RECT    ParentRect;
	////int     nWidth;
	////int     nHeight;
	////HWND    hDesktop = NULL;

	////HWND hWnd = NULL;
	////while (NULL == hWnd) {
	////	hWnd = ::FindWindowEx(NULL, NULL, NULL, APP_NAME);
	////}

	//////�������� ������ ����������� ����.
	////GetWindowRect(hWnd, &DialogRect);

	//////�������� ������ �������� �����
	////hDesktop = GetDesktopWindow();
	////GetWindowRect(hDesktop, &ParentRect);

	//////��������� ������ � ������ ��� MoveWindow().
	////nWidth = DialogRect.right;   // .Width();
	////nHeight = DialogRect.bottom; //.Height();

	//////������� ����� ������ � ����������� � ���������� ������.
	////Point.x = ParentRect.right / 2;
	////Point.y = ParentRect.bottom / 2;

	////ClientToScreen(hDesktop, &Point);

	//////��������� ����� X, Y ��������� �����.
	////Point.x -= nWidth  / 2;
	////Point.y -= nHeight / 2;

	//////���������� ����.
	////MoveWindow(hWnd, Point.x, Point.y, nWidth, nHeight, TRUE);
}
//---------------------------------------------------------------------------
HWND CXConsole::hGetHandle() {
	HWND        hRes         = NULL; 
	BOOL        bRes         = FALSE; 
	std::string sNewWndTitle = "";
	std::string sOldWndTitle = "";

	//Fetch current window title.
	sOldWndTitle = sGetTitle();
	/*DEBUG*/XASSERT_RET(false == sOldWndTitle.empty(), NULL);

	//Format a "unique" szNewWndTitle.
	sNewWndTitle = sFormatStr("%d/%d", ::GetTickCount(), ::GetCurrentProcessId());

	//Change current window title.
	bRes = bSetTitle(sNewWndTitle.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, NULL);

	//Ensure window title has been updated.
	::Sleep(50);

	//Look for NewWindowTitle.
	hRes = ::FindWindow(NULL, sNewWndTitle.c_str());
	/*DEBUG*/XASSERT_RET(NULL != hRes, NULL);

	//Restore original window title.
	bRes = bSetTitle(sOldWndTitle.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, NULL);

	//::CloseHandle(hRes);	hRes = NULL;

	return hRes;


	//-------------------------------------
	//������� �2
	//////std::string sTilte("some crazy but unique string that will ID our window - maybe a GUID and process ID");

	//////if (FALSE == SetConsoleTitle(sTilte.c_str())) {
	//////	return NULL;
	//////}

	////////Give this a chance - it may fail the first time through
	//////HWND hRes = NULL;
	//////while (NULL == hRes) {
	//////	hRes = ::FindWindowEx(NULL, NULL, NULL, sTilte.c_str());
	//////}

	////////Reset old title - we'd normally save it with GetConsoleTitle
	//////if (FALSE == SetConsoleTitle(APP_NAME)) {
	//////	CloseHandle(hRes);	hRes = NULL;
	//////	return NULL;
	//////}

	//////return hRes;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bClear() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != m_hStdOut, FALSE);

	COORD                      coordScreen   = {0};		/*here's where we'll home the cursor*/ 
	BOOL                       bRes          = FALSE;
	ULONG                      cCharsWritten = 0;
	CONSOLE_SCREEN_BUFFER_INFO csbi 		 = {0};		/*to get buffer info*/ 
	ULONG                      ulConSize     = 0;		/*number of character cells in the current buffer*/ 

	//get the number of character cells in the current buffer
	bRes = ::GetConsoleScreenBufferInfo(m_hStdOut, &csbi);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	ulConSize = csbi.dwSize.X * csbi.dwSize.Y;

	//fill the entire screen with blanks
	bRes = ::FillConsoleOutputCharacter(m_hStdOut, (CHAR)' ', ulConSize, coordScreen, &cCharsWritten);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	//get the current text attribute
	bRes = ::GetConsoleScreenBufferInfo(m_hStdOut, &csbi);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	//now set the buffer's attributes accordingly
	bRes = ::FillConsoleOutputAttribute(m_hStdOut, csbi.wAttributes, ulConSize, coordScreen, &cCharsWritten);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	//put the cursor at (0, 0) 
	bRes = ::SetConsoleCursorPosition(m_hStdOut, coordScreen );
	/*DEBUG*/XASSERT_RET(FALSE != bRes,  FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bWriteLine(const std::string &csStr) {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != m_hStdOut, FALSE);
	/*DEBUG*/XASSERT_RET(NULL != m_hStdOut, FALSE);

	BOOL        bRes                    = FALSE;
	ULONG       ulWritten               = 0;    
	std::string sStr                    = "";
	const ULONG culBuffSize             = 1024;
	CHAR        szBuff[culBuffSize + 1] = {0};
	/*DEBUG*/XASSERT_RET(csStr.size() <= culBuffSize, FALSE);

	//��������������� � ���������� ���������
	::CharToOem(csStr.c_str(), szBuff);
	sStr = std::string(szBuff) + "\r\n";

	bRes = ::WriteConsole(m_hStdOut, sStr.c_str(), sStr.size(), &ulWritten, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,            FALSE);
	/*DEBUG*/XASSERT_RET(ulWritten == sStr.size(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXConsole::bWriteErrLine(const std::string &csStr) {
	if (FALSE == bWriteLine("������: " + csStr)) {
		return FALSE;
	}

	////::Beep(40, 40);
	std::cin.get();

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXConsole::sReadLine() {
	/*DEBUG*/XASSERT_RET(INVALID_HANDLE_VALUE != m_hStdIn, "");

	BOOL        bRes                    = FALSE;
	ULONG       ulRead                  = 0;
	const ULONG culBuffSize             = 1024;
	CHAR        szBuff[culBuffSize + 1] = {0};

	bRes = ::ReadConsole(m_hStdIn, &szBuff, culBuffSize, &ulRead, NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes,   "");
	/*DEBUG*/XASSERT_RET(NULL  != szBuff, "");

	return std::string(szBuff, ulRead - 2);	//������ "\r\n"
}
//---------------------------------------------------------------------------