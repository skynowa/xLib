/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.cpp
* String type: Ansi (std::string)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#include <XLib/Debug/CXPerform.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Fso/CXStdioFile.h>
//---------------------------------------------------------------------------
CXPerform::CXPerform(const std::string &csFileName, EPerfomMode pmPerformMode) {
	/*DEBUG*/XASSERT(false == csFileName.empty());
	/*DEBUG*/XASSERT(pmPerformMode < 2 || pmPerformMode > 0);
	
	_bResetData(); 

	_m_pmPerfomModeNow = pmPerformMode;
	_m_sLogPath        = CXPath::sExtractFileDir(CXPath::sExePath()) + "\\" + csFileName;
	
	_bLog("------------------------------");
}
//---------------------------------------------------------------------------
CXPerform::~CXPerform() {	
	_bLog("------------------------------");
}
//--------------------------------------------------------------------------
BOOL CXPerform::bStart() {
	/*DEBUG*/(FALSE == _m_bWasStarted, FALSE);

    switch (_m_pmPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				////////dtBeginTime = Time();
				////SYSTEMTIME stST = {0};
				////::GetLocalTime(&stST);

				////fprintf(pFile, "[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	
			}
			break;

        //pmGetTickCount
		case pmGetTickCount:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				_m_ulBeginTime = ::GetTickCount();
			}
            break;
		
		//QueryPerformanceCounter
        case pmQueryPerformanceCounter:
			{
				if (!::QueryPerformanceFrequency(&_m_liStart)) {
					::MessageBox(0, "��������� ����������", "Log", MB_OK);
					return FALSE;
				}
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::QueryPerformanceFrequency(&_m_liBeginCount);
			}
            break;

		//pmGetThreadTimes
		case pmGetThreadTimes:
			{
				::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
				::GetThreadTimes(::GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTime0, &_m_lpUserTime0);
			}
			break;
		
		//pmUknown
		case pmUknown:
			{
				/*DEBUG*/XASSERT(FALSE);
			}
			break; 

        default:	
			{
				/*DEBUG*/XASSERT_EX(FALSE, "���������� �����");
				::MessageBox(0, "���������� �����", "Log", MB_OK);
			}
            break;
    }

    _m_bWasStarted = TRUE;

	return TRUE;
}
//--------------------------------------------------------------------------
BOOL CXPerform::bStop(const std::string &csComment) {
	/*DEBUG*/(FALSE != _m_bWasStarted, FALSE);

	switch (_m_pmPerfomModeNow) {
		//pmTime
		case pmTime:
			{
				////dtEndTime = Time();
				////bLog(casComment, (dtEndTime - dtBeginTime).FormatString("hh:nn:ss:zz"));
			}
			break;

        //pmGetTickCount (��������)
        case pmGetTickCount:
            {
				_m_ulEndTime = ::GetTickCount();
                _bLog(csComment, _sMilliSecToTimeString(_m_ulEndTime - _m_ulBeginTime));
            }
            break;

	    //QueryPerformanceCounter (�����)
	    case pmQueryPerformanceCounter:
            {
                ::QueryPerformanceCounter(&_m_liEndCount);
                _m_liCount.QuadPart = _m_liEndCount.QuadPart - _m_liBeginCount.QuadPart;
                _bLog(csComment, sAnyToStrT(_m_liCount.QuadPart * 1000 / _m_liStart.QuadPart));
            }
            break;

        //pmGetThreadTimes (��������)
        case pmGetThreadTimes:
            {
                ::GetThreadTimes(GetCurrentThread(), &_m_lpCreationTime, &_m_lpExitTime, &_m_lpKernelTime1, &_m_lpUserTime1);
                /*???? float*/_bLog(csComment, _sMilliSecToTimeString((_iFiletimeToint64(_m_lpUserTime1) - _iFiletimeToint64(_m_lpUserTime0)) / 10000));	//10000 - ������������; 10 - ������������
            }
            break;  
		
		//pmUknown
		case pmUknown:
			{
				/*DEBUG*/XASSERT(false);
			}
			break; 

		default:	
			{
				/*DEBUG*/XASSERT(false);
			}
			break;

	}

	_bResetData();

	_m_bWasStarted = FALSE;

	return TRUE;
}
//--------------------------------------------------------------------------
BOOL CXPerform::bPulse(const std::string &csComment) {
	BOOL bRes = FALSE;

	bRes = bStop(csComment);
    CHECK_RET(FALSE == bRes, FALSE);

	bRes = bStart();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bPulse(ULONG ulComment) {
	BOOL bRes = FALSE;

    bRes = bStop(sAnyToStrT(ulComment));
	CHECK_RET(FALSE == bRes, FALSE);
    
	bRes = bStart();
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bDeleteLog() {
    BOOL bRes = FALSE;

	bRes = CXStdioFile::bIsExists(_m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	bRes = CXStdioFile::bRemove(_m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::bOpenLog() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec(_m_sLogPath);
	CHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------







/****************************************************************************
*	Private methods	
*
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXPerform::_bResetData() {
    _m_bWasStarted                   = FALSE;

	//pmGetTickCount
	_m_ulBeginTime                   = 0;
	_m_ulEndTime                     = 0;

    //QueryPerformanceCounter
    _m_liStart.QuadPart              = 0;
	_m_liBeginCount.QuadPart         = 0;
	_m_liEndCount.QuadPart           = 0;
	_m_liCount.QuadPart              = 0;

	//GetThreadTimes
	_m_lpCreationTime.dwLowDateTime  = 0;
    _m_lpCreationTime.dwHighDateTime = 0;
	_m_lpExitTime.dwLowDateTime      = 0;
    _m_lpExitTime.dwHighDateTime     = 0;
	_m_lpKernelTime0.dwLowDateTime   = 0;
    _m_lpKernelTime0.dwHighDateTime  = 0;
	_m_lpUserTime0.dwLowDateTime     = 0;
    _m_lpUserTime0.dwHighDateTime    = 0;
	_m_lpKernelTime1.dwLowDateTime   = 0;
    _m_lpKernelTime1.dwHighDateTime  = 0;
	_m_lpUserTime1.dwLowDateTime     = 0;
    _m_lpUserTime1.dwHighDateTime    = 0;
    
    ::SetThreadPriority(::GetCurrentThread(), THREAD_PRIORITY_NORMAL);

	return TRUE;
}
//--------------------------------------------------------------------------
__int64 CXPerform::_iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//--------------------------------------------------------------------------
BOOL CXPerform::_bLog(const std::string &csText) {
	BOOL bRes = FALSE;

	CXStdioFile sfLog;

	bRes = sfLog.bOpen(_m_sLogPath, "a");
	CHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
    ::GetLocalTime(&stST);
	
	sfLog.iFprintf("[%d:%d:%d]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csText.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXPerform::_bLog(const std::string &csComment, const std::string &csText) {
	BOOL bRes = FALSE;

	CXStdioFile sfLog;

	bRes = sfLog.bOpen(_m_sLogPath, "a");
	CHECK_RET(FALSE == bRes, FALSE);

	SYSTEMTIME stST = {0};
	::GetLocalTime(&stST);
	
	sfLog.iFprintf("[%d:%d:%d]  %s: %s\n", stST.wHour, stST.wMinute, stST.wSecond, csComment.c_str(), csText.c_str());	

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXPerform::_sMilliSecToTimeString(LONGLONG i64MilliSec) {
	std::string sRes;
    LONGLONG	i64H  = 0;
    LONGLONG	i64M  = 0;
    LONGLONG	i64S  = 0;
    LONGLONG	i64Ms = 0;

    i64H  = i64MilliSec / 3600000;
    i64M  = i64MilliSec % 3600000 / 60000;
    i64S  = i64MilliSec % 60000   / 1000;
    i64Ms = i64MilliSec % 1000;
	
	sRes = sFormatStr("%I64d:%.2I64d:%.2I64d:%.3I64d", i64H, i64M, i64S, i64Ms);
	
	return sRes;
}
//---------------------------------------------------------------------------







/*
__int64 GetCPUClock()
{
    __int64 res;
    __asm
    {
        rdtsc
        mov dword ptr res, eax
        mov dword ptr res+4, edx
    }
    return res;
}

__int64 g_FuncTime = 0; //���� ����� �������� ��������� ����� ���������� F.

BOOL F()
{
    __int64 Time = GetCPUClock();
    ///...
    __int64 Difference = GetCPUClock() - Time;
    g_FuncTime += Difference;
}


#include <stdio.h>
INT main()
{

    __int64 Time = GetCPUClock();
    //����� ����
    __int64 Difference = GetCPUClock() - Time;

    printf("%f\n", (double)Difference);
}
*/