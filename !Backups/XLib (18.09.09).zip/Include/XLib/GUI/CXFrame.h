/****************************************************************************
* Class name:  CXFrame
* Description: ������ � ������
* File name:   CXFrame.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXFrameH
#define CXFrameH
//---------------------------------------------------------------------------
#include <XLib/Gui/CXWindow.h>
//---------------------------------------------------------------------------
class CXFrame :	public CXWindow {
	public:
				     CXFrame  ();
				    ~CXFrame  (); /*virtual*/

		X_DECLARE_MSG_MAP     ()

		BOOL         bCreate  (INT iID, HWND hParent, const std::string &csWndName, 
							   INT iLeft, INT iTop, INT iWidth, INT iHeight, 
							   ULONG ulStyle, ULONG ulExStyle,
							   SHORT siIconID, SHORT siIconSmID, SHORT siBGColor);
		BOOL         bCreateRes(INT iID, HWND hParent);
		
		virtual VOID OnCreate (WPARAM wParam, LPARAM lParam);
		virtual VOID OnPaint  (WPARAM wParam, LPARAM lParam);
		virtual VOID OnCommand(WPARAM wParam, LPARAM lParam);
		virtual VOID OnNotify (WPARAM wParam, LPARAM lParam);
		virtual VOID OnSize   (WPARAM wParam, LPARAM lParam);
		virtual VOID OnClose  (WPARAM wParam, LPARAM lParam);  
		virtual VOID OnDestroy(WPARAM wParam, LPARAM lParam);

	protected:
		////--SHORT        _m_siMenuID; //ID ����
};
//---------------------------------------------------------------------------
#endif