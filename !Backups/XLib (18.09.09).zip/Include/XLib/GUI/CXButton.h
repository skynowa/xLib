/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXButton_H
#define CXButton_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXButton: public CXWindow {
	public:
		     CXButton  ();
		    ~CXButton  ();

		BOOL bCreate   (INT iID, HWND hParent, const std::string &csText, 
						INT iLeft, INT iTop, INT iWidth, INT iHeight,
						ULONG ulStyles, ULONG ulExStyles); 
		BOOL bCreateRes(INT iID, HWND hParent);
};
//---------------------------------------------------------------------------
#endif