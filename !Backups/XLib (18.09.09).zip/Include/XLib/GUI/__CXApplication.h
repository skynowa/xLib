#ifndef __ULAPP__H_
#define __ULAPP__H_
//---------------------------------------------------------------------------
#include "windows.h"
//---------------------------------------------------------------------------
class CXApplication {
		static CXApplication *m_App;

	public:
				      CXApplication       ();
				     ~CXApplication       ();

		HINSTANCE     m_hInstance;
		LPTSTR        m_lpCmdLine;
		INT           m_nCmdShow;

		virtual INT   InitInstance() = 0;
		virtual INT   Run         () = 0;
		static CXApplication* GetApp      ();
};
//---------------------------------------------------------------------------
#endif//__ULAPP__H_