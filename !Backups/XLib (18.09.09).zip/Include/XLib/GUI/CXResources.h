/****************************************************************************
* Class name:  CXResources
* Description: 
* File name:   CXResources.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.09.2009 9:44:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/





#ifndef CXResourcesH
#define CXResourcesH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXString.h>
#include <vector>
#include <map>
////#include <boost/preprocessor/seq/elem.hpp>
//---------------------------------------------------------------------------
/*
#define (ID)(Left)(Top)(Width)(Length)(Style)(StyleEx)
*/	
////#define CTRL_ID(CTRL)       BOOST_PP_SEQ_ELEM(0, CTRL)	
////#define CTRL_LEFT(CTRL)     BOOST_PP_SEQ_ELEM(1, CTRL)
////#define CTRL_TOP(CTRL)      BOOST_PP_SEQ_ELEM(2, CTRL)
////#define CTRL_WIDTH(CTRL)	BOOST_PP_SEQ_ELEM(3, CTRL)
////#define CTRL_HEIGHT(CTRL)	BOOST_PP_SEQ_ELEM(4, CTRL)
////#define CTRL_STYLE (CTRL)   BOOST_PP_SEQ_ELEM(5, CTRL)
////#define CTRL_STYLE_EX(CTRL) BOOST_PP_SEQ_ELEM(6, CTRL)
////
////#define CTRL1_PROPERTIES 1001
////#define CTRL2_PROPERTIES 1002

//---------------------------------------------------------------------------
//����� �������� ���������	
class CXSettings {
	public:
						CXSettings   () :
						    _m_sText    (""), 			
							_m_iLeft    (0), 
							_m_iTop     (0), 
							_m_iWidth   (0), 
							_m_iHeight  (0),			   
							_m_ulStyle  (0),			   
							_m_ulStyleEx(0)	  {}
						/*CXSettings   (INT iLeft, INT iTop, INT iWidth, INT iHeight, ULONG ulStyle, ULONG ulStyleEx) :
							_m_iLeft    (iLeft), 
							_m_iTop     (iTop), 
							_m_iWidth   (iWidth), 
							_m_iHeight  (iHeight),			   
							_m_ulStyle  (ulStyle),			   
							_m_ulStyleEx(ulStyleEx) {}*/
		               ~CXSettings   ()       {} 

		std::string     sGetText     () const {return _m_sText;    }
		INT             iGetLeft     () const {return _m_iLeft;    }
		INT             iGetTop      () const {return _m_iTop;     }
		INT             iGetWidth    () const {return _m_iWidth;   }
		INT             iGetHeight   () const {return _m_iHeight;  }
		ULONG           ulGetStyle   () const {return _m_ulStyle;  }
		ULONG           ulGetStyleEx () const {return _m_ulStyleEx;}

		VOID            vSetText     (const std::string &csText) {_m_sText = csText;    }
		VOID            vSetLeft     (INT iLeft)                 {_m_iLeft = iLeft;    }
		VOID            vSetTop      (INT iTop)                  {_m_iTop = iTop;     }
		VOID            vSetWidth    (INT iWidth)				 {_m_iWidth = iWidth;   }
		VOID            vSetHeight   (INT iHeight)				 {_m_iHeight = iHeight;  }
		VOID            vSetStyle    (ULONG ulStyle)			 {_m_ulStyle = ulStyle;  }
		VOID            vSetStyleEx  (ULONG ulStyleEx)			 {_m_ulStyleEx = ulStyleEx;}

	private:
		std::string     _m_sText;
		INT             _m_iLeft; 
		INT             _m_iTop; 
		INT             _m_iWidth; 
		INT             _m_iHeight;
		ULONG           _m_ulStyle;
		ULONG           _m_ulStyleEx;
};
//---------------------------------------------------------------------------
class CXResources {
	public:
		static BOOL         bInit		    (const std::string &csResourceContent);
		static std::string  sGetText		(INT iID);
		static INT          iGetLeft		(INT iID);
		static INT          iGetTop		    (INT iID);
		static INT          iGetWidth       (INT iID);
		static INT          iGetHeight      (INT iID);
		static ULONG        ulGetStyle      (INT iID);
		static ULONG        ulGetStyleEx    (INT iID);

	private:
		typedef std::map   <INT, CXSettings> TSettingsMap;	
		typedef std::vector<CXSettings>      TSettingsVec;	

		static TSettingsMap _m_mapSettings;		    //����� ID + ������
		static TSettingsVec _m_vecsSettings;	    //����� ������

							 CXResources	();
							~CXResources	();

		static BOOL         _bParse         (const std::string &csIncludeFileContent);
		static BOOL         _bAddControl    (INT iID, const CXSettings *pcSettings);
		static BOOL         _bRemoveControl (INT iID);
};
//---------------------------------------------------------------------------
#endif