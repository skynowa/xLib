/****************************************************************************
* Class name:  CXSystemInfo
* Description: ��������� ����������
* File name:   CXSystemInfo.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.07.2009 11:52:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXSystemInfoH
#define CXSystemInfoH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXSystemInfo {
   public:
	  enum EOs {
		 osUnknown     = 0,
		 osWindows95   = 1,
		 osWindows98   = 2,
		 osWindowsNT   = 3,
		 osWindows2000 = 4,
		 osWindowsXP   = 5,
		 osWindows2003 = 6,
		 osWindows3    = 7
	  };

			     CXSystemInfo(void);
			    ~CXSystemInfo(void);

	  static EOs         GetOS        ();
	  static std::string sComputerName();
};
//---------------------------------------------------------------------------
#endif