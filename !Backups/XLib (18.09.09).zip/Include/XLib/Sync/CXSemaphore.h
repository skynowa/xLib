/****************************************************************************
* Class name:  CXSemaphore
* Description: ������ � ����������
* File name:   CXSemaphore.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 18:46:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXSemaphoreH
#define CXSemaphoreH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXSemaphore {
		_NO_COPY(CXSemaphore);

	public:
			   CXSemaphore          ();
			  ~CXSemaphore          ();
        HANDLE hGetHandle           ();
		BOOL   bCreate              (PSECURITY_ATTRIBUTES lpsaAttributes, LONG liInitialCount, LONG liMaxCount, LPCSTR pcszName);
		BOOL   bOpen                (ULONG ulAccess, BOOL bInheritHandle, LPCSTR lpszName);
		BOOL   bRelease             (LONG liReleaseCount = 1, LONG *pliOldCount = NULL );
        ULONG  ulWaitForSingleObject(ULONG ulTimeout = INFINITE);

	private:
		HANDLE _m_hSemaphore;
};
//---------------------------------------------------------------------------
#endif