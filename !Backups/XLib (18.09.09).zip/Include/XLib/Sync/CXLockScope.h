/****************************************************************************
* Class name:  CXLockScope
* Description: ������ � ������������ �������� � �����
* File name:   CXLockScope.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXLockScopeH
#define CXLockScopeH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXLockScope {
		_NO_COPY(CXLockScope);

    public:
        CXLockScope(CXCriticalSection &l) : 
			_m_LockScope(l) 
		{
            _m_LockScope.vEnter();
        }
        ~ CXLockScope() {
            _m_LockScope.vLeave();
        }
        
	private:
        CXCriticalSection &_m_LockScope;
};
//---------------------------------------------------------------------------
#endif