/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXPathH
#define CXPathH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <vector>
//---------------------------------------------------------------------------
class CXPath {
		_NO_COPY(CXPath);
		
	public:	
									   CXPath                   ();
									  ~CXPath                   ();

       static std::string			   sExePath                 (); /*+*/
	   static std::string              sExeDirPath              (); /*+*/
	   static std::string              sExtractFullFileName     (const std::string &csFilePath); /*+*/
	   static std::string              sExtractFileName         (const std::string &csFilePath); /*+*/
	   static std::string              sExtractFileExt          (const std::string &csFilePath); /*+*/
	   static std::string              sExtractFileDir          (const std::string &csFilePath); /*+*/
	   static std::string              sExtractFileDrive        (const std::string &csFilePath); /*+*/
	   static std::string              sExtractRelativePath     (const std::string &csFilePath); /*....*/
	   static std::string              sAddSlash                (const std::string &csDirPath);  /*+*/
	   static std::string              sDeleteSlash             (const std::string &csDirPath);  /*+*/
	   /*ExpandUNCFileName	���������� ������ ��� ����� �� ������� �����.*/
	   /*ExtractShortPathName	������������ ������� ��� ����� � ������ DOS.*/
	   /*ProcessPath	��������� �� ������� ����� ����� ��� �����, ��� �������� � ��� �����.*/
	   static std::string              sChangeFileExt           (const std::string &csFilePath, const std::string &csFileExt); /*+*/
	   static std::string              sChangeFullFileName      (const std::string &csFilePath, const std::string &csFileName); /*+*/
	   static std::string              sRemoveFileExt           (const std::string &csFilePath); /*+*/
	   static std::string              sRemoveFileExtIf         (const std::string &csFilePath, const std::string &csFileExt); /*-*/
	   static std::string              sMakeValidFileName       (const std::string &csFileName); /*-*/

	   static std::string              sGetEnvironmentVariable  (const std::string &csVar);      /*+*/
	   static BOOL                     bSetEnvironmentVariable  (const std::string &csVar, const std::string &csValue); /*+*/
	   static std::vector<std::string> vecsGetEnvironmentStrings(); /*+*/
	   static std::string              sExpandEnvironmentStrings(const std::string &csvVar); /*+*/

	   static std::string              sUnixToWinPath           (const std::string &csUnixPath, BOOL bNeedBackslashAtEnd); /*+*/
	   static std::string              sWinToUnixPath           (const std::string &csWinPath,  BOOL bNeedBackslashAtEnd); /*+*/

	   static std::string              sMinimizeFileName        (const std::string &csStr, const size_t cuiMaxLen);
	   static std::string              sMinimizePath            (const std::string &csPath, const size_t cuiMaxLen);
	   
	   //normalize
	private:	   
		//////{$IFDEF MSWINDOWS}
		////static const std::string       ms_csWinSlash;
		////static const std::string       ms_csUnixSlash;
		////static const std::string       ms_csPathDelim;
		////static const std::string       ms_csDriveDelim;
		////static const std::string       ms_csPathSep;
		////static const std::string       ms_csDot;
		////static const std::string       ms_csAllFilesMask;  
		//////{$ENDIF MSWINDOWS}
		//////{$IFDEF UNIX}
		//////	PathDelim    = '/';
		//////	AllFilesMask = '*';
		//////{$ENDIF UNIX}

};
//---------------------------------------------------------------------------
#endif
