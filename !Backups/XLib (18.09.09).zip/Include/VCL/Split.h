/**********************************************************************
*	������ � ������������ (������� Split)
*
***********************************************************************/

	
AnsiString TForm1::Split(AnsiString Str, char Delimiter, int Index){
    AnsiString Buff[256];
    int StartPos=0;
    int BuffIndex=0;
    for (int EndPos=1; EndPos<Str.Length()+1; EndPos++) {
        if (Str[EndPos]==Delimiter){
            BuffIndex++;
            Buff[BuffIndex]=Str.SubString(StartPos+1, (EndPos-1)-(StartPos+1)+1);
            StartPos=EndPos;
        }
    }
    return Buff[Index];
}
