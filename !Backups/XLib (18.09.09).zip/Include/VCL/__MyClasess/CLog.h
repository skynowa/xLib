/**********************************************************************
*	�����  CLog (CLog.h)
*
***********************************************************************/


#ifndef CLogH
#define CLogH       
//---------------------------------------------------------------------------
//--#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
//---------------------------------------------------------------------------
class CLog {
	public:
		CLog();
		~CLog();

		void vLog          (const std::string &csFileText);
		void vLogCharAsHex (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
        void vLogCharAsStr (const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen);
		void vOpen         ();
		void vDelete       ();
		void vSetName      (const std::string &csFileName);
		void vSetPath      (const std::string &csFilePath);
	
	private:
		std::string sLogPath;
		std::string sLogName;
		
		void vErrorMessageBox();
        std::string sGetCurrentDir();
};
//---------------------------------------------------------------------------
#endif