/**********************************************************************
*	vDBColumnToPickList -
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vDBColumnToPickList(TDBGrid *pDBGrid, int iColumn, TADOConnection *pADOConnection,  const UnicodeString &cusTableName, const UnicodeString &cusFieldName) {
	TADOQuery *qryTmp =  new TADOQuery(NULL);

	try {
		qryTmp->Connection = pADOConnection;
		qryTmp->Close();
		qryTmp->SQL->Text = L"SELECT " + cusFieldName + L" FROM " + cusTableName + L"  ORDER BY " + cusFieldName + L" ASC;"; 	//ShowMessage(qryTmp->SQL->Text);
		qryTmp->Open();
        qryTmp->First();
        pDBGrid->Columns->Items[iColumn]->PickList->Clear();
		while (! qryTmp->Eof) {
			if (qryTmp->FieldByName(cusFieldName)->IsNull == false) {
                pDBGrid->Columns->Items[iColumn]->PickList->Add(qryTmp->FieldByName(cusFieldName)->Value);
            }
            qryTmp->Next();
		}
        qryTmp->Close();

        pDBGrid->Columns->Items[iColumn]->DropDownRows = 20;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }

	delete qryTmp; qryTmp = NULL;
}
//---------------------------------------------------------------------------
