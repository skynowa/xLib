/****************************************************************************
* Class name:  CXFrame
* Description: ������ � ������
* File name:   CXFrame.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:10:17
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXFrame.h>

#include <XLib/GUI/Common.h>
#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXFrame::CXFrame() :
	CXWindow()
{
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName = /*CXFRAME_CONTROL_CLASS + "_" +*/ sCreatePlainGUID();
	_m_ulStyle    = CXFRAME_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle  = CXFRAME_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft      = CW_USEDEFAULT;
	_m_iTop       = CW_USEDEFAULT;
	_m_iWidth     = CXFRAME_DEFAULT_WIDTH;
	_m_iHeight    = CXFRAME_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXFrame::~CXFrame() {

}
//---------------------------------------------------------------------------
//����� ���������
X_BEGIN_MSG_MAP(CXFrame)
	X_MSG(WM_CREATE,  OnCreate)	
	X_MSG(WM_PAINT,   OnPaint);
	X_MSG(WM_COMMAND, OnCommand);
	X_MSG(WM_NOTIFY,  OnNotify);
	X_MSG(WM_SIZE,    OnSize);
	X_MSG(WM_CLOSE,   OnClose); 
	X_MSG(WM_DESTROY, OnDestroy)
X_END_MSG_MAP(CXWindow)
//X_END_MSG_MAP_NOPARENT
//---------------------------------------------------------------------------
BOOL CXFrame::bCreate(INT iID, HWND hParent, const std::string &csText, 
					  INT iLeft, INT iTop, INT iWidth, INT iHeight, 
					  ULONG ulStyle, ULONG ulExStyle,
					  SHORT siIconID, SHORT siIconSmID, SHORT siBGColor)
{
	////////BOOL bRes = FALSE;

	////////_m_iID = iID;

	//////////-------------------------------------
	//////////������������ ����� ����
	////////WNDCLASSEX wcex = {0};

	////////wcex.cbSize         = sizeof(WNDCLASSEX); 
	////////wcex.style			= CS_HREDRAW | CS_VREDRAW;
	////////wcex.lpfnWndProc	= (WNDPROC)_s_pWndProc;
	////////wcex.cbClsExtra		= 0;
	////////wcex.cbWndExtra		= 0;
	////////wcex.hInstance		= CXApplication::hGetInstance();
	////////wcex.hIcon			= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconID);
	////////wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);
	////////wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW + (HBRUSH)siBGColor);
	////////wcex.lpszMenuName	= (LPCTSTR)_m_iID;
	////////wcex.lpszClassName	= _m_sClassName.c_str();
	////////wcex.hIconSm		= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconSmID);
	////////
	////////bRes = _bRegisterClass(&wcex);
	////////CHECK_RET(FALSE == bRes, FALSE);

	//////////-------------------------------------
	//////////������� ����
 ////////   bRes = bCreateEx(0, hParent, _m_sClassName, csText, 
	////////	             iLeft, iTop, iWidth, iHeight,
	////////				 WS_OVERLAPPEDWINDOW, 
	////////				 WS_EX_CLIENTEDGE | WS_EX_APPWINDOW, 
 ////////      				 (LPVOID)this);
	////////CHECK_RET(FALSE == bRes, FALSE);

	////////if (NULL != hParent) {
	////////	::EnableWindow(hParent, FALSE);
	////////}

	////////return TRUE;
	BOOL bRes = FALSE;

	_m_iID = iID;

	//-------------------------------------
	//������������ ����� ����
	WNDCLASSEX wcex = {0};

	wcex.cbSize         = sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)_s_pWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= CXApplication::hGetInstance();
	wcex.hIcon			= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconID);
	wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW + (HBRUSH)siBGColor);
	wcex.lpszMenuName	= (LPCTSTR)/*_m_iID*/iID;
	wcex.lpszClassName	= _m_sClassName.c_str();
	wcex.hIconSm		= ::LoadIcon(CXApplication::hGetInstance(), (LPCTSTR)siIconSmID);

	bRes = _bRegisterClass(&wcex);
	CHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//������� ����
	bRes = bCreateEx(0, hParent, _m_sClassName, csText, 
					iLeft, iTop, iWidth, iHeight,
					WS_OVERLAPPEDWINDOW, 
					WS_EX_CLIENTEDGE | WS_EX_APPWINDOW, 
					(LPVOID)this);
					CHECK_RET(FALSE == bRes, FALSE);

	if (NULL != hParent) {
		::EnableWindow(hParent, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXFrame::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/XASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*////XASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXFrame::bCreate(iID, hParent, 
						    CXResources::sGetText(iID), 
							CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
							CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
							CXResources::ulGetStyle(iID), 
							CXResources::ulGetStyleEx(iID),
							/*SHORT siIconID*/0, /*SHORT siIconSmID*/0, /*SHORT siBGColor*/1);

	return TRUE;
}
//---------------------------------------------------------------------------
VOID CXFrame::OnCreate(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXFrame::OnPaint(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	PAINTSTRUCT ps  = {0};
	HDC         hdc = NULL;

	hdc = ::BeginPaint(_m_hWnd, &ps);
	//TODO: Add any drawing code here...
	::EndPaint(_m_hWnd, &ps);
}
//---------------------------------------------------------------------------
VOID CXFrame::OnCommand(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	
}
//---------------------------------------------------------------------------
VOID CXFrame::OnNotify(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	
}
//---------------------------------------------------------------------------
VOID CXFrame::OnSize(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

}
//---------------------------------------------------------------------------
VOID CXFrame::OnClose(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 
	bDestroy();
}
//---------------------------------------------------------------------------
VOID CXFrame::OnDestroy(WPARAM wParam, LPARAM lParam) {		/*virtual*/ 

	if (NULL != _m_hParentWnd) {
		bClose();
		::EnableWindow(_m_hParentWnd, TRUE);
		
		return;
	}

	CXApplication::vTerminate();
}
//---------------------------------------------------------------------------