/****************************************************************************
* Class name:  CXResources
* Description: 
* File name:   CXResources.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.09.2009 9:44:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXResources.h>

#include <XLib/CXString.h>
#include <map>
////#include <boost/preprocessor/seq/elem.hpp>
//---------------------------------------------------------------------------
//TODO: + �������������� ������ �����
/*TSettingsMap*/std::map   <INT, CXSettings> CXResources::_m_mapSettings;
/*TSettingsVec*/std::vector<CXSettings>      CXResources::_m_vecsSettings;    //--test
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
CXResources::CXResources() {        

}
//---------------------------------------------------------------------------
CXResources::~CXResources() {		 
	//code
}
//---------------------------------------------------------------------------
BOOL CXResources::bInit(const std::string &csResourceContent) {
	/*DEBUG*/XASSERT_RET(false == csResourceContent.empty(), FALSE);

	BOOL bRes = FALSE;

	bRes = _bParse(csResourceContent);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
std::string CXResources::sGetText(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].sGetText();
}
//---------------------------------------------------------------------------
INT CXResources::iGetLeft(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].iGetLeft();
}
//---------------------------------------------------------------------------
INT CXResources::iGetTop(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].iGetTop();
}
//---------------------------------------------------------------------------
INT CXResources::iGetWidth(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].iGetWidth();
}
//---------------------------------------------------------------------------
INT CXResources::iGetHeight(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].iGetHeight();
}
//---------------------------------------------------------------------------
ULONG CXResources::ulGetStyle(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].ulGetStyle();
} 
//---------------------------------------------------------------------------
ULONG CXResources::ulGetStyleEx(INT iID) {
	CHECK_RET(true == _m_mapSettings.empty(), 0);

	return _m_mapSettings[iID].ulGetStyleEx();
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXResources::_bParse(const std::string &csIncludeFileContent) {
	/*DEBUG*/XASSERT_RET(false == csIncludeFileContent.empty(), FALSE);
	/*DEBUG*///���� �� [;"] � ����� ������

	BOOL bRes = FALSE;

	//---------------------------
	//��������� ����� �������� (������ ������: "109 400,400,600,400,0,0;")	
	const std::string csResIDDelimiter       = " ";
	const std::string csResPropertyDelimiter = ",";
	const std::string csResEOL               = ";";

	//---------------------------
	//���� ���������� ������ [CTRL1_PROPERTIES 0,0,75,25,0,0;CTRL2_PROPERTIES 10,10,75,25,0,0;]
	std::vector<std::string> vecsLines;

	bRes = bSplit(csIncludeFileContent, csResEOL, &vecsLines);
	CHECK_RET(FALSE == bRes, FALSE);

	//---------------------------
	//������ ������ ��������:
	//	CTRL1_PROPERTIES 0,0,75,25,0,0	
	//	CTRL2_PROPERTIES 10,10,75,25,0,0
	//	[������ ������]

	_m_vecsSettings.resize(vecsLines.size() - 1);

	for (std::size_t i = 0; i < vecsLines.size() - 1; i ++) {
		INT         iID       = 0;
		std::string sText     = "";
		INT         iLeft     = 0;
		INT			iTop      = 0;
		INT			iWidth    = 0;
		INT			iHeight   = 0;
		ULONG		ulStyle   = 0;
		ULONG		ulStyleEx = 0;

		//-------------------------------------
		//������ ������ [ID Left,Top,Width,Height,Style,StyleEx]
		std::string sLine = "";

		sLine = vecsLines.at(i);
		sLine = sReplaceAll(sLine, "\t", " ");
		sLine = sTrimSpace(sLine);
		CHECK_DO(true == sLine.empty(), continue);

		//-------------------------------------
		//ID + Properties [ID Left,Top,Width,Height,Style,StyleEx]
		std::vector<std::string> vecsID_And_Properties;
		bRes = bSplit(sLine, csResIDDelimiter, &vecsID_And_Properties);
		CHECK_RET(FALSE == bRes, FALSE);

		iID  = tStrToAnyT<INT>(vecsID_And_Properties.at(0));	

		//-------------------------------------
		//properties
		std::vector<std::string> vecsProperties;
		bRes = bSplit(vecsID_And_Properties.at(1), csResPropertyDelimiter, &vecsProperties);
		CHECK_RET(FALSE == bRes, FALSE);

		sText     =                  (vecsProperties.at(0));
		iLeft     = tStrToAnyT<INT>  (vecsProperties.at(1));
		iTop      = tStrToAnyT<INT>  (vecsProperties.at(2));
		iWidth    = tStrToAnyT<INT>  (vecsProperties.at(3));
		iHeight   = tStrToAnyT<INT>  (vecsProperties.at(4));
		ulStyle   = tStrToAnyT<ULONG>(vecsProperties.at(5));
		ulStyleEx = tStrToAnyT<ULONG>(vecsProperties.at(6));

		//-------------------------------------
		//�������������� � ��������� �������
		_m_vecsSettings.at(i).vSetText   (sText);
		_m_vecsSettings.at(i).vSetLeft   (iLeft);
		_m_vecsSettings.at(i).vSetTop    (iTop);
		_m_vecsSettings.at(i).vSetWidth  (iWidth);
		_m_vecsSettings.at(i).vSetHeight (iHeight);
		_m_vecsSettings.at(i).vSetStyle  (ulStyle);
		_m_vecsSettings.at(i).vSetStyleEx(ulStyleEx);

		bRes = _bAddControl(iID, &_m_vecsSettings.at(i));	
		/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXResources::_bAddControl(INT iID, const CXSettings *pcSettings) {
	XASSERT_RET(0 < iID,            FALSE);
	XASSERT_RET(NULL != pcSettings, FALSE);

	_m_mapSettings[iID] = (*pcSettings);

	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXResources::_bRemoveControl(INT iID) {
	XASSERT_RET(0 < iID, FALSE);

	TSettingsMap::const_iterator it;

	it = _m_mapSettings.find(iID);
	XASSERT_RET(_m_mapSettings.end() != it, FALSE);

	_m_mapSettings.erase(it);

	return TRUE;
}
//---------------------------------------------------------------------------


