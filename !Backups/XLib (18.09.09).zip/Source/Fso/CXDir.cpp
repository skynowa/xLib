/****************************************************************************
* Class name:  CXDir
* Description: �������� � �������
* File name:   CXDir.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:23:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXDir.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXFile.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Debug/xassert.h>

const std::string csWinSlash  = "\\";
const std::string csUnixSlash = "/";
//---------------------------------------------------------------------------
//TODO: + CXDir
CXDir::CXDir() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXDir
CXDir::~CXDir() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsExists (����������, ���������� �� ��������� �������)
/*static*/BOOL CXDir::bIsExists(const std::string &csDirPath) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);

	if (CXFile::faDirectory == CXFile::ulGetAttr(csDirPath)) {
		return TRUE;
	}

	return FALSE;
}
//---------------------------------------------------------------------------
//TODO: + bIsEmpty (���������� ���� ������� ��� ���)
/*static*/BOOL CXDir::bIsEmpty(const std::string &csDirPath, const std::string &csMask) { 
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE);
	/*DEBUG*/XASSERT_RET(false == csMask.empty(),    FALSE);

	BOOL            bRes;
	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            _bRet;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, TRUE); 

	do {
		std::string sFileName = std::string(fd.cFileName);

		if ("." != sFileName && ".." != sFileName) {
			bRes = FALSE;	//�� ������
		} else {
			bRes = TRUE;	//������
		}

		_bRet = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == _bRet); 

	_bRet = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != _bRet, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: + sGetCurrent (���������� ������ ��� �������� ��������)
/*static*/std::string CXDir::sGetCurrent() {
	TCHAR szBuff[MAX_PATH + 1] = {0};
	
	ULONG ulRes = ::GetCurrentDirectory(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(0 != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//TODO: + bSetCurrent (������������� ������� �������)
/*static*/BOOL CXDir::bSetCurrent(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;
	
	bRes = ::SetCurrentDirectory(csDirPath.c_str());
	/*DEBUG*/XASSERT_RET(0 != bRes, FALSE);
	
	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: + sGetTempPath (���������� ���� � �������� %Temp%)
/*static*/std::string CXDir::sGetTempPath() {
	TCHAR szBuff[MAX_PATH + 1] = {'\0'};		
	ULONG ulRes = ::GetTempPath(MAX_PATH, szBuff);
	/*DEBUG*/XASSERT_RET(FALSE != ulRes, "");
	/*DEBUG*/XASSERT_RET(ulRes < MAX_PATH, "");

	return std::string(szBuff, ulRes);
}
//--------------------------------------------------------------------------
//TODO: + bCreate (������� �������)
/*static*/BOOL CXDir::bCreate(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = ::CreateDirectory(csDirPath.c_str(), NULL);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//--------------------------------------------------------------------------
//TODO: + vForceCreate (������� ��� ����������� �������� �� ��������� ����)
/*static*/VOID CXDir::vForceCreate(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), VOID(NULL));

	CHAR szPath[MAX_PATH + 1] = {0};

	::lstrcpy(szPath, CXPath::sUnixToWinPath(csDirPath, true).c_str());  

	LPSTR pszTemp = szPath;

	if (':' == pszTemp[1]) {
		pszTemp += 3;
	}

	while (*pszTemp) {
		CHAR szPathNow[MAX_PATH + 1] = {0};

		pszTemp = strchr(pszTemp, '\\') + 1;
		::lstrcpyn(szPathNow, szPath, pszTemp - szPath);
		if (FALSE == ::CreateDirectory(szPathNow, NULL) && ERROR_ALREADY_EXISTS != ::GetLastError()) {
			throw ::GetLastError();
		}
	}
}
//---------------------------------------------------------------------------
//TODO: - bCopy ()
/*static*/BOOL CXDir::bCopy(const std::string &csDirPathFrom, const std::string &csDirPathTo, BOOL bFailIfExists) {
	/*DEBUG*/XASSERT_RET(false == csDirPathFrom.empty(),    FALSE);
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csDirPathFrom), FALSE);
	/*DEBUG*/XASSERT_RET(false == csDirPathTo.empty(),      FALSE);

	BOOL bRes = FALSE;

	bRes = ::CopyFile(csDirPathFrom.c_str(), csDirPathTo.c_str(), bFailIfExists);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + bDelete (������� �������� �������)
/*static*/BOOL CXDir::bDelete(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = ::RemoveDirectory(csDirPath.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE);

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + bForceClear (������� �� ���������� ����������)
/*static*/BOOL CXDir::bForceClear(const std::string &csDirPath) { //��� �����
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    FALSE); 
	/*DEBUG*/XASSERT_RET(TRUE  == bIsExists(csDirPath), FALSE);

	HANDLE          hFile  = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA fd     = {0};
	std::string     sPath  = "";
	BOOL            bRes   = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, FALSE); 

	do {
		std::string sFileName = std::string(fd.cFileName);

		if ("." != sFileName && ".." != sFileName) {
			if (CXFile::faDirectory == CXFile::ulGetAttr(sPath + sFileName/*fd.dwFileAttributes*/)) {
				bRes = bForceDelete(sPath + sFileName);
			} else {
				bRes = CXFile::bDelete(sPath + sFileName);
			}
			//if not Result then Exit;
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bForceDelete (������� ���������� � ��� � ����������)
/*static*/BOOL CXDir::bForceDelete(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), FALSE); 

	BOOL bRes = FALSE;

	bForceClear(csDirPath);
	bRes = bDelete(csDirPath);

	return bRes;
}
//---------------------------------------------------------------------------
//TODO: + vecsListFiles (���������� ������ ������ � ����������)
std::vector<std::string> CXDir::vecsListFiles(const std::string &csDirPath, const std::string &csMask) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    std::vector<std::string>());

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;


	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + csMask).c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, std::vector<std::string>()); 

	do {
		//���������� �����
		if (!(CXFile::faDirectory == (fd.dwFileAttributes & CXFile::faDirectory))) {
			vecsRes.push_back(std::string(fd.cFileName));	
		} 

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
//TODO: + vecsListDirs (���������� ������ ���������� � ����������)
/*static*/std::vector<std::string> CXDir::vecsListDirs(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(),    std::vector<std::string>());

	std::vector<std::string> vecsRes;
	HANDLE                   hFile     = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA          fd        = {0}; 
	std::string              sPath     = "";
	BOOL                     bRes      = FALSE;

	sPath = csDirPath + csWinSlash;		//<-- MakePathOk
	hFile = ::FindFirstFile((sPath + "*").c_str(), &fd);
	CHECK_RET(INVALID_HANDLE_VALUE == hFile, std::vector<std::string>()); 

	do {
		//���������� ����� � "." ".."
		if ((CXFile::faDirectory == (fd.dwFileAttributes & CXFile::faDirectory)) && ("." != std::string(fd.cFileName)) && (".." != std::string(fd.cFileName))) {
			vecsRes.push_back(fd.cFileName);
		}

		bRes = ::FindNextFile(hFile, &fd);
	} 
	while (TRUE == bRes); 

	bRes = ::FindClose(hFile);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------







/*
  bool 
   FileUtilities::CopyDirectory(String sFrom, String sTo)
   {
      if (!FileUtilities::Exists(sTo))
      {
         if( !CreateDirectory(sTo))
         {
            String sMessage;
            sMessage.Format("Source: FileUtilities::CopyDirectory, Code: HM4234, Description: CreateDirectory %s failed. See previous error.", sTo);
            Logger::Instance()->LogError(sMessage);

            return false;
         }
      }

      if (sFrom.Right(1) != "\\")
         sFrom += "\\";
      if (sTo.Right(1) != "\\")
         sTo += "\\";

      String sWildCard = sFrom + "*.*";

      // Locate first match
      WIN32_FIND_DATA ffData;
      HANDLE hFileFound = FindFirstFile(sWildCard, &ffData);

      if (hFileFound == INVALID_HANDLE_VALUE)
      {
         String sMessage;
         sMessage.Format("Source: FileUtilities::CopyDirectory, Code: HM4233, Description: Find first file with wildcard %s failed. Error: %d.", sWildCard, GetLastError());
         Logger::Instance()->LogError(sMessage);

         return false;
      }

      while (hFileFound && FindNextFile(hFileFound, &ffData))
      {
         String sOldFullPath = sFrom + ffData.cFileName;
         String sNewFullPath = sTo + ffData.cFileName;

         if (ffData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) 
         {
            if( (_tcscmp(ffData.cFileName, _T(".")) != 0) &&
               (_tcscmp(ffData.cFileName, _T("..")) != 0) ) 
            {
               if( !CopyDirectory(sOldFullPath, sNewFullPath) )
                  return false;
            }

         }
         else
         { 
            if (FileUtilities::Exists(sNewFullPath))
            {
               // File already exists
               continue;
            }

            if (CopyFile(sOldFullPath, sNewFullPath, TRUE))
            {
               // We have copied the file successfully
               continue;
            }

            // We failed to copy the file. Check if the file no 
            // longer exists
            if (!FileUtilities::Exists(sOldFullPath))
               continue;

            // The file exists , but we were not able to copy it.
            String sMessage;
            sMessage.Format("Source: FileUtilities::CopyDirectory, Code: HM4232, Description: Copy of file from %s to %s failed. Error: %d", sOldFullPath, sNewFullPath, GetLastError());
            Logger::Instance()->LogError(sMessage);

            return false;
         }
      }

      FindClose(hFileFound);

      return true;
   }

   bool 
   FileUtilities::DeleteDirectory(const String &sDirName)
   {
      char szSource[MAX_PATH + 2] = "";
      _tcsncpy_s(szSource, MAX_PATH + 2, sDirName, MAX_PATH);

      SHFILEOPSTRUCT fs;
      ::memset(&fs, 0, sizeof(SHFILEOPSTRUCT));

      fs.pFrom = szSource;
      fs.wFunc = FO_DELETE;
      fs.fFlags |= (FOF_NOCONFIRMATION | FOF_NOCONFIRMMKDIR | FOF_SILENT |FOF_NOERRORUI);

      if (::SHFileOperation(&fs) != 0)
         return false;

      return true;
   }

   bool
   FileUtilities::DeleteFilesInDirectory(const String &sDirName)
   {
      String sDir = sDirName;
      if (sDir.Right(1) != "\\")
         sDir += "\\";

      WIN32_FIND_DATA ffData;
      HANDLE hFileFound = FindFirstFile(sDir + "*.*", &ffData);

      if (hFileFound == INVALID_HANDLE_VALUE)
         return TRUE;

      while (hFileFound && FindNextFile(hFileFound, &ffData))
      {
         if (!(ffData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
         {
            String sFileName = sDir + ffData.cFileName;
            FileUtilities::DeleteFile(sFileName);
         }
      }

      FindClose(hFileFound);

      return true;
   }

   bool
   FileUtilities::DeleteDirectoriesInDirectory(const String &sDirName, const std::set<String> vecExcludes)
   {
      String sDir = sDirName;
      if (sDir.Right(1) != "\\")
         sDir += "\\";

      WIN32_FIND_DATA ffData;
      HANDLE hFileFound = FindFirstFile(sDir + "*.*", &ffData);

      if (hFileFound == INVALID_HANDLE_VALUE)
         return TRUE;

      while (hFileFound && FindNextFile(hFileFound, &ffData))
      {
         if (ffData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
         {
            if( (_tcscmp(ffData.cFileName, _T(".")) != 0) &&
               (_tcscmp(ffData.cFileName, _T("..")) != 0) ) 
            {
               if (vecExcludes.find(ffData.cFileName) == vecExcludes.end())
               {
                  String sFileName = sDir + ffData.cFileName;
                  FileUtilities::DeleteDirectory(sFileName);
               }
            }
         }
      }

      FindClose(hFileFound);

      return true;
   }

   bool
   FileUtilities::_CreateDirectoryRecursive(const String &sDirName)
   {
      if (FileUtilities::Exists(sDirName))
         return true;

      int iLength = sDirName.GetLength();
      for (int i = 3; i < iLength; i++)
      {
         char c = sDirName.GetAt(i);

         if (c == '\\')
         {
            String sDirectoryName = sDirName.Mid(0, i);

            if (FileUtilities::Exists(sDirectoryName))
               continue;

            if (!CreateDirectory(sDirectoryName))
               return false;
         }
      }

      if (!FileUtilities::Exists(sDirName))
         return CreateDirectory(sDirName);

      return true;
   }
*/