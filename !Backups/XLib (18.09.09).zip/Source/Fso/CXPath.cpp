/****************************************************************************
* Class name:  CXPath
* Description: �������� � ������
* File name:   CXPath.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.06.2009 9:27:28
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXPath.h>

//#include <shlwapi.h>
//#pragma comment(lib, "shlwapi.lib")   

#include <XLib/CXString.h>
#include <XLib/Debug/xassert.h>
//---------------------------------------------------------------------------
#define ms_csWinSlash     "\\" //ms_csPathDelim
#define ms_csUnixSlash    "/"
#define ms_csDriveDelim   ":"
#define ms_csPathSep      ";"
#define ms_csDot          "."
#define ms_csAllFilesMask "*.*"
//---------------------------------------------------------------------------
CXPath::CXPath() {
	//code
}
//---------------------------------------------------------------------------
CXPath::~CXPath() {
	//code
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sExeDirPath() {
	return sExtractFileDir(sExePath());
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sExePath() {
	CHAR  szRes[MAX_PATH + 1] = {0};
	
	ULONG ulStored = ::GetModuleFileName(NULL, szRes, MAX_PATH);
	/*DEBUG*/XASSERT_RET(0    != ulStored, "");
	/*DEBUG*/XASSERT_RET(NULL != szRes,    "");        
	/*DEBUG*/XASSERT_RET('\0' != *szRes,   "");    

	return std::string(szRes, ulStored);	
}
//---------------------------------------------------------------------------
//��� + ���������
/*static*/std::string CXPath::sExtractFullFileName(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind(ms_csWinSlash, csFilePath.size());
	
	return csFilePath.substr(uiEndOfPathIndex + 1, csFilePath.size());
}
//--------------------------------------------------------------------------
//���
/*static*/std::string CXPath::sExtractFileName(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	return sRemoveFileExt(sExtractFullFileName(csFilePath));
}
//--------------------------------------------------------------------------
//Returns the path, without a trailing backslash '\'
/*static*/std::string CXPath::sExtractFileDir(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiEndOfPathIndex = csFilePath.rfind(ms_csWinSlash, csFilePath.size());

	return csFilePath.substr(0, uiEndOfPathIndex);
}
//---------------------------------------------------------------------------
//����
/*static*/std::string CXPath::sExtractFileDrive(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiPos = csFilePath.find(ms_csDriveDelim);

	return csFilePath.substr(0, uiPos + 1);
}
//---------------------------------------------------------------------------
//TODO: sExtractRelativePath
/*static*/std::string CXPath::sExtractRelativePath(const std::string &csFilePath) {

	return "";
}
//--------------------------------------------------------------------------
//TODO: sAddSlash (��������� � ����� ������ ������ ��������� ����� ����� '\')
/*static*/std::string CXPath::sAddSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	std::string sRes;

	if ('\\' == csDirPath.at(csDirPath.size() - 1)) {
		return csDirPath;
	}
	
	sRes.assign(csDirPath + ms_csWinSlash);

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: sDeleteSlash (������� � ����� ������ (���� � �����) ������ ��������� ����� ����� '\')
/*static*/std::string CXPath::sDeleteSlash(const std::string &csDirPath) {
	/*DEBUG*/XASSERT_RET(false == csDirPath.empty(), ""); 

	const size_t cuiPos = csDirPath.size() - 1;	//������� ���������� �������

	if ('\\' == csDirPath.at(cuiPos)) {
		return csDirPath.substr(0, cuiPos);
	}

	return csDirPath;
}
//--------------------------------------------------------------------------
//���������� ��� �����
/*static*/std::string CXPath::sExtractFileExt(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiDotPos = csFilePath.rfind(ms_csDot, csFilePath.size());

	return csFilePath.substr(uiDotPos + 1);
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sChangeFileExt(const std::string &csFilePath, const std::string &csFileExt) {	
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� '.'
		if ('.' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileExt);

			break;
		}
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sChangeFullFileName(const std::string &csFilePath, const std::string &csFileName) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csFilePath);

	for (size_t i = sRes.size() - 1; i > 0; i --) {
		//������� ���� '\\'
		if ('\\' == sRes.at(i - 1)) {
			sRes.erase(i, sRes.size() - i);
			sRes.append(csFileName);

			break;
		}
	}

	return sRes;
}
//--------------------------------------------------------------------------
//TODO: + sRemoveFileExt
/*static*/std::string CXPath::sRemoveFileExt(const std::string &csFilePath) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	size_t uiDotPos = csFilePath.rfind(ms_csDot, csFilePath.size());

	return csFilePath.substr(0, uiDotPos);
}
//--------------------------------------------------------------------------
//TODO: + sRemoveFileExtIf
/*static*/std::string CXPath::sRemoveFileExtIf(const std::string &csFilePath, const std::string &csFileExt) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), ""); 

	//���� ��� ������ ����������, �� ���������� �������� ������
	size_t uiFileExtPos = csFilePath.rfind(ms_csDot + csFileExt, csFilePath.size());
	if (std::string::npos == uiFileExtPos) {
		return csFilePath;
	}

	size_t uiDotPos = csFilePath.rfind(ms_csDot, csFilePath.size());

	return csFilePath.substr(0, uiDotPos);
}
//---------------------------------------------------------------------------
//TODO: + sMakeValidFileName
/*static*/std::string CXPath::sMakeValidFileName(const std::string &csFileName) {
	std::string sRes    = "";
	sRes.assign(csFileName);

	const INT ciFileNameMaxSize = 255;

	//-------------------------------------
	//��� ����� �� ������ ������
	if (true == sRes.empty()) {
		return "";
	}

	//-------------------------------------
	//��� ����� �� ������ 255 ��������
	if (ciFileNameMaxSize <= sRes.size()) {
		return "";
	}

	//-------------------------------------
	//��� ����� �� ����� �������� ������ �� ����� �����
	size_t uiDotPos = sRes.find_first_not_of(".");
	if (uiDotPos == std::string::npos) {
		return "";
	}

	//-------------------------------------
	//������ ������ - �� �����  	// if the first character is a dot, the filename is okay
	if ('.' == sRes.at(0)) {  //or space
		return "";
	}

	//-------------------------------------
	//A device name was used. You can pass this value to GetIsValidFileNameErrStr to obtain a pointer to the name of this device.


	//-------------------------------------
	//All characters greater than ASCII 31 to be used except for the following:    "/*:<>?\|
	const std::string csFatalChars = "\\/:*<>|?\"\t\n\r";

	size_t uiFound = sRes.find_first_of(csFatalChars);
	while (std::string::npos != uiFound) 	{
		sRes.erase(uiFound, 1);
		uiFound = sRes.find_first_of(csFatalChars, uiFound);
	}

	//-------------------------------------
	//The following device names cannot be used for a file name nor may they
	//be used for the first segment of a file name (that part which precedes the  first dot):
	//CLOCK$, AUX, CON, NUL, PRN, COM1, COM2, COM3, COM4, COM5, COM6, COM7, COM8,
	//COM9, LPT1, LPT2, LPT3, LPT4, LPT5, LPT6, LPT7, LPT8, LPT9
	//Device names are case insensitve. aux, AUX, Aux, etc. are identical.

	const std::string csReserved[] = { 
		"CON", "PRN", "AUX", "CLOCK$", "NUL",
		"COM0", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
		"LPT0", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" 
	};

	std::string sFileName = sRemoveFileExt(sRes);

	for (size_t i = 0; i < sizeof(csReserved)/sizeof(csReserved[0]); ++ i) {
		CHECK_RET(TRUE == bCompareNoCase(sFileName, csReserved[i]), "");
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sGetEnvironmentVariable(const std::string &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(MAX_PATH, '\0');

	//not including the terminating null character
	ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, ""); 

	sRes.resize(ulStored);

	if (sRes.size() < ulStored) {
		ulStored = ::GetEnvironmentVariable(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, "");
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/BOOL CXPath::bSetEnvironmentVariable(const std::string &csVar, const std::string &csValue) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), FALSE); 

	BOOL bRes = FALSE;

	bRes = ::SetEnvironmentVariable(csVar.c_str(), csValue.c_str());
	/*DEBUG*/XASSERT_RET(FALSE != bRes, FALSE); 

	return bRes;
}
//--------------------------------------------------------------------------
/*static*/std::vector<std::string> CXPath::vecsGetEnvironmentStrings() {
	std::vector<std::string> vecsRes;

	LPSTR pszVar = NULL; 
	LPCH  lpvEnv = NULL; 

	lpvEnv = ::GetEnvironmentStrings();
	/*DEBUG*/XASSERT_RET(NULL != lpvEnv, std::vector<std::string>()); 

	//Variable strings are separated by NULL byte, and the block is terminated by a NULL byte. 
	pszVar = (LPSTR)lpvEnv;

	while (*pszVar)	{
		//printf("%s\n", lpszVariable);
		vecsRes.push_back(std::string(pszVar));
		pszVar += ::lstrlen(pszVar) + 1;
	}

	BOOL bRes = FALSE;

	bRes = ::FreeEnvironmentStrings(lpvEnv);
	/*DEBUG*/XASSERT_RET(FALSE != bRes, std::vector<std::string>()); 

	return vecsRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sExpandEnvironmentStrings(const std::string &csVar) {
	/*DEBUG*/XASSERT_RET(false == csVar.empty(), ""); 

	ULONG       ulStored = FALSE;
	std::string sRes(MAX_PATH, '\0');

	ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
	/*DEBUG*/XASSERT_RET(0 != ulStored, ""); 

	sRes.resize(ulStored);	

	if (sRes.size() < ulStored) {
		ulStored = ::ExpandEnvironmentStrings(csVar.c_str(), &sRes.at(0), sRes.size());
		/*DEBUG*/XASSERT_RET(0 != ulStored, "");
	}

	sRes.resize(ulStored - sizeof(CHAR));	//������� '\0', including the terminating null character

	return sRes;
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sUnixToWinPath(const std::string &csUnixPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csUnixPath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csUnixPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('/' == sRes.at(i)) {
			sRes.at(i) = '\\';
		}
	}

	if (bNeedBackslashAtEnd && '\\' != sRes.at(sRes.size() - 1)) {
		sRes.append(ms_csWinSlash);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sWinToUnixPath(const std::string &csWinPath, BOOL bNeedBackslashAtEnd) {
	/*DEBUG*/XASSERT_RET(false == csWinPath.empty(), ""); 

	std::string sRes("");
	sRes.assign(csWinPath);

	for (size_t i = 0; i < sRes.size(); i ++) {
		if ('\\' == sRes.at(i)) {
			sRes.at(i) = '/';
		}
	}

	if (bNeedBackslashAtEnd && '/' != sRes.at(sRes.size() - 1)) {
		sRes.append(ms_csUnixSlash);
	}

	return sRes; 
}
//--------------------------------------------------------------------------
/*static*/std::string CXPath::sMinimizeFileName(const std::string &csStr, const size_t cuiMaxLen) {	
	/*DEBUG*/XASSERT_RET(false == csStr.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,          "");

	std::string sRes("");
	std::string sTildaDotExt      = "~." + sExtractFileExt(csStr);
	size_t      uiTildaDotExtSize = sTildaDotExt.size();

	if (csStr.size() > cuiMaxLen) {
		if (cuiMaxLen < uiTildaDotExtSize) {
			sRes = csStr.substr(0, cuiMaxLen);
		} else {
			sRes = csStr.substr(0, cuiMaxLen - uiTildaDotExtSize) + sTildaDotExt;
		}
	} else {
		sRes = csStr;
	}

	return sRes;
}
//---------------------------------------------------------------------------
/*static*/std::string CXPath::sMinimizePath(const std::string &csFilePath, const size_t cuiMaxLen) {
	/*DEBUG*/XASSERT_RET(false == csFilePath.empty(), "");
	/*DEBUG*/XASSERT_RET(0 < cuiMaxLen,               "");

	std::string sRes("");
	sRes.assign(csFilePath);	

	std::string sDrive = sExtractFileDrive(csFilePath);					    //D:
	std::string sDir   = sExtractFileDir(csFilePath).erase(0, 2) + ms_csWinSlash;	//\XLib\Test\CXString\Project\Debug\ 
	std::string sName  = sExtractFullFileName(csFilePath);				    //Test.exe

	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/> cuiMaxLen)) { 
		if ((std::string(ms_csWinSlash) + "..." + std::string(ms_csWinSlash)) == sDir ) {
			sDrive.clear();
			sDir = "..." + std::string(ms_csWinSlash);
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			BOOL   bRoot = FALSE;
			size_t P     = std::string::npos;

			if (ms_csWinSlash == sDir) {
				sDir.clear();
			} else {
				if (sDir.at(0) == '\\') {
					bRoot = true;
					//������� � 1(0) ������� 1 ������
					//Delete(S, 1, 1);
					sDir.erase(0, 1);
				} else {
					bRoot = FALSE;
				}

				if ('.' == sDir.at(0)) {
					//Delete(S, 1, 4);
					sDir.erase(0, 4);
				}

				//P = AnsiPos("\\", S); 
				P = sDir.find_first_of(ms_csWinSlash) + 1;

				if (std::string::npos != P) {
					//Delete(S, 1, P); - c ������� 1(0) P ��������
					sDir.erase(0, P);
					sDir = "..." + std::string(ms_csWinSlash) + sDir;        
				} else {
					sDir.clear();
				}

				if (bRoot) {
					sDir = ms_csWinSlash + sDir;
				}
			}
			//-------------------------------

		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//--------------------------------------------------------------------------
/*
CommandLineToArgvA
    PCHAR*
    CommandLineToArgvA(
        PCHAR CmdLine,
        int* _argc
        )
    {
        PCHAR* argv;
        PCHAR  _argv;
        ULONG   len;
        ULONG   argc;
        CHAR   a;
        ULONG   i, j;

        BOOLEAN  in_QM;
        BOOLEAN  in_TEXT;
        BOOLEAN  in_SPACE;

        len = strlen(CmdLine);
        i = ((len+2)/2)*sizeof(PVOID) + sizeof(PVOID);

        argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
            i + (len+2)*sizeof(CHAR));

        _argv = (PCHAR)(((PUCHAR)argv)+i);

        argc = 0;
        argv[argc] = _argv;
        in_QM = FALSE;
        in_TEXT = FALSE;
        in_SPACE = TRUE;
        i = 0;
        j = 0;

        while( a = CmdLine[i] ) {
            if(in_QM) {
                if(a == '\"') {
                    in_QM = FALSE;
                } else {
                    _argv[j] = a;
                    j++;
                }
            } else {
                switch(a) {
                case '\"':
                    in_QM = TRUE;
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    in_SPACE = FALSE;
                    break;
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    if(in_TEXT) {
                        _argv[j] = '\0';
                        j++;
                    }
                    in_TEXT = FALSE;
                    in_SPACE = TRUE;
                    break;
                default:
                    in_TEXT = TRUE;
                    if(in_SPACE) {
                        argv[argc] = _argv+j;
                        argc++;
                    }
                    _argv[j] = a;
                    j++;
                    in_SPACE = FALSE;
                    break;
                }
            }
            i++;
        }
        _argv[j] = '\0';
        argv[argc] = NULL;

        (*_argc) = argc;
        return argv;
    }
*/

/*

 String
   FileUtilities::GetShortPath(const String &sInPath)
   {
      TCHAR szModuleShort[_MAX_PATH];
      GetShortPathName(sInPath, szModuleShort, _MAX_PATH );

      return szModuleShort;
   }

   String
   FileUtilities::GetLongPath(const String &sInPath)
   {
      TCHAR szLong[_MAX_PATH];
      GetLongPathName(sInPath, szLong, _MAX_PATH );

      return szLong;
   }




//--------------------------------------------------------------------------
*/