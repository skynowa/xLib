/****************************************************************************
* Class name:  CXTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CXTraceLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXTraceLog.h>

#include <XLib/Debug/xassert.h>
#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
//---------------------------------------------------------------------------
CXTraceLog::CXTraceLog() {
	//code
}
//---------------------------------------------------------------------------
CXTraceLog::~CXTraceLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
BOOL CXTraceLog::bWrite(LPCSTR pcszFormat, ...) {     
	/*DEBUG*/XASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	std::string sTime = "";
	SYSTEMTIME  stST  = {0};

	::GetLocalTime(&stST);
	sTime = sFormatStr("[%.2d:%.2d:%.2d]", stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	std::string sParam  = "";
	va_list     palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = sFormatStrV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	::OutputDebugString((sTime + " " + sParam + "\r\n").c_str());
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------