/****************************************************************************
* Class name:  CXEdit
* Description: ������ � ��������� �����
* File name:   CXEdit.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXEdit.h>
//---------------------------------------------------------------------------
CXEdit::CXEdit() {
	LOG();
	
	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXEDIT_CONTROL_CLASS;
	_m_ulStyle        = CXEDIT_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXEDIT_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXEDIT_DEFAULT_WIDTH;
	_m_iHeight        = CXEDIT_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXEdit::~CXEdit() {
	LOG();
}
//---------------------------------------------------------------------------
LRESULT CXEdit::bLimitText(UINT uiSize) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(EM_LIMITTEXT, uiSize, NULL);
}
//---------------------------------------------------------------------------
/*
VOID CXEdit::CopyEditToClipboard() {
	lSendMessage(EM_SETSEL, 0, 65535L);
	lSendMessage(WM_COPY,   0, 0);
	lSendMessage(EM_SETSEL, 0, 0);
}
*/
//---------------------------------------------------------------------------