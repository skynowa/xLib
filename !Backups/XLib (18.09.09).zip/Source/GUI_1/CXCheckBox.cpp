/****************************************************************************
* Class name:  CXCheckBox
* Description: 
* File name:   CXCheckBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:47:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXCheckBox.h>
//---------------------------------------------------------------------------
CXCheckBox::CXCheckBox() {
	LOG();
	
	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXBUTTON_CONTROL_CLASS;
	_m_ulStyle        = CXCHECKBOX_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXCHECKBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXCHECKBOX_DEFAULT_WIDTH;
	_m_iHeight        = CXCHECKBOX_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXCheckBox::~CXCheckBox() {
	LOG();
}
//---------------------------------------------------------------------------
BOOL CXCheckBox::bIsChecked() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return lSendMessage(BM_GETCHECK, 0, 0) == BST_CHECKED;
}
//---------------------------------------------------------------------------
BOOL CXCheckBox::bCheck(BOOL bChecked) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, FALSE);

	return (BOOL)lSendMessage(BM_SETCHECK, bChecked ? BST_CHECKED : BST_UNCHECKED, 0);
}
//---------------------------------------------------------------------------