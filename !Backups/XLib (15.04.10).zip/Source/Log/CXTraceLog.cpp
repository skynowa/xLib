/****************************************************************************
* Class name:  CXTraceLog
* Description: ����������� ����� "TRACE"
* File name:   CXTraceLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:45:21
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Log/CXTraceLog.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
//---------------------------------------------------------------------------
//TODO: + CXTraceLog ()
CXTraceLog::CXTraceLog(BOOL bIsNeedTimeStr) :
	_m_bIsNeedTimeStr(bIsNeedTimeStr)
{
	//code
}
//---------------------------------------------------------------------------
//TODO: + ~CXTraceLog ()
CXTraceLog::~CXTraceLog() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CXTraceLog::bWrite(LPCTSTR pcszFormat, ...) {  
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	//-------------------------------------
	//�����
	tString    sTime;
	SYSTEMTIME stST = {0};

	if (TRUE == _m_bIsNeedTimeStr) {
		::GetLocalTime(&stST);
		sTime = CXString::sFormat(_T("[%.2d:%.2d:%.2d] "), stST.wHour, stST.wMinute, stST.wSecond);
	} else {
		sTime = _T("");
	}

	//-------------------------------------
	//���������
	tString sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = CXString::sFormatV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	::OutputDebugString((sTime + sParam + xLF).c_str());
	/*DEBUG*///not need

	return TRUE;
}
//---------------------------------------------------------------------------