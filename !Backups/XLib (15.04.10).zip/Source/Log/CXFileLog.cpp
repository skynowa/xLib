/****************************************************************************
* Class name:  CXFileLog
* Description: ����������� � ����
* File name:   CXFileLog.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:40:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Log/CXFileLog.h>

#include <XLib/CXString.h>
#include <XLib/Fso/CXPath.h>
#include <XLib/Sync/CXAutoCriticalSection.h>
#include <XLib/Fso/CXStdioFile.h>
//---------------------------------------------------------------------------
//TODO: + CXFileLog ()
CXFileLog::CXFileLog() : 
	_m_sLogPath     (), 
	_m_ulMaxFileSize(0)
{
	/*DEBUG*/xASSERT_DO(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE, return);

	//�� ������ ���� (��� �����)
	_m_sLogPath      = CXPath::sSetExt(CXPath::sGetExe(), _T("exe.log"));
	_m_ulMaxFileSize = DEFAULT_MAX_LOG_SIZE;
}
//---------------------------------------------------------------------------
//TODO: + CXFileLog ()
CXFileLog::CXFileLog(const tString &csFilePath, ULONG ulMaxFileSize) : 
	_m_sLogPath     (), 
	_m_ulMaxFileSize(0)
{
	/*DEBUG*/xASSERT_DO(false         == csFilePath.empty(),   return);
	/*DEBUG*/xASSERT_DO(LIMIT_LOG_SIZE > ulMaxFileSize,        return);
	/*DEBUG*/xASSERT_DO(LIMIT_LOG_SIZE > DEFAULT_MAX_LOG_SIZE, return);

	//��� ����� - �� �������� "\"
	if (tString::npos == csFilePath.find(xWIN_SLASH)) {
		//�� ������ ���� (��� �����)
		_m_sLogPath      = CXPath::sGetDir(CXPath::sGetExe()) + xWIN_SLASH + csFilePath/* + ".log"*/;
		_m_ulMaxFileSize = ulMaxFileSize;
	} else {
		//������ ����
		_m_sLogPath      = csFilePath;
		_m_ulMaxFileSize = ulMaxFileSize;
	}
}
//---------------------------------------------------------------------------
//TODO: + ~CXFileLog ()
CXFileLog::~CXFileLog() {
	//code
}
//---------------------------------------------------------------------------


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bWrite ()
BOOL CXFileLog::bWrite(LPCTSTR pcszFormat, ...) {   
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, FALSE);

	BOOL bRes = FALSE;

	bRes = _bDeleteIfFull();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//�����
	tString    sTime;
	SYSTEMTIME stST = {0};

	::GetLocalTime(&stST);
	sTime = CXString::sFormat(_T("[%.2d:%.2d:%.2d]"), stST.wHour, stST.wMinute, stST.wSecond);

	//-------------------------------------
	//���������
	tString sParam;
	va_list palArgs = NULL;

	va_start(palArgs, pcszFormat);
	sParam = CXString::sFormatV(pcszFormat, palArgs);
	va_end(palArgs);	

	//-------------------------------------
	//����� ���
	/*LOCK*/CXAutoCriticalSection SL(_m_csFile);

	CXStdioFile sfFile;

	bRes = sfFile.bOpen(_m_sLogPath, _T("a"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	sfFile.iFprintf(_T("%s %s\n"), sTime.c_str(), sParam.c_str());

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXFileLog::bOpen() {
	BOOL bRes = FALSE;

	bRes = CXStdioFile::bExec(_m_sLogPath);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bClear ()
BOOL CXFileLog::bClear() {
	BOOL bRes = FALSE;

	/*LOCK*/CXAutoCriticalSection SL(_m_csFile);

	CXStdioFile sfFile;
	
	bRes = sfFile.bOpen(_m_sLogPath, _T("w"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	
	sfFile.iFprintf(_T(""));

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bDelete ()
BOOL CXFileLog::bDelete() {
	BOOL bRes = FALSE;

	/*LOCK*/CXAutoCriticalSection SL(_m_csFile);

	bRes = CXStdioFile::bRemove(_m_sLogPath);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: + _bDeleteIfFull ()
BOOL CXFileLog::_bDeleteIfFull() {
	BOOL bRes = FALSE;

	/*LOCK*/CXAutoCriticalSection SL(_m_csFile);

	bRes = CXStdioFile::bIsExists(_m_sLogPath);
	xCHECK_RET(FALSE == bRes, TRUE);

	CXStdioFile sfFile;
	LONG        liSize = CXStdioFile::ppError;

	bRes = sfFile.bOpen(_m_sLogPath, _T("r"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	liSize = sfFile.liGetSize();
	/*DEBUG*/xASSERT_RET(CXStdioFile::ppError != liSize, FALSE);

	bRes = sfFile.bClose();
	/*DEBUG*/xASSERT_RET(CXStdioFile::ppError != liSize, FALSE);

	//-------------------------------------
	//���� ������ ���� �������� ���������� �������� - ������� ���
	if (static_cast<ULONG>(liSize / 1000000) >= _m_ulMaxFileSize) {		//������ ����� � ������ / 1000000		//���������
		bRes = CXStdioFile::bRemove(_m_sLogPath);
		/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------