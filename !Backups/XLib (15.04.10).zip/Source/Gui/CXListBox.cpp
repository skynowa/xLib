/****************************************************************************
* Class name:  CXListBox
* Description: 
* File name:   CXListBox.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 22:59:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXListBox.h>

//---------------------------------------------------------------------------
//TODO: + CXListBox 
CXListBox::CXListBox() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXLISTBOX_CONTROL_CLASS;
	_m_ulStyle        = xCXLISTBOX_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = xCXLISTBOX_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXLISTBOX_DEFAULT_WIDTH;
	_m_iHeight        = xCXLISTBOX_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXListBox
CXListBox::~CXListBox() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXListBox::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/xASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
		CXResources::sGetText(iID), 
		CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
		CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
		CXResources::ulGetStyle(iID), 
		CXResources::ulGetStyleEx(iID),
		this);
	xCHECK_RET(FALSE == bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAddString 
BOOL CXListBox::bAddString(const tString &csItem) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_ADDSTRING, NULL, (LPARAM)csItem.c_str());
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bResetContent 
BOOL CXListBox::bResetContent() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_RESETCONTENT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAddFile
BOOL CXListBox::bAddFile(const tString &csFileName) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_ADDFILE, NULL, (LPARAM)csFileName.c_str());
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bDeleteString
BOOL CXListBox::bDeleteString(INT iStartIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_DELETESTRING, (WPARAM)iStartIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bDeleteString
BOOL CXListBox::bDir(UINT uiDir) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	////pSendMessage(LB_DIR, (WPARAM)uiDir, NULL);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bFindString
BOOL CXListBox::bFindString(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_FINDSTRING, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bFindStringExact
BOOL CXListBox::bFindStringExact(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_FINDSTRINGEXACT, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetAnchorIndex
BOOL CXListBox::bGetAnchorIndex() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETANCHORINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCaretIndex
BOOL CXListBox::bGetCaretIndex() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETCARETINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCount
BOOL CXListBox::bGetCount() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETCOUNT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetCurSel
BOOL CXListBox::bGetCurSel() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETCURSEL, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetHorizontalExtent
BOOL CXListBox::bGetHorizontalExtent() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETHORIZONTALEXTENT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemData
BOOL CXListBox::bGetItemData(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETITEMDATA, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemHeight
BOOL CXListBox::bGetItemHeight(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETITEMHEIGHT, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetItemRect
BOOL CXListBox::bGetItemRect(WPARAM wItemIndex, LPARAM lRect) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETITEMRECT, wItemIndex, lRect);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetListBoxInfo
BOOL CXListBox::bGetListBoxInfo() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	///////////////pSendMessage(LB_GETLISTBOXINFO, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetLocale
BOOL CXListBox::bGetLocale() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETLOCALE, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSel
BOOL CXListBox::bGetSel(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETSEL, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSelCount
BOOL CXListBox::bGetSelCount() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETSELCOUNT, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetSelItems
BOOL CXListBox::bGetSelItems(LPARAM lItems) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETSELITEMS, NULL, lItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetText
BOOL CXListBox::bGetText(WPARAM wItemIndex, LPARAM lItems) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETTEXT, wItemIndex, lItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetTextLen
BOOL CXListBox::bGetTextLen(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETTEXTLEN, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bGetTopIndex
BOOL CXListBox::bGetTopIndex() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_GETTOPINDEX, NULL, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bInitStorage
BOOL CXListBox::bInitStorage(WPARAM wItemsCount, LPARAM lMem) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_INITSTORAGE, wItemsCount, lMem);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bInsertString
BOOL CXListBox::bInsertString(WPARAM wItemIndex, LPARAM lString) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_INSERTSTRING, wItemIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bItemFromPoint
BOOL CXListBox::bItemFromPoint(LPARAM lPoint) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_ITEMFROMPOINT, NULL, lPoint);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelectString
BOOL CXListBox::bSelectString(WPARAM wStartIndex, LPARAM lString) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SELECTSTRING, wStartIndex, lString);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelItemRange
BOOL CXListBox::bSelItemRange(WPARAM wOption, LPARAM lFirstLastItems) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SELITEMRANGE, wOption, lFirstLastItems);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSelItemRangeEx
BOOL CXListBox::bSelItemRangeEx(WPARAM wFirstItem, LPARAM lLastItem) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SELITEMRANGEEX, wFirstItem, lLastItem);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetAnchorIndex
BOOL CXListBox::bSetAnchorIndex(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETANCHORINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCaretIndex
BOOL CXListBox::bSetCaretIndex(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETCARETINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetColumnWidth
BOOL CXListBox::bSetColumnWidth(WPARAM wWidth) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETCOLUMNWIDTH, wWidth, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCount
BOOL CXListBox::bSetCount(WPARAM wCount) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETCOUNT, wCount, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetCurSel
BOOL CXListBox::bSetCurSel(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETCURSEL, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetHorizontalExtent
BOOL CXListBox::bSetHorizontalExtent(WPARAM wScrollWidth) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETHORIZONTALEXTENT, wScrollWidth, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetItemData
BOOL CXListBox::bSetItemData(WPARAM wItemIndex, LPARAM lValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETITEMDATA, wItemIndex, lValue);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetItemHeight
BOOL CXListBox::bSetItemHeight(WPARAM wItemIndex, LPARAM lHeight) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETITEMHEIGHT, wItemIndex, lHeight);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetLocale
BOOL CXListBox::bSetLocale(WPARAM wLocaleIdentifier) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETLOCALE, wLocaleIdentifier, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetSel
BOOL CXListBox::bSetSel(WPARAM wSelOption, LPARAM lItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETSEL, wSelOption, lItemIndex);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetTabStops
BOOL CXListBox::bSetTabStops(WPARAM wTabStopsNum, LPARAM lTabStopsArr) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETTABSTOPS, wTabStopsNum, lTabStopsArr);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bSetTopIndex
BOOL CXListBox::bSetTopIndex(WPARAM wItemIndex) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	pSendMessage(LB_SETTOPINDEX, wItemIndex, NULL);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO:  bVScroll
BOOL CXListBox::bVScroll(WPARAM wPos) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

    return pSendMessage(WM_VSCROLL, MAKEWORD(wPos, 0), 0);
    
    return TRUE;
}
//---------------------------------------------------------------------------