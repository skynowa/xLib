/****************************************************************************
* Class name:  CXStatic
* Description: ������ � ����������� �����
* File name:   CXStatic.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:20:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Gui/CXStatic.h>

#include <XLib/GUI/CXWindowImpl.h>

//---------------------------------------------------------------------------
//TODO: + CXStatic
CXStatic::CXStatic() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXSTATIC_CONTROL_CLASS;
	_m_ulStyle        = xCXSTATIC_DEFAULT_WINDOW_STYLE;
	_m_ulStyleEx      = xCXSTATIC_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXSTATIC_DEFAULT_WIDTH;
	_m_iHeight        = xCXSTATIC_DEFAULT_HEIGHT;

	_m_bIsControl = TRUE;
}
//---------------------------------------------------------------------------
//TODO: + ~CXStatic
CXStatic::~CXStatic() {
	LOG();

	///pParentWnd->DelControl(hWnd);
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXStatic::bCreateRes(INT iID, CXWindow *pwndParent/*HWND hParent*/) {
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/////xASSERT_RET(NULL != hParent, FALSE);

	BOOL bRes = FALSE;

	bRes = CXWindow::bCreate(iID, pwndParent->hGetHandle()/*hParent*/, _m_sClassName, 
							 CXResources::sGetText    (iID), 
							 CXResources::iGetLeft    (iID), CXResources::iGetTop(iID), 
							 CXResources::iGetWidth   (iID), CXResources::iGetHeight(iID), 
							 CXResources::ulGetStyle  (iID), 
							 CXResources::ulGetStyleEx(iID),
							 this);
	xCHECK_RET(FALSE == bRes, FALSE);

	CXWindowImpl *pParent = reinterpret_cast<CXWindowImpl *>(pwndParent);
	/*DEBUG*/xASSERT_RET(NULL != pParent, FALSE);
	
	pParent->m_vecpContainer.bAdd(this);

	return TRUE;
}
//---------------------------------------------------------------------------