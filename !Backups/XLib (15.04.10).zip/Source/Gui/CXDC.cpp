/****************************************************************************
* Class name:  CXDC
* Description: ������ � ���������� ����������
* File name:   CXDC.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.06.2009 21:30:49
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXDC.h>
//---------------------------------------------------------------------------------------
CXDC::CXDC() : 
	_m_hDC(NULL)
{
}
//---------------------------------------------------------------------------
CXDC::~CXDC() {
	if (_m_hDC) {
	    ::DeleteDC(_m_hDC);
	}
}
//---------------------------------------------------------------------------
BOOL CXDC::bAttach(HDC hdc) {
	if (_m_hDC) {
	    return FALSE;
	}
	
	_m_hDC = hdc;

	return TRUE;
}
//---------------------------------------------------------------------------
HDC CXDC::hDetach() {
	HDC RetDc = _m_hDC;
	_m_hDC = NULL;
	
	return RetDc;
}
//---------------------------------------------------------------------------
BOOL CXDC::bTextOut(INT xStart, INT yStart, std::string &csText, INT iText) {
	if (!_m_hDC) {
	    return FALSE;
	}
	
	return ::TextOut(_m_hDC, xStart, yStart, csText.c_str(), iText);
}
//---------------------------------------------------------------------------
BOOL CXDC::bTextOut(INT xStart, INT yStart, std::string &csText) {
	if (!_m_hDC) {
	    return FALSE;
	}
	
	return ::TextOut(_m_hDC, xStart, yStart, csText.c_str(), csText.size());
}
//---------------------------------------------------------------------------------------