/****************************************************************************
* Class name:  CXStatusBar
* Description: ������ ���������
* File name:   CXStatusBar.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     26.07.2009 23:49:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/



#include <XLib/Gui/CXStatusBar.h>

#include <XLib/GUI/CXApplication.h>
//---------------------------------------------------------------------------
CXStatusBar::CXStatusBar() :
    _m_iDefaultSize                  (0),
	m_iNumParts                      (0)

{
	::ZeroMemory(&m_iPartsWidths[0], sizeof(m_iPartsWidths));
	
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = xCXSTATUSBAR_CONTROL_CLASS;
	_m_ulStyle        = xCXSTATUSBAR_DEFAULT_WINDOW_STYLE | SBT_TOOLTIPS;
	_m_ulStyleEx      = xCXSTATUSBAR_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = xCXSTATUSBAR_DEFAULT_WIDTH;
	_m_iHeight        = xCXSTATUSBAR_DEFAULT_HEIGHT;

	_m_bIsControl     = TRUE;
	
	_m_iDefaultSize   = - 1;
	
	//TODO: _bInitCommonControls
	_bInitCommonControls(ICC_BAR_CLASSES);
}
//---------------------------------------------------------------------------
CXStatusBar::~CXStatusBar() {
	LOG();
}
//---------------------------------------------------------------------------
//TODO: + bCreateRes
BOOL CXStatusBar::bCreateRes(INT iID, HWND hParent) {
	/*DEBUG*/xASSERT_RET(0 < iID,         FALSE);
	/*DEBUG*/xASSERT_RET(NULL != hParent, FALSE);

	_m_bRes = CXWindow::bCreate(iID, hParent, _m_sClassName, 
								CXResources::sGetText(iID), 
								CXResources::iGetLeft(iID),  CXResources::iGetTop(iID), 
								CXResources::iGetWidth(iID), CXResources::iGetHeight(iID), 
								CXResources::ulGetStyle(iID), 
								CXResources::ulGetStyleEx(iID),
								this);
	xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + bGetBorders (Retrieves the current widths of the horizontal and vertical borders of a status window. )
BOOL CXStatusBar::bGetBorders(INT *pBorderWidth[3]) {
	/*DEBUG*/

	_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_GETBORDERS, (WPARAM)0, (LPARAM)pBorderWidth) );
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bSetIcon (Sets the icon for a part in a status bar)
BOOL CXStatusBar::bSetIcon(INT iPart, HICON hIcon) {
	/*DEBUG*/

	_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_SETICON, (WPARAM)iPart, (LPARAM)hIcon/*NULL*/) );
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - hGetIcon (Retrieves the icon for a part in a status bar)
HICON CXStatusBar::hGetIcon(INT iPart) {
	/*DEBUG*/ 

	HICON hIcon = NULL;

	hIcon = static_cast<HICON>( pSendMessage((UINT)SB_GETICON, (WPARAM)iPart, (LPARAM)0) );
	/*DEBUG*/xASSERT_RET(NULL != hIcon, NULL); 

	return hIcon;
}
//---------------------------------------------------------------------------
//TODO: - iGetParts (Retrieves a count of the parts in a status window. The message also retrieves the coordinate of the right edge of the specified number of parts. )
INT CXStatusBar::iGetParts(/*PARAMS*/) {
	/*DEBUG*/

	INT iRes = 0;

	////_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_GETPARTS, (WPARAM)xxxx, (LPARAM)xxxx) );
	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: - bSetParts (Sets the number of parts in a status window and the coordinate of the right edge of each part)
BOOL CXStatusBar::bSetParts(INT iParts) {
	/*DEBUG*///iParts <= 256

	m_iNumParts = iParts;
	
	m_veciParts.resize(m_iNumParts);

	_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)&m_veciParts) );
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------







//---------------------------------------------------------------------------
//SB_GETRECT	Retrieves the bounding rectangle of a part in a status window. 
//---------------------------------------------------------------------------
//TODO: - bGetText (The SB_GETTEXT message retrieves the text from the specified part of a status window)
tString CXStatusBar::sGetText(INT iPartIndex) {
	/*DEBUG*/ 

	tString sRes;
	ULONG   ulRes;

	ulRes = static_cast<ULONG>( pSendMessage((UINT)SB_GETTEXTLENGTH, (WPARAM)iPartIndex, (LPARAM)0) );
	/*DEBUG*/// n/a

	sRes.resize(LOWORD(ulRes));

	/*ulRes = static_cast<ULONG>*/( pSendMessage((UINT)SB_GETTEXT, (WPARAM)iPartIndex, (LPARAM)&sRes.at(0)) );
	/*DEBUG*/// n/a

	return sRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetText (The SB_SETTEXT message sets the text in the specified part of a status window)
BOOL CXStatusBar::bSetText(INT iPartIndex, const tString &csText) {
	/*DEBUG*/

	_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_SETTEXT, (WPARAM)(INT) iPartIndex /*FIX: | uType*/, (LPARAM)(LPSTR) &csText.at(0)) );
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//Retrieves the tooltip text for a part in a status bar. The status bar must be created with the SBT_TOOLTIPS style to enable tooltips. 
//TODO: - bGetTipText ()
tString CXStatusBar::sGetTipText(INT iPartIndex) {
	/*DEBUG*/
	
	tString sRes(256, xT('\0'));

	pSendMessage((UINT)SB_GETTIPTEXT, (WPARAM) MAKEWPARAM(iPartIndex, 256/*FIX: nSize*/), (LPARAM)(LPCTSTR) &sRes.at(0));
	/*DEBUG*/// n/a

	return sRes.assign(sRes.c_str());
}
//---------------------------------------------------------------------------
//TODO: - bSetTipText (Sets the tooltip text for a part in a status bar. The status bar must have been created with the SBT_TOOLTIPS style to enable tooltips.)
BOOL CXStatusBar::bSetTipText(INT iPartIndex, const tString &csTest) {
	/*DEBUG*/

	pSendMessage((UINT)SB_SETTIPTEXT, (WPARAM)iPartIndex, (LPARAM)&csTest.at(0));
	/*DEBUG*/// n/a 

	return TRUE;
}
//---------------------------------------------------------------------------








//---------------------------------------------------------------------------
//SB_GETUNICODEFORMAT	Retrieves the Unicode character format flag for the control. 
//---------------------------------------------------------------------------
//TODO: + bIsSimple (Checks a status bar control to determine if it is in simple mode)
BOOL CXStatusBar::bIsSimple() {
	/*DEBUG*/

	_m_bRes = static_cast<BOOL>( pSendMessage((UINT)SB_ISSIMPLE, (WPARAM)0, (LPARAM)0) );
	/*DEBUG*/// n/a 

	return _m_bRes;
}
//---------------------------------------------------------------------------
//TODO: + bSetSimple (Specifies whether a status window displays simple text or displays all window parts set by a previous SB_SETPARTS message.)
BOOL CXStatusBar::bSetSimple(BOOL bFlag) {
	/*DEBUG*/ 

	pSendMessage(SB_SIMPLE, (WPARAM)bFlag, (LPARAM)0);
	/*DEBUG*/// n/a 

	return TRUE;
}
//---------------------------------------------------------------------------
//SB_SETBKCOLOR	Sets the background color in a status bar. 

//---------------------------------------------------------------------------
//SB_SETMINHEIGHT	Sets the minimum height of a status window's drawing area. 
//---------------------------------------------------------------------------




//---------------------------------------------------------------------------
//SB_SETUNICODEFORMAT	Sets the Unicode character format flag for the control. This message allows you to change the character set used by the control at run time rather than having to re-create the control. 
//---------------------------------------------------------------------------










































//---------------------------------------------------------------------------
INT CXStatusBar::Height() {
	/*RECT rect = GetRect();*/
	
	return 0;/*rect.bottom - rect.top;*/
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetMinHeight(INT iHeight) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)pSendMessage(SB_SETMINHEIGHT, (WPARAM)iHeight, (LPARAM)0);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(INT nPart, HICON hIcon) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)pSendMessage(SB_SETICON, (WPARAM)nPart, (LPARAM)hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetIcon(INT PartIndex, INT IdIcon) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return SetIcon(PartIndex, hIcon);
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetText(INT PartIndex, const tString &csPartText) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	return (BOOL)pSendMessage(SB_SETTEXT, PartIndex, (LPARAM)csPartText.c_str());
}
//---------------------------------------------------------------------------
BOOL CXStatusBar::SetSize(INT PartIndex, INT Size) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	if (PartIndex >= m_iNumParts) {
		return FALSE;
	}
	m_iPartsWidths[PartIndex] = Size;

	return (BOOL)pSendMessage(SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart() {
	return AddPart(_m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const tString &csPartText) {
	return AddPart(csPartText, _m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const tString &csPartText, HICON hIcon) {
	return AddPart(csPartText, hIcon, _m_iDefaultSize);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const tString &csPartText, INT IdIcon) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);
	
	return AddPart(csPartText, hIcon);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(INT Size) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, NULL);

	m_iPartsWidths[m_iNumParts] = 0;
	for (INT Cnt = 0; Cnt < m_iNumParts; Cnt ++) {
		m_iPartsWidths[m_iNumParts] += m_iPartsWidths[Cnt];
	}
	m_iPartsWidths[m_iNumParts] += Size;
	m_iNumParts ++;
	if (!pSendMessage(SB_SETPARTS, (WPARAM)m_iNumParts, (LPARAM)m_iPartsWidths)) {
		return  - 1;
	}
	
	return m_iNumParts - 1;
}
//---------------------------------------------------------------------------
////////INT CXStatusBar::AddPart(const tString &csPartText, INT Size) {
////////	INT Index = - 1;
////////	Index = AddPart(Size);
////////	if (Index < 0) {
////////		return Index;
////////	}
////////	SetText(m_iNumParts - 1, csPartText);
////////	
////////	return Index;
////////}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const tString &csPartText, HICON hIcon, INT Size) {
	INT Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);
	SetText(m_iNumParts - 1, csPartText);
	
	return Index;
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(const tString &csPartText, INT IdIcon, INT Size) {
	HICON hIcon = (HICON)::LoadImage(CXApplication::hGetInstance(), MAKEINTRESOURCE(IdIcon), IMAGE_ICON, 0, 0, LR_SHARED);

	return AddPart(csPartText, hIcon, Size);
}
//---------------------------------------------------------------------------
INT CXStatusBar::AddPart(HICON hIcon, INT Size) {
	INT Index = - 1;
	Index = AddPart(Size);
	if (Index < 0) {
		return Index;
	}
	SetIcon(m_iNumParts - 1, hIcon);

	return Index;
}
//---------------------------------------------------------------------------