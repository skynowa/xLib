/****************************************************************************
* Class name:  CXStyle
* Description: �������� �����
* File name:   CXStyle.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.04.2010 13:37:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Gui/CXStyle.h>



/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXStyle (comment)
CXStyle::CXStyle() : 
	_m_hWnd(NULL)
{
	/*DEBUG*/xASSERT_DO(NULL == _m_hWnd, return);
}
//---------------------------------------------------------------------------
//TODO: - ~CXStyle (comment)
CXStyle::~CXStyle() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXStyle (comment)
BOOL CXStyle::bSetOwner(HWND hWnd) {
	/*DEBUG*/xASSERT_RET(NULL != hWnd, FALSE);

	_m_hWnd = hWnd;
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + atGet
/*static*/
CXStyle::TStyle CXStyle::stGet() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return static_cast<TStyle>(::GetWindowLong(_m_hWnd, GWL_STYLE));
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + bSet
/*static*/
BOOL CXStyle::bSet(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	::SetWindowLong(_m_hWnd, GWL_STYLE, static_cast<ULONG>(stValue));
	/*DEBUG*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAdd
/*static*/
BOOL CXStyle::bAdd(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	return bModify(static_cast<TStyle>(0), stValue);
}
//---------------------------------------------------------------------------
//TODO: + bRemove ()
/*static*/
BOOL CXStyle::bRemove(TStyle stValue)  {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	return bModify(stValue, static_cast<TStyle>(0));
}
//---------------------------------------------------------------------------
//TODO: + bModify
/*static*/
BOOL CXStyle::bModify(TStyle stRemoveValue, TStyle stAddValue) {	
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stRemoveValue
	/*DEBUG*/// stAddValue

	BOOL bRes = FALSE;
	
	//First we get the current window Attr.
	TStyle stValue = stGet();

	//Change bits.
	////stValue &= ~ulRemoveValue;
	////stValue |= ulAddValue;
	stValue = static_cast<TStyle>( static_cast<ULONG>(stValue) & ~stRemoveValue );
	stValue = static_cast<TStyle>( static_cast<ULONG>(stValue) |  stAddValue    );

	//Change the Attr.
	bSet(stValue);
	/*DEBUG*/
	
	bRes = ::InvalidateRect(_m_hWnd, NULL, TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bIsExists ()
/*static*/
BOOL CXStyle::bIsExists(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	//////ULONG _ulAttr = 0xffffffff;
	//////	
	//////_m_bRes = bGetAttr(&_ulAttr);
	///////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//////if (_ulAttr & ulAttr) {
	//////	return TRUE;
	//////}

	////////////////////if ((ulGetAttr() & BS_TYPEMASK) == stValue) {
	////////////////////	return TRUE;
	////////////////////}

	/*ULONG _ulAttr = ulGetAttr();
	if (_ulAttr & ulAttr) {
		return TRUE;
	}*/
	
	
	TStyle _atValue /*= faInvalid*/;
	
	_atValue = stGet();
	xCHECK_RET(_atValue & stValue, TRUE);

	return FALSE;
}
//---------------------------------------------------------------------------







//---------------------------------------------------------------------------
//TODO: + atGet
/*static*/
CXStyle::TStyle CXStyle::stGetEx() {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);

	return static_cast<TStyle>(::GetWindowLong(_m_hWnd, GWL_EXSTYLE));
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + bSet
/*static*/
BOOL CXStyle::bSetEx(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	::SetWindowLong(_m_hWnd, GWL_EXSTYLE, static_cast<ULONG>(stValue));
	/*DEBUG*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAdd
/*static*/
BOOL CXStyle::bAddEx(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	return bModifyEx(static_cast<TStyle>(0), stValue);
}
//---------------------------------------------------------------------------
//TODO: + bRemove ()
/*static*/
BOOL CXStyle::bRemoveEx(TStyle stValue)  {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	return bModifyEx(stValue, static_cast<TStyle>(0));
}
//---------------------------------------------------------------------------
//TODO: + bModify
/*static*/
BOOL CXStyle::bModifyEx(TStyle stRemoveValue, TStyle stAddValue) {	
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stRemoveValue
	/*DEBUG*/// stAddValue

	BOOL bRes = FALSE;

	//First we get the current window Attr.
	TStyle stValue = stGetEx();

	//Change bits.
	////stValue &= ~ulRemoveValue;
	////stValue |= ulAddValue;
	stValue = static_cast<TStyle>( static_cast<ULONG>(stValue) & ~stRemoveValue );
	stValue = static_cast<TStyle>( static_cast<ULONG>(stValue) |  stAddValue    );

	//Change the Attr.
	bSetEx(stValue);
	/*DEBUG*/

	bRes = ::InvalidateRect(_m_hWnd, NULL, TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bIsExists ()
/*static*/
BOOL CXStyle::bIsExistsEx(TStyle stValue) {
	/*DEBUG*/xASSERT_RET(NULL != _m_hWnd, FALSE);
	/*DEBUG*/// stValue

	//////ULONG _ulAttr = 0xffffffff;
	//////	
	//////_m_bRes = bGetAttr(&_ulAttr);
	///////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//////if (_ulAttr & ulAttr) {
	//////	return TRUE;
	//////}

	////////////////////if ((ulGetAttr() & BS_TYPEMASK) == stValue) {
	////////////////////	return TRUE;
	////////////////////}

	/*ULONG _ulAttr = ulGetAttr();
	if (_ulAttr & ulAttr) {
	return TRUE;
	}*/


	TStyle _atValue /*= faInvalid*/;

	_atValue = stGetEx();
	xCHECK_RET(_atValue & stValue, TRUE);

	return FALSE;
}
//---------------------------------------------------------------------------

/****************************************************************************
*    Private methods                                                          
*                                                                            
*****************************************************************************/









/****************************************************************************
*	�����
*
*****************************************************************************/

//////---------------------------------------------------------------------------
//////TODO: + bGetStyle
////ULONG CXWindow::ulGetStyle() {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return static_cast<ULONG>( liGetWindowLong(GWL_STYLE) );
////	}
//////---------------------------------------------------------------------------
//////TODO: + bGetStyleEx
////ULONG CXWindow::ulGetStyleEx() {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return static_cast<ULONG>( liGetWindowLong(GWL_EXSTYLE));
////	}
//////---------------------------------------------------------------------------
//////TODO: + bAddStyle
////BOOL CXWindow::bAddStyle(ULONG ulStyle) {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return bModifyStyle(0, ulStyle);
////	}
//////---------------------------------------------------------------------------
//////TODO: + bAddStyleEx
////BOOL CXWindow::bAddStyleEx(ULONG ulStyleEx) {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return bModifyStyleEx(0, ulStyleEx);
////	}
//////---------------------------------------------------------------------------
//////TODO: + bRemoveStyle ()
////BOOL CXWindow::bRemoveStyle(ULONG ulStyle)  {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return bModifyStyleEx(ulStyle, 0);
////	}
//////---------------------------------------------------------------------------
//////TODO: + bRemoveStyleEx ()
////BOOL CXWindow::bRemoveStyleEx(ULONG ulStyleEx)  {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	return bModifyStyleEx(ulStyleEx, 0);
////	}
//////---------------------------------------------------------------------------
//////TODO: + bModifyStyle
////BOOL CXWindow::bModifyStyle(ULONG ulRemoveStyle, ULONG ulAddStyle) {	
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	//First we get the current window style.
////	ULONG ulStyle = ulGetStyle();
////
////	//Change bits.
////	ulStyle &= ~ulRemoveStyle;
////	ulStyle |= ulAddStyle;
////
////	//Change the style.
////	liSetWindowLong(GWL_STYLE, ulStyle);
////	/*DEBUG*/
////
////	////_m_bRes = bSetPos(0, 0, 0, 0, SWP_DRAWFRAME | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
////	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
////
////	_m_bRes = bInvalidateRect(NULL, TRUE);
////	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
////
////	return TRUE;
////
////	////liSetWindowLong(GWL_STYLE,
////	////	(liGetWindowLong(GWL_STYLE)&(~ulRemoveStyle))|ulAddStyle);
////
////
////	//SetWindowLong(Handle, GWL_STYLE, GetWindowLong(Handle, GWL_STYLE) xor WS_BORDER);
////	}
//////---------------------------------------------------------------------------
//////TODO: + bModifyStyleEx
////BOOL CXWindow::bModifyStyleEx(ULONG ulRemoveStyleEx, ULONG ulAddStyleEx) {	
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	//First we get the current window extended style.
////	ULONG ulStyleEx = ulGetStyleEx();
////
////	//Change bits.
////	ulStyleEx &= ~ulRemoveStyleEx;
////	ulStyleEx |= ulAddStyleEx;
////
////	//Change the extended style.
////	liSetWindowLong(GWL_EXSTYLE, ulStyleEx);
////	/*DEBUG*/
////
////	////_m_bRes = bSetPos(0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
////	/////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
////
////	_m_bRes = bInvalidateRect(NULL, TRUE);
////	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
////
////	return TRUE;
////	}
//////---------------------------------------------------------------------------
//////TODO: - bIsStyleExists ()
////BOOL CXWindow::bIsStyleExists(ULONG ulStyle) {
////	/*DEBUG*/xASSERT_RET(FALSE != bIsWindow(), FALSE);
////
////	//////ULONG _ulStyle = 0xffffffff;
////	//////	
////	//////_m_bRes = bGetStyle(&_ulStyle);
////	///////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
////
////	//////if (_ulStyle & ulStyle) {
////	//////	return TRUE;
////	//////}
////
////	if ((ulGetStyle() & BS_TYPEMASK) == ulStyle) {
////		return TRUE;
////	}
////
////	/*ULONG _ulStyle = ulGetStyle();
////	if (_ulStyle & ulStyle) {
////	    return TRUE;
////	}*/
////
////	return FALSE;
////}
//////---------------------------------------------------------------------------