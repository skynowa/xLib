/****************************************************************************
* Class name:  CXTls
* Description: ��������� ������ ������
* File name:   CXTls.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     18.01.2010 14:42:20
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXTls.h>

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXTls (�����������)
CXTls::CXTls() :
	_m_ulIndex(TLS_OUT_OF_INDEXES)
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXTls (����������)
CXTls::~CXTls() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bAlloc (Allocates a thread local storage (TLS) index)
BOOL CXTls::bAlloc() {
	/*DEBUG*/xASSERT_RET(TLS_OUT_OF_INDEXES == _m_ulIndex, FALSE);
	
	BOOL  bRes  = FALSE;
	ULONG ulRes = TLS_OUT_OF_INDEXES;
	
	ulRes = ::TlsAlloc();
	/*DEBUG*/xASSERT_RET(TLS_OUT_OF_INDEXES != ulRes, FALSE);	
	
	_m_ulIndex = ulRes;
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bFree (Releases a thread local storage (TLS) index, making it available for reuse)
BOOL CXTls::bFree() {
	/*DEBUG*/xASSERT_RET(TLS_OUT_OF_INDEXES != _m_ulIndex, FALSE);
	
	BOOL bRes = FALSE;
	
	bRes = ::TlsFree(_m_ulIndex);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);	 

	return TRUE;
}
//--------------------------------------------------------------------------- 
//TODO: - pGetValue (Retrieves the value in the calling thread's thread local storage (TLS) slot for the specified TLS index)
VOID *CXTls::pvGetValue() {
	/*DEBUG*/xASSERT_RET(TLS_OUT_OF_INDEXES != _m_ulIndex, FALSE);
	
	VOID *pvRes = NULL;
	
	pvRes = ::TlsGetValue(_m_ulIndex);
	/*DEBUG*/xASSERT_RET(FALSE      != pvRes, FALSE);
	/*DEBUG*/////xASSERT_RET(_m_ulIndex == pvRes, FALSE);

	return pvRes;
}
//--------------------------------------------------------------------------- 
//TODO: - bSetValue (Stores a value in the calling thread's thread local storage (TLS) slot for the specified TLS index)
BOOL CXTls::bSetValue(VOID *pvValue) {
	/*DEBUG*/xASSERT_RET(TLS_OUT_OF_INDEXES != _m_ulIndex, FALSE);
	/*DEBUG*/xASSERT_RET(NULL               != pvValue,    FALSE);
	
	BOOL bRes = FALSE;
	
	bRes = ::TlsSetValue(_m_ulIndex, pvValue);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------