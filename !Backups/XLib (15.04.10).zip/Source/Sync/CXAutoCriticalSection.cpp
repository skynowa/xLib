/****************************************************************************
* Class name:  CXAutoCriticalSection
* Description: ������ � ������������ �������� � �����
* File name:   CXAutoCriticalSection.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXAutoCriticalSection.h>

/****************************************************************************
*	public
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXAutoCriticalSection (�����������)
CXAutoCriticalSection::CXAutoCriticalSection(CXCriticalSection &csCS) : 
	_m_csCS(csCS) 
{
	_m_csCS.vEnter();
}
//---------------------------------------------------------------------------
//TODO: + CXAutoCriticalSection (�����������)
////CXAutoCriticalSection::CXAutoCriticalSection(CXCriticalSection &csCS, BOOL bTry, ULONG ulTimeout /*= 1000*/) : 
////	_m_csCS(csCS) 
////{
////	bTry = FALSE;
////
////	if (TRUE == bTry) {       
////		/*DEBUG*/xASSERT(FALSE);
////
////		BOOL bRes = FALSE;
////
////		while (FALSE == _m_csCS.bTryEnter()) {
////			::OutputDebugString(_T("bTryEnter is FALSE\n"));
////			
////			//::Sleep(ulTimeout); 
////			BOOL bRes = _m_slSleeper.bSleep(ulTimeout);
////			/*DEBUG*/xASSERT_DO(FALSE != bRes, break)
////
////		}
////	} else {
////		_m_csCS.vEnter();
////	}
////}
//---------------------------------------------------------------------------
//TODO: + ~CXAutoCriticalSection (����������)
CXAutoCriticalSection::~CXAutoCriticalSection() {
	_m_csCS.vLeave();
}
//---------------------------------------------------------------------------