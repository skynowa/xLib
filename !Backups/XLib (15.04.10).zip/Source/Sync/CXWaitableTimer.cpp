/****************************************************************************
* Class name:  CXWaitableTimer
* Description: ������ � �������� ��������
* File name:   CXWaitableTimer.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.05.2009 17:07:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXWaitableTimer.h>

//---------------------------------------------------------------------------
//TODO: + CXWaitableTimer ()
CXWaitableTimer::CXWaitableTimer() {

}  
//---------------------------------------------------------------------------
//TODO: + ~CXWaitableTimer ()
CXWaitableTimer::~CXWaitableTimer() {
	/*DEBUG*/xASSERT(FALSE != _m_hWaitableTimer.bIsValid());

}
//---------------------------------------------------------------------------
//TODO: + hGetHandle ()
HANDLE CXWaitableTimer::hGetHandle() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hWaitableTimer.bIsValid(), NULL);

	return _m_hWaitableTimer.m_hHandle;
}
//---------------------------------------------------------------------------
//TODO: + bCreate ()
BOOL CXWaitableTimer::bCreate(BOOL bManualReset, LPCTSTR pcszName, LPSECURITY_ATTRIBUTES lpTimerAttributes) {
	/*DEBUG*/xASSERT_RET(FALSE == _m_hWaitableTimer.bIsValid(), FALSE);

	HANDLE hRes = NULL;

	hRes = ::CreateWaitableTimer(lpTimerAttributes, bManualReset, pcszName);
	/*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	_m_hWaitableTimer.m_hHandle = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bOpen ()
BOOL CXWaitableTimer::bOpen(LPCTSTR pcszName, ULONG ulDesiredAccess, BOOL bInheritHandle) {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hWaitableTimer.bIsValid(), FALSE);

	HANDLE hRes = NULL;

	hRes = ::OpenWaitableTimer(ulDesiredAccess, bInheritHandle, pcszName);
	/*DEBUG*/xASSERT_RET(NULL != hRes, FALSE);

	_m_hWaitableTimer.m_hHandle = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCancel ()
BOOL CXWaitableTimer::bCancel() const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hWaitableTimer.bIsValid(), FALSE);

	BOOL bRes = FALSE;

	bRes = ::CancelWaitableTimer(_m_hWaitableTimer.m_hHandle);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSet ()
BOOL CXWaitableTimer::bSet(LONGLONG i64DueTime, LONG liPeriod, PTIMERAPCROUTINE pfnCompletionRoutine, LPVOID pvArgToCompletionRoutine, BOOL bResume) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hWaitableTimer.bIsValid(), FALSE);

	/*
	#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	//����� �������� ��� ������� = 2 �������
	qwTimeInterval = -2 * _SECOND;
	*/
	BOOL bRes = FALSE;  //#define _SECOND 10000000   // ���� ������� ��� ���������� �������
	
	LARGE_INTEGER liDueTime = {0};
	liDueTime.QuadPart = i64DueTime;
	
	bRes = ::SetWaitableTimer(_m_hWaitableTimer.m_hHandle, &liDueTime, liPeriod, pfnCompletionRoutine, pvArgToCompletionRoutine, bResume);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWait ()
BOOL CXWaitableTimer::bWait(ULONG ulTimeout) const {
	/*DEBUG*/xASSERT_RET(FALSE != _m_hWaitableTimer.bIsValid(), FALSE);

	ULONG ulRes = WAIT_FAILED;

	ulRes = ::WaitForSingleObject(_m_hWaitableTimer.m_hHandle, ulTimeout); 
	/*DEBUG*/xASSERT_RET(WAIT_OBJECT_0 == ulRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------