/****************************************************************************
* Class name:  CCompletionPort
* Description: ���� ����������
* File name:   CCompletionPort.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.02.2010 14:28:40
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Sync/CXCompletionPort.h>

/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXCompletionPort (�����������)
CXCompletionPort::CXCompletionPort() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXCompletionPort (����������)
CXCompletionPort::~CXCompletionPort() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bCreate (Creates an input/output (I/O) completion port and associates it with a specified file handle, or creates an I/O completion port that is not yet associated with a file handle, allowing association at a later time.)
BOOL CXCompletionPort::bCreate(HANDLE hFileHandle, HANDLE hExistingCompletionPort, ULONG_PTR pulCompletionKey, ULONG ulNumberOfConcurrentThreads) {
	/*DEBUG*/

	BOOL   bRes = FALSE;
	HANDLE hRes = NULL;

	hRes = ::CreateIoCompletionPort(hFileHandle, hExistingCompletionPort, pulCompletionKey, ulNumberOfConcurrentThreads);
	/*DEBUG*/

	_m_hCompletionPort = hRes;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetStatus (Attempts to dequeue an I/O completion packet from the specified I/O completion port.)
BOOL CXCompletionPort::bGetStatus(LPDWORD lpNumberOfBytes, PULONG_PTR lpCompletionKey, LPOVERLAPPED *lpOverlapped, ULONG ulMilliseconds) {
	/*DEBUG*/

	BOOL bRes = FALSE;

	bRes = ::GetQueuedCompletionStatus(_m_hCompletionPort, lpNumberOfBytes, lpCompletionKey, lpOverlapped, ulMilliseconds);
	/*DEBUG*/

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bPostStatus (Posts an I/O completion packet to an I/O completion port.)
BOOL CXCompletionPort::bPostStatus(ULONG ulNumberOfBytesTransferred, ULONG_PTR ulCompletionKey, LPOVERLAPPED lpOverlapped) {
	/*DEBUG*/

	BOOL bRes = FALSE;

	bRes = ::PostQueuedCompletionStatus(_m_hCompletionPort, ulNumberOfBytesTransferred, ulCompletionKey, lpOverlapped);
	/*DEBUG*/

	return TRUE;
}
//---------------------------------------------------------------------------