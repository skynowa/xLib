/****************************************************************************
* Class name:  CXFileAttribute
* Description: �������� �����
* File name:   CXFileAttribute.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.04.2010 13:37:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXFileAttribute.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + atGet
/*static*/
CXFileAttribute::TAttribute CXFileAttribute::atGet(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);

	return static_cast<TAttribute>( ::GetFileAttributes(csFilePath.c_str()) );
	/*DEBUG*/// n/a
}
//---------------------------------------------------------------------------
//TODO: + bSet
/*static*/
BOOL CXFileAttribute::bSet(const tString &csFilePath, TAttribute atValue) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/// atValue

	BOOL bRes = FALSE;

	bRes = ::SetFileAttributes(csFilePath.c_str(), static_cast<ULONG>(atValue));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
//TODO: + bAdd
/*static*/
BOOL CXFileAttribute::bAdd(const tString &csFilePath, TAttribute atValue) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/// atValue

	return bModify(csFilePath, static_cast<TAttribute>(0), atValue);
}
//---------------------------------------------------------------------------
//TODO: + bRemove ()
/*static*/
BOOL CXFileAttribute::bRemove(const tString &csFilePath, TAttribute atValue)  {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/// atValue

	return bModify(csFilePath, atValue, static_cast<TAttribute>(0));
}
//---------------------------------------------------------------------------
//TODO: + bModify
/*static*/
BOOL CXFileAttribute::bModify(const tString &csFilePath, TAttribute atRemoveValue, TAttribute atAddValue) {	
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/// atRemoveValue
	/*DEBUG*/// atAddValue

	//First we get the current window Attr.
	TAttribute atValue = atGet(csFilePath);

	//Change bits.
	////atValue &= ~ulRemoveValue;
	////atValue |= ulAddValue;
	atValue = static_cast<TAttribute>( static_cast<ULONG>(atValue) & ~atRemoveValue );
	atValue = static_cast<TAttribute>( static_cast<ULONG>(atValue) |  atAddValue    );

	//Change the Attr.
	bSet(csFilePath, atValue);
	/*DEBUG*/
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bIsExists ()
/*static*/
BOOL CXFileAttribute::bIsExists(const tString &csFilePath, TAttribute atValue) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/// atValue

	//////ULONG _ulAttr = 0xffffffff;
	//////	
	//////_m_bRes = bGetAttr(&_ulAttr);
	///////*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//////if (_ulAttr & ulAttr) {
	//////	return TRUE;
	//////}

	////////////////////if ((ulGetAttr() & BS_TYPEMASK) == atValue) {
	////////////////////	return TRUE;
	////////////////////}

	/*ULONG _ulAttr = ulGetAttr();
	if (_ulAttr & ulAttr) {
		return TRUE;
	}*/
	
	
	TAttribute _atValue = faInvalid;
	
	_atValue = atGet(csFilePath);
	xCHECK_RET(_atValue & atValue, TRUE);

	return FALSE;
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXFileAttribute (comment)
CXFileAttribute::CXFileAttribute() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXFileAttribute (comment)
CXFileAttribute::~CXFileAttribute() {
	//code
}
//---------------------------------------------------------------------------