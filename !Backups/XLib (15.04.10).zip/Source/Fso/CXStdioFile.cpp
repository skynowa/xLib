/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Fso/CXStdioFile.h>

#include <XLib/Fso/CXPath.h>
#include <XLib/CXLocale.h>


/****************************************************************************
*	public: ������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXStdioFile (����������)
CXStdioFile::CXStdioFile() :
	_m_pFile    (NULL),
	_m_sFilePath(),
	_m_bRes     (FALSE)
{
	////BOOL bRes = FALSE;
	////
	////bRes = CXLocale::bSetDefault();
	////xASSERT_DO(FALSE != bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXStdioFile (����������)
CXStdioFile::~CXStdioFile() { 
	xCHECK_DO(NULL == _m_pFile, return);

	_m_bRes = bClose();
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);	
}
//---------------------------------------------------------------------------
//TODO: + operator FILE* ()
CXStdioFile::operator FILE * () {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, NULL);     
	
	return _m_pFile;
}
//---------------------------------------------------------------------------
//TODO: + pGet (��������� ���������)
FILE *CXStdioFile::pGet() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, NULL);      

	return _m_pFile;
}
//---------------------------------------------------------------------------
//TODO: + bOpen (��������)
BOOL CXStdioFile::bOpen(const tString &csFilePath, CXOpenMode::TMode omMode) {
	/*DEBUG*/xASSERT_RET(NULL  == _m_pFile,           FALSE);
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/xASSERT_RET(false == omMode.empty(),     FALSE); 
	
	_m_pFile = _tfopen(csFilePath.c_str(), omMode.c_str());
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE); 

	_m_sFilePath = csFilePath; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReopen (Reopen stream with different file or mode)
BOOL CXStdioFile::bReopen(const tString &csFilePath, const tString &csMode) {
	/*DEBUG*/xASSERT_RET(NULL  != _m_pFile,           FALSE);
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*/xASSERT_RET(false == csMode.empty(),     FALSE); 

	_m_pFile = _tfreopen(csFilePath.c_str(), csMode.c_str(), _m_pFile);
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);   

	_m_sFilePath = csFilePath; 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sGetPath (��������� ����)
tString CXStdioFile::sGetPath() {
	/*DEBUG*/xASSERT_RET(false == _m_sFilePath.empty(), tString()); 

	return _m_sFilePath;
}
//---------------------------------------------------------------------------


/****************************************************************************
* public: ������/������ �����
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + uiRead (Read block of data from stream)
std::size_t CXStdioFile::uiRead(LPVOID pvBuff, std::size_t uiCount) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, 0); 
	/*DEBUG*/xASSERT_RET(NULL != pvBuff,   0); 
	
	std::size_t uiRes = 0;

	uiRes = fread(pvBuff, /*sizeof(TCHAR)*/1, uiCount, _m_pFile);          
	/*DEBUG*/xASSERT_RET(uiCount >= uiRes, 0); 
	
	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: - uiWrite (Write block of data to stream)
std::size_t CXStdioFile::uiWrite(const LPVOID pcvBuf, std::size_t uiCount) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, 0);
	/*DEBUG*/xASSERT_RET(NULL != pcvBuf,   0); 

	std::size_t uiRes = 0;

	uiRes = fwrite(pcvBuf,/* sizeof(TCHAR)*/1, uiCount, _m_pFile);
	/*DEBUG*/xASSERT_RET(uiCount == uiRes, 0); 

	return uiRes;
}
//---------------------------------------------------------------------------
//TODO: - bReadAll (������ ���� ���� �������)
BOOL CXStdioFile::bReadAll(LPVOID pvBuff, std::size_t uiBuffSize, std::size_t uiBlockSize) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,    FALSE); 
	/*DEBUG*/xASSERT_RET(NULL != pvBuff,      FALSE); 
	/*DEBUG*/xASSERT_RET(0    != uiBlockSize, FALSE); 

	xASSERT_MSG_RET(FALSE, _T("not implemented"), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bWriteAll (����� ���� ���� �������)
BOOL CXStdioFile::bWriteAll(const LPVOID pcvBuf, std::size_t uiBuffSize, std::size_t uiBlockSize) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,    FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pcvBuf,      FALSE); 
	/*DEBUG*/xASSERT_RET(0    != uiBlockSize, FALSE); 

	xASSERT_MSG_RET(FALSE, _T("not implemented"), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReadAll (������ ���� ���� �������)
BOOL CXStdioFile::bReadAll(uString *psBuff, std::size_t uiBlockSize) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,    FALSE); 
	/*DEBUG*/xASSERT_RET(NULL != psBuff,      FALSE); 
	/*DEBUG*/xASSERT_RET(0    <  uiBlockSize, FALSE); 

	std::size_t uiRes = 0;
	LONG   liFileSize = 0;
		
	liFileSize = liGetSize(); 
	/*DEBUG*/xASSERT_RET(ppError != liFileSize, FALSE);
	
	(*psBuff).clear();
	(*psBuff).resize(liFileSize);
	
	for (LONG i = 0; i < liFileSize; i += uiBlockSize) {	
		uiRes = fread(&(*psBuff).at(0) + i, sizeof(UCHAR)/*1*/, uiBlockSize, _m_pFile);
		/*DEBUG*/xASSERT_RET(uiBlockSize >= uiRes, FALSE); 
    }

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteAll (����� ���� ���� �������)
BOOL CXStdioFile::bWriteAll(const uString &csBuff, std::size_t uiBlockSize) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,    FALSE); 
	/*DEBUG*///csBuff - n/a
	/*DEBUG*/xASSERT_RET(0    <  uiBlockSize, FALSE); 

	std::size_t uiRes = 0;

	for (std::size_t i = 0; i < csBuff.size(); i += uiBlockSize) {
		//������� ������
		if (uiBlockSize > (csBuff.size() - i)) {
			uiBlockSize = csBuff.size() - i;
		}

		uiRes = fwrite(&csBuff.at(0) + i, sizeof(UCHAR)/*1*/, uiBlockSize, _m_pFile);
		/*DEBUG*/xASSERT_RET(uiBlockSize == uiRes, FALSE); 
    }

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReadLine (Reads data from the file to pszStr till '\n' is encountered)
BOOL CXStdioFile::bReadLine(LPTSTR pszStr, std::size_t uiMaxCount) {		//TODO: overflow
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pszStr,   FALSE); 

	LPTSTR pszRes = NULL;
	
	pszRes = _fgetts/*fgets*/(pszStr, uiMaxCount, _m_pFile);
	/*DEBUG*/xASSERT_RET(NULL != pszRes, FALSE); 

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteLine (Writes csStr and then writes '\n' to the file)
BOOL CXStdioFile::bWriteLine(const tString &csStr) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);

	std::size_t uiSize = csStr.size() + xEOL.size();
	std::size_t uiRes  = uiWrite(static_cast<LPVOID>(&(csStr + xEOL).at(0)), uiSize);
	xCHECK_RET(uiRes < uiSize, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteChar (Write character to stream)
BOOL CXStdioFile::bWriteChar(TCHAR cChar) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _fputtc(static_cast<INT>(cChar), _m_pFile);
	/*DEBUG*/xASSERT_RET(static_cast<INT>(cChar) != etError, FALSE);
	/*DEBUG*/xASSERT_RET(static_cast<INT>(cChar) == iRes,    FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + cGetChar (Get character from stream)
TCHAR CXStdioFile::cReadChar() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _gettc/*getc*/(_m_pFile);
	/*DEBUG*///not need xASSERT_RET(iRes != etError, (TCHAR)etError);
	/*DEBUG*///not need xASSERT_RET(EOF < iRes,      (TCHAR)etError);

	return static_cast<TCHAR>(iRes); 
} 
//---------------------------------------------------------------------------
//TODO: + bUngetChar (Unget character from stream)
BOOL CXStdioFile::bUngetChar(TCHAR cChar) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _ungettc/*ungetc*/(cChar, _m_pFile);
	/*DEBUG*/xASSERT_RET(iRes  != etError,                  FALSE);
	/*DEBUG*/xASSERT_RET(cChar == static_cast<TCHAR>(iRes), FALSE);	

	return TRUE; 
}
//---------------------------------------------------------------------------
//TODO: + bWriteString (Write string to stream)
BOOL CXStdioFile::bWriteString(const tString &csStr) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);

	INT iRes = etError;

	iRes = _fputts/*fputs*/(csStr.c_str(), _m_pFile); 
	/*DEBUG*/xASSERT_RET(iRes != etError, FALSE);
	/*DEBUG*/xASSERT_RET(EOF < iRes,      FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bReadFile (���� � std::vector)
/*static*/
BOOL CXStdioFile::bReadFile(const tString &csFilePath, std::vector<tString> *pvecsVector) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pvecsVector,        FALSE);
		
	BOOL bRes = FALSE;
	INT  iRes = etError;

	CXStdioFile stdFile;

	bRes = stdFile.bOpen(csFilePath.c_str(), _T("rb"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	tString sLine;

	for (;;) {
		bRes = stdFile.bIsEof();
		if (TRUE == bRes) {
			break;
		}

		iRes = static_cast<INT>(stdFile.cReadChar());      
		if (etError == iRes) {
			//�������� ��������� ������ (� ��� ��� EOL)
			pvecsVector->push_back(sLine);	
			sLine.clear();

			break;
		}

		sLine += static_cast<TCHAR>(iRes);
		if (xLF.at(0)/*'\n'*/ == static_cast<TCHAR>(iRes)) {
			pvecsVector->push_back(CXString::sRemoveEOL(sLine));	
			sLine.clear();		
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteFile (std::vector � ����)
/*static*/
BOOL CXStdioFile::bWriteFile(const tString &csFilePath, const std::vector<tString> *pcvecsVector) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pcvecsVector,       FALSE);
	
	BOOL bRes = FALSE;
	INT  iRes = etError;
	
	CXStdioFile stdFile;

	bRes = stdFile.bOpen(csFilePath.c_str(), _T("wb"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
		
	std::vector<tString>::const_iterator it;
	for (it = pcvecsVector->begin(); it < pcvecsVector->end(); it ++) {		
		std::size_t uiRes   = 0;
		tString     sLine   = *it + xEOL;
		std::size_t uiCount = sLine.size();

		uiRes = stdFile.uiWrite(static_cast<LPVOID>(&sLine.at(0)), uiCount);
		if (uiCount != uiRes) {   
			return FALSE;
		}
	}

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ...
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - bSetVBuff (Change stream buffering)
BOOL CXStdioFile::bSetVBuff(LPTSTR pszBuff, EBufferingMode bmMode, std::size_t uiSize) {
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile,               FALSE);
    /*DEBUG*/xASSERT_RET(NULL != pszBuff,                FALSE);
    /*DEBUG*/xASSERT_RET(2 < uiSize && uiSize < INT_MAX, FALSE);
    
    INT iRes = etError;
    
	////iRes = setvbuf(_m_pFile, pszBuff, bmMode, uiSize);
	/////*DEBUG*/xASSERT_RET(0 == iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetMode (Sets the file translation mode)
BOOL CXStdioFile::bSetMode(ETranslationMode tmMode) {    
	INT iRes = etError;

	iRes = /*BC++_setmode*/setmode(_iGetHandle(), tmMode);
	/*DEBUG*/xASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bSetPosition (REFilePosition stream position indicator)
BOOL CXStdioFile::bSetPosition(LONG lOffset, EPointerPosition fpPos/* = fpBegin*/) {
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
    
	INT iRet = ppError;

	iRet = fseek(_m_pFile, lOffset, fpPos);
	/*DEBUG*/xASSERT_RET(0 == iRet, FALSE); 
	
	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + liGetPosition (Get current position in stream)
LONG CXStdioFile::liGetPosition() {
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
    
	LONG liRes = ppError;

	liRes = ftell(_m_pFile);
	/*DEBUG*/xASSERT_RET(ppError != liRes, ppError); 
		
	return liRes;
}
//---------------------------------------------------------------------------
//TODO: + liGetSize (������ �����)
LONG CXStdioFile::liGetSize() {
	LONG liStreamSize    = ppError;
	LONG liCurrStreamPos = ppError;
	
	//Get current position
	liCurrStreamPos = liGetPosition();
	
	//seek to the end of file
	if (FALSE == bSetPosition(0, ppEnd)) {
		return ppError; 
	}
	
	liStreamSize = liGetPosition();
	
	//Get back to the stored position
	if (FALSE == bSetPosition(liCurrStreamPos, ppBegin)) {
		return ppError;
	}

	return liStreamSize;
}
//---------------------------------------------------------------------------
//TODO: + bChsize(Changes the file size)
BOOL CXStdioFile::bChsize(LONG liSize) {
	/*DEBUG*///not need 

	INT iRes = etError;

	iRes = /*BC++ _chsize*/chsize(_iGetHandle(), liSize); 
	/*DEBUG*/xASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: + bLocking (Locks or unlocks bytes of a file)
BOOL CXStdioFile::bLocking(ELockingMode lmMode, LONG liBytes) {
	INT iRes = etError;

//	iRes = _locking(_iGetHandle(), lmMode, liBytes);           CG2010
//	/*DEBUG*/xASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//TODO: + bFlush (Flush stream)
BOOL CXStdioFile::bFlush() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	

	iRes = fflush(_m_pFile);
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bClose (Close file)
BOOL CXStdioFile::bClose() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);  

	INT iRes = etError;	

	iRes = fclose(_m_pFile);
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);

	_m_pFile = NULL;

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	��������
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bIsExists (�������� ������������� �����)
/*static*/
BOOL CXStdioFile::bIsExists(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE); 
	
	INT iRes = etError;

	iRes = _taccess(csFilePath.c_str(), amExistence); 
	ULONG ulLasError = ::GetLastError();
	xCHECK_RET((etError == iRes) && (2 == ulLasError || 3 == ulLasError), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bAccess (Determine file-access permission)
/*static*/
BOOL CXStdioFile::bAccess(const tString &csFilePath, EAccessMode amMode) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _taccess(csFilePath.c_str(), amMode); 
	/*DEBUG*/xASSERT_RET(iRes != etError, FALSE);

	return TRUE;	
}
//---------------------------------------------------------------------------
//TODO: + bChmod (Change the file-permission settings)
/*static*/
BOOL CXStdioFile::bChmod(const tString &csFilePath, EPermissionMode pmMode) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE); 
	/*DEBUG*///iMode

	INT iRes = etError;

	iRes = _tchmod(csFilePath.c_str(), pmMode);   
	/*DEBUG*/xASSERT_RET(iRes != etError, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------		
//TODO: + bRemove (Remove file)
/*static*/
BOOL CXStdioFile::bRemove(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);  
	
	INT iRes = etError;

	iRes = bChmod(csFilePath.c_str(), pmWrite);
	/*DEBUG*/xASSERT_RET(FALSE != iRes, FALSE);  

	iRes = _tremove(csFilePath.c_str());
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUnlink (Delete a file)
/*static*/
BOOL CXStdioFile::bUnlink(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	
	INT iRes = etError;

	iRes = _tunlink(csFilePath.c_str());
	/*DEBUG*/xASSERT_RET(etError != iRes, FALSE);

	return FALSE; 
}
//---------------------------------------------------------------------------
//TODO: + bRename (Rename file) 
/*static*/
BOOL CXStdioFile::bRename(const tString &csOldFilePath, const tString &csNewFilePath) {
	/*DEBUG*/xASSERT_RET(false == csOldFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csNewFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = _trename(csOldFilePath.c_str(), csNewFilePath.c_str());
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);  

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bCopy (�������� ����)
//TODO: - FilePath -> DirPath
/*static*/
BOOL CXStdioFile::bCopy(const tString &csFromFilePath, const tString &csToFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFromFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csToFilePath.empty(),   FALSE); 

	BOOL        bRes     = FALSE;	
	std::size_t uiReaded = 0;
	std::size_t uiWrited = 0;
	tString     sBuff;
	
	CXStdioFile stdfFile;

	//-------------------------------------
	//������
	bRes = stdfFile.bOpen(csFromFilePath.c_str(), _T("rb"));
	xCHECK_RET(FALSE == bRes, FALSE);

	sBuff.resize(stdfFile.liGetSize());

	uiReaded = stdfFile.uiRead(&sBuff.at(0), sBuff.size());
	xCHECK_RET(sBuff.size() != uiReaded, FALSE);

	bRes = stdfFile.bClose();
	xCHECK_RET(FALSE == bRes, FALSE);

	//-------------------------------------
	//�����
	bRes = stdfFile.bOpen(csToFilePath.c_str(), _T("wb"));
	xCHECK_RET(FALSE == bRes, FALSE);

	uiWrited = stdfFile.uiWrite(&sBuff[0], sBuff.size());
	if (sBuff.size() != uiWrited) {
		//���� �� �������� ���� - �������
		stdfFile.bClose();
		CXStdioFile::bRemove(csToFilePath);
		
		return FALSE;
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bMove (����������� ����� � �����) 
/*static*/
BOOL CXStdioFile::bMove(const tString &csFilePath, const tString &csDirPath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csDirPath.empty(),  FALSE);

	BOOL bRes = FALSE;
	INT  iRes = etError;

	tString sFileName = CXPath::sGetFullName(csFilePath);

	bRes = bRename(csFilePath, csDirPath + _T("\\") + sFileName);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bExec (��������� ����)
/*static*/
BOOL CXStdioFile::bExec(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);

	INT iRes = etError;

	iRes = _tsystem(csFilePath.c_str());
	/*DEBUG*/xASSERT_RET(etError != iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sCreateTempFileName (Generate temporary filename (������ ����� ����� [\s150.]))
/*static*/
tString CXStdioFile::sCreateTempFileName() {
	TCHAR  szBuff[L_tmpnam] = {0};
	TCHAR *pszRes           = NULL;

	pszRes = _ttmpnam(szBuff);
	/*DEBUG*/xASSERT_RET(NULL != pszRes, tString()); 

	return tString(szBuff);  
}
//---------------------------------------------------------------------------
//TODO: + bFlushAllOutput (Flushes all streams opened for output)
/*static*/
BOOL CXStdioFile::bFlushAllOutput() {
	INT iRes = etError;	

	iRes = fflush(NULL);
	/*DEBUG*/xASSERT_RET(0 == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + iFlushAll (returns the number of open streams (input and output))
/*static*/
INT CXStdioFile::iFlushAll() {
	INT iRes = etError;	

	iRes = _flushall();
	/*DEBUG*///not need

	return iRes;
}
//--------------------------------------------------------------------------
//TODO: - ulLines (���-�� ����� � �����)
/*static*/
ULONG CXStdioFile::ulLines(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(),    0);
	/*DEBUG*/xASSERT_RET(TRUE  == bIsExists(csFilePath), 0);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	xASSERT_RET(FALSE != bRes, FALSE);
	
	ULONG ulLines = 0;   //������� �����

	tifstream ifsStream(csFilePath.c_str(), std::ios::in);
	if (!ifsStream || ifsStream.fail() || !ifsStream.good() || !ifsStream.is_open() || ifsStream.eof()) {
		return 0;
	}

	TCHAR cChar = _T('\0');
	while (ifsStream.get(cChar)) {
		if (_T('\n') == cChar) {
			ulLines ++;
		}
	} 
	ulLines ++;
	ifsStream.close();

	return ulLines;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: character input/output
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + cGetCharFromStdin (Get character from stdin)
TCHAR CXStdioFile::cGetCharFromStdin() {
	INT iRes = etError;
	
	iRes = _gettchar();
	/*DEBUG*/xASSERT_RET(etError != iRes, static_cast<TCHAR>(etError));
	
	return (TCHAR)iRes;
}
//---------------------------------------------------------------------------
//TODO: + sGetStringFromStdin (Get string from stdin)
tString CXStdioFile::sGetStringFromStdin(LPTSTR pszBuff) {
	LPTSTR pszRes = NULL;

	pszRes = _getts(pszBuff);
	/*DEBUG*/xASSERT_RET(NULL != pszRes, tString());

	return tString(pszRes);
}
//---------------------------------------------------------------------------
//TODO: + bWriteCharToStdout (Write character to stdout)
BOOL CXStdioFile::bWriteCharToStdout(TCHAR cChar) {
	INT iRes = etError;

	iRes = _puttchar(static_cast<INT>(cChar));
	/*DEBUG*/xASSERT_RET(etError                 != iRes, FALSE);
	/*DEBUG*/xASSERT_RET(static_cast<INT>(cChar) == iRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bWriteStringToStdout (Write string to stdout)
BOOL CXStdioFile::bWriteStringToStdout(const tString &csStr) {
	INT iRes = etError;
	
	iRes = _putts/*puts*/(csStr.c_str());
	/*DEBUG*/xASSERT_RET(etError < iRes, FALSE);
	
	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: Formatted input/output 
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + iFprintf(Write formatted output to stream)
INT CXStdioFile::iFprintf(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,   etError); 
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);
	
    iRes = _vftprintf/*vfprintf*/(_m_pFile, pcszFormat, args);
    /*DEBUG*/xASSERT_RET(etError < iRes, etError);
    
    va_end(args);
    
    return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iPrintf (Print formatted data to stdout)
INT CXStdioFile::iPrintf(LPCTSTR pcszFormat, ...) {
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = _vtprintf/*vprintf*/(pcszFormat, args);
	/*DEBUG*/////////////////////////////////////xASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iSprintf(Write formatted data to string)
INT CXStdioFile::iSprintf(LPTSTR pszStr, LPCTSTR pcszFormat, ...) {
	/*DEBUG*/xASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	
	INT iRes = etError;
	
	va_list args = NULL;
	va_start(args, pcszFormat);

	iRes = _vstprintf/*vsprintf*/(pszStr, pcszFormat, args);
	/*DEBUG*/xASSERT_RET(etError < iRes, etError);
	
	va_end(args);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iFprintfV (Write formatted variable argument list to stream)
INT CXStdioFile::iFprintfV(LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile,   etError); 
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/xASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vftprintf/*vfprintf*/(_m_pFile, pcszFormat, arg);
	/*DEBUG*/xASSERT_RET(etError < iRes, etError);
	
	return iRes;
}
//---------------------------------------------------------------------------
//TODO: + iPrintfV (Print formatted variable argument list to stdout)
INT CXStdioFile::iPrintfV(LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/xASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vtprintf/*vprintf*/(pcszFormat, arg);
	/*DEBUG*/xASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------
//TODO: iSprintfV (Print formatted variable argument list to string)
INT CXStdioFile::iSprintfV(LPTSTR pszStr, LPCTSTR pcszFormat, va_list arg) {
	/*DEBUG*/xASSERT_RET(NULL != pszStr,     etError); 
	/*DEBUG*/xASSERT_RET(NULL != pcszFormat, etError); 
	/*DEBUG*/xASSERT_RET(NULL != arg,        etError); 
	
	INT iRes = etError;

	iRes = _vstprintf/*vsprintf*/(pszStr, pcszFormat, arg);
	/*DEBUG*/xASSERT_RET(etError < iRes, etError);

	return iRes;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: Error-handling:
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + bClearErr (Clear error indicators)
BOOL CXStdioFile::bClearErr() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
    
    clearerr(_m_pFile);
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bIsEof (Check End-of-File indicator)
BOOL CXStdioFile::bIsEof() {
	/*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
 
	INT iRes = feof(_m_pFile);
	/*DEBUG*///not need

    return static_cast<BOOL>(iRes);
	/*DEBUG*///not need
}
//---------------------------------------------------------------------------
//TODO: + bIsError (Check error indicator)
BOOL CXStdioFile::bIsError() {
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile, FALSE);
    
    BOOL bRes = FALSE;
    
    bRes = static_cast<BOOL>(ferror(_m_pFile));
    /*DEBUG*///not need
    
    return TRUE;
}		
//---------------------------------------------------------------------------
//TODO: + bPrintError (Print error message)
BOOL CXStdioFile::bPrintError(const tString &csStr) {
    _tperror(csStr.c_str());
    /*DEBUG*///not need
    
    return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	public: ������ / ������ �����
*
*****************************************************************************/

//--------------------------------------------------------------------------
//TODO: - vecsReadFile (DEPR)
/*static*/
std::vector<tString> CXStdioFile::vecsReadFile(const tString &csFilePath) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(),    std::vector<tString>());
	/*DEBUG*/xASSERT_RET(TRUE  == bIsExists(csFilePath), std::vector<tString>());

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	xASSERT_RET(FALSE != bRes, std::vector<tString>());

	std::vector<tString> vecRes;
	tString              sStr;
	tifstream            ifsStream(csFilePath.c_str());
	/*DEBUG*/xASSERT_RET(ifsStream,           std::vector<tString>());
	/*DEBUG*/xASSERT_RET(!ifsStream.fail(),   std::vector<tString>());
	/*DEBUG*/xASSERT_RET(ifsStream.good(),    std::vector<tString>());
	/*DEBUG*/xASSERT_RET(ifsStream.is_open(), std::vector<tString>());
	/*DEBUG*/xASSERT_RET(!ifsStream.eof(),    std::vector<tString>());	

	////CXPerform   P("__TEST.test", CXPerform::pmGetTickCount);
	/*SPEED*/////P.bStart();

	for (INT i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);
		vecRes.push_back(sStr);
	}

	/*SPEED*/////P.bStop("CXStdioFile::vecsReadFile ---> ");

	return vecRes;
}
//--------------------------------------------------------------------------
//TODO: - bReadFile
/*static*/
BOOL CXStdioFile::bReadFile(const tString &csFilePath, std::vector<TCHAR> *pvecchVector) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(),    FALSE);
	/*DEBUG*/xASSERT_RET(TRUE  == bIsExists(csFilePath), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pvecchVector,          FALSE);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	xASSERT_RET(FALSE != bRes, FALSE);

	tifstream ifsStream(csFilePath.c_str(), std::ios::in | std::ios::binary);
	/*DEBUG*/xASSERT_RET(ifsStream,           FALSE);
	/*DEBUG*/xASSERT_RET(!ifsStream.fail(),   FALSE);
	/*DEBUG*/xASSERT_RET(ifsStream.good(),    FALSE);
	/*DEBUG*/xASSERT_RET(ifsStream.is_open(), FALSE);
	/*DEBUG*/xASSERT_RET(!ifsStream.eof(),    FALSE);

	/*std::size_t*/std::size_t uiSize = 0;

	if (ifsStream.seekg(0, std::ios::end)) {
		uiSize = static_cast<std::size_t>(ifsStream.tellg());	//FIX_ME: ����
	}

	if (uiSize && ifsStream.seekg(0, std::ios::beg)) {
		(*pvecchVector).resize(uiSize);
		ifsStream.read(&((*pvecchVector))[0], uiSize);
	}

	return TRUE;
}
//--------------------------------------------------------------------------
//TODO: - mapReadFile (���������� ����� Name1=Value1\r\r\nName2=Value2\r\n...)
/*static*/
std::map<tString, tString> CXStdioFile::mapReadFile(const tString &csFilePath, const tString &csDelimiter) {
	/*DEBUG*//*TODO: BC++*///xASSERT_RET(false == csFilePath.empty(),               (std::map<tString, tString>()));
	/*DEBUG*//*TODO: BC++*///xASSERT_RET(TRUE  == bAccess(csFilePath, amExistence), (std::map<tString, tString>()));
	
	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	//////////////////////////xASSERT_RET(FALSE != bRes, (std::map<tString, tString>()));
	
	std::map<tString, tString> mapLines;
	tString                    sStr;
	tifstream                  ifsStream(csFilePath.c_str());
	/*DEBUG*//*BC++*///xASSERT_RET(ifsStream,           (std::map<tString, tString>()));
	/*DEBUG*//*BC++*///xASSERT_RET(!ifsStream.fail(),   (std::map<tString, tString>()));
	/*DEBUG*//*BC++*///xASSERT_RET(ifsStream.good(),    (std::map<tString, tString>()));
	/*DEBUG*//*BC++*///xASSERT_RET(ifsStream.is_open(), (std::map<tString, tString>()));
	/*DEBUG*//*BC++*///xASSERT_RET(!ifsStream.eof(),    (std::map<tString, tString>()));

	////setlocale(LC_ALL, "Russian");
	
	for (int i = 0; !ifsStream.eof();  ++ i) {
		std::getline(ifsStream, sStr);

		std::vector<tString> vecsLine;
		
		bRes = CXString::bSplit(sStr, csDelimiter, &vecsLine);
		/*DEBUG*///TODO:

		mapLines[vecsLine.at(0)] = vecsLine.at(1);
	}

	return mapLines;
}
//--------------------------------------------------------------------------
//TODO: - bReadFile (Writes csStr and then writes '\n' to the file)
/*static*/
BOOL CXStdioFile::bReadFile(const tString &csFilePath, tString &cStr) {
	/*DEBUG*/xASSERT_RET(false == csFilePath.empty(), FALSE);

	//-------------------------------------
	//������������� ��������� ������
	BOOL bRes = CXLocale::bSetDefault();
	xASSERT_RET(FALSE != bRes, FALSE);
	
	tifstream  ifsStream(csFilePath.c_str());
	/*DEBUG*/xASSERT_RET(ifsStream,           FALSE);
	/*DEBUG*/xASSERT_RET(!ifsStream.fail(),   FALSE);
	/*DEBUG*/xASSERT_RET(ifsStream.good(),    FALSE);
	/*DEBUG*/xASSERT_RET(ifsStream.is_open(), FALSE);
	/*DEBUG*/xASSERT_RET(!ifsStream.eof(),    FALSE);

	tString sTemp;
	
	cStr.clear();
	for (; !ifsStream.eof(); ) {
		std::getline(ifsStream, sTemp);
		cStr.append(sTemp);
		cStr.append(xEOL);
	}

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	private methods
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + _iGetHandle (Gets the file descriptor associated with a stream)
INT CXStdioFile::_iGetHandle() {
    /*DEBUG*/xASSERT_RET(NULL != _m_pFile, etError);
    
    INT iRes = etError;
    
	iRes = _fileno(_m_pFile);
	/*DEBUG*/xASSERT_RET(etError != iRes, etError);
	
	return iRes; 
}
//---------------------------------------------------------------------------




/*
ofstream fout;
fout.open("D:\\vec.txt");
copy(vec.begin(), vec.end(), ostream_iterator<int>(fout," "));
fout.close();
*/