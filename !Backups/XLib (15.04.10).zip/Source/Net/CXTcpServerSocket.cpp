/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.cpp
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/    
    
    
#include <XLib/Net/CXTcpServerSocket.h> 

#include <stdio.h>   
#include <iostream> 
#include <XLib/CXString.h>   
//---------------------------------------------------------------------------  
//TODO: + CXTcpServerSocket
CXTcpServerSocket::CXTcpServerSocket() {   
	////bSetTimeout(0, COptions::SOCKET_TIMEOUT);
} 
//---------------------------------------------------------------------------  
//TODO: + CXTcpServerSocket 
CXTcpServerSocket::CXTcpServerSocket(SOCKET puiSocket) {   
	_m_puiSocket = puiSocket;   
}   
//---------------------------------------------------------------------------  
//TODO: + ~CXTcpServerSocket 
 CXTcpServerSocket::~CXTcpServerSocket() {
 
 }   
//---------------------------------------------------------------------------
//TODO: - bBind (associates a local address with a socket.) 
BOOL CXTcpServerSocket::bBind(USHORT usPort) {   
    /*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket,   FALSE);
    /*DEBUG*/xASSERT_RET((32767 > usPort) && (0 < usPort), FALSE);	

	INT iRes = SOCKET_ERROR;

	struct sockaddr_in saSockAddr = {0};	     
	saSockAddr.sin_family      = AF_INET;   
	saSockAddr.sin_addr.s_addr = INADDR_ANY;   
	saSockAddr.sin_port        = htons(usPort);   
    
	iRes = ::bind(_m_puiSocket, (const struct sockaddr *)&saSockAddr, sizeof(saSockAddr)); 
    /*DEBUG*/xASSERT_RET(SOCKET_ERROR != iRes, FALSE);  

	////INT iOpt = 1;  
	//???
	////if (::setsockopt(_m_puiSocket, SOL_SOCKET, SO_REUSEADDR, (LPSTR)&iOpt, sizeof(iOpt)) < 0) {   
	////    return FALSE;   
	////}

    return TRUE;   
}   
//--------------------------------------------------------------------------- 
//TODO: - bListen (places a socket in a state in which it is listening for an incoming connection) 
BOOL CXTcpServerSocket::bListen(INT iBacklog /*= SOMAXCONN*/) { 
	/*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket, FALSE);

	INT iRes = SOCKET_ERROR;

	iRes = ::listen(_m_puiSocket, iBacklog); 
    /*DEBUG*/xASSERT_RET(SOCKET_ERROR != iRes, FALSE);

    return TRUE;   
}   
//---------------------------------------------------------------------------  
//TODO: - bAccept (permits an incoming connection attempt on a socket)
BOOL CXTcpServerSocket::bAccept(CXTcpServerSocket &s, std::string *psFromIp) { 
	/*DEBUG*/xASSERT_RET(INVALID_SOCKET != _m_puiSocket,      FALSE);
	/*DEBUG*/xASSERT_RET(NULL           != psFromIp,          FALSE);

	SOCKET scktClient = INVALID_SOCKET;
	
	struct sockaddr_in cliaddr  = {0};   
    INT                iAddrlen = sizeof(cliaddr);

	scktClient = ::accept(_m_puiSocket, (struct sockaddr *)&cliaddr, &iAddrlen); 
    /*DEBUG*/xASSERT_RET(INVALID_SOCKET != scktClient, FALSE);      
    
    s = scktClient;  

	(*psFromIp).resize(std::string(inet_ntoa(cliaddr.sin_addr)).size());
	
	/*if (NULL != pszFromIp) {  
	    ::wsprintf(pszFromIp, "%s", );   
	}*/

	(*psFromIp) = inet_ntoa(cliaddr.sin_addr);
    
    return TRUE;   
}   
//---------------------------------------------------------------------------  
