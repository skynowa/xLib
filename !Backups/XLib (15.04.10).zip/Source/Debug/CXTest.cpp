/****************************************************************************
* Class name:  CXTest
* Description: ������������
* File name:   CXTest.cpp
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 9:29:52
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/Debug/CXTest.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: + CXTest (�����������)
CXTest::CXTest() :
	_m_bRes  (FALSE),
	m_bRes   (FALSE),
	m_iRes   (- 1),
	m_uiRes  (0),
	m_ulRes  (0),
	m_ullRes (0UL),
	m_dRes   (0.0f),
	m_hRes   (INVALID_HANDLE_VALUE),
	m_hwndRes(NULL),
	m_sRes   (),
	m_vecsRes(),
	m_mapsRes()
{
	_m_bRes = bSetWorkDir();
	/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);
}
//---------------------------------------------------------------------------
//TODO: + ~CXTest (����������)
CXTest::~CXTest() {
	//code
}
//---------------------------------------------------------------------------
//TODO: + bRun (������)
BOOL CXTest::bRun(ULONG ulLoops) {
	/*DEBUG*/

	try	{
		if (0 == ulLoops) {
			//����������
			for ( ;  ; ) {
				_m_bRes = bUnit();
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
			}
		} else {
			//������� ���-�� ������
			for (ULONG i = 0; i < ulLoops; ++ i) {
				_m_bRes = bUnit();
				/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
			}	
		}
	} catch (...) {
		/*DEBUG*/xASSERT_MSG_RET(FALSE, _T("����������� ������ �����"), FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + bUnit (������ ���� ��������������)
/*virtual*/
BOOL CXTest::bUnit() /*= 0*/  {
	/*DEBUG*/
	
	BOOL bRes = FALSE;
	
	/*��� ������������*/

	//////-------------------------------------
	//////[FUNCTION_NAME]
	////{
	////	tString sTestData[][2] = {
	////		{_T("TEST_STRING_1"),		 _T("MUST_BE_1")},
	////		{_T("TEST_STRING_2"),		 _T("MUST_BE_2")},
	////		{_T("TEST_STRING_3"),		 _T("MUST_BE_3")},
	////		{_T("TEST_STRING_4"),		 _T("MUST_BE_4")}
	////	};

	////	for (std::size_t i = 0; i < xARRAY_SIZE(sTestData); ++ i) {
	////		////tString sStr1 = [FUNCTION_NAME](sTestData[i][0]);
	////		////tString sStr2 = [FUNCTION_NAME](sTestData[i][1]);
	////		////xASSERT(sStr1 == sStr2);

	////		////tString sStr3 = [FUNCTION_NAME](sTestData[i][0]);
	////		////tString sStr4 = sTestData[i][1];
	////		////xASSERT(sStr3 == sStr4);
	////	}
	////}

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: + sGetWorkDir ()
tString CXTest::sGetWorkDir() {
	/*DEBUG*/xASSERT(false == _m_sWorkDir.empty());

	return _m_sWorkDir;
}
//---------------------------------------------------------------------------
//TODO: + bSetWorkDir ()
BOOL CXTest::bSetWorkDir(const tString &csDirPath) {
	/*DEBUG*/

	if (true == csDirPath.empty()) {
		_m_sWorkDir = CXEnvironment::sGetVar(_T("temp"));
	} else {
		_m_sWorkDir = csDirPath;		
	}

	return TRUE; 
}
//---------------------------------------------------------------------------