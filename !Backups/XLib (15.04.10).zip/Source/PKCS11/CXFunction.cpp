/****************************************************************************
* Class name:  CXFunction
* Description: PKCS11 �������
* File name:   CXFunction.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:14:45
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXFunction.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXFunction ()
CXFunction::CXFunction(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXFunction ()
CXFunction::~CXFunction() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bGetList (returns the function list)
BOOL CXFunction::bGetList(
	CK_FUNCTION_LIST_PTR_PTR ppFunctionList  /* receives pointer to function list */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetFunctionList(ppFunctionList );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetStatus (is a legacy function; it obtains an updated status of a function running in parallel with an application)
BOOL CXFunction::bGetStatus() {
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GetFunctionStatus(_m_hSession );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bCancel (is a legacy function; it cancels a function running in parallel)
BOOL CXFunction::bCancel() {
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_CancelFunction(_m_hSession);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bGetListEx (� SDK 4.53 ���� ������� ���)
BOOL CXFunction::bGetListEx() {
	/*DEBUG*/

	////_m_ulRes = _m_pFunc->ETC_GetFunctionListEx();
	/////*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------





/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
