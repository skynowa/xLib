/****************************************************************************
* Class name:  CXEncrypt
* Description: PKCS11 ����������
* File name:   CXEncrypt.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:10:51
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXEncrypt.h>

#include <XLib/PKCS11/CXUtils.h>
#include <XLib/Fso/CXStdioFile.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXEncrypt ()
CXEncrypt::CXEncrypt(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXEncrypt ()
CXEncrypt::~CXEncrypt() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bInit (initializes an encryption operation)
BOOL CXEncrypt::bInit(
	CK_MECHANISM_PTR  pMechanism,  /* the encryption mechanism */
	CK_OBJECT_HANDLE  hKey         /* handle of encryption key */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_EncryptInit(_m_hSession, pMechanism, hKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bMake (encrypts single-part data)
BOOL CXEncrypt::bMake(
	CK_BYTE_PTR       pData,               /* the plaintext data */
	CK_ULONG          ulDataLen,           /* bytes of plaintext */
	CK_BYTE_PTR       pEncryptedData,      /* gets ciphertext */
	CK_ULONG_PTR      pulEncryptedDataLen  /* gets c-text size */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_Encrypt(_m_hSession, pData, ulDataLen, pEncryptedData, pulEncryptedDataLen  );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bUpdate (continues a multiple-part encryption operation)
BOOL CXEncrypt::bUpdate(
	CK_BYTE_PTR       pPart,              /* the plaintext data */
	CK_ULONG          ulPartLen,          /* plaintext data len */
	CK_BYTE_PTR       pEncryptedPart,     /* gets ciphertext */
	CK_ULONG_PTR      pulEncryptedPartLen /* gets c-text size */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_EncryptUpdate(_m_hSession, pPart, ulPartLen, pEncryptedPart, pulEncryptedPartLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bFinal (finishes a multiple-part encryption operation)
BOOL CXEncrypt::bFinal(
	CK_BYTE_PTR       pLastEncryptedPart,      /* last c-text */
	CK_ULONG_PTR      pulLastEncryptedPartLen  /* gets last size */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_EncryptFinal(_m_hSession, pLastEncryptedPart, pulLastEncryptedPartLen );
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bSeedRandom (mixes additional seed material into the token's random number generator)
BOOL CXEncrypt::bSeedRandom(
	CK_BYTE_PTR       pSeed,     /* the seed material */
	CK_ULONG          ulSeedLen  /* length of seed material */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_SeedRandom(_m_hSession, pSeed, ulSeedLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bGenerateRandom (generates random data)
BOOL CXEncrypt::bGenerateRandom(
	CK_BYTE_PTR       RandomData,  /* receives the random data */
	CK_ULONG          ulRandomLen  /* # of bytes to generate */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GenerateRandom(_m_hSession, RandomData, ulRandomLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------

/****************************************************************************
*    Public utils                                                         
*                                                                            
*****************************************************************************/


//---------------------------------------------------------------------------
//TODO: - bMakeFile ()
BOOL CXEncrypt::bMakeFile(const tString &csInFilePath, const tString &csOutFilePath, CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey) {
	/*DEBUG*/xASSERT_RET(false == csInFilePath.empty(),  FALSE);
	/*DEBUG*/xASSERT_RET(false == csOutFilePath.empty(), FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pMechanism,            FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != hKey,                  FALSE);

	//-------------------------------------
	//������ ����� � �����
	uString usPlainData;		//����� ��� ����������
	
	{
		CXStdioFile sfFileRaw;
		
		_m_bRes = sfFileRaw.bOpen(csInFilePath, _T("rb"));
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

		_m_bRes = sfFileRaw.bReadAll(&usPlainData, 1024);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	}	
	
	//-------------------------------------
	//���������� ������
	ULONG ulPadSize  = 128 - 11;  //��� RSA 117-����.����� �����, 128-������������� ����
    ULONG ulOffset   = 0;
    ULONG ulOffset2  = 0;
	ULONG ulResEncryptSize = 0;

	////CK_BYTE  usEncryptedData[128]  = {0}; 
	const ULONG          g_culBuffSize    = 8192 * 4;  //FIX_ME:
	uString  usEncryptedData;	usEncryptedData.resize(g_culBuffSize);     
	CK_ULONG usEncryptedDataSize = g_culBuffSize;
		
	{
		size_t uiDataSize = usPlainData.size();
		for (ulOffset = 0; ulOffset < uiDataSize; ulOffset += ulPadSize) {
			//������� ������
			if (ulPadSize > (uiDataSize - ulOffset)) {
				ulPadSize = uiDataSize - ulOffset;
			}

			_m_bRes = bInit(pMechanism, hKey);
			xCHECK_RET(FALSE == _m_bRes, FALSE);

			_m_bRes = bMake(&usPlainData[0] + ulOffset, ulPadSize, &usEncryptedData[0] + ulOffset2, &usEncryptedDataSize);
			xCHECK_RET(FALSE == _m_bRes, FALSE);
			
			ulOffset2 += usEncryptedDataSize;
		}
		ulResEncryptSize = ulOffset2;
	}
	usEncryptedData.resize(ulResEncryptSize);
	
	
	//-------------------------------------
	//������ ����-������ � ����
	{
		CXStdioFile sfFileEncrypt;

		_m_bRes = sfFileEncrypt.bOpen(csOutFilePath, _T("wb"));
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

		_m_bRes = sfFileEncrypt.bWriteAll(usEncryptedData, 1024);
		/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------

		
		
		

/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
