/****************************************************************************
* Class name:  CXKey
* Description: PKCS11 ���� ����������
* File name:   CXKey.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:10:29
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXKey.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXKey ()
CXKey::CXKey(const CXPKCS11 &cPKCS11, const CXSession &cSession) :
	_m_bRes    (FALSE),
	_m_ulRes   (!CKR_OK),
	_m_pFunc   (cPKCS11.pGetFuncList()),
	_m_hSession(cSession.hGetHandle())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXKey ()
CXKey::~CXKey() {
	//code
}
//---------------------------------------------------------------------------
//TODO: - bGenerate (generates a secret key, creating a new key object)
BOOL CXKey::bGenerate(
	CK_MECHANISM_PTR     pMechanism,  /* key generation mech. */
	CK_ATTRIBUTE_PTR     pTemplate,   /* template for new key */
	CK_ULONG             ulCount,     /* # of attrs in template */
	CK_OBJECT_HANDLE_PTR phKey        /* gets handle of new key */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GenerateKey(_m_hSession, pMechanism, pTemplate, ulCount, phKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}  
//---------------------------------------------------------------------------
//TODO: - bGeneratePair (generates a public-key/private-key pair, creating new key objects)      
BOOL CXKey::bGeneratePair(
	CK_MECHANISM_PTR     pMechanism,                  /* key-gen mech. */
	CK_ATTRIBUTE_PTR     pPublicKeyTemplate,          /* template for pub key */
	CK_ULONG             ulPublicKeyAttributeCount,   /* # pub. attrs. */
	CK_ATTRIBUTE_PTR     pPrivateKeyTemplate,         /* template for priv. key */
	CK_ULONG             ulPrivateKeyAttributeCount,  /* # priv. attrs. */
	CK_OBJECT_HANDLE_PTR phPublicKey,                 /* gets pub. key handle */
	CK_OBJECT_HANDLE_PTR phPrivateKey    
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_GenerateKeyPair(_m_hSession, pMechanism, pPublicKeyTemplate, ulPublicKeyAttributeCount, pPrivateKeyTemplate, ulPrivateKeyAttributeCount, phPublicKey, phPrivateKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bDerive (derives a key from a base key, creating a new key object)
BOOL CXKey::bDerive(
	CK_MECHANISM_PTR     pMechanism,        /* key deriv. mech. */
	CK_OBJECT_HANDLE     hBaseKey,          /* base key */
	CK_ATTRIBUTE_PTR     pTemplate,         /* new key template */
	CK_ULONG             ulAttributeCount,  /* template length */
	CK_OBJECT_HANDLE_PTR phKey 
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_DeriveKey(_m_hSession, pMechanism, hBaseKey, pTemplate, ulAttributeCount, phKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
}  
//---------------------------------------------------------------------------
//TODO: - bWrap (wraps (i.e., encrypts) a key)
BOOL CXKey::bWrap(
	CK_MECHANISM_PTR  pMechanism,      /* the wrapping mechanism */
	CK_OBJECT_HANDLE  hWrappingKey,    /* wrapping key */
	CK_OBJECT_HANDLE  hKey,            /* key to be wrapped */
	CK_BYTE_PTR       pWrappedKey,     /* gets wrapped key */
    CK_ULONG_PTR      pulWrappedKeyLen /* gets wrapped key size */
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_WrapKey(_m_hSession, pMechanism, hWrappingKey, hKey, pWrappedKey, pulWrappedKeyLen);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//---------------------------------------------------------------------------
//TODO: - bUnwrap (unwraps (decrypts) a wrapped key, creating a new key object)
BOOL CXKey::bUnwrap(
	CK_MECHANISM_PTR     pMechanism,        /* unwrapping mech. */
	CK_OBJECT_HANDLE     hUnwrappingKey,    /* unwrapping key */
	CK_BYTE_PTR          pWrappedKey,       /* the wrapped key */
	CK_ULONG             ulWrappedKeyLen,   /* wrapped key len */
	CK_ATTRIBUTE_PTR     pTemplate,         /* new key template */
	CK_ULONG             ulAttributeCount,  /* template length */
	CK_OBJECT_HANDLE_PTR phKey 
)
{
	/*DEBUG*/

	_m_ulRes = _m_pFunc->C_UnwrapKey(_m_hSession, pMechanism, hUnwrappingKey, pWrappedKey, ulWrappedKeyLen, pTemplate, ulAttributeCount, phKey);
	/*DEBUG*/xASSERT_MSG_RET(CKR_OK == _m_ulRes, CXUtils::sErrorStr(_m_ulRes).c_str(), FALSE);

	return TRUE;
} 
//--------------------------------------------------------------------------- 


/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
