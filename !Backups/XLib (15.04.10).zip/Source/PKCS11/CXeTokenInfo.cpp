/****************************************************************************
* Class name:  CXeTokenInfo
* Description: ���������� � eToken
* File name:   CXeTokenInfo.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 12:53:01
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/PKCS11/CXeTokenInfo.h>

#include <XLib/PKCS11/CXUtils.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: - CXeTokenInfo ()
CXeTokenInfo::CXeTokenInfo(const CXPKCS11 &cPKCS11) :
	_m_bRes (FALSE),
	_m_ulRes(!CKR_OK),
	_m_pFunc(cPKCS11.pGetFuncList())
{
	//code
}
//---------------------------------------------------------------------------
//TODO: - ~CXeTokenInfo ()
CXeTokenInfo::~CXeTokenInfo() {
	//code
}
//---------------------------------------------------------------------------



/****************************************************************************
*    Private methods                                                         
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
