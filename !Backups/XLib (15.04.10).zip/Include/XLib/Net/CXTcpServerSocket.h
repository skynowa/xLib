/****************************************************************************
* Class name:  CXClientSocket
* Description: 
* File name:   CXClientSocket.h
* String type: Ansi
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef XLib_Net_CXServerSocketH
#define XLib_Net_CXServerSocketH 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <XLib/Common.h>
#include <XLib/Net/CXSocket.h>
//---------------------------------------------------------------------------
class CXTcpServerSocket : public CXSocket { 
    public: 
                	CXTcpServerSocket (); 
					CXTcpServerSocket (SOCKET puiSocket); 
                   ~CXTcpServerSocket (); 

    	BOOL        bBind             (USHORT usPort); 
     	BOOL        bListen           (INT iBacklog = 5);  
		BOOL        bAccept           (CXTcpServerSocket &s, std::string *psFromIp); 

	protected: 
		timeval     _m_tvTimeout;
}; 
//---------------------------------------------------------------------------
#endif	//XLib_Net_CXServerSocketH



/*
Server

Initialize Winsock.
Create a socket.
Bind the socket.
Listen on the socket for a client.
Accept a connection from a client.
Receive and send data.
Disconnect.
*/