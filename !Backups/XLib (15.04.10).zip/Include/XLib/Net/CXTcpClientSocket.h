/****************************************************************************
* Class name:  CXTcpClientSocket
* Description: 
* File name:   CXTcpClientSocket.h
* String type: Ansi (������ �� ������ ��������������!!!)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     04.04.2009 6:21:18
*
*****************************************************************************/


#ifndef XLib_Net_CXTcpClientSocket
#define XLib_Net_CXTcpClientSocket 
//---------------------------------------------------------------------------
#include <winsock2.h>
#include <XLib/Common.h>
#include <XLib/Net/CXSocket.h>
//---------------------------------------------------------------------------
class CXTcpClientSocket : public CXSocket { 
    public: 
					CXTcpClientSocket  (); 
					CXTcpClientSocket  (SOCKET puiSocket); 
                   ~CXTcpClientSocket  (); 

		BOOL        bIsReadable        ();
    	BOOL        bConnect           (const std::string &csIp, USHORT usPort); 
		BOOL        bIoctl             (LONG liCmd, ULONG *pulArgp);
		BOOL        bSetNonBlockingMode(const BOOL cbFlag);
    	

		
		BOOL        bSetTimeout        (LONG liSec,   LONG liMicroSec);
		BOOL        bGetTimeout        (LONG *pliSec, LONG *pliMicroSec);
		


	protected: 
    	timeval     _m_tvTimeout;
}; 
//---------------------------------------------------------------------------
#endif	//XLib_Net_CXTcpClientSocket


/*

tString sStr = _T("Some string!!!");
::send(0, reinterpret_cast<char const*>(sStr.data()), sStr.size() * sizeof(tString::value_type), 0);

sizeof(tString::value_type)

*/


/*
Client

Initialize Winsock.
Create a socket.
Connect to the server.
Send and receive data.
Disconnect.
*/