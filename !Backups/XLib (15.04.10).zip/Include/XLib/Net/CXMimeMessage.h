/****************************************************************************
* Class name:  CXMimeMessage
* Description: �������� ��������� (RFC 822)
* File name:   CXMimeMessage.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.07.2009 19:09:16
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Net_CXMimeMessageH
#define XLib_Net_CXMimeMessageH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Net/CXMimeHeader.h>
#include <XLib/Net/CXMimeBody.h>
//---------------------------------------------------------------------------
class CXMimeMessage {
	public:
				CXMimeMessage();
			   ~CXMimeMessage(); 
		static BOOL bParse          (const tString &csRawMessage, CXMimeHeader &Header, CXMimeBody &Body); 
		static BOOL	bLoadFromRawFile(const tString &csFilePath);	   //csFilePath - raw msg
		static BOOL bSaveToRawFile  (const tString &csFilePath);       //csFilePath - raw msg
	   
	private:
		tString _m_csRawMessage;
};
//---------------------------------------------------------------------------
#endif	//XLib_Net_CXMimeMessageH
