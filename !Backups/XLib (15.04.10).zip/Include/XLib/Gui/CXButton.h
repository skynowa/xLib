/****************************************************************************
* Class name:  CXButton
* Description: ������ � �������
* File name:   CXButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXButtonH
#define XLib_Gui_CXButtonH
//---------------------------------------------------------------------------
#include <XLib/Gui/Common.h>
#include <XLib/Gui/CXWindow.h>
#include <XLib/GUI/CXButtonBase.h>
//---------------------------------------------------------------------------
class CXButton : public CXButtonBase {
	public:
		//����� (�����������/�����)
		typedef enum EViewStyle {
			vsText     = BS_TEXT,
			vsBitmap   = BS_BITMAP,
			vsIcon     = BS_ICON
		};
		
		//��� �����������
		typedef enum EImageType {
			itBitmap   = IMAGE_BITMAP,
			itIcon	   = IMAGE_ICON,
			itCursor   = IMAGE_CURSOR,
			itMetaFile = IMAGE_ENHMETAFILE
		};	
				
			     CXButton        ();
		virtual ~CXButton        ();

		BOOL     bCreateRes      (INT iID, CXWindow *pwndParent);

		//-------------------------------------
		//���������
		BOOL     bSetViewStyle   (EViewStyle vsViewStyle);	
		BOOL     bSetImage       (EImageType itImageType, HANDLE hImage);

		//-------------------------------------
		//�������
		VOID     vSet_OnClick    (SClosureT<VOID(CXButton *pbtnSender)> vCallback);
		VOID     vSet_OnDbClick  (SClosureT<VOID(CXButton *pbtnSender)> vCallback);
		VOID     vSet_OnKillFocus(SClosureT<VOID(CXButton *pbtnSender)> vCallback);
		VOID     vSet_OnSetFocus (SClosureT<VOID(CXButton *pbtnSender)> vCallback);

	private:
		virtual void vOnClick    () { _vHandler_OnClick    (this); }
		virtual void vOnDbClick  () { _vHandler_OnDbClick  (this); }
		virtual void vOnKillFocus() { _vHandler_OnKillFocus(this); }
		virtual void vOnSetFocus () { _vHandler_OnSetFocus (this); }


		//callback ������
		SClosureT<VOID(CXButton *pthSender)> _m_vCallback_OnClick;
		VOID                                 _vHandler_OnClick(CXButton *pthSender);

		SClosureT<VOID(CXButton *pthSender)> _m_vCallback_OnDbClick;
		VOID                                 _vHandler_OnDbClick(CXButton *pthSender);

		SClosureT<VOID(CXButton *pthSender)> _m_vCallback_OnKillFocus;
		VOID                                 _vHandler_OnKillFocus(CXButton *pthSender);

		SClosureT<VOID(CXButton *pthSender)> _m_vCallback_OnSetFocus;
		VOID                                 _vHandler_OnSetFocus(CXButton *pthSender);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXButtonH












//GetParent()->PostMessage (WM_COMMAND, MAKELONG (GetDlgCtrlID(), BN_CLICKED), (LPARAM)m_hWnd);,