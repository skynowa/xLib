/****************************************************************************
* Class name:  CXStyle
* Description: �������� �����
* File name:   CXStyle.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     06.04.2010 13:37:54
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXStyleH
#define XLib_Gui_CXStyleH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXStyle : public CXNonCopyable {
	public:
		//-------------------------------------
		//�������� ������
		typedef ULONG TStyle;
		typedef ULONG TStyleEx;

		////static const TStyle faInvalid           = INVALID_FILE_ATTRIBUTES;

				 CXStyle    ();
		virtual ~CXStyle    ();	

		BOOL     bSetOwner  (HWND hWnd);
		
		TStyle   stGet      ();
		BOOL     bSet       (TStyle stValue);
		BOOL     bAdd       (TStyle stValue);
		BOOL     bRemove    (TStyle stValue);
		BOOL     bModify    (TStyle stRemoveValue, TStyle stAddValue);
		BOOL     bIsExists  (TStyle stValue);
		
		TStyle   stGetEx    ();
		BOOL     bSetEx     (TStyle stValue);
		BOOL     bAddEx     (TStyle stValue);
		BOOL     bRemoveEx  (TStyle stValue);
		BOOL     bModifyEx  (TStyle stRemoveValue, TStyle stAddValue);
		BOOL     bIsExistsEx(TStyle stValue);
	 
	private:
	    HWND   _m_hWnd;	
};
//---------------------------------------------------------------------------
#endif //XLib_Gui_CXStyleH


/*
ULONG             ulGetStyle         ();
ULONG             ulGetStyleEx       ();
BOOL              bAddStyle          (ULONG ulStyle);
BOOL              bAddStyleEx        (ULONG ulStyleEx);
BOOL              bRemoveStyle       (ULONG ulStyle);
BOOL              bRemoveStyleEx     (ULONG ulStyleEx);
BOOL              bModifyStyle       (ULONG ulRemoveStyle,   ULONG ulAddStyle);
BOOL              bModifyStyleEx     (ULONG ulRemoveStyleEx, ULONG ulAddStyleEx);
BOOL              bIsStyleExists     (ULONG ulStyle);
*/