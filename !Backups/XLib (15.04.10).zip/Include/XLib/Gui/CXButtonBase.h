/****************************************************************************
* Class name:  CXButtonBase
* Description: ������ � �������
* File name:   CXButtonBase.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     23.07.2009 13:11:14
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXButtonBaseH
#define XLib_Gui_CXButtonBaseH
//---------------------------------------------------------------------------
#include <XLib/Gui/Common.h>
#include <XLib/Gui/CXWindow.h>
//---------------------------------------------------------------------------
class CXButtonBase : public CXWindow {
	public:
		//������������ ������
		enum ETextAligment {
			taLeft    = BS_LEFT,
			taTop     = BS_TOP,
			taRight   = BS_RIGHT,
			taBottom  = BS_BOTTOM,
			taHCenter = BS_CENTER,
			taVCenter = BS_VCENTER
		};
				
			     CXButtonBase    ();
		virtual ~CXButtonBase    () = 0;

		///BOOL bCreateRes       (INT iID, CXWindow *pwndParent);

		//-------------------------------------
		//���������
		BOOL     bSetAlignment   (ETextAligment taTextAligment);
		BOOL     bSetNotify      (BOOL bFlag);
		BOOL     bSetFlat        (BOOL bFlag);
		BOOL     bSetMultiLine   (BOOL bFlag);
		BOOL     bClick          ();

		//-------------------------------------
		//�������
		VOID     vSet_OnClick    (SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback);
		VOID     vSet_OnDbClick  (SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback);
		VOID     vSet_OnKillFocus(SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback);
		VOID     vSet_OnSetFocus (SClosureT<VOID(CXButtonBase *pbtnSender)> vCallback);

	private:
		virtual VOID vOnClick    () { _vHandler_OnClick    (this); }
		virtual VOID vOnDbClick  () { _vHandler_OnDbClick  (this); }
		virtual VOID vOnKillFocus() { _vHandler_OnKillFocus(this); }
		virtual VOID vOnSetFocus () { _vHandler_OnSetFocus (this); }


		//callback ������
		SClosureT<VOID(CXButtonBase *pthSender)> _m_vCallback_OnClick;
		VOID                                     _vHandler_OnClick(CXButtonBase *pthSender);

		SClosureT<VOID(CXButtonBase *pthSender)> _m_vCallback_OnDbClick;
		VOID                                     _vHandler_OnDbClick(CXButtonBase *pthSender);

		SClosureT<VOID(CXButtonBase *pthSender)> _m_vCallback_OnKillFocus;
		VOID                                     _vHandler_OnKillFocus(CXButtonBase *pthSender);

		SClosureT<VOID(CXButtonBase *pthSender)> _m_vCallback_OnSetFocus;
		VOID                                     _vHandler_OnSetFocus(CXButtonBase *pthSender);
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXButtonBaseH







//GetParent()->PostMessage (WM_COMMAND, MAKELONG (GetDlgCtrlID(), BN_CLICKED), (LPARAM)m_hWnd);