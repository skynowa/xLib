/****************************************************************************
* Class name:  CXLayout
* Description: ���� ��� ���������� ���������
* File name:   CXLayout.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     11.03.2010 14:32:02
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXLayoutH
#define XLib_Gui_CXLayoutH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindowImpl.h>
//---------------------------------------------------------------------------
class CXLayout : public CXWindowImpl {
	public:
		CXLayout();
	   ~CXLayout();
	   
		//xDECLARE_MSG_MAP()
		////////xBEGIN_MSG_MAP(CXLayout)
		////////	/*xCMD(m_CXButton3.iGetID(), OnTest)*/
		////////	/*xCMD(m_CXButton4.iGetID(), OnTest)*/
		////////xEND_MSG_MAP(CXWindowImpl)
		////VOID OnTest  (WORD   id,     LPARAM lParam) {};
		
		///*virtual*/ VOID OnCreate	 (WPARAM wParam, LPARAM lParam);
		///*virtual*/ VOID OnPaint     (WPARAM wParam, LPARAM lParam);
		///*virtual*/ VOID OnCommand   (WPARAM wParam, LPARAM lParam);
		///*virtual*/ VOID OnNotify    (WPARAM wParam, LPARAM lParam);
		///*virtual*/ VOID OnSize      (WPARAM wParam, LPARAM lParam);
		///*virtual*/ VOID OnClose     (WPARAM wParam, LPARAM lParam);  
		///*virtual*/ VOID OnDestroy   (WPARAM wParam, LPARAM lParam);
	   
	private:
	
};
//---------------------------------------------------------------------------
#endif //XLib_Gui_CXLayoutH
