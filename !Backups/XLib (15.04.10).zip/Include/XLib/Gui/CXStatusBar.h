/****************************************************************************
* Class name:  CXStatusBar
* Description: ������ ���������
* File name:   CXStatusBar.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     26.07.2009 23:49:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXStatusBarH
#define XLib_Gui_CXStatusBarH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXStatusBar: public CXWindow {
	public:
			  CXStatusBar ();
			 ~CXStatusBar ();

		BOOL bCreateRes   (INT iID, HWND hParent);

		BOOL    bGetBorders(INT *pBorderWidth[3]);
		BOOL    bIsSimple  ();
		BOOL    bSetSimple (BOOL bFlag);
		tString sGetText   (INT iPartIndex);
		BOOL    bSetText   (INT iPartIndex, const tString &csText);
		tString sGetTipText(INT iPartIndex);
		BOOL    bSetTipText(INT iPartIndex, const tString &csTest);

		BOOL    bSetParts  (INT iParts);
		INT     iGetParts  (/*PARAMS*/);

		BOOL    bSetIcon   (INT iPart, HICON hIcon);
		HICON   hGetIcon   (INT iPart);






		////////////////////////////////////////////////////////////

		INT   Height      ();
		BOOL  SetMinHeight(INT iHeight);	//???????????
		INT   AddPart     ();
		INT   AddPart     (const tString &csPartText);	
		INT   AddPart     (const tString &csPartText, HICON hIcon);
		INT   AddPart     (const tString &csPartText, INT IdIcon);
		INT   AddPart     (INT Size);
		/////////////INT   AddPart     (const tString &csPartText, INT Size);
		INT   AddPart     (const tString &csPartText, HICON hIcon, INT Size);
		INT   AddPart     (const tString &csPartText, INT IdIcon, INT Size);
		INT   AddPart     (HICON hIcon, INT Size);
		BOOL  SetIcon     (INT PartIndex, HICON hIcon);
		BOOL  SetIcon     (INT PartIndex, INT IdIcon);
		BOOL  SetText     (INT PartIndex, const tString &csPartText);
		BOOL  SetSize     (INT PartIndex, INT Size);
		////BOOL  SetParts    (INT iParts, INT iSize);
	
	private:
		INT   m_iNumParts;
		std::vector<INT> m_veciParts;



		//current widths
		class CXWidth {
			public:
				INT	m_iHorWidth;
				INT m_iVertWidth; 
				INT	m_iBetweenWidth;
		};

		
		
		
		
		
		
		
		
		
		////////////////////////////////////////////////////////////
		static const INT ms_ciMaxParts = 256; // MSDN 256 parts max

		INT   _m_iDefaultSize;
		INT   m_iPartsWidths[ms_ciMaxParts + 1];
		
};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXStatusBarH