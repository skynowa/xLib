/****************************************************************************
* Class name:  CXIcon
* Description: ������
* File name:   CXIcon.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2010 11:21:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXIconH
#define XLib_Gui_CXIconH
//---------------------------------------------------------------------------
#include <XLib/Gui/Common.h>
//---------------------------------------------------------------------------
#define STRINGIZE2(x) #x
class CXIcon : public CXNonCopyable {
	public:
			   CXIcon();
	virtual   ~CXIcon();
	   
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hCopyIcon                   (HICON hIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hCreateIcon                 (HINSTANCE hInstance, INT iWidth, INT iHeight, BYTE ucPlanes, BYTE ucBitsPixel, const BYTE *pcucANDBits, const BYTE *pcucXORBits);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hCreateIconFromResource     (PBYTE pucResBits, ULONG ulResSize, BOOL bIcon, ULONG ulVersion);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hCreateIconFromResourceEx   (PBYTE pucIconBits, ULONG ulIconBits, BOOL bIcon, ULONG ulVersion, INT ciDesiredX, INT ciDesiredY, UINT uiFlags);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hCreateIconIndirect         (ICONINFO *pIconInfo);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		BOOL   bDestroyIcon                (HICON hIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		BOOL   bDrawIcon                   (HDC hDC, INT iX, INT iY, HICON hIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		BOOL   bDrawIconEx                 (HDC hdc, INT iLeft, INT iTop, HICON hIcon, INT iWidth, INT iHeight, UINT uiStepIfAniCur, HBRUSH hBrFlickerFreeDraw, UINT uiFlags);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hDuplicateIcon              (HINSTANCE hInstance, HICON hIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hExtractAssociatedIcon      (HINSTANCE hInstance, LPTSTR pszIconPath, LPWORD pusIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hExtractIcon                (HINSTANCE hInstance, LPCTSTR pcszExeFileName, UINT uiIconIndex);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		UINT   uiExtractIconEx             (LPCTSTR pcszFile, INT iIconIndex, HICON *phIconLarge, HICON *phIconSmall, UINT uiIcons);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		BOOL   bGetIconInfo                (HICON hIcon, ICONINFO *pIconInfo);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_VISTA)
		BOOL   bGetIconInfoEx              (HICON hIcon, ICONINFOEX *pIconInfoEx);
	#endif //xWIN32_VISTA
	#if (xWINVER >= xWIN32_WINXP)
		HICON  hLoadIcon                   (HINSTANCE hInstance, LPCTSTR pcszIconName);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		INT    iLookupIconIdFromDirectory  (PBYTE pucResBits, BOOL bIcon);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WINXP)
		INT    iLookupIconIdFromDirectoryEx(PBYTE pucResBits, BOOL bIcon, INT cixDesired, INT ciyDesired, UINT uiFlags);
	#endif //xWIN32_WINXP
	#if (xWINVER >= xWIN32_WIN2K)
		UINT   uiPrivateExtractIcons       (LPCTSTR pcszFile, INT iIconIndex, INT ciIconX, INT ciIconY, HICON *phIcon, UINT *pIconId, UINT uiIcons, UINT uiFlags);
	#endif //xWIN32_WIN2K

	private:
		HICON _m_hHandle;
};
//---------------------------------------------------------------------------
#endif //XLib_Gui_CXIconH
