/****************************************************************************
* Class name:  -
* Description: ����� ��������� 
* File name:   XMessageMap.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     31.08.2009 16:44:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_XMessageMapH
#define XLib_Gui_XMessageMapH
//---------------------------------------------------------------------------
#include <XLib/GUI/Common.h>
//---------------------------------------------------------------------------
#define xDECLARE_MSG_MAP()				virtual LRESULT lpProcessMsg(UINT uiMsg, WPARAM wParam, LPARAM lParam) 

#define xBEGIN_MSG_MAP_NO_DECLARE() 	virtual LRESULT lpProcessMsg(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	

#define xBEGIN_MSG_MAP(_CXClass) 		LRESULT _CXClass::lpProcessMsg(UINT uiMsg, WPARAM wParam, LPARAM lParam) {	

#define xMSG(_msg, _func)				if ((_msg) == uiMsg) {												\
											/*LOG*/_m_tlLog.bWrite(_T("xMSG:  %i, %i"), wParam, lParam);	\
																											\
											(_func)(wParam, lParam);										\
																											\
											return NULL;													\
										}

#define xCMD(_id, _func)                if ((WM_COMMAND == uiMsg) && (LOWORD(wParam) == (_id))) {			\
											/*LOG*/_m_tlLog.bWrite(_T("xCMD:  %i, %i"), wParam, lParam);	\
																											\
											(_func)(LOWORD(wParam), lParam);								\
																											\
											return NULL;													\
										}

#define xEND_MSG_MAP(_CXParentClass)		return _CXParentClass::lpProcessMsg(uiMsg, wParam, lParam);		\
										};

#define xEND_MSG_MAP_NOPARENT    			return NULL;													\
										};
//---------------------------------------------------------------------------
#endif //XLib_Gui_XMessageMapH


/*
#define HANDLE_MSG(hwnd, message, fn)    \
		case (message): return HANDLE_##message((hwnd), (wParam), (lParam), (fn))
*/