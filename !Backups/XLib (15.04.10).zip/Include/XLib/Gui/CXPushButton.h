/****************************************************************************
* Class name:  CXPushButton
* Description: 
* File name:   CXPushButton.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     25.07.2009 21:38:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Gui_CXPushButtonH
#define XLib_Gui_CXPushButtonH
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
#include <XLib/GUI/CXButtonBase.h>
//---------------------------------------------------------------------------
class CXPushButton: public CXButtonBase {
	public:
		//���������
		typedef enum ECheckState {
			csUknown     = - 1,
			csChecked	 = BST_CHECKED,
			csUnchecked	 = BST_UNCHECKED,	
		};	
		
		//����� (�����������/�����)
		typedef enum EViewStyle {
			vsText   = BS_TEXT,
			vsBitmap = BS_BITMAP,
			vsIcon   = BS_ICON
		};

		//��� �����������
		typedef enum EImageType {
			itBitmap   = IMAGE_BITMAP,
			itIcon	   = IMAGE_ICON,
			itCursor   = IMAGE_CURSOR,
			itMetaFile = IMAGE_ENHMETAFILE
		};

			        CXPushButton (BOOL bRadioButtonLike);
		virtual    ~CXPushButton ();
			
	    BOOL        bCreateRes   (INT iID, CXWindow *pwndParent);

		//-------------------------------------
		//���������
		BOOL        bSetViewStyle(EViewStyle vsViewStyle);	
		BOOL        bSetImage    (EImageType itImageType, HANDLE hImage);
		
		ECheckState csGetState   ();							
		BOOL        bSetState    (CXPushButton::ECheckState csCheckState);	
		


		//-------------------------------------
		//�������

};
//---------------------------------------------------------------------------
#endif	//XLib_Gui_CXPushButtonH