/****************************************************************************
*    �����: CXCrc32 (CXCrc32.h)
*
*****************************************************************************/



#ifndef XLib_Crypt_CXCrc32H
#define XLib_Crypt_CXCrc32H
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXCrc32 : public CXNonCopyable {
	public:
			  CXCrc32       ();
			 ~CXCrc32       ();

		ULONG ulCalc        (UCHAR *pucBuff, ULONG ulSize);
		ULONG ulCalcFile    (const std::string &csFilePath);
		
		ULONG ulCalcFast    (UCHAR *pucBuff, ULONG ulSize);
		ULONG ulCalcFileFast(const std::string &csFilePath);

	private:
		ULONG ulFileSize    (FILE *pFile);
};
//---------------------------------------------------------------------------
#endif	//XLib_Crypt_CXCrc32H
