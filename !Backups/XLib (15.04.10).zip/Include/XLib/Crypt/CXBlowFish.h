/****************************************************************************
* Class name:  CXBlowFish
* Description: ���������� ��������� ���������� Blowfish
* File name:   CXBlowFish.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     28.07.2009 17:37:50
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXBlowFishH
#define CXBlowFishH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string>
//---------------------------------------------------------------------------
class CXBlowFish {
	public:
		//���� ������
		typedef enum {
			etEncodeSuccessed,           
			etDecodeSuccessed,           
			etSrcFileOpenFailed,     
			etDestFileCreateFailed,   
			etErrorEncodeFile,        
			etUknown,        
		} EErrorType;	
	                     CXBlowFish   ();
		                ~CXBlowFish   ();

		VOID             vInitialize  (const std::string &csKey);
		std::string      sGetSignature();
		BOOL             bSetSignature(const std::string &csSignature);
		EErrorType       iEncodeFile  (const std::string &csInFileName, const std::string &csOutFileName);
		EErrorType       iDecodeFile  (const std::string &csInFileName, const std::string &csOutFileName);
		VOID             vEncode      (UCHAR *pucIn, UCHAR *pucOut);
        VOID             vDecode      (UCHAR *pucIn, UCHAR *pucOut); 
		VOID             vShowErrorMsg(INT code);

    private:
		std::string      _m_sSignature;

		unsigned int     _ulFunction   (UINT uiData32);
		unsigned __int64 _ui64Encode   (unsigned __int64 ui64Data64);  
		unsigned __int64 _ui64Decode   (unsigned __int64 ui64Data64);  		
};
//---------------------------------------------------------------------------
#endif