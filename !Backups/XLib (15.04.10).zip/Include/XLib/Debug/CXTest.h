/****************************************************************************
* Class name:  CXTest
* Description: ������������
* File name:   CXTest.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     14.04.2010 9:29:52
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CXTestH
#define XLib_CXTestH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Fso/CXEnvironment.h>
//---------------------------------------------------------------------------
class CXTest : public CXNonCopyable {
	public:
					BOOL                       m_bRes;
					INT                        m_iRes;
					UINT                       m_uiRes;
					ULONG                      m_ulRes;
					ULONGLONG                  m_ullRes;
					DOUBLE                     m_dRes;
					HANDLE                     m_hRes;
					HWND                       m_hwndRes;
					tString                    m_sRes;
					std::vector<tString>       m_vecsRes; 
					std::map<tString, tString> m_mapsRes;

		            CXTest        ();
	   virtual     ~CXTest        ();

	   BOOL         bRun          (ULONG ulLoops /*0 - infinite*/);
	   virtual BOOL bUnit         () = 0;
	   tString      sGetWorkDir   ();
	   BOOL         bSetWorkDir   (const tString &csDirPath = _T(""));
	
	private:
		BOOL        _m_bRes;
		tString     _m_sWorkDir;
};
//---------------------------------------------------------------------------
#endif //XLib_CXTestH
