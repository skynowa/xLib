/****************************************************************************
* Class name:  CXPerform
* Description: ����� ������������������ ����
* File name:   CXPerform.h
* String type: Ansi (tString)
* Compilers:   Visual C++ 2008
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     07.04.2009 16:59:44
*
*****************************************************************************/


#ifndef XLib_Debug_CXPerformH
#define XLib_Debug_CXPerformH       
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
class CXPerform : public CXNonCopyable {
	public:
		//Perfomance mode
		enum EMode {
			pmUknown, 
			pmTime, 
			pmTickCount, 
			pmPerformanceCount, 
			pmThreadTimes
		};
		
		
		////class CXMode {
		////	public:
		////		////static const INT pmUknown                  = 0;
		////		////static const INT pmTime                    = 1;
		////		////static const INT pmGetTickCount            = 2;
		////		////static const INT pmQueryPerformanceCounter = 3;
		////		////static const INT pmGetThreadTimes          = 4;

		////		static enum EMode {
		////			pmUknown, 
		////			pmTime, 
		////			pmGetTickCount, 
		////			pmQueryPerformanceCounter, 
		////			pmGetThreadTimes
		////		};

		////	private:
		////		CXMode();
		////};
		////typedef CXMode::EMode TMode;
		
		              CXPerform            (const tString &csFileName, EMode pmMode); //TODO: csFileName + iPerfomMode
		             ~CXPerform            ();

		BOOL          bStart               ();
		BOOL          bStop                (const tString &csComment);
        BOOL          bPulse               (const tString &csComment);     
        BOOL          bPulse               (ULONG ulComment);
        BOOL          bOpenLog             ();
		BOOL          bDeleteLog           ();

    private:
		EMode		  _m_pmModeNow;		 
        BOOL          _m_bWasStarted;

		BOOL          _bResetData           ();
        tString       _sMilliSecToTimeString(LONGLONG i64MilliSec); 
		
		//pmTime
		//TDateTime    dtBeginTime;
		//TDateTime    dtEndTime;

		//pmGetTickCount
		ULONG         _m_ulBeginTime;
		ULONG         _m_ulEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER _m_liStart;
		LARGE_INTEGER _m_liBeginCount;
		LARGE_INTEGER _m_liEndCount;
		LARGE_INTEGER _m_liCount;
		
		//GetThreadTimes
		FILETIME      _m_lpCreationTime;  
		FILETIME      _m_lpExitTime;
		FILETIME      _m_lpKernelTime0;
		FILETIME      _m_lpUserTime0;
		FILETIME      _m_lpKernelTime1;
		FILETIME      _m_lpUserTime1;
		LONGLONG      _iFiletimeToint64     (FILETIME F);

		//���
		tString       _m_sLogPath;
		BOOL          _bLog                 (const tString &csText);
        BOOL          _bLog                 (const tString &csComment, const tString &csText); 
};
//---------------------------------------------------------------------------
#endif	//XLib_Debug_CXPerformH



/*
// rdtsc.cpp
// processor: x86, x64
#include <stdio.h>
#include <intrin.h>

#pragma intrinsic(__rdtsc)

int main()
{
unsigned __int64 i;
i = __rdtsc();
printf_s("%I64d ticks\n", i);
}
*/