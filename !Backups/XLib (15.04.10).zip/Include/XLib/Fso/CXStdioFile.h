/****************************************************************************
* Class name:  CXStdioFile
* Description: ������ � �������
* File name:   CXStdioFile.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     21.05.2009 17:46:38
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef	XLib_Fso_CXStdioFileH
#define	XLib_Fso_CXStdioFileH
//---------------------------------------------------------------------------
#include <XLib/Common.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/locking.h>
#include <io.h>
#include <fcntl.h>
#include <iostream>
#include <ostream>
#include <fstream>
//---------------------------------------------------------------------------
class CXStdioFile : public CXNonCopyable {
	public:
	    //EErrorType
	    enum EErrorType{
			etError = EOF
		};
	    
		//Open mode
		class CXOpenMode {
			public:
				typedef tString TMode;

				static const TMode omRead;				//"r"
				static const TMode omWrite;				//"w"
				static const TMode omAppend;			//"a"
				static const TMode omOpenReadWrite;		//"r+"
				static const TMode omCreateReadWrite;	//"w+"
				static const TMode omOpenReadAppend;	//"a+"
		};

		//File attribute
		enum EAttributes {
			faInvalid  = - 1,           /*?*/
			faNormal   =  _A_NORMAL,    /* Normal file - No read/write restrictions */
			faReadOnly =  _A_RDONLY,	/* Read only file */
			faHidden   =  _A_HIDDEN,    /* Hidden file */
			faSystem   =  _A_SYSTEM,    /* System file */
			faSubDir   =  _A_SUBDIR,    /* Subdirectory */
			faArchive  =  _A_ARCH ,     /* Archive file */			
		};	
		
		//Translation mode
		enum ETranslationMode {
			tmText   = _O_TEXT,          /* file mode is text (translated) */
			tmBinary = _O_BINARY         /* file mode is binary (untranslated) */
		};	
		
		//Access mode
		enum EAccessMode {
			amExistence = 0,	//Existence only
			amWrite     = 2, 	//Write permission
			amRead      = 4,	//Read permission
			amReadWrite = 6		//Read and write permission
		};	
		
		//file position data for the given stream
		enum EPointerPosition {
			ppBegin = SEEK_SET,	
			ppCurr  = SEEK_CUR,	
			ppEnd   = SEEK_END,
			ppError = - 1L	
		};	
		
		//mode for file buffering
		enum EBufferingMode {
			bmFull = _IOFBF, 
			bmLine = _IOLBF, 
			bmNo   = _IONBF	 
		};
		
		//Locking action to perform
		enum ELockingMode {
			lmTryLock = LK_LOCK/*_LK_LOCK*/,		//Locks the specified bytes. If the bytes cannot be locked, the program immediately tries again after 1 second. If, after 10 attempts, the bytes cannot be locked, the constant returns an error.
			lmLock    = LK_NBLCK/*_LK_NBLCK*/,		//Locks the specified bytes. If the bytes cannot be locked, the constant returns an error.
			//lmXXX = _LK_NBRLCK,		            //Same as _LK_NBLCK.
			//lmXXX = _LK_RLCK,		                //Same as _LK_LOCK.
			lmUnlock  = LK_UNLCK/*_LK_UNLCK*/		//Unlocks the specified bytes, which must have been previously locked.
		};
		
		//Permission mode
		enum EPermissionMode {
			pmWrite     = _S_IWRITE,				//Writing permitted
			pmRead      = _S_IREAD,					//Reading permitted
			pmReadWrite = (_S_IREAD | _S_IWRITE)	//Reading and writing permitted
		};
	
			               CXStdioFile         ();	
			              ~CXStdioFile         ();	
			              
		operator           FILE *              ();	
		
		//������
		FILE              *pGet                ();
		BOOL               bOpen               (const tString &csFilePath, CXOpenMode::TMode omMode);	
		BOOL               bReopen             (const tString &csFilePath, const tString &csMode);	
		tString            sGetPath            ();	
		
		//������ / ������
		std::size_t        uiRead              (LPVOID pvBuf,         std::size_t uiCount); 
		std::size_t        uiWrite             (const LPVOID pcvBuff, std::size_t uiCount); 

		BOOL               bReadAll            (LPVOID pvBuff,        std::size_t uiBuffSize, std::size_t uiBlockSize);
		BOOL               bWriteAll           (const LPVOID pcvBuf,  std::size_t uiBuffSize, std::size_t uiBlockSize);

		BOOL               bReadAll            (uString *psBuff,       std::size_t uiBlockSize);
		BOOL               bWriteAll           (const uString &csBuff, std::size_t uiBlockSize);



		
		BOOL               bReadLine           (LPTSTR pszStr, std::size_t uiMaxSize); 
		BOOL               bWriteLine          (const tString &csStr); 	

		BOOL               bWriteChar          (TCHAR cChar); 
		TCHAR              cReadChar           (); 
		BOOL               bUngetChar          (TCHAR cChar); 
		
		BOOL               bWriteString        (const tString &csStr); 
				
		static BOOL        bReadFile           (const tString &csFilePath, std::vector<tString> *pvecsVector);
		static BOOL        bWriteFile          (const tString &csFilePath, const std::vector<tString> *pcvecsVector);
		
		//...
		BOOL               bLocking            (ELockingMode lmMode, LONG liBytes); 
		BOOL               bSetPosition        (LONG lOffset, EPointerPosition fpPos/* = fpBegin*/); 
		LONG               liGetPosition       (); 
		BOOL               bClose              (); 
		BOOL               bFlush              (); 
		LONG               liGetSize           (); 
		BOOL               bChsize             (LONG liSize); 
		BOOL               bSetVBuff           (LPTSTR pszBuff, EBufferingMode bmMode, std::size_t uiSize); 
		BOOL               bSetMode            (ETranslationMode tmMode); 

		//��������
		static BOOL        bIsExists           (const tString &csFilePath); 
		static BOOL        bAccess             (const tString &csFilePath, EAccessMode amMode); 
		static BOOL        bChmod              (const tString &csFilePath, EPermissionMode pmMode); 
		static BOOL        bRemove             (const tString &csFilePath); 
		static BOOL        bUnlink             (const tString &csFilePath);	
		static BOOL        bRename             (const tString &csOldFilePath,  const tString &csNewFilePath); 
		static BOOL        bMove               (const tString &csFilePath,     const tString &csDirPath); 
		static BOOL        bCopy               (const tString &csFromFilePath, const tString &csToFilePath);
		static BOOL        bExec               (const tString &csFilePath); 
        static tString     sCreateTempFileName (); 
		static BOOL        bFlushAllOutput     (); 
		static INT         iFlushAll           (); 
		static ULONG       ulLines             (const tString &csFilePath); 

		//character input/output
		static TCHAR       cGetCharFromStdin   (); 
		static tString     sGetStringFromStdin (LPTSTR pszBuff); 
		static BOOL        bWriteCharToStdout  (TCHAR cChar); 
		static BOOL        bWriteStringToStdout(const tString &csStr);

		//formatted input/output
		INT                iFprintf            (LPCTSTR pcszFormat, ...); 
		static INT         iPrintf             (LPCTSTR pcszFormat, ...); 
		static INT         iSprintf            (LPTSTR  pszStr, LPCTSTR pcszFormat, ...); 
		INT                iFprintfV           (LPCTSTR pcszFormat, va_list arg); 
		static INT         iPrintfV            (LPCTSTR pcszFormat, va_list arg); 
		static INT         iSprintfV           (LPTSTR  pszStr, LPCTSTR pcszFormat, va_list arg); 

		//Error-handling:
		BOOL               bClearErr           (); 
		BOOL               bIsEof              (); 
		BOOL               bIsError            (); 	
		static BOOL        bPrintError         (const tString &csStr); 		

		//Macros
		//FILENAME_MAX	Maximum length of file names (constant)
		//TMP_MAX		Number of temporary files (constant)

		/****************************************************************************
		* ������ / ������ ����� (all not tested)
		*
		*****************************************************************************/
		static std::vector<tString>       vecsReadFile(const tString &csFilePath);  /* DEPR */
		static BOOL                       bReadFile	  (const tString &csFilePath, std::vector<TCHAR>   *pvecchVector); 
		static std::map<tString, tString> mapReadFile (const tString &csFilePath, const tString &csDelimiter); 
		static BOOL                       bReadFile   (const tString &csFilePath, tString &cStr); 

	private:
		FILE              *_m_pFile;
		tString            _m_sFilePath;
		BOOL               _m_bRes;
		INT                _iGetHandle         ();
};
//---------------------------------------------------------------------------
#endif	//XLib_Fso_CXStdioFileH	


/*
"r"		Open a file for reading. The file must exist.
"w"		Create an empty file for writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file. 
"a"		Append to a file. Writing operations append data at the end of the file. The file is created if it does not exist.
"r+"	Open a file for update both reading and writing. The file must exist.
"w+"	Create an empty file for both reading and writing. If a file with the same name already exists its content is erased and the file is treated as a new empty file.
"a+"	Open a file for reading and appending. All writing operations are performed at the end of the file, protecting the previous content to be overwritten. You can re
*/




/*
//setlocale(LC_NUMERIC, "");
//setlocale(LC_ALL, ".ACP" );
//setlocale(LC_ALL,"Russian");
*/


//TODO: std::ifsStream - �� ������ ������� �����