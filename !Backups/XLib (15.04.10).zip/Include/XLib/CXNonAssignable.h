/****************************************************************************
* Class name:  CXNonAssignable
* Description: ����� ��� ������� ��������� ������������
* File name:   CXNonAssignable.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     09.11.2009 11:11::00
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_CXNonAssignableH
#define XLib_CXNonAssignableH
//---------------------------------------------------------------------------
class CXNonAssignable {
   protected:
       CXNonAssignable() {}
      ~CXNonAssignable() {}
      
   private:  
       const CXNonAssignable &operator = (const CXNonAssignable &);
};
//---------------------------------------------------------------------------
#endif	//XLib_CXNonAssignableH