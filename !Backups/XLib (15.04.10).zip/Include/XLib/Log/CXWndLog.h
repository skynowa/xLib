/****************************************************************************
* Class name:  CXWndLog
* Description: ����������� � ����
* File name:   CXWndLog.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.06.2009 17:44:10
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Log_CXWndLogH
#define XLib_Log_CXWndLogH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
//---------------------------------------------------------------------------
class CXWndLog : public CXNonCopyable {
	public:
		//����� ����
		typedef enum {
		    wcNone,
			wcListBox,          
		} EWindowClass;	

								 CXWndLog(EWindowClass wcWC);
								~CXWndLog();
   		BOOL                     bWrite  (HWND hWnd, LPCTSTR pcszFormat, ...);
   		
   	private:	
   		EWindowClass             _m_eWC;
   		static CXCriticalSection _ms_csListBox;  //Mutex
};
//---------------------------------------------------------------------------
#endif