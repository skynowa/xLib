/****************************************************************************
* Class name:  CXMallocT
* Description: ������ � ��������
* File name:   CXMallocT.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2009 17:20:09
* Version:     1.0.0.0 Debug
*
*****************************************************************************/

/*
Usage:

	PSP_DEVICE_INTERFACE_DETAIL_DATA pData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(ulBytesReturned);
	...
	free(pData);

	CXMallocT<PSP_DEVICE_INTERFACE_DETAIL_DATA> diddDeviceInterfaceDetailData((size_t)ulBytesReturned);
*/

#ifndef XLib_CXMallocH
#define XLib_CXMallocH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
//---------------------------------------------------------------------------
template<class PointerT>
class CXMallocT : public CXNonCopyable {
	public:
		         CXMallocT(const std::size_t cuiSize);
		        ~CXMallocT();

		PointerT pGetPtr();
            
	private:
        PointerT _m_pDataT;
};
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//TODO: + CXMallocT (����������)
template<class PointerT>
CXMallocT<PointerT>::CXMallocT(const std::size_t cuiSize) :
	_m_pDataT(NULL)
{
	_m_pDataT = (PointerT)malloc(cuiSize);
	/*DEBUG*/xASSERT(NULL != _m_pDataT);		//MessageBox(0, "Constructor", "", MB_OK);
}
//---------------------------------------------------------------------------
//TODO: + pGetPtr (��������� ���������)
template<class PointerT>
PointerT CXMallocT<PointerT>::pGetPtr() {
	/*DEBUG*/xASSERT(NULL != _m_pDataT);

	return _m_pDataT; 
}
//---------------------------------------------------------------------------
//TODO: + ~CXMallocT (����������)
template<class PointerT>
CXMallocT<PointerT>::~CXMallocT() {		
	/*DEBUG*/xASSERT(NULL != _m_pDataT);

	free(_m_pDataT);	
	_m_pDataT = NULL;							//MessageBox(0, "Destructor", "", MB_OK);
}
//---------------------------------------------------------------------------
#endif	//XLib_CXMallocH