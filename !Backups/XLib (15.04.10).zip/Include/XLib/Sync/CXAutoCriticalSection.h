/****************************************************************************
* Class name:  CXAutoCriticalSection
* Description: ������ � ������������ �������� � �����
* File name:   CXAutoCriticalSection.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     19.05.2009 21:16:33
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXAutoCriticalSectionH
#define XLib_Sync_CXAutoCriticalSectionH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXCriticalSection.h>
////#include <XLib/Sync/CXSleeper.h>
//---------------------------------------------------------------------------
class CXAutoCriticalSection : public CXNonCopyable {
	public:
						   CXAutoCriticalSection(CXCriticalSection &csCS);
						   ////CXAutoCriticalSection(CXCriticalSection &csCS, BOOL bTry, ULONG ulTimeout = 1000);
   					      ~CXAutoCriticalSection();

	private:
		CXCriticalSection &_m_csCS;
		////CXSleeper		   _m_slSleeper;	//������
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXAutoCriticalSectionH