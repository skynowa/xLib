/****************************************************************************
* Class name:  CCompletionPort
* Description: ���� ����������
* File name:   CCompletionPort.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.02.2010 14:28:40
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXCompletionPortH
#define XLib_Sync_CXCompletionPortH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/CXHandleT.h>
//---------------------------------------------------------------------------
class CXCompletionPort : public CXNonCopyable  {
	public:
		explicit        CXCompletionPort();
	                   ~CXCompletionPort();

		BOOL            bCreate         (HANDLE hFileHandle, HANDLE hExistingCompletionPort, ULONG_PTR pulCompletionKey, ULONG ulNumberOfConcurrentThreads);
		BOOL            bGetStatus      (LPDWORD lpNumberOfBytes, PULONG_PTR lpCompletionKey, LPOVERLAPPED *lpOverlapped, ULONG ulMilliseconds);
		BOOL            bPostStatus     (ULONG ulNumberOfBytesTransferred, ULONG_PTR ulCompletionKey, LPOVERLAPPED lpOverlapped);

	private:
		CXHandleT<NULL> _m_hCompletionPort; 
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXCompletionPortH