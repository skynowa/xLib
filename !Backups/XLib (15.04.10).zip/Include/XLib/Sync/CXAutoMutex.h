/****************************************************************************
* Class name:  CXMutexScopeLock
* Description: ������� � �����
* File name:   CXAutoMutex.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     16.12.2009 10:06:46
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CXAutoMutexH
#define XLib_Sync_CXAutoMutexH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Sync/CXMutex.h>
//---------------------------------------------------------------------------
class CXAutoMutex : public CXNonCopyable {
	public:
				 CXAutoMutex(CXMutex &mtMutex);
				~CXAutoMutex();

	private:
		CXMutex &_m_mtMutex;
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CXAutoMutexH