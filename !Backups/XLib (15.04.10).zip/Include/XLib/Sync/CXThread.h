/****************************************************************************
* Class name:  CXThread
* Description: �����
* File name:   CXThread.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     22.11.2009 13:59:34
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_Sync_CThreadH
#define XLib_Sync_CThreadH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/Closure.h>
#include <XLib/CXHandleT.h>
#include <XLib/CXCOM.h>
#include <XLib/Sync/CXEvent.h>
#include <XLib/Sync/CXSleeper.h>
#include <XLib/closure.h>
#include <XLib/Log/CXConsoleLog.h>
#include <XLib/Log/CXTraceLog.h>
#include <XLib/Log/CXFileLog.h>
#include <XLib/Log/CXWndlog.h>
//---------------------------------------------------------------------------
#ifndef _MT
#	define _MT
#endif // _MT

///#define	defVarPolicy TRUE
//---------------------------------------------------------------------------
class CXThread : public CXNonCopyable {
	public:
		//��������� ������
		typedef enum {
			xPRIORITY_ERROR         = THREAD_PRIORITY_ERROR_RETURN,
			xPRIORITY_TIME_CRITICAL = THREAD_PRIORITY_TIME_CRITICAL,
			xPRIORITY_HIGHEST       = THREAD_PRIORITY_HIGHEST,
			xPRIORITY_ABOVE_NORMAL  = THREAD_PRIORITY_ABOVE_NORMAL,
			xPRIORITY_NORMAL        = THREAD_PRIORITY_NORMAL,
			xPRIORITY_BELOW_NORMAL  = THREAD_PRIORITY_BELOW_NORMAL,
			xPRIORITY_LOWEST        = THREAD_PRIORITY_LOWEST,
			xPRIORITY_IDLE          = THREAD_PRIORITY_IDLE
		} EPriority;

		typedef  UINT      (WINAPI *pThreadProc)(VOID *pvParams); 
		volatile LONG      m_ulTag;

		explicit           CXThread          (BOOL bIsPaused, BOOL bAutoDelete, BOOL bIsUsingCOM);
		virtual           ~CXThread          ();

		//��������
		BOOL               bCreate           (UINT uiStackSize, const pThreadProc ptfStartAddress, VOID *pvParam);
		BOOL               bResume           ();
		BOOL               bPause            ();
		BOOL               bExit             (ULONG ulTimeout);
		BOOL               bKill             (ULONG ulTimeout);
		BOOL               bWait             (ULONG ulTimeout) const;

		//����� ��������
		BOOL               bIsCreated        () const;
		BOOL               bIsRunning        () const;
		BOOL               bIsPaused         () const;
		BOOL               bIsSleeping       () const;
		BOOL               bIsExited         () const;

		//���������
		BOOL		       bPostMessage      (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL		       bSendMessage      (HWND hHwnd, UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL		       bPostThreadMessage(UINT uiMsg, INT iParam1, INT iParam2) const;
		BOOL		       bMessageWaitQueue (UINT uiMsg, INT *piParam1, INT *piParam2) const;

		//���������
		BOOL               bSetPriority      (EPriority tpPriority) const;
		EPriority          tpGetPriority     () const; 
		tString            sGetPriorityString() const;
        BOOL               bPriorityUp       () const;
		BOOL               bPriorityDown     () const;
		BOOL               bIsPriorityBoost  () const;	
		BOOL               bSetPriorityBoost (BOOL bIsEnabled) const;

		//CPU
		BOOL		       bSetAffinityMask  (DWORD_PTR pulMask) const;
		BOOL               bSetIdealCPU      (ULONG ulIdealCPU) const;
		ULONG              ulGetIdealCPU     () const;
		ULONG              ulGetCPUCount     () const;	/*static ???*/ 
		
		//���������
		HANDLE             hGetHandle        () const;
		ULONG              ulGetId           () const;
		ULONG              ulGetExitCode     () const;      
		BOOL               bSetDebugNameA    (LPCSTR pcszName) const;
		//GetThreadLocale

		//static
		static HANDLE      hOpen             (ULONG ulAccess, BOOL bInheritHandle, ULONG ulId);
		static ULONG       ulGetCurrId       ();
		static HANDLE      hGetCurrHandle    ();

		//callback ������
		VOID               vAttachHandler_OnEnter(SClosureT<VOID(CXThread *pthSender)> vCallback);
		////VOID           vDetachHandler_OnEnter(CXThread *pthSender);

		VOID               vAttachHandler_OnExit (SClosureT<VOID(CXThread *pthSender)> vCallback);
		////VOID           vDetachHandler_OnExit (CXThread *pthSender);

	protected:
		CXTraceLog		   _m_clLog;						//���

		//�������
		virtual UINT       uiOnRun           (VOID *pvParam) = 0;
		virtual VOID       vOnEnter          ();
		virtual VOID       vOnExit           ();	

		BOOL               bYield            () const;			/*static ???*/ 
		BOOL               bSleep            (ULONG ulTimeout);	/*static ???*/ 
		BOOL               bSleeperWakeUp    ();				/*static ???*/ 

		BOOL               bIsTimeToExit     ();
		
	private:
		//���������
		const ULONG        _m_culStillActiveTimeout;	//������� �������� ����������	
		const ULONG        _m_culExitTimeout;			//������� ������ / �����������        
		
		//������ ������
		CXHandleT<NULL>    _m_hThread;					//�����
		ULONG              _m_ulID;						//ID
		UINT               _m_uiExitCode;				//��� ��������
		pThreadProc        _m_ptfStartAddress;			//����� ������� �������
		VOID              *_m_pvParam;					//�������� ��� ������� �������
		const BOOL         _m_cbIsAutoDelete;			//���� ������������

		//��������� �������
		BOOL			   _m_bIsCreated;				//���� �������� 
		BOOL               _m_bIsRunning;				//���� ����������
		BOOL               _m_bIsPaused;				//���� �����
		////-TEST- BOOL    _m_bIsSleeping;				//���� ���
#ifdef defVarPolicy
		volatile BOOL      _m_bIsExited;				//���� ������
#else 
		CXEvent            _m_evExit;					//������� ��� ������
#endif
		//���������
		CXEvent            _m_evPause;					//������� ��� �����
		CXEvent           *_m_pevStarter;				//������� ��� ����������� ������� ������
		CXSleeper		   _m_slSleeper;				//������
		//HANDLE           _m_hParentHandle;
		//HANDLE           _m_hParentId;
		const BOOL		   _m_cbIsUsingCOM;				//���� ������������� COM
		CXCOM             *_m_pcomCOM;					//������ COM-�

        static UINT WINAPI _s_uiStartFunc    (VOID *pvParam);
		BOOL			   _bWaitResumption  (); 
		VOID               _vSetDefaultStates(); 

		//callback ������
		SClosureT<VOID(CXThread *pthSender)> _m_vCallback_OnEnter;
		BOOL                               _m_bFlag_OnEnter;

		SClosureT<VOID(CXThread *pthSender)> _m_vCallback_OnExit;
		BOOL                               _m_bFlag_OnExit;

		VOID               _vHandler_OnEnter(CXThread *pthSender);
		VOID               _vHandler_OnExit (CXThread *pthSender);
};
//---------------------------------------------------------------------------
#endif	//XLib_Sync_CThreadH



/*
	*
	*	Info: Attaches a Thread Function
	*	
	*	Used primarily for porting but can serve in developing generic thread objects
	*
	void Attach( LPTHREAD_START_ROUTINE lpThreadFunc ){
		m_pThreadFunc = lpThreadFunc;
	}

	*
	*	Info: Detaches the Attached Thread Function
	*	
	*	Detaches the Attached Thread Function, If any.
	*	by resetting the thread function pointer to EntryPoint1
	*
	void  Detach( void ){
		m_pThreadFunc = CThread::EntryPoint; 
	}
*/


/*
	static __int64 GetThreadCPUTime(DWORD id);

	__int64 CThread::GetThreadCPUTime(DWORD id)
	{
	int result = 0;
	__int64 TimeTotal = 0;
	FILETIME CreationTime;
	FILETIME ExitTime;
	FILETIME KernelTime;
	FILETIME UserTime;
	ULARGE_INTEGER temp;

	HANDLE hThread = OpenThread(THREAD_QUERY_INFORMATION, FALSE, id);

	if (hThread != NULL) {

	::GetThreadTimes(hThread, &CreationTime, &ExitTime, &KernelTime, &UserTime);

	temp.HighPart = KernelTime.dwHighDateTime;
	temp.LowPart = KernelTime.dwLowDateTime; 
	TimeTotal = (__int64)temp.QuadPart;

	temp.HighPart = UserTime.dwHighDateTime;
	temp.LowPart = UserTime.dwLowDateTime; 
	TimeTotal += (__int64)temp.QuadPart;

	CloseHandle(hThread);

	}

	return TimeTotal;

	}

*/

/*
LPTHREADENTRY32
*/


/*
BOOL GetThreadTimes(LPFILETIME lpCreationTime, LPFILETIME lpExitTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime) const
{
	_ASSERTE(m_hThread);
	_ASSERTE(lpExitTime!=NULL && lpKernelTime!=NULL && lpUserTime!=NULL);
	return ::GetThreadTimes(m_hThread, lpCreationTime, lpExitTime, lpKernelTime, lpUserTime);
}
*/