#ifndef XLib_CommonH
#define XLib_CommonH
//---------------------------------------------------------------------------
#if !defined(WIN32) || !defined(_WIN32)
	//#error This file is intended only for use with the Microsoft Windows API.
#endif

#ifndef __cplusplus
	#error XLib requires C++ compilation (use a .cpp suffix)
#endif

//Required for VS 2008 (fails on XP and Win2000 without this fix)
////#ifndef _WIN32_WINNT
////	#define _WIN32_WINNT 0x0500
////#endif

#ifdef WINVER
	#undef  WINVER
	#define WINVER 0x0500
#else
	#define WINVER 0x0500
#endif

#ifdef _WIN32_WINNT
	#undef  _WIN32_WINNT
	#define _WIN32_WINNT 0x0500
#else
	#define _WIN32_WINNT 0x0500
#endif
//---------------------------------------------------------------------------
//win version
////#define _WIN32_WINNT_NT4       0x0400	//Windows NT 4.0
////#define _WIN32_WINNT_WIN2K     0x0500	//Windows 2000
////#define _WIN32_WINNT_WINXP     0x0501	//Windows Server 2003, Windows XP
////#define _WIN32_WINNT_WS03      0x0502	//Windows Server 2003 with SP1, Windows XP with SP2
////#define _WIN32_WINNT_WIN6      0x0600	//
////#define _WIN32_WINNT_VISTA     0x0600	//Windows Vista
////#define _WIN32_WINNT_WS08      0x0600	//Windows Server 2008
////#define _WIN32_WINNT_LONGHORN  0x0600	//
////#define _WIN32_WINNT_WIN7      0x0601	//Windows 7

#define xWINVER       	       WINVER	//������� ������ Windows


#define xWIN32_NT4       	   0x0400	//Windows NT 4.0
#define xWIN32_WIN2K     	   0x0500	//Windows 2000
#define xWIN32_WINXP    	   0x0501	//Windows Server 2003, Windows XP
#define xWIN32_WS03      	   0x0502	//Windows Server 2003 with SP1, Windows XP with SP2
#define xWIN32_WIN6     	   0x0600	//
#define xWIN32_VISTA     	   0x0600	//Windows Vista
#define xWIN32_WS08      	   0x0600	//Windows Server 2008
#define xWIN32_LONGHORN  	   0x0600	//
#define xWIN32_WIN7      	   0x0601	//Windows 7
//---------------------------------------------------------------------------
//Remove pointless warning messages
#ifdef _MSC_VER
	#pragma warning (disable : 4511)	//copy operator could not be generated
	#pragma warning (disable : 4512)	//assignment operator could not be generated
	#pragma warning (disable : 4702)	//unreachable code (bugs in Microsoft's STL)
	#pragma warning (disable : 4786)	//identifier was truncated
	#pragma warning (disable : 4996)	//function or variable may be unsafe (deprecated)
	#ifndef _CRT_SECURE_NO_WARNINGS
		#define _CRT_SECURE_NO_WARNINGS //eliminate deprecation warnings for VS2005
	#endif
	////#define _SECURE_SCL 0
#endif // _MSC_VER

#ifdef __INTEL_COMPILER
	////#pragma warning(disable:  383)  // value copied to temporary, reference to temporary used
	////#pragma warning(disable:  444)  // destructor for base class is not virtual
	////#pragma warning(disable:  981)  // operands are evaluated in unspecified order
#endif	//__INTEL_COMPILER

#ifdef __BORLANDC__
    #pragma option -w-8027				//function not expanded inline
#endif
//---------------------------------------------------------------------------
//OBM_ (#include <winuser.h>)
#define OEMRESOURCE

#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <tchar.h>
#include <string>
#include <stdio.h>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <map>
#include <algorithm>
#include <iterator> 
#include <ctime>
////#include <shellapi.h>
//---------------------------------------------------------------------------
//For compilers lacking Win64 support
////#ifndef  GetWindowLongPtr
////	#define GetWindowLongPtr   GetWindowLong
////	#define SetWindowLongPtr   SetWindowLong
////	#define GWLP_WNDPROC       GWL_WNDPROC
////	#define GWLP_HINSTANCE     GWL_HINSTANCE
////	#define GWLP_ID            GWL_ID
////	#define GWLP_USERDATA      GWL_USERDATA
////	#define DWLP_DLGPROC       DWL_DLGPROC
////	#define DWLP_MSGRESULT     DWL_MSGRESULT
////	#define DWLP_USER          DWL_USER
////	#define DWORD_PTR          DWORD
////	#define LONG_PTR           LONG
////	#define ULONG_PTR          LONG
////#endif
////	#ifndef GetClassLongPtr
////	#define GetClassLongPtr    GetClassLong
////	#define SetClassLongPtr    SetClassLong
////	#define GCLP_HBRBACKGROUND GCL_HBRBACKGROUND
////	#define GCLP_HCURSOR       GCL_HCURSOR
////	#define GCLP_HICON         GCL_HICON
////	#define GCLP_HICONSM       GCL_HICONSM
////	#define GCLP_HMODULE       GCL_HMODULE
////	#define GCLP_MENUNAME      GCL_MENUNAME
////	#define GCLP_WNDPROC       GCL_WNDPROC
////#endif

//Strict
#ifndef STRICT
	#define STRICT 1
#endif

//Prevent winsock.h #include's.
#define _WINSOCKAPI_    

//For Visual Studio 6 (without an updated platform SDK) and Dev-C++
#ifndef OPENFILENAME_SIZE_VERSION_400
	#define OPENFILENAME_SIZE_VERSION_400 sizeof(OPENFILENAME)
#endif
//---------------------------------------------------------------------------

#if defined(UNICODE) || defined(_UNICODE)
	#define xT(x)					 (L ## x)
	
	typedef std::wstring             tString;     
	typedef std::basic_string<UCHAR> uString;
	typedef std::wostringstream		 tostringstream; 
	typedef std::wistringstream		 tistringstream;
	typedef std::wifstream			 tifstream;      
	typedef std::wofstream			 tofstream;  

	#define tcout					 (std::wcout)  
#else   
	#define xT(x)					 (x)
	
	typedef std::string              tString;       
	typedef std::basic_string<UCHAR> uString;
	typedef std::ostringstream       tostringstream; 
	typedef std::istringstream       tistringstream;  
	typedef std::ifstream            tifstream;      
	typedef std::ofstream            tofstream;     
	typedef std::ostream             tcout; 

	#define tcout                    (std::cout)   
#endif  /*_UNICODE*/
//---------------------------------------------------------------------------
#include <XLib/Constants.h>

////
#define xDELETE_PTR(p)   	 { if (NULL != (p)) {delete p;      p = NULL;} }
#define xDELETE_ARRAY(a)	 { if (NULL != (a)) {delete [] a;   a = NULL;} } //++memset
#define xRELEASE(p)          { if (NULL != (p)) {p->Release (); p = NULL;} } 
#define xZERO_BUFF(x)        ::ZeroMemory(&x, sizeof(x))
#define xARRAY_SIZE(a)       (sizeof(a) / sizeof(a[0]))
#define xIS_9xME             ((::GetVersion () & 0x80000000) != 0)
#define xMAX(a, b)           { (((a) > (b)) ? (a) : (b)) }
#define xMIN(a, b)           { (((a) < (b)) ? (a) : (b)) }
#define xUNUSED_ARG(arg)	 (arg) = (arg)

#define xKEYDOWN(vk_code)    ((::GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define xKEYUP(vk_code)      ((::GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1) 

#define xGET_X_LPARAM(lp)    ( (INT)(SHORT)LOWORD(lp) )
#define xGET_Y_LPARAM(lp)    ( (INT)(SHORT)HIWORD(lp) )
//---------------------------------------------------------------------------
//Automatically include the XLib namespace define NO_USING_NAMESPACE to skip this step
namespace XLib {}
#ifndef NO_USING_NAMESPACE
    using namespace XLib;
#endif
//---------------------------------------------------------------------------
#include <XLib/CXNonCopyable.h>
#include <XLib/Debug/XAssert.h>
#include <XLib/CXString.h>
#include <XLib/Gui/CXMsgBoxT.h>
//---------------------------------------------------------------------------
#endif  //XLib_CommonH
















 
  //---------------------------------------------------------------------------
  //#undef  FALSE
  //#define FALSE       0
  //
  //#undef  TRUE
  //#define TRUE        1
  //
  //#undef  NULL
  //#define NULL        0
  //
  //#undef  CHAR        
  //#define CHAR        char
  //
  //#undef  WCHAR       
  //#define WCHAR       wchar_t
  //
  //#undef  UCHAR       
  //#define UCHAR       unsigned char
  //
  //#undef  INT        
  //#define INT         int
  //
  //#undef  UINT     
  //#define UINT        unsigned int
  //
  //#undef  SHORT      
  //#define SHORT       short
  //
  //#undef  USHORT      
  //#define USHORT      unsigned short
  //
  //#undef  LONG         
  //#define LONG        long
  //
  //#undef ULONG       
  //#define ULONG       unsigned long

  //#undef long long int
  //#define long long int

  //#undef  LONGLONG    
  //#define LONGLONG    __int64
  //
  //#undef  ULONGLONG   
  //#define ULONGLONG   unsigned __int64 

  //#undef  VOID        (void)
  //#define VOID        void
  //
  //#undef  CONST       const
  //#define CONST       const

  //#undef  LPSTR       
  //#define LPSTR       char *
  //
  //#undef  LPCSTR      
  //#define LPCSTR      const char *
  //
  //#undef  LPWSTR      
  //#define LPWSTR      wchar_t *  
  //
  //#undef  LPWCSTR     
  //#define LPWCSTR     const wchar_t
  //
  //#undef  LPTSTR     
  //#define LPTSTR      wchar_t *
  //
  //#undef  LPTCSTR     
  //#define LPTCSTR     const wchar_t *

  /*
  CHAR        char
  WCHAR       wchar_t
  UCHAR       unsigned char
  INT         int
  UINT        unsigned int
  SHORT       short
  USHORT      unsigned short
  LONG        long
  ULONG       unsigned long
  long long int
  LONGLONG    __int64
  ULONGLONG   unsigned __int64 
  VOID        void
  CONST       const
  LPSTR       char *
  LPCSTR      const char *
  LPWSTR      wchar_t *  
  LPWCSTR     const wchar_t
  LPTSTR      wchar_t *
  LPTCSTR     const wchar_t *
  */
  