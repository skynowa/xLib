/****************************************************************************
* Class name:  -
* Description: ���������
* File name:   Constants.h
* Compilers:   Visual C++ 2010 
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     13.04.2010 17:51:37
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


//---------------------------------------------------------------------------
//[xNULL]
const std::string  xNULL_A           ();
const std::wstring xNULL_W           ();
const tString      xNULL             ();

//[xCR]
const std::string  xCR_A             ("\r");
const std::wstring xCR_W             (L"\r");
const tString      xCR               (_T("\r"));

//[xLF]
const std::string  xLF_A             ("\n");
const std::wstring xLF_W             (L"\n");
const tString      xLF               (_T("\n"));

//[xCRLF]
const std::string  xCRLF_A           (xCR_A + xLF_A);
const std::wstring xCRLF_W           (xCR_W + xLF_W);
const tString      xCRLF             (xCR   + xLF);

//[xCOLON]
const std::string  xCOLON_A          (":");
const std::wstring xCOLON_W          (L":");
const tString      xCOLON            (_T(":"));

//[xWIN_SLASH]
const std::string  xWIN_SLASH_A      ("\\");
const std::wstring xWIN_SLASH_W      (L"\\");
const tString      xWIN_SLASH        (_T("\\"));
//const tString    xWINNIX_SLASH     

//[xNIX_SLASH]
const std::string  xNIX_SLASH_A      ("/");
const std::wstring xNIX_SLASH_W      (L"/");
const tString      xNIX_SLASH        (_T("/"));

//[xEOL]
const std::string  xEOL_A            (xCRLF_A);
const std::wstring xEOL_W            (xCRLF_W);
const tString      xEOL              (xCRLF);

//[xDRIVE_DELIM]
const std::string  xDRIVE_DELIM_A    (xCOLON_A);	//DELIM
const std::wstring xDRIVE_DELIM_W    (xCOLON_W);
const tString      xDRIVE_DELIM      (xCOLON);

//[xPATH_SEP]
const std::string  xPATH_SEP_A       (";");
const std::wstring xPATH_SEP_W       (L";");
const tString      xPATH_SEP         (_T(";"));

//[xDOT]
const std::string  xDOT_A            (".");
const std::wstring xDOT_W            (L".");
const tString      xDOT              (_T("."));

//[x2DOT]
const std::string  x2DOT_A           ("..");
const std::wstring x2DOT_W           (L"..");
const tString      x2DOT             (_T(".."));

//[x3DOT]
const std::string  x3DOT_A           ("...");
const std::wstring x3DOT_W           (L"...");
const tString      x3DOT             (_T("..."));

//[xALL_FILES_MASK]
const std::string  xALL_FILES_MASK_A ("*.*");
const std::wstring xALL_FILES_MASK_W (L"*.*");
const tString      xALL_FILES_MASK   (_T("*.*"));

//[xATTR_DELIMITER]
const std::string  xATTR_DELIMITER_A (xCOLON_A);
const std::wstring xATTR_DELIMITER_W (xCOLON_W);
const tString      xATTR_DELIMITER   (xCOLON);

//[xHORIZ_TAB]
const std::string  xHORIZ_TAB_A      ("\t");
const std::wstring xHORIZ_TAB_W      (L"\t");
const tString      xHORIZ_TAB_TAB    (_T("\t"));

//[xVERT_TAB]
//const std::string  xVERT_TAB_A     = Chr(11);
//const std::wstring xVERT_TAB_W     = L Chr(11);
//const tString      xVERT_TAB       = _T( Chr(11) );

//[xSPACE]
const std::string  xSPACE_A          (" ");
const std::wstring xSPACE_W          (L" ");
const tString      xSPACE            (_T(" "));
//---------------------------------------------------------------------------
////const tString xOPEN_BRACKET          ("{");
////const tString xCLOSE_BRACKET          ("}");
////const tString xOPEN_LINE_COMMENT          ("//");
////const tString xOPEN_COMMENT          ("/*");
////const tString xCLOSE_COMMENT          ("*/");
////
////const tString xASSIGN          ("=");
////const tString xPLUS_ASSIGN          ("+=");
////const tString xMINUS_ASSIGN          ("-=");
////const tString xMULT_ASSIGN          ("*=");
////const tString xDIV_ASSIGN          ("/=");
////const tString xMOD_ASSIGN          ("%=");
////const tString xOR_ASSIGN          ("|=");
////const tString xAND_ASSIGN          ("&=");
////const tString xXOR_ASSIGN          ("^=");
////const tString xGR_GR_ASSIGN          (">>=");
////const tString xLS_LS_ASSIGN          ("<<=");
////const tString xGR_GR_GR_ASSIGN          (">>>=");
////const tString xLS_LS_LS_ASSIGN          ("<<<=");
////const tString xGCC_MIN_ASSIGN          ("<?");
////const tString xGCC_MAX_ASSIGN          (">?");
////
////const tString xEQUAL          ("==");
////const tString xPLUS_PLUS          ("++");
////const tString xMINUS_MINUS          ("--");
////const tString xNOT_EQUAL          ("!=");
////const tString xGR_EQUAL          (">=");
////const tString xGR_GR          (">>");
////const tString xGR_GR_GR          (">>>");
////const tString xLS_EQUAL          ("<=");
////const tString xLS_LS          ("<<");
////const tString xLS_LS_LS          ("<<<");
////const tString xQUESTION_QUESTION          ("??");
////const tString xEQUAL_GR          ("=>");            // C# lambda expression arrow
////const tString xARROW          ("->");
////const tString xAND          ("&&");
////const tString xOR          ("||");
////const tString xCOLON_COLON          ("::");
////const tString xPAREN_PAREN          ("()");
////const tString xBLPAREN_BLPAREN          ("[]");
////
////const tString xPLUS          ("+");
////const tString xMINUS          ("-");
////const tString xMULT          ("*");
////const tString xDIV          ("/");
////const tString xMOD          ("%");
////const tString xGR          (">");
////const tString xLS          ("<");
////const tString xNOT          ("!");
////const tString xBIT_OR          ("|");
////const tString xBIT_AND          ("&");
////const tString xBIT_NOT          ("~");
////const tString xBIT_XOR          ("^");
////const tString xQUESTION          ("?");
////const tString xCOLON          (":");
////const tString xCOMMA          (",");
////const tString xSEMICOLON          (";");
