/****************************************************************************
* Class name:  CXUtils
* Description: PKCS11 �������
* File name:   CXUtils.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:15:59
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXUtilsH
#define XLib_PKCS11_CXUtilsH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXPKCS11.h>
//---------------------------------------------------------------------------
class CXUtils : public CXNonCopyable {
	public:
		CXUtils(const CXPKCS11 &cPKCS11);
	   ~CXUtils();

	   	//-------------------------------------
		//static
        static tString sErrorStr(CK_RV ulRes);
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXUtilsH