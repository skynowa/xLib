/****************************************************************************
* Class name:  CXPin
* Description: PKCS11 ���-���
* File name:   CXPin.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:09:04
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXPinH
#define XLib_PKCS11_CXPinH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXPin : public CXNonCopyable {
	public:
		CXPin(const CXPKCS11 &cPKCS11, const CXSession &cSession);
	   ~CXPin();
	   
		BOOL bInitToken          (CK_SLOT_ID slotID, CK_UTF8CHAR_PTR pPin, CK_ULONG ulPinLen, CK_UTF8CHAR_PTR pLabel);	/*C_InitToken*/		
		BOOL bInitPIN            (CK_UTF8CHAR_PTR pPin, CK_ULONG ulPinLen);		/*C_InitPIN*/
		BOOL bSetPIN             (CK_UTF8CHAR_PTR pOldPin, CK_ULONG ulOldLen, CK_UTF8CHAR_PTR pNewPin, CK_ULONG ulNewLen);	/*C_SetPIN*/
		
		//Utils
		////tString sChangeUserPin  (const AnsiString &casOldUserPin, const AnsiString &casNewUserPin);
		////tString sChangeSOPin    (const AnsiString &casOldSOPin,   const AnsiString &casNewSOPin);
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXPinH
