/****************************************************************************
* Class name:  CXEncrypt
* Description: PKCS11 ����������
* File name:   CXEncrypt.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:10:51
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXEncryptH
#define XLib_PKCS11_CXEncryptH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
#include <XLib/PKCS11/CXSession.h>
//---------------------------------------------------------------------------
class CXEncrypt : public CXNonCopyable {
	public:
		CXEncrypt(const CXPKCS11 &cPKCS11, const CXSession &cSession);
	   ~CXEncrypt();
	   
	   	BOOL bInit	        (CK_MECHANISM_PTR  pMechanism, CK_OBJECT_HANDLE hKey);	/*C_EncryptInit*/	
		BOOL bMake    		(CK_BYTE_PTR pData, CK_ULONG ulDataLen, CK_BYTE_PTR pEncryptedData, CK_ULONG_PTR pulEncryptedDataLen);	/*C_Encrypt*/
		BOOL bUpdate	    (CK_BYTE_PTR pPart, CK_ULONG ulPartLen, CK_BYTE_PTR  pEncryptedPart, CK_ULONG_PTR pulEncryptedPartLen);	/*C_EncryptUpdate*/	
		BOOL bFinal	        (CK_BYTE_PTR pLastEncryptedPart, CK_ULONG_PTR pulLastEncryptedPartLen );	/*C_EncryptFinal*/	
		
		BOOL bSeedRandom	(CK_BYTE_PTR pSeed, CK_ULONG ulSeedLen);	/*C_SeedRandom*/
		BOOL bGenerateRandom(CK_BYTE_PTR RandomData, CK_ULONG ulRandomLen);	/*C_GenerateRandom*/
		
		//Utils
		BOOL bMakeFile      (const tString &csInFilePath, const tString &csOutFilePath, CK_MECHANISM_PTR pMechanism, CK_OBJECT_HANDLE hKey);		
	   	
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
		CK_SESSION_HANDLE    _m_hSession;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXEncryptH
