/****************************************************************************
* Class name:  CXSlot
* Description: PKCS11 ����
* File name:   CXSlot.h
* Compilers:   Visual C++ 2008
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib, Aladdin eToken SDK
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     01.03.2010 13:07:29
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef XLib_PKCS11_CXSlotH
#define XLib_PKCS11_CXSlotH
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <XLib/PKCS11/Common.h>
#include <XLib/PKCS11/CXPKCS11.h>
//---------------------------------------------------------------------------
class CXSlot : public CXNonCopyable {
	public:
		CXSlot(const CXPKCS11 &cPKCS11);
	   ~CXSlot();

	   	BOOL  bGetList        (CK_BBOOL bTokenPresent, CK_SLOT_ID_PTR pSlotList, CK_ULONG_PTR pulCount);	/*C_GetSlotList*/
		BOOL  bGetInfo        (CK_SLOT_ID slotID, CK_SLOT_INFO_PTR pInfo);								/*C_GetSlotInfo*/	
		BOOL  bWaitForEvent   (CK_FLAGS flags, CK_SLOT_ID_PTR pSlot, CK_VOID_PTR pRserved);				/*C_WaitForSlotEvent*/	
	   	
	private:
		BOOL  _m_bRes;
		CK_RV _m_ulRes;

		CK_FUNCTION_LIST_PTR _m_pFunc;
};
//---------------------------------------------------------------------------
#endif	//XLib_PKCS11_CXSlotH