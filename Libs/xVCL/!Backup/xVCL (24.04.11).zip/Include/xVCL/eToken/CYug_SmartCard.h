/**********************************************************************
*	����� CYug_SmartCard (CYug_SmartCard.h)
*
***********************************************************************/


#ifndef CYug_SmartCardH
#define CYug_SmartCardH       
//---------------------------------------------------------------------------
#include <pkcs11.h>
#include <eTSAPI.h>
#include <otp-pkcs11.h>

#include <stdio.h>
#include <stdlib.h>
#include <winscard.h>   //vEnumReaderList
#include <wincrypt.h>   //vEnumReaderList
#include <iostream>     //STL vEnumReaderList
#include <iomanip>      //STL vEnumReaderList
#include <vector>       //STL vEnumReaderList

#include <system.hpp>   //AnsiString
#include <Classes.hpp>  //TStringList
//---------------------------------------------------------------------------
#define DEBUG_(MSG)       MessageBox(0, AnsiString(MSG).c_str(), "Debug", MB_OK)
#define MSG_WARNING(MSG)  MessageBox(0, AnsiString(MSG).c_str(), Application->Title.c_str(), MB_OK + MB_ICONSTOP        + MB_TOPMOST)
#define MSG_INFO(MSG)     MessageBox(0, AnsiString(MSG).c_str(), Application->Title.c_str(), MB_OK + MB_ICONINFORMATION + MB_TOPMOST)

#define APPLICATION_TITLE "eToken"
#define LOG_FILE          "___Log.txt"
#define EMPTY_MSG         "=�����������\n"
#define ETPKCS11_PATH     "DLL\\eTPKCS11.dll"	//���� � eTPKCS11.dll
#define ETSAPI_PATH       "DLL\\eTSAPI.dll"     //���� � eTSAPI.dll
#define TRUE_MSG          "��"
#define FALSE_MSG         "���"
#define TOKEN_NON_PRESENT  - 1
//---------------------------------------------------------------------------
class CYug_SmartCard {
	public:
	    /*+*/CYug_SmartCard();
		/*+*/~CYug_SmartCard();
		
        TStringList   *vEnumReaderList();
		AnsiString     asSmartCardErrorString(DWORD dwRV);
        
    private:
 
};
//---------------------------------------------------------------------------
#endif