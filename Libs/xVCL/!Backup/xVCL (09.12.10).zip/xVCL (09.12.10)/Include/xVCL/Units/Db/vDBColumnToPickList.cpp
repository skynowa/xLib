/**********************************************************************
*	vDBColumnToPickList -
*
***********************************************************************/


//---------------------------------------------------------------------------
void vDBColumnToPickList(TDBGrid *pDBGrid, int iColumn, TADOConnection *pADOConnection, const String &csTableName, const String &csFieldName) {
	/*DEBUG*/xASSERT(NULL  != pDBGrid);
	/*DEBUG*/xASSERT(0     <= iColumn);
	/*DEBUG*/xASSERT(NULL  != pADOConnection);
	/*DEBUG*/xASSERT(false == csTableName.IsEmpty());
    /*DEBUG*/xASSERT(false == csFieldName.IsEmpty());

	std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(NULL));
    /*DEBUG*/xASSERT(NULL != apqryTmp.get());

	try {
		apqryTmp->Connection = pADOConnection;
		apqryTmp->Close();
		apqryTmp->SQL->Text = _T("SELECT ") + csFieldName + _T(" FROM ") + csTableName + _T("  ORDER BY ") + csFieldName + _T(" ASC;"); 	//ShowMessage(apqryTmp->SQL->Text);
		apqryTmp->Open();
        apqryTmp->First();
        pDBGrid->Columns->Items[iColumn]->PickList->Clear();
		while (! apqryTmp->Eof) {
			if (false == apqryTmp->FieldByName(csFieldName)->IsNull) {
                pDBGrid->Columns->Items[iColumn]->PickList->Add(apqryTmp->FieldByName(csFieldName)->Value);
            }
            apqryTmp->Next();
		}
        apqryTmp->Close();

        pDBGrid->Columns->Items[iColumn]->DropDownRows = 20;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }
}
//---------------------------------------------------------------------------
