/****************************************************************************
* Unit name:   bDBGrid_ExcelExport
* Description: export to MS Excel
* File name:   bDBGrid_ExcelExport.cpp
* Compilers:   C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Alca
* E-mail:      dr.web.agent@gmail.com
* Created:     23.11.2010 16:11:03
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include "bDBGrid_ExcelExport.h"

#include <ADODB.hpp>
#include <DB.hpp>


//---------------------------------------------------------------------------
//TODO: bDBGrid_ExcelExport
BOOL bDBGrid_ExcelExport(
	TJvDBUltimGrid *dbgrdGrid, 
	BOOL            bIsSilent,
	BOOL            bIsPortraitOrientation,
	BOOL            bIsLineNumbering, 
	INT             iFontSize,
	BOOL            bIsPrintPreview
) 
{
	/*DEBUG*/xASSERT_RET(NULL != dbgrdGrid, FALSE);
	/*DEBUG*/// bIsLineNumbering - n/a
	/*DEBUG*/xASSERT_RET(0     < iFontSize, FALSE);

	BOOL bRes      = FALSE;
	INT  iRowCount = dbgrdGrid->DataSource->DataSet->RecordCount;
	INT  iColCount = dbgrdGrid->Columns->Count;

	//-------------------------------------
	//excel launch
	CxExcel exlExcel;
	LONG    liBookIndex  = - 1;
	LONG    liSheetIndex = 1;

	bRes = exlExcel.bCreate();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = exlExcel.bVisible(!bIsSilent);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = exlExcel.bEnableEvents(FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = exlExcel.bWorkbooksAdd();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	liBookIndex = exlExcel.liWorkbooksCount();
	/*DEBUG*/xASSERT_RET(0 < liBookIndex, FALSE);

	bRes = exlExcel.bSheetSetupOrientation(liBookIndex, liSheetIndex, (TRUE == bIsPortraitOrientation) ? (CxExcel::poPortrait) : (CxExcel::poLandscape));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = exlExcel.bSheetSetupPrintTitleRows(liBookIndex, liSheetIndex, xT("$1:$1"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//table header
	for (INT r = 1, c = 0; c < iColCount; ++ c) {
		xCHECK_DO(false == dbgrdGrid->Columns->Items[c]->Visible, continue);

		String sHeader = dbgrdGrid->Columns->Items[c]->Title->Caption;

		bRes = exlExcel.bSheetSetCell(liBookIndex, liSheetIndex, r, c, sHeader, dbgrdGrid->Columns->Items[c]->Width / 7, dbgrdGrid->RowsHeight / 1.5, TRUE, TRUE, TRUE, iFontSize, TRUE, 1, TRUE, TRUE, TRUE, TRUE);
		/*DEBUG*/xASSERT_DO(FALSE != bRes, FALSE);
	}

	//-------------------------------------
	//table data
	if (0 < iRowCount) {
		const INT ciBounds[4] = {0, iRowCount, 0, iColCount};
		Variant   vDataArray  = VarArrayCreate(ciBounds, 3, varVariant);

		try {
			TADOQuery *pqryADO = static_cast<TADOQuery *>(dbgrdGrid->DataSource->DataSet);
			/*DEBUG*/xASSERT_RET(NULL != pqryADO, FALSE);

			TBookmark bmSavePlace = pqryADO->GetBookmark();

			pqryADO->First();

			for (INT r = 0, iSkippedCols = 0; r < iRowCount; ++ r) {
				for (INT c = 0; c < iColCount; ++ c) {
					String sData;
					
					//field is hidden
					if (false == dbgrdGrid->Columns->Items[c]->Visible) {	
						++ iSkippedCols;
						continue;
					} 
					//field is not tied to the DB
					else if (NULL == dbgrdGrid->Fields[c]) {				
						//if the column "�", then enumerate the rows of
						if (xT("�") == dbgrdGrid->Columns->Items[c]->Title->Caption && TRUE == bIsLineNumbering) {
							sData = IntToStr(r + 1);
						} else {
							//or skipping
							++ iSkippedCols;
							continue;
						}
					}
					//field is empty
					else if (true == dbgrdGrid->Fields[c]->IsNull) {		
						sData = xT("");
					}
					//field is filled
					else {
						sData = dbgrdGrid->Fields[c]->AsString.Trim();         	
					}

					//value to an array
					vDataArray.PutElement(sData, r, c - iSkippedCols);
				}
				pqryADO->Next();
				iSkippedCols = 0;
			}

			pqryADO->GotoBookmark(bmSavePlace);
			pqryADO->FreeBookmark(bmSavePlace);
		} catch (Exception &e) {
			/*DEBUG*/xASSERT_MSG(FALSE, xD2AS(e.Message).c_str());
		} catch (...) {
			/*DEBUG*/xASSERT_MSG(FALSE, xT("Uknown error"));
		}

		//-------------------------------------
		//filling the table data
		INT  iBeginRow = 1 + 1;		//data starts from 2-d row
		INT  iBeginCol = 1;

		INT  iEndRow   = iBeginRow + iRowCount - 1;
		INT  iEndCol   = iBeginCol + iColCount - 2;

		bRes = exlExcel.bSheetSetCells(liBookIndex, liSheetIndex, iBeginRow, iBeginCol, iEndRow, iEndCol, vDataArray, - 1, dbgrdGrid->RowsHeight / 1.5, TRUE, TRUE, TRUE, iFontSize, TRUE, 1, TRUE, TRUE, TRUE, TRUE);
		/*DEBUG*/xASSERT_DO(FALSE != bRes, FALSE);

		//-------------------------------------
		//TODO: special for Savitskiy V.
		#if defined(xSPECIAL_FOR_SAVITSKIY)
		{
			#pragma message("[CxExcel::bSetColumnNumberFormat] special for Savitskiy V., it must remove from working code")

			const LONG   cliDateColumn  = 2;
			const String csNumberFormat = xT("��.��.����;@");

			bRes = exlExcel.bSetColumnNumberFormat(liBookIndex, liSheetIndex, cliDateColumn, csNumberFormat);
			/*DEBUG*/xASSERT_DO(FALSE != bRes, FALSE);		
		}
		#endif
	}

	//-------------------------------------
	//showing
	bRes = exlExcel.bVisible(TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	if (TRUE == bIsPrintPreview) {
		bRes = exlExcel.bWorksheetsPrintPreview(liBookIndex);
		/*DEBUG*/xASSERT_DO(FALSE != bRes, FALSE);
	}

	return TRUE;
}
//---------------------------------------------------------------------------