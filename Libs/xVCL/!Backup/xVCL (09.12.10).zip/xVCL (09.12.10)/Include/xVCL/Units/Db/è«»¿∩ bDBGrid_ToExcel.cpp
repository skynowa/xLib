/**********************************************************************
*	vDBGridSelectedRowsToClip 
*
***********************************************************************/


#include <XVCL/Classes/Ole/CxExcel.h>
#include <JvDBUltimGrid.hpp>


//---------------------------------------------------------------------------
//TODO: bDBGrid_ToExcel
BOOL bDBGrid_ToExcel(TJvDBUltimGrid *dbgrdGrid, CxExcel *pexlExcel, BOOL bIsLineNumbering, INT iFontSize) {
	/*DEBUG*/xASSERT_RET(NULL != dbgrdGrid, FALSE);
	/*DEBUG*/xASSERT_RET(NULL != pexlExcel, FALSE);
	/*DEBUG*/// bIsLineNumbering - n/a

	BOOL       bRes           = FALSE;
	LONG       liBookIndex    = - 1;
	TADOQuery *pqryADO        = NULL;
	INT        iColomnPosFrom = - 1;	//���� TRUE = bIsLineNumbering, �� ������ ���������� �� 1-�� �������
	INT        iColomnPosTo   = - 1;	//���� TRUE = bIsLineNumbering, �� ������ ���������� �� 1-�� �������

	bRes = pexlExcel->bCreate();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = pexlExcel->bEnableEvents(FALSE);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = pexlExcel->bWorkbooksAdd();
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	liBookIndex = pexlExcel->liWorkbooksCount();
	/*DEBUG*/xASSERT_RET(0 < liBookIndex, FALSE);

	bRes = pexlExcel->bSheetSetupOrientation(liBookIndex, 1, CxExcel::poLandscape);
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	bRes = pexlExcel->bSheetSetupPrintTitleRows(liBookIndex, 1, xT("$1:$1"));
	/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

	//-------------------------------------
	//��������� �����
	if (TRUE == bIsLineNumbering) {
		String sHeaderCell = xT("�");

		bRes = pexlExcel->bSheetSetCell(liBookIndex, 1, 1, 1, sHeaderCell);
		/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);

		for (INT r = 2, iLineNo = 1; r < dbgrdGrid->DataSource->DataSet->RecordCount + 2; ++ r, ++ iLineNo) {
			bRes = pexlExcel->bSheetSetCell(liBookIndex, 1, r, 1, IntToStr(iLineNo), - 1, dbgrdGrid->RowsHeight, TRUE, TRUE, TRUE, iFontSize, FALSE, 1, TRUE, TRUE, TRUE, TRUE);
			/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
		}
		
		//����� �����
		iColomnPosFrom = (0) + 1;
		iColomnPosTo   = (dbgrdGrid->Columns->Count - 1) + 1;
	} else {
		//��� ������ �����
		iColomnPosFrom = 0;
		iColomnPosTo   = dbgrdGrid->Columns->Count - 1;
	}

	//-------------------------------------
	//���������
	for (INT c = iColomnPosFrom; c < iColomnPosTo/*dbgrdGrid->Columns->Count - 1*/; ++ c) {
		xCHECK_DO(false == dbgrdGrid->Columns->Items[c]->Visible, continue);

		String sHeaderCell = dbgrdGrid->Columns->Items[c]->Title->Caption;

		bRes = pexlExcel->bSheetSetCell(liBookIndex, 1, 1, c, sHeaderCell, dbgrdGrid->Columns->Items[c]->Width / 7, dbgrdGrid->RowsHeight, TRUE, TRUE, TRUE, iFontSize, TRUE, 1, TRUE, TRUE, TRUE, TRUE);
		/*DEBUG*/xASSERT_RET(FALSE != bRes, FALSE);
	}

	//-------------------------------------
	//������
	INT     iRowCount  = dbgrdGrid->DataSource->DataSet->RecordCount;
	INT     iColCount  = dbgrdGrid->DataSource->DataSet->FieldDefs->Count;

	const INT ciBounds[4] = {0, iRowCount, 0, iColCount};
	Variant   vDataArray  = VarArrayCreate(ciBounds, 3, varVariant);

////	for (INT i = 0; i < RowCount; ++ i) {
////		for (INT j = 0; j < ColCount; ++ j) {
////			vData.PutElement(/*AGrid->Cells[j][i]*/0, i, j);
////		}
////	}

   ///	Variant ArrayData = VarArrayCreate({1, RowCount, 1, ColCount}, varVariant);


	try {
		TADOQuery *pqryADO    = static_cast<TADOQuery *>( dbgrdGrid->DataSource->DataSet );
		/*DEBUG*/xASSERT_RET(NULL != pqryADO, FALSE);

		TBookmark bmSavePlace = pqryADO->GetBookmark();

		pqryADO->First();
		for (INT r = 2; ! pqryADO->Eof; ++ r) {
			for (INT c = iColomnPosFrom; c < iColomnPosTo/*c < dbgrdGrid->Columns->Count - 1*/; ++ c) {
				String sDataCell;

				if (false == dbgrdGrid->Columns->Items[c]->Visible) {	//���� ������
					continue; 
				} 
				else 
				if (NULL  == dbgrdGrid->Fields[c]) {					//���� �� ��������� � ��
					continue;
				}
				else 
				if (true  == dbgrdGrid->Fields[c]->IsNull) {			//���� ������
					sDataCell = xT("");
				}
				else {
					sDataCell = dbgrdGrid->Fields[c]->AsString;         //���� ���������
				}

//				bRes = pexlExcel->bSheetSetCell(liBookIndex, 1, r, c, sDataCell, - 1, - 1, TRUE, TRUE, TRUE, iFontSize, FALSE, 1, TRUE, TRUE, TRUE, TRUE);
//				/*DEBUG*/xASSERT_DO(FALSE != bRes, break);
				vDataArray.PutElement(sDataCell, r - 2, c - 1);
			}
			pqryADO->Next();
		}

        pqryADO->GotoBookmark(bmSavePlace);
        pqryADO->FreeBookmark(bmSavePlace);
	} catch (Exception &e) {
		/*DEBUG*/xASSERT_MSG(FALSE, xD2AS(e.Message).c_str());
	} catch (...) {
		/*DEBUG*/xASSERT_MSG(FALSE, xT("Uknown error"));
	}

	iMsgBox(xT("vDataArray"));
	bRes = pexlExcel->bSheetSetCell(liBookIndex, 1, 1, 1, 12, iColomnPosTo - 1, vDataArray);
	/*DEBUG*/xASSERT_DO(FALSE != bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------