/**********************************************************************
*	vDBGrid_MouseScrolling - ��������� DBGrid ������� ����
*
***********************************************************************/


//---------------------------------------------------------------------------
//TODO: vDBGrid_MouseScrolling (��������� DBGrid ������� ����)
VOID vDBGrid_MouseScrolling(TDBGrid *pdbgrdDBGrid, tagMSG &Msg, bool &Handled) {
    /*DEBUG*/xASSERT_DO(NULL != pdbgrdDBGrid, return);

	if (WM_MOUSEWHEEL == Msg.message) {
        Msg.message = WM_KEYDOWN;
        Msg.lParam  = 0;

		INT i = DWORD(Msg.wParam);
		if (i > 0) {
            Msg.wParam = VK_UP;
        } else {
            Msg.wParam = VK_DOWN; 
		}

        Handled = false;
	}
}
//---------------------------------------------------------------------------