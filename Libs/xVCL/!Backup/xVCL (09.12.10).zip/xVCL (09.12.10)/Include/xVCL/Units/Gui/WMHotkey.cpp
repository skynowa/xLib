/**********************************************************************
*   WMHotkey
*
***********************************************************************/


////void __fastcall TfrmMainClient::WMHotkey(TMessage &Msg) {
////    if (frmMainClient->Visible == true) {
////        frmMainClient->Visible = false;
////    } else {
////        frmMainClient->Visible = true;
////    }
////}

