/**********************************************************************
*	�����  CxAccess (CxAccess.h)
*
***********************************************************************/


#ifndef XVCL_OLE_CxAccessH
#define XVCL_OLE_CxAccessH
//---------------------------------------------------------------------------
#include <XLib/xCommon.h>
#include <XLib/Fso/CxPath.h>
#include <XLib/Fso/CxFile.h>

#include <XVCL/xCommon.h>
#include <ComObj.hpp>   //OLE
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class CxAccess : public CxNonCopyable {
	public:
        		CxAccess          ();
        	   ~CxAccess          ();

		BOOL    bIsMdbFile        (const String &csFilePath);
		BOOL    bIsOleAppInstalled(const String &csApplicationString);
		BOOL    bCreateResMdb     (const String &csFilePath, const String &csResource);
		BOOL    bCreateAdoMdb     (const String &csMdbFilePath);
		BOOL    bCompactMdb       (const String &csMdbFilePath, const String &csPass1, const String &csPass2);
		String  sGetADOVersion    ();
	
	private:
		BOOL    _m_bRes;
		Variant _m_vRes;

};
//---------------------------------------------------------------------------
#endif	//XVCL_OLE_CxAccessH
