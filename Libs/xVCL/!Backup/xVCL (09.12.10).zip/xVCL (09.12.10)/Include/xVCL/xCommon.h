#ifndef xVCL_CommonH
#define xVCL_CommonH
//---------------------------------------------------------------------------
#include <vcl.h>
#include <tchar.h>
#include <SysUtils.hpp>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <memory>
#include <vector>
////#include <assert.h>
////#include <shlwapi.h>

#include <XLib/Debug/CxAssert.h>

#pragma hdrstop
//---------------------------------------------------------------------------
#endif  //xVCL_CommonH