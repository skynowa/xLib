/**********************************************************************
*	����� CPerform (CPerform.cpp)
*
***********************************************************************/


#include "CPerform.h"
#include "Unit1.h"        //frmMain
#include <SysUtils.hpp>
//---------------------------------------------------------------------------
//TODO: CPerform
CPerform::CPerform() {	
	vResetData();
	vSetLogName("___Log.txt");
	
	vLog("------------------------------");
}
//---------------------------------------------------------------------------
//TODO: ~CPerform
CPerform::~CPerform() {	
	vLog("------------------------------");
}
//--------------------------------------------------------------------------
//TODO: vStart
void CPerform::vStart(int iPerformMode) {
    if (iPerformMode > 3 || iPerformMode < 0) {
        bWasStarted = false;
        MSG_WARNING("���������� �����");
        return;
    }
    iPerfomModeNow = iPerformMode;

    switch (iPerfomModeNow) {
        //Time
        case pmTime:
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
            dtBeginTime = Time();
            break;

        //pmGetTickCount
		case pmGetTickCount:
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
            dwBeginTime = GetTickCount();
            break;
		
		//QueryPerformanceCounter
        case pmQueryPerformanceCounter:
			if (!QueryPerformanceFrequency(&liFrequency)) {
				MSG_WARNING("��������� ����������");
				return;
			}
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
			QueryPerformanceFrequency(&liBeginCount);
            break;

		//pmGetThreadTimes
		case pmGetThreadTimes:
			SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
			GetThreadTimes(GetCurrentThread(), &lpCreationTime, &lpExitTime, &lpKernelTime0, &lpUserTime0);
            break;
		
        default:	
            MSG_WARNING("���������� �����");
            break;
    }

    bWasStarted = true;
}
//--------------------------------------------------------------------------
//TODO: vStop
void CPerform::vStop() {
    if (bWasStarted == false) {
        return;
    }

    switch (iPerfomModeNow) {
        //Time (�����)
        case pmTime:
            dtEndTime = Time(); 
            vLog((dtEndTime - dtBeginTime).FormatString("hh:nn:ss:zz"));
            break;

        //QueryPerformanceCounter (�����)
        case pmQueryPerformanceCounter: 
            QueryPerformanceCounter(&liEndCount);
            liCount.QuadPart = liEndCount.QuadPart - liBeginCount.QuadPart;
            vLog(IntToStr(liCount.QuadPart * 1000 / liFrequency.QuadPart));
            break;
			
		//pmGetThreadTimes (��������)
		case pmGetThreadTimes:  
			GetThreadTimes(GetCurrentThread(), &lpCreationTime, &lpExitTime, &lpKernelTime1, &lpUserTime1);
			vLog(asMilliSecToTimeString((iFiletimeToint64(lpUserTime1) - iFiletimeToint64(lpUserTime0)) / 10000));	//10000 - ������������; 10 - ������������
            break;
			
		//pmGetTickCount (��������)
		case pmGetTickCount:
            dwEndTime = GetTickCount();
			vLog(asMilliSecToTimeString(dwEndTime - dwBeginTime));
            break;
    }

	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
	iPerfomModeNow = pmTime;
	vResetData();
}
//--------------------------------------------------------------------------
//TODO: iFiletimeToint64
__int64 CPerform::iFiletimeToint64(FILETIME F) {
	return Int64ShllMod32(F.dwHighDateTime, 32) | F.dwLowDateTime;
}
//---------------------------------------------------------------------------
//TODO: vResetData
void CPerform::vResetData() {
    iPerfomModeNow                = pmGetThreadTimes;
    bWasStarted                   = false;

    //DateTime
    dtBeginTime                   = 0;
    dtEndTime                     = 0;
	
	//pmGetTickCount
	dwBeginTime                   = 0;
	dwEndTime                     = 0;

    //QueryPerformanceCounter
    liFrequency.QuadPart          = 0;
	liBeginCount.QuadPart         = 0;
	liEndCount.QuadPart           = 0;

	//GetThreadTimes
	lpCreationTime.dwLowDateTime  = 0;
    lpCreationTime.dwHighDateTime = 0;
	lpExitTime.dwLowDateTime      = 0;
    lpExitTime.dwHighDateTime     = 0;
	lpKernelTime0.dwLowDateTime   = 0;
    lpKernelTime0.dwHighDateTime  = 0;
	lpUserTime0.dwLowDateTime     = 0;
    lpUserTime0.dwHighDateTime    = 0;
	lpKernelTime1.dwLowDateTime   = 0;
    lpKernelTime1.dwHighDateTime  = 0;
	lpUserTime1.dwLowDateTime     = 0;
    lpUserTime1.dwHighDateTime    = 0;
}
//---------------------------------------------------------------------------
//TODO: vDeleteLog
void CPerform::vDeleteLog() {
    if (FileExists(asLogPath) == true) {
        FileSetAttr(asLogPath, 0);
        DeleteFile(asLogPath);
    }
}
//---------------------------------------------------------------------------
//TODO: vSetLogPath
void CPerform::vSetLogPath(const AnsiString &casFilePath) {
	asLogPath = asLogPath;
}
//---------------------------------------------------------------------------
//TODO: vSetLogName
void CPerform::vSetLogName(const AnsiString &casFileName) {
	asLogName = casFileName;
	asLogPath = GetCurrentDir() + "\\" + casFileName;
}
//---------------------------------------------------------------------------
//TODO: vOpenLog
void CPerform::vOpenLog() {
	ShellExecute(NULL, NULL, asLogPath.c_str(), NULL, NULL, SW_SHOW);
	/*if (GetLastError() != 0) {
        vErrorMessageBox();
	}*/
}
//---------------------------------------------------------------------------
//TODO: vLog
void CPerform::vLog(const AnsiString &casFileText) {
	FILE* pFile = NULL;
	
    if ((pFile = fopen(asLogPath.c_str(), "a")) == NULL) {
        vErrorMessageBox();
    } else {
        fprintf(pFile, "[%s]  %s\n", (Now().FormatString("hh:nn:ss:zz")), casFileText.c_str());
        fclose(pFile);
    }
}
//---------------------------------------------------------------------------
//TODO: vErrorMessageBox
void CPerform::vErrorMessageBox() {
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
	LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------
//TODO: asMilliSecToTimeString
AnsiString CPerform::asMilliSecToTimeString(unsigned short usMilliSec) {
	#include <systypes.h>
    
	#define HOUR(time)    ((uint16)((uint32)(time) / 3600000))
	#define MIN(time)     ((uint16)(((uint32)(time) % 3600000) / 60000))
	#define SEC(time)     ((uint16)((((uint32)(time) % 3600000) % 60000) / 1000))
	#define MSEC(time)    ((uint16)((uint32)(time) % 1000l))

	TDateTime dtD(HOUR(usMilliSec), MIN(usMilliSec), SEC(usMilliSec), MSEC(usMilliSec));

	unsigned short usHour, usMin, usSec, usMSec;
	DecodeTime(dtD, usHour, usMin, usSec, usMSec);

    return AnsiString(0).sprintf("%.2i:%.2i:%.2i:%.3i", usHour, usMin, usSec, usMSec);
}
//---------------------------------------------------------------------------