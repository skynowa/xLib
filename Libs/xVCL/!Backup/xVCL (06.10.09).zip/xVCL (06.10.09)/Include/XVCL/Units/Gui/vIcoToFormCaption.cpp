/***********************************************************************
*   vIcoToSpeedBtn   
*
************************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vIcoToFormCaption(TForm *pFrm, const AnsiString &casAssociateFileExt, const AnsiString &casFrmCaption) {    //".exe"
    /*DEBUG*/XASSERT(NULL != pFrm);

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
    /*DEBUG*/XASSERT(NULL != apImageList.get());

    //-------------------------------------
    //��������� ������
    AnsiString asFilePath = "";
    if (true == casAssociateFileExt.IsEmpty()) {
        //��������� ������ (������ �����)
    } else {
    #ifdef BC_DEF
        asFilePath = asSearchFileEx(casAssociateFileExt, BASE_PATH + "Project" + "\\");
    #endif
    #ifdef VC_DEF
        asFilePath = asSearchFileEx(casAssociateFileExt, BASE_PATH + "Project" + "\\" + "Debug" + "\\");

        if (asFilePath.IsEmpty() == true) {
            asFilePath = asSearchFileEx(casAssociateFileExt, BASE_PATH + "Project" + "\\" + "Realese"+ "\\");
        }
    #endif
    }

    TSHFileInfo sfInfo;   ::ZeroMemory(&sfInfo, sizeof(sfInfo));
    DWORD dwImageHandle = ::SHGetFileInfo(asFilePath.c_str(),
                                        0,
                                        &sfInfo,
                                        sizeof(sfInfo),
                                        SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);
                                        
    if (0 != dwImageHandle) {
        apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }

	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/XASSERT(NULL != apIcon.get());
    apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
    apIcon.get()->Transparent = true;

	//-------------------------------------
	//����� + �����   
    pFrm->Icon    = apIcon.get();
#ifdef BC_DEF
    pFrm->Caption = casFrmCaption + "  [Borland C++ project]";
#endif
#ifdef VC_DEF
    pFrm->Caption = casFrmCaption + "  [Visual C++ project]";
#endif
}
//---------------------------------------------------------------------------


