/***********************************************************************
*	������� ��������� ����
*
************************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vBringToFrontWindow(HWND hWnd) {
    /*DEBUG*/XASSERT(NULL != hWnd);

	HWND hCurrWnd = ::GetForegroundWindow();
	int  iMyTID   = ::GetCurrentThreadId();
	int  iCurrTID = ::GetWindowThreadProcessId(hCurrWnd, 0);

	::AttachThreadInput  (iMyTID, iCurrTID, TRUE);
	::SetForegroundWindow(hWnd);
	::AttachThreadInput  (iMyTID, iCurrTID, FALSE);
}
//---------------------------------------------------------------------------
