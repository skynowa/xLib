/***********************************************************************
*   vShowDlgProperties
*
************************************************************************/



//---------------------------------------------------------------------------
void __fastcall TfrmMain::vShowDlgProperties(const UnicodeString &cusFilePath) {
	typedef BOOL (WINAPI *SHOBJECTPROPERTIES)(HWND hwnd, DWORD dwType, LPCWSTR lpObject, LPCWSTR lpPage);

	#ifndef SHOP_FILEPATH
	#define SHOP_FILEPATH		    0x00000002
	#endif

	#define SHOP_EXPORT_ORDINAL     178

	SHOBJECTPROPERTIES pSHObjectProperties = (SHOBJECTPROPERTIES)::GetProcAddress(::LoadLibrary(L"shell32"), (LPCSTR)"SHObjectProperties");

	if (!pSHObjectProperties) {
		pSHObjectProperties = (SHOBJECTPROPERTIES)::GetProcAddress(::LoadLibrary(L"shell32"), (LPCSTR)SHOP_EXPORT_ORDINAL);
	}

	if (pSHObjectProperties) {
		pSHObjectProperties(Handle, SHOP_FILEPATH, cusFilePath.t_str(), 0);
	}
}
//---------------------------------------------------------------------------