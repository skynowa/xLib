/**********************************************************************
*
*
***********************************************************************/


#include "uWLMaster.h"

//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asRemoveWhiteSpaces(AnsiString &asInputStr, const AnsiString &asRegExprRemoveTag) {   
    Application->ProcessMessages();
    
    TRegExpr *pR = new TRegExpr;
    {
        pR->ModifierI = true;
        pR->ModifierM = false;
        pR->ModifierS = true;
        pR->ModifierX = false;
        pR->ModifierG = false;
        pR->ModifierR = true;

        pR->Expression = asRegExprRemoveTag;
    }

    AnsiString asOutStr = "";

	if (pR->Exec(asInputStr)) {
        asOutStr = pR->Replace(asInputStr, "", true);   //ShowMessage(asOutStr);
	} else {
        asOutStr = asInputStr;
    }
	pR->Free();

    return asOutStr;
}
//---------------------------------------------------------------------------