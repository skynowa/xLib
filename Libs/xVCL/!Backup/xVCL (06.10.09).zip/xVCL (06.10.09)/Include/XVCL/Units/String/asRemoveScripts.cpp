/**********************************************************************
*    ������� �������
*
***********************************************************************/


//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asRemoveScripts(AnsiString &asInputStr, const AnsiString &asRegExprRemoveTag) {   
    Application->ProcessMessages();

    AnsiString asT = asInputStr;

    TRegExpr *pR = new TRegExpr;
    {
        pR->ModifierI = true;
        pR->ModifierM = false;
        pR->ModifierS = true;
        pR->ModifierX = false;
        pR->ModifierG = false;
        pR->ModifierR = true;

        pR->Expression = asRegExprRemoveTag;
    }

    AnsiString asOutStr = "";

    if (pR->Exec(asT)) {
        while (pR->Match[0] != "") {    //ShowMessage(pR->Match[0]);
            //���� �������� ����. ���� - ����������
            AnsiString asTemp = pR->Match[0].Delete(1, 1).LowerCase().Pos("<script");
            if (asTemp != 0) {
                //���� �������� ����. "document.write" - �������
                if (asTemp.LowerCase().Pos("document.write") == 0) {
                    ShowMessage(asTemp.LowerCase().Pos("document.write"));
                    asOutStr = pR->Replace(pR->Match[0], "", true);
                }
            } else {
                 asOutStr = pR->Replace(pR->Match[0], "", true);
            }

            pR->ExecNext();
        }

    } else {
        asOutStr = asT;
    }
    pR->Free();

    return asOutStr;
}
//---------------------------------------------------------------------------