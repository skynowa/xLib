/***********************************************************************
*	��������� IE � ����� ����
*
************************************************************************/



//---------------------------------------------------------------------------
void __fastcall TfrmMain::vOpenHTTP(const UnicodeString &usURL) {
	//--ShellExecute(NULL, NULL, "explorer.exe", ("http://" + asURL).c_str(), NULL, SW_SHOW);
	////ShellExecuteW(NULL, NULL, L"explorer.EXE", (L"/e, http://" + usURL).w_str(), NULL, SW_SHOW);
	ShellExecuteW(NULL, NULL, L"IEXPLORE.EXE", usURL.w_str(), NULL, SW_SHOW);

////    Variant IE;
////    IE = Variant::CreateObject("InternetExplorer.Application");
////    IE.OlePropertySet("Visible", true);
////    IE.OleProcedure("Navigate", (WideString)asURL);
////    IE = Unassigned;
}
//---------------------------------------------------------------------------
