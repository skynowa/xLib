/**********************************************************************
* �������� ��������� �������
*
***********************************************************************/


//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asReplaceBreaks(AnsiString asString) {
    char          szFatalChars[] = {'\r'};
    TReplaceFlags flags;           flags << rfReplaceAll << rfIgnoreCase;

    for (int i = 0; i < sizeof(szFatalChars) / sizeof(szFatalChars[0]); i ++) {
        asString = StringReplace(asString, szFatalChars[i], "", flags);
	}

    return asString;
}
//---------------------------------------------------------------------------
