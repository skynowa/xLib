/**********************************************************************
*	vAddImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vAddImage(TImage *pImage, TADOQuery* pADOQuery, const UnicodeString &cusFieldName) {
	/*DEBUG*/assert(NULL  != pImage);
	/*DEBUG*/assert(NULL  != pADOQuery);
	/*DEBUG*/assert(false == cusFieldName.IsEmpty());

	//-------------------------------------
	//������� ������
	const std::auto_ptr<TOpenPictureDialog> apdlgOpenPhoto(new TOpenPictureDialog(this));
	/*DEBUG*/assert(NULL != apdlgOpenPhoto.get());

	apdlgOpenPhoto->Name   = _T("dlgOpenPhoto");
	apdlgOpenPhoto->Filter = _T("JPEG Image File (*.jpg;*.jpeg)|*.jpg;*.jpeg|"
								"All files       (*.*)|*.*");

	if (false == apdlgOpenPhoto->Execute()) {
        pADOQuery->Cancel();
        return;
	}

	//-------------------------------------
	//������� 1
////    Repaint();
////	m_pMemoryStream->Clear();
////    m_pMemoryStream->LoadFromFile(OpenPictureDialog1->FileName);
////    pADOQuery->Edit();
////	((TBlobField *)pADOQuery->FieldByName(cusFieldName))->LoadFromStream(m_pMemoryStream);
////    pADOQuery->Post();

	////////////////////?????Repaint();

	//-------------------------------------
	//������� 2
    pADOQuery->Edit();
	((TBlobField *)pADOQuery->FieldByName(cusFieldName))->LoadFromFile(apdlgOpenPhoto->FileName);
	pADOQuery->Post();

	//-------------------------------------
	//���������� ��������
	vShowImage(pImage, pADOQuery, cusFieldName);
}
//---------------------------------------------------------------------------

/*
��� �������� ���� � Blob ����?

1)����� �������:
(table1.fieldbyname('ddd') as TBlobField).loadfromfile('dddss');

2) ����� ��������� � �������...
ADOquery1.sql.text:='Insert into myTable (a) Values (:b)';
ADOQuery1.parameters.parseSQL(ADOquery1.sql.text, true);
ADOQuery1.parameters.parambyname('b').LoadFromFile('MyFile');
ADOQuery1.execsql;
*/
