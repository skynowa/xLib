/***********************************************************************
*   hGetAssociatedIcon   
*
************************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
HICON __fastcall TfrmMain::hGetAssociatedIcon(char* pFilePath) {
//	WORD iconIndex = 0;
//	HICON hIcon    = 0;
//
//	if (pFilePath == "") {
//		pFilePath = "nul.txt";
//	}
//	try	{
//		char buf[MAX_PATH];
//		strncpy(buf, pFilePath, sizeof(buf));
//		hIcon = ::ExtractAssociatedIcon(HInstance, buf, &iconIndex);
//	} catch (...) {
//		hIcon = 0;
//	}
	return 0/*hIcon*/;
}
//---------------------------------------------------------------------------


