/**********************************************************************
*	MakeADOConnectingString -
*
***********************************************************************/


#include "uDM.h"            //frmDM

//---------------------------------------------------------------------------
WideString TdmDM::vMakeADOConnectingString(const WideString &wsBasePath) {
    //-------------------------------------
    //��������
    if (FileExists(wsBasePath) == false) {
        MessageBox(0, ("�� ������ ����� ���� ��:\n" + wsBasePath).c_str(), Application->Title.c_str(), MB_OK + MB_ICONSTOP + MB_TOPMOST);
        Application->Free();
        Application->Terminate();
    }
    
    WideString wsConnectionString = "";
    wsConnectionString += "Provider=Microsoft.Jet.OLEDB.4.0;";
    wsConnectionString += "User ID=Admin;";
    wsConnectionString += "Data Source=" + wsBasePath + ";";
    wsConnectionString += "Mode=ReadWrite|Share Deny None;";    
    wsConnectionString += "Extended Properties=\"\";";
    wsConnectionString += "Jet OLEDB:System database=\"\";";
    wsConnectionString += "Jet OLEDB:Registry Path=\"\";";
    wsConnectionString += "Jet OLEDB:Database Password=\"\";";
    wsConnectionString += "Jet OLEDB:Engine Type=5;";
    wsConnectionString += "Jet OLEDB:Database Locking Mode=1;";
    wsConnectionString += "Jet OLEDB:Global Partial Bulk Ops=2;";
    wsConnectionString += "Jet OLEDB:Global Bulk Transactions=1;";
    wsConnectionString += "Jet OLEDB:New Database Password="";";
    wsConnectionString += "Jet OLEDB:Create System Database=False;";
    wsConnectionString += "Jet OLEDB:Encrypt Database=False;";
    wsConnectionString += "Jet OLEDB:Don't Copy Locale on Compact=False;";
    wsConnectionString += "Jet OLEDB:Compact Without Replica Repair=False;";
    wsConnectionString += "Jet OLEDB:SFP=False";
    //MessageBox(0, ((AnsiString)conFilter->ConnectionString).c_str(), "", MB_OK);

    return wsConnectionString;
}
//---------------------------------------------------------------------------