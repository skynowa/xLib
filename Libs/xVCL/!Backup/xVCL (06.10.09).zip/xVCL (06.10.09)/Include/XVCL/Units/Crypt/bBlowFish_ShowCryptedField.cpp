/**********************************************************************
*	bShowCryptedField.cpp	
*
***********************************************************************/


#include "Unit1.h"

//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asGetCryptedField(TADOQuery *pAdoQuery, const AnsiString &csFieldName) {
	//-------------------------------------
	//F_POP3_PASS
    CXBlowfish  BF;
    std::string sIn;
    std::string sOut;

    const std::auto_ptr<TMemoryStream> pMS(new TMemoryStream());
    //������ �� � �����
    pMS->Position = 0;
    ((TBlobField *)pAdoQuery->FieldByName(csFieldName))->SaveToStream(pMS.get());

    //������ ������ � �����
    pMS->Position = 0;
    sIn.resize(pMS->Size);
    pMS->ReadBuffer((VOID *)&sIn[0], sIn.size());
    /*DEBUG*///XASSERT(false == sIn.empty());

    BF.bSetKey(_m_sCryptKey);
    BF.bDecryptCbc(sIn, /*ref*/sOut);
    //--pEdit->Text = AnsiString(sOut.c_str());

    return  AnsiString(sOut.c_str());
}
//---------------------------------------------------------------------------
