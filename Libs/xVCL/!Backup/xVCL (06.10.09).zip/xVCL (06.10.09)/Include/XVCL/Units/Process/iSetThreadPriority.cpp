/**********************************************************************
*
*
***********************************************************************/


//---------------------------------------------------------------------------
int __fastcall TfrmMain::iSetThreadPriority(const AnsiString& casThreadPriorityLevel) {
    int iPriority = tpNormal;

    if (casThreadPriorityLevel == "Idle") {
        iPriority = tpIdle;
    }
    if (casThreadPriorityLevel == "Lowest") {
        iPriority = tpLowest;
    }
    if (casThreadPriorityLevel == "Lower") {
        iPriority = tpLower;
    }
    if (casThreadPriorityLevel == "Normal") {
        iPriority = tpNormal;
    }
    if (casThreadPriorityLevel == "Higher") {
        iPriority = tpHigher;
    }
    if (casThreadPriorityLevel == "Highest") {
        iPriority = tpHighest;
    }
    if (casThreadPriorityLevel == "TimeCritical") {
        iPriority = tpTimeCritical;
    }
    
    return iPriority;
}
//---------------------------------------------------------------------------
