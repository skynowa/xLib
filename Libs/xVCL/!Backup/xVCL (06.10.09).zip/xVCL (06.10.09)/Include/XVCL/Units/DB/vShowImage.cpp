/**********************************************************************
*	vShowImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vShowImage(TImage* pImage, TADOQuery* pADOQuery, const UnicodeString &cusFieldName) {
	/*DEBUG*/assert(NULL  != pImage);
	/*DEBUG*/assert(NULL  != pADOQuery);
	/*DEBUG*/assert(false == cusFieldName.IsEmpty());

	//-------------------------------------
	//������� ������ �������� (BC++ 6.0 - RAD2009: ��������, RAD2010 - ������)
	pImage->Picture->Assign(NULL);
	pImage->Repaint();

//	Graphics::TBitmap *bmp = new Graphics::TBitmap();
//	pImage->Picture->Assign(bmp);

	//pImage->Picture->Bitmap = NULL;


	//-------------------------------------
	//������� �1: BMP + JPEG
	try {
		m_pMemoryStream->Clear();
		((TBlobField*)pADOQuery->FieldByName(cusFieldName))->SaveToStream(m_pMemoryStream);
		if ((NULL == m_pMemoryStream) || (0 == m_pMemoryStream->Size)) {
			pImage->Visible = false;
			return;
		}
		pImage->Visible = true;
		m_pMemoryStream->Position = 0;
		m_pJPEGImage->LoadFromStream(m_pMemoryStream);
		//ScrollBox1->HorzScrollBar->Range = jpg->Width;
		//ScrollBox1->VertScrollBar->Range = jpg->Height;
		pImage->Picture->Assign((TPersistent *)m_pJPEGImage);
	} catch (...) {
		pImage->Picture->Assign(pADOQuery->FieldByName(_T("FN_PHOTO")));
	}

	//-------------------------------------
	//������� �2: PNG
//	m_pMemoryStream->Clear();
//	((TBlobField*)pADOQuery->FieldByName(cusFieldName))->SaveToStream(m_pMemoryStream);
//	if ((!m_pMemoryStream) || (m_pMemoryStream->Size == 0)) {
//		pImage->Visible = false;
//		return;
//	}
//	pImage->Visible = true;
//	m_pMemoryStream->Position = 0;
//	m_pPngImage->LoadFromStream(m_pMemoryStream);
//	pImage->Picture->Assign((TPersistent *)m_pPngImage);
}
//---------------------------------------------------------------------------
