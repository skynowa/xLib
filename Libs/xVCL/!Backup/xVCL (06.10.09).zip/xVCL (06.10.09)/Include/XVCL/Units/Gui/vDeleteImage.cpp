/**********************************************************************
*	vDeleteImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vDeleteImage(TImage *pImage, TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {
	pADOQuery->Edit();
	pADOQuery->FieldByName(cusFieldName)->Clear();
	pADOQuery->Post();

	//�������������� TImage
	pImage->Picture->Assign(NULL);
	pImage->Repaint();
}
//---------------------------------------------------------------------------

/*
UPDATE MyTable

Set MyBlobField = Null

WHERE SomeField = 'Somevalue'
*/
