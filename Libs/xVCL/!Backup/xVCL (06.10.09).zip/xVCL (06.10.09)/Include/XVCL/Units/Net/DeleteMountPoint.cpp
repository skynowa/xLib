/***********************************************************************
*   
*
************************************************************************/


void __fastcall TfrmMain::DeleteMountPoint(const AnsiString & asMountPointHost, const AnsiString & asMountPointShare) {
    ////#if (WINVER == 1281)
        TRegistry *pReg = new TRegistry(KEY_ALL_ACCESS);
        AnsiString asKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\MountPoints2\\##" + asMountPointHost + "#" + asMountPointShare + "$" + "\\";
        ////ShowMessage(asKey);
        if (pReg) {
            if (pReg->KeyExists(asKey)) {
                pReg->RootKey = HKEY_CURRENT_USER;
                pReg->DeleteKey(asKey);
                pReg->CloseKey();
            }
        }
        delete pReg;
    ////#endif
}