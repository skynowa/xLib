/***********************************************************************
*   asGetParentFolderName
*
************************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asGetParentFolderName(const AnsiString &asFilePath) {
    int iStartPos = ExtractFilePath(asFilePath).SetLength(ExtractFilePath(asFilePath).Length() - 1).LastDelimiter("\\") + 1;
    
    return ExtractFilePath(asFilePath).SubString(iStartPos, ExtractFilePath(asFilePath).Length() - iStartPos);
}
//---------------------------------------------------------------------------
