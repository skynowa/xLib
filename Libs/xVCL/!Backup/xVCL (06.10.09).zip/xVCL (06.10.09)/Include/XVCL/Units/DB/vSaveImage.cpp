/**********************************************************************
*	vSaveImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSaveImage(TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {
	/*DEBUG*/assert(NULL  != pADOQuery);
	/*DEBUG*/assert(false == cusFieldName.IsEmpty());

	//-------------------------------------
	//������� ������
	const std::auto_ptr<TSavePictureDialog> apdlgSavePhoto(new TSavePictureDialog(this));
	/*DEBUG*/assert(NULL != apdlgSavePhoto.get());

	apdlgSavePhoto->Name   = _T("dlgSavePhoto");
	apdlgSavePhoto->Filter = _T("JPEG Image File (*.jpg;*.jpeg)|*.jpg;*.jpeg|"
								"All files       (*.*)|*.*");

	//-------------------------------------
	//������� �1 - ������� (����� PNG)
	////	if (!SavePictureDialog1->Execute()) {
	////		ADOQuery1->Cancel();
	////		return;
	////	}
	////
	////	((TBlobField *)ADOQuery1->FieldByName(cusFieldName))->SaveToFile(SavePictureDialog1->FileName);

	//-------------------------------------
	//������� �2 - �� �������
	////	if (!SavePictureDialog1->Execute()) {
	////		ADOQuery1->Cancel();
	////		return;
	////	}
	////
	////	pMemoryStream->Clear();
	////	((TBlobField *)ADOQuery1->FieldByName(cusFieldName))->SaveToStream(pMemoryStream);
	////	pPngImage->LoadFromStream(pMemoryStream);
	////	pPngImage->SaveToFile(SavePictureDialog1->FileName);

	//-------------------------------------
	//������� �3 - �� ������� (��� ������ ������� �����)
	if (!apdlgSavePhoto->Execute()) {
		pADOQuery->Cancel();
		return;
	}

	TField *pField = pADOQuery->FieldByName(cusFieldName);
	std::auto_ptr<TBlobStream> apBlobStream((TBlobStream *)pADOQuery->CreateBlobStream(pField, bmRead));
	std::auto_ptr<TFileStream> apOutFile   (new TFileStream(apdlgSavePhoto->FileName + _T(".jpg") , fmCreate | fmShareExclusive));
	unsigned char *pucBuff = new unsigned char[apBlobStream->Size];
	__try {
		int iReadBytes = 0;
		do {
		   iReadBytes = apBlobStream->Read(pucBuff, 1024);
		   apOutFile->Write(pucBuff, iReadBytes);
		}
		while (iReadBytes);
	} __finally {
		if (pucBuff) {delete []pucBuff; pucBuff = NULL;}
	}
}
//---------------------------------------------------------------------------
