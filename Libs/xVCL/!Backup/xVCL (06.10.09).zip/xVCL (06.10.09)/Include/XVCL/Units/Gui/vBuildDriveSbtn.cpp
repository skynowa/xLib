/***********************************************************************
*	vBitmapToSbtn.cpp
*
************************************************************************/


#include <Math.hpp>

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vBuildDriveSbtn(TSpeedButton        *pSbtn,
										  Graphics::TBitmap   *pBitmap,
										  const UnicodeString &�usDrivePath,
										  const UnicodeString &cusDriveLabel,
										  unsigned __int64     ui64TotalNumberOfBytes,
										  unsigned __int64     ui64TotalNumberOfFreeBytes)
{
	/*DEBUG*/assert(NULL != pSbtn);
	/*DEBUG*/assert(NULL != pBitmap);

	pSbtn->Glyph   = pBitmap;
	pSbtn->Caption = �usDrivePath.SubString(0, 1);    //������ "C"
	pSbtn->Hint    = L"Label: " + cusDriveLabel                                                       + L"\r\n"
					 L"Total: " + FloatToStr(RoundTo(ui64TotalNumberOfBytes  / 1000000000.0, - 3))    + L" Gb\r\n"
					 L"Free:  " + FloatToStr(RoundTo(ui64TotalNumberOfFreeBytes / 1000000000.0, - 3)) + L" Gb";

	pSbtn->Visible = true;
}
//---------------------------------------------------------------------------
