/***********************************************************************
*    �������� HTML ����
*
***********************************************************************/


//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asReplaceHtmlTag(AnsiString &asInputStr, const AnsiString &asInputTag, const AnsiString &asOutputTag) {
    Application->ProcessMessages();

    TReplaceFlags flags;
    flags << rfReplaceAll << rfIgnoreCase;

    return StringReplace(asInputStr, asInputTag, asOutputTag, flags);
}
//---------------------------------------------------------------------------