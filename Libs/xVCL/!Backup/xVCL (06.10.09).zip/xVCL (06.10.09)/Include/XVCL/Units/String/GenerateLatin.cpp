/**********************************************************************
*   TODO: a-z (97-122)
*
***********************************************************************/


TStringList* __fastcall TfrmMain::GenerateLatin(TStringList* pLatinList) {
    if (chkLatin_1->Checked == true) {
        //1 �����
        for (int a = 97; a <= 122; a ++) {
            pLatinList->Add(
                    AnsiString(char(a))
            );
        }
    }

    if (chkLatin_2->Checked == true) {
        //2 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b))
            );
        }}
    }

    if (chkLatin_3->Checked == true) {
        //3 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c))
            );
        }}}
    }

    if (chkLatin_4->Checked == true) {
        //4 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d))
            );
        }}}}
    }

    if (chkLatin_5->Checked == true) {
        //5 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e))

            );
        }}}}}
    }

    if (chkLatin_6->Checked == true) {
        //6 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f))

            );
        }}}}}}
    }

    if (chkLatin_7->Checked == true) {
        //7 �����
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g))

            );
        }}}}}}}
    }

    if (chkLatin_8->Checked == true) {
        //8
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h))

            );
        }}}}}}}}
    }

    if (chkLatin_9->Checked == true) {
        //9
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i))

            );
        }}}}}}}}}
    }

    if (chkLatin_10->Checked == true) {
        //10
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
        for (int j = 97; j <= 122; j ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i)) +
                    AnsiString(char(j))

            );
        }}}}}}}}}}
    }

    if (chkLatin_11->Checked == true) {
        //11
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
        for (int j = 97; j <= 122; j ++) {
        for (int k = 97; k <= 122; k ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i)) +
                    AnsiString(char(j)) +
                    AnsiString(char(k))

            );
        }}}}}}}}}}}
    }

    if (chkLatin_12->Checked == true) {
        //12
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
        for (int j = 97; j <= 122; j ++) {
        for (int k = 97; k <= 122; k ++) {
        for (int l = 97; l <= 122; l ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i)) +
                    AnsiString(char(j)) +
                    AnsiString(char(k)) +
                    AnsiString(char(l))

            );
        }}}}}}}}}}}}
    }

    if (chkLatin_13->Checked == true) {
        //13
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
        for (int j = 97; j <= 122; j ++) {
        for (int k = 97; k <= 122; k ++) {
        for (int l = 97; l <= 122; l ++) {
        for (int m = 97; m <= 122; m ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i)) +
                    AnsiString(char(j)) +
                    AnsiString(char(k)) +
                    AnsiString(char(l)) +
                    AnsiString(char(m))

            );
        }}}}}}}}}}}}}
    }

    if (chkLatin_14->Checked == true) {
        //14
        for (int a = 97; a <= 122; a ++) {
        for (int b = 97; b <= 122; b ++) {
        for (int c = 97; c <= 122; c ++) {
        for (int d = 97; d <= 122; d ++) {
        for (int e = 97; e <= 122; e ++) {
        for (int f = 97; f <= 122; f ++) {
        for (int g = 97; g <= 122; g ++) {
        for (int h = 97; h <= 122; h ++) {
        for (int i = 97; i <= 122; i ++) {
        for (int j = 97; j <= 122; j ++) {
        for (int k = 97; k <= 122; k ++) {
        for (int l = 97; l <= 122; l ++) {
        for (int m = 97; m <= 122; m ++) {
        for (int n = 97; n <= 122; n ++) {
            pLatinList->Add(
                    AnsiString(char(a)) +
                    AnsiString(char(b)) +
                    AnsiString(char(c)) +
                    AnsiString(char(d)) +
                    AnsiString(char(e)) +
                    AnsiString(char(f)) +
                    AnsiString(char(g)) +
                    AnsiString(char(h)) +
                    AnsiString(char(i)) +
                    AnsiString(char(j)) +
                    AnsiString(char(k)) +
                    AnsiString(char(l)) +
                    AnsiString(char(m)) +
                    AnsiString(char(n))

            );
        }}}}}}}}}}}}}}
    }

    return pLatinList;
}

