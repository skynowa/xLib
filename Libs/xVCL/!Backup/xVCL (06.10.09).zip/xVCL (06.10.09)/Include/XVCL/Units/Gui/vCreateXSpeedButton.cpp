/***********************************************************************
*   vCreateXSpeedButton
*
************************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vCreateXSpeedButton(TTabSheet* pTBS, int iHeight, int iWidth/*78*/, int iStartCapacity,
                                              int iStopCapacity, int iItemsInRow) {

	/*DEBUG*/assert(NULL != pTBS);
	/*
    vCreateXSpeedButton(tsSoft,   22, 22,   0,   200,  14);  //0    - 299
    vCreateXSpeedButton(tsBrowse, 22, 77,   300, 500,  4);   //300  - 599     <------
    */
	//-------------------------------------
	//������� ������
	std::auto_ptr<TIniFile> apIni(new TIniFile(ChangeFileExt(Application->ExeName, _T(".ini"))));
	/*DEBUG*/assert(NULL != apIni.get());

	int iCapacity       = iStartCapacity;
	int x               = 0;       //�������
	int y               = 0;       //����
	int iCountBtnsInRow = 0;       //������� ������ � ����

	for (y = 0, iCountBtnsInRow = 0; iCapacity < iStopCapacity; iCapacity ++, iCountBtnsInRow ++) { //144 - ����� ����
		//-------------------------------------
		//������� ����
		if (iCountBtnsInRow >= iItemsInRow) {
			y              += iHeight;
			x               = 0;
			iCountBtnsInRow = 0;
		}

		//-------------------------------------
		//�������� ������
		m_pSpeedBtn[iCapacity]             = new TXSpeedButton(NULL);
		/*DEBUG*/assert(NULL != m_pSpeedBtn[iCapacity]);
		m_pSpeedBtn[iCapacity]->Tag        = iCapacity;       //Name
		m_pSpeedBtn[iCapacity]->Parent     = pTBS;
		m_pSpeedBtn[iCapacity]->Left       = (x += iWidth) - iWidth;
		m_pSpeedBtn[iCapacity]->Top        = y;
		m_pSpeedBtn[iCapacity]->Width      = iWidth;  //22;
		m_pSpeedBtn[iCapacity]->Height     = iHeight; //22;
		m_pSpeedBtn[iCapacity]->Margin     = 2;
		m_pSpeedBtn[iCapacity]->Spacing    = 5;
		m_pSpeedBtn[iCapacity]->Flat       = true;
		//Hint
		UnicodeString usHint = apIni.get()->ReadString(IntToStr(iCapacity), _T("Caption"), _T(""));
		if (true == usHint.IsEmpty()) {
			m_pSpeedBtn[iCapacity]->Hint   = apIni.get()->ReadString(IntToStr(iCapacity), _T("FilePath"), _T(""));
		} else {
			m_pSpeedBtn[iCapacity]->Hint   = usHint;
		}
		m_pSpeedBtn[iCapacity]->ShowHint   = true;
		//
		m_pSpeedBtn[iCapacity]->Caption    = apIni.get()->ReadString(IntToStr(iCapacity), _T("Caption"),  _T(""));
		m_pSpeedBtn[iCapacity]->usFilePath = apIni.get()->ReadString(IntToStr(iCapacity), _T("FilePath"), _T(""));
		m_pSpeedBtn[iCapacity]->usParam    = apIni.get()->ReadString(IntToStr(iCapacity), _T("Param"),    _T(""));
		m_pSpeedBtn[iCapacity]->usIconPath = apIni.get()->ReadString(IntToStr(iCapacity), _T("IconPath"), _T(""));
		//Glyph
		vAssotiativeIconToXSBtn(m_pSpeedBtn[iCapacity], apIni.get()->ReadString(IntToStr(iCapacity), _T("IconPath"), _T("")));
		m_pSpeedBtn[iCapacity]->PopupMenu  = pmBtnProperties;
		m_pSpeedBtn[iCapacity]->OnClick    = vXSpeedButton_OnClick;
	}
}
//---------------------------------------------------------------------------