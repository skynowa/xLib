/***********************************************************************
*   vIcoToMenuItem
*
************************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vIcoToMenuItem(TPopupMenu *pMenuItem ,  const AnsiString &casAssociateFileExt, const AnsiString &casMenuItemCaption) {    //".exe"
    /*DEBUG*/XASSERT(NULL != pMenuItem);

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
    /*DEBUG*/XASSERT(NULL != apImageList.get());

    //-------------------------------------
    //��������� ������
    AnsiString asFilePath = "";
    if (true == casAssociateFileExt.IsEmpty()) {
        //��������� ������ (������ �����)
    } else {
        asFilePath = asSearchFileEx(casAssociateFileExt, BASE_PATH + "Project" + "\\");
    }                

    TSHFileInfo sfInfo;   ::ZeroMemory(&sfInfo, sizeof(sfInfo));
    DWORD dwImageHandle = ::SHGetFileInfo(asFilePath.c_str(),
                                        0,
                                        &sfInfo,
                                        sizeof(sfInfo),
                                        SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);

    if (0 != dwImageHandle) {
        apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }
                                              
	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/XASSERT(NULL != apIcon.get());
    apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
    apIcon.get()->Transparent = true;

    //////////int iIconIndex = pImageList->AddIcon(pIcon);

    //-------------------------------------
    //--������ + ����
    //--pTrayIcon->Icons     = pImageList;   //��������� � pImageList
    //--pTrayIcon->IconIndex = iIconIndex;
    //--pTrayIcon->Hint      = casTrayIconHint;
    
    //-------------------------------------
    //����
    pmnuTray->Items->Items[0]->ImageIndex = 2; //iIconIndex;
}
//---------------------------------------------------------------------------


