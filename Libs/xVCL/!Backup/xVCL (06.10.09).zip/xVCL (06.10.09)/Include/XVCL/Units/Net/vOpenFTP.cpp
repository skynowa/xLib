/***********************************************************************
*	vOpenFTP
*
************************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vOpenFTP(const UnicodeString &usURL) {
	ShellExecuteW(NULL, NULL, L"explorer.exe", (L"/e, ftp://" + usURL).w_str(), NULL, SW_SHOW);

////    Variant IE;
////    IE = Variant::CreateObject("InternetExplorer.Application");
////    IE.OlePropertySet("Visible", true);
////    IE.OleProcedure("Navigate", (WideString)asURL);
////    IE = Unassigned;
}
//---------------------------------------------------------------------------
