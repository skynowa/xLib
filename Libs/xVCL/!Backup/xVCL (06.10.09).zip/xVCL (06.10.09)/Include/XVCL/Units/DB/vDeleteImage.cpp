/**********************************************************************
*	vDeleteImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vDeleteImage(TImage *pImage, TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {
	/*DEBUG*/assert(NULL  != pImage);
	/*DEBUG*/assert(NULL  != pADOQuery);
	/*DEBUG*/assert(false == cusFieldName.IsEmpty());

	pADOQuery->Edit();
	pADOQuery->FieldByName(cusFieldName)->Clear();
	pADOQuery->Post();

    //-------------------------------------
	//�������������� TImage  (BC++ 6.0 - RAD2009: ��������, RAD2010 - ������)
	pImage->Picture->Assign(NULL);
	pImage->Repaint();
}
//---------------------------------------------------------------------------

/*
UPDATE MyTable

Set MyBlobField = Null

WHERE SomeField = 'Somevalue'
*/
