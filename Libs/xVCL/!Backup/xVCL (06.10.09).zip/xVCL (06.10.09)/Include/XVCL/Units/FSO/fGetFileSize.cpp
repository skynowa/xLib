/***********************************************************************
*	������ ������ ����� (Mb) (������ API ������� GetFileSize) 
*
************************************************************************/


#include <Math.hpp>
#include <sys\stat.h>
#include  <stdio.h>

//---------------------------------------------------------------------------
float __fastcall TfrmMain::fGetFileSize(const std::string &sFilePath) {
    struct stat statbuf;
    FILE *pFile;
    if ((pFile = fopen(sFilePath.c_str(), "r+t")) == NULL) {
        MessageBox(0, ("File " + sFilePath + " can't open").c_str(), APP_NAME, MB_OK + MB_ICONSTOP);
        return 0;
    }
    stat(sFilePath.c_str(), &statbuf);
    fclose(pFile);
    return RoundTo((statbuf.st_size) / 1000000.0, -3);
}
//---------------------------------------------------------------------------
