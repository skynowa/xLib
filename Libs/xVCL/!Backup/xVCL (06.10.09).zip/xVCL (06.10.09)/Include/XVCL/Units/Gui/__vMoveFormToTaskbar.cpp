/***********************************************************************
*   vMoveFormToTaskbar
*
************************************************************************/



//---------------------------------------------------------------------------
void __fastcall TfrmMain::vMoveFormToTaskbar(TForm *pForm) {
    RECT rect;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &rect, 0);
    pForm->Top  = rect.bottom - pForm->Height - 2;
    pForm->Left = Screen->Width - pForm->Width - 2;
}
//---------------------------------------------------------------------------
