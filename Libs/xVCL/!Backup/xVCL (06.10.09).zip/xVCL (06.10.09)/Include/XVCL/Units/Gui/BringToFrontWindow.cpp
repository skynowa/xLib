/***********************************************************************
*	������� ��������� ����
*
************************************************************************/

void __fastcall TfrmToolTip::BringToFrontWindow(HWND hWnd) {
	HWND hCurrWnd = ::GetForegroundWindow();
	int iMyTID    = GetCurrentThreadId();
	int iCurrTID  = GetWindowThreadProcessId(hCurrWnd,0);

	AttachThreadInput(iMyTID, iCurrTID, TRUE);
	SetForegroundWindow(hWnd);
	AttachThreadInput(iMyTID, iCurrTID, FALSE);
}