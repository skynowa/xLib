/***********************************************************************
*   ��� ����� � ��������
*
************************************************************************/


#include "uLaunchProject.h"

extern TfrmMain *frmMain;
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vMoveFormToTaskbar() {
    RECT rect;    ::ZeroMemory(&rect, sizeof(rect));
    ::SystemParametersInfo(SPI_GETWORKAREA, 0, &rect, 0);
    frmMain->Top  = rect.bottom   - frmMain->Height - 2;
    frmMain->Left = Screen->Width - frmMain->Width - 2;
}
//---------------------------------------------------------------------------
