/**********************************************************************
*	i64GetBlobSize - ������ ���� ����
*
***********************************************************************/


//---------------------------------------------------------------------------
__int64 __fastcall TfrmMain::i64GetBlobSize(TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {
	/*DEBUG*/assert(NULL  != pADOQuery);
    /*DEBUG*/assert(false == cusFieldName.IsEmpty()); 
	
	__int64 i64Res = 0;

	TField *pField = pADOQuery->FieldByName(cusFieldName);
	/*DEBUG*/assert(NULL  != pField);
	
	std::auto_ptr<TBlobStream> apBlobStream((TBlobStream *)pADOQuery->CreateBlobStream(pField, bmRead));

	i64Res = apBlobStream->Size; 	//Indicates the size in bytes of the stream.
	//i64Res = apBlobStream->Seek(0, soFromEnd);

	return i64Res;
}
//---------------------------------------------------------------------------
