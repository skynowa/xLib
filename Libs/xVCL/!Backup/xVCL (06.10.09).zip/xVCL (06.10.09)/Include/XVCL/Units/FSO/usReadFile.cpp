/***********************************************************************
*	usReadFile
*
************************************************************************/


#include "Units\sRemoveEOL.cpp"
//---------------------------------------------------------------------------
UnicodeString __fastcall TfrmMain::usReadFile(const UnicodeString &usFilePath) {
	std::auto_ptr<TStringList> apList(new TStringList());
	apList.get()->LoadFromFile(usFilePath);
	UnicodeString usTemp = apList.get()->Text;
	usTemp = sRemoveEOL(usTemp.c_str()).c_str();

	return usTemp;
}
//---------------------------------------------------------------------------