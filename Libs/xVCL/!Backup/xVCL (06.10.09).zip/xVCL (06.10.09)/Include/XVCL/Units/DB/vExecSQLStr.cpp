/**********************************************************************
*	vExecSQLStr -
*
***********************************************************************/


#include "Unit1.h"           //frmDoc

//---------------------------------------------------------------------------
void TfrmMain::vExecSQLStr(TADOConnection *pADOConnection, const AnsiString &asSQLStr, bool bIsSelectMode) {
	TADOQuery *qryTmp =  new TADOQuery(NULL);
	qryTmp->Connection = pADOConnection;

	qryTmp->Close();
	qryTmp->SQL->Text = asSQLStr;

    try {
        if (bIsSelectMode == true) {
           qryTmp->Open();
        } else {
           qryTmp->ExecSQL();
        }
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }

	delete qryTmp; qryTmp = NULL;
}
//---------------------------------------------------------------------------

