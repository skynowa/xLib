/***********************************************************************
*   vFileToCombobox	
*
************************************************************************/



//---------------------------------------------------------------------------
void __fastcall TfrmMain::vFileToCombobox(TComboBox *pCB, int iItemIndex, const UnicodeString &cusFilePath) {
	TStringList *pSL = new TStringList();
	pSL->LoadFromFile(cusFilePath);

    pCB->Clear();
    pCB->Items->AddStrings(pSL);
    pCB->ItemIndex = iItemIndex;
    
    delete pSL;  pSL = NULL;
}
//---------------------------------------------------------------------------
