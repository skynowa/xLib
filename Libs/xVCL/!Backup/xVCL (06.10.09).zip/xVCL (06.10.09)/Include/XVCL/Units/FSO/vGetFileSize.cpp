/***********************************************************************
*	������ ������ ����� (Mb) (������ API ������� GetFileSize) 
*
************************************************************************/


//---------------------------------------------------------------------------
float __fastcall TfrmMain::vGetFileSize(const AnsiString &asFilePath) {
    //����� ������ read-only
    FileSetAttr(asFilePath, 0);

	struct stat statbuf;
	FILE *pFile; 
	if ((pFile = fopen(asFilePath.c_str(), "r+t")) == NULL){
		MessageBox(NULL, ("File " + asFilePath + " can't open").c_str(), Application->Title.c_str(), 0 | 16 | 0 | 0 | 262144);
		return 0;
	}
	stat(asFilePath.c_str(), &statbuf);
	fclose(pFile);
	//ShowMessage(IntToStr(statbuf.st_size));
	return RoundTo((statbuf.st_size) / 1000000.0, -3);
}
//---------------------------------------------------------------------------