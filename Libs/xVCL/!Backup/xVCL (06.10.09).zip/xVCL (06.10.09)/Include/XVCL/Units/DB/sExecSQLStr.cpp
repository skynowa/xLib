/**********************************************************************
*	asExecSQLStr - tmp_var - ������ ���� � SQL �������
*
***********************************************************************/


//---------------------------------------------------------------------------
tString sExecSQLStr(TADOConnection *pADOConnection, const tString &csSQLStr) {
	/*DEBUG*/assert(NULL  != pADOConnection);
    /*DEBUG*/assert(false == csSQLStr.IsEmpty());
	
	tString sResult = _T("");
	
	const std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(0));
	/*DEBUG*/assert(NULL != apqryTmp.get());
	
	apqryTmp->Connection = pADOConnection;

    try {
        apqryTmp->Close();
        apqryTmp->SQL->Text = csSQLStr;
        apqryTmp->Open();   

		sResult = apqryTmp->FieldByName(_T("tmp_var"))->AsString;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }
	
	return sResult;
}
//---------------------------------------------------------------------------