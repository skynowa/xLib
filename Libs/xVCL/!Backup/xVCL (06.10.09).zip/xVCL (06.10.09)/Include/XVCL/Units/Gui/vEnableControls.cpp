/**********************************************************************
*	
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vEnableControls(bool bFlag) {
    for (int i = 1; i < ComponentCount; i ++) {
        AnsiString asClassName           = Components[i]->ClassName();
        AnsiString asParentComponentName = "";

        if (Components[i]->HasParent() && asClassName == "TCheckBox") {
            asParentComponentName = Components[i]->GetParentComponent()->Name;

            if (asParentComponentName == "tsDeleteOptions") {
                ((TCheckBox *)Components[i])->Enabled = bFlag;
            }
        }
    }

    //--TCheckBox->Enabled = bFlag;
}
//---------------------------------------------------------------------------