/***********************************************************************
*   vExecFile
*
************************************************************************/


//---------------------------------------------------------------------------
//TODO: vExecFile
void __fastcall TfrmMain::vExecFile(const UnicodeString &cusFilePath) {
	ClientHeight = cmdStart->Height;
	Application->ProcessMessages();

	//-------------------------------------
	//�����, ���� ��� ����
	UnicodeString usExecStr = L"";
	if (true == DirectoryExists(cusFilePath)) {
		usExecStr =  L"explorer.exe /e, " + cusFilePath;
	} else {
        //���� ���� ����������
		if (true == FileExists(cusFilePath)) {
            //exe-���� ��� �������
			if (L".cpl" == ExtractFileExt(cusFilePath)) {
				usExecStr = L"Control.exe " + ExtractFileName(cusFilePath);
			} else {
				usExecStr = cusFilePath;
			}
		} else {
        	return;
		}
	}

	//-------------------------------------
	//������� ������� �� ������
	STARTUPINFO         si;   ::ZeroMemory(&si, sizeof(si));   si.cb = sizeof(si);
	PROCESS_INFORMATION pi;   ::ZeroMemory(&pi, sizeof(pi));

	if (!::CreateProcess(NULL, usExecStr.t_str(), NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi)) {
		return;
	}

	//dwExitCode = WaitForSingleObject(piProcessInfo.hProcess, (SecondsToWait * 1000)/*INFINITE*/);
	::CloseHandle(pi.hThread);
	::CloseHandle(pi.hProcess);

	::ZeroMemory(&si, sizeof(si));
	::ZeroMemory(&pi, sizeof(pi));
}
//---------------------------------------------------------------------------
