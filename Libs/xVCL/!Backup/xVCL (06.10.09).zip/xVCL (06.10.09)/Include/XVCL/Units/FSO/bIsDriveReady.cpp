/***********************************************************************
*	bIsDriveReady.cpp
*
************************************************************************/


//---------------------------------------------------------------------------
BOOL __fastcall TfrmMain:: bIsDriveReady(const UnicodeString &cusDrive) {	//���� �� ������
	HANDLE          hFile      = INVALID_HANDLE_VALUE; 
	WIN32_FIND_DATA stFindData = {0};   

	hFile = ::FindFirstFile((cusDrive + "\\*.*").t_str(), &stFindData);
	if (INVALID_HANDLE_VALUE == hFile) {   
		return FALSE; 
	} 

	BOOL bRes = FALSE;
	bRes = ::FindClose(hFile); 
	/*DEBUG*/assert(FALSE != bRes);

	return TRUE;   
}
//---------------------------------------------------------------------------