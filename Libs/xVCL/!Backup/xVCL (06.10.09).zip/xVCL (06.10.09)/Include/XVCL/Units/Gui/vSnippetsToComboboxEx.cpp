/***********************************************************************
*   vSnippetsToComboboxEx
*
************************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSnippetsToComboboxEx(TComboBoxEx *pCBEx, const UnicodeString &asFoderPath, const UnicodeString &usClickedItemCaption, int iSelectedItemIndex) {
	TSearchRec SR;

	if (0 == FindFirst(asFoderPath + L"*.*", faAnyFile, SR)) {      ////ShowMessage(SysErrorMessage(GetLastError()));
        do {
            if (! (SR.Attr & faDirectory)) {    //ShowMessage(SR.Name);
				if (ExtractFileExt(SR.Name).LowerCase() == L".snippet") {    //ShowMessage(ExtractFileExt(SR.Name).LowerCase());
                    pCBEx->Items->Add(SR.Name.SetLength(SR.Name.Length() - ExtractFileExt(SR.Name).Length()));    //������� ����������
                    pCBEx->ItemsEx->Items[pCBEx->ItemsEx->Count - 1]->ImageIndex = 0;
                }
            }
        }
		while (0 == FindNext(SR));

        FindClose(SR);
	}

    pCBEx->ItemIndex = iSelectedItemIndex;
}
//---------------------------------------------------------------------------
