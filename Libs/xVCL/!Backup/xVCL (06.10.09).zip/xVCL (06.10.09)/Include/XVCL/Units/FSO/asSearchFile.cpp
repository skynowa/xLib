/**********************************************************************
   
***********************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
AnsiString __fastcall TfrmMain::asSearchFile(const AnsiString &asFileNameMask, const AnsiString &asFoderPath) {
    TCHAR szBuff[MAX_PATH]; ::ZeroMemory(&szBuff, sizeof(szBuff));

    AnsiString asFileName(FileSearch(asFileNameMask, asFoderPath + AnsiString(";") + AnsiString(szBuff)));
    /*if (asFileName.IsEmpty()) {
        ShowMessage(AnsiString("Couldn't find ") + "ToDo.tdl_" + ".");
    } else {
        ShowMessage(AnsiString("Found ") + asFileName + ".");
    }*/
	return asFileName;
}
//---------------------------------------------------------------------------
