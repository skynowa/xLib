/***********************************************************************
*   vIcoToSpeedBtn   
*
************************************************************************/


#include "uLaunchProject.h"

#include <stdio.h>
#include <Math.hpp>

//---------------------------------------------------------------------------
float __fastcall TfrmMain::fGetExeFileSize(const AnsiString &casFolderPath) {  //".exe"
    AnsiString asFilePath(asSearchFileEx(EXE_EXT, casFolderPath));
    if (true == asFilePath.IsEmpty()) {
        return 0.0;
    }

    unsigned long  ulFileSize = 0;
    FILE          *pFile      = fopen(asFilePath.c_str(), "r+t");
    /*DEBUG*/XASSERT(NULL != pFile);
    if (NULL == pFile) {
        return 0.0;
    }

    __try {
        fseek(pFile, 0, SEEK_END);
        ulFileSize = ftell(pFile);
        fseek(pFile, 0, SEEK_SET);
    } __finally {
        /*DEBUG*/XASSERT(NULL != pFile);
        if (NULL != pFile) {
            fclose(pFile);  pFile = NULL;
        }
    }      

    return RoundTo((ulFileSize / 1000), 0);
}
//---------------------------------------------------------------------------


