/***********************************************************************
*   sRemoveEOL
*
************************************************************************/


#include <string>
//---------------------------------------------------------------------------
std::string sTrimChar(const std::string &csStr, char cChar) {
    std::string sRes("");
    sRes.assign(csStr);

    while ((!sRes.empty()) && (*sRes.begin() == cChar)) {
        sRes.erase(sRes.begin());
    }

    while ((!sRes.empty()) && (*sRes.rbegin() == cChar)) {
        sRes.erase(sRes.end() - 1);
    }
    
    return sRes;	
}
//---------------------------------------------------------------------------
//������� '\r\n' � ����� ������            ��������� �����������������
std::string sRemoveEOL(const std::string &csStr) {
    std::string sRes("");
    sRes.assign(csStr);

	sRes = sTrimChar(sRes, '\n');
	sRes = sTrimChar(sRes, '\r');
    
    return sRes;	
}
//---------------------------------------------------------------------------