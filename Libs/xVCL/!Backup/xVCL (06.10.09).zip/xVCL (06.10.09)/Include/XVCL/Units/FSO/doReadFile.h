/**********************************************************************
*   ������ ����
*
***********************************************************************/

AnsiString __fastcall TfrmMain::doReadFile(AnsiString asPath){ //TODO: ������ ���
    TStringList* pList = new TStringList;
    pList->LoadFromFile(asPath);
    AnsiString asTemp = pList->Text;
    delete pList;

    return asTemp;
}

