/**********************************************************************
*	vShowNoImage.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vShowNoImage(TImage *pImage) {
	/*DEBUG*/assert(NULL != pImage);

	//-------------------------------------
	//������� ������ ��������   (BC++ 6.0 - RAD2009: ��������, RAD2010 - ������)
	pImage->Picture->Assign(NULL);
	pImage->Repaint();

	//-------------------------------------
	//������ �� �����
	const UnicodeString cusNoPhotoText = _T("��� ����");    //oaeno

	pImage->Canvas->Brush->Color = clWhite;
	pImage->Canvas->Font->Color  = clBlack;
	pImage->Canvas->Font->Size   = 18;
	pImage->Canvas->Font->Style  = TFontStyles() << fsBold;
	pImage->Canvas->TextOut(
				pImage->Width  / 2 - pImage->Canvas->TextWidth(cusNoPhotoText) / 2,
				pImage->Height / 2 - pImage->Canvas->TextHeight(cusNoPhotoText) / 2,
				cusNoPhotoText
	);
	//naoea
	pImage->Canvas->Brush->Color = clBlack;
	pImage->Canvas->Brush->Style = bsDiagCross;
	pImage->Canvas->Rectangle(0, 0, pImage->Width, pImage->Height);
	//X
	////pImage->Canvas->MoveTo(pImage->Width, 0);
	////pImage->Canvas->LineTo(0, pImage->Height);

	////pImage->Canvas->MoveTo(0, 0);
	////pImage->Canvas->LineTo(pImage->Width, pImage->Height);
}
//---------------------------------------------------------------------------
