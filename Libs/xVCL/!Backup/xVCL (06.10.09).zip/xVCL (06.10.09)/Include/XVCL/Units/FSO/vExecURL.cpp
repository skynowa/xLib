/**********************************************************************
*	vExecURL.cpp	
*
***********************************************************************/


#include "uHomeDB.h"

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vExecURL(const AnsiString &casURL) {
	if (true == casURL.IsEmpty()) {
		return;
	}
    
    ShellExecute(NULL, NULL, "explorer.exe", casURL.c_str(), NULL, SW_SHOW);
}
//---------------------------------------------------------------------------
