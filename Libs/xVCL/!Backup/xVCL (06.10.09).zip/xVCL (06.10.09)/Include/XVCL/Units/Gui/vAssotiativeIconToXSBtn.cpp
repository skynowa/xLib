/***********************************************************************
*	��������� ComboBoxEx �������, ������� ������
*
************************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vAssotiativeIconToXSBtn(TXSpeedButton *pSBTN, const UnicodeString &cusFlePath) {
	 /*DEBUG*/assert(NULL != pSBTN);

	//-------------------------------------
	//���� ���� ������
	if (true == cusFlePath.IsEmpty()) {
		pSBTN->Glyph->Assign(NULL);
		return;
	}

	//-------------------------------------
	//��������� ������
	if ((false == DirectoryExists(cusFlePath)) && (false == FileExists(cusFlePath))) {
	    //--cusFlePath = "F:\\MyCD\\!!!!!!!!\\_MyProjects\\MyBC++\\Projects\\Start2\\Project\\Icon_16.ico";
        return;
    }

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
	/*DEBUG*/assert(NULL != apImageList.get());

	TSHFileInfo sfInfo = {0};
	DWORD dwImageHandle = ::SHGetFileInfo(cusFlePath.t_str(),
											0,
											&sfInfo,
											sizeof(sfInfo),
											SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);
	if (0 != dwImageHandle) {
		apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }
                                              

	std::auto_ptr<TIcon> apIcon(new TIcon());
	/*DEBUG*/assert(NULL != apIcon.get());
	apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
	apIcon.get()->Transparent = true;

	int iIconIndex = apImageList.get()->AddIcon(apIcon.get());

    //-------------------------------------
    //������ � exe
	std::auto_ptr<Graphics::TBitmap> apBitmap(new Graphics::TBitmap());
	/*DEBUG*/assert(NULL != apBitmap.get());

	apImageList.get()->GetBitmap(iIconIndex, apBitmap.get());
	apBitmap.get()->Transparent      = true;
	apBitmap.get()->TransparentColor = clGradientActiveCaption;     ////????????????

	pSBTN->Glyph   = apBitmap.get();
}
//--------------------------------------------------------------------------- 
