/***********************************************************************
*   
*
************************************************************************/
    

void __fastcall TfrmMainServer::SendToClient(const AnsiString & asMsg) {
    try {
        NMMsg1->PostIt(asMsg);
    } catch (...) {}
}
