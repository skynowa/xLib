/***********************************************************************
*	vGetParentFolderName   
*
************************************************************************/


//---------------------------------------------------------------------------
UnicodeString __fastcall TfrmMain::vGetParentFolderName(const UnicodeString &asFilePath) {
	int           iStartPos = ExtractFilePath(asFilePath).SetLength(ExtractFilePath(asFilePath).Length() - 1).LastDelimiter("\\") + 1;
	UnicodeString usRes     = ExtractFilePath(asFilePath).SubString(iStartPos, ExtractFilePath(asFilePath).Length() - iStartPos);
	
	return usRes;
}
//---------------------------------------------------------------------------
