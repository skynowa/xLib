/**********************************************************************
*	vSqlToComboBox -
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSQLStrToComboBox(TComboBox *pCbb, const UnicodeString &cusFieldName, TADOConnection *pADOConnection, const UnicodeString &cusSQLStr) {
	/*DEBUG*/assert(NULL  != pCbb);
    /*DEBUG*/assert(false == cusFieldName.IsEmpty()); 
	/*DEBUG*/assert(NULL  != pADOConnection);
	/*DEBUG*/assert(false == cusSQLStr.IsEmpty()); 
	
	const std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(this));
	/*DEBUG*/assert(NULL != apqryTmp.get());
	
	apqryTmp->Connection = pADOConnection;

	apqryTmp->Close();
	apqryTmp->SQL->Text = cusSQLStr;

    try {
        apqryTmp->Open();
        apqryTmp->First();
        pCbb->Items->Clear();
        while (! apqryTmp->Eof) {
            if (false == apqryTmp->FieldByName(cusFieldName)->IsNull) {
                pCbb->Items->Add(apqryTmp->FieldByName(cusFieldName)->Value);
            }                
            apqryTmp->Next();
        }
        apqryTmp->Close();

        pCbb->DropDownCount = 20;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }
}
//---------------------------------------------------------------------------
/*
    //��������� cbbCustomerName
    TADOQuery * apqryTmp1 =  new TADOQuery(NULL);
    apqryTmp1->Connection = frmMain->conCustomers;
    apqryTmp1->SQL->Text = "Select * from TN_CUSTOMERS";
    apqryTmp1->Open();

    apqryTmp1->First();
    cbbCustomerName->Items->Clear();
    while (! apqryTmp1->Eof) {
        cbbCustomerName->Items->Add(apqryTmp1->FieldByName("FN_CUSTOMER_NAME")->Value);
        apqryTmp1->Next();
    }
    apqryTmp1->Close();

    delete apqryTmp1; apqryTmp1 = NULL;
    */
