/***********************************************************************
*   
*
************************************************************************/


void __fastcall TfrmMainServer::PlayResourceSound(const AnsiString &asWavSoundID) {
    PlaySound(asWavSoundID.c_str(), 0, SND_RESOURCE | SND_ASYNC);
}
