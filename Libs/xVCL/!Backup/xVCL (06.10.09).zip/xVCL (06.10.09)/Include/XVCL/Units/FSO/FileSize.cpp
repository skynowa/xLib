/***********************************************************************
*	������ ������ ����� (Mb) (������ API ������� GetFileSize)
*
************************************************************************/


#include <Math.hpp>
#include <sys\stat.h>

float __fastcall TfrmMain::FileSize(const AnsiString &asFilePath) {
	struct stat	statbuf;
	FILE		*pStream;
	if ((pStream = fopen(asFilePath.c_str(), "r+t")) == NULL) {
		MessageBox(NULL, ("File " + asFilePath + " can't open").c_str(), "Pump", 0 | 16 | 0 | 0 | 262144);
		return 0;
	}
	stat(asFilePath.c_str(), &statbuf);
	fclose(pStream);
	return RoundTo((statbuf.st_size) / 1000000.0, -6);       //1000000 Mb    
}