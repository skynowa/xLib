/**********************************************************************
*	vImportData -
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vImportData(TADOConnection *pADOConnection, const UnicodeString &cusFilePath) {
    TStringList *pList = new TStringList();
    pList->LoadFromFile(cusFilePath);        

    for (int i = 0; i < pList->Count; i ++) {
        UnicodeString usParam_1 = usSplitEx(pList->Strings[i], '|', 1);
        UnicodeString usParam_2 = usSplitEx(pList->Strings[i], '|', 2);
        UnicodeString usParam_3 = usSplitEx(pList->Strings[i], '|', 3);
        UnicodeString usParam_4 = usSplitEx(pList->Strings[i], '|', 4);

        //-------------------------------------
        //������
        UnicodeString usSQLStr =
		   L"INSERT \
                INTO \
            TN_INFO \
                ( \
                FN_URL, \
                FN_LOGIN, \
                FN_PASSWORD, \
                FN_EMAIL \
                ) \
            VALUES \
                ('" + \
				usParam_1 + L"','" + \
				usParam_2 + L"','" + \
				usParam_3 + L"','" + \
                usParam_4 + L"')";   //MessageBox(0, usSQLStr.c_str(), "", MB_OK);

        //-------------------------------------
        //��������� ������
        TADOQuery *qryTmp =  new TADOQuery(NULL);
        qryTmp->Connection = pADOConnection;

        qryTmp->Close();
		qryTmp->SQL->Text = usSQLStr;

        try {
			qryTmp->ExecSQL();
        } catch (Exception &exception) {
            Application->ShowException(&exception); //��������� �������, � ��.
        }

        delete qryTmp; qryTmp = NULL;
    }

    delete pList; pList = NULL;

    //-------------------------------------
    //������������ ������ 
}
//---------------------------------------------------------------------------

