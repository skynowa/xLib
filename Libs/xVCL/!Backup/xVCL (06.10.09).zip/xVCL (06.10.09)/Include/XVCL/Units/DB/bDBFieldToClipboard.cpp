/**********************************************************************
*	bDBFieldToClipboard -
*
***********************************************************************/



#include <Clipbrd.hpp>

//---------------------------------------------------------------------------
bool __fastcall TfrmMain::bDBFieldToClipboard(TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {
    bool bRes = false;

    TClipboard *pC = new TClipboard();
    __try {
        pC->AsText = pADOQuery->FieldByName(cusFieldName)->Value;
        bRes = true;
    }
    __finally {
        delete pC; pC = NULL;
    }

    return bRes;
}
//---------------------------------------------------------------------------