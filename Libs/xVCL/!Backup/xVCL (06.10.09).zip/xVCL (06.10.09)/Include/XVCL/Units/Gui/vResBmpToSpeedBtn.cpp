/***********************************************************************
*   vResBmpToSpeedBtn   
*
************************************************************************/


////#include "uLaunchProject.h"

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vResBmpToSpeedBtn(TSpeedButton *pSpeedBtn, const AnsiString &casRes, const AnsiString &casSpeedBtnCaption) {
    /*DEBUG*/XASSERT(NULL != pSpeedBtn);

    ////pBitmap->Transparent      = false;
    ////pBitmap->TransparentColor = clWhite;
    pSpeedBtn->Margin        = 4;
    pSpeedBtn->Spacing       = 4;
    pSpeedBtn->Flat          = true;
    pSpeedBtn->Glyph->Handle = ::LoadBitmap(HInstance, casRes.c_str());
    pSpeedBtn->Caption       = casSpeedBtnCaption;
}
//---------------------------------------------------------------------------


