/***********************************************************************
*   EditRecordsInDB
*
************************************************************************/

void __fastcall TfrmChangePerson::EditRecordsInDB() {
//    frmMain->Query1->Edit();
//
//    frmMain->Query1->FieldByName("AGE")->AsString                = cbbAGE->Text;
//    frmMain->Query1->FieldByName("ALCOHOL")->AsString            = cbbALCOHOL->Text;
//    frmMain->Query1->FieldByName("APARTMENT")->AsString          = cbbAPARTMENT->Text;
//    frmMain->Query1->FieldByName("BUILDING")->AsString           = cbbBUILDING->Text;
//    frmMain->Query1->FieldByName("CHILDREN_AGE")->AsString       = cbbCHILDREN_AGE->Text;
//    frmMain->Query1->FieldByName("CHILDREN_EXISTS")->AsString    = cbbCHILDREN_EXISTS->Text;
//    frmMain->Query1->FieldByName("CHILDREN_MALE")->AsString      = cbbCHILDREN_MALE->Text;
//    frmMain->Query1->FieldByName("CHILDREN_NAME")->AsString      = cbbCHILDREN_NAME->Text;
//    frmMain->Query1->FieldByName("CITY")->AsString               = cbbCITY->Text;
//    frmMain->Query1->FieldByName("CODE")->AsString               = cbbCODE->Text;
//    frmMain->Query1->FieldByName("COMPANY")->AsString            = cbbCOMPANY->Text;
//    frmMain->Query1->FieldByName("COUNTRY")->AsString            = cbbCOUNTRY->Text;
//    frmMain->Query1->FieldByName("DALA")->AsString               = cbbDALA->Text;
//    frmMain->Query1->FieldByName("DISTRICT")->AsString           = cbbDISTRICT->Text;
//    frmMain->Query1->FieldByName("ENTRANCE")->AsString           = cbbENTRANCE->Text;
//    frmMain->Query1->FieldByName("FLOOR")->AsString              = cbbFLOOR->Text;
//    frmMain->Query1->FieldByName("HAIR_COLOR")->AsString         = cbbHAIR_COLOR->Text;
//    frmMain->Query1->FieldByName("HAIR_LENGTH")->AsString        = cbbHAIR_LENGTH->Text;
//    frmMain->Query1->FieldByName("HEIGHT")->AsString             = cbbHEIGHT->Text;
//    frmMain->Query1->FieldByName("HOBBY")->AsString              = cbbHOBBY->Text;
//    frmMain->Query1->FieldByName("HOUSING_CONDITIONS")->AsString = cbbHOUSING_CONDITIONS->Text;
//    frmMain->Query1->FieldByName("JOB_ADDRESS")->AsString        = cbbJOB_ADDRESS->Text;
//    frmMain->Query1->FieldByName("JOB_PROFESSION")->AsString     = cbbJOB_PROFESSION->Text;
//    frmMain->Query1->FieldByName("MARRIED")->AsString            = cbbMARRIED->Text;
//    frmMain->Query1->FieldByName("NAME")->AsString               = cbbNAME->Text;
//    frmMain->Query1->FieldByName("NARCOTIC")->AsString           = cbbNARCOTIC->Text;
//    frmMain->Query1->FieldByName("PATRONYMIC")->AsString         = cbbPATRONYMIC->Text;
//    frmMain->Query1->FieldByName("SALARY")->AsString             = cbbSALARY->Text;
//    frmMain->Query1->FieldByName("SMOKING")->AsString            = cbbSMOKING->Text;
//    frmMain->Query1->FieldByName("SPORT")->AsString              = cbbSPORT->Text;
//    frmMain->Query1->FieldByName("STREET")->AsString             = cbbSTREET->Text;
//    frmMain->Query1->FieldByName("SURNAME")->AsString            = cbbSURNAME->Text;
//    frmMain->Query1->FieldByName("WEIGHT")->AsString             = cbbWEIGHT->Text;
//    frmMain->Query1->FieldByName("BIRTHDAY")->AsString           = dtpBIRTHDAY->Date;
//    frmMain->Query1->FieldByName("BIRTHDAY_FATHER")->AsString    = dtpBIRTHDAY_FATHER->Date;
//    frmMain->Query1->FieldByName("BIRTHDAY_MOTHER")->AsString    = dtpBIRTHDAY_MOTHER->Date;
//    frmMain->Query1->FieldByName("DATE_CHANGE_RECORD")->AsString = dtpDATE_CHANGE_RECORD->Date;
//    frmMain->Query1->FieldByName("DATE_CREATE_RECORD")->AsString = dtpDATE_CREATE_RECORD->Date;
//    frmMain->Query1->FieldByName("HOME_PHONE")->AsString         = edtHOME_PHONE->Text;
//    frmMain->Query1->FieldByName("ICQ")->AsString                = edtICQ->Text;
//    frmMain->Query1->FieldByName("JOB_PHONE")->AsString          = edtJOB_PHONE->Text;
//    frmMain->Query1->FieldByName("MOBILE_PHONE")->AsString       = edtMOBILE_PHONE->Text;
//    frmMain->Query1->FieldByName("NIK")->AsString                = edtNIK->Text;
//    frmMain->Query1->FieldByName("WEB")->AsString                = edtWEB->Text;
//    frmMain->Query1->FieldByName("DESCRIPTION")->AsString        = mmoDESCRIPTION->Text;
//    frmMain->Query1->FieldByName("MAIL")->AsString               = mmoMAIL->Text;
//
//    frmMain->Query1PHOTO->Assign(imgPhoto->Picture);
//    ShowMessage(SysErrorMessage(GetLastError()));
//
//    frmMain->Query1->Post();
//    frmMain->Query1->Refresh();
}
