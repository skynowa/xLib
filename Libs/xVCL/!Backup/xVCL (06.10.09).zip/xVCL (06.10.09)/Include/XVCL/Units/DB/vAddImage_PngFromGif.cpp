/**********************************************************************
*	vAddImage_PngFromGif.cpp
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall TfrmMain::vAddImage_PngFromGif(TImage *pImage, TADOQuery *pADOQuery, const UnicodeString &cusFieldName) {


}
//---------------------------------------------------------------------------