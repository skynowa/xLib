/***********************************************************************
*	�������� ������� �������� ListView ��� ��������
*
************************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSwapLVItems(TListView *pLV, const int &a, const int &b) { 
    int iNew;
    pLV->Items->BeginUpdate();
    {
        pLV->Items->Add();
        iNew = pLV->Items->Count - 1;
        pLV->Items->Item[iNew] = pLV->Items->Item[a];
        pLV->Items->Item[a]    = pLV->Items->Item[b];
        pLV->Items->Item[b]    = pLV->Items->Item[iNew];
        pLV->Items->Delete(iNew);
    }
    pLV->Items->EndUpdate();
}
//---------------------------------------------------------------------------
