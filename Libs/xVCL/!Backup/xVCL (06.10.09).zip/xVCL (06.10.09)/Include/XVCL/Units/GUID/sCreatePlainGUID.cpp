#include <ComObj.hpp>
#include <objbase.h>  
//---------------------------------------------------------------------------
//TODO: + sCreatePlainGUID
AnsiString asCreatePlainGUID() {
	AnsiString  asRes  = "";
	GUID        guidId = {0};
	HRESULT     hrGuid;

    hrGuid = ::CoCreateGuid(&guidId);
    if (FAILED(hrGuid)) {
        return Now().DateTimeString();
    }

    CHAR szBuff[64] = {0};                

	INT iRes = ::wsprintf(
                    szBuff,
                    "%04X-%02X-%02X-%02X%02X-%02X%02X%02X%02X%02X%02X",
                    guidId.Data1,
                    guidId.Data2,
                    guidId.Data3,
                    guidId.Data4[0], guidId.Data4[1],
                    guidId.Data4[2], guidId.Data4[3], guidId.Data4[4], guidId.Data4[5], guidId.Data4[6], guidId.Data4[7]
	);

    if (0 < ::lstrlen(szBuff)) {
        asRes = AnsiString(szBuff, iRes);
    } else {
        asRes = Now().DateTimeString();
    }

	return asRes;
}
//---------------------------------------------------------------------------
