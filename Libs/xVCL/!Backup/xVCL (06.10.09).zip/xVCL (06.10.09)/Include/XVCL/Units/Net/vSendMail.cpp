/**********************************************************************
*	vSendMail.cpp	
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSendMail(const UnicodeString &cusURL) {
	/*DEBUG*/assert(false == cusURL.IsEmpty());
	
    ::ShellExecute(NULL, NULL, ("mailto:" + cusURL).w_str(), cusURL.w_str(), NULL, SW_SHOW);
}
//---------------------------------------------------------------------------
