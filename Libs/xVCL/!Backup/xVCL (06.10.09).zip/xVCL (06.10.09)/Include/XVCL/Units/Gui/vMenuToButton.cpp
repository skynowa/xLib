/**********************************************************************
*	vMenuToButton - ������ � ��������
*
***********************************************************************/


#include "uDM.h"        //frmDM
#include "uDoc.h"       //frmDoc
#include "uEToken.h"    //frmMain

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vMenuToButton(TPopupMenu *pPopupMenu, TBitBtn *pBitBtn) {
    TPoint Point = pBitBtn->ClientToScreen(TPoint(0, 0));
    pPopupMenu->Popup(Point.x, Point.y + pBitBtn->Height);
}
//---------------------------------------------------------------------------
