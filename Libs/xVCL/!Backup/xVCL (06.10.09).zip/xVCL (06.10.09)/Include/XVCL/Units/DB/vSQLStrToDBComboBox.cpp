/**********************************************************************
*	vSQLStrToDBComboBox -
*
***********************************************************************/


#include "uDmMain.h"    //frmDM

//---------------------------------------------------------------------------
void __fastcall TfrmMain::vSQLStrToDBComboBox(TDBComboBox *pCbb, const UnicodeString &cusFieldName, TADOConnection *pADOConnection, const UnicodeString &cusSQLStr) {
	TADOQuery *qryTmp =  new TADOQuery(NULL);
	qryTmp->Connection = pADOConnection;

	qryTmp->Close();
	qryTmp->SQL->Text = cusSQLStr;

    try {
        qryTmp->Open();
        qryTmp->First();
        pCbb->Items->Clear();
        while (! qryTmp->Eof) {
            if (false == qryTmp->FieldByName(cusFieldName)->IsNull) {
                pCbb->Items->Add(qryTmp->FieldByName(cusFieldName)->Value);
            }                
            qryTmp->Next();
        }
        qryTmp->Close();

        pCbb->DropDownCount = 20;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }

	delete qryTmp; qryTmp = NULL;
}
//---------------------------------------------------------------------------
/*
    //��������� cbbCustomerName
    TADOQuery * qryTmp1 =  new TADOQuery(NULL);
    qryTmp1->Connection = frmMain->conCustomers;
    qryTmp1->SQL->Text = "Select * from TN_CUSTOMERS";
    qryTmp1->Open();

    qryTmp1->First();
    cbbCustomerName->Items->Clear();
    while (! qryTmp1->Eof) {
        cbbCustomerName->Items->Add(qryTmp1->FieldByName("FN_CUSTOMER_NAME")->Value);
        qryTmp1->Next();
    }
    qryTmp1->Close();

    delete qryTmp1; qryTmp1 = NULL;
    */
