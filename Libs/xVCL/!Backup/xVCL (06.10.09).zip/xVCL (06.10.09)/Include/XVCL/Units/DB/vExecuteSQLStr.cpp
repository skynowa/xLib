/**********************************************************************
*	vExecuteSQLStr -
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vExecuteSQLStr(TADOConnection *pADOConnection, const UnicodeString &cusSQLStr, bool bSelectMode) {
	/*DEBUG*/assert(NULL  != pADOConnection);
	/*DEBUG*/assert(false == cusSQLStr.IsEmpty()); 

	const std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(this));
	/*DEBUG*/assert(NULL != apqryTmp.get());
	
	apqryTmp->Connection = pADOConnection;

	apqryTmp->Close();
	apqryTmp->SQL->Text = cusSQLStr;

    try {
        if (true == bSelectMode) {
           apqryTmp->Open();
        } else {
           apqryTmp->ExecSQL();
        }
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }
}
//---------------------------------------------------------------------------