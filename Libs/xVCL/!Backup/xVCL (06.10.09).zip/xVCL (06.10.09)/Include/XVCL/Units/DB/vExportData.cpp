/**********************************************************************
*	vImportData -
*
***********************************************************************/


//---------------------------------------------------------------------------
void __fastcall TfrmMain::vExportData(TADOConnection *pADOConnection, const UnicodeString &cusFilePath, const UnicodeString &usMode) {
    TStringList *pList = new TStringList();

    //-------------------------------------
    //������
	UnicodeString asSQLStr = L"SELECT * FROM TN_INFO";

    //-------------------------------------
    //��������� ������
    TADOQuery *qryTmp =  new TADOQuery(NULL);
    qryTmp->Connection = pADOConnection;

    qryTmp->Close();
    qryTmp->SQL->Text = asSQLStr;

    try {
        qryTmp->Open();

        qryTmp->First();
        while (! qryTmp->Eof) {
            pList->Add(
				qryTmp->FieldByName(L"FN_URL")->AsString      + L"|" +
				qryTmp->FieldByName(L"FN_LOGIN")->AsString    + L"|" +
				qryTmp->FieldByName(L"FN_PASSWORD")->AsString + L"|" +
				qryTmp->FieldByName(L"FN_EMAIL")->AsString
            );
            qryTmp->Next();
        }
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }

    pList->SaveToFile(cusFilePath);

    delete qryTmp; qryTmp = NULL;
    delete pList;  pList  = NULL;
}
//---------------------------------------------------------------------------

