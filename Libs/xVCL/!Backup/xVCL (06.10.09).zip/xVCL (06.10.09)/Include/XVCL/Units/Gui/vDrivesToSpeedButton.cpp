/***********************************************************************
*	vDrivesToSpeedButton.cpp
*
************************************************************************/


#include <Math.hpp>
//---------------------------------------------------------------------------        
void __fastcall TfrmMain::vDrivesToSpeedButton() {
   //-------------------------------------
	/* ��� SpeedButton */
    sbtnDisk1->Visible  = false;
	sbtnDisk2->Visible  = false;
	sbtnDisk3->Visible  = false;
	sbtnDisk4->Visible  = false;
	sbtnDisk5->Visible  = false;
	sbtnDisk6->Visible  = false;
	sbtnDisk7->Visible  = false;
	sbtnDisk8->Visible  = false;
	sbtnDisk9->Visible  = false;
	sbtnDisk10->Visible = false;

	DWORD dwBufLen = ::GetLogicalDriveStrings(0, NULL);
	/*DEBUG*/assert(dwBufLen != 0);
	if (!dwBufLen) {
		return;
	}

	TCHAR *pwzBuff = new TCHAR[sizeof(TCHAR) * dwBufLen], *pBuf = pwzBuff;
	/*DEBUG*/assert(NULL != pwzBuff);
	/*DEBUG*/assert(NULL != pBuf);
	__try {
		if (!::GetLogicalDriveStrings(dwBufLen, pwzBuff)) {
			return;
		}

		//-------------------------------------
		//���� �� ������
		int iSbtnDriveIndex = 0;
		sbtnMyComputer->Hint = L"";

		while (*pBuf) {      //pBuf - ��� ���� �� ������ "C:\\"
			/*DEBUG*/assert(NULL != pBuf);

			iSbtnDriveIndex ++;

			//-------------------------------------
			//����� �����
			UnicodeString usDrivePath = pBuf;            //���� �� ������

			//-------------------------------------
			//������� ��������� �� ��� ���������� �����
			pBuf += (usDrivePath.Length() + 1) /* * sizeof(wchar_t)*/;

			//-------------------------------------
			//������ �����
			std::auto_ptr<Graphics::TBitmap> apBitmap(new Graphics::TBitmap());
			apBitmap.get()->Transparent      = true;
			apBitmap.get()->TransparentColor = clBtnFace;	// clGradientActiveCaption;     ////????????????


			SHFILEINFO info = {0};
			DWORD dwImageHandle = ::SHGetFileInfo(usDrivePath.t_str(), 0, &info, sizeof(info), SHGFI_SYSICONINDEX | SHGFI_SMALLICON);
			if (0 != dwImageHandle) {
				ilDrives->Handle = dwImageHandle;
				ilDrives->ShareImages = true;
			}
			////CloseHandle(dwImageHandle);

			if	(ilDrives->Count > 0) {
				ilDrives->GetBitmap(info.iIcon, apBitmap.get());
			}

			//-------------------------------------
			//����� �� ����?
			if (FALSE == bIsDriveReady(usDrivePath)) {
				////MessageBox(0, (L"vDrivesToSpeedButton ���� " + usDrivePath + L" �� �����.").t_str(), usAppName.t_str(), MB_OK);
			}

			//-------------------------------------
			//����� �����
			TCHAR wszDriveLabel[30] = _T("[Empty]");

			if (false == ::GetVolumeInformation(usDrivePath.t_str(), wszDriveLabel, 255, NULL, NULL, NULL, NULL, NULL)) {

			}

			//-------------------------------------
			//��������� / ������� �����
			unsigned __int64 ui64FreeBytesAvailable     = 0;
			unsigned __int64 ui64TotalNumberOfBytes     = 0;
			unsigned __int64 ui64TotalNumberOfFreeBytes = 0;

			if (FALSE == ::GetDiskFreeSpaceEx(usDrivePath.t_str(), (PULARGE_INTEGER)&ui64FreeBytesAvailable, (PULARGE_INTEGER)&ui64TotalNumberOfBytes, (PULARGE_INTEGER)&ui64TotalNumberOfFreeBytes)) {

			}

			//-------------------------------------
			//�������� ��� ������ �� ������
			TSpeedButton *psbtnDrives[10] = {
				sbtnDisk1,
				sbtnDisk2,
				sbtnDisk3,
				sbtnDisk4,
				sbtnDisk5,
				sbtnDisk6,
				sbtnDisk7,
				sbtnDisk8,
				sbtnDisk9,
				sbtnDisk10
			};

			vBuildDriveSbtn(psbtnDrives[iSbtnDriveIndex - 1], apBitmap.get(), usDrivePath, wszDriveLabel, ui64TotalNumberOfBytes, ui64TotalNumberOfFreeBytes);

			//-------------------------------------
			//���� � ������ "My Computer"
			UnicodeString usHint = usDrivePath.SubString(0, 2) + _T(" (") + wszDriveLabel + _T(")")                    + _T(" ")
								   _T("Total: ") + FloatToStr(RoundTo(ui64TotalNumberOfBytes     / 1000000000.0, - 3)) + _T(" Gb  ")
								   _T("Free:  ") + FloatToStr(RoundTo(ui64TotalNumberOfFreeBytes / 1000000000.0, - 3)) + _T(" Gb  ");
			sbtnMyComputer->Hint += usHint + _T("\r\n");
		}
	} __finally {
		/*DEBUG*/assert(NULL != pwzBuff);
		delete [] pwzBuff;	pwzBuff = NULL;
	}
}
//---------------------------------------------------------------------------
