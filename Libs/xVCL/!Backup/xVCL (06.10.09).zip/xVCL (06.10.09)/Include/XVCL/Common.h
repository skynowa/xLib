#ifndef XVCL_CommonH
#define XVCL_CommonH

#ifndef WIN32
////#    error This file is intended only for use with the Microsoft Windows API.
#endif
#ifndef __cplusplus
   #error XVCL requires C++ compilation (use a .cpp suffix)
#endif


#ifdef  _UNICODE
	//#define tstring std::wstring 
    #define tString UnicodeString 
#else   
	//#define tstring std::string 
    #define tString AnsiString 
#endif  /*_UNICODE*/

#define DELETE_POINTER(p)   if (NULL != (p)) {delete p;    p = NULL;} 
#define DELETE_ARRAY(a)		if (NULL != (a)) {delete [] a; a = NULL;}
#define ZERO_BUFF(x)        ::ZeroMemory(&x, sizeof(x));
#define SIZEOF(array)       (sizeof(array) / sizeof(array[0]))

#define CHECK_HANDLE(h)		((INVALID_HANDLE_VALUE != h) && (NULL != h) /*&& (FALSE != ::GetHandleInformation(h, HANDLE_FLAG_INHERIT))*/)
#define CLOSE_HANDLE(h)		if (INVALID_HANDLE_VALUE != h) {::CloseHandle(h);	h = INVALID_HANDLE_VALUE;}

#define max(a,b)            (((a) > (b)) ? (a) : (b))
#define min(a,b)            (((a) < (b)) ? (a) : (b))

#pragma option -w-8027		   // function not expanded inline

#ifndef STRICT
  #define STRICT 1
#endif

//Prevent winsock.h #include's.
#define _WINSOCKAPI_            

#include <windows.h>
#include <windowsx.h>
#include <string>
#include <stdio.h>
#include <tchar.h>
////#include <shlwapi.h>
//---------------------------------------------------------------------------
#endif  //XVCL_CommonH