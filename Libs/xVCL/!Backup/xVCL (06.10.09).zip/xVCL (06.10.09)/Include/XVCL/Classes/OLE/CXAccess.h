/**********************************************************************
*	�����  CXAccess (CXAccess.h)
*
***********************************************************************/


#ifndef CXAccessH
#define CXAccessH       
//---------------------------------------------------------------------------
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <Classes.hpp>
#include <SysUtils.hpp> //
#include <system.hpp>   //AnsiString
#include <SysUtils.hpp> //GetCurrentDir, Now()
#include <windows.h>	//vErrorMessageBox
#include <ComObj.hpp>   //OLE
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class CXAccess {
	public:
		CXAccess();
		~CXAccess();

		bool          bIsMDBFile        (const UnicodeString &usFilePath); /*+*/
		bool          bIsOleAppInstalled(const UnicodeString &cusApplicationString); /*+*/
		bool          bCreateResMDB     (const UnicodeString &usFilePath, const UnicodeString &cusResource);
		bool          bCreateAdoMDB     (const UnicodeString &cusMdbFilePath); /*+*/
		bool          bCompactMDB       (const UnicodeString &cusMdbFilePath, const UnicodeString &cusPass1, const UnicodeString &cusPass2); /*+*/
		bool          bCompactMDBEx     (TADOConnection *pADOConnection, TADOQuery *pADOQuery, const UnicodeString &cusMdbFilePath, const UnicodeString &cusPass1, const UnicodeString &cusPass2);
		bool          bCreateBackupMDB  (const UnicodeString &cusMdbFilePath); /*+*/
		UnicodeString usADOVersion      (); /*+*/
	
	private:

};
//---------------------------------------------------------------------------
#endif