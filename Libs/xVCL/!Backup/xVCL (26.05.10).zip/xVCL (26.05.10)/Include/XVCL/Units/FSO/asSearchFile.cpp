/**********************************************************************
   
***********************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
tString __fastcall asSearchFile(const tString &asFileNameMask, const tString &asFoderPath) {
    TCHAR szBuff[MAX_PATH]; ::ZeroMemory(&szBuff, sizeof(szBuff));

    tString asFileName(FileSearch(asFileNameMask, asFoderPath + tString(";") + tString(szBuff)));
    /*if (asFileName.IsEmpty()) {
        ShowMessage(tString("Couldn't find ") + "ToDo.tdl_" + ".");
    } else {
        ShowMessage(tString("Found ") + asFileName + ".");
    }*/
	return asFileName;
}
//---------------------------------------------------------------------------
