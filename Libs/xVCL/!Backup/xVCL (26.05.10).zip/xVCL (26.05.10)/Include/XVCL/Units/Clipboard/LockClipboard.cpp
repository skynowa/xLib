/***********************************************************************
*   
*
************************************************************************/

//static HGLOBAL   hglb;

void __fastcall TfrmMainServer::LockClipboard(bool bLockFlag) {
    if (bLockFlag == true) {
        OpenClipboard(NULL);
//        hglb = GetClipboardData(CF_TEXT);
//        GlobalLock(hglb);

        EmptyClipboard();
    } else {
//        GlobalUnlock(hglb);
//        GlobalFree(hglb);
        CloseClipboard();
    }
}

/*

				if(OpenClipboard(NULL)) {
					EmptyClipboard();
					SetClipboardData(CF_DIB,hmem);
					CloseClipboard();
				}
				else {
					GlobalFree(hmem);
				}

*/
