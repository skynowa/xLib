/***********************************************************************
*	vSpeedButton_LoadDrives.cpp
*
************************************************************************/


#include <vcl.h>
#pragma hdrstop
#include <Math.hpp>
//---------------------------------------------------------------------------        
void vSpeedButton_LoadDrives(TImageList *pilDrives, const std::vector<TSpeedButton *> &vecsbtnBtns) {
	/*DEBUG*/xASSERT(NULL != pilDrives);
	/*DEBUG*/// vecsbtnBtns - n/a

	BOOL bRes = FALSE;
	
	//-------------------------------------
	//������ TSpeedButton-�
	for (size_t i = 0; i < vecsbtnBtns.size(); ++ i) {
		vecsbtnBtns.at(i)->Visible = false;  
	}


	tstring sLstr = CXDrive::sGetLogicalStrings();

	ULONG ulBuffSize = ::GetLogicalDriveStrings(0, NULL);
	/*DEBUG*/xASSERT(ulBuffSize != 0);

	TCHAR *pszBuff = new TCHAR[ulBuffSize * sizeof(TCHAR) + sizeof(TCHAR)], *pBuf = pszBuff;
	/*DEBUG*/xASSERT(NULL != pszBuff);
	/*DEBUG*/xASSERT(NULL != pBuf);
	
	__try {
		ulBuffSize = ::GetLogicalDriveStrings(ulBuffSize, pszBuff);
		/*DEBUG*/xASSERT(0 != ulBuffSize);

		//-------------------------------------
		//���� �� ������
		int iSbtnDriveIndex = - 1;
		////sbtnMyComputer->Hint = _T("");

		while (*pBuf) {      //pBuf - ��� ���� �� ������ "C:\\"
			/*DEBUG*/xASSERT(NULL != pBuf);

			++ iSbtnDriveIndex;

			//-------------------------------------
			//����� �����
			String sDrivePath(pBuf);    //ShowMessage(pBuf);    //���� �� ������

			//-------------------------------------
			//������� ��������� �� ��� ���������� �����
			pBuf += sDrivePath.Length() + sizeof('\0'); 	//'\0' - �� ���������

			//-------------------------------------
			//������ �����
		    const std::auto_ptr<Graphics::TBitmap> apBitmap(new Graphics::TBitmap());
			/*DEBUG*/xASSERT(NULL != apBitmap.get());
			apBitmap->Transparent      = true;
			apBitmap->TransparentColor = clBtnFace;	// clGradientActiveCaption;     ////????????????

			SHFILEINFO info = {0};
			DWORD ulImageHandle = ::SHGetFileInfo(sDrivePath.c_str(), 0, &info, sizeof(info), SHGFI_SYSICONINDEX | SHGFI_SMALLICON);
			if (0 != ulImageHandle) {
				pilDrives->Handle      = ulImageHandle;
				pilDrives->ShareImages = true;
			}
			////CloseHandle(ulImageHandle);

			if (pilDrives->Count > 0) {
				pilDrives->GetBitmap(info.iIcon, apBitmap.get());
			}

			//-------------------------------------
			//�������� ���������� �����
			bRes = CXDrive::bIsReady(sDrivePath.c_str());
			/*DEBUG*///n/a
			xCHECK_DO(FALSE == bRes, -- iSbtnDriveIndex; continue);





			//-------------------------------------
			//����� �����
			TCHAR szDriveLabel[30 + 1] = _T("[Empty]");
			
			bRes = CXDrive::bGetInformation(sDrivePath.c_str(), szDriveLabel, 255, NULL, NULL, NULL, NULL, NULL);
			/*DEBUG*/xASSERT(FALSE != bRes);

			//-------------------------------------
			//��������� / ������� �����
			unsigned __int64 ui64FreeBytesAvailable     = 0;
			unsigned __int64 ui64TotalNumberOfBytes     = 0;
			unsigned __int64 ui64TotalNumberOfFreeBytes = 0;

			bRes = CXDrive::bGetFreeSpace(sDrivePath.c_str(), &ui64FreeBytesAvailable, &ui64TotalNumberOfBytes, &ui64TotalNumberOfFreeBytes);
			/*DEBUG*/xASSERT(FALSE != bRes);

			//-------------------------------------
			//�������� ��� ������ �� ������
			/*DEBUG*/xASSERT(vecsbtnBtns.size() > iSbtnDriveIndex);
			/*DEBUG*/xASSERT(NULL  != vecsbtnBtns.at(iSbtnDriveIndex));
			/*DEBUG*/xASSERT(NULL  != apBitmap.get());
			/*DEBUG*/xASSERT(false == sDrivePath.IsEmpty());
			/*DEBUG*/xASSERT(false == String(szDriveLabel).IsEmpty());

			vecsbtnBtns.at(iSbtnDriveIndex)->Glyph   = apBitmap.get();
			vecsbtnBtns.at(iSbtnDriveIndex)->Caption = sDrivePath.SubString(0, 1);    //������ "C"
			vecsbtnBtns.at(iSbtnDriveIndex)->Hint    = _T("Label: ") + String(szDriveLabel)                                               + _T("\r\n")
													   _T("Total: ") + FloatToStr(RoundTo(ui64TotalNumberOfBytes     / 1000000000.0, - 3)) + _T(" Gb\r\n")
							                           _T("Free:  ") + FloatToStr(RoundTo(ui64TotalNumberOfFreeBytes / 1000000000.0, - 3)) + _T(" Gb");

			vecsbtnBtns.at(iSbtnDriveIndex)->Visible = true;
									
			//-------------------------------------
			//���� � ������ "My Computer"
			////tString usHint = sDrivePath.SubString(0, 2) + _T(" (") + szDriveLabel + _T(")")                    + _T(" ")
			////					   _T("Total: ") + FloatToStr(RoundTo(ui64TotalNumberOfBytes     / 1000000000.0, - 3)) + _T(" Gb  ")
			////					   _T("Free:  ") + FloatToStr(RoundTo(ui64TotalNumberOfFreeBytes / 1000000000.0, - 3)) + _T(" Gb  ");
			/////sbtnMyComputer->Hint += usHint + _T("\r\n");
		} //while
	} __finally {
		/*DEBUG*/xASSERT(NULL != pszBuff);
		xDELETE_ARRAY(pszBuff);
	}
}
//---------------------------------------------------------------------------
