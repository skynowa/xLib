/****************************************************************************
*    bReadFile
*
*****************************************************************************/
	

//---------------------------------------------------------------------------
bool bReadFile(const tString &csFilePath, tString *psText) {
	/*DEBUG*/xASSERT(false == csFilePath.IsEmpty());
	/*DEBUG*/xASSERT(true  == FileExists(csFilePath));
	/*DEBUG*/xASSERT(NULL  != psText);

	std::auto_ptr<TStringList> apslSL(new TStringList());
	/*DEBUG*/xASSERT(NULL != apslSL.get());

	apslSL->LoadFromFile(csFilePath);

	////usTemp = sRemoveEOL(usTemp.c_str()).c_str();
		
	(*psText) = apslSL->Text.SetLength(apslSL->Text.Length() - tString(_T("\r\n")).Length());

    
	return true;
}
//---------------------------------------------------------------------------


/*function SaveFileFromStr(const SrcStr,FilePath: String): Boolean;
var
   FS: TFileStream;
begin
   Result := False;
   FS := TFileStream.Create(FilePath,fmCreate);
   try
	 FS.Write(SrcStr[1],Length(SrcStr));
	 Result := True;
   finally
	 FS.Free;
	end;
end;*/