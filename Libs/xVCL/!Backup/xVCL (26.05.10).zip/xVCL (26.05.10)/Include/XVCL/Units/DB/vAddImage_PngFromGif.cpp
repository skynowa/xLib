/**********************************************************************
*	vAddImage_PngFromGif.cpp
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
void __fastcall vAddImage_PngFromGif(TImage *pImage, TADOQuery *pADOQuery, const tString &csFieldName) {


}
//---------------------------------------------------------------------------