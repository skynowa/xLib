/***********************************************************************
*	iDateTimeToSeconds - ��������� ����� � �������	
*
************************************************************************/


////#include <DateUtils.hpp>
//---------------------------------------------------------------------------
__int64 i64DateTimeToSeconds(const TDateTime &dtDateTime) {
    WORD wYear, wMonth, wDay, wHour, wMin, wSec, wMSec;
    
	DecodeTime(dtDateTime, wHour, wMin, wSec, wMSec);
    
	return (wHour * 60 * 60) + (wMin * 60) + (wSec);
}
//---------------------------------------------------------------------------
/*
extern PACKAGE Word __fastcall YearOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall MonthOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall WeekOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall DayOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall HourOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall MinuteOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall SecondOf(const System::TDateTime AValue);
extern PACKAGE Word __fastcall MilliSecondOf(const System::TDateTime AValue);
*/
