/**********************************************************************
    ���� ���� �� ����������, �����. ���� � ����

***********************************************************************/


#include "uLaunchProject.h"

//---------------------------------------------------------------------------
tString __fastcall asSearchFileEx(const tString &asFileExt, const tString &asFoderPath) {
	//-------------------------------------
	//CHECK
////    if (DirectoryExists(asFoderPath) == false) {
////        return tString("");
////    }        

    static tString asFilePathRes("");

    TSearchRec SR;    ::ZeroMemory(&SR, sizeof(SR));
	if (0 == FindFirst(asFoderPath + "*.*", faAnyFile, SR)) {
        do {
            if (SR.Attr & faDirectory) {    //ShowMessage(SR.Name);
                //�����
                if (SR.Name != ".") {
                    if (SR.Name != "..") {
                        asSearchFileEx(asFileExt, asFoderPath + SR.Name + "\\");
                    }
                }
            } else {                       //ShowMessage(SR.Name);
                //�����
                if (ExtractFileExt(SR.Name) == asFileExt) {
                    //ShowMessage(asFoderPath + SR.Name);
                    asFilePathRes = asFoderPath + SR.Name; //�����. ���� � �����
                }
            }
        }
        while (0 == FindNext(SR));

        FindClose(SR);
	}
    //ShowMessage(asFilePathRes);

    
    return asFilePathRes; //�����. ���� � �����
}
//---------------------------------------------------------------------------
