/**********************************************************************
*	vDBGridSelectedRowsToClip 
*
***********************************************************************/


#include "uDoc.h"       //frmDoc
#include "uDM.h"        //frmDM
#include <Clipbrd.hpp>
//---------------------------------------------------------------------------
void __fastcall vDBGridSelectedRowsToClip(TDBGrid *dbgrdGrid) {
    tString   asDocId         = dmDM->qryDocs->FieldByName("FN_DOC_ID")->Value;
    TStringList *pslSelectedRows = new TStringList();
    TBookmark    SavePlace       = dbgrdGrid->DataSource->DataSet->GetBookmark();

    dbgrdGrid->DataSource->DataSet->First();
    dbgrdGrid->DataSource->DataSet->DisableControls();
    try {
        while (! dbgrdGrid->DataSource->DataSet->Eof) {
            if (dbgrdGrid->SelectedRows->CurrentRowSelected) {
                //DEBUG(dbgrdGrid->DataSource->DataSet->FieldByName("FN_ETOKEN_ID")->Value);
                pslSelectedRows->Add(dbgrdGrid->DataSource->DataSet->FieldByName("FN_ETOKEN_ID")->Value);
            }
            dbgrdGrid->DataSource->DataSet->Next();
        }
        dbgrdGrid->DataSource->DataSet->GotoBookmark(SavePlace);
        dbgrdGrid->DataSource->DataSet->FreeBookmark(SavePlace);
    } __finally {
        dbgrdGrid->DataSource->DataSet->EnableControls();
    }   //DEBUG(pslSelectedRows->Text);
    
    //-------------------------------------
    //���������� � �����
    try {
        ActivateKeyboardLayout(LoadKeyboardLayout(IntToHex(MAKELANGID(LANG_RUSSIAN, SUBLANG_DEFAULT), 8).c_str(), 0), 0);
        Clipboard()->SetTextBuf(pslSelectedRows->Text.c_str());
        //--MSG_BOX_INFO("������ ������� �������������� � ����� ������");
    } catch (Exception &exception) {
        Application->ShowException(&exception);
    }                    

    delete pslSelectedRows; pslSelectedRows = NULL;
}
//---------------------------------------------------------------------------