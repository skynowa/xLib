/**********************************************************************
*   sFileExistsEx - ��������� ���� �� �������������
*
***********************************************************************/


//---------------------------------------------------------------------------
tString sFileExistsEx(const tString &csFilePath) { 
    static int s_iFileExistsIndex = 0; 
    tString    sFileDir           = ExtractFileDir(csFilePath);
    tString    sFileName          = ExtractFileName(csFilePath).SubString(0, LastDelimiter(_T("."), ExtractFileName(csFilePath)) - 1);
    tString    sFileExt           = ExtractFileExt(csFilePath);

    tString sTemp = csFilePath;

    while (FileExists(sTemp)) {
        s_iFileExistsIndex ++;
		
        sTemp = sFileDir                     + _T("\\") + 
		        sFileName                    + _T(" (") + 
				IntToStr(s_iFileExistsIndex) + _T(")")  + 
				sFileExt;
    }

    s_iFileExistsIndex = 0;

    return sTemp;
}
//---------------------------------------------------------------------------