/**********************************************************************
*	vExecSQLStr -
*
***********************************************************************/


//---------------------------------------------------------------------------
void vExecSQLStr(TADOConnection *pADOConnection, const String &csSQLStr, bool bIsSelectMode) {
	/*DEBUG*/xASSERT(NULL  != pADOConnection);
	/*DEBUG*/xASSERT(false == csSQLStr.IsEmpty());

	std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(NULL));
    /*debug*/xASSERT(NULL != apqryTmp.get());

	apqryTmp->Close();
	apqryTmp->Connection = pADOConnection;
	apqryTmp->SQL->Text  = csSQLStr;

    try {
        if (true == bIsSelectMode) {
           apqryTmp->Open();
        } else {
           apqryTmp->ExecSQL();
        }
    } catch (Exception &exception) {
        Application->ShowException(&exception);     //��������� �������, � ��.
    }
}
//---------------------------------------------------------------------------

