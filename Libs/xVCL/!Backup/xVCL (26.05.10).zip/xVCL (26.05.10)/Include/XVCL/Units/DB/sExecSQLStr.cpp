/**********************************************************************
*	asExecSQLStr - tmp_var - ������ ���� � SQL �������
*
***********************************************************************/


//---------------------------------------------------------------------------
String sExecSQLStr(TADOConnection *pADOConnection, const String &csSQLStr) {
	/*DEBUG*/xASSERT(NULL  != pADOConnection);
	/*DEBUG*/xASSERT(false == csSQLStr.IsEmpty());
	
	String sResult;
	
	const std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(0));
	/*DEBUG*/xASSERT(NULL != apqryTmp.get());
	
	apqryTmp->Connection = pADOConnection;

    try {
        apqryTmp->Close();
        apqryTmp->SQL->Text = csSQLStr;
        apqryTmp->Open();   

		sResult = apqryTmp->FieldByName(_T("tmp_var"))->AsString;
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }

	/*DEBUG*/xASSERT(false == sResult.IsEmpty());

	return sResult;
}
//---------------------------------------------------------------------------