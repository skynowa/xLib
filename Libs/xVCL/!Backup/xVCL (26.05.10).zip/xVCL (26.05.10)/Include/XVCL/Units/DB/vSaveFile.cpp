/**********************************************************************
*	vSaveFile.cpp	
*
***********************************************************************/


//---------------------------------------------------------------------------
void vSaveFile(TADOQuery *pADOQuery, const String &csFieldName, const String &csNewFileName) {
	/*DEBUG*/xASSERT(NULL  != pADOQuery);
	/*DEBUG*/xASSERT(false == csFieldName.IsEmpty());

	//-------------------------------------
	//�������� �������
	const std::auto_ptr<TSaveDialog> apdlgSaveFile(new TSaveDialog(0));
	/*DEBUG*/xASSERT(NULL != apdlgSaveFile.get());

	apdlgSaveFile->Name     = _T("dlgSaveFile");
	apdlgSaveFile->Filter   = _T("All files (*.*)|*.*");
	apdlgSaveFile->FileName = csNewFileName;

	if (false == apdlgSaveFile->Execute()) {
		pADOQuery->Cancel();
		return;
	}

	//-------------------------------------
	//���������� �����
	((TBlobField *)pADOQuery->FieldByName(csFieldName))->SaveToFile(apdlgSaveFile->FileName);
}
//---------------------------------------------------------------------------