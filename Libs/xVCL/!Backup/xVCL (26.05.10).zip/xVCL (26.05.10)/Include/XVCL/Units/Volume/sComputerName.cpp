//---------------------------------------------------------------------------
//TODO: + asComputerName
tString asComputerName() {
	BOOL        bRes                                = FALSE;
	ULONG       ulBuffSize                          = MAX_COMPUTERNAME_LENGTH;
	CHAR        szBuff[MAX_COMPUTERNAME_LENGTH + 1] = {0};

	bRes = ::GetComputerName(szBuff, &ulBuffSize);
	if (FALSE == bRes) {
        return "LOCALHOST";
    }

	return tString(szBuff, ulBuffSize);
}
//---------------------------------------------------------------------------
