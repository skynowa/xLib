/***********************************************************************
*	������� ��������� ����
*
************************************************************************/


//---------------------------------------------------------------------------
void vForm_BringToFront(TForm *pfrmForm) {
	/*DEBUG*/xASSERT(NULL != pfrmForm);

	HWND hCurrWnd = ::GetForegroundWindow();
	int  iMyTID   = ::GetCurrentThreadId();
	int  iCurrTID = ::GetWindowThreadProcessId(hCurrWnd, 0);

	::AttachThreadInput  (iMyTID, iCurrTID, TRUE);
	::SetForegroundWindow(pfrmForm->Handle);
	::AttachThreadInput  (iMyTID, iCurrTID, FALSE);
}
//---------------------------------------------------------------------------
