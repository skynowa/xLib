/**********************************************************************
*	vExecuteSQLStr -
*
***********************************************************************/


//---------------------------------------------------------------------------
void vExecuteSQLStr(TADOConnection *pADOConnection, const String &cusSQLStr, bool bSelectMode) {
	/*DEBUG*/xASSERT(NULL  != pADOConnection);
	/*DEBUG*/xASSERT(false == cusSQLStr.IsEmpty());

	const std::auto_ptr<TADOQuery> apqryTmp(new TADOQuery(0));
	/*DEBUG*/xASSERT(NULL != apqryTmp.get());

	apqryTmp->Close();
	apqryTmp->Connection = pADOConnection;
	apqryTmp->SQL->Text = cusSQLStr;

    try {
        if (true == bSelectMode) {
           apqryTmp->Open();
        } else {
           apqryTmp->ExecSQL();
        }
    } catch (Exception &exception) {
        Application->ShowException(&exception); //��������� �������, � ��.
    }
}
//---------------------------------------------------------------------------