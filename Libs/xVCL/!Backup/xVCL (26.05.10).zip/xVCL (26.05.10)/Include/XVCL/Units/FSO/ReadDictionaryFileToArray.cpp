/***********************************************************************
*	������ ������� � ������
*
************************************************************************/

#include  <stdio.h>
long __fastcall ReadDictionaryFileToArray(tString asPathToFile) {
	FILE *F;
    if ((F=fopen(asPathToFile.c_str(), "r+t"))==NULL){
		MessageBox(NULL, ("File: "+asPathToFile+" can't open").c_str(), "LAN Hack++", 0 | 16 | 0 | 0 | 262144);
	    return false;
    }

    char  s[80];
    do{
	    fgets(s, 80, F);
		//ShowMessage(s);
	    if(feof(F)){
    		break;
    	}
    } while(true);
    fclose(F);
	return Lines;
}
