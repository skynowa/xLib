/***********************************************************************
*	���� �� ���� ������ (��� prgMainCommon ���������� MaxValue)
*
************************************************************************/
int AllFilesInFolder=0;
int __fastcall doCountAllFilesInFolder(tString path){
	TSearchRec sr;
	if (FindFirst(path+"*.*", faAnyFile, sr)==0){
	do{
		if (sr.Attr & faDirectory){
			//�����
			if (sr.Name!=".")
			if (sr.Name!=".."){
				doCountAllFilesInFolder(path+sr.Name+"\\");
			}
		}else{
			//�����
			tString Ext=ExtractFileExt(sr.Name).UpperCase();
            //ShowMessage(Ext);
			if (Ext==".TXT"){           //cboFileMask [*.txt]
                AllFilesInFolder++;
				//List->Add(path+sr.Name);
			}
		}
	}
	while(FindNext(sr)==0);
	FindClose(sr);
	}
	Application->ProcessMessages();
    return AllFilesInFolder;
}
