/***********************************************************************
*   vResIcoToSpeedBtn   
*
************************************************************************/


////#include "uLaunchProject.h"

//---------------------------------------------------------------------------
void __fastcall vResIcoToSpeedBtn(TSpeedButton *pSpeedBtn, const tString &casRes, const tString &casSpeedBtnCaption) {
    /*DEBUG*/xASSERT(NULL != pSpeedBtn);

    const int iIcoWidth  = 16;
    const int iIcoHeight = 16;

	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/xASSERT(NULL != apIcon.get());
	apIcon.get()->Handle     = ::LoadImage(HInstance, casRes.c_str(), IMAGE_ICON, iIcoWidth, iIcoHeight, LR_COPYFROMRESOURCE);
    pSpeedBtn->Margin        = 4;
    pSpeedBtn->Spacing       = 4;
    pSpeedBtn->Flat          = true;
	pSpeedBtn->Glyph->Width  = iIcoWidth/*Icon->Width*/;
	pSpeedBtn->Glyph->Height = iIcoHeight/*Icon->Height*/;
	pSpeedBtn->Glyph->Canvas->Draw(0, 0, Icon);
    pSpeedBtn->Caption       = casSpeedBtnCaption;
}                                                             //24-4
//---------------------------------------------------------------------------


