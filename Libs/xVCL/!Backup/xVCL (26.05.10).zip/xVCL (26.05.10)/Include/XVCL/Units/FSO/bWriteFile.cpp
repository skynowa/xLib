/****************************************************************************
*    bReadFile
*
*****************************************************************************/
	

//---------------------------------------------------------------------------
bool bWriteFile(const tString &csFilePath, const tString &csText) {
	/*DEBUG*/xASSERT(false == csFilePath.IsEmpty());

	std::auto_ptr<TStringList> apslSL(new TStringList());
	/*DEBUG*/xASSERT(NULL != apslSL.get());

	apslSL->Text = csText;  
	
	apslSL->SaveToFile(csFilePath);
    
	return true;
}
//---------------------------------------------------------------------------


/*function SaveFileFromStr(const SrcStr,FilePath: String): Boolean;
var
   FS: TFileStream;
begin
   Result := False;
   FS := TFileStream.Create(FilePath,fmCreate);
   try
	 FS.Write(SrcStr[1],Length(SrcStr));
	 Result := True;
   finally
	 FS.Free;
	end;
end;*/