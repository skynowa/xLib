/***********************************************************************
*   TODO: ������ ����
*
***********************************************************************/


//---------------------------------------------------------------------------
tString __fastcall asReadFile(const tString &asPath) {
    TStringList* pList = new TStringList;
    pList->LoadFromFile(asPath);
    tString asTemp = pList->Text;
    delete pList;

    return asTemp;
}
//---------------------------------------------------------------------------