/**********************************************************************
*	vDBGridSelectAll 
*
***********************************************************************/


#include "uDoc.h"       //frmDoc
#include "uDM.h"        //frmDM

//---------------------------------------------------------------------------
void __fastcall vDBGridSelectAll(TDBGrid *dbgrdGrid) {
    dbgrdGrid->SelectedRows->Clear();

    dbgrdGrid->DataSource->DataSet->First();
    dbgrdGrid->DataSource->DataSet->DisableControls();
    try {
        while (! dbgrdGrid->DataSource->DataSet->Eof) {
            dbgrdGrid->SelectedRows->CurrentRowSelected = true;   
            dbgrdGrid->DataSource->DataSet->Next();
        }
    } __finally {
        dbgrdGrid->DataSource->DataSet->EnableControls();
    }
}
//---------------------------------------------------------------------------