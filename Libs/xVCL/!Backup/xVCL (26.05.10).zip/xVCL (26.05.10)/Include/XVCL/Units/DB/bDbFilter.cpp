/**********************************************************************
*	bDbFilter.cpp	
*
***********************************************************************/


#include <vcl.h>
#pragma hdrstop

//#include "uMain.h"
//---------------------------------------------------------------------------
//TODO:
bool bDbFilter(TADOQuery *pqryADOQuery, const String &csTableName, TStringList *pslFieldsAndControls) {
	/*DEBUG*/xASSERT(NULL  != pqryADOQuery);
    /*DEBUG*/xASSERT(false == csTableName.IsEmpty());
	/*DEBUG*/xASSERT(NULL  != pslFieldsAndControls);
    
	//-------------------------------------
	//���������� ������
	String sSqlStr;

	//-------------------------------------
	//����� �� ��� ����?
	bool bIsAllFieldsEmpty = true;

	for (int i = 0; i < pslFieldsAndControls->Count; ++ i) {
		String sCtrlValue = pslFieldsAndControls->Values[pslFieldsAndControls->Names[i]];
		
		if (false == sCtrlValue.IsEmpty()) {
            bIsAllFieldsEmpty = false;
            break;
        }
    }
    
	if (true == bIsAllFieldsEmpty) {
    	sSqlStr = _T("SELECT * FROM ") + csTableName;
    } else {
    	sSqlStr = _T("SELECT * FROM ") + csTableName + _T(" WHERE");
	}

	bool bIsFirstNotEmptyField = true;

	for (int i = 0; i < pslFieldsAndControls->Count; ++ i) {
		String sFieldName = pslFieldsAndControls->Names[i];
		String sCtrlValue = pslFieldsAndControls->Values[pslFieldsAndControls->Names[i]];
		//ShowMessage(sName + " __ " + sValue);

		if (true == sCtrlValue.IsEmpty()) {
			continue;
		}

		//1-�� �������� ����
		if (true == bIsFirstNotEmptyField) {
			sSqlStr += _T(" (") + sFieldName + _T(" LIKE '%");
			sSqlStr += sCtrlValue;
			sSqlStr += _T("%')");

			bIsFirstNotEmptyField = false;
			continue;
		}

		sSqlStr += _T(" AND (") + sFieldName + _T(" LIKE '%");    // sSqlStr += " AND (FN_NIK = '";
		sSqlStr += sCtrlValue;
		sSqlStr += _T("%')");
	}

	////sSqlStr += _T(" ORDER BY F_MAIN_CLASS ASC;");
	////ShowMessage(sSqlStr);

	//-------------------------------------
	//��������� ������
	pqryADOQuery->Close();
	pqryADOQuery->SQL->Text = sSqlStr;
	pqryADOQuery->Open();
	pqryADOQuery->Last();

	return true;
}
//---------------------------------------------------------------------------
