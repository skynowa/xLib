#ifndef XVCL_CommonH
#define XVCL_CommonH

//#ifdef  _UNICODE
//	//#define tstring std::wstring
//    #define tString UnicodeString
//#else
//	//#define tstring std::string
//    #define tString AnsiString
//#endif  /*_UNICODE*/

#define xLOG(sStr) 	            ::OutputDebugString(tString(sStr).c_str())
#define LOG_MSG(sStr, sCaption)	::MessageBox(0, tString(sStr).c_str(), tString(sCaption).c_str(), MB_OK);


#include <vcl.h>
#include <tchar.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <memory>
#include <vector>
////#include <assert.h>
////#include <shlwapi.h>

#include <XLib/Debug/CXAssert.h>

#pragma hdrstop
//---------------------------------------------------------------------------
#endif  //XVCL_CommonH