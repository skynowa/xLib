/**********************************************************************
*	�����  CXAccess (CXAccess.h)
*
***********************************************************************/


#ifndef XVCL_OLE_CXAccessH
#define XVCL_OLE_CXAccessH
//---------------------------------------------------------------------------
#include <XVCL/Common.h>
///#include <Classes.hpp>
///#include <SysUtils.hpp> //
////#include <system.hpp>   //AnsiString
//#include <SysUtils.hpp> //GetCurrentDir, Now()
//#include <windows.h>	//vErrorMessageBox
#include <ComObj.hpp>   //OLE
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------
class CXAccess {
	public:
        		CXAccess          ();
        	   ~CXAccess          ();

		bool    bIsMDBFile        (const String &csFilePath);
		bool    bIsOleAppInstalled(const String &csApplicationString);
		bool    bCreateResMDB     (const String &csFilePath, const String &csResource);
		bool    bCreateAdoMDB     (const String &csMdbFilePath);
		bool    bCompactMDB       (const String &csMdbFilePath, const String &csPass1, const String &csPass2);
		bool    bCompactMDBEx     (TADOConnection *pADOConnection, TADOQuery *pADOQuery, const String &csMdbFilePath, const String &csPass1, const String &csPass2);
		bool    bCreateBackupMDB  (const String &csMdbFilePath);
		String  sADOVersion       ();
	
	private:

};
//---------------------------------------------------------------------------
#endif	//XVCL_OLE_CXAccessH
