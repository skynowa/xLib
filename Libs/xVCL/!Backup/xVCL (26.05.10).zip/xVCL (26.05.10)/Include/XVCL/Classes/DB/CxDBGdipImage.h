/****************************************************************************
* Class name:  CxDBGdipImage
* Description: ����������� �������� �� �� 
* File name:   CxDBGdipImage.h
* Compilers:   C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     20.05.2010 11:57:56
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxXVCL_Classes_Db_DBGdipImageH
#define CxXVCL_Classes_Db_DBGdipImageH
//---------------------------------------------------------------------------
#include <XVCL/Common.h>
#include <XVCL/Classes/Gui/CxGdipImage.h>
#include <ADODB.hpp>
#include <DB.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class CxDBGdipImage : public CXNonCopyable {
	public:
		static BOOL bShow  (CxGdipImage *pImage, TADOQuery *pADOQuery, const String &csFieldName);
		static BOOL bShowNo(CxGdipImage *pImage); 
		static BOOL bSave  (CxGdipImage *pImage, TADOQuery *pADOQuery, const String &csFieldName); 
		static BOOL bAdd   (CxGdipImage *pImage, TADOQuery *pADOQuery, const String &csFieldName);
		static BOOL bDelete(CxGdipImage *pImage, TADOQuery *pADOQuery, const String &csFieldName);

	private:
		CxDBGdipImage();
	   ~CxDBGdipImage();
};
//---------------------------------------------------------------------------
#endif //CxXVCL_Classes_Db_DBGdipImageH
