/**********************************************************************
*	����� CPerform (CPerform.h)
*
***********************************************************************/


#ifndef CPerformH
#define CPerformH       
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>

#include <system.hpp>   //AnsiString
#include <Classes.hpp>  //TStringList
//---------------------------------------------------------------------------
#define DEBUG_(MSG)       MessageBox(0, AnsiString(MSG).c_str(), "�������",    MB_OK)
#define MSG_WARNING(MSG)  MessageBox(0, AnsiString(MSG).c_str(), "��������",   MB_OK + MB_ICONSTOP        + MB_TOPMOST)
#define MSG_INFO(MSG)     MessageBox(0, AnsiString(MSG).c_str(), "����������", MB_OK + MB_ICONINFORMATION + MB_TOPMOST)
//---------------------------------------------------------------------------
class CPerform {
	public:
		    CPerform                     ();
		    ~CPerform                    ();
		
		void vStart                      (int iPerfomMode);
		void vStop                       ();
		
        void vOpenLog                    ();
		void vDeleteLog                  ();
		void vSetLogName                 (const AnsiString &casFileName);
		void vSetLogPath                 (const AnsiString &casFilePath);

    private:
		int   iPerfomModeNow;		  //����� �������
        bool  bWasStarted;
		enum {pmTime, pmGetTickCount, pmQueryPerformanceCounter, pmGetThreadTimes} ePerfomMode;
		
		//TDateTime
		TDateTime     dtBeginTime;
		TDateTime     dtEndTime;
		
		//pmGetTickCount
		DWORD         dwBeginTime;
		DWORD         dwEndTime;
		
        //QueryPerformanceCounter
		LARGE_INTEGER liFrequency;
		LARGE_INTEGER liBeginCount;
		LARGE_INTEGER liEndCount;
		LARGE_INTEGER liCount;
		
		//GetThreadTimes
		FILETIME      lpCreationTime;  
		FILETIME      lpExitTime;
		FILETIME      lpKernelTime0;
		FILETIME      lpUserTime0;
		FILETIME      lpKernelTime1;
		FILETIME      lpUserTime1;
		
		__int64    iFiletimeToint64      (FILETIME F);

		//���
		AnsiString    asLogPath;
		AnsiString    asLogName;
        
		void       vLog                  (const AnsiString &casFileText);

		//�����
		void       vResetData            ();
     	void       vErrorMessageBox      ();
        AnsiString asMilliSecToTimeString(unsigned short ulMilliSec);
};
//---------------------------------------------------------------------------
#endif