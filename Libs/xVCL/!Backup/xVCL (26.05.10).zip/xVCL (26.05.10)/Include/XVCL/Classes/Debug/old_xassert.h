/****************************************************************************
*	XASSERT.h
*
*****************************************************************************/


#ifndef XLCL_XASSERT_H
#define XLCL_XASSERT_H
//---------------------------------------------------------------------------
#include <stddef.h>
#include <assert.h>
//---------------------------------------------------------------------------
#ifdef NDEBUG
	#define XASSERT(ignore)    ((void)0)
    #define XASSERT_EX(ignore) ((void)0)
#else /*NDEBUG*/
	void vAssert(const char *pcszExp, unsigned long int ulLastError, const char *pcszFile, unsigned long int ulLine, const char *pcszFunc, const char *pcszComment = NULL);

    #ifndef __FILE__
	#	define __FILE__ "<unknown>"
	#endif

	#ifndef __LINE__
	#	define __LINE__ "<unknown>"
	#endif

	#ifndef __FUNCTION__
	#	define __FUNCTION__ __FUNC__
	#endif

	#ifndef __FUNC__
	#	define __FUNC__ "<unknown>"
	#endif

    #define XASSERT(exp)             ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __FUNCTION__),          (void)0))
    #define XASSERT_EX(exp, comment) ((exp) ? (void)0 : (vAssert(#exp, ::GetLastError(), __FILE__, __LINE__, __FUNCTION__, comment), (void)0))
#endif /*NDEBUG*/
//---------------------------------------------------------------------------
#endif /*XLCL_XASSERT_H*/
