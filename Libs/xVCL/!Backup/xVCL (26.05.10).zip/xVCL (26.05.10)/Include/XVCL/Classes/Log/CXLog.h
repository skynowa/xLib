/**********************************************************************
*	�����  CXLog (CXLog.hpp) (C++Builder 6.0)
*
***********************************************************************/


#ifndef CXLogH
#define CXLogH      
//---------------------------------------------------------------------------
#include <vcl.h>
#include <sstream>
#include "xassert.h"
//---------------------------------------------------------------------------
class CXLog {
	public:
					             CXLog             (const AnsiString &casFileName, unsigned long int ulMaxFileSize);
						         CXLog			   (unsigned long int ulMaxFileSize);
					             ~CXLog            ();

		void                     vLog              (const AnsiString &casStr);
		void                     vLog              (const AnsiString &casComment, const AnsiString &casStr);
		void                     vLog              (const AnsiString &casComment, int iValue);
		void                     vLog              (const AnsiString &casComment, unsigned long int ulLastError);
					
		void                     vLogUCharAsHex    (const AnsiString &casFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
        void                     vLogUCharAsStr    (const AnsiString &casFileTextDescription, unsigned char *pucFileText, unsigned long int ulFileTextLen);
		void                     vLogLastErrorStr  (const AnsiString &casComment, unsigned long int ulLastError);
        
		void                     vTrace            (const AnsiString &casStr);
		void                     vTrace            (const AnsiString &casComment, const AnsiString &casStr);
		void                     vTrace            (const AnsiString &casComment, int iValue);
		void                     vTrace            (const AnsiString &casComment, unsigned long int ulValue);
		void                     vTraceLastError   (const AnsiString &casComment, unsigned long int ulLastError);

		void                     vOpen             ();
		void                     vSetMaxFileSizeMb (unsigned long int ulMaxFileSize);	
		void                     vClear            ();
		void                     vSetName          (const AnsiString &casFileName);
		void                     vSetPath          (const AnsiString &casFilePath);
		void                     vDelete           ();

		void					 vMsgBoxLastError  (const AnsiString &casComment);

        template<typename TText, typename TCaption>
        void vMsgBox(TText Text, TCaption Caption, unsigned long ulType = MB_OK) {
														std::ostringstream ossText;
														ossText << Text;

														std::ostringstream ossCaption;
														ossCaption << Caption;

														::MessageBox(0, ossText.str().c_str(), ossCaption.str().c_str(), ulType);
													}; 
	
	private:
		AnsiString               m_asLogName;
		AnsiString               m_asLogPath;
		unsigned long int        m_ulMaxFileSize;
		CRITICAL_SECTION         m_csLog;

		void                     vDeleteLogIfFull  ();
		void                     vLogLastErrStrServ();
        AnsiString               asExePath         ();
        unsigned long int        ulFileSize        (const AnsiString &casFilePath);
};
//---------------------------------------------------------------------------
#endif