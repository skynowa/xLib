/****************************************************************************
* Class name:  CxGdipImage
* Description: GDI+ ��������
* File name:   CxGdipImage.h
* Compilers:   C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2010 13:55:40
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CxGdiPlusImageH
#define CxGdiPlusImageH
//---------------------------------------------------------------------------
#include <XVCL/Common.h>
#include <XLib/Common.h>
#include <XLib/GDI+/CxGdiplus.h>
#include <XLib/GDI+/CxImage.h>
//---------------------------------------------------------------------------
class CxGdipImage : public TGraphicControl {
	__published:
		__property              PopupMenu;
		__property              Visible = {default = true};

		__property              OnClick;
		__property              OnDblClick;
		__property              OnMouseDown;


	public:
		__fastcall              CxGdipImage            (Classes::TComponent* AOwner);
		__fastcall virtual     ~CxGdipImage            ();

		BOOL                    bSetMargin             (LONG liMargin);

		BOOL                    bLoadFromFile          (const String &csFilePath);
		BOOL                    bLoadFromStream        (TMemoryStream *pmsStream);

		BOOL                    bSaveToFile            (const String &csFilePath);
		BOOL                    bSaveToStream          (TMemoryStream *pmsStream);

		BOOL                    bClear                 ();

	protected:
		virtual void __fastcall Paint                  ();

	private:
		BOOL                    _m_bRes;
		CxImage                 _m_imgImage;
		LONG                    _m_liMargin;

		BOOL                    _bMemoryStreamToIStream(TMemoryStream *pmsStream, IStream **ppisStream);
};
//---------------------------------------------------------------------------
#endif //CxGdiPlusImageH
