/****************************************************************************
*	XASSERT.cpp
*
*****************************************************************************/


#pragma warning(disable: 4996)	//strcpy, sprintf, vsnprintf
//---------------------------------------------------------------------------
#include <windows.h>
#include <string> 
//---------------------------------------------------------------------------
std::string sCutFirstDirectory(const std::string &csS) {
	std::string S = "";
	S.assign(csS);	

	bool   bRoot = false;
	size_t P     = - 1;

	if ("\\" == S) {
		S.clear();
	} else {
		if (S[0] == '\\') {
			bRoot = true;
			//������� � 1(0) ������� 1 ������
			//Delete(S, 1, 1);
			S.erase(0, 1);
		} else {
			bRoot = false;
		}

		if ('.' == S[0]) {
			//Delete(S, 1, 4);
			S.erase(0, 4);
		}

		//P = AnsiPos("\\", S); 
		P = S.find_first_of("\\") + 1;

		if (std::string::npos != P) {
			//Delete(S, 1, P); - c ������� 1(0) P ��������
			S.erase(0, P);
			S = "...\\" + S;        
		} else {
			S.clear();
		}

		if (bRoot) {
			S = "\\" + S;
		}
	}

	return S;
}
//---------------------------------------------------------------------------
std::string sMinimizeName(const std::string &csFilePath, size_t uiMaxLen) {
	std::string sRes   = csFilePath;	

	CHAR szDrive[MAX_PATH + 1] = {0};
	CHAR szDir  [MAX_PATH + 1] = {0};
	CHAR szName [MAX_PATH + 1] = {0};
	CHAR szExt  [MAX_PATH + 1] = {0};
	_splitpath(csFilePath.c_str(), szDrive, szDir, szName, szExt);	

	std::string sDrive = std::string(szDrive);
	std::string sDir   = std::string(szDir);
	std::string sName  = std::string(szName) + std::string(szExt);

	//while ((Dir <> '') or (Drive <> '')) and (Canvas.TextWidth(Result) > MaxLen) do
	while (((!sDir.empty()) || (!sDrive.empty())) && (sRes.size()/*sDir.size()*/ > uiMaxLen)) { 
		if ("\\...\\" == sDir ) {
			sDrive.clear();
			sDir = "...\\";
		} else if (sDir.empty()) {
			sDrive.clear();
		} else {
			sDir = sCutFirstDirectory(sDir);		  
		}

		sRes = sDrive + sDir + sName;
	}

	return sRes;
}
//---------------------------------------------------------------------------
void vAssert(const char *pcszExp, unsigned long int ulLastError, const char *pcszFile, unsigned long int ulLine, const char *pcszFunc, const char *pcszComment) {
	//-------------------------------------
	//���� � exe-�����
	CHAR szExePath[MAX_PATH + 1] = {0};
	if (!::GetModuleFileNameA(::GetModuleHandleA(NULL), szExePath, MAX_PATH) || 0 == ::lstrlenA(szExePath)) {
		::MessageBoxA(0, "GetModuleFileName() - fail", "XASSERT - system message", MB_ICONERROR | MB_OK);
		return;
	}

	//-------------------------------------
	//���� � ��� exe-�����
	CHAR szExeName[MAX_PATH + 1] = {0};
	_splitpath(szExePath, NULL, NULL, szExeName, NULL);
	if (NULL == szExeName || 0 == ::lstrlenA(szExeName)) {
		::MessageBoxA(0, "_splitpath() - fail", "XASSERT - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� GetLastError()
	LPVOID lpMsgBuf = NULL;
	::FormatMessageA(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		ulLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  //���� �� ���������
		(LPSTR)&lpMsgBuf,
		0,
		NULL);
	if (NULL == lpMsgBuf || 0 == ::lstrlenA((LPSTR)lpMsgBuf)) {
		::MessageBoxA(0, "FormatMessage() - fail", "XASSERT - system message", MB_ICONERROR | MB_OK);
        return;
	}

	//-------------------------------------
	//����������� ���������
	const unsigned int cuiMsgSize = 2024; 
	CHAR               szMsg[cuiMsgSize + 1] = {0};
	::wsprintfA(szMsg,
			 "%s\n\n"
			 "%s%s\n"
			 "%s%s\n"
			 "%s%i\n"
			 "%s%s\n"
			 "%s%s\n"
			 "%s%s"		/*����� ���� \n �� ����*/
			 "%s%s",

			 "Assertion failed.",
			 "Program:         ", sMinimizeName(szExePath, 75).c_str(),
			 "File:            ", sMinimizeName(pcszFile,  75).c_str(),
			 "Line:            ", ulLine,
			 "Function:        ", pcszFunc,
			 "Expression:      ", pcszExp,
			 "GetLastError():  ", (LPSTR)lpMsgBuf,
			 "Comment:         ", pcszComment
	);

	if (NULL == szMsg || 0 == ::lstrlenA(szMsg)) {
		::MessageBoxA(0, "wsprintf() - fail", "XASSERT - system message", MB_ICONERROR | MB_OK);
        return;
	}

	if (NULL != lpMsgBuf) {
		::LocalFree(lpMsgBuf);    lpMsgBuf = NULL;
	}

	//-------------------------------------
	//������� MessageBox
	int iRes = ::MessageBoxA(NULL, szMsg, szExeName, MB_ABORTRETRYIGNORE | MB_ICONSTOP);
	switch (iRes) {
		case IDABORT: {
	    	exit(- 1);
			break;
		}
		case IDRETRY: {
			_asm {
				int 3
			} 
			break;
		}
		case IDIGNORE: {
			break;
		}
	}
}
//---------------------------------------------------------------------------

