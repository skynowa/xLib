/****************************************************************************
* Class name:  CxGdipImage
* Description: GDI+ ��������
* File name:   CxGdipImage.cpp
* Compilers:   C++ Builder 2010
* String type: Ansi, Unicode
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     17.05.2010 13:55:40
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XVCL/Classes/Gui/CxGdipImage.h>

#include <Ole2.h>


/****************************************************************************
*    Public methods                                                          
*                                                                            
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: CxGdipImage (�����������)
__fastcall CxGdipImage::CxGdipImage(Classes::TComponent* AOwner) :
	TGraphicControl(AOwner),
	_m_bRes        (FALSE),
	_m_imgImage    (),
	_m_liMargin    (2)
{

}
//---------------------------------------------------------------------------
//TODO: ~CxGdipImage (����������)
/*virtual*/
__fastcall CxGdipImage::~CxGdipImage() {

}
//---------------------------------------------------------------------------
//TODO: - bSetMargin (�������) 
BOOL CxGdipImage::bSetMargin(LONG liMargin) {
	/*DEBUG*/// _m_imgImage - n/a
	/*DEBUG*/// liMargin    - n/a

	xCHECK_DO(0 > liMargin, liMargin = 0);

	_m_liMargin = liMargin + 2;

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bLoadFromFile (�������� �� �����)
BOOL CxGdipImage::bLoadFromFile(const String &csFilePath) {
	/*DEBUG*/// _m_imgImage 
	/*DEBUG*/xASSERT_RET(false == csFilePath.IsEmpty(), FALSE);

	//-------------------------------------
	//��������
	_m_bRes = _m_imgImage.bLoad(xD2S(csFilePath));
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//�����������
	RECT rcRect = {Left, Top, Width, Height};
	
	_m_bRes = ::InvalidateRect(Parent->Handle, &rcRect, TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bLoadFromStream (�������� �� ������)
BOOL CxGdipImage::bLoadFromStream(TMemoryStream *pmsStream) {
	/*DEBUG*/// _m_imgImage
	/*DEBUG*/xASSERT_RET(NULL != pmsStream, FALSE);

	//-------------------------------------
	//��������
	IStream *pisStream = NULL;
	
	//TMemoryStream -> IStream
	_m_bRes = _bMemoryStreamToIStream(pmsStream, &pisStream);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes,   FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pisStream, FALSE);

	_m_bRes = _m_imgImage.bLoad(pisStream);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	pisStream->Release();

	//-------------------------------------
	//�����������
	RECT rcRect = {Left, Top, Width, Height};
	
	_m_bRes = ::InvalidateRect(Parent->Handle, &rcRect, TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bSaveToFile
BOOL CxGdipImage::bSaveToFile(const String &csFilePath) {
	/*DEBUG*/// _m_imgImage
	/*DEBUG*/xASSERT_RET(false == csFilePath.IsEmpty(), FALSE);

	_m_bRes = _m_imgImage.bSave(xD2S(csFilePath), CxImage::etPng); 	//FIXME: CxImage::etPng
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: bSaveToStream
BOOL CxGdipImage::bSaveToStream(TMemoryStream *pmsStream) {
	/*DEBUG*/// _m_imgImage
	/*DEBUG*/xASSERT_RET(NULL != pmsStream, FALSE);

	IStream *pisStream = NULL;

	//TMemoryStream -> IStream
	_m_bRes = _bMemoryStreamToIStream(pmsStream, &pisStream);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes,   FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pisStream, FALSE);

	_m_bRes = _m_imgImage.bSave(pisStream, CxImage::etPng); 	//FIXME: CxImage::etPng
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	pisStream->Release();

	return TRUE;
}
//---------------------------------------------------------------------------
//TODO: - bClear ()
BOOL CxGdipImage::bClear() {
	/*DEBUG*/// _m_imgImage

	xCHECK_DO(FALSE == _m_imgImage.bIsLoaded(), TRUE);

//	HDC hDc = ::GetDC(Parent->Handle);
//	/*DEBUG*/xASSERT_RET(NULL != hDc, FALSE);
//
//	RECT rcRect = {Left, Top, Width, Height};
//
//	Gdiplus::Color clBackGround(0, 0, 0, 0);
//
//	_m_bRes = _m_imgImage.bClear(hDc, rcRect, clBackGround);
//	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);
//
//	_m_bIsLoaded = FALSE;
//
//	INT iRes = ::ReleaseDC(Parent->Handle, hDc);
//	/*DEBUG*/xASSERT_RET(0 != iRes, FALSE);



	_m_bRes = _m_imgImage.bClear();
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	//-------------------------------------
	//�����������
	RECT rcRect = {Left, Top, Width, Height};
	
	_m_bRes = ::InvalidateRect(Parent->Handle, &rcRect, TRUE);
	/*DEBUG*/xASSERT_RET(FALSE != _m_bRes, FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------


/****************************************************************************
*	protected
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: Paint (��������� CxImage)
/*virtual*/
void __fastcall CxGdipImage::Paint() {
	/*DEBUG*/// _m_imgImage - n/a
	xCHECK_DO(FALSE == _m_imgImage.bIsLoaded(), return);

	HDC hDc = ::GetDC(Parent->Handle);
	/*DEBUG*/xASSERT_DO(NULL != hDc, return);

	{
		RECT rcClient = {0};
		_m_bRes = ::GetClientRect(Parent->Handle, &rcClient);
		/*DEBUG*/xASSERT_DO(FALSE != _m_bRes, return);

		const LONG  liClientWidth  = rcClient.right  - rcClient.left;
		const LONG  liClientHeight = rcClient.bottom - rcClient.top;
		const FLOAT fRatio         = static_cast<FLOAT>(liClientHeight)            / static_cast<FLOAT>(liClientWidth);
		const FLOAT fImgRatio      = static_cast<FLOAT>(_m_imgImage.uiGetHeight()) / static_cast<FLOAT>(_m_imgImage.uiGetWidth());

		LONG liLeft, liTop, liWidth, liHeight;	//[SPEED] - ������ ������������� ����������

		if (fImgRatio > fRatio) {
			liWidth  = liClientHeight / fImgRatio;
			liLeft   = (liClientWidth - liWidth) / 2;
			liTop    = 0;
			liHeight = liClientHeight;
		} else {
			liLeft   = 0;
			liWidth  = liClientWidth;
			liHeight = liClientWidth * fImgRatio;
			liTop    = (liClientHeight - liHeight) / 2;
		}		

		/*RECT rcImage = {
			liLeft   + _m_liMargin, 
			liTop    + _m_liMargin, 
			liWidth  - _m_liMargin * 2, 
			liHeight - _m_liMargin * 2
		};		

		_m_imgImage.bDraw(hDc, rcImage);*/

		_m_imgImage.bDraw(hDc, 
			liLeft   + _m_liMargin, 
			liTop    + _m_liMargin, 
			liWidth  - _m_liMargin * 2, 
			liHeight - _m_liMargin * 2
		);
	}

	INT iRes = ::ReleaseDC(Parent->Handle, hDc);
	/*DEBUG*/xASSERT_DO(0 != iRes, return);
};
//---------------------------------------------------------------------------



/****************************************************************************
*	private
*
*****************************************************************************/

//---------------------------------------------------------------------------
//TODO: _bMemoryStreamToIStream (TMemoryStream -> ppisStream)
//INFO: ������� pisStream->Release(), ����� pisStream ��� �� �����
BOOL CxGdipImage::_bMemoryStreamToIStream(TMemoryStream *pmsStream, IStream **ppisStream) {
	/*DEBUG*/// _m_imgImage
	/*DEBUG*/xASSERT_RET(NULL != pmsStream,   FALSE);
	/*DEBUG*/xASSERT_RET(NULL == *ppisStream, FALSE); 

	HGLOBAL hGlobal = NULL;

	__int64 i64MemoryStreamSize = pmsStream->Size;

	hGlobal = ::GlobalAlloc(GMEM_MOVEABLE, i64MemoryStreamSize);
	/*DEBUG*/xASSERT_RET(NULL != hGlobal, FALSE);

	LPVOID pvData = ::GlobalLock(hGlobal);
	/*DEBUG*/xASSERT_RET(NULL != pvData, FALSE);

	__int64 i64BytesRead = 0;
	__try {
		//read TMemoryStream and store in global memory
		pmsStream->Position = 0;
		i64BytesRead        = pmsStream->Read(pvData, i64MemoryStreamSize);
	}
	__finally {
		::GlobalUnlock(hGlobal);
	}

	if (i64MemoryStreamSize != i64BytesRead) {
		hGlobal = ::GlobalFree(hGlobal);
		/*DEBUG*/xASSERT_RET(NULL == hGlobal, FALSE);
		
		return FALSE;
	} 

	//create IStream* from global memory
	HRESULT hRes = ::CreateStreamOnHGlobal(hGlobal, TRUE, ppisStream);
	/*DEBUG*/xASSERT_RET(SUCCEEDED(hRes), FALSE);

	return TRUE;
}
//---------------------------------------------------------------------------
