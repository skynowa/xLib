/**********************************************************************
*	�����  CLog (CLog.cpp)  
*	
***********************************************************************/


#include "CLog.h"

#include <shlwapi.h>

//#pragma comment (lib, "shlwapi.lib")

//---------------------------------------------------------------------------
CLog::CLog() {
	sLogName = "___Log.txt";
	sLogPath = sGetCurrentDir() + "\\" + sLogName;
}
//---------------------------------------------------------------------------
std::string CLog::sGetCurrentDir() {
    std::string sRes = "";    

    TCHAR szPath[MAX_PATH] = {0};
	GetCurrentDirectory(sizeof(szPath), szPath);
    sRes = szPath;

    return sRes;  //����� ���� (��� ����� �� �����)
} 
//---------------------------------------------------------------------------
CLog::~CLog() {	

}
//---------------------------------------------------------------------------
void CLog::vDelete() {
    if (!SetFileAttributes(sLogPath.c_str(), FILE_ATTRIBUTE_NORMAL)) {
        vErrorMessageBox();
    }
    if (remove(sLogPath.c_str()) != 0) {
        vErrorMessageBox();
    }
}
//---------------------------------------------------------------------------
void CLog::vSetPath(const std::string &csFilePath) {
	sLogPath = sLogPath;
}
//---------------------------------------------------------------------------
void CLog::vSetName(const std::string &csFileName) {
	sLogName = csFileName;
	sLogPath = sGetCurrentDir() + "\\" + csFileName;
}
//---------------------------------------------------------------------------
void CLog::vOpen() {
	ShellExecute(NULL, NULL, sLogPath.c_str(), NULL, NULL, SW_SHOW);
	/*if (GetLastError() != 0) {
        vErrorMessageBox();
	}*/
}
//---------------------------------------------------------------------------
void CLog::vLog(const std::string &csFileText) {
	FILE *pFile = NULL;
	
    if ((pFile = fopen(sLogPath.c_str(), "a")) == NULL) {
        vErrorMessageBox();
    } else {
        SYSTEMTIME stST;
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileText.c_str());
        fclose(pFile);
    }
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsHex(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
	    if (pcFileText[i] < 16) {
            //sRes += AnsiString(0).sprintf("0x0%x ", pcFileText[i]);
		} else {
            //sRes += AnsiString(0).sprintf("0x%2x ", pcFileText[i]);
        }
	}
	
	FILE *pFile = NULL;
	
    if ((pFile = fopen(sLogPath.c_str(), "a")) == NULL) {
        vErrorMessageBox();
    } else {
        SYSTEMTIME stST;
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
        fclose(pFile);
    }
}
//---------------------------------------------------------------------------
void CLog::vLogCharAsStr(const std::string &csFileTextDescription, unsigned char *pcFileText, unsigned long int ulFileTextLen) {
	std::string sRes = "";   
	for (unsigned int i = 0; i < ulFileTextLen; i ++) {
        //sRes += AnsiString(0).sprintf("%c", pcFileText[i]);
        sRes.push_back(pcFileText[i]);      //???????????
	}

	FILE *pFile = NULL;
	
    if ((pFile = fopen(sLogPath.c_str(), "a")) == NULL) {
        vErrorMessageBox();
    } else {
        SYSTEMTIME stST;
        GetLocalTime(&stST);
        fprintf(pFile, "[%dd:%dd:%dd]  %s %s\n", stST.wHour, stST.wMinute, stST.wSecond, csFileTextDescription.c_str(), sRes.c_str());
        fclose(pFile);
    }
}
//---------------------------------------------------------------------------
void CLog::vErrorMessageBox() {
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),  // ���� �� ���������
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
	);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, "������ Win32 API",	MB_OK | MB_ICONINFORMATION);
	LocalFree(lpMsgBuf);
}
//---------------------------------------------------------------------------