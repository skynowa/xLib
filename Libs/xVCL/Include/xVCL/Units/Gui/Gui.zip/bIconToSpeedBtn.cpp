/***********************************************************************
*   bIconToSpeedBtn   
*
************************************************************************/


/////--#include "uLaunchProject.h"

//---------------------------------------------------------------------------
//TODO: bIconToSpeedBtn 
BOOL bIconToSpeedBtn(TForm *pfrmForm, TSpeedButton *pSpeedBtn, const String &csAssociateFileExt, const String &csSpeedBtnCaption) {  //".exe"
	/*DEBUG*/xASSERT_RET(NULL  != pfrmForm,                     FALSE);    
	/*DEBUG*/xASSERT_RET(NULL  != pSpeedBtn,                    FALSE);
    /*DEBUG*/xASSERT_RET(false == csAssociateFileExt.IsEmpty(), FALSE);
    /*DEBUG*/xASSERT_RET(false == csSpeedBtnCaption.IsEmpty(),  FALSE);

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
    /*DEBUG*/xASSERT(NULL != apImageList.get());
    
    //-------------------------------------
	//��������� ������
	String sFilePath;

    if (true == csAssociateFileExt.IsEmpty()) {
        //��������� ������ (������ �����)
    } else {
		sFilePath = sSearchFileEx(csAssociateFileExt, pfrmForm->m_sAppDirPath + xT("Project\\Debug\\"));

        if (true == sFilePath.IsEmpty()) {
			sFilePath = sSearchFileEx(csAssociateFileExt, pfrmForm->m_sAppDirPath + xT("Project\\Release\\"));
        }
    }                

    TSHFileInfo sfInfo = {0};
    DWORD dwImageHandle = ::SHGetFileInfo(sFilePath.c_str(),
                                        0,
                                        &sfInfo,
                                        sizeof(sfInfo),
                                        SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);

    if (0 != dwImageHandle) {
        apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }
                                              

	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/xASSERT_RET(NULL != apIcon.get(), FALSE);

    apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
    apIcon.get()->Transparent = true;

    INT iIconIndex = apImageList.get()->AddIcon(apIcon.get());

    //-------------------------------------
    //������ � exe
	std::auto_ptr<Graphics::TBitmap> apBitmap(new Graphics::TBitmap());
	/*DEBUG*/xASSERT_RET(NULL != apBitmap.get(), FALSE);

    apImageList.get()->GetBitmap(iIconIndex, apBitmap.get());
    ////apBitmap.get()->Transparent      = false;
    ////apBitmap.get()->TransparentColor = clWhite;
    pSpeedBtn->Margin  = 4;
    pSpeedBtn->Spacing = 4;
    pSpeedBtn->Flat    = true;
    pSpeedBtn->Glyph   = apBitmap.get();
    pSpeedBtn->Caption = csSpeedBtnCaption;

	return TRUE;
}
//---------------------------------------------------------------------------


