/***********************************************************************
*   bIconToFormCaption   
*
************************************************************************/


//--#include "uLaunchProject.h"

//---------------------------------------------------------------------------
//TODO: bIconToFormCaption 
BOOL bIconToFormCaption(TForm *pfrmForm, const String &csAssociateFileExt, const String &csFrmCaption) {    //".exe"
	/*DEBUG*/xASSERT_RET(NULL  != pfrmForm,                     FALSE);
	/*DEBUG*/xASSERT_RET(false == csAssociateFileExt.IsEmpty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csFrmCaption.IsEmpty(),       FALSE);

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
	/*DEBUG*/xASSERT_RET(NULL != apImageList.get(), FALSE);

    //-------------------------------------
    //��������� ������
    String sFilePath;

    if (true == csAssociateFileExt.IsEmpty()) {
        //��������� ������ (������ �����)
    } else {
		sFilePath = sSearchFileEx(csAssociateFileExt, pfrmForm->m_sAppDirPath + xT("Project\\Debug\\"));

        if (sFilePath.IsEmpty() == true) {
            sFilePath = sSearchFileEx(csAssociateFileExt, pfrmForm->m_sAppDirPath + xT("Project\\Ralease\\"));
        }
    }

    TSHFileInfo sfInfo = {0};
    DWORD dwImageHandle = ::SHGetFileInfo(sFilePath.c_str(),
                                        0,
                                        &sfInfo,
                                        sizeof(sfInfo),
                                        SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);
                                        
    if (0 != dwImageHandle) {
        apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }

	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/xASSERT_RET(NULL != apIcon.get(), FALSE);
    apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
    apIcon.get()->Transparent = true;

	//-------------------------------------
	//����� + �����   
    pfrmForm->Icon    = apIcon.get();
#ifdef BC_DEF
    pfrmForm->Caption = csFrmCaption + "  [Borland C++ project]";
#endif
#ifdef VC_DEF
    pfrmForm->Caption = csFrmCaption + "  [Visual C++ project]";
#endif

	return TRUE;
}
//---------------------------------------------------------------------------


