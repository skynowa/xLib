/***********************************************************************
*   bIconToMenuItem
*
************************************************************************/


//--#include "uLaunchProject.h"

//---------------------------------------------------------------------------
//TODO: bIconToMenuItem
BOOL bIconToMenuItem(TForm *pfrmForm, TPopupMenu *pMenuItem,  const String &csAssociateFileExt, const String &csMenuItemCaption) {    //".exe"
	/*DEBUG*/xASSERT_RET(NULL  != pfrmForm,                     FALSE);
	/*DEBUG*/xASSERT_RET(NULL  != pMenuItem,                    FALSE);
	/*DEBUG*/xASSERT_RET(false == csAssociateFileExt.IsEmpty(), FALSE);
	/*DEBUG*/xASSERT_RET(false == csMenuItemCaption.IsEmpty(),  FALSE);

    //-------------------------------------
    //��������� ������ ����� exe-����� � pImageList
	std::auto_ptr<TImageList> apImageList(new TImageList(NULL));
	/*DEBUG*/xASSERT(NULL != apImageList.get());

    //-------------------------------------
    //��������� ������
    String sFilePath;

    if (true == csAssociateFileExt.IsEmpty()) {
        //��������� ������ (������ �����)
    } else {
		sFilePath = sSearchFileEx(csAssociateFileExt, BASE_PATH + xT("Project") + xT("\\"));
    }                

    TSHFileInfo sfInfo = {0};
    DWORD dwImageHandle = ::SHGetFileInfo(sFilePath.c_str(),
                                        0,
                                        &sfInfo,
                                        sizeof(sfInfo),
                                        SHGFI_SYSICONINDEX | SHGFI_ICON | SHGFI_SMALLICON);

    if (0 != dwImageHandle) {
        apImageList.get()->Handle      = dwImageHandle;
        apImageList.get()->ShareImages = true;
    }
                                              
	std::auto_ptr<TIcon> apIcon(new TIcon());
    /*DEBUG*/xASSERT_RET(NULL != apIcon.get(), FALSE);

    apIcon.get()->Handle      = sfInfo.hIcon;      //<<<<<<<<<<
    apIcon.get()->Transparent = true;

    //////////int iIconIndex = pImageList->AddIcon(pIcon);

    //-------------------------------------
    //--������ + ����
    //--pTrayIcon->Icons     = pImageList;   //��������� � pImageList
    //--pTrayIcon->IconIndex = iIconIndex;
    //--pTrayIcon->Hint      = casTrayIconHint;
    
    //-------------------------------------
    //����
    pmnuTray->Items->Items[0]->ImageIndex = 2; //iIconIndex;

	return TRUE;
}
//---------------------------------------------------------------------------


