/****************************************************************************
* Class name:  CXStatusBar
* Description: ������ ���������
* File name:   CXStatusBar.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     26.07.2009 23:49:15
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXStatusBar_H
#define CXStatusBar_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXStatusBar: public CXWindow {
	public:
			  CXStatusBar ();
			 ~CXStatusBar ();
		BOOL  SetSimple   (BOOL bSimple);
		INT   Height      ();
		BOOL  SetMinHeight(INT iHeight);	//???????????
		INT   AddPart     ();
		INT   AddPart     (const std::string &csPartText);	
		INT   AddPart     (const std::string &csPartText, HICON hIcon);
		INT   AddPart     (const std::string &csPartText, INT IdIcon);
		INT   AddPart     (INT Size);
		/////////////INT   AddPart     (const std::string &csPartText, INT Size);
		INT   AddPart     (const std::string &csPartText, HICON hIcon, INT Size);
		INT   AddPart     (const std::string &csPartText, INT IdIcon, INT Size);
		INT   AddPart     (HICON hIcon, INT Size);
		BOOL  SetIcon     (INT PartIndex, HICON hIcon);
		BOOL  SetIcon     (INT PartIndex, INT IdIcon);
		BOOL  SetText     (INT PartIndex, const std::string &csPartText);
		BOOL  SetSize     (INT PartIndex, INT Size);
		BOOL  SetParts    (INT iParts, INT iSize);
	
	private:
		static const INT ms_ciMaxParts = 256; // MSDN 256 parts max

		INT   _m_iDefaultSize;
		INT   m_iPartsWidths[ms_ciMaxParts + 1];
		INT   m_iNumParts;
};
//---------------------------------------------------------------------------
#endif
