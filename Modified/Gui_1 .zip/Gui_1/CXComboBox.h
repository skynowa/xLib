/****************************************************************************
* Class name:  CXComboBox
* Description: ������ � ���������� �������
* File name:   CXComboBox.h
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 17:01:13
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#ifndef CXComboBox_H
#define CXComboBox_H
//---------------------------------------------------------------------------
#include <XLib/GUI/CXWindow.h>
//---------------------------------------------------------------------------
class CXComboBox: public CXWindow { 
	public:
				 CXComboBox  ();
				~CXComboBox  ();

		BOOL    bAddString   (const std::string &csItem);
		BOOL    bResetContent();
		BOOL    bSetCurSel   (WPARAM wIndex);
		BOOL    bLoadFromFile(const std::string &csFilePath, int iItemIndex = - 1);  
};
//---------------------------------------------------------------------------
#endif
