/****************************************************************************
* Class name:  CXStatic
* Description: ������ � ����������� �����
* File name:   CXStatic.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     24.07.2009 11:20:41
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <XLib/GUI/CXStatic.h>
//---------------------------------------------------------------------------
CXStatic::CXStatic() {
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXSTATIC_CONTROL_CLASS;
	_m_ulStyle        = CXSTATIC_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXSTATIC_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXSTATIC_DEFAULT_WIDTH;
	_m_iHeight        = CXSTATIC_DEFAULT_HEIGHT;
}
//---------------------------------------------------------------------------
CXStatic::~CXStatic() {
	LOG();
}
//---------------------------------------------------------------------------