/****************************************************************************
* Class name:  CXListView
* Description: 
* File name:   CXListView.cpp
* Compilers:   Visual C++ 2008
* String type: Ansi
* Libraries:   WinAPI, Stl, XLib
* Author:      Sergey Shapka
* E-mail:      dr.web.agent@gmail.com
* Created:     27.07.2009 12:12:03
* Version:     1.0.0.0 Debug
*
*****************************************************************************/


#include <Xlib/GUI/CXListView.h>
//---------------------------------------------------------------------------
CXListView::CXListView() : 
	m_ColumnCount(0),
	m_ItemCount  (0)
{
	LOG();

	//-------------------------------------
	//�������������� ��������� ����
	_m_sClassName     = CXLISTVIEW_CONTROL_CLASS;
	_m_ulStyle        = CXLISTVIEW_DEFAULT_WINDOW_STYLE;
	_m_ulExStyle      = CXLISTVIEW_DEFAULT_WINDOW_STYLE_EX;

	_m_iLeft          = 0;
	_m_iTop           = 0;
	_m_iWidth         = CXLISTVIEW_DEFAULT_WIDTH;
	_m_iHeight        = CXLISTVIEW_DEFAULT_HEIGHT;
	
	//TODO: bInitCommonControls
	bInitCommonControls(ICC_LISTVIEW_CLASSES);
	
	//HICON hiconItem;     //icon for list-view items 

	//Create the full-sized icon image lists. 
	m_hLargeImageList = ImageList_Create(GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), ILC_MASK | ILC_COLOR16, 1, 1);
	m_hSmallImageList = ImageList_Create(GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), ILC_MASK | ILC_COLOR16, 1, 1);

	//Add an icon to each image list.  
	/*hiconItem = NULL;//LoadIcon (NULL, IDI_APPLICATION);
	ImageList_AddIcon(hLarge, hiconItem); 
	ImageList_AddIcon(hSmall, hiconItem); 
	DestroyIcon(hiconItem); */

	ListView_SetImageList(_m_hWnd, m_hLargeImageList, LVSIL_NORMAL);
	ListView_SetImageList(_m_hWnd, m_hSmallImageList, LVSIL_SMALL);
}
//---------------------------------------------------------------------------
CXListView::~CXListView() {
	LOG();
}
//---------------------------------------------------------------------------
INT CXListView::AddSmallIcon(HICON Icon) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ImageList_AddIcon(m_hSmallImageList, Icon);
}
//---------------------------------------------------------------------------
INT CXListView::AddLargeIcon(HICON Icon) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ImageList_AddIcon(m_hLargeImageList, Icon);
}
//---------------------------------------------------------------------------
BOOL CXListView::RemoveAllIcons() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ImageList_RemoveAll(m_hLargeImageList) && ImageList_RemoveAll(m_hSmallImageList);
}
//---------------------------------------------------------------------------
INT CXListView::GetColumnCount() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return m_ColumnCount;
}
//---------------------------------------------------------------------------
INT CXListView::GetItemCount() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return m_ItemCount;
}
//---------------------------------------------------------------------------
BOOL CXListView::AddColumn(std::string Text) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return AddColumn(Text, 100);
}
//---------------------------------------------------------------------------
BOOL CXListView::AddColumn(std::string Text, INT Width) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LVCOLUMN lvc;
	lvc.mask = LVCF_TEXT | LVCF_WIDTH;
	lvc.pszText = (char*)Text.c_str();
	lvc.cx = Width;

	return ListView_InsertColumn(_m_hWnd, m_ColumnCount ++, &lvc) !=  - 1;
}
//---------------------------------------------------------------------------
BOOL CXListView::DeleteColumn(INT Index) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	if (ListView_DeleteColumn(_m_hWnd, Index)) {
		m_ColumnCount --;
		return TRUE;
	} else {
		return FALSE;
	} 
}
//---------------------------------------------------------------------------
INT CXListView::AddItem(std::string Text) {
	return AddItem(Text, 0, 0);
}
//---------------------------------------------------------------------------
INT CXListView::AddItem(std::string Text, LPARAM lParam) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return AddItem(Text, lParam, 0);
}
//---------------------------------------------------------------------------
INT CXListView::AddItem(std::string Text, LPARAM lParam, INT Image) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LVITEM lvi;
	lvi.mask = LVIF_TEXT | LVIF_PARAM;
	lvi.iItem = m_ItemCount;
	lvi.iSubItem = 0;
	lvi.pszText = (char*)Text.c_str();
	if (lParam != 0) {
		lvi.mask |= LVIF_PARAM;
		lvi.lParam = lParam;
	}
	if (Image != 0) {
		lvi.mask |= LVIF_IMAGE;
		lvi.iImage = Image;
	}
	
	INT i = ListView_InsertItem(_m_hWnd, &lvi);
	if (i !=  - 1) {
		m_ItemCount ++;
	} 
	
	return i;
}
//---------------------------------------------------------------------------
BOOL CXListView::SetItem(std::string Text, INT Index, INT SubItem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return SetItem(Text, Index, SubItem, 0);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetItem(std::string Text, INT Index, INT SubItem, INT Image) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LVITEM lvi;
	lvi.mask = LVIF_TEXT;
	lvi.iItem = Index;
	lvi.iImage = Image;
	lvi.iSubItem = SubItem;
	lvi.pszText = (char*)Text.c_str();

	return ListView_SetItem(_m_hWnd, &lvi) !=  - 1;
}
//---------------------------------------------------------------------------
BOOL CXListView::SortItems(PFNLVCOMPARE pfnCompare, LPARAM lParamSort) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_SortItems(_m_hWnd, pfnCompare, lParamSort);
}
//---------------------------------------------------------------------------
BOOL CXListView::AutoSizeColumns() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	for (INT i = 0; i < m_ColumnCount; i ++) {
		ListView_SetColumnWidth(_m_hWnd, i, LVSCW_AUTOSIZE_USEHEADER);
	} 
	
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXListView::DeleteAllItems() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return TRUE == ListView_DeleteAllItems(_m_hWnd);
}
//---------------------------------------------------------------------------
INT CXListView::GetSelectedCount() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_GetSelectedCount(_m_hWnd);
}
//---------------------------------------------------------------------------
LPARAM CXListView::GetItemParam(INT Index) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LVITEM lvi;
	lvi.iItem = Index;
	lvi.iSubItem = 0;
	lvi.mask = LVIF_PARAM;
	if (ListView_GetItem(_m_hWnd, &lvi)) {
		return lvi.lParam;
	} else {
		return 0;
	} 
}
//---------------------------------------------------------------------------
LPARAM CXListView::GetSelectedItemParam() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	INT iSelIndex = ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
	if (- 1 == iSelIndex) {
		return 0;
	}

	return GetItemParam(iSelIndex);
}
//---------------------------------------------------------------------------
POINT CXListView::GetOrigin() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, POINT());

	POINT p;
	ListView_GetOrigin(_m_hWnd, &p);

	return p;
}
//---------------------------------------------------------------------------
BOOL CXListView::Scroll(INT x, INT y) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_Scroll(_m_hWnd, x, y) == TRUE;
}
//---------------------------------------------------------------------------
INT CXListView::GetTopIndex() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_GetTopIndex(_m_hWnd);
}
//---------------------------------------------------------------------------
BOOL CXListView::EnsureVisible(INT Index, BOOL PartialOK) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_EnsureVisible(_m_hWnd, Index, PartialOK) == TRUE;
}
//---------------------------------------------------------------------------
BOOL CXListView::SetExtendedListViewStyle(DWORD ExStyle) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	ListView_SetExtendedListViewStyle(_m_hWnd, ExStyle);
	
	return TRUE;
}
//---------------------------------------------------------------------------
BOOL CXListView::View(UINT View) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	LONG nStyle = ::GetWindowLong(_m_hWnd, GWL_STYLE);
	if ((nStyle &LVS_TYPEMASK) != View) {
		::SetWindowLong(_m_hWnd, GWL_STYLE, (nStyle &~LVS_TYPEMASK) | View);
	} 
	
	return TRUE;
}
//---------------------------------------------------------------------------
UINT CXListView::View() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ::GetWindowLong(_m_hWnd, GWL_STYLE) &LVS_TYPEMASK;
}
//---------------------------------------------------------------------------
INT CXListView::HitTest(INT x, INT y) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	m_HitTestInfo.pt.x = x;
	m_HitTestInfo.pt.y = y;
	
	return ListView_HitTest(_m_hWnd, &m_HitTestInfo);
}
//---------------------------------------------------------------------------
INT CXListView::SubItemHitTest(INT x, INT y) {
	m_HitTestInfo.pt.x = x;
	m_HitTestInfo.pt.y = y;
	return ListView_SubItemHitTest(_m_hWnd, &m_HitTestInfo);
}
//---------------------------------------------------------------------------
std::string CXListView::GetItemText(INT Item, INT SubItem) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	CHAR sText[1024];
	ListView_GetItemText(_m_hWnd, Item, SubItem, sText, 1024);

	return std::string(sText);
}
//---------------------------------------------------------------------------
BOOL CXListView::Arrange() {
	return Arrange(LVA_DEFAULT);
}
//---------------------------------------------------------------------------
BOOL CXListView::Arrange(UINT Code) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_Arrange(_m_hWnd, Code);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetColumnWidth(INT Column, INT Width) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_SetColumnWidth(_m_hWnd, Column, Width);
}
//---------------------------------------------------------------------------
BOOL CXListView::GetColumnOrderArray(INT *Order) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	if (Order == NULL) {
		Order = new INT[m_ColumnCount];
	} 
	
	return ListView_GetColumnOrderArray(_m_hWnd, m_ColumnCount, Order);
}
//---------------------------------------------------------------------------
BOOL CXListView::SetColumnOrderArray(INT *Order) {
	return ListView_SetColumnOrderArray(_m_hWnd, m_ColumnCount, Order);
}
//---------------------------------------------------------------------------
HIMAGELIST CXListView::LargeImageList() {
	return m_hLargeImageList;
}
//---------------------------------------------------------------------------
HIMAGELIST CXListView::SmallImageList() {
	return m_hSmallImageList;
}
//---------------------------------------------------------------------------
HICON CXListView::GetSelectedIcon(BOOL Small) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	INT iSelIndex = ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
	if (iSelIndex ==  - 1) {
		return 0;
	} 

	LVITEM lvi;
	lvi.iItem = iSelIndex;
	lvi.iSubItem = 0;
	lvi.mask = LVIF_IMAGE;
	if (!ListView_GetItem(_m_hWnd, &lvi)) {
		return 0;
	} 

	HICON Icon = ImageList_GetIcon(Small ? m_hSmallImageList : m_hLargeImageList, lvi.iImage, ILD_NORMAL);

	return Icon;
}
//---------------------------------------------------------------------------
INT CXListView::GetFirstSelectedIndex() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_GetNextItem(_m_hWnd, (WPARAM) - 1, LVNI_SELECTED);
}
//---------------------------------------------------------------------------
BOOL CXListView::SelectItem(INT Index) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	ListView_SetItemState(_m_hWnd, Index, LVNI_SELECTED, LVNI_SELECTED);
	
	return TRUE;
}
//---------------------------------------------------------------------------
INT CXListView::HitTest(LPLVHITTESTINFO pinfo) {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_HitTest(_m_hWnd, pinfo);
}
//---------------------------------------------------------------------------
HWND CXListView::GetHeader() {
	/*DEBUG*/XASSERT_RET(NULL != _m_hWnd, NULL);

	return ListView_GetHeader(_m_hWnd);
}
//---------------------------------------------------------------------------