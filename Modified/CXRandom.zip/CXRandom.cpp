/**********************************************************************
*	�����  CXRandom (CXRandom.cpp)  
*	
***********************************************************************/


#include "CXRandom.h"
//---------------------------------------------------------------------------
CXRandom::CXRandom() {
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
CXRandom::~CXRandom() {	
	m_hCrypt = NULL;
}
//---------------------------------------------------------------------------
BOOL CXRandom::bInitialize() {
	//Init CryptoAPI for random generation
	////if(!CryptAcquireContext(&m_hCrypt,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT))  {
	////	return FALSE;
	////}  else {
	////	return TRUE;
	////}

	return CryptAcquireContext(&m_hCrypt,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT);
}
//---------------------------------------------------------------------------
//Clean up CryptoAPI
BOOL CXRandom::bFinalize() {
	return CryptReleaseContext(m_hCrypt,0);
}
//---------------------------------------------------------------------------
////Return a single random byte from 0x00 to 0xFF
char CXRandom::cGetRandomByte() {
	char cRes;
	vGetRandomBytes(sizeof(cRes), &cRes);
	
	return cRes;
}
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF
void CXRandom::vGetRandomBytes(int iSize, char *pszBuff) {
	CryptGenRandom(m_hCrypt, iSize, (unsigned char *)pszBuff);
} 
//---------------------------------------------------------------------------
//Fill buf with random bytes ranging from 0x00 to 0xFF + '\0'
void CXRandom::vGetRandomBytes(int iSize, unsigned char *ucBuff) {
	CryptGenRandom(m_hCrypt, iSize, ucBuff);
	ucBuff[iSize - 1] = '\0';
} 
//---------------------------------------------------------------------------
//Return a random integer from 0 to INT_MAX
int CXRandom::iGetRandomInt() {
	int iRes;
	vGetRandomBytes(sizeof(iRes), (char *)&iRes);

	return iRes;
}
//---------------------------------------------------------------------------





/*
//---------------------------------------------------------------------------
int main(int argc, char* argv[]) {
	for (int i = 0; i < 4; i ++) {
		char         szBuff[8];
		
		my_random_init();
		get_random_bytes(8, szBuff);
		std::cout << szBuff << std::endl;
		my_random_shutdown();
	}

	system("pause");

	return 0;
}
//---------------------------------------------------------------------------
*/
