/**********************************************************************
*	�����  CXRandom (CXRandom.h)
*
***********************************************************************/


#ifndef CXRandomH
#define CXRandomH     
//---------------------------------------------------------------------------
#include <XLib/Common.h>
#include <wincrypt.h>
//---------------------------------------------------------------------------
class CXRandom {
	public:
		           CXRandom         ();
		           ~CXRandom        ();

		BOOL       bInitialize      ();
		BOOL       bFinalize        ();
		char       cGetRandomByte   ();
		void       vGetRandomBytes  (int iSize, char *pszBuff);
		void       vGetRandomBytes  (int iSize, unsigned char *ucBuff); 
		int        iGetRandomInt    ();
	
	private:
		HCRYPTPROV m_hCrypt;
};
//---------------------------------------------------------------------------
#endif